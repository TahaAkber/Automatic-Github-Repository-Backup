import { _clearState, _initiateApi } from './src/redux/actions/common/common';
import useNotificationSetup from './src/utils/hooks/useNotificationSetup';
import { _getStores } from '@redux/actions/merchant/merchant';
import { _globalLoader } from '@redux/actions/common/common';
import useReduxStore from '@utils/hooks/useReduxStore';
import { _login } from '@redux/actions/auth/auth';
import { useEffect } from 'react';
import { logAppOpenEvent } from './src/helper/eventTriggers/useEventTriggers';

const useApp = ({ }) => {
  const { dispatch, getState } = useReduxStore();
  const { notificationToken } = getState("common")
  const { notificationBanner, setNotificationBanner } = useNotificationSetup()

  useEffect(() => {
    dispatch(_clearState());

    // Log app open event
    logAppOpenEvent();
  }, []);

  return {
    notificationBanner,
    setNotificationBanner
  };
};

export default useApp;
