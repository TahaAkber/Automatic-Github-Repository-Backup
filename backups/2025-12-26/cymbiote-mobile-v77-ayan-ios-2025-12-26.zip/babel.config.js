module.exports = {
  presets: ['module:@react-native/babel-preset'],
  plugins: [ 
    [
      'module-resolver',
      {
        root: ['./src'],
        extensions: ['.js', '.json'],
        alias: {
          '@assets': './src/assets',
          '@screen': './src/screen',
          '@component': './src/component',
          '@constant': './src/constant',
          '@helper': './src/helper',
          '@materialComponent': './src/materialComponent', // Ensure this points correctly
          '@navigation': './src/navigation',
          '@redux': './src/redux',
          '@utils': './src/utils',
          '@hooks': './src/hooks',
        },
      },
    ],
    'react-native-reanimated/plugin'],
};
