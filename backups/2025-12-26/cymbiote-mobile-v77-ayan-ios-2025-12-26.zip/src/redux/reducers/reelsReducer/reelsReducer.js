import {
  FETCH_REELS,
  FETCH_REELS_LOADER,
  FETCH_REELS_ERROR,
  FETCH_REELS_PAGINATION,
  FETCH_SHOP_DATA,
  FETCH_LATEST_REEL,
  FETCH_LATEST_REEL_ERROR,
  FETCH_LATEST_REEL_LOADER,
  FETCH_SHOP_REELS,
  FETCH_SHOP_REELS_LOADER,
  FETCH_SHOP_REELS_ERROR,
  FETCH_STORIES,
  FETCH_SHOP_REELS_PAGINATION,
  RESET_SHOP_REELS,
} from '@redux/types/reels/reels';

import {
  FETCH_MERCHANT_REELS,
  FETCH_SHOP_SAVED_REELS,
  FETCH_USER_SAVED_REELS,
  FETCH_USER_SAVED_REELS_ERROR,
  FETCH_USER_SAVED_REELS_LOADER,
  TOGGLE_VOLUME,
  UPDATE_SHOP_REEL,
} from '../../types/reels/reels';
``;

const initialState = {
  reels: [],
  shop: {},
  shopReels: [],
  shopAndSavedReels: [],
  // merchantReels: [],
  shopsReels: [],
  stories: [],
  toggleVolume: false,
  latestReel: null,
  latestReelLoading: false,
  latestReelError: null,
  loading: false,
  error: null,
  shopReelsLoading: false,
  shopReelsError: null,
  userSavedReelsLoading: false,
  userSavedReelsError: null,
  userSavedReels: [],
  pagination: {
    totalReelCount: 0,
    totalPages: 0,
    currentPage: 1,
  },
};

const reelsReducer = (state = initialState, action) => {
  switch (action.type) {
    case FETCH_REELS_LOADER:
      return {...state, loading: action.payload};

    case FETCH_REELS:
      return {...state, reels: action.payload, error: null};

    case FETCH_REELS_PAGINATION:
      return {
        ...state,
        reels: [...state.reels, ...action.payload],
        error: null,
      };

    case FETCH_REELS_ERROR:
      return {...state, error: action.payload};

    case FETCH_SHOP_DATA:
      return {
        ...state,
        shop: action.payload,
      };

    case FETCH_SHOP_REELS_LOADER:
      return {...state, shopReelsLoading: action.payload};

    case FETCH_SHOP_REELS:
      if (action.payload.length === 0) {
        return state;
      }

      const existingIds = new Set(
        state.shopReels.map(item => item.video_url_id),
      );
      const filteredNewPayload = action.payload.filter(
        item => !existingIds.has(item.video_url_id),
      );

      const newShopReels = action.meta?.isPagination
        ? [...state.shopReels, ...filteredNewPayload]
        : action.payload;

      return {
        ...state,
        shopReels: newShopReels,
        shopReelsError: null,
      };

    case FETCH_SHOP_REELS_PAGINATION:
      return {
        ...state,
        pagination: {
          totalReelCount: action.payload.totalReelCount,
          totalPages: action.payload.totalPages,
          currentPage: action.payload.currentPage,
        },
      };

    case RESET_SHOP_REELS:
      return {
        ...state,
        shopReels: [],
        pagination: {
          totalReelCount: 0,
          totalPages: 0,
          currentPage: 1,
        },
      };

    case FETCH_SHOP_REELS_ERROR:
      return {...state, shopReelsError: action.payload};

    case FETCH_LATEST_REEL_LOADER:
      return {...state, latestReelLoading: action.payload};

    case FETCH_LATEST_REEL:
      return {...state, latestReel: action.payload, latestReelError: null};

    case FETCH_MERCHANT_REELS:
      return {...state, shopsReels: action.payload};

    case FETCH_SHOP_SAVED_REELS:
      return {
        ...state,
        shopAndSavedReels: action.payload,
      };

    case FETCH_STORIES:
      return {
        ...state,
        stories: action.payload,
      };
    case TOGGLE_VOLUME:
      return {
        ...state,
        toggleVolume: !state.toggleVolume,
      };
    case UPDATE_SHOP_REEL:
      return {
        ...state,
        shopReels: state.shopReels.map(reel =>
          reel.id === action.payload.id
            ? {...reel, ...action.payload.updates}
            : reel,
        ),
      };
    case FETCH_USER_SAVED_REELS_ERROR:
      return {...state, userSavedReelsError: action.payload};

    case FETCH_USER_SAVED_REELS_LOADER:
      return {...state, userSavedReelsLoading: action.payload};
    case FETCH_USER_SAVED_REELS:
      return {...state, userSavedReels: action.payload};
    default:
      return state;
  }
};

export default reelsReducer;
