import {
  FETCH_CONNECTED_ACCOUNT,
  FETCH_CONNECTED_ACCOUNT_ERROR,
  FETCH_CONNECTED_ACCOUNT_LOADER,
  FETCH_INTERNAL_ORDER,
  FETCH_INTERNAL_ORDER_ERROR,
  FETCH_INTERNAL_ORDER_LOADER,
  FETCH_CANCELLATION_ENUMS,
  FETCH_CANCELLATION_ENUMS_LOADER,
  FETCH_CANCELLATION_ENUMS_ERROR,
  CANCEL_ORDER,
  CANCEL_ORDER_LOADER,
  CANCEL_ORDER_ERROR,
  SET_PAGINATION,
} from '../../types/orders/orders';
import {
  FETCH_REVIEWS,
  FETCH_REVIEWS_ERROR,
  FETCH_REVIEWS_LOADER,
} from '../../types/reviews/reviews';

const initial_state = {
  fetch_user_reviews: {
    0: {},
    2: {},
    3: {},
    4: {},
  },
  fetch_user_reviews_loader: true,
  fetch_user_reviews_error: '',
};

const reviewReducer = (state = initial_state, action) => {
  switch (action.type) {
    case FETCH_REVIEWS:
      return {...state, fetch_user_reviews: action.payload};
    case FETCH_REVIEWS_LOADER:
      return {...state, fetch_user_reviews_loader: action.payload};
    case FETCH_REVIEWS_ERROR:
      return {...state, fetch_user_reviews_error: action.payload};
    default: {
      return state;
    }
  }
};
export default reviewReducer;
