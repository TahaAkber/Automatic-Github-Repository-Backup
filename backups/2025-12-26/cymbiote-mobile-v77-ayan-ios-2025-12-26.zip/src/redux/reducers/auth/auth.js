import { FETCH_TOKEN, FETCH_USER_DETAIL } from "../../types/auth/auth";

const initial_state = {
    token: "",
    guest_name: "Guest user",
    fetch_user_detail: {}
};

const authReducer = (state = initial_state, action) => {
    switch (action.type) {
        case FETCH_TOKEN:
            return { ...state, token: action.payload };
        case FETCH_USER_DETAIL:
            return { ...state, fetch_user_detail: action.payload };
        default: {
            return state;
        }
    }
};
export default authReducer;
