import {
  FETCH_ADDRESS,
  FETCH_ADDRESS_ERROR,
  FETCH_ADDRESS_LOADER,
  FETCH_FAVORITE_LIST,
  FETCH_FAVORITE_LIST_ERROR,
  FETCH_FAVORITE_LIST_LOADER,
  FETCH_FAVORITE_LIST_LOCAL,
  FETCH_RECENTLY_VIEWED,
  FETCH_RECENTLY_VIEWED_ERROR,
  FETCH_RECENTLY_VIEWED_LOADER,
  FETCH_RECENTLY_VIEWED_LOCALLY,
  FETCH_SHOP_CATEGORIES,
  FETCH_USER_NOTIFICATION_STATUSES,
  FETCH_USER_NOTIFICATIONS,
  FETCH_USER_NOTIFICATIONS_ERROR,
  SELECTED_CATEGORIES,
} from '../../types/user/user';

const initial_state = {
  fetch_recent_viewed: [],
  fetch_recent_viewed_error: '',
  fetch_recent_viewed_loader: false,
  fetch_recent_viewed_locally: [],
  fetch_address: [],
  fetch_address_error: '',
  fetch_address_loader: false,
  fetch_set_address_default: false,
  fetch_favorite_list: [],
  fetch_favorite_list_loader: false,
  fetch_favorite_list_error: '',
  fetch_favorite_list_local: [],
  fetch_favorite_list_local: [],
  fetch_shop_categories: [],
  selected_categories: [],
  fetch_user_notification_statuses: {},
  fetch_user_notifications: {},
  fetch_user_notifications_error: '',
};

const userReducer = (state = initial_state, action) => {
  switch (action.type) {
    case FETCH_RECENTLY_VIEWED:
      return {...state, fetch_recent_viewed: action.payload};
    case FETCH_RECENTLY_VIEWED_ERROR:
      return {...state, fetch_recent_viewed_error: action.payload};
    case FETCH_RECENTLY_VIEWED_LOADER:
      return {...state, fetch_recent_viewed_loader: action.payload};
    case FETCH_RECENTLY_VIEWED_LOCALLY:
      return {...state, fetch_recent_viewed_locally: action.payload};
    case FETCH_ADDRESS:
      return {...state, fetch_address: action.payload};
    case FETCH_ADDRESS_ERROR:
      return {...state, fetch_address_error: action.payload};
    case FETCH_ADDRESS_LOADER:
      return {...state, fetch_address_loader: action.payload};
    case FETCH_FAVORITE_LIST:
      return {...state, fetch_favorite_list: action.payload};
    case FETCH_FAVORITE_LIST_LOADER:
      return {...state, fetch_favorite_list_loader: action.payload};
    case FETCH_FAVORITE_LIST_ERROR:
      return {...state, fetch_favorite_list_error: action.payload};
    case FETCH_FAVORITE_LIST_LOCAL:
      return {...state, fetch_favorite_list_local: action.payload};
    case FETCH_SHOP_CATEGORIES:
      return {...state, fetch_shop_categories: action.payload};
    case SELECTED_CATEGORIES:
      return {...state, selected_categories: action.payload};
    case FETCH_USER_NOTIFICATION_STATUSES:
      return {...state, fetch_user_notification_statuses: action.payload};
    case FETCH_USER_NOTIFICATIONS:
      return {...state, fetch_user_notifications: action.payload};
    case FETCH_USER_NOTIFICATIONS_ERROR:
      return {...state, fetch_user_notifications_error: action.payload};
    default: {
      return state;
    }
  }
};
export default userReducer;
