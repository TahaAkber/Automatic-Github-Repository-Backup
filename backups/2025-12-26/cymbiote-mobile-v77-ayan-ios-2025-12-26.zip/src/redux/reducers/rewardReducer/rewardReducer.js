// // import { GET_USER_POINTS, GET_USER_POINTS_LOADER, GET_USER_POINTS_ERROR } from "@redux/types/reward/reward";
// // import { GET_USER_POINTS_HISTORY, GET_USER_VOUCHERS, GET_USER_VOUCHERS_ERROR } from "../../types/reward/reward";

// // const initial_state = {
// //   user_point: {},
// //   user_point_loader: false,
// //   user_point_error: "",
// //   user_point_history:[],

// //   user_vouchers:{},
// //   user_vouchers_loader:false,
// //   user_vouchers_error:"",
// // };

// // const RewardReducer = (state = initial_state, action) => {
// //   switch (action.type) {
// //     case GET_USER_POINTS:
// //       return { ...state, user_point: action.payload };
// //       case GET_USER_POINTS_HISTORY:
// //         return { ...state, user_point_history: action.payload || [] };
// //     case GET_USER_POINTS_LOADER:
// //       return { ...state, user_point_loader: action.payload };
// //     case GET_USER_POINTS_ERROR:
// //       return { ...state, user_point_error: action.payload };
// //     case GET_USER_VOUCHERS:
// //       return { ...state, user_vouchers: action.payload };
// //     case GET_USER_POINTS_LOADER:
// //       return { ...state, user_poinuser_vouchers_loadert_error: action.payload };
// //     case GET_USER_VOUCHERS_ERROR:
// //       return { ...state, user_vouchers_error: action.payload };
// //     default: {
// //       return state;
// //     }
// //   }
// // };
// // export default RewardReducer;



import {
  GET_USER_POINTS,
  GET_USER_POINTS_LOADER,
  GET_USER_POINTS_ERROR,
  GET_USER_POINTS_HISTORY,
  GET_USER_POINTS_HISTORY_LOADER,
  GET_USER_POINTS_HISTORY_ERROR,
  APPEND_USER_POINTS_HISTORY,
  GET_USER_VOUCHERS,
  GET_USER_VOUCHERS_LOADER,
  GET_USER_VOUCHERS_ERROR,
} from "@redux/types/reward/reward";

const initial_state = {
  user_point: {},
  user_point_loader: false,
  user_point_error: "",
  user_point_history: {
      1: {}, // All points
      2: {}, // Order Points
      3: {}, // Milestone Points
      4: {}, // Rewards Redemption
      5: {}, // Product Category Points
  },
  user_point_history_loader: true,
  user_point_history_error: "",
 

  user_vouchers: {},
  user_vouchers_loader: false,
  user_vouchers_error: "",

  pagination: { totalPages: 1, currentPage: 1, pageSize: 10 },
};

const RewardReducer = (state = initial_state, action) => {
  switch (action.type) {
      case GET_USER_POINTS:
          return { ...state, user_point: action.payload };

      case GET_USER_POINTS_HISTORY: 
          return {
            ...state ,user_point_history:action.payload
          };
        case GET_USER_POINTS_HISTORY_LOADER:
          return { ...state, user_point_history_loader: action.payload };

      case GET_USER_POINTS_HISTORY_ERROR:
          return { ...state, user_point_history_error: action.payload };

      case GET_USER_POINTS_LOADER:
          return { ...state, user_point_loader: action.payload };

      case GET_USER_POINTS_ERROR:
          return { ...state, user_point_error: action.payload };

      case GET_USER_VOUCHERS:
          return { ...state, user_vouchers: action.payload };

      case GET_USER_VOUCHERS_LOADER:
          return { ...state, user_vouchers_loader: action.payload };

      case GET_USER_VOUCHERS_ERROR:
          return { ...state, user_vouchers_error: action.payload };

      default:
          return state;
  }
};

export default RewardReducer;

// import {
//   GET_USER_POINTS,
//   GET_USER_POINTS_LOADER,
//   GET_USER_POINTS_ERROR,
//   GET_USER_POINTS_HISTORY,
//   GET_USER_POINTS_HISTORY_LOADER,
//   GET_USER_POINTS_HISTORY_ERROR,
//   APPEND_USER_POINTS_HISTORY,
//   GET_USER_VOUCHERS,
//   GET_USER_VOUCHERS_LOADER,
//   GET_USER_VOUCHERS_ERROR,
// } from "@redux/types/reward/reward";

// const initial_state = {
//   user_point: {},
//   user_point_loader: false,
//   user_point_error: "",

//   user_point_history: {
//     0: { points: [], pagination: { totalPages: 1, currentPage: 1, pageSize: 10 } }, // All points
//     2: { points: [], pagination: { totalPages: 1, currentPage: 1, pageSize: 10 } }, // Order Points
//     3: { points: [], pagination: { totalPages: 1, currentPage: 1, pageSize: 10 } }, // Milestone Points
//     4: { points: [], pagination: { totalPages: 1, currentPage: 1, pageSize: 10 } }, // Rewards Redemption
//     6: { points: [], pagination: { totalPages: 1, currentPage: 1, pageSize: 10 } }, // Product Category Points
//   },
//   user_point_history_loader: false,
//   user_point_history_error: "",

//   user_vouchers: {},
//   user_vouchers_loader: false,
//   user_vouchers_error: "",
//   voucher_pagination: { totalPages: 1, currentPage: 1, pageSize: 10 },
// };

// const RewardReducer = (state = initial_state, action) => {
//   switch (action.type) {
//     case GET_USER_POINTS:
//       return { ...state, user_point: action.payload };

//     case GET_USER_POINTS_HISTORY:
//       return {
//         ...state,
//         user_point_history: {
//           ...state.user_point_history,
//           [action.payload.tab || 0]: {
//             points: action.payload.points,
//             pagination: action.payload.pagination,
//           },
//         },
//       };

//     case APPEND_USER_POINTS_HISTORY:
//       return {
//         ...state,
//         user_point_history: {
//           ...state.user_point_history,
//           [action.payload.tab]: {
//             points: [
//               ...(state.user_point_history[action.payload.tab]?.points || []),
//               ...action.payload.points,
//             ],
//             pagination: action.payload.pagination,
//           },
//         },
//       };

//     case GET_USER_POINTS_HISTORY_LOADER:
//       return { ...state, user_point_history_loader: action.payload };

//     case GET_USER_POINTS_HISTORY_ERROR:
//       return { ...state, user_point_history_error: action.payload };

//     case GET_USER_POINTS_LOADER:
//       return { ...state, user_point_loader: action.payload };

//     case GET_USER_POINTS_ERROR:
//       return { ...state, user_point_error: action.payload };

//     case GET_USER_VOUCHERS:
//       return { ...state, user_vouchers: action.payload , };

//     case GET_USER_VOUCHERS_LOADER:
//       return { ...state, user_vouchers_loader: action.payload };

//     case GET_USER_VOUCHERS_ERROR:
//       return { ...state, user_vouchers_error: action.payload };

//     default:
//       return state;
//   }
// };

// export default RewardReducer;