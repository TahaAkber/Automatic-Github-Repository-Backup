import {
  FETCH_CART_DB_ITEM,
  FETCH_CART_DB_ITEM_ERORR,
  FETCH_CART_DB_ITEM_LOADER,
  FETCH_CART_ITEM,
  ADD_TO_CART,
} from '@redux/types/cart/cart';
import {call, showToast} from '@helper/reUsableMethod/reUsableMethod';
import {_commonDispatcher, _globalLoader} from '../common/common';
import {navigate} from '@utils/navigationRef/navigationRef';
import {getStoreState} from '@utils/helper/helper';
import {_getAddress} from '../user/user';
import {store} from '@redux/store/store';

import {getDeviceId} from '../../../utils/helper/helper';
import {
  CART_ITEM_LOADER,
  RESET_CART,
  SYNC_CART_TO_DB_ERROR,
  SYNC_CART_TO_DB_LOADING,
  SYNC_CART_TO_DB_SUCCESS,
} from '../../types/cart/cart';

const toCartToastMessage = err => {
  const raw =
    err?.info?.data?.error ??
    err?.info?.data?.message ??
    err?.message ??
    String(err || '');

  const firstLine = raw
    .split('\n')[0]
    .replace(/^Error:\s*/i, '')
    .trim();

  const m = firstLine.match(
    /Insufficient stock for variant\s+(\d+)\.\s*Requested\s+(\d+),\s*available\s+(\d+)/i,
  );
  if (m) {
    const requested = Number(m[2]),
      available = Number(m[3]);
    return `Only ${available} left (you requested ${requested}).`;
  }
  return firstLine || 'Something went wrong.';
};

export const _addToCart = (
  shop_id,
  variant_id,
  quantityOrDelta,
  isSetQuantity = false,
  options = {},
) => {
  return async (dispatch, getState) => {
    const {cart_item} = getStoreState('cart');
    // const {cart_item} = getState().cart;
    const user_id = getState().auth.fetch_user_detail?.id ?? null;

    // --- Device Identifier Fallback ---
    let deviceIdentifier;
    try {
      deviceIdentifier = await getDeviceId();
    } catch (error) {
      console.error('Failed to get device ID, using fallback:', error);
      deviceIdentifier = `fallback-${Date.now()}`;
    }
    if (!deviceIdentifier) deviceIdentifier = `fallback-${Date.now()}`;

    // --- Unique Cart ID ---
    const cartId = user_id
      ? `user-${shop_id}-${user_id}`
      : `device-${shop_id}-${deviceIdentifier}`;

    // --- Existing cart data ---
    const existingShopCart = cart_item.find(item => item.cartId === cartId);

    const previousPreCartItems = existingShopCart
      ? existingShopCart.products.map(product => ({
          pre_cart_item_id: product.cart_item_id,
          pre_cart_item_variant_id: product.product_variant.variant.variant_id,
          pre_cart_item_quantity: product.quantity,
        }))
      : [];
    // --- Update item quantity ---
    const variantIndex = previousPreCartItems.findIndex(
      item => item.pre_cart_item_variant_id === variant_id,
    );

    let updatedPreCartItems = [...previousPreCartItems];
    if (variantIndex !== -1) {
      if (isSetQuantity) {
        updatedPreCartItems[variantIndex].pre_cart_item_quantity =
          quantityOrDelta; // final quantity
      } else {
        updatedPreCartItems[variantIndex].pre_cart_item_quantity +=
          quantityOrDelta; // delta
      }
    } else if (quantityOrDelta > 0) {
      updatedPreCartItems.push({
        // pre_cart_item_id: null,
        pre_cart_item_variant_id: variant_id,
        pre_cart_item_quantity: quantityOrDelta,
      });
    }

    // Remove zero-quantity items
    updatedPreCartItems = updatedPreCartItems.filter(
      item => item.pre_cart_item_quantity > 0,
    );

    // --- Prevent accidental empty cart clear ---
    if (!updatedPreCartItems.length) {
      console.warn('No items in updatedPreCartItems, skipping API call');
      return;
    }

    const payload = {
      cart_id: cartId,
      deviceIdentifier,
      shop_id,
      pre_cart_items: updatedPreCartItems,
      ...(user_id ? {user_id} : {}),
    };

    try {
      dispatch(_commonDispatcher(SYNC_CART_TO_DB_LOADING, true));

      const responseData = await call({
        baseUrl: `/carts/add-to-cart`,
        method: 'POST',
        body: JSON.stringify(payload),
        signal: options?.signal,
      });
      console.log(responseData, '<AddToCart API response>');

      if (!responseData || responseData.error) {
        showToast('Add to cart failed', responseData?.error);
        dispatch(
          _commonDispatcher(
            SYNC_CART_TO_DB_ERROR,
            responseData?.error || 'Unknown error',
          ),
        );
        return;
      }

      // --- Refresh state after success ---
      if (!isSetQuantity) {
        await dispatch(_getCardItems());
      } else {
        const updatedCartItem = cart_item
          .map(shop => {
            if (shop.cartId === cartId) {
              const updatedProducts = shop.products
                .map(product => {
                  if (
                    product.product_variant.variant.variant_id === variant_id
                  ) {
                    const newQty = updatedPreCartItems.find(
                      item => item.pre_cart_item_variant_id === variant_id,
                    )?.pre_cart_item_quantity;
                    return newQty && newQty > 0
                      ? {...product, quantity: newQty}
                      : null;
                  }
                  return product;
                })
                .filter(Boolean);
              return updatedProducts.length
                ? {...shop, products: updatedProducts}
                : null;
            }
            return shop;
          })
          .filter(Boolean);

        dispatch({type: FETCH_CART_DB_ITEM, payload: updatedCartItem});
      }
    } catch (error) {

      const msg = toCartToastMessage(error);
      showToast(msg);

      dispatch(_commonDispatcher(SYNC_CART_TO_DB_ERROR, error.message));
    } finally {
      dispatch(_commonDispatcher(SYNC_CART_TO_DB_LOADING, false));
    }
  };
};

// !isSetQuantity && (await dispatch(_getCardItem s()));

// export const _addToCart = (shop_id, variant_id, increament_decreament) => {
//   console.log(
//     shop_id,
//     variant_id,
//     increament_decreament,
//     'shop_id, variant_id, increament_decreament',
//   );
//   return async dispatch => {
//     const cart = store.getState().cart.cart;
//     const uniqueDate =
//       new Date().getDate() +
//       '' +
//       new Date().getMonth() +
//       '' +
//       new Date().getFullYear() +
//       '' +
//       new Date().getTime() +
//       '' +
//       new Date().getSeconds();
//     const shopIndex = cart.findIndex(shop => shop.shop_id === shop_id);
//     if (shopIndex !== -1) {
//       const shop = cart[shopIndex];
//       const productIndex = shop.product_variant.findIndex(
//         variant => variant.variant_id === variant_id,
//       );

//       if (productIndex !== -1) {
//         const product = shop.product_variant[productIndex];
//         product.qty += increament_decreament;

//         if (product.qty <= 0) {
//           shop.product_variant.splice(productIndex, 1);

//           if (shop.product_variant.length === 0) {
//             cart.splice(shopIndex, 1);
//           }
//         }
//       } else {
//         shop.product_variant.push({variant_id, qty: 1});
//       }
//     } else {
//       cart.push({
//         shop_id,
//         customCartId: uniqueDate,
//         product_variant: [{variant_id, qty: 1}],
//       });
//     }
//     dispatch(_getCardItems(cart));
//     dispatch({
//       type: FETCH_CART_ITEM,
//       payload: cart,
//     });
//   };
// };

// export const _removeCartProduct = (shop_id, variant_id) => {
//   return async dispatch => {
//     const cart = store.getState().cart.cart;

//     const shopIndex = cart.findIndex(shop => shop.shop_id === shop_id);

//     if (shopIndex !== -1) {
//       const shop = cart[shopIndex];
//       const productIndex = shop.product_variant.findIndex(
//         variant => variant.variant_id === variant_id,
//       );

//       if (productIndex !== -1) {
//         // Remove the product variant from the cart
//         shop.product_variant.splice(productIndex, 1);

//         // If no more products are in this shop, remove the shop from the cart
//         if (shop.product_variant.length === 0) {
//           cart.splice(shopIndex, 1);
//         }
//       }
//     }

//     // Dispatch the updated cart to the store
//     dispatch({
//       type: FETCH_CART_ITEM,
//       payload: cart,
//     });
//   };
// };
export const _removeCartProduct = (shop_id, cartItemId) => {
  return async (dispatch, getState) => {
    const cart = getState().cart.cart_item;

    const updatedCart = cart
      .map(shop => {
        if (shop.shop.shop_id === shop_id) {
          const updatedVariants = shop.products.filter(
            variant => variant.cart_item_id !== cartItemId,
          );

          if (updatedVariants.length === 0) {
            return null; // Mark this shop for removal if no products left
          }

          return {
            ...shop,
            products: updatedVariants,
          };
        }
        return shop;
      })
      .filter(shop => shop !== null);
    const preCartItemId = cartItemId;
    try {
      const responseData = await call({
        baseUrl: `/carts/cart-item/${preCartItemId}`,
        method: 'DELETE',
      });

      if (responseData.status === 200) {
      } else {
        console.error('Failed to remove product from the backend');
      }

      dispatch({
        type: FETCH_CART_DB_ITEM,
        payload: updatedCart,
      });
    } catch (error) {
      if (error.response) {
      } else {
        console.error(
          'Error removing product variant:',
          error.message || error,
        );
      }
      console.error('Full error object:', JSON.stringify(error, null, 2));
    }
  };
};

export const _removeShop = (shop_id, cartId) => {
  return async dispatch => {
    const cart = store.getState().cart.cart;
    const cart_item = store.getState().cart.cart_item;

    const cartDataUpdated = cart_item.filter(
      shop => shop.shop.shop_id != shop_id,
    );
    try {
      dispatch({type: 'CART_REMOVE_LOADER', payload: true}); // show loader

      const responseData = await call({
        baseUrl: `/carts/cart/${cartId}`,
        method: 'DELETE',
      });

      if (responseData.status === 200) {
        console.log('cart removed successfully from the backend');
      } else {
        console.error('Failed to remove cart from the backend');
      }
      console.log(cartDataUpdated, 'updatedCart from remove');
      dispatch({type: 'CART_REMOVE_LOADER', payload: false}); // show loader

      dispatch({
        type: FETCH_CART_DB_ITEM,
        payload: cartDataUpdated,
      });
    } catch (error) {
      dispatch({type: 'CART_REMOVE_LOADER', payload: false});
      console.error('Error removing Cart:', error);
    }
  };
};

export const _getCardItems = (params = {}) => {
  return async dispatch => {
    try {
      dispatch(_commonDispatcher(FETCH_CART_DB_ITEM_ERORR, ''));
      dispatch(_commonDispatcher(CART_ITEM_LOADER, true)); // Start loader
      const {fetch_user_detail} = getStoreState('auth');
      const user_id = params.userId || fetch_user_detail?.id;
      const deviceId = await getDeviceId();
      let queryParam = '';
      if (user_id) {
        queryParam = `user_id=${user_id}`;
      } else {
        queryParam = `device_identifier=${deviceId}`;
      }
      const responseData = await call({
        baseUrl: `/carts/cart?${queryParam}`,
        method: 'GET',
      });
      dispatch(_commonDispatcher(FETCH_CART_DB_ITEM, responseData.data));
      dispatch(_commonDispatcher(CART_ITEM_LOADER, false));
      dispatch(_commonDispatcher(FETCH_CART_DB_ITEM_ERORR, ''));
      return 1;
    } catch (error) {
      dispatch(_commonDispatcher(FETCH_CART_DB_ITEM_ERORR, error.message));
      dispatch(_commonDispatcher(CART_ITEM_LOADER, false));
      return 0;
    }
  };
};

export const _checkout = (array, user_id, voucher_code, shopifyCheckout) => {
  return async dispatch => {
    try {
      const {fetch_user_detail} = getStoreState('auth');
      const {cart} = getStoreState('cart');

      const uniqueDate =
        new Date().getDate() +
        '' +
        new Date().getMonth() +
        '' +
        new Date().getFullYear() +
        '' +
        new Date().getTime() +
        '' +
        new Date().getSeconds();

      const fetchAddress = await dispatch(_getAddress(user_id));
      const shop = cart.find(item => item.shop_id == array?.shop?.shop_id);
      const getVariants = array?.products.map((item, index) => {
        return {
          variant_id: item.product_variant?.variant?.variant_shopify_id,
          quantity: item.quantity,
        };
      });

      const addresses = fetchAddress.map((item, index) => {
        return {
          address: {
            deliveryAddress: {
              address1: item.address_one,
              address2: item.address_two,
              city: item.address_city,
              countryCode: 'PK',
              firstName: item.address_first_name,
              lastName: item.address_last_name,
              phone: item.address_number,
              zip: item.address_postal_code,
            },
          },
          oneTimeUse: false,
          selected: item.address_default_select,
          validationStrategy: 'COUNTRY_CODE_ONLY',
        };
      });

      const rawData = {
        shop: array?.shop?.shop_domain,
        email: fetch_user_detail.email,
        // phone: fetch_user_detail.user_phone,
        voucherCode: voucher_code || '',
        customCartId: shop?.customCartId || uniqueDate,
        lineItems: getVariants,
        // shipping_address: formatAddress(address, fetch_user_detail?.user_phone),
        // billing_address: formatAddress(address, fetch_user_detail?.user_phone),
        addresses,
        cercle_user_id: user_id,
      };

      console.log('rawData =>', rawData);

      const responseData = await call({
        baseUrl: `/order/create-storefront-order`,
        method: 'POST',
        body: JSON.stringify(rawData),
      });

      // const product = {

      // }

      const data = {
        cartId: uniqueDate,
        userId: fetch_user_detail?.id,
        checkoutUrl: responseData?.data?.checkoutUrl,
        shop_id: array?.shop?.shop_id,
        item: array,
      };

      // navigate('Checkout', {
      //   cartId: uniqueDate,
      //   userId: fetch_user_detail?.id,
      //   checkoutUrl: responseData?.data?.checkoutUrl,
      //   shop_id: array?.shop?.shop_id,
      //   item: array,
      // });

      shopifyCheckout.present(responseData?.data?.checkoutUrl);
      return data || false;
    } catch (error) {
      showToast(error?.message);
      return 0;
    }
  };
};

export const _getCardItemsAfterLogin = userId => {
  return async (dispatch, getState) => {
    if (userId) {
      try {
        dispatch(_commonDispatcher(FETCH_CART_DB_ITEM_ERORR, ''));
        dispatch(_commonDispatcher(CART_ITEM_LOADER, true)); // Start loader

        // Build query params
        let queryParams = '';
        if (userId) {
          queryParams = `user_id=${userId}`;
        }

        const responseData = await call({
          baseUrl: `/carts/cart?${queryParams}`,
          method: 'GET',
        });

        const data = responseData.data;
        console.log(responseData, 'cart data hu');

        dispatch(_commonDispatcher(FETCH_CART_DB_ITEM, data));
        dispatch(_commonDispatcher(CART_ITEM_LOADER, false)); // Stop loader

        return 1;
      } catch (error) {
        console.log('error.message', error.message);
        dispatch(_commonDispatcher(FETCH_CART_DB_ITEM_ERORR, error.message));
        dispatch(_commonDispatcher(CART_ITEM_LOADER, false)); // Stop loader on error
        return 0;
      }
    }
  };
};

export const _assignGuestCartToUser = payload => {
  return async dispatch => {
    try {
      console.log(payload, 'payloadpayload');
      const response = await call({
        baseUrl: '/carts/assign-user',
        method: 'POST',
        body: JSON.stringify(payload),
      });

      if (response.status !== 200) {
        console.error('Failed to assign cart to user', response);
      }

      return response;
    } catch (error) {
      console.error('Error in _assignGuestCartToUser:', error);
      throw error;
    }
  };
};

export const assignGuestCartToUser = userId => {
  return async (dispatch, getState) => {
    try {
      let deviceIdentifier;
      try {
        deviceIdentifier = await getDeviceId();
      } catch {
        deviceIdentifier = '';
      }

      const cart_item = getState().cart.cart_item;

      // Filter carts linked to this device
      const deviceCarts = cart_item.filter(cart =>
        cart.cartId?.startsWith('device'),
      );

      if (!deviceCarts.length) return;

      if (!userId) {
        console.warn('No user id found, cannot assign cart');
        return;
      }

      // Extract all cart IDs from device carts
      const cartIds = deviceCarts.map(cart => cart.cartId);

      // Prepare payload for bulk assignment API
      const payload = {
        cartIds,
        userId,
      };

      console.log(cartIds, userId, 'cartIds, userId');

      // Dispatch the new bulk assign action once
      const response = await dispatch(_assignGuestCartToUser(payload));

      // Optionally refresh cart after assignment
      if (response && response.status === 200) {
        await dispatch(_getCardItemsAfterLogin(userId));
      }
    } catch (error) {
      console.error('Error assigning guest cart to user:', error);
    }
  };
};

export const resetCart = () => ({
  type: RESET_CART,
});
