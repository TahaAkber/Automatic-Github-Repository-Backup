import {call, showToast} from '../../../helper/reUsableMethod/reUsableMethod';
import {getStoreState} from '../../../utils/helper/helper';
import {
  FETCH_REVIEWS,
  FETCH_REVIEWS_ERROR,
  FETCH_REVIEWS_LOADER,
} from '../../types/reviews/reviews';
import {_uploadImage} from '../common/common';

export const _getUserReviews = ({page, tab, pull = false}) => {
  return async dispatch => {
    const {fetch_user_detail} = getStoreState('auth');
    const {fetch_user_reviews} = getStoreState('reviews');
    try {
      // const responseData = await call({ baseUrl: `/api/review/user-reviews?page=${page}&user_id=${fetch_user_detail?.id}&status=${tab}`, method: "POST" });
      const responseData = await call({
        baseUrl: `/review/user-reviews?page=${page}&user_id=${fetch_user_detail?.id}&status=${tab}`,
        // baseUrl: `/review/user-reviews?page=${page}&user_id=${55}&status=${tab}`,
        method: 'POST',
      });
      if (page === 1) {
        let updatedResponse = responseData;

        if (pull) {
          const previousData = fetch_user_reviews?.[tab]?.data || [];
          const updatedData = [
            ...responseData.data.slice(
              0,
              responseData?.pagination?.pageSize || 0,
            ),
            ...previousData.slice(responseData?.pagination?.pageSize || 0),
          ];
          updatedResponse = {...responseData, data: updatedData};
        }

        const data = {...fetch_user_reviews, [tab]: updatedResponse};
        dispatch({type: FETCH_REVIEWS, payload: data});
        dispatch({type: FETCH_REVIEWS_ERROR, payload: ''});
      } else {
        let previousData = fetch_user_reviews?.[tab]?.data || [];
        let updatedData = [...previousData, ...responseData.data];

        const updatedResponse = {...responseData, data: updatedData};
        const data = {...fetch_user_reviews, [tab]: updatedResponse};
        dispatch({type: FETCH_REVIEWS, payload: data});
        dispatch({type: FETCH_REVIEWS_ERROR, payload: ''});
      }
      dispatch({type: FETCH_REVIEWS_LOADER, payload: false});
      dispatch({type: FETCH_REVIEWS_ERROR, payload: ''});
    } catch (error) {
      const data = {...fetch_user_reviews, [tab]: {data: []}};
      dispatch({type: FETCH_REVIEWS, payload: data});
      dispatch({type: FETCH_REVIEWS_ERROR, payload: error?.message});
      dispatch({type: FETCH_REVIEWS_LOADER, payload: false});
      return 0;
    }
  };
};

export const _sendUserReview = ({
  comment,
  rating,
  local_images,
  order_item_id,
}) => {
  return async dispatch => {
    try {
      const safeUpload = async (image, retries = 2) => {
        for (let i = 0; i <= retries; i++) {
          const result = await dispatch(_uploadImage({local_image: image}));
          if (result && result !== 0) return result;
        }
        return 0;
      };

      const uploadPromises = local_images.map(image => safeUpload(image));

      const imagesArr = await Promise.all(uploadPromises);
      const rawData = {
        order_item_review_comment: comment,
        order_item_review_rating: rating,
        order_item_id: order_item_id,
        images: imagesArr,
      };

      const responseData = await call({
        baseUrl: `/review/send-order-review`,
        method: 'POST',
        body: JSON.stringify(rawData),
      });
      showToast('Review submitted successfully');
      return 1;
    } catch (error) {
      showToast(error?.message || 'Something went wrong');
      return 0;
    }
  };
};

export const _getReviewDetail = order_item_review_id => {
  return async dispatch => {
    try {
      const rawData = {
        order_item_review_id,
      };

      const responseData = await call({
        baseUrl: `/review/review-detail`,
        method: 'POST',
        body: JSON.stringify(rawData),
      });
      return responseData;
    } catch (error) {
      showToast(error?.message || 'Something went wrong');
      return 0;
    }
  };
};

export const _sendComment = (
  order_item_review_id,
  commenter_type,
  commenter_id,
  comment_text,
  comment_images,
  parent_comment_id,
) => {
  return async dispatch => {
    try {
      const rawData = {
        reviewId: order_item_review_id,
        parentCommentId: parent_comment_id || null,
        commenterType: commenter_type,
        commenterId: commenter_id,
        commentText: comment_text,
        commentImages: comment_images,
      };

      const responseData = await call({
        baseUrl: `/review/comment`,
        method: 'POST',
        body: JSON.stringify(rawData),
      });
      showToast('Comment submitted successfully');
      return 1;
    } catch (error) {
      showToast(error?.message || 'Something went wrong');
      return 0;
    }
  };
};

export const _reviewReaction = (order_item_review_id, entry) => {
  return async dispatch => {
    const {fetch_user_detail} = getStoreState('auth');
    try {
      const rawData = {
        reviewId: order_item_review_id,
        reactorType: 'user',
        reactorId: fetch_user_detail?.id,
        reactionType: 'like',
        reactionRemove: entry,
      };

      console.log('rawData', JSON.stringify(rawData));

      const responseData = await call({
        baseUrl: `/review/reaction`,
        method: 'POST',
        body: JSON.stringify(rawData),
      });
      return 1;
    } catch (error) {
      showToast(error?.message || 'Something went wrong');
      return 0;
    }
  };
};
