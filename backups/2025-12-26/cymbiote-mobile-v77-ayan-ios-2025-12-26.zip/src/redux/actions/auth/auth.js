import {
  _appendToUserIntrest,
  _commonDispatcher,
  _fetchUserIntrestList,
  _globalLoader,
  _initiateApi,
  _introSliderSkip,
} from '../common/common';
import {call, showToast} from '@helper/reUsableMethod/reUsableMethod';
import {FETCH_TOKEN, FETCH_USER_DETAIL} from '../../types/auth/auth';
import {navigate} from '@utils/navigationRef/navigationRef';
import {getDecodedDetail} from '@utils/helper/helper';
import {_appendToFollowingList, _getStores} from '../merchant/merchant';
import {
  _appendToFavoriteList,
  _getUserNotificationStatuses,
} from '../user/user';
import {getDeviceId, getStoreState} from '../../../utils/helper/helper';
import {_getCardItemsAfterLogin, assignGuestCartToUser} from '../cart/cart';
import DeviceInfo from 'react-native-device-info';

export const _login = ({email, password, deviceId, deviceName, remember}) => {
  return async dispatch => {
    const rawData = {
      identifier: email,
      password: password,
      device_id: deviceId,
      device_name: deviceName,
      remember_device: remember,
      login_type: 'email',
    };
    try {
      dispatch(_commonDispatcher(FETCH_TOKEN, ''));
      const responseData = await call({
        baseUrl: `/auth/login`,
        method: 'POST',
        body: JSON.stringify(rawData),
      });
      if (responseData?.token) {
        const decoded = getDecodedDetail(responseData?.token);
        dispatch(_initiateApi(false, decoded?.id));
        dispatch(_commonDispatcher(FETCH_TOKEN, responseData?.token));
        dispatch(_commonDispatcher(FETCH_USER_DETAIL, decoded));

        // goBack()
      } else {
        rawData.message = responseData.message;
        navigate('Otp', {data: rawData});
      }

      return 1;
    } catch (error) {
      showToast(error.message);
      dispatch(_commonDispatcher(FETCH_TOKEN, ''));
      return 0;
    }
  };
};

export const _socialLogin = ({data}) => {
  return async dispatch => {
    const rawData = {
      firstname: data.firstname,
      password: data?.password,
      lastname: data.lastname,
      phone: data?.phone,
      email: data.email,
      identifier: data?.email,
      gender: data?.gender,
      dateofbirth: data?.dob,

      // social detail
      isLogin: data.isLogin || false,
      socialtype: data.type,
      device_id: data.device_id,
      device_name: data.deviceName,
      imageUrl: data?.photo,
      socialid: data.id,
    };
    try {
      dispatch(_commonDispatcher(FETCH_TOKEN, ''));
      const responseData = await call({
        baseUrl: `/auth/social-link`,
        method: 'POST',
        body: JSON.stringify(rawData),
      });

      if (responseData?.token) {
        showToast(responseData.message);
        const decoded = getDecodedDetail(responseData?.token);
        dispatch(_initiateApi(false, decoded?.id));
        dispatch(_commonDispatcher(FETCH_TOKEN, responseData?.token));
        dispatch(_commonDispatcher(FETCH_USER_DETAIL, decoded));
      } else {
        rawData.message = responseData.message;
        navigate('Otp', {data: rawData});
      }
      return 1;
    } catch (error) {
      console.log('error ===>', error.message);
      // showToast(error.message)
      dispatch(_commonDispatcher(FETCH_TOKEN, ''));
      throw new Error(error.message);
    }
  };
};

const handleSuccess = async (responseData, dispatch) => {
  const decoded = getDecodedDetail(responseData?.token);
  dispatch(_initiateApi(false, decoded?.id));
  dispatch(_commonDispatcher(FETCH_TOKEN, responseData?.token));
  dispatch(_commonDispatcher(FETCH_USER_DETAIL, decoded));
};

export const _register = ({
  email,
  username,
  phone,
  firstname,
  lastname,
  password,
  deviceId,
  deviceName,
  gender,
  dateOfBirth,
}) => {
  return async dispatch => {
    const rawData = {
      firstname: firstname,
      username: username,
      lastname: lastname,
      password: password,
      email: email,
      phone: phone,
      gender: gender,
      dateofbirth: dateOfBirth,

      // detail for otp
      device_name: deviceName,
      remember_device: true,
      device_id: deviceId,
      login_type: 'email',
      identifier: email,
      intrestShow: true,
    };

    try {
      dispatch(_commonDispatcher(FETCH_TOKEN, ''));
      const responseData = await call({
        baseUrl: `/auth/signup`,
        method: 'POST',
        body: JSON.stringify(rawData),
      });
      if (responseData?.token) {
        navigate('Success', {
          method: async () => await handleSuccess(responseData, dispatch),
          title: 'Verification Complete',
          subTitle: 'Your account has been verified.',
          intrestShow: true,
        });
        // goBack()
      } else {
        rawData.message = responseData.message;
        navigate('Otp', {data: rawData});
      }

      return 1;
    } catch (error) {
      showToast(error.message);
      dispatch(_commonDispatcher(FETCH_TOKEN, ''));
      return 0;
    }
  };
};

export const _otpVerify = ({data}) => {
  return async dispatch => {
    // dispatch(_globalLoader(true));
    const deviceId = await DeviceInfo.getUniqueId();
    const deviceName = await DeviceInfo.getManufacturer();
    // try {
    // } catch (error) {
    // }
    const rawData = {
      identifier: data.identifier,
      device_id: data?.device_id || deviceId || '',
      device_name: data?.device_name || deviceName || '',
      remember_device: true,
      otp: data.otp || '',
      isLogin: data.isLogin,
    };

    const rawDataForReset = {
      identifier: data.identifier,
      otp: data.otp || '',
    };
    try {
      dispatch(_commonDispatcher(FETCH_TOKEN, ''));
      const responseData = await call({
        baseUrl: `/auth/verify-otp`,
        method: 'POST',
        body: JSON.stringify(data?.forgotPassword ? rawDataForReset : rawData),
      });
      if (data?.forgotPassword) {
        navigate('ResetPassword', {data: rawData});
      } else {
        // dispatch(_commonDispatcher(FETCH_TOKEN, responseData?.token));
        // const decoded = getDecodedDetail(responseData?.token);
        // dispatch(_commonDispatcher(FETCH_USER_DETAIL, decoded));

        navigate('Success', {
          method: async () => await handleSuccess(responseData, dispatch),
          title: 'Verification Complete',
          subTitle: 'Your account has been verified.',
          intrestShow: Boolean(rawData?.isLogin) == false ? true : false,
        });
      }
      console.log('responseData of thr raw data', rawData);

      dispatch(_globalLoader(false));
      return 1;
    } catch (error) {
      showToast(error.message);
      dispatch(_commonDispatcher(FETCH_TOKEN, ''));
      dispatch(_globalLoader(false));
      return 0;
    }
  };
};

export const _sendOtp = ({params, identifier, sendAgain}) => {
  return async dispatch => {
    const rawData = {
      identifier: identifier,
    };
    try {
      const responseData = await call({
        baseUrl: `/auth/send-otp`,
        method: 'POST',
        body: JSON.stringify(rawData),
      });
      showToast(
        sendAgain ? 'We have sent you otp again.' : responseData.message,
      );
      rawData.message = responseData.message;
      if (!params?.socialtype) {
        rawData.forgotPassword = true;
      }
      navigate('Otp', {data: params});
      return 1;
    } catch (error) {
      showToast(error.message);
      return 0;
    }
  };
};

export const _resetPassword = ({identifier, password}) => {
  return async dispatch => {
    const rawData = {
      identifier,
      password,
    };
    try {
      const responseData = await call({
        baseUrl: `/auth/reset-password`,
        method: 'POST',
        body: JSON.stringify(rawData),
      });
      showToast(responseData.message);
      return 1;
    } catch (error) {
      showToast(error.message);
      return 0;
    }
  };
};

export const _userVerifier = ({data}) => {
  return async dispatch => {
    // dispatch(_globalLoader(true));
    const rawData = {
      identifier: data.email,
    };
    try {
      const responseData = await call({
        baseUrl: `/auth/user-verifier`,
        method: 'POST',
        body: JSON.stringify(rawData),
      });
      dispatch(_globalLoader(false));
      return 1;
    } catch (error) {
      showToast(error.message);
      dispatch(_globalLoader(false));
      return 0;
    }
  };
};

export const _storeNotificationToken = (user_id, deviceId) => {
  return async dispatch => {
    const {notificationToken} = getStoreState('common');

    const rawData = {
      user_id: user_id,
      device_id: deviceId,
      notification_token: notificationToken,
    };


    try {
      const responseData = await call({
        baseUrl: `/auth/store-notification-token`,
        method: 'POST',
        body: JSON.stringify(rawData),
      });
      console.log('store-notification-token', responseData);
      return 1;
    } catch (error) {
      console.log('store-notification-token', error.message);
      return 0;
    }
  };
};
