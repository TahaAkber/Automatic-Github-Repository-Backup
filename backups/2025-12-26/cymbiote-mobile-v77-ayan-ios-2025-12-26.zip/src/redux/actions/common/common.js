import {useRef} from 'react';
import {
  call,
  filterObject,
  showToast,
} from '../../../helper/reUsableMethod/reUsableMethod';
import {getDeviceId, getStoreState} from '../../../utils/helper/helper';
import {navigate} from '../../../utils/navigationRef/navigationRef';
import {FETCH_TOKEN, FETCH_USER_DETAIL} from '../../types/auth/auth';
import {CHAT_AI_RESET} from '../../types/chatai/chatai';
import {
  CART_BOTTOM_SHEET,
  FOCUS_HOME_TAB,
  GET_INTRO_SLIDER,
  IS_LOADING_AUTH,
  RESET_VIDEO_INDEXES,
  SET_VIDEO_INDEXES,
  TRIGGER_CART_BOUNCE,
  SET_HOME_SCROLL_POSITION,
  FETCH_APP_UPDATE_CONFIG,
  SET_APP_UPDATE_STATUS,
} from '../../types/common/common';
import {
  FETCH_STORE_FOLLOWING_LIST,
  FETCH_STORE_FOLLOWING_LIST_LOCAL,
} from '../../types/merchant/merchant';
import {
  FETCH_MAINTENANCE_STATUS,
  FETCH_SEARCH_FILTERS,
  FETCH_SHOP_CATEGORIES,
  FETCH_TAXONOMIES,
  RECENT_SEARCHES,
  SELECTED_CATEGORIES,
} from '../../types/user/user';
import {_storeNotificationToken} from '../auth/auth';
import {
  _getCardItems,
  _getCardItemsAfterLogin,
  assignGuestCartToUser,
  resetCart,
} from '../cart/cart';
import {
  _appendToFollowingList,
  _getFollowingStore,
  _getStores,
} from '../merchant/merchant';
import {_getInternalOrder} from '../orders/orders';
import {_getPointsHistory, _getVouchers} from '../reward/reward';
import {
  _appendToFavoriteList,
  _getAddress,
  _getFavorite,
  _getUserNotificationStatuses,
} from '../user/user';
import {
  FETCH_ACTIVE_ORDER,
  FETCH_INTERNAL_ORDER,
} from '../../types/orders/orders';
import {isAndroid} from '../../../constant/contstant';
import DeviceInfo from 'react-native-device-info';
import {currentEnvironmentType} from '@utils/url/url';
import AsyncStorage from '@react-native-async-storage/async-storage';

export const _commonDispatcher = (type, payload) => {
  return async dispatch => {
    dispatch({
      type: type,
      payload: payload,
    });
  };
};
export const _initiateApi = (
  setLoader,
  user_id,
  remove_intro_slider_method,
) => {
  return async dispatch => {
    try {
      const {fetch_user_detail} = getStoreState('auth');
      const {fetch_favorite_list_local} = getStoreState('user');
      const deviceId = await getDeviceId();
      const {cart} = getStoreState('cart');
      const {fetch_store_following_list_local} = getStoreState('merchant');
      await dispatch(_getShopCategories());
      await dispatch(_appendToUserIntrest(user_id || fetch_user_detail?.id));
      await dispatch(_fetchUserIntrestList(user_id || fetch_user_detail?.id));
      const {selected_categories} = getStoreState('user');
      await dispatch(
        _getStores({
          page: 1,
          user_id: fetch_user_detail?.id,
          categories: selected_categories.toString(),
          loader: user_id ? true : false,
        }),
      );
      await Promise.all([
        dispatch(_getMaintenanceStatus()),
        dispatch(_getAddress(user_id || fetch_user_detail?.id)),
        dispatch(_getCardItems(cart)),
        dispatch(_getFollowingStore(true, fetch_store_following_list_local)),
        dispatch(_getFavorite(true, fetch_favorite_list_local)),
        dispatch(_getPointsHistory({page: 1, tab: 0})),
        dispatch(_getVouchers({page: 1})),
        dispatch(_appendToFollowingList(user_id || fetch_user_detail?.id)),
        dispatch(_appendToFavoriteList(user_id || fetch_user_detail?.id)),
        dispatch(
          _getUserNotificationStatuses(user_id || fetch_user_detail?.id),
        ),
        dispatch(assignGuestCartToUser(user_id || fetch_user_detail?.id)),
        dispatch(_getCardItemsAfterLogin(user_id || fetch_user_detail?.id)),
        dispatch(
          _storeNotificationToken(user_id || fetch_user_detail?.id, deviceId),
        ),
      ]);

      !remove_intro_slider_method && dispatch(_introSliderSkip(true));
    } catch (error) {
      console.log('Error while fetching data:', error?.message);
    } finally {
      setLoader && setLoader(false); // Ensure the loader is stopped even if an error occurs
    }
  };
};

export const _clearState = () => {
  return async dispatch => {
    dispatch({type: IS_LOADING_AUTH, payload: false});
    dispatch({type: CART_BOTTOM_SHEET, payload: false});
    dispatch({type: FETCH_SEARCH_FILTERS, payload: {}});
    dispatch({type: CHAT_AI_RESET});
    dispatch(_resetVideoIndexes());
  };
};

export const _cartBottomSheet = payload => {
  return async dispatch => {
    dispatch({type: CART_BOTTOM_SHEET, payload: payload});
  };
};
export const triggerCartBounce = payload => {
  return async dispatch => {
    dispatch({type: TRIGGER_CART_BOUNCE, payload: payload});
  };
};

export const _focusHomeTab = payload => {
  return async dispatch => {
    dispatch({type: FOCUS_HOME_TAB, payload: payload});
  };
};

export const _introSliderSkip = payload => {
  return async dispatch => {
    dispatch({
      type: GET_INTRO_SLIDER,
      payload: payload,
    });
  };
};

export const _globalLoader = payload => {
  return async dispatch => {
    dispatch({
      type: IS_LOADING_AUTH,
      payload: payload,
    });
  };
};

export const _logout = () => {
  return async dispatch => {
    dispatch(_globalLoader(true));
    const deviceId = await getDeviceId();
    const rawData = {
      device_id: deviceId,
    };
    console.log('rawData', rawData);
    const responseData = await call({
      baseUrl: `/auth/logout`,
      method: 'POST',
      body: JSON.stringify(rawData),
    });
    dispatch(_clearUserStates());
    dispatch(resetCart());
    dispatch(_getCardItems());
    dispatch(_globalLoader(false));
    dispatch({
      type: FETCH_STORE_FOLLOWING_LIST_LOCAL,
      payload: [],
    });
    dispatch({
      type: FETCH_STORE_FOLLOWING_LIST,
      payload: [],
    });
  };
};

export const _searchMethod = async (
  text,
  setText,
  setTextLoader,
  setLocalData,
  debounceRef,
  latestSearchId,
  controllerRef,
  saveKeyword,
  ai_url = false,
  url,
  method,
  body = null,
  removeSearchTerm = false,
) => {
  const trimmedText = ai_url ? text : text.trim();
  setText(trimmedText);

  if (debounceRef.current) clearTimeout(debounceRef.current);

  if (!trimmedText) {
    setLocalData([]);
    setTextLoader(false);
    return;
  }

  setTextLoader(true);

  debounceRef.current = setTimeout(async () => {
    if (controllerRef.current) {
      controllerRef.current.abort();
    }

    controllerRef.current = new AbortController();
    const currentSearchId = ++latestSearchId.current;

    try {
      const responseData = await call({
        baseUrl: `/shops/search?search_term=${encodeURIComponent(trimmedText)}`,
        method: method || 'GET',
        signal: controllerRef.current.signal,
        ai_url: ai_url,
        other_url: `${url}${
          !removeSearchTerm ? encodeURIComponent(trimmedText) : ''
        }`,
        body: body,
      });

      // ✅ Accept only if latest
      if (currentSearchId === latestSearchId.current) {
        setLocalData(
          saveKeyword ? responseData[saveKeyword] || [] : responseData,
        );
        setTextLoader(false);
      } else {
        setLocalData(
          saveKeyword
            ? responseData[saveKeyword] || responseData || {}
            : responseData,
        );
        setTextLoader(false);
      }
    } catch (error) {
      if (error.message === 'AbortError') {
        setTextLoader(false);
      } else {
        if (currentSearchId === latestSearchId.current) {
          setTextLoader(false);
          setLocalData([]);
        }
      }
    }
    // finally {
    //   if (currentSearchId === latestSearchId.current) {
    //     setTextLoader(false);
    //   } else {
    //     setTextLoader(false);
    //   }
    // }
  }, 300);
};

export const _searchMethodFollowing = (
  text,
  setText,
  setTextLoader,
  setLocalData,
  debounceRef,
  latestSearchId,
  controllerRef,
  // The following parameters are not used directly in the search method but are kept
  // in the signature for consistency with the calling component
  saveKeyword,
  ai_url,
  url,
  method,
  body,
) => {
  // Clear any previous debounce timer
  if (debounceRef.current) clearTimeout(debounceRef.current);

  const trimmedText = text.trim();

  // Set the search text immediately for UI feedback
  setText(trimmedText);

  // If the search text is empty, clear the local data and stop
  if (!trimmedText) {
    setLocalData([]);
    setTextLoader(false);
    return;
  }

  // Set the loader to true to show loading state
  setTextLoader(true);

  // Start a new debounce timer
  debounceRef.current = setTimeout(async () => {
    // Abort the previous request if it's still in progress
    if (controllerRef.current) {
      controllerRef.current.abort();
    }

    // Create a new AbortController for this request
    controllerRef.current = new AbortController();
    const currentSearchId = ++latestSearchId.current;

    try {
      // Correctly pass the body for a POST request.
      // The URL for a POST request should not contain the search query.
      const responseData = await call({
        url: url, // e.g., '/following/user-following-log'
        method: method, // e.g., 'POST'
        body: {...body, search: trimmedText}, // Use the search text from the trimmedText variable
        signal: controllerRef.current.signal,
      });

      // Only update state if this is the most recent request
      if (currentSearchId === latestSearchId.current) {
        // Set the localData state to the full response object, not just the data array
        setLocalData(responseData || {});
      }
    } catch (error) {
      // Only update state for the latest request to avoid race conditions
      if (currentSearchId === latestSearchId.current) {
        // Handle a search that yields no results or an error
        setLocalData({});
        console.error('Search API Error:', error);
      }
    } finally {
      // Turn off the loader only for the latest request
      if (currentSearchId === latestSearchId.current) {
        setTextLoader(false);
      }
    }
  }, 300); // 300ms debounce delay
};

// Assuming this is your _searchProductMethod. If it's the same as _searchMethod,
// just make sure it's updated as below.
export const _searchProductMethod = (
  text,
  setText,
  setTextLoader,
  setLocalData,
  debounceRef,
  latestSearchId,
  controllerRef,
  saveKeyword,
  ai_url = false,
  url,
  method = 'GET', // Add method parameter
  body = {}, // Add body parameter
) => {
  const trimmedText = ai_url ? text : text.trim();
  setText(trimmedText);

  if (debounceRef.current) clearTimeout(debounceRef.current);

  if (!trimmedText) {
    setLocalData([]);
    setTextLoader(false);
    return;
  }

  setTextLoader(true);

  debounceRef.current = setTimeout(async () => {
    if (controllerRef.current) {
      controllerRef.current.abort();
    }

    controllerRef.current = new AbortController();
    const currentSearchId = ++latestSearchId.current;

    try {
      let requestBody = {};
      let requestUrl = '';
      let requestMethod = method;

      if (method === 'POST') {
        // The URL needs to include the searchKeyword.
        // The body will contain the shop_id (and potentially other fixed parameters).
        requestBody = {...body, searchKeyword: trimmedText}; // Add searchKeyword to body if the backend expects it there
        requestUrl = `${url}${encodeURIComponent(trimmedText)}`; // Append searchKeyword to the URL if it's a query parameter for POST
      } else {
        // For GET
        requestUrl = `${url}${encodeURIComponent(trimmedText)}`;
      }

      const responseData = await call({
        baseUrl: requestUrl,
        method: requestMethod,
        signal: controllerRef.current.signal,
        body: requestMethod === 'POST' ? requestBody : undefined,
      });

      if (currentSearchId === latestSearchId.current) {
        setLocalData(responseData[saveKeyword] || []);
        setTextLoader(false);
      } else {
        setLocalData(responseData[saveKeyword] || responseData || {});
        setTextLoader(false);
      }
    } catch (error) {
      if (error.message === 'AbortError') {
        setTextLoader(false);
      } else {
        if (currentSearchId === latestSearchId.current) {
          setTextLoader(false);
          setLocalData([]);
        }
      }
    }
  }, 300);
};

// And ensure your 'call' function (which is used inside _searchProductMethod)
// can handle POST requests with a body.
/*
const call = async ({ baseUrl, method = 'GET', signal, body }) => {
  const options = {
    method,
    signal,
    headers: {
      'Content-Type': 'application/json',
      // ... other headers
    },
  };

  if (body && Object.keys(body).length > 0) {
    options.body = JSON.stringify(body);
  }

  const response = await fetch(baseUrl, options);

  if (!response.ok) {
    throw new Error(`API error: ${response.statusText}`);
  }

  return response.json();
};
*/

export const _uploadImage = ({local_image}) => {
  return async dispatch => {
    try {
      const formData = new FormData();
      formData.append('file', {
        uri: local_image?.uri,
        type: local_image?.mime || 'image/jpeg',
        name: 'upload.jpg',
      });

      const responseData = await call({
        baseUrl: `/upload`,
        method: 'POST',
        body: formData,
        headers: 'multipart/form-data',
      });

      return responseData?.url;
    } catch (error) {
      console.log('error uploading image', error?.message);
      return 0;
    }
  };
};

export const _getShopCategories = () => {
  return async dispatch => {
    try {
      const responseData = await call({
        baseUrl: `/shops/shop-categories`,
        method: 'POST',
      });

      console.log('responseData?.data', responseData?.data);

      dispatch({type: FETCH_SHOP_CATEGORIES, payload: responseData?.data});
      return responseData?.data || [];
    } catch (error) {
      dispatch({type: FETCH_SHOP_CATEGORIES, payload: []});
      return 0;
    }
  };
};

export const _appendToUserIntrest = user_id => {
  return async dispatch => {
    if (!user_id) {
      return;
    }
    try {
      const {selected_categories} = getStoreState('user');
      const rawData = {
        user_intrest: selected_categories.map(item => {
          return {
            user_intrest_category_id: item,
            user_intrest_user_id: user_id,
          };
        }),
      };

      const responseData = await call({
        baseUrl: `/user/create-user-intrest`,
        method: 'POST',
        body: JSON.stringify(rawData),
      });

      return 1;
    } catch (error) {
      showToast(error?.message);
      return 0;
    }
  };
};

export const _fetchUserIntrestList = user_id => {
  return async dispatch => {
    try {
      const rawData = {
        user_id,
      };
      const responseData = await call({
        baseUrl: `/user/user-intrest`,
        method: 'POST',
        body: JSON.stringify(rawData),
      });

      if (responseData?.data?.length) {
        dispatch(_commonDispatcher(SELECTED_CATEGORIES, responseData?.data));
      }
      return 1;
    } catch (error) {
      return 0;
    }
  };
};

export const _fetchSearchList = user_id => {
  return async dispatch => {
    try {
      const rawData = {
        user_id,
      };
      const responseData = await call({
        baseUrl: `/user/user-intrest`,
        method: 'POST',
        body: JSON.stringify(rawData),
      });

      if (responseData?.data?.length) {
        dispatch(_commonDispatcher(SELECTED_CATEGORIES, responseData?.data));
      }
      return 1;
    } catch (error) {
      return 0;
    }
  };
};

export const _fetchCategoryProducts = category_id => {
  return async dispatch => {
    try {
      const {selected_categories} = getStoreState('user');
      const {fetch_user_detail} = getStoreState('auth');

      const rawData = {
        category_id: category_id || selected_categories?.toString(),
        user_id: fetch_user_detail?.id,
      };

      console.log(JSON.stringify(rawData));

      const responseData = await call({
        baseUrl: `/shops/category-related-product`,
        method: 'POST',
        body: JSON.stringify(rawData),
      });

      return responseData?.data || [];
    } catch (error) {
      return 0;
    }
  };
};

export const _fetchSubCategories = category_id => {
  return async dispatch => {
    try {
      const rawData = {
        store_category_id: category_id,
      };
      const responseData = await call({
        baseUrl: `/shops/shop-sub-categories`,
        method: 'POST',
        body: JSON.stringify(rawData),
      });

      return responseData?.data || [];
    } catch (error) {
      return 0;
    }
  };
};

export const _recentSearchRecord = ({searchTerm, image, navigation}) => {
  return async dispatch => {
    try {
      const {fetch_user_detail} = getStoreState('auth');
      const {recentSearches} = getStoreState('common');

      let updatedSearches = [...recentSearches];

      const index = updatedSearches.indexOf(searchTerm);
      if (index > -1) {
        updatedSearches.splice(index, 1);
      }
      updatedSearches = [searchTerm, ...updatedSearches];
      searchTerm && dispatch({type: RECENT_SEARCHES, payload: updatedSearches});
      navigation.push('SearchedItems', {searchTerm, image});

      return 1;
    } catch (error) {
      console.error(error);
      return 0;
    }
  };
};

export const _recentSearchRemove = ({searchTerm}) => {
  return async dispatch => {
    try {
      const {fetch_user_detail} = getStoreState('auth');
      const {recentSearches} = getStoreState('common');

      const copyArr = recentSearches?.filter(
        (item, index) => item != searchTerm,
      );

      const rawData = {
        user_id: fetch_user_detail?.id,
        searchTerm,
      };

      dispatch({type: RECENT_SEARCHES, payload: copyArr});

      // const responseData = await call({
      //     baseUrl: `/api/user/user-intrest`,
      //     method: 'POST',
      //     body: JSON.stringify(rawData)
      // });

      // if (responseData?.data?.length) {
      //     dispatch(_commonDispatcher(SELECTED_CATEGORIES, responseData?.data));
      // }
      return 1;
    } catch (error) {
      return 0;
    }
  };
};

export const _fetchSearchedList = (
  searchTerm,
  fullResponse,
  page = 1,
  filter = true,
  brand,
  shop_id = '',
  excludeShopId,
  main_search = true,
) => {
  return async dispatch => {
    const {fetch_user_detail} = getStoreState('auth');
    const maxPrice = filter
      ? filterObject('main_search', 'price', 'main_search')
      : '';
    const sortByPrice = filter
      ? filterObject('main_search', 'sort_by', 'main_search')
      : '';
    const rating = filter
      ? filterObject('main_search', 'ratings', 'main_search')
      : '';
    const size = filter
      ? filterObject('main_search', 'size', 'main_search')
      : '';
    const color = filter
      ? filterObject('main_search', 'colors', 'main_search')
      : '';

    console.log(maxPrice);
    try {
      const responseData = await call({
        method: 'GET',
        ai_url: true,
        other_url: `/rag_search?query=${searchTerm}&page=${
          page || 1
        }&limit=10&min_price=${
          Array.isArray(maxPrice) ? maxPrice?.[0] : 0
        }&max_price=${
          Array.isArray(maxPrice) ? maxPrice?.[1] : '1000000000000000'
        }&sort_price=${
          sortByPrice == 2 ? 'asc' : sortByPrice == 3 ? 'desc' : ''
        }&min_rating=${rating || '1'}&sort_rating=&size=${
          size || ''
        }&sort_size=&sort_date=${
          sortByPrice == 4 ? 'asc' : sortByPrice == 5 ? 'desc' : ''
        }&color=${color || ''}&brand=${isNaN(brand) ? brand || '' : ''}${
          excludeShopId
            ? '&exclude_shop_id=' + shop_id
            : shop_id
            ? `&shop_id=${shop_id}`
            : ''
        }&on_search=${main_search || false}&user_id=${
          fetch_user_detail?.id || ''
        }`,
      });

      return fullResponse ? responseData : responseData?.data?.products || [];
    } catch (error) {
      console.log('errror =>', error?.message);
      return 0;
    }
  };
};

export const _fetchSearchedListWithImage = (
  image = {},
  page,
  filter = true,
) => {
  return async dispatch => {
    try {
      const maxPrice = filter
        ? filterObject('main_search', 'price', 'main_search')
        : '';
      const sortByPrice = filter
        ? filterObject('main_search', 'sort_by', 'main_search')
        : '';
      const rating = filter
        ? filterObject('main_search', 'ratings', 'main_search')
        : '';

      const formData = new FormData();
      formData.append('file', {
        uri: image?.uri,
        type: image?.mime || 'image/jpeg',
        name: image?.uri,
      });

      const responseData = await call({
        // baseUrl: `/image-search`,
        baseUrl: `/image-search?page=${page || 1}&min_price=${
          Array.isArray(maxPrice) ? maxPrice?.[0] : 0
        }&max_price=${
          Array.isArray(maxPrice) ? maxPrice?.[1] : '1000000000000000'
        }&sort_price=${
          sortByPrice == 2 ? 'asc' : sortByPrice == 3 ? 'desc' : ''
        }&min_rating=${rating || '1'}&sort_date=${
          sortByPrice == 4 ? 'asc' : sortByPrice == 5 ? 'desc' : ''
        }`,
        method: 'POST',
        ai_url: true,
        body: formData,
        headers: 'multipart/form-data',
      });

      console.log('image search API', responseData);

      return responseData || {};
    } catch (error) {
      console.log('error =>', error.message);
      return 0;
    }
  };
};

export const _getTaxonomies = (searchTerm = '') => {
  return async dispatch => {
    try {
      const responseData = await call({
        baseUrl: `/shops/taxonomies-categories?id=${searchTerm}`,
        method: 'GET',
      });

      dispatch({type: FETCH_TAXONOMIES, payload: responseData?.taxonomies});
      return responseData?.taxonomies || [];
    } catch (error) {
      dispatch({type: FETCH_TAXONOMIES, payload: []});
      console.log('error', error);
      return 0;
    }
  };
};

export const _searchFilters = (key, value, screen) => {
  return async dispatch => {
    try {
      const {screenFilters} = getStoreState('common');

      const data = {
        ...screenFilters,
        [screen]: {
          ...screenFilters[screen],
          [key]: value,
        },
      };

      dispatch({type: FETCH_SEARCH_FILTERS, payload: data});

      return 1;
    } catch (error) {
      return 0;
    }
  };
};

export const _setVideoIndexes = ({index, activeIndex}) => ({
  type: SET_VIDEO_INDEXES,
  payload: {index, activeIndex},
});

export const _resetVideoIndexes = () => ({
  type: RESET_VIDEO_INDEXES,
});

// export const _setHomeScrollPosition = payload => {
//   console.log("homeScrollPosition =>", payload)
//   return async dispatch => {
//     dispatch({
//       type: SET_HOME_SCROLL_POSITION,
//       payload: payload,
//     });
//   };
// };

export const _setHomeScrollPosition = payload => {
  return async dispatch => {
    try {
      dispatch({
        type: SET_HOME_SCROLL_POSITION,
        payload: payload,
      });
    } catch (error) {
      console.log('error', error.message);
      return 0;
    }
  };
};

export const _checkAppUpdate = () => {
  return async dispatch => {
    try {
      const response = await call({
        baseUrl: `/app-update/config`,
        method: 'GET',
      });

      const responseData = response?.data || {};
      dispatch({type: FETCH_APP_UPDATE_CONFIG, payload: responseData});

      const currentVersion = DeviceInfo.getVersion();
      const updatedAt = responseData?.updated_at || '';

      const lastSeen = await AsyncStorage.getItem('@app_update_seen_at');
      if (lastSeen && updatedAt && lastSeen === updatedAt) {
        const status = {
          needsUpdate: false,
          canSkip: true,
          storeUrl: '',
          updatedAt,
          latestVersion: '',
        };
        dispatch({type: SET_APP_UPDATE_STATUS, payload: status});
        return status;
      }

      const platformKey = isAndroid ? 'android' : 'ios';
      const envKey = currentEnvironmentType?.includes('production')
        ? 'prod'
        : currentEnvironmentType?.includes('staging')
        ? 'stage'
        : 'dev';

      const pickVersion = () => {
        const internalKey = `internal_${platformKey}_${envKey}_version`;
        const publicKey = `${platformKey}_${envKey}_version`;
        return responseData?.[internalKey] ?? responseData?.[publicKey] ?? '';
      };

      const pickUrl = () => {
        const internalKey = `internal_${platformKey}_${envKey}_url`;
        const publicKey = `${platformKey}_${envKey}_url`;
        return responseData?.[internalKey] ?? responseData?.[publicKey] ?? '';
      };

      const targetVersion = pickVersion();
      const targetUrl = pickUrl();

      const status = {
        needsUpdate:
          !!(targetVersion && currentVersion != targetVersion) ||
          !!responseData?.update_required,
        canSkip: !responseData?.update_required,
        storeUrl: targetUrl,
        updatedAt,
        latestVersion: targetVersion || '',
      };

      dispatch({type: SET_APP_UPDATE_STATUS, payload: status});
      return status;
    } catch (error) {
      console.log('update check error', error?.message);
      dispatch({type: FETCH_APP_UPDATE_CONFIG, payload: {}});
      const status = {
        needsUpdate: false,
        canSkip: true,
        storeUrl: '',
        updatedAt: '',
        latestVersion: '',
      };
      dispatch({type: SET_APP_UPDATE_STATUS, payload: status});
      return status;
    }
  };
};

export const _skipAppUpdate = updatedAt => {
  return async dispatch => {
    try {
      if (updatedAt) {
        await AsyncStorage.setItem('@app_update_seen_at', updatedAt);
      }
    } catch (err) {
      console.log('skip store error', err?.message);
    } finally {
      const status = {
        needsUpdate: false,
        canSkip: true,
        storeUrl: '',
        updatedAt: updatedAt || '',
        latestVersion: '',
      };
      dispatch({type: SET_APP_UPDATE_STATUS, payload: status});
    }
  };
};

export const _clearUserStates = payload => {
  return async dispatch => {
    dispatch({
      type: FETCH_TOKEN,
      payload: '',
    });
    dispatch({
      type: FETCH_USER_DETAIL,
      payload: {},
    });
    dispatch({
      type: FETCH_INTERNAL_ORDER,
      payload: {},
    });
    dispatch({
      type: FETCH_ACTIVE_ORDER,
      payload: [],
    });
  };
};

export const _getMaintenanceStatus = () => {
  return async dispatch => {
    try {
      const responseData = await call({
        baseUrl: `/app-update/config`,
        method: 'GET',
      });

      console.log('responseData', responseData);

      dispatch({type: FETCH_MAINTENANCE_STATUS, payload: responseData?.data});
      return 1;
    } catch (error) {
      dispatch({type: FETCH_MAINTENANCE_STATUS, payload: {}});
      console.log('error', error);
      return 0;
    }
  };
};
