// import { _commonDispatcher } from "../common/common";
// import { call } from "@helper/reUsableMethod/reUsableMethod";
// import { CANCEL_ORDER, CANCEL_ORDER_LOADER, CANCEL_ORDER_ERROR } from "../../types/orders/orders";

// export const _cancelOrder = (shop_id, shopify_order_id, reason, staff_note = "Cancelled by user") => {
//     return async (dispatch, getState) => {
//         dispatch({ type: CANCEL_ORDER_LOADER, payload: true });

//         try {
//             console.log("Cancelling Order:", { shop_id, shopify_order_id, reason });

//             const responseData = await call({
//                 baseUrl: "/api/order/order-cancellation",
//                 method: "POST",
//                 body: { shop_id, shopify_order_id, reason, staff_note }
//             });

//             console.log("Raw API Response:", responseData);

//             if (responseData?.status === 200) {
//                 console.log("Order cancelled successfully!");

//                 dispatch({
//                     type: CANCEL_ORDER,
//                     payload: { shopify_order_id }
//                 });

//                 return responseData;
//             } else {
//                 throw new Error(responseData?.message || "Unknown API error");
//             }

//         } catch (error) {
//             console.error("Order Cancellation API Error:", error?.message);
//             dispatch({ type: CANCEL_ORDER_ERROR, payload: error?.message });
//             return null;
//         } finally {
//             dispatch({ type: CANCEL_ORDER_LOADER, payload: false });
//         }
//     };
// };

// import { _commonDispatcher } from "../common/common";
// import { call } from "@helper/reUsableMethod/reUsableMethod";
// import { CANCEL_ORDER, CANCEL_ORDER_LOADER, CANCEL_ORDER_ERROR } from "../../types/orders/orders";

// export const _cancelOrder = (shop_id, shopify_order_id, reason, staff_note = "Cancelled by user") => {
//     return async (dispatch, getState) => {
//         dispatch({ type: CANCEL_ORDER_LOADER, payload: true });

//         try {
//             console.log("🔄 Cancelling Order:", { shop_id, shopify_order_id, reason });

//             const responseData = await call({
//                 baseUrl: "/api/order/order-cancellation",
//                 method: "POST",
//                 body: { shop_id, shopify_order_id, reason, staff_note }
//             });

//             console.log("📡 API Response:", responseData);

//             if (responseData?.status === 200 && responseData?.success) {
//                 console.log("✅ Order cancelled successfully!");

//                 dispatch({
//                     type: CANCEL_ORDER,
//                     payload: { shopify_order_id }
//                 });

//                 return { success: true, message: "Order cancelled successfully!" };
//             } else {
//                 throw new Error(responseData?.message || "Unknown API error");
//             }
//         } catch (error) {
//             console.error("❌ Order Cancellation API Error:", error?.message);
//             dispatch({ type: CANCEL_ORDER_ERROR, payload: error?.message });
//             return { success: false, message: error?.message };
//         } finally {
//             dispatch({ type: CANCEL_ORDER_LOADER, payload: false });
//         }
//     };
// };

import {
  CANCEL_ORDER,
  CANCEL_ORDER_LOADER,
  CANCEL_ORDER_ERROR,
} from '../../types/orders/orders';
import {call} from '@helper/reUsableMethod/reUsableMethod';
import {_getInternalOrder} from './orders';
import {showToast} from '../../../helper/reUsableMethod/reUsableMethod';

export const _cancelOrder = (
  shop_id,
  shopify_order_id,
  reason = 'CUSTOMER',
  staff_note = '',
) => {
  return async dispatch => {
    // dispatch({ type: CANCEL_ORDER_LOADER, payload: true });
    const rawData = {shop_id, shopify_order_id, reason: reason, staff_note};
    console.log('JSON.stringify(rawData)', JSON.stringify(rawData));
    try {
      const rawData = {shop_id, shopify_order_id, reason: reason, staff_note};
      const responseData = await call({
        baseUrl: `/order/order-cancellation`,
        method: 'POST',
        body: JSON.stringify(rawData),
      });
      await dispatch(_getInternalOrder({page: 1}));
      showToast('Order Cancelled Successfully.');
      dispatch({type: CANCEL_ORDER_LOADER, payload: false});
      return 1;
    } catch (error) {
      showToast(error?.message);
      dispatch({type: CANCEL_ORDER_ERROR, payload: error.message});
      dispatch({type: CANCEL_ORDER_LOADER, payload: false});
      return 0;
    }
  };
};
