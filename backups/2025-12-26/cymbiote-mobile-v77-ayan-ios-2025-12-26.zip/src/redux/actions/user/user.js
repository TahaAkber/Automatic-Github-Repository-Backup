import {call, showToast} from '@helper/reUsableMethod/reUsableMethod';
import {goBack} from '@utils/navigationRef/navigationRef';
import {getStoreState} from '@utils/helper/helper';
import {
  FETCH_ADDRESS,
  FETCH_ADDRESS_ERROR,
  FETCH_ADDRESS_LOADER,
  FETCH_FAVORITE_LIST,
  FETCH_FAVORITE_LIST_ERROR,
  FETCH_FAVORITE_LIST_LOADER,
  FETCH_FAVORITE_LIST_LOCAL,
  FETCH_RECENTLY_VIEWED,
  FETCH_RECENTLY_VIEWED_ERROR,
  FETCH_RECENTLY_VIEWED_LOADER,
  FETCH_RECENTLY_VIEWED_LOCALLY,
  FETCH_USER_NOTIFICATION_STATUSES,
  FETCH_USER_NOTIFICATIONS,
  FETCH_USER_NOTIFICATIONS_ERROR,
} from '../../types/user/user';
import {_commonDispatcher, _logout} from '../common/common';
import {countries} from '../../../constant/dummyData';

export const _recentViewed = (user_id, type, shop_id, product_id) => {
  return async dispatch => {
    if (user_id) {
      try {
        const {fetch_recent_viewed_locally} = getStoreState('user');

        const rawData = {
          user_id: user_id || '',
          recent_view_type: type,
          recent_view_shop_id: shop_id,
          recent_view_product_id: product_id,
        };

        const responseData = await call({
          baseUrl: `/user/recent-viewed`,
          method: 'POST',
          body: JSON.stringify(rawData),
        });

        if (fetch_recent_viewed_locally.length && user_id) {
          let recentlyViewed = [...fetch_recent_viewed_locally];

          const removeLocalItem = recentlyViewed.map((item, i) => {
            return {...item, user_id: user_id};
          });
          dispatch(
            _commonDispatcher(FETCH_RECENTLY_VIEWED_LOCALLY, removeLocalItem),
          );
        }
        return 1;
      } catch (error) {
        console.log('error', error?.message);
        return 0;
      }
    } else {
      const {fetch_recent_viewed_locally} = getStoreState('user');

      let recentlyViewed = [...fetch_recent_viewed_locally];

      const rawData = {
        user_id,
        recent_view_type: type,
        recent_view_shop_id: shop_id,
        recent_view_product_id: product_id,
      };

      const index = recentlyViewed.findIndex(
        item =>
          item.recent_view_type === rawData.recent_view_type &&
          item.recent_view_shop_id === rawData.recent_view_shop_id &&
          item.recent_view_product_id === rawData.recent_view_product_id,
      );

      if (index !== -1) {
        const [existingItem] = recentlyViewed.splice(index, 1);

        recentlyViewed.unshift({
          ...existingItem,
          ...rawData,
        });
      } else {
        recentlyViewed.unshift(rawData);
      }
      dispatch(
        _commonDispatcher(FETCH_RECENTLY_VIEWED_LOCALLY, recentlyViewed),
      );
    }
  };
};

export const _getRecentViewedList = user_id => {
  return async dispatch => {
    try {
      const {fetch_recent_viewed_locally} = getStoreState('user');
      dispatch(_commonDispatcher(FETCH_RECENTLY_VIEWED_ERROR, ''));
      dispatch(_commonDispatcher(FETCH_RECENTLY_VIEWED_LOADER, true));
      const rawData = {
        user_id,
        local_recent_view: user_id ? '' : fetch_recent_viewed_locally,
      };
      const responseData = await call({
        baseUrl: `/user/recent-viewed-list`,
        method: 'POST',
        body: JSON.stringify(rawData),
      });
      dispatch(_commonDispatcher(FETCH_RECENTLY_VIEWED, responseData.data));
      dispatch(_commonDispatcher(FETCH_RECENTLY_VIEWED_LOADER, false));
      return responseData?.data.products;
    } catch (error) {
      console.log('error', error?.message);
      dispatch(_commonDispatcher(FETCH_RECENTLY_VIEWED, []));
      dispatch(_commonDispatcher(FETCH_RECENTLY_VIEWED_LOADER, false));
      dispatch(_commonDispatcher(FETCH_RECENTLY_VIEWED_ERROR, error.message));
      return 0;
    }
  };
};

export const _createAddress = (values, user_id, address_id) => {
  return async dispatch => {
    const countryIdByData = countries.find(item => item.id == values?.country);
    const address = await dispatch(_getAddress(user_id));
    try {
      const rawData = {
        address_user_id: user_id,
        address_id: address_id,
        address_first_name: values?.firstName,
        address_last_name: values?.lastName,
        address_country: countryIdByData?.value,
        address_one: values.address,
        address_two: values.apartment,
        address_city: values.city,
        address_postal_code: values.postalcode,
        address_number: values?.phone,
        address_default_select: address.length ? false : true,
      };
      const responseData = await call({
        baseUrl: `/user/${address_id ? 'update-address' : 'create-address'}`,
        method: 'POST',
        body: JSON.stringify(rawData),
      });
      await dispatch(_getAddress(user_id));
      showToast(responseData?.message);
      goBack();
      return 1;
    } catch (error) {
      showToast(error?.message);
      return 0;
    }
  };
};

export const _getAddress = user_id => {
  return async dispatch => {
    if (user_id) {
      try {
        dispatch(_commonDispatcher(FETCH_ADDRESS_ERROR, ''));
        dispatch(_commonDispatcher(FETCH_ADDRESS_LOADER, true));
        const rawData = {user_id};
        const responseData = await call({
          baseUrl: `/user/get-address`,
          method: 'POST',
          body: JSON.stringify(rawData),
        });
        dispatch(_commonDispatcher(FETCH_ADDRESS, responseData.data));
        dispatch(_commonDispatcher(FETCH_ADDRESS_LOADER, false));
        return responseData.data;
      } catch (error) {
        dispatch(_commonDispatcher(FETCH_ADDRESS, []));
        dispatch(_commonDispatcher(FETCH_ADDRESS_LOADER, false));
        dispatch(_commonDispatcher(FETCH_ADDRESS_ERROR, error.message));
        return 0;
      }
    }
  };
};

export const _setDefaultAddress = (user_id, address_id) => {
  return async dispatch => {
    try {
      const rawData = {user_id, address_id};
      await call({
        baseUrl: `/user/set-default-address`,
        method: 'POST',
        body: JSON.stringify(rawData),
      });
      return 1;
    } catch (error) {
      showToast(error?.message);
      return 0;
    }
  };
};

export const _getAddressDetail = address_id => {
  return async dispatch => {
    try {
      const rawData = {
        address_id: address_id,
      };
      const responseData = await call({
        baseUrl: `/user/get-address-detail`,
        method: 'POST',
        body: JSON.stringify(rawData),
      });
      return responseData?.data;
    } catch (error) {
      showToast(error?.message);
      return 0;
    }
  };
};

export const _deleteAddress = address_id => {
  return async dispatch => {
    try {
      const rawData = {
        address_id: address_id,
      };
      const responseData = await call({
        baseUrl: `/user/delete-address`,
        method: 'POST',
        body: JSON.stringify(rawData),
      });
      return responseData?.data;
    } catch (error) {
      showToast(error?.message);
      return 0;
    }
  };
};

export const _favoriteUpdateStatus = (
  product_id,
  is_added,
  item,
  date,
  user_id,
  not_loading,
) => {
  return async dispatch => {
    const {fetch_favorite_list_local} = getStoreState('user');
    try {
      const {fetch_user_detail} = getStoreState('auth');
      if (user_id || fetch_user_detail?.id) {
        const created_at = date || new Date().toISOString();
        const rawData = {
          user_id: user_id || fetch_user_detail?.id,
          product_id,
          is_added,
          created_at,
        };

        console.log('JSON.stringify(rawData)', JSON.stringify(rawData));

        const response = await call({
          baseUrl: `/wishlist/create-wishlist-log`,
          method: 'POST',
          body: JSON.stringify(rawData),
        });

        const updateLocalList = fetch_favorite_list_local.filter(
          el => el.wishlist_product_id != product_id,
        );

        dispatch(_commonDispatcher(FETCH_FAVORITE_LIST_LOCAL, updateLocalList));
        dispatch(_getFavorite(true, [], not_loading));
      } else {
        // Copying the list to avoid mutation of original state
        const updatedList = [...fetch_favorite_list_local];
        item.is_added = is_added;
        item.created_at = new Date().toISOString();

        const existingIndex = updatedList.findIndex(
          el => el.wishlist_product_id === item.wishlist_product_id,
        );
        if (existingIndex !== -1) {
          updatedList.splice(existingIndex, 1);
        } else {
          updatedList.push(item);
        }

        dispatch(_commonDispatcher(FETCH_FAVORITE_LIST_LOCAL, updatedList));
      }

      return 1;
    } catch (error) {
      console.log('error', error?.message);
      return 0;
    }
  };
};

export const _appendToFavoriteList = user_id => {
  return async dispatch => {
    try {
      const {fetch_favorite_list_local} = getStoreState('user');
      fetch_favorite_list_local.forEach(element => {
        dispatch(
          _favoriteUpdateStatus(
            element.wishlist_product_id,
            true,
            false,
            element.created_at,
            user_id,
          ),
        );
      });
      return 1;
    } catch (error) {
      console.log('error', error?.message);
      return 0;
    }
  };
};

export const _getFavorite = (product, favorite_local, not_loading) => {
  return async dispatch => {
    try {
      const {fetch_user_detail} = getStoreState('auth');
      !not_loading &&
        dispatch(_commonDispatcher(FETCH_FAVORITE_LIST_LOADER, true));

      const filterArr = favorite_local.filter(
        (item, index) => item?.wishlist_product_id,
      );

      const rawData = {
        user_id: fetch_user_detail?.id || false,
        wishlist_local: filterArr,
      };

      console.log('rawData', JSON.stringify(rawData));

      const responseData = await call({
        baseUrl: `/wishlist/user-wishlist-log`,
        method: 'POST',
        body: JSON.stringify(rawData),
      });
      const data = responseData.data;

      dispatch(_commonDispatcher(FETCH_FAVORITE_LIST, data));
      dispatch(_commonDispatcher(FETCH_FAVORITE_LIST_LOADER, false));
      dispatch(_commonDispatcher(FETCH_FAVORITE_LIST_ERROR, ''));
      return 1;
    } catch (error) {
      dispatch(_commonDispatcher(FETCH_FAVORITE_LIST_LOADER, false));
      dispatch(_commonDispatcher(FETCH_FAVORITE_LIST_ERROR, error.message));
      return 0;
    }
  };
};

export const _updateNotificationStatus = (
  notification_type,
  notification_toggle,
) => {
  return async dispatch => {
    try {
      const {fetch_user_detail} = getStoreState('auth');

      const rawData = {
        userId: fetch_user_detail?.id,
        notificationSettings: {
          [notification_type]: notification_toggle,
        },
      };

      const responseData = await call({
        baseUrl: `/notification/update-notification`,
        method: 'POST',
        body: JSON.stringify(rawData),
      });
      return 1;
    } catch (error) {
      return 0;
    }
  };
};

export const _getUserNotificationStatuses = user_id => {
  return async dispatch => {
    const {fetch_user_detail} = getStoreState('auth');
    if (user_id || fetch_user_detail?.id) {
      try {
        const responseData = await call({
          baseUrl: `/notification/user-notification?user_id=${
            user_id || fetch_user_detail?.id
          }`,
          method: 'GET',
        });
        dispatch(
          _commonDispatcher(
            FETCH_USER_NOTIFICATION_STATUSES,
            responseData?.data,
          ),
        );
        return 1;
      } catch (error) {
        dispatch(_commonDispatcher(FETCH_USER_NOTIFICATION_STATUSES, {}));
        return 0;
      }
    }
  };
};

export const _deleteUser = () => {
  return async dispatch => {
    const {fetch_user_detail} = getStoreState('auth');
    try {
      const rawData = {
        userId: fetch_user_detail?.id,
      };
      const responseData = await call({
        baseUrl: `/user/delete-user`,
        method: 'POST',
        body: JSON.stringify(rawData),
      });
      showToast(responseData?.message);
      dispatch(_logout());
      return 1;
    } catch (error) {
      showToast(error?.message);
      return 0;
    }
  };
};

export const _getUserNotifications = (page = 1, pull = false) => {
  return async dispatch => {
    const {fetch_user_detail} = getStoreState('auth');
    const {fetch_user_notifications} = getStoreState('user');
    try {
      const responseData = await call({
        baseUrl: `/notification/app-notifications?userId=${
          fetch_user_detail?.id
        }&page=${pull ? 1 : page}`,
        // baseUrl: `/notification/app-notifications?userId=${81}&page=${page}`,
        method: 'GET',
      });

      if (page != 1) {
        // Group by created_at (date)
        const groupedData = responseData.data.reduce((acc, notification) => {
          const createdDate = new Date(notification.created_at);
          const today = new Date();
          const yesterday = new Date(today);
          yesterday.setDate(today.getDate() - 1);

          const notificationDate = createdDate.toLocaleDateString();
          const todayDate = today.toLocaleDateString();
          const yesterdayDate = yesterday.toLocaleDateString();

          let displayDate = notificationDate;
          if (notificationDate === todayDate) {
            displayDate = 'Today';
          } else if (notificationDate === yesterdayDate) {
            displayDate = 'Yesterday';
          }

          let dateGroup = acc.find(group => group.date === displayDate);
          if (!dateGroup) {
            dateGroup = {date: displayDate, data: []};
            acc.push(dateGroup);
          }
          dateGroup.data.push(notification);
          return acc;
        }, []);

        // ✅ Merge old + new groups by date
        const mergedData = [...fetch_user_notifications?.data];

        groupedData.forEach(newGroup => {
          const existingGroup = mergedData.find(g => g.date === newGroup.date);
          if (existingGroup) {
            existingGroup.data.push(...newGroup.data);
          } else {
            mergedData.push(newGroup);
          }
        });

        const response = {
          ...responseData,
          data: mergedData,
          pagination: responseData?.pagination,
        };

        dispatch(_commonDispatcher(FETCH_USER_NOTIFICATIONS, response));
        dispatch(_commonDispatcher(FETCH_USER_NOTIFICATIONS_ERROR, ''));
        return 1;

        // Dispatch to the store
        // dispatch(_commonDispatcher(FETCH_USER_NOTIFICATIONS, response));
        // dispatch(_commonDispatcher(FETCH_USER_NOTIFICATIONS_ERROR, ''));
      } else {
        // Group by created_at (date)
        const groupedData = responseData.data.reduce((acc, notification) => {
          // Extract the date (e.g., 'YYYY-MM-DD') from the created_at field
          const createdDate = new Date(notification.created_at);
          const today = new Date();
          const yesterday = new Date(today);
          yesterday.setDate(today.getDate() - 1);

          // Format the created date to 'YYYY-MM-DD'
          const notificationDate = createdDate.toLocaleDateString();

          // Format today's date and yesterday's date
          const todayDate = today.toLocaleDateString();
          const yesterdayDate = yesterday.toLocaleDateString();

          // Check if the notification date is today, yesterday, or older
          let displayDate = notificationDate;
          if (notificationDate === todayDate) {
            displayDate = 'Today';
          } else if (notificationDate === yesterdayDate) {
            displayDate = 'Yesterday';
          }

          // Check if the date already exists in the accumulator
          let dateGroup = acc.find(group => group.date === displayDate);

          if (!dateGroup) {
            // If the date doesn't exist, add a new group for that date
            dateGroup = {date: displayDate, data: []};
            acc.push(dateGroup);
          }

          // Push the notification into the group's data array
          dateGroup.data.push(notification);

          return acc;
        }, []);

        // console.log('groupedData =>', groupedData , responseData.data);
        responseData.data = groupedData;

        dispatch(_commonDispatcher(FETCH_USER_NOTIFICATIONS, responseData));
        dispatch(_commonDispatcher(FETCH_USER_NOTIFICATIONS_ERROR, ''));
      }
      return 1;
    } catch (error) {
      dispatch(_commonDispatcher(FETCH_USER_NOTIFICATIONS, {}));
      dispatch(
        _commonDispatcher(FETCH_USER_NOTIFICATIONS_ERROR, error?.message || ''),
      );
      return 0;
    }
  };
};

export const _notificationRead = notification_id => {
  return async dispatch => {
    const {fetch_user_notifications} = getStoreState('user');
    try {
      const responseData = await call({
        baseUrl: `/notification/read-notification?app_notification_id=${notification_id}
          `,
        method: 'GET',
      });

      const updatedFullResponse = JSON.parse(
        JSON.stringify(fetch_user_notifications),
      );

      Object.entries(updatedFullResponse.data).map(([key, section]) => {
        const index = section?.data?.findIndex(
          n => n.app_notification_id === notification_id,
        );

        if (index !== -1) {
          section.data[index].app_notification_read = true;
        }

        return section; // optional if you want to use map's return value
      });

      dispatch(
        _commonDispatcher(FETCH_USER_NOTIFICATIONS, updatedFullResponse),
      );
      return 1;
    } catch (error) {
      console.log('error =>', error?.message);
      return 0;
    }
  };
};
