// redux/store.js

import { createStore, applyMiddleware } from 'redux';
import { persistStore, persistReducer } from 'redux-persist';
import { composeWithDevTools } from 'redux-devtools-extension';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { thunk } from 'redux-thunk';
import rootReducer from '@redux/reducers/rootReducer';

const persistConfig = {
    key: 'root',
    storage: AsyncStorage,
};

const persistedReducer = persistReducer(persistConfig, rootReducer);
const middleware = [thunk];
const composedEnhancer = composeWithDevTools(applyMiddleware(...middleware));

export const store = createStore(persistedReducer, composedEnhancer);
export const persistor = persistStore(store);