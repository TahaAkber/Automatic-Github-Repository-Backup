import React from 'react';
import { Text, StyleSheet } from 'react-native';
import { moderateScale } from 'react-native-size-matters';
import { font, colors, fontSizes } from '@constant/contstant';

const CustomText = ({
  text,
  style,
  color,
  numberOfLines,
  fontSize,
  fontFamily,
  marginTop,
  center,
  textAlign,
  hide,

}) => {
  return (
    <Text
      numberOfLines={numberOfLines}
      style={[
        styles.text,
        style,
        hide && { color: colors.light_theme.backgroundColor },
        color && { color: color || 'black' },
        marginTop && { marginTop: marginTop || 0 },
        fontSize && { fontSize: fontSize || moderateScale(16) },
        fontFamily && { fontFamily: fontFamily || font.medium },
        textAlign && { textAlign },
        center && { textAlign: 'center' },


      ]}>
      {text || ""}
    </Text>
  );
};

export default CustomText;

const styles = StyleSheet.create({
  text: {
    color: colors.light_theme.text,
    fontSize: fontSizes.regular,
    fontFamily: font.regular,
    // paddingTop: 1
  },
});