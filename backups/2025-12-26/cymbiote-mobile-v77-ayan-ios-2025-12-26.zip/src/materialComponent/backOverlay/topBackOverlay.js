import React from 'react';
import { StyleSheet, TouchableOpacity } from 'react-native';
import { goBack } from '@utils/navigationRef/navigationRef';
import { moderateScale } from 'react-native-size-matters';
import Icon from '@materialComponent/icon/icon';
import { WH } from '@constant/contstant';
import { margin } from '../../constant/contstant';

const TopBackOverLay = () => {
    return (
        <TouchableOpacity onPress={() => goBack()} style={styles.view}>
            <Icon
                size={moderateScale(25)}
                icon_type={"MaterialIcons"}
                name={"keyboard-backspace"}
                color={"black"}
            />
        </TouchableOpacity>
    );
};

export default TopBackOverLay;

const styles = StyleSheet.create({
    view: {
        width: WH.width(12),
        // backgroundColor: "rgba(255,255,255,0.2)",
        justifyContent: "center",
        alignItems: "center",
        borderRadius: 180,
        aspectRatio: 1,
        position: "absolute",
        top: WH.height(6),
        left: margin.horizontal
    }
})