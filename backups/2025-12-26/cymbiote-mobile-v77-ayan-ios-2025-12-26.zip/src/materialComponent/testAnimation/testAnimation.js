import React, { useEffect } from "react";
import { View, Text, StyleSheet } from "react-native";
import Animated, { useSharedValue, useAnimatedStyle, withTiming } from "react-native-reanimated";

const BasicReanimatedAnimation = () => {
    // Shared values for animation
    const opacity = useSharedValue(0); // Initial opacity: 0 (hidden)
    const translateY = useSharedValue(20); // Start position: 20px down

    useEffect(() => {
        // Start animations when the component mounts
        opacity.value = withTiming(1, { duration: 500 }); // Fade in
        translateY.value = withTiming(0, { duration: 500 }); // Move up
    }, []);

    // Animated styles using shared values
    const animatedStyle = useAnimatedStyle(() => {
        return {
            opacity: opacity.value, // Apply fade-in effect
            transform: [{ translateY: translateY.value }], // Apply move-up effect
        };
    });

    return (
        <Animated.View style={[styles.box, animatedStyle]}>
            <Text style={styles.text}>Hello, Reanimated! 🚀</Text>
        </Animated.View>
    );
};

const styles = StyleSheet.create({
    box: {
        width: 200,
        height: 100,
        backgroundColor: "#ff6347",
        alignItems: "center",
        justifyContent: "center",
        borderRadius: 10,
    },
    text: {
        color: "white",
        fontSize: 16,
        fontWeight: "bold",
    },
});

export default BasicReanimatedAnimation;
