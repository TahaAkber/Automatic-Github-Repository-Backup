import React, {useEffect, useRef} from 'react';
import {
  TouchableOpacity,
  View,
  StyleSheet,
  Dimensions,
  Animated,
  ActivityIndicator,
  Vibration,
} from 'react-native';
import CustomText from '@materialComponent/customText/customText';
import PagionationLoader from '../../component/loader/endReachLoader';
import {font} from '../../constant/contstant';
import { triggerHaptic } from '../../utils/haptic/haptic';

const {width, fontScale} = Dimensions.get('window'); // Get screen width dynamically
const defaultSize = width * 0.05; // Set radio button size relative to screen width

const CustomRadioButton = ({
  selected,
  onPress,
  label,
  size = defaultSize,
  color = 'black',
  loader,
  marginTop,
}) => {
  const scaleAnim = useRef(new Animated.Value(selected ? 1 : 0)).current; // Animated value for scaling

  useEffect(() => {
    Animated.timing(scaleAnim, {
      toValue: selected ? 1 : 0,
      duration: 200, // Animation duration in milliseconds
      useNativeDriver: true,
    }).start();
  }, [selected]);

  const handlePress = () => {
    if (onPress) {
      triggerHaptic()
      onPress();
    }
  };

  return (
    <TouchableOpacity
      onPress={handlePress}
      style={[styles.container, marginTop && {marginTop}]}
      activeOpacity={0.7}>
      {loader ? (
        <ActivityIndicator size="small" color={'black'} />
      ) : (
        <View
          style={[
            styles.radio,
            {
              borderColor: color,
              width: size,
              height: size,
              borderRadius: size / 2,
            },
          ]}>
          <Animated.View
            style={[
              styles.innerCircle,
              {
                backgroundColor: color,
                width: size * 0.6,
                height: size * 0.6,
                borderRadius: (size * 0.6) / 2,
                transform: [{scale: scaleAnim}], // Apply scale animation
                opacity: scaleAnim, // Apply fade-in effect
              },
            ]}
          />
        </View>
      )}
      {label ? (
        <CustomText
          color={'black'}
          fontSize={fontScale * 16}
          fontFamily={font.medium}
          style={{marginLeft: width * 0.04}}
          text={label}
        />
      ) : (
        <></>
      )}
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: width * 0.01, // Adjust margin relative to screen width
  },
  radio: {
    borderWidth: 2,
    alignItems: 'center',
    justifyContent: 'center',
  },
  innerCircle: {
    position: 'absolute',
  },
  label: {
    marginLeft: width * 0.02, // Adjust spacing dynamically
    fontSize: width * 0.035, // Adjust font size based on screen width
    color: '#333',
  },
});

export default CustomRadioButton;
