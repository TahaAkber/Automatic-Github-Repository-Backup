import React from "react";
import { View, StyleSheet, Dimensions } from "react-native";
import CustomText from "../customText/customText";
import LinearGradient from "react-native-linear-gradient";

const steps = [
    { label: "In Progress", color: "#2E7DC1" },
    { label: "Shipped", color: "#FCB914" },
    { label: "In Transit", color: "#F57F21" },
    { label: "Delivered", color: "#23B477" },
];

const { height, fontScale } = Dimensions.get("screen");

const CustomProgressIndicator = ({ currentStep }) => {
    return (
        <View style={styles.container}>

            {/* Progress Bar */}
            <View style={styles.progressBar}>


                <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
                    {/* {(currentStep == 1 || currentStep == 2 || currentStep == 3) &&
                        <LinearGradient
                            // colors={["#2E7DC1", "#FCB914"]} // Red to Green gradient
                            start={{ x: 0, y: 0 }} // Start from left
                            end={{ x: 1, y: 0 }}   // End at right
                            style={[
                                styles.gradientProgress,
                                {
                                    // left: index === 1 ? "31%" : index === 2 ? "62%" : index === 3 && "75%",
                                    width: "28%"
                                }
                            ]}
                        >
                        </LinearGradient >
                    }

                    {(currentStep == 2 || currentStep == 3) &&
                        <LinearGradient
                            // colors={["#fff", "#"]} // Red to Green gradient
                            start={{ x: 0, y: 0 }} // Start from left
                            end={{ x: 1, y: 0 }}   // End at right
                            style={[
                                styles.gradientProgress,
                                {
                                    left: "35%",
                                    // left: index === 1 ? "31%" : index === 2 ? "62%" : index === 3 && "75%",
                                    width: "30%"
                                }
                            ]}
                        >
                        </LinearGradient >
                    }

                    {(currentStep == 2) &&
                        <LinearGradient
                            // colors={["#F57F21", "#23B477"]} // Red to Green gradient
                            start={{ x: 0, y: 0 }} // Start from left
                            end={{ x: 1, y: 0 }}   // End at right
                            style={[
                                styles.gradientProgress,
                                {
                                    left: "65%",
                                    // left: index === 1 ? "31%" : index === 2 ? "62%" : index === 3 && "75%",
                                    width: "30%"
                                }
                            ]}
                        >
                        </LinearGradient >
                    } */}

                    {steps.map((step, index) => (
                        <>

                            <View
                                key={index * 120123}
                                style={[
                                    styles.stepCircle,
                                    { backgroundColor: index <= (currentStep -1) ? step.color : "#D9D9D9" },
                                ]}
                            />
                        </>

                    ))}
                </View>
            </View>

            {/* Labels */}
            <View style={styles.labelsContainer}>
                {steps.map((step, index) => (
                    <View key={index * 12312312} style={styles.labelWrapper}>
                        <CustomText color={"black"} fontSize={fontScale * 8} text={step.label} />
                    </View>
                ))}
            </View>
        </View >
    );
};

const styles = StyleSheet.create({
    container: {
        marginTop: height * 0.02,
        zIndex: 1
    },
    progressBar: {
        height: height * 0.005,
        width: "100%",
        borderRadius: 20,
        backgroundColor: "#E5EBFC",
        justifyContent: "center",
        alignSelf:"center"
        
    },
    stepCircle: {
        height: height * 0.02,
        aspectRatio: 1,
        borderRadius: 180,
        zIndex: 3
    },
    labelsContainer: {
        flexDirection: "row",
        justifyContent: "space-between",
        marginTop: height * 0.01,
        width:"115%",
        alignSelf:"center"
    },
    labelWrapper: {
        width: height * 0.05,
        alignItems: "center",
        justifyContent: "center",

    },
    gradientProgress: {
        // height: "100%",
        height: height * 0.015,
        borderRadius: 20,
        position: "absolute",
        left: height * 0.02,
        // left: 10,
        zIndex: 2,
        top: "25%"

    },
});

export default CustomProgressIndicator;


// <View style={styles.progressBar}>
// <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
//     {/* ✅ Render Progress Steps */}
//     {steps.map((step, index) => (
//         <View
//             key={index}
//             style={[
//                 styles.stepCircle,
//                 { backgroundColor: index < currentStep ? step.color : "#D9D9D9" },
//             ]}
//         />
//     ))}
// </View>
// </View>

