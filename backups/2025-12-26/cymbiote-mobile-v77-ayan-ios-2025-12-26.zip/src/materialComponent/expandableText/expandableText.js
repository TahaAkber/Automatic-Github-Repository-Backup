import React, {useState, useRef, useEffect} from 'react';
import {
  Text,
  StyleSheet,
  TouchableOpacity,
  View,
  Animated,
  Dimensions,
} from 'react-native';
import {moderateScale} from 'react-native-size-matters';
import {font, colors, fontSizes} from '@constant/contstant';
import {heightPercentageToDP} from 'react-native-responsive-screen';
import BottomSheetRenderHtml from '../bottomSheet/bottomSheetRenderHtml';
import {margin} from '../../constant/contstant';

const {height, width} = Dimensions.get('screen');

const ExpandableText = ({
  text,
  style,
  color,
  fontSize,
  fontFamily,
  marginTop,
  center,
  textAlign,
  htmlContent,
  removeSeeMore,
}) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [showSeeMore, setShowSeeMore] = useState(false);
  const [measured, setMeasured] = useState(false);
  const animationValue = useRef(new Animated.Value(0)).current;
  const refRBSheet = useRef();

  // smooth height animation
  useEffect(() => {
    Animated.timing(animationValue, {
      toValue: isExpanded ? 1 : 0,
      duration: 250,
      useNativeDriver: false,
    }).start();
  }, [isExpanded]);

  // const onTextLayout = e => {
  //   if (!measured) {
  //     const lines = e.nativeEvent.lines.length;
  //     if (lines > 2) setShowSeeMore(true);
  //     setMeasured(true); // ensure we only measure once
  //   }
  // };

  const onTextLayout = e => {
    if (!showSeeMore) {
      const {lines} = e.nativeEvent;
      if (lines.length >= 2) {
        setShowSeeMore(true);
      }
    }
  };

  if (!text) return null;

  const IsView = removeSeeMore ? TouchableOpacity : View;

  return (
    <IsView
      activeOpacity={1}
      onPress={() =>
        htmlContent ? refRBSheet?.current?.open() : setIsExpanded(!isExpanded)
      }>
      <Text
        onTextLayout={onTextLayout}
        ellipsizeMode="tail"
        numberOfLines={isExpanded ? undefined : 2}
        style={[
          styles.text,
          style,
          color && {color},
          marginTop && {marginTop},
          fontSize && {fontSize},
          fontFamily && {fontFamily},
          textAlign && {textAlign},
          center && {textAlign: 'center'},
        ]}>
        {text}
      </Text>

      <BottomSheetRenderHtml
        refRBSheet={refRBSheet}
        height={height * 0.6}
        htmlContent={htmlContent}
      />

      {showSeeMore && !removeSeeMore && (
        <TouchableOpacity
          onPress={() =>
            htmlContent
              ? refRBSheet?.current?.open()
              : setIsExpanded(!isExpanded)
          }>
          <Text style={styles.seeMoreText}>
            {isExpanded ? 'See Less' : 'See More'}
          </Text>
        </TouchableOpacity>
      )}
    </IsView>
  );
};

const styles = StyleSheet.create({
  text: {
    color: colors.light_theme.text,
    fontSize: fontSizes.regular,
    fontFamily: font.regular,
  },
  seeMoreText: {
    fontSize: moderateScale(14),
    marginTop: moderateScale(3),
    fontFamily: font.bold,
    color: colors.light_theme.theme,
  },
});

export default ExpandableText;
