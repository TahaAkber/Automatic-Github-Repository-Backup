import React, { useEffect, useRef } from 'react';
import { View, Animated, Easing, StyleSheet } from 'react-native';

const defaultColor = '#dfdfdf';
const defaultHighlightColor = '#F8F8F8';

const CustomSkeleton = ({ style, color = defaultColor, highlightColor = defaultHighlightColor, loading = true, children }) => {
  const fadeAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    let animation;

    if (loading) {
      animation = Animated.loop(
        Animated.sequence([
          Animated.timing(fadeAnim, {
            toValue: 1,
            duration: 1000,
            easing: Easing.linear,
            useNativeDriver: true,
          }),
          Animated.timing(fadeAnim, {
            toValue: 0.2,
            duration: 1000,
            easing: Easing.linear,
            useNativeDriver: true,
          }),
        ])
      );
      animation.start();
    }

    return () => {
      if (animation) animation.stop();
    };
  }, [loading, fadeAnim]);

  if (!loading) {
    return children || null;
  }

  return (
    <View style={[{ backgroundColor: color, overflow: 'hidden' }, style]}>
      <Animated.View
        style={[
          StyleSheet.absoluteFill,
          {
            backgroundColor: highlightColor,
            opacity: fadeAnim,
          },
        ]}
      />
    </View>
  );
};

export default React.memo(CustomSkeleton);
