import React from "react";
import { View, Text, StyleSheet, Dimensions } from "react-native";
import { PieChart } from "react-native-gifted-charts";
import CustomText from "../customText/customText";
import { colors, font, globalStyle } from "../../constant/contstant";
import Icon from "../icon/icon";
import RatingStars from "../ratingStars/ratingStars";

const { width, height, fontScale } = Dimensions.get("window");

const ReviewGraph = ({ productDetailReview }) => {



    const rating = productDetailReview?.averageRating;

    const percentage = (rating / 5) * 100;

    const data = [
        { value: percentage, color: "#FF7F00" },  // Active part
        { value: 100 - percentage, color: "#E4E9EE" } // Inactive part
    ];

    const percentages = {};

    if (
        productDetailReview &&
        productDetailReview.totalReviews &&
        productDetailReview.breakdown &&
        Object.keys(productDetailReview.breakdown).length > 0
    ) {
        for (const [key, value] of Object.entries(productDetailReview.breakdown)) {
            percentages[key] = ((value / productDetailReview.totalReviews) * 100).toFixed(1) + "%";
        }
    } else {
        console.warn("Breakdown data missing or totalReviews is 0");
    }



    const arr = [
        {
            title: "5.0",
            rating: percentages?.excellent || "0%",
            totalReviews: productDetailReview?.breakdown?.excellent || "0"
        },
        {
            title: "4.0",
            rating: percentages?.good || "0%",
            totalReviews: productDetailReview?.breakdown?.good || "0"
        },
        {
            title: "3.0",
            rating: percentages?.average || "0%",
            totalReviews: productDetailReview?.breakdown?.average || "0"
        },
        {
            title: "2.0",
            rating: percentages?.poor || "0%",
            totalReviews: productDetailReview?.breakdown?.poor || "0"
        },
        {
            title: "1.0",
            rating: percentages?.veryPoor || "0%",
            totalReviews: productDetailReview?.breakdown?.veryPoor || "0"
        },
    ]

    return (
        <View>
            <CustomText
                fontSize={fontScale * 17}
                fontFamily={font.bold}
                color="black"
                text={"Top Reviews"}
                marginTop={height * 0.02}
            />
            <View style={styles.container}>

                <View style={{
                    flexDirection: "row",
                    alignItems: "center",
                }}>
                    <View style={styles.chartContainer}>
                        <PieChart
                            data={data}
                            radius={width * 0.08} // Keep the same radius for a smaller chart
                            innerRadius={width * 0.06} // Keep inner radius small
                            showText={false}
                            donut
                        />
                        <View style={styles.centerTextContainer}>
                            <CustomText fontSize={fontScale * 14} fontFamily={font.black} text={productDetailReview?.averageRating ? productDetailReview?.averageRating?.toFixed(1) : `0`} />
                        </View>
                    </View>

                    <View style={{ flex: 1, justifyContent: "space-between", marginLeft: width * 0.03 }}>
                        <View style={[globalStyle.row, { marginBottom: height * 0.003 }]}>
                            {/* {[...Array(5)].map((_, i) => (
                                <Icon key={i} icon_type="AntDesign" name="star" color="#FF7F00" style={{ marginRight: 5 }} size={fontScale * 18} />
                            ))} */}
                            <RatingStars setRating={() => console.log("object")} view={true} initialRating={0} size={fontScale * 20} color={"#FF7F00"} rating={productDetailReview?.averageRating || 0} />
                        </View>
                        <View>
                            <CustomText fontSize={fontScale * 12} fontFamily={font.medium} text={(productDetailReview?.reviews || []).length ?  `from ${productDetailReview?.totalReviews || 0} reviews` : `This product has no reviews`} />
                        </View>
                    </View>
                </View>
                {(productDetailReview?.reviews || []).length > 0 ?
                    <View style={{ marginTop: height * 0.02 }}>
                        {arr.map((item, index) => {
                            return (
                                <View key={index} style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginTop: index == 0 ? 0 : height * 0.015 }}>
                                    <View style={[globalStyle.space_between, { width: "15%" }]}>
                                        <CustomText text={item.title} color={"black"} fontFamily={font.bold} fontSize={fontScale * 10} />
                                        <Icon icon_type="Entypo" name="star" color="#FF7F00" style={{ marginRight: 5 }} size={fontScale * 16} />
                                    </View>
                                    <View style={{ height: height * 0.01, width: "70%", backgroundColor: "#E4E9EE", zIndex: 1 }}>
                                        <View style={{ height: height * 0.01, width: item.rating, zIndex: 2, backgroundColor: "black" }} />
                                    </View>
                                    <View style={[{ width: "12%" }]}>
                                        <CustomText text={item.totalReviews || 0} color={"black"} textAlign={"right"} fontFamily={font.bold} fontSize={fontScale * 10} />
                                    </View>
                                </View>
                            )
                        })}
                    </View> : <></>
                }

            </View>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {

        borderWidth: 1,
        borderColor: colors.light_theme.themeGray,
        borderStyle: "dashed",
        padding: width * 0.04,
        borderRadius: 5,
        marginTop: height * 0.02
        // justifyContent: "center", // Ensures the chart is centered horizontally
    },
    chartContainer: {
        height: height * 0.07, // Adjust height if necessary
        aspectRatio: 1, // Keeps the chart as a square
        justifyContent: "center", // Ensures the chart stays centered vertically
        alignItems: "center", // Centers the chart inside the container,
    },
    centerTextContainer: {
        position: "absolute", // Ensures text is placed on top of the pie chart
        justifyContent: "center",
        alignItems: "center",
    },
    points: {
        fontSize: 24,
        fontWeight: "bold",
        color: "#000",
    },
    subtitle: {
        fontSize: 14,
        color: "gray",
    },
    legendContainer: {
        flexDirection: "row",
        justifyContent: "center",
        marginTop: height * 0.02,
        width: "80%",
    },
    legendItem: {
        flexDirection: "row",
        alignItems: "center",
        marginHorizontal: 10,
    },
    legendDot: {
        width: width * 0.02,
        aspectRatio: 1,
        borderRadius: 180,
        marginRight: width * 0.02,
    },
    legendText: {
        fontSize: 14,
        color: "#000",
    },
});

export default ReviewGraph;

