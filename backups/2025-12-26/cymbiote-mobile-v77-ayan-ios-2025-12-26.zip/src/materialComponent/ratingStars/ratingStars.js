import React, {useState} from 'react';
import {Dimensions, View} from 'react-native';
import StarRating from 'react-native-star-rating-widget';
import StarRatingDisplay from 'react-native-star-rating-widget';
import CustomText from '../customText/customText';
import {font} from '../../constant/contstant';
import {moderateScale} from 'react-native-size-matters';

const {fontScale} = Dimensions.get('screen');

const RatingStars = ({
  initialRating = 0,
  size,
  setRating,
  rating,
  marginLeft,
  marginRight,
  showRating,
  color,
  view,
}) => {
  return (
    <View
      style={{
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center',
      }}>
      {view ? (
        <StarRatingDisplay
          color={color || '#E4A70A'}
          starStyle={{
            marginRight: marginRight || 0,
            marginLeft: marginLeft || 0,
          }}
          maxStars={5}
          starSize={size || fontScale * 15}
          rating={rating}
          onChange={setRating}
        />
      ) : (
        <StarRating
          rating={rating}
          onChange={setRating}
          starSize={size || fontScale * 15}
          maxStars={5}
          starStyle={{
            marginRight: marginRight || 0,
            marginLeft: marginLeft || 0,
          }}
          color={color || '#E4A70A'}
        />
      )}

      {showRating && rating ? (
        <CustomText
          style={{marginLeft: 5}}
          fontSize={moderateScale(11)}
          color={'black'}
          fontFamily={font.medium}
          text={`${rating}`}
        />
      ) : (
        <></>
      )}
    </View>
  );
};

export default RatingStars;
