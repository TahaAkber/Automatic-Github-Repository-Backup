import {moderateScale, verticalScale} from 'react-native-size-matters';
import {showToast} from '@helper/reUsableMethod/reUsableMethod';
import CustomText from '@materialComponent/customText/customText';
import {colors, font, globalStyle} from '@constant/contstant';
import {useNavigation} from '@react-navigation/native';
import BrandTab from '@component/brandTab/brandTab';
import Icon from '@materialComponent/icon/icon';
import {WH} from '@constant/contstant';
import React, {useMemo, useRef, useState} from 'react';
import {
  View,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  Text,
  Dimensions,
  Linking,
} from 'react-native';
import {margin} from '../../constant/contstant';
import GorhomBottomSheet from './GorhomBottomSheet';
import BottomSheetReport from './bottomSheetReport';

const {height: screenHeight} = Dimensions.get('screen');

const BottomSheetForBrand = ({
  refRBSheet,
  title,
  height,
  brand,
  isProductDetail,
  shop,
  reel,
  story,
  id,
}) => {
  const [form, setForm] = useState('');
  const navigation = useNavigation();
  const reportSheetRef = useRef(null);

  const privacy_policy_url = brand?.shop_privacy_policy_url;
  const return_policy_url = brand?.shop_return_policy_url;
  const instagram_url = brand?.shop_instagram_url;
  const facebook_url = brand?.shop_facebook_url;
  const twitter_url = brand?.shop_twitter_url;
  const web_url = brand?.shop_web_url;

  const data = [];

  console.log('url ===>', brand);
  const openSocialLink = async (url, type) => {
    let appURL = url;
    let webURL = url;

    try {
      if (type === 'instagram') {
        const username = url.split('instagram.com/')[1]?.split('/')[0];
        appURL = `instagram://user?username=${username}`;
        webURL = `https://instagram.com/${username}`;
      } else if (type === 'facebook') {
        const username = url.split('facebook.com/')[1]?.split('/')[0];
        appURL = `fb://facewebmodal/f?href=https://facebook.com/${username}`;
        webURL = `https://facebook.com/${username}`;
      } else if (type === 'twitter') {
        const username = url.split('twitter.com/')[1]?.split('/')[0];
        appURL = `twitter://user?screen_name=${username}`;
        webURL = `https://twitter.com/${username}`;
      }

      const supported = await Linking.canOpenURL(appURL);

      if (supported) {
        await Linking.openURL(appURL); // ✅ Open app
      } else {
        await Linking.openURL(webURL); // 🌐 Fallback to web
      }
    } catch (error) {
      await Linking.openURL(webURL); // ✅ Final fallback (if anything fails)
    }
  };

  const openReportSheet = () => {
    reportSheetRef?.current?.open();
    refRBSheet?.current?.close();
  };

  const items = useMemo(() => {
    const arr = [...data]; // clone

    if (brand?.shop_web_url) {
      arr.push({
        id: 'visit',
        value: 'Visit shop',
        iconType: 'Fontisto',
        iconName: 'world-o',
        onPress: () => openSocialLink(web_url, 'web'),
      });
    }

    if (brand?.shop_instagram_url) {
      arr.push({
        id: 'instagram',
        value: 'Instagram',
        iconType: 'FontAwesome',
        iconName: 'instagram',
        onPress: () => openSocialLink(instagram_url, 'instagram'),
      });
    }

    if (brand?.shop_facebook_url) {
      arr.push({
        id: 'facebook',
        value: 'Facebook',
        iconType: 'FontAwesome',
        iconName: 'facebook',
        onPress: () => openSocialLink(facebook_url, 'facebook'),
      });
    }

    if (brand?.shop_twitter_url) {
      arr.push({
        id: 'twitter',
        value: 'Twitter',
        iconType: 'FontAwesome',
        iconName: 'twitter',
        onPress: () => openSocialLink(twitter_url, 'twitter'),
      });
    }

    if (brand?.shop_privacy_policy_url) {
      arr.push({
        id: 'privacy',
        value: 'Privacy policy',
        iconType: 'MaterialIcons',
        iconName: 'privacy-tip',
        onPress: () => openSocialLink(privacy_policy_url, 'web'),
      });
    }

    if (brand?.shop_return_policy_url) {
      arr.push({
        id: 'return',
        value: 'Return policy',
        webView: true,
        redirect_property: 'shop_return_policy_url',
        iconType: 'FontAwesome',
        iconName: 'undo',
        onPress: () => openSocialLink(return_policy_url, 'web'),
      });
    }
    arr.push({
      id: 'report',
      value: 'Report',
      iconType: 'Feather',
      iconName: 'flag',
      onPress: () => openReportSheet(),
    });

    return arr.filter(
      (obj, index, self) => index === self.findIndex(o => o.id === obj.id),
    );
  }, [data, brand]);

  const handleSubmit = (press, title) => {
    refRBSheet.current.close();
  };

  const closeMethod = () => {
    form ? setForm('') : refRBSheet.current.close();
  };

  const handleModifiedArray = (item, index) => {
    if (item.iconName === 'shop') {
      handleSubmit();
      navigation.navigate('Brand', {shop_id: brand?.shop_id});
    } else if (item.onPress) {
      item.onPress();
    }
  };

  const ITEM_HEIGHT = WH.height(8);

  const dynamicHeight = screenHeight * 0.1 + items.length * ITEM_HEIGHT;

  return (
    <View style={{zIndex: 1}}>
      <GorhomBottomSheet
        ref={refRBSheet}
        closeOnDragDown={true}
        closeOnPressMask={true}
        height={Math.min(dynamicHeight, screenHeight * 0.8)}
        customStyles={{
          container: {
            borderRadius: moderateScale(25),
            marginHorizontal: 10,
            // width: '90%',
            alignSelf: 'center',
            // marginBottom: WH.height(3),
            paddingHorizontal: margin.horizontal,
            paddingTop: screenHeight * 0.02,
          },
          indicator: {
            backgroundColor: 'black',
            width: 40,
          },
        }}>
        <View style={{flex: 1}}>
          {title && (
            <View style={styles.title}>
              <CustomText
                fontFamily={font.bold}
                fontSize={moderateScale(18)}
                text={title}
              />
            </View>
          )}

          <>
            {form ? (
              <View style={styles.formContainer}>
                <View>
                  <CustomText
                    fontFamily={font.bold}
                    text={form?.form?.heading}
                  />
                  <CustomText
                    fontSize={moderateScale(13)}
                    marginTop={verticalScale(5)}
                    fontFamily={font.regular}
                    text={form?.form?.subHeading}
                  />
                </View>
                <TouchableOpacity
                  onPress={closeMethod}
                  style={[styles.followContainer, styles.circle]}>
                  <Icon
                    icon_type="Ionicons"
                    name="close"
                    size={moderateScale(17)}
                    color="black"
                  />
                </TouchableOpacity>
              </View>
            ) : (
              <View style={styles.brandTabContainer}>
                <BrandTab
                  mainViewStyle={styles.brandTabContainer}
                  onPress={closeMethod}
                  item={brand}
                />
              </View>
            )}
          </>

          <ScrollView showsVerticalScrollIndicator={false}>
            {form &&
              form.form.fields.map((item, index) => (
                <TouchableOpacity
                  key={item.id}
                  style={[
                    styles.view,
                    {
                      borderBottomWidth: 1,
                      borderStyle: 'dashed',
                      borderColor: colors.light_theme.gray,
                    },
                  ]}
                  onPress={() => {
                    setForm('');
                    handleSubmit(item.text);
                    showToast();
                  }}>
                  {item.iconType && (
                    <Icon
                      icon_type={item.iconType}
                      name={item.iconName}
                      size={moderateScale(20)}
                      color="black"
                    />
                  )}
                  <Text
                    style={[
                      styles.text,
                      {fontFamily: font.medium, fontSize: moderateScale(12)},
                    ]}>
                    {item.text}
                  </Text>
                </TouchableOpacity>
              ))}

            {!form &&
              items.map((item, index) => (
                <TouchableOpacity
                  key={index}
                  style={styles.view}
                  onPress={() => handleModifiedArray(item, index)}>
                  {item.iconType && (
                    <View style={styles.iconContainer}>
                      <Icon
                        icon_type={item.iconType}
                        name={item.iconName}
                        size={item.size || moderateScale(20)}
                        color={item.color || 'black'}
                      />
                    </View>
                  )}
                  <Text style={[styles.text, {color: item.color || 'black'}]}>
                    {item.value}
                  </Text>
                </TouchableOpacity>
              ))}
          </ScrollView>
        </View>
      </GorhomBottomSheet>
      <BottomSheetReport
        ref={reportSheetRef}
        product={isProductDetail}
        shop={shop}
        reel={reel}
        story={story}
        id={id}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  view: {
    borderRadius: moderateScale(10),
    height: WH.height(6),
    // marginHorizontal: 10,
    ...globalStyle.row,
  },
  title: {
    marginHorizontal: moderateScale(20),
    marginBottom: verticalScale(15),
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: '2%',
  },
  text: {
    marginLeft: moderateScale(12),
    fontSize: moderateScale(14),
    color: colors.light_theme.text,
    fontFamily: font.medium,
  },
  formContainer: {
    paddingHorizontal: moderateScale(20),
    marginBottom: verticalScale(10),
    marginTop: WH.height(5),
    ...globalStyle.space_between,
  },
  brandTabContainer: {
    paddingHorizontal: moderateScale(0),
    // marginTop: WH.height(5),
  },
  followContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  circle: {
    width: moderateScale(25),
    backgroundColor: colors.light_theme.borderColor,
    justifyContent: 'center',
    alignItems: 'center',
    aspectRatio: 1 / 1,
    borderRadius: 180,
  },
  iconContainer: {
    justifyContent: 'center',
    height: WH.height(4),
    alignItems: 'center',
    aspectRatio: 1 / 1,
    borderRadius: 180,
  },
});

export default BottomSheetForBrand;
