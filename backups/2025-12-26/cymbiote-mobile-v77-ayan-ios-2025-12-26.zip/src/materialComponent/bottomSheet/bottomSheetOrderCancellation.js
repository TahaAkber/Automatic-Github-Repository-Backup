import React, {useEffect, useRef, useState} from 'react';
import {
  View,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  StatusBar,
  Dimensions,
} from 'react-native';
import GorhomBottomSheet from './GorhomBottomSheet';
import Icon from '@materialComponent/icon/icon';
import {font} from '@constant/contstant';
import CustomText from '../customText/customText';
import CustomButton from '../customButton/customButton';
import {useNavigation} from '@react-navigation/native';
import {margin} from '../../constant/contstant';
import CustomRadioButton from '../radioButton/radioButton';
import SearchInput from '../../component/input/searchInput';
import useCancellationEnums from '../../screen/loggedIn/orders/useCancellationEnums ';
import useReduxStore from '../../utils/hooks/useReduxStore';
import {
  _cancelOrder,
  _getInternalOrder,
  _getCancellationEnums,
} from '../../redux/actions/orders/orders';

const {fontScale, width, height} = Dimensions.get('screen');

const BottomSheetOrderCancellation = ({
  refRBSheet,
  refConfirmationSheet,
  height: sheetHeight,
  selectedOrder,
  tabId,
}) => {
  const [selectedReason, setSelectedReason] = useState(false);
  const {fetch_cancellation_enums_loader} = useCancellationEnums();
  const [isCancelling, setIsCancelling] = useState(false);
  const [orderCancelReason, setOrderCancelReason] = useState('');
  const scrollViewRef = useRef(null);

  const {dispatch} = useReduxStore();

  const closeSheet = () => {
    if (refRBSheet?.current) {
      refRBSheet.current.close();
    } else {
    }
  };
  const handleCloseConfirmation = () => {
    refConfirmationSheet.current?.close();
    setSelectedReason(null);
  };

  const handleCancelOrder = async () => {
    setIsCancelling(true);
    const res = await dispatch(
      _cancelOrder(
        selectedOrder?.order_shop_id,
        selectedOrder?.order_shopify_id,
        selectedReason,
        '',
        orderCancelReason,
        tabId,
      ),
    );
    setIsCancelling(false);
    if (res) {
      refRBSheet.current?.close();
      setTimeout(() => {
        refConfirmationSheet.current?.open();
      }, 300);
    }
  };

  const scrollBottom = () => {
    if (scrollViewRef.current) {
      setTimeout(() => {
        scrollViewRef.current.scrollToEnd({animated: true});
      }, 50);
    }
  };

  const handleValue = item => {
    setOrderCancelReason('');
    setSelectedReason(item);
    if (item == 'Other') scrollBottom();
  };

  return (
    <View style={{zIndex: 1}}>
      <GorhomBottomSheet
        ref={refRBSheet}
        closeOnDragDown={true}
        closeOnPressMask={true}
        height={sheetHeight || height * 0.45}
        customStyles={{
          container: {
            borderTopRightRadius: width * 0.06,
            borderTopLeftRadius: width * 0.06,
            paddingHorizontal: width * 0.025,
            alignSelf: 'flex-start',
          },
          indicator: {backgroundColor: 'black', width: width * 0.1},
        }}>
        <StatusBar
          animated
          barStyle={'light-content'}
          backgroundColor={'rgba(0, 0, 0, 0.8)'}
          translucent={false}
        />

        <View style={styles.content}>
          <View style={{marginBottom: height * 0.02}}>
            <CustomText
              fontFamily={font.bold}
              fontSize={fontScale * 18}
              marginTop={height * 0.02}
              text={'Order Cancellation'}
            />

            <TouchableOpacity onPress={closeSheet} style={styles.closeIcon}>
              <Icon
                icon_type="AntDesign"
                name="closecircleo"
                color="black"
                size={fontScale * 20}
              />
            </TouchableOpacity>
          </View>

          <ScrollView
            ref={scrollViewRef}
            showsVerticalScrollIndicator={false}
            contentContainerStyle={styles.scrollContent}>
            <View style={{width: '100%'}}>
              {fetch_cancellation_enums_loader ? (
                <CustomText
                  text="Loading cancellation reasons..."
                  center
                  fontSize={fontScale * 14}
                />
              ) : cancellationReasons.length > 0 ? (
                cancellationReasons.map((reason, index) => (
                  <CustomRadioButton
                    key={index}
                    selected={selectedReason == reason}
                    label={reason}
                    onPress={() => handleValue(reason)}
                    marginTop={height * 0.02}
                  />
                ))
              ) : (
                <CustomText
                  text="No cancellation reasons available."
                  center
                  fontSize={fontScale * 14}
                />
              )}

              {selectedReason == 'Other' ? (
                <SearchInput
                  removeSearchIcon={true}
                  placeholder={'Enter your reason'}
                  inputHeight={height * 0.08}
                  multiline={true}
                  onChangeText={setOrderCancelReason}
                  value={orderCancelReason}
                  style={{
                    borderRadius: 10,
                    marginTop: height * 0.01,
                    height: height * 0.08,
                    borderWidth: 1,
                    borderColor: '#E5E5E5',
                    backgroundColor: 'white',
                  }}
                />
              ) : (
                <></>
              )}
            </View>

            {/* <View style={{ width: "100%" }}>
                {cancellationReasons.map((reason, index) => (
                  <CustomRadioButton
                    key={index}
                    selected={selectedReason === reason}
                    label={reason}
                    onPress={() => setSelectedReason(reason)}
                    marginTop={height * 0.02}
                  />
                ))}
              </View> */}
          </ScrollView>

          <View style={styles.buttonContainer}>
            <CustomButton
              buttonStyle={styles.buttonStyle}
              textStyle={styles.buttonText}
              text={isCancelling ? 'Cancelling...' : 'Confirm'}
              onPress={() =>
                isCancelling ? closeSheet() : handleCancelOrder()
              }
              disabled={isCancelling || !selectedReason}
              loader={isCancelling}
              loaderSize={'small'}
            />
          </View>
        </View>
      </GorhomBottomSheet>
      <GorhomBottomSheet
        ref={refConfirmationSheet}
        closeOnDragDown={true}
        closeOnPressMask={true}
        height={height * 0.28}
        customStyles={{
          container: {
            borderTopRightRadius: width * 0.06,
            borderTopLeftRadius: width * 0.06,
            paddingHorizontal: width * 0.025,
          },
          indicator: {backgroundColor: 'black', width: width * 0.1},
        }}>
        <View>
          <View
            style={{
              width: width * 0.7,
              alignSelf: 'center',
              marginTop: height * 0.02,
            }}>
            <CustomText
              fontFamily={font.bold}
              fontSize={fontScale * 24}
              // marginTop={height * 0.02}
              text={'Your order has been cancelled'}
              center
            />
            <CustomText
              fontFamily={font.light}
              fontSize={fontScale * 14}
              marginTop={height * 0.02}
              text={'Thank you for choosing cercle'}
              center
            />
          </View>
          <View style={styles.buttonContainer}>
            <CustomButton
              buttonStyle={styles.buttonStyle}
              textStyle={styles.buttonText}
              text={'Done'}
              onPress={handleCloseConfirmation}
            />
          </View>
        </View>
      </GorhomBottomSheet>
    </View>
  );
};

export default BottomSheetOrderCancellation;

const styles = StyleSheet.create({
  content: {
    flex: 1,
    // alignItems: 'center',
    zIndex: 1,
    marginHorizontal: margin.horizontal,
  },
  closeIcon: {
    top: height * 0.015,
    right: -10,
    width: '20%',
    alignItems: 'flex-end',
    padding: 5,
    position: 'absolute',
    zIndex: 2,
  },
  scrollContent: {
    alignItems: 'center',
    justifyContent: 'center',
    // marginTop: height * 0.02,
  },
  point: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: height * 0.01,
  },
  buttonContainer: {
    // width: width * 0.9,
    marginTop: height * 0.03,
  },
  buttonStyle: {
    height: height * 0.05,
    borderRadius: 5,
    backgroundColor: 'black',
    marginBottom: height * 0.02,
  },
  buttonText: {
    fontSize: fontScale * 15,
    fontFamily: font.medium,
    color: 'white',
  },
});

const cancellationReasons = [
  'I no longer want this item',
  'Ordered by mistake',
  'Changed my mind after ordering',
  'Product information was unclear',
  'Payment or checkout issue',
  'Incorrect shipping address',
  // 'Delivery Time is too long',
  // 'Decided for an alternative product',
  // 'Duplicate order',
  // 'Urgent need no longer exists',
  // 'Ordered by mistake / accidental order',
  // 'Insufficient Product Information',
  'Other',
];
