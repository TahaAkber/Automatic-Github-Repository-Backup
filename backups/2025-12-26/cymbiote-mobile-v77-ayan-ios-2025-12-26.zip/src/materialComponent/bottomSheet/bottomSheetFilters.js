import {moderateScale, verticalScale} from 'react-native-size-matters';
import CustomText from '@materialComponent/customText/customText';
import {globalStyle, margin, WH} from '@constant/contstant';
import Icon from '@materialComponent/icon/icon';
import {colors} from '@constant/contstant';
import {font} from '@constant/contstant';
import React, {useEffect, useRef, useState} from 'react';
import Next from '@assets/images/next.svg';
import {
  View,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  Text,
  StatusBar,
  Dimensions,
} from 'react-native';
import CustomRadioButton from '../radioButton/radioButton';
import CustomCheckbox from '../checkboxButton/checkboxButton';
import CustomButton from '../customButton/customButton';
import Slider from '@react-native-community/slider';
import MultiSlider from '@ptomasroos/react-native-multi-slider';
import {currency} from '../../constant/signature';
import {heightPercentageToDP} from 'react-native-responsive-screen';
import {StarRatingDisplay} from 'react-native-star-rating-widget';
import GorhomBottomSheet from './GorhomBottomSheet';

const {width, fontScale, height: screenHeight} = Dimensions.get('screen');

const BottomSheetFilters = ({
  refRBSheet,
  data,
  height,
  onPress,
  filters,
  removeSelectedData,
  fetchAPI,
  brand,
  setBrand,
}) => {
  const [selectLocalItem, setSelectLocalItem] = useState(
    filters?.[data?.db_value] || data?.default_value,
  );

  const [isResetDisabled, setIsResetDisabled] = useState(true);

  const [range, setRange] = useState([0, 1000]);

  const sliderValueRef = useRef(
    filters?.[data?.db_value] || data?.default_value,
  );

  const handleSliderChange = values => {
    setSelectLocalItem(values);
  };

  useEffect(() => {
    if (data?.type == 'range') {
      sliderValueRef.current = selectLocalItem;
      setSelectLocalItem(filters?.[data?.db_value] || data?.default_value);
    } else if (typeof setBrand == 'function') {
      setSelectLocalItem(brand);
    } else {
      setSelectLocalItem(filters?.[data?.db_value] || data?.default_value);
    }

    setIsResetDisabled(filters?.[data?.db_value] ? false : true);
  }, [filters?.[data?.db_value], data?.default_value, data]);


  const _handleSubmit = () => {
    refRBSheet.current.close();
    onPress(data.db_value, selectLocalItem);
    fetchAPI(data.type != 'range' && selectLocalItem);
    removeSelectedData();
  };

  const handleSelectValue = id => {
    if (data?.type === 'radio') {
      // if (data?.db_value == 'brands') {
      //   setSelectLocalItem(id);
      // } else {
      setSelectLocalItem(id);
      setIsResetDisabled(false);
    } else if (data?.type === 'checkbox') {
      if (Array.isArray(id)) {
        setSelectLocalItem([]);
      } else {
        const copyArr = selectLocalItem ? [...selectLocalItem] : [];
        if (copyArr.includes(id)) {
          const updatedArr = copyArr.filter(item => item !== id);
          setSelectLocalItem(updatedArr);
        } else {
          copyArr.push(id);
          setSelectLocalItem(copyArr);
        }
      }
      setIsResetDisabled(false);
    } else if (data?.type === 'range') {
      sliderValueRef.current = id;
      setSelectLocalItem(id);
      setIsResetDisabled(false);
    }
  };
  const closeSheet = () => {
    if (refRBSheet?.current) {
      refRBSheet.current.close();
    } else {

    }
  };

  return (
    <View style={{zIndex: 1}}>
      <GorhomBottomSheet
        ref={refRBSheet}
        closeOnDragDown={true}
        closeOnPressMask={true}
        height={height || Dimensions.get('window').height * 0.5}
        customStyles={{
          container: {
            borderRadius: moderateScale(25),
            // paddingHorizontal: moderateScale(10),
          },
          indicator: {
            backgroundColor: 'black',
            width: 40,
          },
        }}>
        <StatusBar animated barStyle={'light-content'} translucent={false} />
        <View style={{flex: 1}}>
          {/* <View style={styles.bar} /> */}
          {data?.heading && (
            <View style={styles.title}>
              <CustomText
                fontFamily={font.bold}
                fontSize={moderateScale(18)}
                text={data?.heading}
              />
              {/* <TouchableOpacity
                onPress={closeSheet}
                style={[styles.closeIcon, {alignItems: 'flex-end'}]}>
                <Icon
                  icon_type="AntDesign"
                  name="closecircleo"
                  color="black"
                  size={20}
                />
              </TouchableOpacity> */}
            </View>
          )}

          <ScrollView showsVerticalScrollIndicator={false}>
            {data?.data?.map((item, index) => {
        
              return (
                <TouchableOpacity
                  onPress={() => handleSelectValue(item.id)}
                  style={styles.view}
                  activeOpacity={1}
                  key={item.id}>
                  <View
                    style={{
                      width: '100%',
                      // borderBottomWidth: 1,
                      borderColor: colors.light_theme.gray,
                      // height: 100,
                      paddingVertical: 10,
                      paddingTop: index == 0 ? 0 : 0,
                      // marginTop: screenHeight * 0.04,
                      // borderStyle: 'dashed',
                    }}>
                    <View style={globalStyle.space_between}>
                      {data?.db_value == 'ratings' ? (
                        <View style={globalStyle.row}>
                          {item.id ? (
                            <View>
                              <StarRatingDisplay
                                rating={Number(item?.main_search)}
                                starSize={fontScale * 20}
                                maxStars={5}
                                starStyle={{
                                  marginRight: 0,
                                  marginLeft: 0,
                                }}
                                color="#E4A70A"
                              />
                            </View>
                          ) : (
                            <></>
                          )}

                          <Text
                            style={[
                              styles.text,
                              {
                                color: colors.light_theme.text,
                                marginLeft: width * 0.01,
                                fontSize: item.id
                                  ? fontScale * 15
                                  : fontScale * 18,
                              },
                            ]}>
                            {item.value}
                          </Text>
                        </View>
                      ) : (
                        <Text
                          style={[
                            styles.text,
                            {color: colors.light_theme.text},
                          ]}>
                          {item.value}
                        </Text>
                      )}

                      {data?.type == 'radio' && (
                        <CustomRadioButton
                          onPress={() => handleSelectValue(item.id)}
                          selected={
                            // data?.db_value == 'brands'
                            //   ? brand == item.id
                            //   :
                            selectLocalItem == item.id
                          }
                        />
                      )}
                      {data?.type == 'checkbox' && (
                        <CustomCheckbox
                          selected={selectLocalItem?.includes(item.id)}
                          onPress={() => handleSelectValue(item.id)}
                        />
                      )}
                    </View>
                  </View>
                </TouchableOpacity>
              );
            })}

            {data?.type == 'range' && (
              <View
                style={{
                  marginTop: '20%',
                  marginHorizontal: margin.horizontal,
                }}>
                <CustomText
                  text={`${selectLocalItem?.[0]} - ${selectLocalItem?.[1]}`}
                  center
                  fontFamily={font.bold}
                  // fontSize={font}
                />

                {/* <View style={styles.rangeContainer}>
                  <Text style={styles.range}>${priceRange[0]}</Text>
                  <Text style={styles.range}>${priceRange[1]}</Text>
                </View> */}
                {selectLocalItem ? (
                  <MultiSlider
                    min={data?.default_value?.[0] || 0}
                    max={data?.default_value?.[1] || 100000}
                    step={1}
                    values={selectLocalItem}
                    onValuesChange={handleSliderChange}
                    trackStyle={styles.trackStyle}
                    selectedStyle={styles.selectedStyle}
                    unselectedStyle={styles.unselectedStyle}
                    sliderLength={width * 0.8}
                    markerStyle={{
                      width: heightPercentageToDP(2),
                      height: heightPercentageToDP(2),
                      marginTop: heightPercentageToDP(1),
                      backgroundColor: colors.light_theme.theme,
                      borderColor: 'white',
                      borderWidth: 1,
                    }}
                    // containerStyle={{borderRadius: 10, overflow: 'hidden'}}
                  />
                ) : (
                  <></>
                )}

                {/* <Slider
                  ref={sliderValueRef}
                  minimumValue={0}
                  maximumValue={100000}
                  onValueChange={handleSelectValue}
                  value={selectLocalItem}
                  minimumTrackTintColor="black" // Active (selected) part in black
                  maximumTrackTintColor="grey" // Inactive part in grey
                  thumbTintColor={'#223ea4'} // Thumb color in black
                  style={{height: 80}} // Adjust height of the slider (optional)
                  trackStyle={{
                    height: 20, // Thumb height (adjust size of the thumb)
                    borderRadius: 15, // Optional: Rounded corners for thumb
                  }}
                  step={1}
                /> */}
              </View>
            )}
          </ScrollView>
          <View
            style={[
              globalStyle.space_between,
              // {marginHorizontal: margin.horizontal},
            ]}>
            <View style={styles.buttonView}>
              <CustomButton
                backgroundColor={isResetDisabled ? '#f5f5f5' : '#e0e0e0'}
                textStyle={{
                  color: isResetDisabled ? '#a0a0a0' : 'black', // Light grey when disabled
                }}
                buttonStyle={{
                  // borderWidth: 1,
                  // borderColor: isResetDisabled ? '#e0e0e0' : '#b0b0b0',
                  opacity: isResetDisabled ? 0.5 : 1, // Reduced opacity when disabled
                }}
                onPress={() => {
                  if (!isResetDisabled) {
                    handleSelectValue(data?.default_value);
                    setIsResetDisabled(true); // Disable after reset
                  }
                }}
                disabled={isResetDisabled}
                text={'Reset'}
              />
            </View>
            <View style={styles.buttonView}>
              <CustomButton onPress={_handleSubmit} text={'Done'} />
            </View>
          </View>
        </View>
      </GorhomBottomSheet>
    </View>
  );
};
export default BottomSheetFilters;

const styles = StyleSheet.create({
  view: {
    borderRadius: moderateScale(10),
    // marginHorizontal: margin.horizontal,
    height: WH.height(6),
    ...globalStyle.space_between,
    // marginTop: WH.height(2),
  },
  bar: {
    marginTop: verticalScale(20),
    height: verticalScale(5),
    backgroundColor: colors.light_theme.darkBorderColor,
    alignSelf: 'center',
    borderRadius: 180,
    width: '10%',
  },
  title: {
    // marginHorizontal: margin.horizontal,
    marginBottom: verticalScale(15),
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: '2%',

    justifyContent: 'space-between',
  },
  text: {
    // marginLeft: moderateScale(12),
    fontSize: moderateScale(16),
    color: colors.light_theme.text,
    fontFamily: font.medium,
  },
  buttonView: {
    marginBottom: verticalScale(20),
    // marginHorizontal: margin.horizontal,
    width: '48%',
  },
  unselectedStyle: {
    backgroundColor: '#d9d9d9',
    height: heightPercentageToDP(1),
  },
  selectedStyle: {
    backgroundColor: colors.light_theme.theme,
    height: heightPercentageToDP(1),
  },
  trackStyle: {
    backgroundColor: 'red',
    borderRadius: 180,
  },
});
