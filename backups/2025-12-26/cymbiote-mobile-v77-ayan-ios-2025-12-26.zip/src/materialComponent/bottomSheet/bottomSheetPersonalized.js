import {
  View,
  Text,
  StyleSheet,
  Dimensions,
  TouchableOpacity,
  Alert,
} from 'react-native';
import React, {useState} from 'react';
import Toggle from '@materialComponent/toggle/toggle';
import {font, margin} from '../../constant/contstant';
import CustomToggle from '../toggle/togglePersonalized';
import useReduxStore from '../../utils/hooks/useReduxStore';
import {_createNotificationPreference} from '../../redux/actions/merchant/merchant';
import CustomButton from '../customButton/customButton';
import Icon from '../icon/icon';
import {moderateScale} from 'react-native-size-matters';
import GorhomBottomSheet from './GorhomBottomSheet';

const {fontScale, width, height} = Dimensions.get('screen');

const BottomSheetPersonalized = ({
  refRBSheet,
  userId,
  merchantId,
  toggles,
  setSelectedPrefrencesItems,
  selectedPrefrencesItems,
}) => {
  const [isLoading, setIsLOading] = useState(false);

  const {dispatch} = useReduxStore();

  const closeSheet = () => {
    if (refRBSheet?.current) {
      refRBSheet.current.close();
    } else {
   
    }
  };

  const handleToggle = dbValue => {
    let newArr = [...selectedPrefrencesItems];

    if (newArr.includes(dbValue)) {
      newArr = newArr.filter(item => item !== dbValue);
    } else {
      newArr.push(dbValue);
    }
    setSelectedPrefrencesItems(newArr);
  };

  const handleSave = async () => {
    closeSheet();
    try {
      setIsLOading(true);
      const payload = {
        userId,
        merchantId,
        preference: 'personalized',
        rules: selectedPrefrencesItems,
      };

     

      await dispatch(_createNotificationPreference(payload));

      setIsLOading(false);
    } catch (e) {
     
    }
  };
  return (
    <View style={styles.Container}>
      <GorhomBottomSheet
        ref={refRBSheet}
        closeOnDragDown={true}
        closeOnPressMask={true}
        customStyles={{
          container: {
            borderTopRightRadius: width * 0.06,
            borderTopLeftRadius: width * 0.06,
            paddingHorizontal: width * 0.025,
            height: height * 0.44,
          },
          indicator: {backgroundColor: 'black', width: width * 0.1},
        }}>
        <View style={{flex: 1, paddingTop: 20}}>
          <View
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
            }}>
            <Text
              style={{
                fontSize: moderateScale(18),
                fontFamily: font.bold,
                alignSelf: 'flex-start',
                marginHorizontal: margin.horizontal - 10,
              }}>
              Personalized Notifications
            </Text>
            <TouchableOpacity onPress={closeSheet} style={styles.closeIcon}>
              <Icon
                icon_type="AntDesign"
                name="closecircleo"
                color="black"
                size={fontScale * 20}
              />
            </TouchableOpacity>
          </View>
          <View style={styles.toggleContainer}>
            {toggles.map((item, index) => {
              return (
                <CustomToggle
                  key={item.id}
                  text={item.title}
                  marginTop={index === 0 ? height * 0.02 : height * 0.03}
                  value={selectedPrefrencesItems?.includes(item.db_value)}
                  onValueChange={() => handleToggle(item.db_value)}
                />
              );
            })}
            <View
              style={{marginTop: 20, marginBottom: 10, alignItems: 'center'}}>
              <CustomButton
                text={'Save '}
                onPress={handleSave}
                width={width - margin.horizontal}
                loader={isLoading}
              />
            </View>
          </View>
        </View>
      </GorhomBottomSheet>
    </View>
  );
};

export default BottomSheetPersonalized;

const styles = StyleSheet.create({
  Container: {
    flex: 1,
  },
  toggleContainer: {
    marginTop: 20,
  },
  closeIcon: {
    marginRight: margin.horizontal - 10,
  },
});
