import React, {useEffect, useState} from 'react';
import {
  View,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  StatusBar,
  Dimensions,
  FlatList,
} from 'react-native';
import Icon from '@materialComponent/icon/icon';
import RewardSvg from '@assets/images/reward.svg';
import PointSvg from '@assets/images/point.svg';
import {colors, font} from '@constant/contstant';
import CustomText from '../customText/customText';
import CustomImage from '../image/image';
import CustomButton from '../customButton/customButton';
import {CommonActions, useNavigation} from '@react-navigation/native';
import {globalStyle, margin, WH} from '../../constant/contstant';
import VoucherCard from '../../component/cards/voucherCard/voucherCard';
import {call, showToast} from '../../helper/reUsableMethod/reUsableMethod';
import {
  checkUserExistence,
  formatDateTime,
  formatExpiryDisplay,
  getStoreState,
  toFixedMethod2,
} from '../../utils/helper/helper';
import EmptyScreen from '../../component/emptyScreen/emptyScreen';
import useReduxStore from '../../utils/hooks/useReduxStore';
import GorhomBottomSheet from './GorhomBottomSheet';
import BottomSheetConfirmRedemption from './bottomSheetConfirmRedemption';

const {fontScale, width, height} = Dimensions.get('screen');

const BottomSheetVoucherList = ({
  onPress,
  refRBSheet,
  height: sheetHeight,
  heading,
  desc,
  buttonText,
  shop_detail,
  onCreateNewPress,
  voucher,
  setVoucher,
  orderAmount,
}) => {
  const navigation = useNavigation();
  const {fetch_user_detail} = getStoreState('auth');
  const [voucherList, setVoucherList] = useState([]);
  const [voucherListLoader, setVoucherListLoader] = useState(true);
  const [isCreating, setIsCreating] = useState(false);
  const listHeight = sheetHeight || height * 0.47;
  const createHeight = height * 0.46;
  const [currentHeight, setCurrentHeight] = useState(listHeight);
  const {getState, dispatch} = useReduxStore();
  const {user_point_history} = getState('reward');

  const confirmPoint = user_point_history?.[0]?.totalPoints ?? 0;
  const currentBalance = confirmPoint;

  const fetchAPI = async () => {
    if (fetch_user_detail?.id) {
      try {
        setVoucherListLoader(true);
        const responseData = await call({
          baseUrl: `/points/user/voucher/${
            fetch_user_detail?.id
          }?page=${1}&pageSize=&shop_id=${shop_detail?.shop_id}`,
          method: 'GET',
        });
        setVoucherList(responseData?.logs || []);
        setVoucherListLoader(false);
        console.log('responseData =>', responseData?.logs);
      } catch (error) {
        console.log('responseData', error?.message);
        console.log(error, '<=====error');
        setVoucherList([]);
        showToast(error?.message);
        setVoucherListLoader(false);
      }
    }
  };

  console.log('orderAmount ===>', orderAmount);

  const handlePress = () => {
    onPress && onPress();
    setIsCreating(true);
    setCurrentHeight(createHeight);
    onCreateNewPress && onCreateNewPress();
  };

  const closeSheet = () => {
    if (refRBSheet?.current) {
      refRBSheet.current.close();
      setIsCreating(false);
      setCurrentHeight(listHeight);
    } else {
      console.log('Error: refRBSheet is undefined or not assigned.');
    }
  };

  useEffect(() => {
    fetchAPI();
  }, [refRBSheet, voucher, shop_detail]);

  const handleSetVoucher = item => {
    if (voucher?.voucher_id == item?.voucher_id) {
      setVoucher({});
      setIsCreating(false);
      closeSheet();
    } else {
      setVoucher(item);
      setIsCreating(false);
      closeSheet();
    }
  };

  const renderVoucherItem = ({item, index}) => {
    return (
      <VoucherCard
        heading={
          item?.voucher_is_redeemed
            ? 'voucher has been used.'
            : 'Your Voucher has been created'
        }
        subTitle={`${item.voucher_code}`}
        expiryDate={formatExpiryDisplay(item.voucher_expiration_date, true)}
        point={item.voucher_value}
        image={item?.shop?.shop_logo_url}
        buttonColor="black"
        buttonText={
          voucher?.voucher_id == item?.voucher_id ? 'Remove' : 'Apply now'
        }
        onPress={() => handleSetVoucher(item)}
        orderAmount={orderAmount}
      />
    );
  };

  return (
    <View style={{zIndex: 1}}>
      <GorhomBottomSheet
        onClose={closeSheet}
        ref={refRBSheet}
        height={currentHeight}>
        <StatusBar animated barStyle="light-content" translucent={false} />

        <View style={styles.content}>
          {!isCreating && (
            <>
              <CustomText
                fontFamily={font.medium}
                fontSize={fontScale * 20}
                marginTop={height * 0.03}
                text={`${currentBalance ? toFixedMethod2(currentBalance) : 0}`}
                center
              />

              <CustomText
                fontFamily={font.regular}
                fontSize={fontScale * 13}
                marginTop={height * 0.005}
                text={`Remaining points`}
                color={'#8f8f8f'}
                center
              />
            </>
          )}

          <View
            style={[
              {
                marginHorizontal: margin.horizontal,
                marginTop: height * 0.015,
                marginBottom: height * 0.02,
              },
            ]}>
            {!isCreating && (
              <CustomButton
                onPress={() => handlePress()}
                text={'Create New Voucher'}
                textStyle={{fontSize: fontScale * 14}}
                buttonStyle={{
                  width: '100%',
                  height: height * 0.05,
                  borderRadius: 8,
                }}
              />
            )}
          </View>
          <View style={{flex: 1}}>
            {isCreating ? (
              <BottomSheetConfirmRedemption
                embedded
                data={shop_detail}
                setVoucher={setVoucher}
                voucher={voucher}
                onCloseRequest={() => {
                  setIsCreating(false);
                  setCurrentHeight(listHeight);
                }}
                onHeightChange={setCurrentHeight}
                initialHeight={createHeight}
                orderAmount={orderAmount}
              />
            ) : (
              <View
                style={{
                  marginBottom: height * 0.01,
                  marginTop: height * 0.01,
                }}>
                {voucherList.length > 0 ? (
                  <FlatList
                    data={voucherList}
                    keyExtractor={(item, index) => index.toString()}
                    renderItem={renderVoucherItem}
                    contentContainerStyle={[{marginBottom: height * 0.2}]}
                  />
                ) : (
                  <View
                    style={{
                      justifyContent: 'center',
                      alignItems: 'center',
                      marginTop: height * 0.03,
                    }}>
                    <EmptyScreen
                      image={'empty_voucher'}
                      heading={'No voucher yet'}
                      desc={
                        "No vouchers are available at the moment. Click 'Create New Voucher' to redeem your points at this store."
                      }
                      imageSize={width * 0.16}
                      headingSize={fontScale * 14}
                      descSize={fontScale * 12}
                    />
                  </View>
                )}
              </View>
            )}
          </View>
        </View>
      </GorhomBottomSheet>
    </View>
  );
};

export default BottomSheetVoucherList;

const styles = StyleSheet.create({
  content: {
    flex: 1,
    // alignItems: 'center',
    zIndex: 1,
  },
  closeIcon: {
    // top: height * 0.015,
    right: width * 0.03,
    width: '20%',
    // alignItems: "flex-end",
    padding: 5,
    // position: "absolute",
    zIndex: 2,
    marginTop: -20,
  },
  scrollContent: {
    // alignItems: 'center',
    // justifyContent: 'center',
  },
  point: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: height * 0.01,
  },
  buttonContainer: {
    width: width * 0.9,
    marginTop: height * 0.03,
  },
  buttonStyle: {
    height: height * 0.05,
    borderRadius: 5,
  },
  buttonText: {
    fontSize: fontScale * 15,
    fontFamily: font.medium,
  },
});
