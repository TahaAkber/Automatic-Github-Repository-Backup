import React, { useRef, useEffect } from 'react';
import {
  View,
  StatusBar,
  Dimensions,
  StyleSheet,
} from 'react-native';
import Cart from '../../screen/loggedIn/cart/cart';
import GorhomBottomSheet from './GorhomBottomSheet';

const { width, height } = Dimensions.get("screen");

const BottomSheetCart = ({ isVisible, toggleSheet }) => {
  const refRBSheet = useRef(null);

  useEffect(() => {
    if (isVisible) {
      refRBSheet.current?.open();
    } else {
      closeSheet();
    }
  }, [isVisible]);

  const closeSheet = () => {
    refRBSheet.current?.close();
    toggleSheet(false);
  };

  return (
    <View style={{ zIndex: 1 }}>
      <StatusBar animated barStyle="dark-content" translucent={false} />
      <GorhomBottomSheet
        ref={refRBSheet}
        closeOnDragDown={true}
        closeOnPressMask={false}
        onClose={closeSheet}
        customStyles={{
          container: {
            borderTopRightRadius: width * 0.06,
            borderTopLeftRadius: width * 0.06,
            paddingHorizontal: width * 0.025,
          },
          indicator: { backgroundColor: 'black', width: width * 0.1 },
        }}>
        <View style={styles.header}>
          <View style={styles.dragIndicator} />
        </View>
        <Cart />
      </GorhomBottomSheet>
    </View>
  );
};

export default BottomSheetCart;

const styles = StyleSheet.create({
  container: {
    backgroundColor: "white",
    width: "100%",
    position: "absolute",
    bottom: 0,
    borderTopRightRadius: 20,
    borderTopLeftRadius: 20,
  },
  header: {
    backgroundColor: "black",
    height: height * 0.05,
    justifyContent: "flex-end",
    paddingBottom: height * 0.02,
    borderBottomRightRadius: 20,
    borderBottomLeftRadius: 20,
    alignItems: "center",
  },
  dragIndicator: {
    width: width * 0.15,
    height: height * 0.007,
    backgroundColor: "white",
    borderRadius: 180,
  },
});
