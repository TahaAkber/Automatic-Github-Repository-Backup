import React, { useEffect, useRef } from 'react';
import {
  TouchableOpacity,
  View,
  StyleSheet,
  Dimensions,
  Animated,
  ActivityIndicator,
  Vibration,
} from 'react-native';
import CustomText from '@materialComponent/customText/customText';
import { font } from '../../constant/contstant';
import Icon from '../icon/icon';
import { triggerHaptic } from '../../utils/haptic/haptic';

const { width, fontScale } = Dimensions.get('window'); // Get screen width dynamically
const defaultSize = width * 0.05; // Set checkbox size relative to screen width

const CustomCheckbox = ({
  selected,
  onPress,
  label,
  size = defaultSize,
  color = 'black',
  loader,
  marginTop,
}) => {
  const scaleAnim = useRef(new Animated.Value(selected ? 1 : 0)).current; // Animated value for scaling

  useEffect(() => {
    Animated.timing(scaleAnim, {
      toValue: selected ? 1 : 0,
      duration: 200, // Animation duration in milliseconds
      useNativeDriver: true,
    }).start();
  }, [selected]);

  const handlePress = () => {
    if (onPress) {
      triggerHaptic()
      onPress(); // This will toggle the checkbox
    }
  };

  return (
    <TouchableOpacity
      onPress={handlePress}
      style={[styles.container, marginTop && { marginTop }]}
      activeOpacity={1}>
      {loader ? (
        <ActivityIndicator size="small" color={'black'} />
      ) : (
        <View
          style={[
            styles.checkbox,
            {
              borderColor: color,
            },
          ]}>
          <Animated.View
            style={[
              styles.innerSquare,
              {
                width: size * 0.9,
                height: size * 0.9,
                opacity: scaleAnim, // Apply fade-in effect
              },
            ]}
          />
          <Icon
            name={selected ? 'checkbox-active' : 'checkbox-passive'}
            size={size * 0.9} // Adjust size of checkmark
            color="black"
            style={styles.icon}
            icon_type={'Fontisto'}
          />
        </View>
      )}
      {label ? (
        <CustomText
          color={'black'}
          fontSize={fontScale * 16}
          fontFamily={font.medium}
          style={{ marginLeft: width * 0.04 }}
          text={label}
        />
      ) : (
        <></>
      )}
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: width * 0.01, // Adjust margin relative to screen width
  },
  checkbox: {
    // borderWidth: 2,
    alignItems: 'center',
    justifyContent: 'center',
  },
  innerSquare: {
    position: 'absolute',
  },
});

export default CustomCheckbox;
