import React from 'react';
import { Dimensions, StyleSheet, View } from 'react-native';
import { colors, font, globalStyle } from '../../constant/contstant';
import CustomText from '../customText/customText';

const { height, width, fontScale } = Dimensions.get("screen")

const CustomProgressBar = ({ title, percent, marginTop }) => {
    return (
        <View style={[globalStyle.space_between, marginTop && { marginTop }]}>
            <CustomText fontSize={fontScale * 14} color={"#858585"} text={title} fontFamily={font.bold} />
            <View style={styles.progress}>
                <View style={[styles.activeProgress, { width: percent }]} />
            </View>
        </View>
    );
};

export default CustomProgressBar;

const styles = StyleSheet.create({
    progress: {
        height: height * 0.01,
        backgroundColor: "#D9D9D9",
        width: "75%",
        borderRadius: 180
    },
    activeProgress: {
        height: height * 0.01,
        backgroundColor: colors.light_theme.theme,
        width: "80%",
        borderRadius: 180
    },
});