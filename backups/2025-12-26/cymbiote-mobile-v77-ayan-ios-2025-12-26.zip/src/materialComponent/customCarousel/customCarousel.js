import React, { useRef, useState } from 'react';
import { Dimensions, FlatList, StyleSheet, View, Animated } from 'react-native';
import CustomImage from '../image/image';
import Icon from '../icon/icon';

const { width } = Dimensions.get("screen");

const url = "https://s3-alpha-sig.figma.com/img/dfc3/dd72/6e0f810b0310ac03baa5a0afa501097b?Expires=1742169600&Key-Pair-Id=APKAQ4GOSFWCW27IBOMQ&Signature=tjIUDhsYxTjA92vVbkyC~8bjEsa5oq2fDkmVGRsxybO5xFD1sD3tIf-1rrAnijeuT6kW23VJRazYXL~-ITME74EIO2zER2DrCrPVZ5X9ns-w4sdNEJphUCgY0ekJfJ48eTNodPd~KLkzplskf6Jy9osJyu7MJ8DhzSIrOObzS9owIAO2W2eRbYSiCoYpy3IkEoAR0fQpvlck9cXom7Ke5fKRfErpUXW74Bd9NvrjfhIzYWHnaL4Fk~486KbUZoD31Im5EpAwldpJPDY9GJWkXsr647uoxAw43SD9dBOJ~sHUJR0EC4Y30GSy3j2xHYr4yxsxH6xKqSVBNdWpU6pm7g__";

const images = Array(10).fill(url);

const CustomCarousel = ({ marginTop, horizontal = true }) => {
    const [centerIndex, setCenterIndex] = useState(4); // Default center index
    const scrollX = useRef(new Animated.Value(0)).current;

    const handleScroll = (event) => {
        const offsetX = event.nativeEvent.contentOffset.x;
        const index = Math.round(offsetX / (width * 0.08)); // Calculate center index dynamically
        setCenterIndex(index);
    };

    const renderItem = ({ item, index }) => {
        const isCenter = index === centerIndex;
        const imageWidth = isCenter ? width * 0.145 : width * 0.128;

        return (
            <View style={[styles.imageView, { width: imageWidth }]}>
                <CustomImage source={{ uri: item }} style={[styles.image, { width: imageWidth }]} />
            </View>
        );
    };

    return (
        <View style={[styles.container, marginTop && { marginTop }, !horizontal && { backgroundColor: "red", width: width * 0.2, alignItems: "center", flexDirection: "column" }]}>
            <View style={styles.circle}>
                <Icon icon_type={"MaterialIcons"} name={"keyboard-arrow-left"} color={"white"} />
            </View>
            <View style={[styles.list, !horizontal && { width: width * 0.2, }]}>
                <FlatList
                    data={images}
                    renderItem={renderItem}
                    keyExtractor={(item, index) => index.toString()}
                    horizontal={horizontal}
                    showsHorizontalScrollIndicator={false}
                    onScroll={handleScroll} // Track scroll position
                    scrollEventThrottle={16} // Smooth scrolling
                    snapToInterval={width * 0.1}
                    decelerationRate="fast"
                    ItemSeparatorComponent={() => <View style={{ width: width * 0.01 }} />}  // Adds space between items
                />
            </View>
            <View style={styles.circle}>
                <Icon icon_type={"MaterialIcons"} name={"keyboard-arrow-right"} color={"white"} />
            </View>
        </View>
    );
};

export default CustomCarousel;

const styles = StyleSheet.create({
    container: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
    },
    image: {
        aspectRatio: 1,
        borderRadius: 4,
        backgroundColor: "white"
    },
    circle: {
        width: width * 0.06,
        aspectRatio: 1,
        borderRadius: 180,
        backgroundColor: "rgba(0,0,0,0.5)",
        justifyContent: "center",
        alignItems: "center"
    },
    imageView: {
        justifyContent: "center",
        alignItems: "center",
    },
    list: {
        width: width * 0.7,
        justifyContent: "center",
        alignItems: "center",

    },
    centerText: {
        marginTop: 10,
        alignItems: "center",
    },
    centerImage: {
        width: 50,
        height: 50,
        borderRadius: 8,
    }
});
