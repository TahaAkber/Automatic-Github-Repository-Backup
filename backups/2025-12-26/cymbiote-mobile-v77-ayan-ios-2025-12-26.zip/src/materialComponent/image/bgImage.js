import {
  ImageBackground,
  StyleSheet,
  ActivityIndicator,
  View,
} from 'react-native';
import React, { memo, useState } from 'react';
import { colors } from '@constant/contstant';
import { noImageUrl } from '../../constant/contstant';

const CustomBackgoundImage = ({
  source,
  style,
  resizeMode,
  size,
  imageStyle,
  children,
}) => {
  const [loading, setLoading] = useState(true);

  // Handle the image loading event
  const handleImageLoad = () => {
    setLoading(false);
  };

  const finalSource = source?.uri ? source : { uri: noImageUrl };

  return (
    <ImageBackground
      onLoad={handleImageLoad}
      source={finalSource}
      imageStyle={imageStyle}
      resizeMode={resizeMode}
      style={[styles.container, style]}>
      {loading && (
        <View style={styles.loaderContainer}>
          <ActivityIndicator
            size={size || 'large'}
            color={colors.light_theme.theme}
          />
        </View>
      )}
      {children}
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  container: {
    position: 'relative',
    backgroundColor: 'rgba(0,0,0,0.5)', // Optional: background overlay
  },
  loader: {
    position: 'absolute',
    top: '50%',
    left: '50%',
    // marginLeft: -25, // This centers the loader horizontally
    // marginTop: -25,  // This centers the loader vertically
  },
  loaderContainer: {
    ...StyleSheet.absoluteFillObject, // pura parent cover karega
    justifyContent: 'center',
    alignItems: 'center',
  },
  image: {
    width: '100%',
    height: '100%',
  },
});

export default memo(CustomBackgoundImage);
