import {Image, StyleSheet, View, ActivityIndicator} from 'react-native';
import React, {useState} from 'react';
import {colors} from '@constant/contstant';
import FastImage from 'react-native-fast-image';
import {noImageUrl} from '../../constant/contstant';

const CustomImage = ({source, style, size, resizeMode}) => {
  const [loading, setLoading] = useState(false);
  const [imageError, setImageError] = useState(false);

  // Determine if the source is a remote URL or a local image
  const isRemote =
    typeof source === 'string' || source?.uri?.startsWith('http');

  // Handle the image loading event
  const handleImageLoad = () => setLoading(false);

  // Handle image load failure
  const handleImageError = () => {
    setLoading(false);
    setImageError(true);
  };

  // Adjust the size of the ActivityIndicator based on the `size` prop
  const getLoaderStyle = () => {
    const loaderSize = size === 'small' ? 20 : 40; // size in px for small/large
    return {
      width: loaderSize,
      height: loaderSize,
      transform: [{translateX: -loaderSize / 2}, {translateY: -loaderSize / 2}],
    };
  };

  return (
    <View style={[styles.container, style]}>
      {loading && (
        <ActivityIndicator
          style={[styles.loader, getLoaderStyle()]} // Dynamically adjust loader position
          size={size || 'large'}
          color={colors.light_theme.theme} // Customize the color as needed
        />
      )}

      <FastImage
        source={
          source
            ? {uri: source.uri || noImageUrl, priority: FastImage.priority.high}
            : source
        }
        resizeMode={resizeMode || 'cover'}
        style={[styles.image, style, loading && {opacity: 0}]} // Hide image while loading
        onLoad={handleImageLoad}
        onError={handleImageError}
        fadeDuration={300} // Smooth transition effect
        resizeMethod="resize" // Improve performance by resizing on load
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    position: 'relative',
    // backgroundColor: 'rgba(0,0,0,0.5)', // Optional: adjust based on needs
    backgroundColor: '#EFEFEF', // Optional: adjust based on needs
  },
  loader: {
    position: 'absolute',
    top: '50%',
    left: '50%',
  },
  image: {
    width: '100%',
    height: '100%',
  },
});

export default CustomImage;
