import {StyleSheet, View} from 'react-native';
import React from 'react';
import LinearGradient from 'react-native-linear-gradient';

const Overlay = ({reverseGradient = false, borderRadius}) => {
  return (
    <LinearGradient
      colors={[
        'rgba(0, 0, 0, 0.9)',
        'rgba(0, 0, 0, 0.5)',
        'rgba(0, 0, 0, 0.3)',
        'rgba(0, 0, 0, 0.1)',
      ]}
      style={[styles.overlay, {borderRadius}]}
      start={reverseGradient ? {x: 0, y: 1} : {x: 0, y: 0}} // Start from bottom-left if reversed
      end={reverseGradient ? {x: 0, y: 0} : {x: 1, y: 1}} // End at top-right if reversed
    />
  );
};

export default Overlay;

const styles = StyleSheet.create({
  overlay: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 20, // Rounded corners for the overlay
  },
});
