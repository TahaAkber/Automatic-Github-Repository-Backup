import React, {useEffect} from 'react';
import {StyleSheet, View, TouchableOpacity} from 'react-native';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import {bottomTabShadow} from '@constant/contstant';
import {HomeNavigator, OrderNavigation, SearchNavigator} from './navigators';
import useReduxStore from '../utils/hooks/useReduxStore';
import HomeIcon from '../assets/images/homeunfilled';
import SearchIcon from '../assets/images/searchunfilled';
import TrackingOrdersIcon from '../assets/images/orderunfilled';
import HomeIconFilled from '../assets/images/homefilled.svg';
import SearchIconFilled from '../assets/images/searchfilled';
import TrackingOrdersIconFilled from '../assets/images/orderfilled';

import {_setHomeScrollPosition} from '../redux/actions/common/common';
import {isAndroid} from '../constant/contstant';
import {
  heightPercentageToDP,
  widthPercentageToDP,
} from 'react-native-responsive-screen';
import {triggerHaptic} from '../utils/haptic/haptic';
import {handleNotificationPress} from '../helper/reUsableMethod/reUsableMethod';
import branch from 'react-native-branch';
import BottomTabBackAndCart from '../component/bottomTabBackAndCart/bottomTabBackAndCart';
import {
  getFocusedRouteNameFromRoute,
  useNavigationState,
} from '@react-navigation/native';
import messaging from '@react-native-firebase/messaging';
import {useSafeAreaInsets} from 'react-native-safe-area-context';
import {verticalScale} from 'react-native-size-matters';

const Tab = createBottomTabNavigator();
const TAB_HEIGHT = verticalScale(40);
const TAB_ICON_SIZE = 17;
const HiddenTabRoutes = new Set([
  'AuthNavigator',
  'ForgotPassword',
  'IntroSlider',
  'ResetPassword',
  'CreateAddress',
  'Register',
  'Login',
  'Otp',
  'Checkout',
  'Intrest',
  'SocialRegister',
  'Success',
  'Chat',
  'ChatProduct',
  'OrderManagemanet',
  'ManageOrder',
  'OrderPlacement',
  'TrackOrder',
  'ChatBot',
  'CustomerCare',
  'ReelsScreen',
  'Stories',
  'ChatWithAI',
]);

const createTabIcon =
  (FilledIcon, UnfilledIcon) =>
  ({focused}) => {
    const IconComponent = focused ? FilledIcon : UnfilledIcon;
    return (
      <View style={styles.iconWrapper}>
        <IconComponent width={TAB_ICON_SIZE} height={TAB_ICON_SIZE} />
      </View>
    );
  };

const homeTabIcon = createTabIcon(HomeIconFilled, HomeIcon);
const searchTabIcon = createTabIcon(SearchIconFilled, SearchIcon);
const cartTabIcon = createTabIcon(TrackingOrdersIconFilled, TrackingOrdersIcon);

const TabButton = props => {
  const {style, ...rest} = props;
  return (
    <TouchableOpacity
      {...rest}
      activeOpacity={1}
      style={[style, styles.tabButton]}
    />
  );
};

const AppTabs = () => {
  const {getState, dispatch} = useReduxStore();
  const {focusHomeScreen} = getState('common');

  useEffect(() => {
    messaging()
      .getInitialNotification()
      .then(remoteMessage => {
        if (remoteMessage) {
          handleNotificationPress(remoteMessage, dispatch);
        }
      });
  }, []);

  useEffect(() => {
    const unsubscribe = branch?.subscribe(({error, params}) => {
      if (error) {
        return;
      }

      if (params['+clicked_branch_link']) {
        const canonical = params?.['$canonical_identifier'];

        if (canonical) {
          const [screenName, productId] = canonical.split('/');
          const parsingData = {
            data: {
              screenName: screenName,
              payload: params?.payload,
            },
          };
          handleNotificationPress(parsingData, dispatch);
        }
      }
    });

    return () => {
      unsubscribe && unsubscribe();
    };
  }, [focusHomeScreen]);

  const getActiveRouteName = state => {
    if (!state || !state.routes || state.index === undefined) return null;
    const route = state.routes[state.index];

    if (route.state) {
      return getActiveRouteName(route.state);
    }

    return route.name;
  };

  const navigationState = useNavigationState(state => state);
  const currentRouteName = getActiveRouteName(navigationState);
  const insets = useSafeAreaInsets();

  const showBottomTabBackAndCart = !HiddenTabRoutes.has(currentRouteName);

  return (
    <View style={{flex: 1, width: '100%', zIndex: 1}}>
      {showBottomTabBackAndCart && <BottomTabBackAndCart height={TAB_HEIGHT} />}
      <Tab.Navigator
        screenOptions={({route}) => {
          const routeName = getFocusedRouteNameFromRoute(route) ?? route.name;
          const hideTab = HiddenTabRoutes.has(routeName);

          return {
            headerShown: false,
            tabBarShowLabel: false,
            tabBarActiveTintColor: '#FF3B30',
            tabBarInactiveTintColor: '#B0B0B0',
            tabBarStyle: {
              ...styles.tabBar,
              display: hideTab ? 'none' : 'flex',
              bottom: isAndroid
                ? heightPercentageToDP(4) +
                  insets.bottom -
                  heightPercentageToDP(2)
                : heightPercentageToDP(4),
            },
            tabBarItemStyle: styles.tabItem,
            tabBarIconStyle: styles.tabIcon,
            safeAreaInsets: {bottom: 0},
            tabBarButton: TabButton,
          };
        }}>
        <Tab.Screen
          name="Home"
          component={HomeNavigator}
          listeners={{
            tabPress: e => {
              triggerHaptic();
              if (focusHomeScreen) {
                dispatch(_setHomeScrollPosition(true));
                setTimeout(() => {
                  dispatch(_setHomeScrollPosition(false));
                }, 300);
              }
            },
          }}
          options={{
            tabBarIcon: homeTabIcon,
          }}
        />
        <Tab.Screen
          name="Search"
          component={SearchNavigator}
          listeners={{
            tabPress: e => {
              triggerHaptic();
            },
          }}
          options={{
            tabBarIcon: searchTabIcon,
          }}
        />
        <Tab.Screen
          name="Cart"
          component={OrderNavigation}
          listeners={{
            tabPress: e => {
              triggerHaptic();
            },
          }}
          options={{
            tabBarIcon: cartTabIcon,
          }}
        />
      </Tab.Navigator>
    </View>
  );
};

export default AppTabs;

const styles = StyleSheet.create({
  tabBar: {
    bottom: heightPercentageToDP(4),
    height: TAB_HEIGHT,
    alignSelf: 'center',
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'visible',
    position: 'absolute',
    borderRadius: 180,
    marginHorizontal: widthPercentageToDP(30),
    borderWidth: 1,
    borderColor: '#f4f4f4',
    backgroundColor: 'white',
    ...bottomTabShadow,
    padding: 0,
  },
  tabButton: {
    flex: 1,
    height: '100%',
    minHeight: TAB_HEIGHT,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 0,
    marginVertical: 0,
    backgroundColor: 'transparent',
  },
  tabItem: {
    height: TAB_HEIGHT,
    minHeight: TAB_HEIGHT,
    justifyContent: 'center',
    alignItems: 'center',
  },
  tabIcon: {
    height: '100%',
    alignItems: 'center',
    justifyContent: 'center',
  },
  iconWrapper: {
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
  },
});
