import React from 'react';
import {View, Animated, StyleSheet} from 'react-native';
import {NavigationContainer} from '@react-navigation/native';
import SplashScreen from '@screen/loggedIn/splashScreen/splashScreen';
import AppUpdateScreen from '@screen/appUpdate/appUpdateScreen';
import {BottomSheetModalProvider} from '@gorhom/bottom-sheet';
import InAppNotification from '../component/inAppNotification/inAppNotification';
import {navigationRef} from '@utils/navigationRef/navigationRef';
import {IntroSliderNavigator} from './navigators';
import AppTabs from './customBottomTab';
import {_cartBottomSheet} from '../redux/actions/common/common';
import useNavigationContainer from './useNavigationContainer';
import {triggerHaptic} from '../utils/haptic/haptic';
import CartBottomSheet from './cartBottomSheet';

const linking = {
  prefixes: ['cercle://', 'https://cercle.one'],
  config: {
    screens: {
      Search: 'product/:234',
    },
  },
};

const AppNavigationContainer = () => {
  const {
    setSplash,
    animatedBackgroundColor,
    backgroundColorAnim,
    appTabsTranslateY,
    appTabsOpacity,
    cartBottomSheet,
    animatedHeight,
    bottomSheetOpacity,
    introSlider,
    dispatch,
    splash,
    cart_item: cartItems,
    showUpdateScreen,
    canSkipUpdate,
    updateUrl,
    latestVersion,
    skipUpdateScreen,
  } = useNavigationContainer();

  const handleCloseCart = () => {
    dispatch(_cartBottomSheet(false));
    triggerHaptic();
  };

  const renderMainContent = () => (
    <>
      {!introSlider && !splash && (
        <View style={styles.flex}>
          <IntroSliderNavigator />
        </View>
      )}

      {!splash && introSlider && (
        <View style={styles.mainWrapper}>
          <Animated.View
            style={[
              styles.appTabsWrapper,
              {
                transform: [{translateY: appTabsTranslateY}],
                backgroundColor: animatedBackgroundColor,
                opacity: appTabsOpacity,
              },
            ]}>
            <AppTabs />
          </Animated.View>

          <CartBottomSheet
            animatedHeight={animatedHeight}
            isVisible={cartBottomSheet}
            cartItems={cartItems}
            onClose={handleCloseCart}
            tabsTranslateY={appTabsTranslateY}
            backgroundDim={backgroundColorAnim}
            opacity={bottomSheetOpacity}
          />
        </View>
      )}

      <View style={styles.notificationContainer}>
        <InAppNotification />
      </View>
    </>
  );

  const renderContent = () => {
    if (showUpdateScreen && !splash) {
      return (
        <AppUpdateScreen
          onSkip={skipUpdateScreen}
          storeUrl={updateUrl}
          canSkip={canSkipUpdate}
          latestVersion={latestVersion}
        />
      );
    }

    return renderMainContent();
  };

  return (
    <NavigationContainer linking={linking} ref={navigationRef}>
      <BottomSheetModalProvider>
        {splash && <SplashScreen splash={splash} setLoader={setSplash} />}
        {renderContent()}
      </BottomSheetModalProvider>
    </NavigationContainer>
  );
};

export default AppNavigationContainer;

const styles = StyleSheet.create({
  flex: {
    flex: 1,
  },
  mainWrapper: {
    flex: 1,
    backgroundColor: 'white',
  },
  appTabsWrapper: {
    flex: 1,
    borderRadius: 180,
  },
  notificationContainer: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 1000,
  },
});
