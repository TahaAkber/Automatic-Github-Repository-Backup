import * as React from 'react';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import {createNavigationContainerRef} from '@react-navigation/native';
import {TransitionSpecs} from '@react-navigation/bottom-tabs';
import useReduxStore from '@utils/hooks/useReduxStore';

// Authentication Screens
import ForgotPassword from '@screen/authentication/forgotPassword/forgotPassword';
import ResetPassword from '@screen/authentication/resetPassword/resetPassword';
import Register from '@screen/authentication/register/register';
import Otp from '@screen/authentication/otp/otp';
import SocialRegister from '@screen/authentication/socialRegister/socialRegister';
import Success from '@screen/authentication/success/success';
import AuthControl from '@component/authController/authController';

// Logged-in Screens
import Home from '@screen/loggedIn/home/home';
import ProductDetail from '@screen/loggedIn/productDetail/productDetail';
import CreateAddress from '@screen/loggedIn/createAddress/createAddress';
import Notification from '@screen/loggedIn/notification/notification';
import EditProfile from '@screen/loggedIn/editProfile/editProfile';
import RecentView from '@screen/loggedIn/recentViewed/recentView';
import Addresses from '@screen/loggedIn/addresses/addresses';
import Profile from '@screen/loggedIn/profile/profile';
import Brand from '@screen/loggedIn/brand/brand';
import Cart from '@screen/loggedIn/cart/cart';
import Checkout from '@screen/loggedIn/checkout/checkout';
import Search from '@screen/loggedIn/search/search';
import ThankYou from '@screen/loggedIn/thankYou/thankYou';
import Tracking from '@screen/loggedIn/tracking/tracking';

// Intro Screens
import IntroSlider from '@screen/introSlider/introSlider';
import Intrest from '@screen/loggedIn/intrest/intrest';
import Following from '@screen/loggedIn/following/following';
import Favorites from '@screen/loggedIn/favorites/favorites';
import ProductReview from '@screen/loggedIn/productReview/productReview';
import ReviewDetail from '@screen/loggedIn/reviewDetail/reviewDetail';
import AllReviews from '@screen/loggedIn/allReviews/allReviews';
import Inbox from '../screen/loggedIn/inbox/inbox';
import Rewards from '../screen/loggedIn/rewards/rewards';
import PointHistory from '../screen/loggedIn/pointHistory/pointHistory';
import Redeem from '../screen/loggedIn/redeem/redeem';
import Settings from '../screen/loggedIn/settings/settings';
import NotificationSetting from '../screen/loggedIn/notificationSetting/notificationSetting';
import TrackingNotificationSetting from '../screen/loggedIn/trackingNotificationSetting/trackingNotificationSetting';
import ShoppingNotificationSetting from '../screen/loggedIn/shoppingNotificationSetting/shoppingNotificationSetting';
import TrackingSources from '../screen/loggedIn/trackingSources/trackingSources';
import CustomWebView from '../screen/loggedIn/customWebView/customWebView';
import DeleteAccount from '../screen/loggedIn/deleteAccount/DeleteAccount';
import Orders from '../screen/loggedIn/orders/orders';
import OrderDetail from '../screen/loggedIn/orderDetail/orderDetail';
import BrandSearch from '../screen/loggedIn/brandSearch/brandSearch';
// import Chat from '@screen/loggedIn/inbox/chat';
import ChatProduct from '../screen/loggedIn/inbox/chatProduct';
import HelpCenter from '../screen/loggedIn/inbox/helpCenter';
import OrderManagment from '../screen/loggedIn/inbox/orderManagement';
import OrderPlacement from '../screen/loggedIn/helpCenter/orderPlacement';
import ManageOrder from '../screen/loggedIn/helpCenter/manageOrder';
import TrackOrder from '../screen/loggedIn/helpCenter/trackOrder';
import ChatBot from '../screen/loggedIn/helpCenter/chatBot';
import HelpCenterHeader from '../component/header/helpCenterHeader';
import CustomerCare from '../screen/loggedIn/customerCare/customerCare';
import Reels from '../screen/reels/reels';
import ReelsScreen from '../screen/reels/reelsScreen';
import ProfileLogin from '../screen/loggedIn/profile/profileLogin';
import {CardStyleInterpolators} from '@react-navigation/stack';
import Vouchers from '../screen/loggedIn/vouchers/vouchers';
import SearchedItems from '../screen/loggedIn/searchedItems/searchedItems';
import SearchSecondDegree from '../screen/loggedIn/searchSecondDegree/searchSecondDegree';
import Stories from '../screen/stories/storiesViewer';
import BrandCollection from '../screen/loggedIn/brandCollection/brandCollection';
import {isAndroid} from '../constant/contstant';
import TrendingCollection from '../screen/loggedIn/trendingCollection/trendingCollection';
import SavedReels from '../screen/loggedIn/savedReels/savedReels';
// import Chat from '../screen/loggedIn/inbox/chat';
import ChatwithAi from '@screen/loggedIn/chatwithai/chatwithai';
import MerchantSearches from '../component/brandContent/merchantSearches';
import OrderReceipt from '../screen/loggedIn/orderReceipt/orderReceipt';
import CreateTracking from '../screen/loggedIn/createTracking/createTracking';
import TrackingDetail from '../screen/loggedIn/trackingDetail/trackingDetail';
import Chat from '../screen/loggedIn/inbox/chat';
import ChatScreen from '../screen/loggedIn/chat/chat';

const Stack = createNativeStackNavigator();
export const homeStackRef = createNavigationContainerRef();
/**
 * 🔹 Default Navigation Animation Settings (Performance Optimized)
 */
// const defaultStackNavOptions = {
//   gestureEnabled: true, // Enable gestures
//   gestureDirection: 'horizontal', // Horizontal gestures for swipe animations
//   headerShown: false,
//   transitionSpec: {
//     open: TransitionSpecs.TransitionIOSSpec,
//     close: TransitionSpecs.TransitionIOSSpec,
//   },
//   animation: 'slide_from_right',
// };

const defaultStackNavOptions = () => {
  if (isAndroid) {
    return {
      gestureEnabled: true,
      gestureDirection: 'horizontal',
      headerShown: false,
      animation: 'fade',
    };
  } else {
    return {
      gestureEnabled: true,
      gestureDirection: 'horizontal',
      headerShown: false,
      transitionSpec: {
        open: TransitionSpecs.TransitionIOSSpec,
        close: TransitionSpecs.TransitionIOSSpec,
      },
      animation: 'slide_from_right',
    };
  }
};
/**
 * 🔹 Authentication Stack (Public Routes)
 */
export const AuthNavigator = () => (
  <Stack.Navigator screenOptions={defaultStackNavOptions}>
    <Stack.Screen name="Login" component={AuthControl} />
    <Stack.Screen name="ForgotPassword" component={ForgotPassword} />
    <Stack.Screen name="ResetPassword" component={ResetPassword} />
    <Stack.Screen name="Register" component={Register} />
    <Stack.Screen name="SocialRegister" component={SocialRegister} />
    <Stack.Screen name="Otp" component={Otp} />
    <Stack.Screen name="Success" component={Success} />
    <Stack.Screen name="Intrest" component={Intrest} />
  </Stack.Navigator>
);

/**
 * 🔹 Home Navigation Stack (Protected Routes)
 */
export const HomeNavigator = () => {
  const {getState} = useReduxStore();
  const {token} = getState('auth');
  return (
    <Stack.Navigator screenOptions={defaultStackNavOptions} ref={homeStackRef}>
      <Stack.Screen name="HomePage" component={Home} />
      <Stack.Screen
        name="ProductDetail"
        component={ProductDetail}
        options={{
          animation: isAndroid ? 'fade' : 'slide_from_right',
          animationTypeForReplace: 'pop',
        }}
      />
      <Stack.Screen name="OrderDetail" component={OrderDetail} />

      <Stack.Screen name="CreateAddress" component={CreateAddress} />
      <Stack.Screen name="Notification" component={Notification} />
      <Stack.Screen name="EditProfile" component={EditProfile} />
      <Stack.Screen name="RecentView" component={RecentView} />
      <Stack.Screen name="Addresses" component={Addresses} />
      <Stack.Screen name="Profile" component={Profile} />
      <Stack.Screen name="Brand" component={Brand} />
      <Stack.Screen name="Cart" component={Cart} />
      <Stack.Screen name="Checkout" component={Checkout} />
      <Stack.Screen name="ThankYou" component={ThankYou} />
      <Stack.Screen name="Following" component={Following} />
      <Stack.Screen name="Favorites" component={Favorites} />
      <Stack.Screen name="ProductReview" component={ProductReview} />
      <Stack.Screen name="ReviewDetail" component={ReviewDetail} />
      <Stack.Screen name="AllReviews" component={AllReviews} />
      <Stack.Screen name="Inbox" component={Inbox} />
      <Stack.Screen name="Rewards" component={Rewards} />
      <Stack.Screen name="PointHistory" component={PointHistory} />
      <Stack.Screen name="Redeem" component={Redeem} />
      <Stack.Screen name="SavedReels" component={SavedReels} />
      <Stack.Screen name="Settings" component={Settings} />
      <Stack.Screen
        name="NotificationSetting"
        component={NotificationSetting}
      />
      <Stack.Screen
        name="TrackingNotificationSetting"
        component={TrackingNotificationSetting}
      />
      <Stack.Screen
        name="ShoppingNotificationSetting"
        component={ShoppingNotificationSetting}
      />
      <Stack.Screen name="TrackingSources" component={TrackingSources} />
      <Stack.Screen name="CustomWebView" component={CustomWebView} />
      <Stack.Screen name="DeleteAccount" component={DeleteAccount} />

      <Stack.Screen name="BrandSearch" component={BrandSearch} />
      <Stack.Screen name="ChatWithAI" component={ChatwithAi} />
      <Stack.Screen name="ChatProduct" component={ChatProduct} />
      <Stack.Screen name="HelpCenter" component={HelpCenter} />
      <Stack.Screen name="OrderManagemanet" component={OrderManagment} />
      <Stack.Screen name="OrderPlacement" component={OrderPlacement} />
      <Stack.Screen name="ManageOrder" component={ManageOrder} />
      <Stack.Screen name="TrackOrder" component={TrackOrder} />
      <Stack.Screen name="ChatBot" component={ChatBot} />
      <Stack.Screen name="CustomerCare" component={CustomerCare} />
      <Stack.Screen name="ReelsScreen" component={ReelsScreen} />
      <Stack.Screen name="Reels" component={Reels} />
      <Stack.Screen name="ProfileLogin" component={ProfileLogin} />
      <Stack.Screen name="Vouchers" component={Vouchers} />
      <Stack.Screen name="BrandCollection" component={BrandCollection} />
      <Stack.Screen name="Tracking" component={Tracking} />
      <Stack.Screen name="CreateTracking" component={CreateTracking} />
      <Stack.Screen
        name="Stories"
        component={Stories}
        options={{
          animation: 'slide_from_bottom',
          headerShown: false,
        }}
      />

      <Stack.Screen name="OrderNavigation" component={OrderNavigation} />
      <Stack.Screen name="TrendingCollection" component={TrendingCollection} />
      <Stack.Screen name="Orders" component={Orders} />
      <Stack.Screen name="MerchantSearches" component={MerchantSearches} />
      <Stack.Screen name="OrderReceipt" component={OrderReceipt} />
      <Stack.Screen name="TrackingDetail" component={TrackingDetail} />
      <Stack.Screen name="Chat" component={ChatScreen} />

      {!token && (
        <Stack.Screen name="AuthNavigator" component={AuthNavigator} />
      )}
    </Stack.Navigator>
  );
};

/**
 * 🔹 Intro Slider Navigation
 */
export const IntroSliderNavigator = () => (
  <Stack.Navigator screenOptions={defaultStackNavOptions}>
    <Stack.Screen name="IntroSlider" component={IntroSlider} />
    <Stack.Screen name="Intrest" component={Intrest} />
    <Stack.Screen name="AuthNavigator" component={AuthNavigator} />
  </Stack.Navigator>
);

export const OrderNavigation = () => (
  <Stack.Navigator screenOptions={defaultStackNavOptions}>
    <Stack.Screen name="Orders" component={Orders} />
    <Stack.Screen name="OrderDetail" component={OrderDetail} />
    <Stack.Screen name="Checkout" component={Checkout} />
    <Stack.Screen name="Notification" component={Notification} />
    <Stack.Screen name="Settings" component={Settings} />
    <Stack.Screen name="CreateAddress" component={CreateAddress} />
    <Stack.Screen name="Addresses" component={Addresses} />
    <Stack.Screen name="TrackingSources" component={TrackingSources} />
    <Stack.Screen name="NotificationSetting" component={NotificationSetting} />
    <Stack.Screen
      name="TrackingNotificationSetting"
      component={TrackingNotificationSetting}
    />
    <Stack.Screen name="CustomWebView" component={CustomWebView} />
    <Stack.Screen name="DeleteAccount" component={DeleteAccount} />
    <Stack.Screen
      name="ProductDetail"
      component={ProductDetail}
      options={{
        animation: isAndroid ? 'fade' : 'slide_from_right',
        animationTypeForReplace: 'pop',
        // animation: 'fade', // Use slide animation for both platforms
      }}
    />
    <Stack.Screen name="MerchantSearches" component={MerchantSearches} />
    <Stack.Screen name="Brand" component={Brand} />
    <Stack.Screen name="OrderReceipt" component={OrderReceipt} />
    <Stack.Screen name="Tracking" component={Tracking} />
    <Stack.Screen name="CreateTracking" component={CreateTracking} />
    <Stack.Screen name="TrackingDetail" component={TrackingDetail} />
    <Stack.Screen name="Reels" component={Reels} />
    <Stack.Screen name="BrandCollection" component={BrandCollection} />
    <Stack.Screen name="Chat" component={ChatScreen} />
     <Stack.Screen
        name="Stories"
        component={Stories}
        options={{
          animation: 'slide_from_bottom',
          headerShown: false,
        }}
      />
    {/* <Stack.Screen name="ChatWithAi" component={Chat} /> */}
  </Stack.Navigator>
);

export const SearchNavigator = () => (
  <Stack.Navigator screenOptions={defaultStackNavOptions}>
    <Stack.Screen name="Search" component={Search} />
    <Stack.Screen
      name="ProductDetail"
      component={ProductDetail}
      options={{
        animation: isAndroid ? 'fade' : 'slide_from_right',
        animationTypeForReplace: 'pop',
        // animation: 'fade', // Use slide animation for both platforms
      }}
    />
    <Stack.Screen name="Brand" component={Brand} />
    <Stack.Screen name="SearchedItems" component={SearchedItems} />
    <Stack.Screen name="SearchSecondDegree" component={SearchSecondDegree} />
    <Stack.Screen name="BrandCollection" component={BrandCollection} />
    <Stack.Screen name="ReelsScreen" component={ReelsScreen} />
    <Stack.Screen name="ChatWithAI" component={ChatwithAi} />
    <Stack.Screen name="CreateAddress" component={CreateAddress} />
    <Stack.Screen name="Checkout" component={Checkout} />
    <Stack.Screen name="MerchantSearches" component={MerchantSearches} />
    <Stack.Screen name="BrandSearch" component={BrandSearch} />
    <Stack.Screen name="OrderReceipt" component={OrderReceipt} />
    <Stack.Screen name="Tracking" component={Tracking} />
    <Stack.Screen name="CreateTracking" component={CreateTracking} />
    <Stack.Screen name="TrackingDetail" component={TrackingDetail} />
     <Stack.Screen
        name="Stories"
        component={Stories}
        options={{
          animation: 'slide_from_bottom',
          headerShown: false,
        }}
      />
  </Stack.Navigator>
);

/**
 * 🔹 Main App Navigation Stack
 */
const Navigator = () => {
  return (
    <Stack.Navigator screenOptions={defaultStackNavOptions}>
      <Stack.Screen name="HomeNavigator" component={HomeNavigator} />
      <Stack.Screen name="SearchNavigator" component={SearchNavigator} />
      <Stack.Screen name="Cart" component={Cart} />
    </Stack.Navigator>
  );
};

export default Navigator;
