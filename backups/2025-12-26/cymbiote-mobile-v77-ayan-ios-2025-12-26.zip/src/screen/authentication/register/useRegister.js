import { _register, _socialLogin, _userVerifier } from '@redux/actions/auth/auth';
import { GoogleSignin } from '@react-native-google-signin/google-signin';
import { showToast } from '@helper/reUsableMethod/reUsableMethod';
import { _getStores } from '@redux/actions/merchant/merchant';
import { _globalLoader } from '@redux/actions/common/common';
import useReduxStore from '@utils/hooks/useReduxStore';
import { useEffect, useRef, useState } from 'react';
import { Animated, Keyboard, Vibration } from 'react-native';
import { _login } from '@redux/actions/auth/auth';
import DeviceInfo from 'react-native-device-info';
import * as Yup from 'yup';
import {
  AccessToken,
  AuthenticationToken,
  LoginManager,
} from 'react-native-fbsdk-next';
import { triggerHaptic } from '../../../utils/haptic/haptic';

GoogleSignin.configure({
  webClientId:
    "1045679124479-aqeukkjlkf80aim1i44dlul46cgp3upn.apps.googleusercontent.com",
});

const useRegister = ({ }) => {
  const { getState, dispatch } = useReduxStore();
  const { fetch_token } = getState('auth');

  const genderInputRef = useRef(null);
  const dobInputRef = useRef(null);
  const passwordInputRef = useRef(null);
  const emailInputRef = useRef(null);
  const phoneInputRef = useRef(null);
  const firstnameRef = useRef(null);
  const usernameRef = useRef(null);
  const lastnameRef = useRef(null);

  const [keyboardVisible, setKeyboardVisible] = useState(false);
  const [socialDetail, setSocialDetail] = useState({});
  const [remember, setRemember] = useState(false);
  const [loader, setLoader] = useState(false);

  const emptyObject = Object.keys(socialDetail).length;

  const _handleSubmit = async values => {
    triggerHaptic()

    if (emptyObject) {
      setLoader(true);
      const value = { ...values, ...socialDetail };
      await dispatch(_socialLogin({ data: value }));
      setLoader(false);
    } else {
      setLoader(true);
      const deviceId = await DeviceInfo.getUniqueId();
      const deviceName = await DeviceInfo.getManufacturer();
      const res = await dispatch(
        _register({
          email: values.email,
          username: values.username,
          phone: values.phone,
          firstname: values.firstname,
          lastname: values.lastname,
          password: values.password,
          gender: values.gender,
          dateOfBirth: values.dob,
          deviceId,
          deviceName,
        }),
      );
      setLoader(false);
    }
  };

  useEffect(() => {
    // Keyboard show and hide listeners
    const showSubscription = Keyboard.addListener('keyboardDidShow', () =>
      setKeyboardVisible(true),
    );
    const hideSubscription = Keyboard.addListener('keyboardDidHide', () =>
      setKeyboardVisible(false),
    );

    return () => {
      showSubscription.remove();
      hideSubscription.remove();
    };
  }, []);

  const _handleGoogleLogin = async () => {
    dispatch(_globalLoader(true));
    try {
      await GoogleSignin.signOut();
      await GoogleSignin.hasPlayServices();
      const userInfo = await GoogleSignin.signIn();
      const name = userInfo?.data?.user?.name || ''; // Default to an empty string if name is undefined or null
      const nameParts = name.split(' '); // Split the name into parts (safe for empty string)

      // Handling different cases
      const firstName = nameParts[0] || ''; // First part of the name
      const lastName = nameParts[1] || ''; // Second part of the name (if exists)
      const data = {
        firstname: firstName,
        lastname: lastName,
        email: userInfo?.data?.user?.email,
        id: userInfo?.data?.user?.id,
        photo: userInfo?.data?.user?.photo,
        type: 'google',
      };
      const res = await dispatch(_userVerifier({ data }));
      // await dispatch(_socialLogin({ data }))
      res && setSocialDetail(data);
      dispatch(_globalLoader(false));
    } catch (error) {
      showToast(error.message);
      dispatch(_globalLoader(false));
    }
  };

  const fetchUserData = async accessToken => {
    dispatch(_globalLoader(true));
    try {
      // const accessTokenData = await AccessToken.getCurrentAccessToken(); // Android ke liye
      // const accessToken = accessTokenData?.accessToken;

      if (accessToken) {
        const response = await fetch(
          `https://graph.facebook.com/me?fields=id,name,email,picture&access_token=${accessToken}`,
        );
        const userInfo = await response.json();
        const name = userInfo?.name || '';
        const nameParts = name.split(' ');

        // Handling different cases
        const firstName = nameParts[0] || '';
        const lastName = nameParts[1] || '';
        const data = {
          firstname: firstName,
          lastname: lastName,
          email: userInfo?.email,
          id: userInfo?.id,
          photo: userInfo?.picture?.data?.url,
          type: 'facebook',
        };

        setSocialDetail(data);
        dispatch(_globalLoader(false));
      } else {
        showToast('Access Token not available');
        dispatch(_globalLoader(false));
      }
    } catch (error) {
      showToast(error.message);
      dispatch(_globalLoader(false));
    }
  };

  const _handleFacebookLogin = async () => {
    try {
      await LoginManager.logOut();
      const result = await LoginManager.logInWithPermissions([
        'public_profile',
        'email',
      ]);
      if (Platform.OS === 'ios') {
        const result = await AuthenticationToken.getAuthenticationTokenIOS();
      } else {
        const result = await AccessToken.getCurrentAccessToken();
        await fetchUserData(result.accessToken);
      }
    } catch (error) {
    }
  };

  const validationSchema = Yup.object({
    email: Yup.string()
      .email('Invalid email address') // Yup's built-in email validation
      .required('Email is required'), // Makes the field mandatory
    username: Yup.string().required('username is required'),
    phone: Yup.string()
      // .matches(/^[0-9]{11}$/, 'Phone number must be 11 digits') // Ensures 11 digit phone number
      .required('Phone number is required'),
    firstname: Yup.string().required('First name is required'),
    lastname: Yup.string().required('Last name is required'),
    password: Yup.string()
    .min(6, 'Password must be at least 6 characters')
    .required('Password is required'),
    dob: Yup.string().required('Date of birth is required'),
    gender: Yup.string().required('Please select your gender'),
  });

  const socialValidationSchema = Yup.object({
    email: Yup.string()
      .email('Invalid email address') // Yup's built-in email validation
      .required('Email is required'), // Makes the field mandatory
    phone: Yup.string()
      // .matches(/^[0-9]{11}$/, 'Phone number must be 11 digits') // Ensures 11 digit phone number
      .required('Phone number is required'),
  });

  const schema = emptyObject ? socialValidationSchema : validationSchema;

  return {
    _handleFacebookLogin,
    _handleGoogleLogin,
    _handleSubmit,
    setRemember,
    passwordInputRef,
    keyboardVisible,
    genderInputRef,
    phoneInputRef,
    emailInputRef,
    firstnameRef,
    socialDetail,
    dobInputRef,
    usernameRef,
    emptyObject,
    lastnameRef,
    remember,
    loader,
    schema,
  };
};

export default useRegister;
