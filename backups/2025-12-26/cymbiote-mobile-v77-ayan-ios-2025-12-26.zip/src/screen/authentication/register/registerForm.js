import React from 'react';
import {
  StyleSheet,
  View,
  KeyboardAvoidingView,
  Platform,
  TouchableOpacity,
} from 'react-native';
import {moderateScale, verticalScale} from 'react-native-size-matters';
import {globalStyle, margin, colors, font} from '@constant/contstant';
import CustomButton from '@materialComponent/customButton/customButton';
import CustomText from '@materialComponent/customText/customText';
import {navigate} from '@utils/navigationRef/navigationRef';
import {goBack} from '@utils/navigationRef/navigationRef';
import Content from '@materialComponent/content/content'; // Ensure this is a ScrollView
import AuthInput from '@component/input/authInput';
import useRegister from './useRegister';
import {Formik} from 'formik';
import Dropdown from '../../../component/dropdown/dropdown';
import {heightPercentageToDP} from 'react-native-responsive-screen';
import DatePicker from '../../../component/DatePicker/DatePicker';
import DropdownInput from '../../../component/dropdown/globalDropdown';

const RegisterForm = () => {
  const {
    _handleSubmit: submitLogin,
    _handleFacebookLogin,
    _handleGoogleLogin,
    passwordInputRef,
    genderInputRef,
    emailInputRef,
    phoneInputRef,
    firstnameRef,
    socialDetail,
    dobInputRef,
    usernameRef,
    lastnameRef,
    emptyObject,
    loader,
    schema,
    keyboardVisible,
  } = useRegister({});

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      style={{
        flex: 1,
      }}>
      <View
        style={[
          styles.mainView,
          {
            flexGrow: 1,
            paddingHorizontal: margin.horizontal,
            // paddingBottom: keyboardVisible
            //   ? verticalScale(10)
            //   : verticalScale(0),
          },
        ]}>
        <Formik
          initialValues={{
            email: socialDetail?.email,
            firstname: socialDetail?.firstname,
            lastname: socialDetail?.lastname,
          }}
          validationSchema={schema}
          onSubmit={values => submitLogin(values)}
          enableReinitialize>
          {({
            handleChange,
            handleSubmit,
            handleBlur,
            values,
            errors,
            touched,
            isValid,
            setFieldValue,
          }) => (
            <View
              style={[
                styles.mainView,
                // {
                //   paddingBottom: keyboardVisible
                //     ? heightPercentageToDP(10)
                //     : heightPercentageToDP(3),
                // },
              ]}>
              <AuthInput
                ref={firstnameRef}
                label="First name"
                placeholder="First Name"
                onChangeText={handleChange('firstname')}
                onBlur={handleBlur('firstname')}
                value={values.firstname}
                errorMessage={
                  touched.firstname && errors.firstname
                    ? errors.firstname
                    : null
                }
                returnKeyType="next"
                onSubmitEditing={() => lastnameRef.current?.focus()} // Focus next input
                marginTop={verticalScale(10)}
                editable={emptyObject}
              />
              <AuthInput
                ref={lastnameRef}
                label="Last name"
                placeholder="Last Name"
                onChangeText={handleChange('lastname')}
                onBlur={handleBlur('lastname')}
                value={values.lastname}
                errorMessage={
                  touched.lastname && errors.lastname ? errors.lastname : null
                }
                returnKeyType="next"
                onSubmitEditing={() => emailInputRef.current?.focus()} // Focus next input
                marginTop={verticalScale(10)}
                editable={emptyObject}
              />

              {/* Email Input */}
              <AuthInput
                ref={emailInputRef}
                label="Email"
                placeholder="Email Address"
                keyboardType="email-address"
                onChangeText={handleChange('email')}
                onBlur={handleBlur('email')}
                value={values.email}
                errorMessage={
                  touched.email && errors.email ? errors.email : null
                }
                returnKeyType="next"
                onSubmitEditing={() => usernameRef.current?.focus()} // Focus next input
                marginTop={verticalScale(10)}
                editable={emptyObject}
              />
              <AuthInput
                ref={usernameRef}
                label="Username"
                placeholder="User Name"
                onChangeText={handleChange('username')}
                onBlur={handleBlur('username')}
                value={values.username}
                errorMessage={
                  touched.username && errors.username ? errors.username : null
                }
                returnKeyType="next"
                onSubmitEditing={() => phoneInputRef.current?.focus()} // Focus next input
                marginTop={verticalScale(10)}
                hide={emptyObject}
              />

              <AuthInput
                ref={phoneInputRef}
                label="phone"
                placeholder="Phone Number"
                marginTop={verticalScale(10)}
                onChangeText={handleChange('phone')}
                onBlur={handleBlur('phone')}
                value={values.phone}
                returnKeyType="next"
                keyboardType={'phone-pad'}
                onSubmitEditing={() => passwordInputRef.current?.focus()} // Focus next input
                errorMessage={
                  touched.phone && errors.phone ? errors.phone : null
                }
                // phone={true}
              />

              {/* Password Input */}
              <AuthInput
                ref={passwordInputRef}
                label={emptyObject ? 'Password (optional)' : 'Password'}
                placeholder="Password"
                secureTextEntry
                marginTop={verticalScale(10)}
                onChangeText={handleChange('password')}
                onBlur={handleBlur('password')}
                value={values.password}
                returnKeyType="done"
                onSubmitEditing={handleSubmit} // Submit form
                errorMessage={
                  touched.password && errors.password ? errors.password : null
                }
                // hide={emptyObject}
              />

              <DropdownInput
                ref={genderInputRef}
                value={values.gender}
                onSelect={handleChange('gender')}
                marginTop={verticalScale(10)}
                backgroundColor={'white'}
                placeholder="Select Gender"
                options={[
                  {id: 'Male', value: 'Male'},
                  {id: 'Female', value: 'Female'},
                ]}
              />

              <DatePicker
                ref={dobInputRef}
                value={values.dob}
                onChange={date => setFieldValue('dob', date)}
                marginTop={verticalScale(10)}
                placeholder={"Enter DOB"}
              />

              {/* Remember Me */}
              {/* <View style={[globalStyle.space_between, { marginTop: verticalScale(10) }]}>
                                <View style={globalStyle.row}>
                                    <Checkbox
                                        onPress={() => setRemember(!remember)}
                                        status={remember ? 'checked' : 'unchecked'}
                                    />
                                    <CustomText
                                        fontSize={moderateScale(14)}
                                        color={colors.light_theme.gray}
                                        // style={{ marginLeft: 0 }}
                                        text="Remember me"
                                    />
                                </View>
                                <CustomText
                                    fontSize={moderateScale(14)}
                                    color={colors.light_theme.gray}
                                    textAlign="right"
                                    text="Forgot Password"
                                />
                            </View> */}

              {/* Submit Button */}
              <CustomButton
                marginTop={verticalScale(40)}
                text={emptyObject ? 'Complete' : 'Register'}
                onPress={handleSubmit}
                loader={loader}
                disabled={!isValid}
                backgroundColor={
                  !isValid ? colors.light_theme.rgbaTheme : false
                }
              />
            </View>
          )}
        </Formik>
        {/* Footer */}
      </View>
    </KeyboardAvoidingView>
  );
};

export default RegisterForm;

const styles = StyleSheet.create({
  mainView: {
    // flex: 1,
    paddingBottom: heightPercentageToDP(3),
  },
  footer: {
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'center',
    marginBottom: verticalScale(30),
    marginTop: verticalScale(20),
  },
});
