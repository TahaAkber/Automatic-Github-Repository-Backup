import React from 'react';
import { StyleSheet, View, KeyboardAvoidingView, Platform } from 'react-native';
import { moderateScale, verticalScale } from 'react-native-size-matters';
import { WH, margin, colors, font } from '@constant/contstant';
import CustomButton from '@materialComponent/customButton/customButton';
import CustomText from '@materialComponent/customText/customText';
import Content from '@materialComponent/content/content'; // Ensure this is a ScrollView
import useSocialRegister from './useSocialRegister.js';
import OtpSvg from "@assets/images/set_password.svg"
import AuthInput from '@component/input/authInput';
import { Formik } from 'formik';
import CustomImage from '@materialComponent/image/image.js';


const SocialRegisterForm = ({ route }) => {
    const { _handleSubmit: submit, loader, validationSchema, createPasswordRef, phoneNoRef } = useSocialRegister({ route });

    return (
        <KeyboardAvoidingView
            behavior={Platform.OS === 'ios' ? 'padding' : undefined}
            style={{ flex: 1 }}
        >
            <Content
                contentContainerStyle={[
                    styles.mainView,
                    { flexGrow: 1, paddingHorizontal: margin.horizontal },
                ]}
            >
                <Formik
                    initialValues={{
                        email: '',
                    }}
                    validationSchema={validationSchema}
                    onSubmit={(values) => submit(values)}
                >
                    {({
                        handleChange,
                        handleBlur,
                        handleSubmit,
                        values,
                        errors,
                        touched,
                        isValid
                    }) => (
                        <View style={styles.mainView}>
                            <View style={styles.headerContainer}>
                                <CustomImage source={{ uri: route?.params?.data?.photo }} style={{ width: WH.width(25), aspectRatio: 1, borderRadius: 180 }} />
                                <View style={styles.titleContainer}>
                                    <CustomText center fontFamily={font.bold} text={"Welcome"} style={styles.titleText} />
                                </View>
                                <View style={styles.subtitleContainer}>
                                    <CustomText
                                        center
                                        fontSize={moderateScale(12)}
                                        fontFamily={font.light}
                                        text={route?.params?.data?.firstname + " " + route?.params?.data?.lastname}
                                    />
                                </View>

                                <View style={{ width: "100%" }}>
                                    {/* Email Input */}
                                    <AuthInput
                                        ref={phoneNoRef}
                                        label="phone"
                                        placeholder="Phone Number"
                                        keyboardType="phone-pad"
                                        onChangeText={handleChange('phone')}
                                        onBlur={handleBlur('phone')}
                                        value={values.phone}
                                        returnKeyType="next"
                                        onSubmitEditing={() => phoneNoRef.current?.focus()}
                                        errorMessage={touched.phone && errors.phone ? errors.phone : null}
                                        marginTop={verticalScale(20)}
                                        phone={true}
                                    />
                                    <AuthInput
                                        ref={createPasswordRef}
                                        label="password"
                                        placeholder="Create password (optional)"
                                        onChangeText={handleChange('password')}
                                        onBlur={handleBlur('password')}
                                        value={values.password}
                                        returnKeyType="next"
                                        onSubmitEditing={handleSubmit}
                                        errorMessage={touched.password && errors.password ? errors.password : null}
                                        marginTop={verticalScale(10)}
                                        secureTextEntry={true}
                                    />

                                </View>
                            </View>

                            <CustomButton
                                onPress={handleSubmit}
                                backgroundColor={!isValid ? colors.light_theme.rgbaTheme : false}
                                disabled={!isValid}
                                loader={loader}
                                buttonStyle={{ marginBottom: WH.height(3) }}
                                text="Continue"
                            />
                        </View>
                    )}
                </Formik>
            </Content>
        </KeyboardAvoidingView>
    );
};

export default SocialRegisterForm;

const styles = StyleSheet.create({
    mainView: {
        flex: 1,
        justifyContent: "space-between"
    },
    footer: {
        position: 'absolute',
        bottom: 20,
        justifyContent: 'center',
        alignSelf: 'center',
        alignItems: 'center',
        flexDirection: 'row',
    },
    headerContainer: {
        // marginHorizontal: margin.horizontal,
        justifyContent: "center",
        alignItems: "center",
        marginTop: WH.height(15),
    },
    titleContainer: {
        width: "100%",
        justifyContent: "center",
        alignItems: "center",
        marginTop: WH.height(2),
    },
    subtitleContainer: {
        width: "70%",
        justifyContent: "center",
        alignItems: "center",
        marginTop: verticalScale(5),
    },
    titleText: {
        fontFamily: font.bold,
        fontSize: moderateScale(22),
        color: "black",
        width: "100%",
        // backgroundColor:"red"
    },
    headerContainer: {
        // marginHorizontal: margin.horizontal,
        justifyContent: "center",
        alignItems: "center",
        marginTop: WH.height(15),
    },
});
