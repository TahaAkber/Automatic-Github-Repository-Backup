import { StyleSheet, View, KeyboardAvoidingView, Platform, TouchableOpacity, Dimensions } from 'react-native';
import { moderateScale, verticalScale } from 'react-native-size-matters';
import { globalStyle, margin, colors, font, WH } from '@constant/contstant';
import CustomButton from '@materialComponent/customButton/customButton';
import CustomText from '@materialComponent/customText/customText';
import { navigate } from '@utils/navigationRef/navigationRef';
import Content from '@materialComponent/content/content'; // Ensure this is a ScrollView
import AuthInput from '@component/input/authInput';
import Facebook from "@assets/images/facebook.svg"
import Apple from "@assets/images/apple.svg"
import Google from "@assets/images/google.svg"
import useLogin from './useLogin';
import { Formik } from 'formik';
import React from 'react';
import { heightPercentageToDP } from 'react-native-responsive-screen';

const { width, fontScale } = Dimensions.get("screen")

const LoginForm = ({ refRBSheet }) => {
    const {
        _handleSubmit: submitLogin,
        _handleFacebookLogin,
        _handleGoogleLogin,
        validationSchema,
        passwordInputRef,
        keyboardVisible,
        emailInputRef,
        loader,
    } = useLogin({});


    return (
        <KeyboardAvoidingView
            behavior={Platform.OS === 'ios' ? 'padding' : undefined}
            style={{ flex: 1 }}
        >
            <Content
                contentContainerStyle={[
                    styles.mainView,
                    { flexGrow: 1, paddingHorizontal: margin.horizontal },
                ]}
            >

                <Formik
                    initialValues={{
                        email: '',
                        password: '',
                    }}
                    validationSchema={validationSchema}
                    onSubmit={(values) => submitLogin(values)}
                >
                    {({
                        handleChange,
                        handleBlur,
                        handleSubmit,
                        values,
                        errors,
                        touched,
                        isValid
                    }) => (
                        <View style={styles.mainView}>


                            {/* Email Input */}
                            <AuthInput
                                ref={emailInputRef}
                                label="Email or username"
                                placeholder="Enter email or username"
                                keyboardType="email-address"
                                onChangeText={handleChange('email')}
                                onBlur={handleBlur('email')}
                                value={values.email}
                                errorMessage={touched.email && errors.email ? errors.email : null}
                                returnKeyType="next"
                                onSubmitEditing={() => passwordInputRef.current?.focus()} // Focus next input

                            />

                            {/* Password Input */}
                            <AuthInput
                                ref={passwordInputRef}
                                label="Password"
                                placeholder="Password"
                                secureTextEntry
                                marginTop={verticalScale(10)}
                                onChangeText={handleChange('password')}
                                onBlur={handleBlur('password')}
                                value={values.password}
                                returnKeyType="done"
                                onSubmitEditing={handleSubmit} // Submit form
                                errorMessage={touched.password && errors.password ? errors.password : null}
                            />

                            {/* Remember Me */}
                            <View style={[globalStyle.space_between, { marginTop: verticalScale(10), justifyContent: "flex-end" }]}>
                                {/* <TouchableOpacity onPress={() =>  navigate("ForgotPassword")}> */}
                                <TouchableOpacity onPress={() => navigate("ForgotPassword", { email: true })}>
                                {/* <TouchableOpacity onPress={() => refRBSheet?.current?.open()}> */}
                                    <CustomText
                                        fontSize={moderateScale(14)}
                                        color={colors.light_theme.gray}
                                        textAlign="right"
                                        text="Forgot Password"
                                    />
                                </TouchableOpacity>
                            </View>

                            {/* Submit Button */}
                            <CustomButton
                                marginTop={verticalScale(20)}
                                text="Log In"
                                onPress={handleSubmit}
                                loader={loader}
                                disabled={!isValid}
                                backgroundColor={!isValid ? colors.light_theme.rgbaTheme : false}
                            />
                            {!keyboardVisible &&
                                <>
                                    <View style={[globalStyle.space_between, { marginTop: WH.height(2) }]}>
                                        <View style={{ height: 0.8, width: "40%", backgroundColor: "#D9DDDF" }} />
                                        <CustomText
                                            fontSize={moderateScale(14)}
                                            // marginTop={verticalScale(20)}
                                            color={colors.light_theme.gray}
                                            textAlign="center"
                                            text="Or"
                                        />
                                        <View style={{ height: 0.8, width: "40%", backgroundColor: "#D9DDDF" }} />
                                    </View>
                                    <View >
                                        <CustomButton
                                            backgroundColor="white"
                                            outline={true}
                                            marginTop={WH.height(2)}
                                            onPress={_handleGoogleLogin}
                                            ImageComponent={Google}
                                            text={"Continue with Google"}
                                            textStyle={{ color: "black", fontFamily: font.medium, fontSize: fontScale * 15 }}
                                            ImageComponentSize={width * 0.06}
                                            // imageComponentStyle={{ left: '16%' }}
                                            imageComponentStyle={{marginRight:  "3%"}}
                                        />
                                        {/* <CustomButton
                                            backgroundColor="white"
                                            outline={true}
                                            marginTop={WH.height(1.5)}
                                            onPress={_handleFacebookLogin}
                                            ImageComponent={Facebook}
                                            text={"Continue with Facebook"}
                                            imageComponentStyle={{ left: '14%' }}
                                            textStyle={{ color: "black", fontFamily: font.medium, fontSize: fontScale * 15 }}
                                            ImageComponentSize={width * 0.06}
                                        /> */}


                                        {/* <CustomButton
                                            backgroundColor="white"
                                            outline={true}
                                            marginTop={WH.height(1.5)}
                                            onPress={_handleGoogleLogin}
                                            ImageComponent={Apple}
                                            text={"Continue with Apple"}
                                            textStyle={{ color: "black", fontFamily: font.medium }}
                                        /> */}

                                    </View>
                                </>
                            }
                        </View>
                    )}
                </Formik>
            </Content>
        </KeyboardAvoidingView>
    );
};

export default LoginForm;

const styles = StyleSheet.create({
    mainView: {
        // flex: 1,
        marginBottom : heightPercentageToDP(3)
    },
    footer: {
        position: 'absolute',
        bottom: 20,
        justifyContent: 'center',
        alignSelf: 'center',
        alignItems: 'center',
        flexDirection: 'row',
    },
    skipText: {
        fontFamily: font.bold,
        fontSize: moderateScale(25),
        color: "black",
    },
});
