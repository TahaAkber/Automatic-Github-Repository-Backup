import React from 'react';
import Container from '@materialComponent/container/container';
import LoginForm from './loginForm';
import BackOverLay from '@materialComponent/backOverlay/backOverlay';
import SnakeWave from '../../../materialComponent/snakeWave/snakeWave';
import { font, globalStyle, margin, WH } from '../../../constant/contstant';
import { StyleSheet, View } from 'react-native';
import CustomText from '../../../materialComponent/customText/customText';
import { moderateScale, verticalScale } from 'react-native-size-matters';
import AppIcon from "@assets/images/app_icon.svg"
import { useIsFocused } from '@react-navigation/native';

const Login = () => {
    const isFocused = useIsFocused()
    return (
        <Container
            barColor={"transparent"}
            translucent={true}
            isFocused={isFocused}
            dark
        >
            <SnakeWave />
            <View style={[{ marginHorizontal: margin.horizontal, justifyContent: "center", alignItems: "center", marginTop: globalStyle.paddingVertical.paddingVertical }]}>
                <AppIcon width={WH.height(6)} height={WH.height(6)} />
                <View style={[{ width: "80%", justifyContent: "center", alignItems: "center", marginTop: WH.height(2) }]}>
                    <CustomText center fontFamily={font.bold} text={"Sign in to your Account"} style={styles.skipText} />
                </View>
                <View style={[{ width: "80%", justifyContent: "center", alignItems: "center", marginTop: verticalScale(10) }]}>
                    <CustomText center fontSize={moderateScale(12)} fontFamily={font.light} text={"Enter your email and password to log in "} />
                </View>
            </View>
            <LoginForm />
            {/* <BackOverLay /> */}
        </Container>
    );
};

export default Login;

const styles = StyleSheet.create({
    skipText: {
        fontFamily: font.bold,
        fontSize: moderateScale(25),
        color: "black",
    },
});
