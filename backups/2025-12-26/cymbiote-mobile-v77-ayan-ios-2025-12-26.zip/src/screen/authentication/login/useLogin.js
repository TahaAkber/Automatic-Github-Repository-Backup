import {useEffect, useRef, useState} from 'react';
import {GoogleSignin} from '@react-native-google-signin/google-signin';
import {showToast} from '@helper/reUsableMethod/reUsableMethod';
import {_getStores} from '@redux/actions/merchant/merchant';
import {_globalLoader} from '@redux/actions/common/common';
import useReduxStore from '@utils/hooks/useReduxStore';
import {_login, _socialLogin} from '@redux/actions/auth/auth';
import DeviceInfo from 'react-native-device-info';
import {Keyboard, Platform, Vibration} from 'react-native';
import {
  AccessToken,
  AuthenticationToken,
  LoginManager,
} from 'react-native-fbsdk-next';
import * as Yup from 'yup';
import {navigate} from '@utils/navigationRef/navigationRef';
import {gmailAuthError} from '../../../utils/errors/errors';
import {triggerHaptic} from '../../../utils/haptic/haptic';
import {useIsFocused} from '@react-navigation/native';

// GoogleSignin.configure({
//     webClientId: '937096976179-aklkis433crc8ujie6rc6e9fogepg3tj.apps.googleusercontent.com',
//     offlineAccess: true,  // ✅ Required to get a refresh token
//     scopes: [
//         "https://www.googleapis.com/auth/userinfo.email",
//         "https://www.googleapis.com/auth/userinfo.profile",
//         "https://www.googleapis.com/auth/gmail.readonly",
//     ],
// });

const useLogin = ({}) => {
  const {getState, dispatch} = useReduxStore();
  const {fetch_token} = getState('auth');
  const isFocused = useIsFocused();

  const emailInputRef = useRef(null);
  const passwordInputRef = useRef(null);

  const [keyboardVisible, setKeyboardVisible] = useState(false);
  const [remember, setRemember] = useState(false);
  const [loader, setLoader] = useState(false);

  const _handleSubmit = async values => {
    triggerHaptic();
    setLoader(true);
    const deviceId = await DeviceInfo.getUniqueId();
    const deviceName = await DeviceInfo.getManufacturer();
    const res = await dispatch(
      _login({
        email: values.email,
        password: values.password,
        deviceId,
        deviceName,
        remember,
      }),
    );
    setLoader(false);
  };

  useEffect(() => {
    // Keyboard show and hide listeners
    const showSubscription = Keyboard.addListener('keyboardDidShow', () =>
      setKeyboardVisible(true),
    );
    const hideSubscription = Keyboard.addListener('keyboardDidHide', () =>
      setKeyboardVisible(false),
    );

    return () => {
      showSubscription.remove();
      hideSubscription.remove();
    };
  }, []);

  useEffect(() => {
    GoogleSignin.configure({
      webClientId:
        '1045679124479-aqeukkjlkf80aim1i44dlul46cgp3upn.apps.googleusercontent.com',
      offlineAccess: true,
      scopes: [
        'https://www.googleapis.com/auth/gmail.readonly',
        'https://www.googleapis.com/auth/user.gender.read',
        'https://www.googleapis.com/auth/user.birthday.read',
      ],
    });
  }, []); // Empty array ensures this runs only once

  async function getPeopleProfile(accessToken) {
    const res = await fetch(
      'https://people.googleapis.com/v1/people/me?personFields=genders,birthdays',
      {headers: {Authorization: `Bearer ${accessToken}`}},
    );
    if (!res.ok) {
      const t = await res.text();
      throw new Error(`People API ${res.status}: ${t}`);
    }
    const people = await res.json();

    // gender (first available)
    const gender = people?.genders?.[0]?.value || null;

    // birthday: Google kabhi multiple/partial date bhejta hai
    // try to prefer ACCOUNT source, else first
    const bdays = people?.birthdays || [];
    const accountBday =
      bdays.find(b => b?.metadata?.source?.type === 'ACCOUNT') || bdays[0];

    const date = accountBday?.date || null; // {year?, month, day}
    // Normalize to string (year optional)
    const birthday = date
      ? [
          date.year,
          String(date.month).padStart(2, '0'),
          String(date.day).padStart(2, '0'),
        ]
          .filter(Boolean)
          .join('-')
      : null;

    const d1 = new Date(birthday + 'T00:00:00Z').toISOString();

    const toCap = s =>
      s ? s.charAt(0).toUpperCase() + s.slice(1).toLowerCase() : null;

    // usage with People API value
    const genderRaw = gender ?? null; // e.g., 'male', 'FEMALE', 'other'
    const genderr = toCap(genderRaw); // 'Male', 'Female', 'Other'

    return {gender: genderr, birthday: d1};
  }

  const _handleGoogleLogin = async () => {
    // try {
    //   await GoogleSignin.hasPlayServices();
    //   const userInfo = await GoogleSignin.signIn();
    // } catch (error) {
    //   alert("error =>", error?.message)
    // }
    try {
      triggerHaptic();
      // dispatch(_globalLoader(true));

      await GoogleSignin.hasPlayServices();
      const userInfo = await GoogleSignin.signIn();
      const {accessToken} = await GoogleSignin.getTokens();
      let gender = null,
        birthday = null;
      try {
        const p = await getPeopleProfile(accessToken);
        gender = p.gender;
        birthday = p.birthday; // 'YYYY-MM-DD' ya 'MM-DD'
      } catch (e) {
       
        // optional: silently continue
      }
      const name = userInfo?.data?.user?.name || ''; // Default to an empty string if name is undefined or null
      const nameParts = name.split(' '); // Split the name into parts (safe for empty string)

      // Handling different cases
      const firstName = nameParts[0] || ''; // First part of the name
      const lastName = nameParts[1] || ''; // Second part of the name (if exists)
      const data = {
        firstname: firstName,
        lastname: lastName,
        email: userInfo?.data?.user?.email,
        id: userInfo?.data?.user?.id,
        photo: userInfo?.data?.user?.photo,
        gender,
        dob: birthday,
        type: 'google',
        isLogin: true,
      };

      try {
        await dispatch(_socialLogin({data}));
        dispatch(_globalLoader(false));
        GoogleSignin.signOut();
      } catch (error) {
        
        if (error.message == gmailAuthError && data?.firstname) {
          navigate('SocialRegister', {data});
          dispatch(_globalLoader(false));
          GoogleSignin.signOut();
        } else {
          // handleButtonPress({})
          showToast(data?.firstname ? error.message : 'Invalid Attempt');
          dispatch(_globalLoader(false));
          GoogleSignin.signOut();
        }
      }
    } catch (error) {
      if (!error?.message?.includes('Token')) {
        showToast(error.message);
      }
    }
  };

  const fetchUserData = async accessToken => {
    try {
      if (accessToken) {
        const response = await fetch(
          `https://graph.facebook.com/me?fields=id,name,email,picture&access_token=${accessToken}`,
        );
        const userInfo = await response.json();
        const name = userInfo?.name || '';
        const nameParts = name.split(' ');

        // Handling different cases
        const firstName = nameParts[0] || '';
        const lastName = nameParts[1] || '';
        const data = {
          firstname: firstName,
          lastname: lastName,
          email: userInfo?.email,
          id: userInfo?.id,
          photo: userInfo?.picture?.data?.url,
          type: 'facebook',
          isLogin: true,
        };

        setSocialDetail(data);
        await dispatch(_socialLogin({data}));
        dispatch(_globalLoader(false));
      } else {
        showToast('Access Token not available');
        dispatch(_globalLoader(false));
      }
    } catch (error) {
      if (
        error.message === 'No account is associated with this.' &&
        data?.firstname
      ) {
        navigate('SocialRegister', {data});
        dispatch(_globalLoader(false));
      } else {
        // handleButtonPress({})
        showToast(data?.firstname ? error.message : 'Invalid Attempt');
        dispatch(_globalLoader(false));
      }
    }
  };

  const _handleFacebookLogin = async () => {
    // dispatch(_globalLoader(true));
    try {
      // await LoginManager.logOut();
      const result = await LoginManager.logInWithPermissions([
        'public_profile',
        'email',
      ]);
      // if (Platform.OS === 'ios') {
      //   const result = await AuthenticationToken.getAuthenticationTokenIOS();
      //   console.log(result?.authenticationToken);
      //   dispatch(_globalLoader(false));
      // } else {
      //   const result = await AccessToken.getCurrentAccessToken();
      //   dispatch(_globalLoader(false));
      //   await fetchUserData(result.accessToken);
      // }
    } catch (error) {
      // dispatch(_globalLoader(false));
      console.log(error);
    }
  };

  const validationSchema = Yup.object({
    email: Yup.string()
      .required('Email or username is required')
      .test(
        'email-or-username',
        'Please enter a valid email or username',
        value => {
          // Check if it's a valid email OR if it's a valid username
          // You can customize the username pattern as needed
          const emailRegex = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i;
          const usernameRegex = /^[a-zA-Z0-9_]+$/; // Example username pattern
          return emailRegex.test(value) || usernameRegex.test(value);
        },
      ),
    password: Yup.string()
      .required('Password is required')
      .min(6, 'Password must be at least 6 characters'),
  });

  return {
    _handleFacebookLogin,
    _handleGoogleLogin,
    _handleSubmit,
    setRemember,
    passwordInputRef,
    validationSchema,
    keyboardVisible,
    emailInputRef,
    remember,
    loader,
    isFocused,
  };
};

export default useLogin;
