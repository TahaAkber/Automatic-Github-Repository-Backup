import React from 'react';
import { StyleSheet, View, KeyboardAvoidingView, Platform, TouchableOpacity } from 'react-native';
import { moderateScale, verticalScale } from 'react-native-size-matters';
import { globalStyle, margin, colors, font, WH } from '@constant/contstant';
import CustomButton from '@materialComponent/customButton/customButton';
import CustomText from '@materialComponent/customText/customText';
import Content from '@materialComponent/content/content'; // Ensure this is a ScrollView
import useResetPassword from './useResetPassword.js';
import AuthInput from '@component/input/authInput';
import OtpSvg from "@assets/images/set_password.svg"
import { Formik } from 'formik';


const ResetPasswordForm = ({ route }) => {
    const {
        _handleSubmit: submit,
        loader,
        validationSchema,
        confirmPasswordInputRef,
        passwordInputRef
    } = useResetPassword({ route });

    return (
        <KeyboardAvoidingView
            behavior={Platform.OS === 'ios' ? 'padding' : undefined}
            style={{ flex: 1 }}
        >
            <Content
                contentContainerStyle={[
                    styles.mainView,
                    { flexGrow: 1, paddingHorizontal: margin.horizontal },
                ]}
            >
                <Formik
                    initialValues={{
                        email: '',
                        password: '',
                    }}
                    validationSchema={validationSchema}
                    onSubmit={(values) => submit(values)}
                >
                    {({
                        handleChange,
                        handleBlur,
                        handleSubmit,
                        values,
                        errors,
                        touched,
                        isValid
                    }) => (
                        <View style={styles.mainView}>
                            <View style={styles.headerContainer}>
                                <OtpSvg width={WH.height(8)} height={WH.height(8)} />
                                <View style={styles.titleContainer}>
                                    <CustomText center fontFamily={font.bold} text={"Create New Password"} style={styles.titleText} />
                                </View>
                                <View style={styles.subtitleContainer}>
                                    <CustomText
                                        center
                                        fontSize={moderateScale(12)}
                                        fontFamily={font.light}
                                        text={"New Password and Confirm Password must match."}
                                    />
                                </View>
                                <View style={{ width: "100%" }}>
                                    <AuthInput
                                        onChangeText={handleChange('password')}
                                        onBlur={handleBlur('password')}
                                        marginTop={verticalScale(20)}
                                        errorMessage={touched.password && errors.password ? errors.password : null}
                                        onSubmitEditing={() => confirmPasswordInputRef.current?.focus()}
                                        placeholder="Create Password"
                                        value={values.password}
                                        ref={passwordInputRef}
                                        secureTextEntry={true}
                                        returnKeyType="next"
                                        label="Password"
                                    />
                                </View>

                                <View style={{ width: "100%" }}>
                                    <AuthInput
                                        onChangeText={handleChange('confirmPassword')}
                                        onBlur={handleBlur('confirmPassword')}
                                        onSubmitEditing={handleSubmit}
                                        marginTop={verticalScale(10)}
                                        ref={confirmPasswordInputRef}
                                        errorMessage={touched.confirmPassword && errors.confirmPassword ? errors.confirmPassword : null}
                                        value={values.confirmPassword}
                                        placeholder="Please Confirm Your Password"
                                        label="Confirm Password"
                                        secureTextEntry={true}
                                        returnKeyType="next"
                                    />
                                </View>
                            </View>


                            {/* Submit Button */}
                            <CustomButton
                                marginBottom={verticalScale(20)}
                                onPress={handleSubmit}
                                backgroundColor={!isValid ? colors.light_theme.rgbaTheme : false}
                                disabled={!isValid}
                                loader={loader}
                                buttonStyle={{ marginBottom: WH.height(3) }}
                                text="Change Password"
                            />
                        </View>
                    )}
                </Formik>
            </Content>
        </KeyboardAvoidingView>
    );
};

export default ResetPasswordForm;

const styles = StyleSheet.create({
    mainView: {
        flex: 1,
        justifyContent: "space-between"
    },
    footer: {
        justifyContent: 'center',
        alignItems: 'center',
        position: 'absolute',
        flexDirection: 'row',
        alignSelf: 'center',
        bottom: 20,
    },
    headerContainer: {
        // marginHorizontal: margin.horizontal,
        justifyContent: "center",
        alignItems: "center",
        marginTop: WH.height(15),
    },
    titleContainer: {
        width: "100%",
        justifyContent: "center",
        alignItems: "center",
        marginTop: WH.height(2),
    },
    subtitleContainer: {
        width: "100%",
        justifyContent: "center",
        alignItems: "center",
        marginTop: verticalScale(5),
    },
    titleText: {
        fontFamily: font.bold,
        fontSize: moderateScale(22),
        color: "black",
        width: "100%",
        // backgroundColor:"red"
    },
});
