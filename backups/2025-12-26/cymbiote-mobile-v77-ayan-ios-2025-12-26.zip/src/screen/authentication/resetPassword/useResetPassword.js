import { _login, _socialLogin, _sendOtp } from '@redux/actions/auth/auth';
import { _getStores } from '@redux/actions/merchant/merchant';
import { _globalLoader } from '@redux/actions/common/common';
import { _resetPassword } from '@redux/actions/auth/auth';
import useReduxStore from '@utils/hooks/useReduxStore';
import { useRef, useState } from 'react';
import * as Yup from 'yup';
import { CommonActions, useNavigation } from '@react-navigation/native';
import { navigate } from '../../../utils/navigationRef/navigationRef';


const useResetPassword = ({ route }) => {
    const { getState, dispatch } = useReduxStore()
    const { fetch_token } = getState("auth")
    const navigation = useNavigation()

    const confirmPasswordInputRef = useRef(null)
    const [loader, setLoader] = useState(false)
    const passwordInputRef = useRef(null)

    const validationSchema = Yup.object({
        password: Yup.string()
            .min(6, 'Password must be at least 6 characters')
            .required('Password is required'),
        confirmPassword: Yup.string()
            .oneOf([Yup.ref('password'), null], 'Passwords must match')
            .required('Confirm password is required'),
    });

    const handleSuccess = () => {
        navigation.dispatch(
            CommonActions.reset({
                index: 0,
                routes: [{ name: 'Login' }], // Keep only the Login screen in the stack
            })
        );
    }

    const _handleSubmit = async (values) => {
        setLoader(true)
        const res = await dispatch(_resetPassword({ identifier: route?.params?.data.identifier, password: values.password, method: handleSuccess }))
        setLoader(false)
        if (res) {
            navigate("Success", { method: handleSuccess, title: "Password Created", subTitle: "Your password has been created" })
        }
    }

    return {
        _handleSubmit,
        confirmPasswordInputRef,
        validationSchema,
        passwordInputRef,
        loader
    };
};

export default useResetPassword;
