import { _login, _socialLogin, _sendOtp } from '@redux/actions/auth/auth';
import { _getStores } from '@redux/actions/merchant/merchant';
import { _globalLoader } from '@redux/actions/common/common';
import useReduxStore from '@utils/hooks/useReduxStore';
import { useState } from 'react';
import * as Yup from 'yup';
import DeviceInfo from 'react-native-device-info';


const useForgotPassword = ({ route }) => {
    const { getState, dispatch } = useReduxStore()
    const { fetch_token } = getState("auth")
    const [loader, setLoader] = useState(false)

    const validationSchema = Yup.object({
        email: Yup.string()
            .email('Invalid email format') // Ensures the input is a valid email
            .required('Email is required'), // Ensures email field is not empty
    });

    const _handleSubmit = async (values) => {
        setLoader(true)
        const device_id = await DeviceInfo.getUniqueId()
        const device_name = await DeviceInfo.getManufacturer()
        const res = await dispatch(_sendOtp({ params: { identifier: values.email, forgotPassword: true, device_id, device_name }, identifier: values.email, }))
        setLoader(false)
    }

    return {
        _handleSubmit,
        validationSchema,
        loader
    };
};

export default useForgotPassword;
