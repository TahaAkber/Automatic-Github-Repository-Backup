import TopBackOverLay from '@materialComponent/backOverlay/topBackOverlay';
import Container from '@materialComponent/container/container';
import ForgotPasswordForm from './forgotPasswordForm';
import React from 'react';
import SnakeWave from '../../../materialComponent/snakeWave/snakeWave';
import {useIsFocused} from '@react-navigation/native';

const ForgotPassword = ({route}) => {
  const isFocused = useIsFocused();
  return (
    <Container
      barColor={'transparent'}
      translucent={true}
      isFocused={isFocused}
      dark>
      <SnakeWave />
      <ForgotPasswordForm route={route} />
      <TopBackOverLay />
    </Container>
  );
};

export default ForgotPassword;
