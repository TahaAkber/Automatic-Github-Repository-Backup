import React from 'react';
import { StyleSheet, View, KeyboardAvoidingView, Platform } from 'react-native';
import { moderateScale, verticalScale } from 'react-native-size-matters';
import { WH, margin, colors, font } from '@constant/contstant';
import CustomButton from '@materialComponent/customButton/customButton';
import CustomText from '@materialComponent/customText/customText';
import Content from '@materialComponent/content/content'; // Ensure this is a ScrollView
import useForgotPassword from './useForgotPassword.js';
import OtpSvg from "@assets/images/set_password.svg"
import AuthInput from '@component/input/authInput';
import { Formik } from 'formik';


const ForgotPasswordForm = ({ route }) => {
    const { _handleSubmit: submit, loader, validationSchema } = useForgotPassword({});

    return (
        <KeyboardAvoidingView
            behavior={Platform.OS === 'ios' ? 'padding' : undefined}
            style={{ flex: 1 }}
        >
            <Content
                contentContainerStyle={[
                    styles.mainView,
                    { flexGrow: 1, paddingHorizontal: margin.horizontal },
                ]}
            >
                <Formik
                    initialValues={{
                        email: '',
                    }}
                    validationSchema={validationSchema}
                    onSubmit={(values) => submit(values)}
                >
                    {({
                        handleChange,
                        handleBlur,
                        handleSubmit,
                        values,
                        errors,
                        touched,
                        isValid
                    }) => (
                        <View style={styles.mainView}>
                            <View style={styles.headerContainer}>
                                <OtpSvg width={WH.height(8)} height={WH.height(8)} />
                                <View style={styles.titleContainer}>
                                    <CustomText center fontFamily={font.bold} text={route?.params?.email ? "Enter Your Email" : "Enter Your Number"} style={styles.titleText} />
                                </View>
                                <View style={styles.subtitleContainer}>
                                    <CustomText
                                        center
                                        fontSize={moderateScale(12)}
                                        fontFamily={font.light}
                                        text={route?.params?.email ? "Enter your email address which is associate with app" : "Enter your mobile number which is associate with app"}
                                    />
                                </View>

                                <View style={{ width: "100%" }}>
                                    {/* Email Input */}
                                    {route?.params?.email ?
                                        <AuthInput
                                            label="Email"
                                            placeholder="Example@gmail.com"
                                            keyboardType="email-address"
                                            onChangeText={handleChange('email')}
                                            onBlur={handleBlur('email')}
                                            value={values.email}
                                            returnKeyType="next"
                                            onSubmitEditing={handleSubmit}
                                            errorMessage={touched.email && errors.email ? errors.email : null}
                                            marginTop={verticalScale(20)}
                                        /> :
                                        <AuthInput
                                            label="Email"
                                            placeholder="Example@gmail.com"
                                            keyboardType="email-address"
                                            onChangeText={handleChange('email')}
                                            onBlur={handleBlur('email')}
                                            value={values.email}
                                            returnKeyType="next"
                                            onSubmitEditing={handleSubmit}
                                            errorMessage={touched.email && errors.email ? errors.email : null}
                                            marginTop={verticalScale(20)}
                                            phone={true}
                                        />
                                    }

                                </View>
                            </View>

                            <CustomButton
                                onPress={handleSubmit}
                                backgroundColor={!isValid ? colors.light_theme.rgbaTheme : false}
                                disabled={!isValid}
                                loader={loader}
                                buttonStyle={{ marginBottom: WH.height(3) }}
                                text="Next"
                            />
                        </View>
                    )}
                </Formik>
            </Content>
        </KeyboardAvoidingView>
    );
};

export default ForgotPasswordForm;

const styles = StyleSheet.create({
    mainView: {
        flex: 1,
        justifyContent: "space-between"
    },
    footer: {
        position: 'absolute',
        bottom: 20,
        justifyContent: 'center',
        alignSelf: 'center',
        alignItems: 'center',
        flexDirection: 'row',
    },
    headerContainer: {
        // marginHorizontal: margin.horizontal,
        justifyContent: "center",
        alignItems: "center",
        marginTop: WH.height(15),
    },
    titleContainer: {
        width: "100%",
        justifyContent: "center",
        alignItems: "center",
        marginTop: WH.height(2),
    },
    subtitleContainer: {
        width: "70%",
        justifyContent: "center",
        alignItems: "center",
        marginTop: verticalScale(5),
    },
    titleText: {
        fontFamily: font.bold,
        fontSize: moderateScale(22),
        color: "black",
        width: "100%",
        // backgroundColor:"red"
    },
    headerContainer: {
        // marginHorizontal: margin.horizontal,
        justifyContent: "center",
        alignItems: "center",
        marginTop: WH.height(15),
    },
});
