import { Dimensions, StatusBar, StyleSheet, View } from 'react-native';
import React, { useState } from 'react';
import InnerHeader from '@component/header/innerHeader';
import { margin } from '@constant/contstant';
import Toggle from '@materialComponent/toggle/toggle';
import Content from '@materialComponent/content/content';
import { font } from '../../../constant/contstant';
import Container from '../../../materialComponent/container/container';

const { height, fontScale } = Dimensions.get('screen');

const ShoppingNotificationSetting = ({ route }) => {
  return (
    <Container barColor={"white"}>
      <View style={[styles.mainView]}>
        <InnerHeader title={'Shopping'} />
        <Content>
          <View style={styles.content}>
            {data.map((item, index) => {
              return (
                <Toggle
                  text={item.desc}
                  marginTop={index == 0 ? height * 0.02 : height * 0.03}
                  item={item}
                />
              );
            })}
          </View>
        </Content>
      </View>
    </Container>
  );
};

export default ShoppingNotificationSetting;

const styles = StyleSheet.create({
  mainView: {
    flex: 1,
    backgroundColor: 'white',
  },
  content: {
    marginHorizontal: margin.horizontal,
    paddingBottom: height * 0.1,
  },
});

const data = [
  {
    toggle: true,
    desc: 'Price drop',
    db_value: 'notification_setting_pricedrop',
  },
  {
    toggle: true,
    desc: 'Back in stock',
    db_value: 'notification_setting_stock_available',
  },
  {
    toggle: true,
    desc: 'Bag reminder',
    db_value: 'notification_setting_abandone_cart',
  },
  {
    toggle: true,
    desc: 'Product reviews',
    db_value: 'notification_setting_remind_review',
  },
];
