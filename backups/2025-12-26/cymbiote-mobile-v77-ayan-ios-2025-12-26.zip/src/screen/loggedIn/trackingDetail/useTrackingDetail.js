import {useState, useEffect} from 'react';
import useReduxStore from '@utils/hooks/useReduxStore';
import {_getUserNotifications} from '@redux/actions/user/user';
import {useIsFocused} from '@react-navigation/native';
import {_getTrackingDetail, _getTrackings} from '@redux/actions/orders/orders';

const useTrackingDetail = ({route}) => {
  const {custom_tracking_id} = route?.params;
  const {dispatch} = useReduxStore();

  const [loader, setLoader] = useState(false);
  const [trackingDetail, setTrackingDetail] = useState({});
  const isFocused = useIsFocused();

  const fetchAPI = async () => {
    setLoader(true);
    const response = await dispatch(_getTrackingDetail(custom_tracking_id));
    response && setTrackingDetail(response);
    setLoader(false);
  };

  useEffect(() => {
    fetchAPI();
  }, []);

  const timeLine =
    trackingDetail?.manual_tracking_payload &&
    JSON.parse(trackingDetail?.manual_tracking_payload)?.track_info?.milestone;

  return {
    isFocused,
    loader,
    trackingDetail,
    timeLine,
  };
};

export default useTrackingDetail;
