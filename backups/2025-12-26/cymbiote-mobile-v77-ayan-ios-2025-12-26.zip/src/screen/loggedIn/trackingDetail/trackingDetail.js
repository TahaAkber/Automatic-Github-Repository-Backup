import { Dimensions, StyleSheet, View, TouchableOpacity, ScrollView } from 'react-native';
import React, { useState } from 'react';
import InnerHeader from '@component/header/innerHeader';
import Container from '@materialComponent/container/container';
import useTrackingDetail from './useTrackingDetail';
import { heightPercentageToDP } from 'react-native-responsive-screen';
import NotificationLoader from '@component/loader/notificationLoader';
import CustomText from '../../../materialComponent/customText/customText';
import { colors, font, fontSizes, margin } from '../../../constant/contstant';
import TrackingTimeline from '../../../component/trackingTimeline/trackingTimeline';
import Icon from '../../../materialComponent/icon/icon';
import Animated, { LinearTransition } from 'react-native-reanimated';
import { moderateScale } from 'react-native-size-matters';

const { height } = Dimensions.get('screen');

const TrackingDetail = ({ route }) => {
  const { isFocused, loader, trackingDetail, timeLine } = useTrackingDetail({
    route,
  });
  const [isExpanded, setIsExpanded] = useState(true);

  const toggleExpand = () => {
    setIsExpanded(!isExpanded);
  };

  return (
    <Container>
      <View style={styles.mainView}>
        <InnerHeader
          title={'Tracking Summary'}
          showBackIcon={true}
          fontSize={moderateScale(14)}
          style={{borderBottomWidth : 1, paddingBottom : height * 0.02, borderColor : "#f4f4f4"}}
      
        // light={true}
        // headerTextColor={'white'}
        />

        {loader ? (
          <NotificationLoader loading={true} />
        ) : (
          <ScrollView showsVerticalScrollIndicator={false} style={{ flex: 1 }} contentContainerStyle={{ paddingBottom: height * 0.09 }}>
            <View style={{ marginHorizontal: margin.horizontal }}>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 20 }}>
                <View>
                  <CustomText
                    text={`Tracking via ${trackingDetail?.manual_tracking_courier}`}
                    fontFamily={font.bold}
                    fontSize={moderateScale(14)}
                  />
                  <CustomText
                    text={`${trackingDetail?.manual_tracking_number}`}
                    fontFamily={font.bold}
                    color={colors.light_theme.theme} // Keep theme color for number or change to cyan if needed
                    fontSize={moderateScale(10)}
                    style={{ marginTop: 5 }}
                  />
                </View>
              </View>
              <View
                // layout={LinearTransition.springify().damping(18).stiffness(120)}
                style={{ marginHorizontal: -margin.horizontal, overflow: 'hidden' }}
              >
                {timeLine && (
                  <TrackingTimeline
                    trackingData={JSON.stringify(timeLine)}
                    isExpanded={isExpanded}
                    scrollEnabled={false}
                  />
                )}
              </View>
              {/* <TouchableOpacity
                onPress={toggleExpand}
                style={{ alignItems: 'center', paddingVertical: 10 }}
              >
                <Icon
                  name={isExpanded ? 'chevron-up' : 'chevron-down'}
                  size={24}
                />
              </TouchableOpacity> */}
            </View>
          </ScrollView>
        )}
      </View>
    </Container>
  );
};

export default TrackingDetail;

const styles = StyleSheet.create({
  mainView: {
    flex: 1,
    backgroundColor: 'white',
  },
  flatLists: {
    // paddingHorizontal: scale(15),
    // paddingVertical: verticalScale(10),
    paddingBottom: heightPercentageToDP(20),
  },
});
