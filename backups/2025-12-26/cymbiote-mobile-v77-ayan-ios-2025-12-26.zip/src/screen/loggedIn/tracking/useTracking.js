import React, {useState, useCallback, useEffect} from 'react';
import useReduxStore from '@utils/hooks/useReduxStore';
import {pagination} from '@utils/helper/helper';
import {_getUserNotifications} from '@redux/actions/user/user';
import {useIsFocused} from '@react-navigation/native';
import TrackingCard from '@component/cards/reelCard/trackingCard';
import {_getTrackings} from '../../../redux/actions/orders/orders';

const useTracking = () => {
  const {getState, dispatch} = useReduxStore();
  const {fetch_user_detail} = getState('auth');
  const {fetch_tracking, fetch_tracking_loader, fetch_tracking_error} =
    getState('order');

  const [page, setPage] = useState(0);
  const [loader, setLoader] = useState(false);
  const [paginationLoader, setPaginationLoader] = useState(false);
  const [pullLoader, setPullLoader] = useState(false);
  const isFocused = useIsFocused();

  const fetchAPI = async loading => {
    !loading && setPullLoader(true);
    loading && setLoader(true);
    await dispatch(_getTrackings(1));
    setPage(1);
    setPullLoader(false);
    setLoader(false);
  };

  const paginationAPI = async () => {
    if (!paginationLoader) {
      const totalPages = fetch_tracking?.total_pages == fetch_tracking?.page;
      const nextPagination = totalPages
        ? false
        : pagination(page, fetch_tracking?.total_pages);
      if (nextPagination) {
        setPaginationLoader(true);
        const response = await dispatch(_getTrackings(nextPagination));
        setPage(nextPagination);
        setPaginationLoader(false);
      }
    }
  };

  const renderItem = useCallback(({item, index}) => {
    return (
      <TrackingCard
        lastIndex={(fetch_tracking?.data || [])?.length - 1}
        index={index}
        item={item}
      />
    );
  }, []);

  useEffect(() => {
    fetchAPI(true);
  }, []);

  return {
    paginationLoader,
    paginationAPI,
    fetchAPI,
    renderItem,
    isFocused,
    pullLoader,
    loader,
    fetch_tracking,
    fetch_tracking_error,
  };
};

export default useTracking;
