import {
  Dimensions,
  FlatList,
  RefreshControl,
  StyleSheet,
  View,
} from 'react-native';
import React from 'react';
import InnerHeader from '@component/header/innerHeader';
import Container from '@materialComponent/container/container';
import useTracking from './useTracking';
import PagionationLoader from '@component/loader/endReachLoader';
import {heightPercentageToDP} from 'react-native-responsive-screen';
import NotificationLoader from '@component/loader/notificationLoader';
import EmptyScreen from '@component/emptyScreen/emptyScreen';
import {navigate} from '../../../utils/navigationRef/navigationRef';
import {globalStyle} from '../../../constant/contstant';
import {showErrorScreen} from '../../../utils/helper/helper';

const {height} = Dimensions.get('screen');

const data = Array.from({length: 10}, (_, index) => ({id: index}));

const Tracking = () => {
  const {
    paginationLoader,
    paginationAPI,
    fetchAPI,
    renderItem,
    isFocused,
    pullLoader,
    loader,
    fetch_tracking,
    fetch_tracking_loader,
    fetch_tracking_error,
  } = useTracking();


  return showErrorScreen(fetch_tracking_error) ? (
    <View style={globalStyle.show_error}>
      <EmptyScreen
        fullWidth={true}
        reload={fetchAPI}
        loader={pullLoader}
        message={fetch_tracking_error}
      />
    </View>
  ) : (
    <Container isFocused={isFocused} dark={true} barColor={'white'}>
      <View style={styles.mainView}>
        <InnerHeader
          onPressPlus={() => navigate('CreateTracking')}
          plus={true}
          title={'Manual Trackings'}
        />

        {loader ? (
          <NotificationLoader loading={true} />
        ) : (
          <View style={{flex: 1}}>
            <FlatList
              contentContainerStyle={styles.flatLists}
              showsVerticalScrollIndicator={false}
              onEndReached={paginationAPI}
              onEndReachedThreshold={0.5}
              data={fetch_tracking?.data || []}
              // data={data}
              keyExtractor={item => item.manual_tracking_id?.toString()}
              renderItem={renderItem}
              refreshControl={
                <RefreshControl refreshing={pullLoader} onRefresh={fetchAPI} />
              }
              ListFooterComponent={
                paginationLoader ? (
                  <View
                    style={{
                      justifyContent: 'center',
                      alignItems: 'center',
                    }}>
                    <PagionationLoader />
                  </View>
                ) : null
              }
              ListEmptyComponent={
                <View
                  style={{
                    justifyContent: 'center',
                    alignItems: 'center',
                    marginTop: height * 0.25,
                  }}>
                  <EmptyScreen
                    image={'empty_order'}
                    heading={'Tracking Not Found'}
                    desc={`You haven't had any activity yet.`}
                    // imageSize={width * 0.16}
                    // headingSize={fontScale * 14}
                    // descSize={fontScale * 12}
                  />
                </View>
              }
            />
          </View>
        )}
      </View>
    </Container>
  );
};

export default Tracking;

const styles = StyleSheet.create({
  mainView: {
    flex: 1,
    backgroundColor: 'white',
  },
  flatLists: {
    // paddingHorizontal: scale(15),
    // paddingVertical: verticalScale(10),
    paddingBottom: heightPercentageToDP(20),
  },
});
