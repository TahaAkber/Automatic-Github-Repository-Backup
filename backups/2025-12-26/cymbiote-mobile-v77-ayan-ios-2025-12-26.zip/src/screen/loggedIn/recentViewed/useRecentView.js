import { _getRecentViewedList, _recentViewed } from '@redux/actions/user/user';
import { _getStores } from '@redux/actions/merchant/merchant';
import { _globalLoader } from '@redux/actions/common/common';
import { useFocusEffect } from '@react-navigation/native';
import useReduxStore from '@utils/hooks/useReduxStore';
import { _login } from '@redux/actions/auth/auth';
import { useCallback, useState } from 'react';

const useRecentView = ({ }) => {
    const { getState, dispatch } = useReduxStore()
    const { fetch_user_detail } = getState("auth")
    const { fetch_recent_viewed, fetch_recent_viewed_error, fetch_recent_viewed_loader, fetch_recent_viewed_locally } = getState("user")


    const [activeVideoIndex, setActiveVideoIndex] = useState(null);

    const multipleRecentViewedPushed = async () => {
        await Promise.all(
            (fetch_recent_viewed_locally || []).reverse().map((item) =>
                !item.user_id &&
                dispatch(
                    _recentViewed(
                        fetch_user_detail?.id,
                        item.recent_view_type,
                        item.recent_view_shop_id,
                        item.recent_view_product_id
                    )
                )
            )
        );
    }

    useFocusEffect(
        useCallback(() => {
            const processRecentViews = async () => {
                if (fetch_recent_viewed_locally.length && fetch_user_detail?.id) {
                    await multipleRecentViewedPushed(); // Ensure this runs first and completes
                }
                dispatch(
                    _getRecentViewedList(fetch_user_detail?.id || "", fetch_user_detail?.id ? "" : fetch_recent_viewed_locally)
                ); // Run this after the above completes
            };

            processRecentViews(); // Call the async function
        }, [fetch_user_detail, fetch_recent_viewed_locally])
    );

    return {
        fetch_recent_viewed,
        setActiveVideoIndex,
        fetch_user_detail,
        activeVideoIndex,
    };
};

export default useRecentView;
