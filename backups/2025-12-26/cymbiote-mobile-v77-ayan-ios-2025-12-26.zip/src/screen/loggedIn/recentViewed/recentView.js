import {
    FlatList,
    Image,
    ImageBackground,
    StyleSheet,
    Text,
    TouchableOpacity,
    View,
} from 'react-native';
import React from 'react';
import { moderateScale, scale, verticalScale } from 'react-native-size-matters';
import InnerHeader from '@component/header/innerHeader';
import { colors, font, globalStyle, shadow, WH } from '@constant/contstant';
import ProfileImage from '@component/profileImage/profileImage';
import { margin } from '@constant/contstant';
import ProfileItem from '@component/cards/profileItem/profileItem';
import BorderLine from '@component/borderLine/borderLine';
import useRecentView from './useRecentView';
import ShopTile from '../../../component/cards/shopTile/shopTile';

const RecentView = () => {
    const { fetch_user_detail, fetch_recent_viewed, activeVideoIndex, setActiveVideoIndex } = useRecentView({})

    function getShopsAndProducts() {
        // Group data by shop_id
        const groupedShops = {};

        fetch_recent_viewed.forEach(item => {
            const shopId = item?.shop_id || item.shop_detail?.shop_id || item.product_detail?.product_shop_id;
            console.error("bhai mera item", shopId);
            if (shopId) {
             
                // Initialize the group if it doesn't exist
                if (!groupedShops[shopId]) {
                    groupedShops[shopId] = {
                        ...item,
                        ...item.shop_detail,
                        products: []  // Initialize an empty array for products
                    };
                }

                // If product details exist, add them to the corresponding shop
                if (item.product_detail?.product_shop_id === shopId) {
                    groupedShops[shopId].products.push({
                        ...item.product_detail,
                        product_variant: item.product_variant || [] // Ensure variants are included
                    });
                }
            }
        });

        const shopsArray = Object.values(groupedShops);
        return shopsArray;
    }

    return (
        <View style={styles.mainView}>
            <InnerHeader title={'Recently Viewed'} />
            <View style={{ flex: 1 }}>

                <FlatList
                    renderItem={({ item, index }) => (
                        <ShopTile
                            key={index}
                            activeVideoIndex={activeVideoIndex}
                            setActiveVideoIndex={setActiveVideoIndex}
                            item={item}
                            index={index}
                        />
                    )}
                    keyExtractor={(item, index) => index.toString()}
                    showsVerticalScrollIndicator={false}
                    contentContainerStyle={{ ...globalStyle.bottomSpace }}
                    data={getShopsAndProducts()}
                />
            </View>
        </View>
    );
};

export default RecentView;

const styles = StyleSheet.create({
    mainView: {
        flex: 1,
        backgroundColor: 'white',
        paddingHorizontal: margin.horizontal
    },
    flatLists: {
        paddingVertical: verticalScale(10),
        paddingBottom: globalStyle.bottomSpace.marginBottom,
    },
});


const data = [
    {
        icon_type: "AntDesign",
        name: "hearto",
        title: "Favorite",
        size: moderateScale(15)
    },
    {
        icon_type: "Feather",
        name: "eye",
        title: "Recently Viewed",
        size: moderateScale(15)
    },
    {
        borderLine: true
    },
    {
        icon_type: "Ionicons",
        name: "location-outline",
        title: "Location",
        size: moderateScale(15)
    },
    {
        icon_type: "Ionicons",
        name: "wallet-outline",
        title: "Wallet",
        size: moderateScale(15)
    },
    {
        borderLine: true
    },
    {
        icon_type: "MaterialCommunityIcons",
        name: "history",
        title: "Orders",
        size: moderateScale(15)
    },
    {
        icon_type: "AntDesign",
        name: "setting",
        title: "Setting",
        size: moderateScale(15)
    },
    {
        icon_type: "Ionicons",
        name: "exit-outline",
        title: "Logout",
        size: moderateScale(16),
        color: "red"
    },
]