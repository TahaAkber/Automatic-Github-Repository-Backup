import {
  Dimensions,
  StatusBar,
  StyleSheet,
  View,
  Animated,
  ScrollView,
  TouchableOpacity,
  RefreshControl,
  FlatList,
} from 'react-native';
import React, {useState} from 'react';
import InnerHeader from '@component/header/innerHeader';
import {margin} from '@constant/contstant';
import TabBar from '@component/tabBar/tabBar';
import useInnerHeaderAnimation from '../../../hooks/innerHeaderAnimation';
import Content from '@materialComponent/content/content';
import PointCard from '@component/cards/pointCard/pointCard';
import {colors} from '@constant/contstant';
import {isEven} from '@helper/reUsableMethod/reUsableMethod';
import GiftedChart from '@materialComponent/pointHistoryChart/pointHistoryChart';
import Icon from '@materialComponent/icon/icon';
import DatePicker from '../../../component/DatePicker/DatePicker';
import CustomText from '../../../materialComponent/customText/customText';
import {dateFormate} from '../../../helper/reUsableMethod/reUsableMethod';
import {font} from '../../../constant/contstant';
import useAllVouchers from './useAllVouchers';
import VoucherCard from '../../../component/cards/voucherCard/voucherCard';
import {formatExpiryDisplay, handleScroll} from '../../../utils/helper/helper';
import OrderLoader from '../../../component/loader/orderLoader';
import PagionationLoader from '../../../component/loader/endReachLoader';
import EmptyScreen from '../../../component/emptyScreen/emptyScreen';
import Container from '../../../materialComponent/container/container';

const {height, fontScale, width} = Dimensions.get('screen');

const Vouchers = () => {
  const {headerOpacity, headerTranslate, onScroll} = useInnerHeaderAnimation();
  const [id, setId] = useState(0);
  const [startDate, setStartDate] = useState(new Date());
  const [open, setOpen] = React.useState(false);
  const {
    all_vouchers,
    all_vouchers_loader,
    paginationAPI,
    paginationLoader,
    fetchAPI,
    pullLoader,
    all_vouchers_error,
  } = useAllVouchers();

  const renderVoucher = ({item, index}) => (
    <VoucherCard
      heading="Your Voucher has been created"
      subTitle={`${item.voucher_code}`}
      expiryDate={formatExpiryDisplay(item.voucher_expiration_date, true)}
      image={item.shop?.shop_logo_url}
      point={item.voucher_value}
      buttonColor="black"
      buttonText="Apply Now"
      style={{marginHorizontal: 0}}
      // marginTop={index == 0 ? 0 : 1}
    />
  );

  return (
    <Container barColor={'white'}>
      <View style={styles.container}>
        {/* Sticky Header (not part of scroll) */}
        <Animated.View
          style={[
            styles.headerContainer,
            {
              transform: [{translateY: headerTranslate}],
              opacity: headerOpacity,
            },
          ]}>
          <InnerHeader notification={true} setting={true} title="Vouchers" />
        </Animated.View>

        {/* Scrollable area */}
        <Content
          contentContainerStyle={{paddingBottom: height * 0.15}}
          onScroll={e => handleScroll(e, paginationAPI)}
          scrollEventThrottle={16}
          stickyHeaderIndices={[1]}
          refreshControl={
            <RefreshControl
              refreshing={pullLoader}
              onRefresh={fetchAPI}
              colors={[colors.light_theme.theme]}
            />
          }>
          {all_vouchers_loader &&
          (!all_vouchers || all_vouchers.length === 0) ? (
            <OrderLoader loading={true} />
          ) : (
            <>
              {(all_vouchers?.logs || []).length > 0 ? (
                <FlatList
                  data={all_vouchers.logs}
                  keyExtractor={(item, index) => `month-${index}`}
                  renderItem={({item}) => (
                    <View style={{marginTop: height * 0.01}}>
                      <View style={styles.dataView}>
                        <CustomText
                          fontSize={fontScale * 14}
                          fontFamily={font.bold}
                          text={item.month}
                        />
                      </View>
                      <FlatList
                        data={item.data || []}
                        keyExtractor={(voucher, index) => `voucher-${index}`}
                        renderItem={renderVoucher}
                        scrollEnabled={false}
                        // Important: prevent nested scrolling
                      />
                    </View>
                  )}
                  contentContainerStyle={{
                    paddingHorizontal: margin.horizontal,
                    marginTop: height * 0.01,
                  }}
                  // onEndReached={paginationAPI}
                  // onEndReachedThreshold={0.5}
                  ListFooterComponent={
                    paginationLoader ? <PagionationLoader /> : null
                  }
                  showsVerticalScrollIndicator={false}
                  scrollEnabled={false}
                />
              ) : (
                <View
                  style={{
                    justifyContent: 'center',
                    alignItems: 'center',
                    marginTop: height * 0.25,
                  }}>
                  <EmptyScreen
                    image={'empty_vouchers'}
                    heading={'No Vouchers Available'}
                    desc={
                      "You haven't received any vouchers yet. Start earning and redeeming rewards!"
                    }
                  />
                </View>
              )}
            </>
          )}
        </Content>
      </View>
    </Container>
  );
};

export default Vouchers;

const styles = StyleSheet.create({
  mainView: {
    // marginBottom: height * 0.03,
    marginHorizontal: margin.horizontal,
    paddingBottom: height * 0.2,
  },
  container: {
    flex: 1,
    backgroundColor: 'white',
  },
  headerContainer: {
    width: '100%',
    zIndex: 2, // Ensure the header is above other content
  },
  // tabBarContainer: {
  //     zIndex: 3, // TabBar should have the highest zIndex to stay on top
  //     backgroundColor: "white",
  //     flexDirection: "row",
  //     justifyContent: "center",
  //     // alignItems: "center",
  // },
  contentContainer: {
    marginTop: height * 0.04,
  },
  reviewsCard: {
    marginHorizontal: margin.horizontal,
    marginTop: height * 0.04,
  },
  vouchersView: {
    marginTop: height * 0.02,
  },
  pointsView: {
    // marginTop: height * 0.04
  },
  buttonContainer: {
    width: '25%',
    // height :
    // height: height * 0.0
  },
  customSliderView: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: height * 0.01,
    marginTop: height * 0.04,
  },
  dataView: {
    width: width * 1,
    alignSelf: 'center',
    backgroundColor: '#e6e6e6',
    paddingHorizontal: height * 0.025,
    paddingVertical: height * 0.007,
  },
});

const tabBar = [
  'All',
  'Pending',
  'Processing',
  'Confirmed',
  'Redeemed',
  'Cancelled',
];
