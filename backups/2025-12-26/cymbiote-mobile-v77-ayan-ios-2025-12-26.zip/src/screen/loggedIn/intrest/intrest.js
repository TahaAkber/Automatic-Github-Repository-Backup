import {moderateScale, verticalScale} from 'react-native-size-matters';
import CustomButton from '@materialComponent/customButton/customButton';
import {font, WH, globalStyle, margin} from '@constant/contstant';
import CustomText from '@materialComponent/customText/customText';
import {_introSliderSkip} from '@redux/actions/common/common';
import Container from '@materialComponent/container/container';
import SnakeWave from '@materialComponent/snakeWave/snakeWave';
import {StyleSheet, View, FlatList} from 'react-native';
import useIntroSlider from './useIntrest';
import React from 'react';
import {heightPercentageToDP} from 'react-native-responsive-screen';

const Intrest = ({route}) => {
  const {
    renderItem,
    dispatch,
    layoutReady,
    flatListRef,
    // data,
    categories,
    loader,
    getShops,
    selected_categories,
    isFocused,
  } = useIntroSlider({route});

  return (
    <Container
      isFocused={isFocused}
      dark
      barColor={'transparent'}
      translucent={true}>
      <SnakeWave />
      <View style={styles.container}>
        <View
          style={[
            {
              marginHorizontal: margin.horizontal,
              justifyContent: 'center',
              alignItems: 'center',
            },
          ]}>
          <View
            style={[
              {width: '50%', justifyContent: 'center', alignItems: 'center'},
            ]}>
            <CustomText
              center
              fontFamily={font.black}
              text={'Tell Us What You Love'}
              style={styles.skipText}
            />
          </View>
          <View
            style={[
              {
                width: '80%',
                justifyContent: 'center',
                alignItems: 'center',
                marginTop: verticalScale(10),
              },
            ]}>
            <CustomText
              center
              fontSize={moderateScale(12)}
              fontFamily={font.light}
              text={
                'Choose between 3 and 25 interests, and we’ll create the best events for your feed'
              }
            />
          </View>
        </View>

        {/* FlatList for Carousel */}
        {layoutReady && (
          <FlatList
            ref={flatListRef}
            // data={data}
            data={categories}
            renderItem={renderItem}
            keyExtractor={(item, index) => index.toString()}
            showsVerticalScrollIndicator={false}
            contentContainerStyle={styles.content}
            numColumns={3}
          />
        )}

        {/* Get Started Button */}
        <View style={[{marginHorizontal: margin.horizontal}]}>
          <View style={styles.getStartedButtonContainer}>
            <CustomButton
              disabled={selected_categories.length < 3 ? true : false}
              loader={loader}
              onPress={getShops}
              width={'100%'}
              text={'Continue'}
            />
          </View>
        </View>
      </View>
    </Container>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    // alignItems: 'center',
    justifyContent: 'space-between',
    ...globalStyle.paddingVertical,
    paddingBottom: heightPercentageToDP(3),
    width: '100%',
  },
  content: {
    justifyContent: 'center',
    alignItems: 'center',
    marginHorizontal: WH.width(5),
    flexGrow: 1, // Ensure content grows to fill available space
  },
  skipText: {
    fontFamily: font.bold,
    fontSize: moderateScale(25),
    color: 'black',
  },
  carouselItem: {
    justifyContent: 'center',
    alignItems: 'center',
    width: WH.width(30), // Adjust width for carousel items
    margin: WH.width(2), // Space between items
  },
  getStartedButtonContainer: {
    width: '100%',
  },
});

export default Intrest;
