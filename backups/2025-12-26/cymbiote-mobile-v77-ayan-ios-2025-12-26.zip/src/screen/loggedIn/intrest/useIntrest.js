import { useEffect, useRef, useState } from 'react';
import { globalStyle, margin, WH } from '@constant/contstant';
import { moderateScale, verticalScale } from 'react-native-size-matters';
import {
  Animated,
  Dimensions,
  StyleSheet,
  TouchableOpacity,
  Vibration,
  View,
} from 'react-native';
import Baloon from '@assets/images/baloon.svg';
import Shorts from '@assets/images/shorts.svg';
import Shoes from '@assets/images/shoes.svg';
import Heels from '@assets/images/heeled.svg';
import { Easing } from 'react-native';
import useReduxStore from '../../../utils/hooks/useReduxStore';

import garden from '@assets/images/garden.svg';
import automotive from '@assets/images/automotive.svg';
import fashion from '@assets/images/fashion.svg';
import office from '@assets/images/office.svg';
import gifts from '@assets/images/gifts.svg';
import travel from '@assets/images/travel.svg';
import books from '@assets/images/books.svg';
import grocery from '@assets/images/grocery.svg';
import pet from '@assets/images/pet.svg';
import beauty from '@assets/images/beauty.svg';
import toy from '@assets/images/toy.svg';
import health from '@assets/images/health.svg';
import sports from '@assets/images/sports.svg';
import electronics from '@assets/images/electronics.svg';
import CustomText from '../../../materialComponent/customText/customText';
import { font } from '../../../constant/contstant';
import CustomImage from '../../../materialComponent/image/image';
import {
  _appendToUserIntrest,
  _commonDispatcher,
  _introSliderSkip,
} from '../../../redux/actions/common/common';
import { SELECTED_CATEGORIES } from '../../../redux/types/user/user';
import { SvgUri } from 'react-native-svg'; // Import SvgUri from react-native-svg
import { _getStores } from '../../../redux/actions/merchant/merchant';
import { triggerHaptic } from '../../../utils/haptic/haptic';
import { useIsFocused } from '@react-navigation/native';

const { fontScale, height, width } = Dimensions.get('screen');

const useIntrest = ({ route }) => {
  const { dispatch, getState } = useReduxStore();
  const [selectIndex, setSelectindex] = useState(0);
  const flatListRef = useRef(null);
  const [layoutReady, setLayoutReady] = useState(false);
  const [loader, setLoader] = useState(false);
  const { method = false } = route?.params || {};
  const isFocused = useIsFocused()

  const { fetch_shop_categories, selected_categories, fetch_user_detail } =
    getState('user');

  const balloonTranslateY = useRef(new Animated.Value(0)).current;
  const oddBalloonTranslateY = useRef(new Animated.Value(0)).current;
  const balloonScale = useRef(new Animated.Value(0)).current; // Animated value for size

  const data = [
    {
      image: Shorts,
      heading: 'Browse Categories',
      text: 'Find everything you need in one place.',
    },
    {
      image: Shoes,
      heading: 'Track Orders',
      text: 'Stay updated with real-time order tracking.',
    },
    {
      image: Heels,
      heading: 'Earn Cashback',
      text: 'Earn rewards on every purchase you make.',
    },
    {
      image: Shorts,
      heading: 'Browse Categories',
      text: 'Find everything you need in one place.',
    },
    {
      image: Shoes,
      heading: 'Track Orders',
      text: 'Stay updated with real-time order tracking.',
    },
    {
      image: Heels,
      heading: 'Earn Cashback',
      text: 'Earn rewards on every purchase you make.',
    },
    {
      image: Shorts,
      heading: 'Browse Categories',
      text: 'Find everything you need in one place.',
    },
    {
      image: Shoes,
      heading: 'Track Orders',
      text: 'Stay updated with real-time order tracking.',
    },
    {
      image: Heels,
      heading: 'Earn Cashback',
      text: 'Earn rewards on every purchase you make.',
    },
    {
      image: Shorts,
      heading: 'Browse Categories',
      text: 'Find everything you need in one place.',
    },
    {
      image: Shoes,
      heading: 'Track Orders',
      text: 'Stay updated with real-time order tracking.',
    },
    {
      image: Heels,
      heading: 'Earn Cashback',
      text: 'Earn rewards on every purchase you make.',
    },
  ];

  // const categories = [
  //     { name: "Electronics", Image: electronics },
  //     { name: "Sports & Outdoor", Image: sports },
  //     { name: "Toys & Hobbies", Image: toy },
  //     { name: "Health & Wellness", Image: health },
  //     { name: "Beauty & Personal Care", Image: beauty },
  //     { name: "Pet Supplies", Image: pet },
  //     { name: "Grocery & Food", Image: grocery },
  //     { name: "Books & Media", Image: books },
  //     { name: "Travel & Experiences", Image: travel },
  //     { name: "Gifts & Speciality", Image: gifts },
  //     { name: "Office Supplies", Image: office },
  //     { name: "Fashion & Apparel", Image: fashion },
  //     { name: "Automotive", Image: automotive },
  //     { name: "Home & Garden", Image: garden }
  // ];

  const categories = fetch_shop_categories.map((item, index) => {
    return { ...item, name: item.category_name, Image: item.category_image_url };
  });

  function toggleCategorySelection(categoryId) {
    if (selected_categories.includes(categoryId)) {
      selected_categories.splice(selected_categories.indexOf(categoryId), 1);
    } else {
      selected_categories.push(categoryId);
    }
    dispatch(_commonDispatcher(SELECTED_CATEGORIES, selected_categories));
  }
  async function getShops() {
    setLoader(true);
    triggerHaptic()
    // Check if method exists and is a function
    if (method && typeof method === 'function') {
      try {
        await method(); // Ensure method is a promise-returning function
      } catch (error) {
        console.error('Error executing method:', error);
      }
    } else {
      console.warn('Method is not defined or is not a function');
    }

    // Continue with the rest of the dispatch actions
    await dispatch(
      _getStores({
        page: 1,
        user_id: fetch_user_detail?.id,
        pull: false,
        categories: selected_categories.toString(),
      }),
    );
    dispatch(_introSliderSkip(true));

    setLoader(false);
  }

  const animateBalloon = index => {
    const scaleTo = index % 2 === 0 ? 1.2 : 0.8; // Adjust size scale (bigger or smaller)

    Animated.loop(
      Animated.parallel([
        Animated.sequence([
          Animated.timing(oddBalloonTranslateY, {
            toValue: verticalScale(5),
            duration: 500,
            easing: Easing.ease,
            useNativeDriver: true,
          }),
          Animated.timing(oddBalloonTranslateY, {
            toValue: 0,
            duration: 500,
            easing: Easing.ease,
            useNativeDriver: true,
          }),
        ]),
        Animated.sequence([
          Animated.timing(balloonTranslateY, {
            toValue: 5,
            duration: 500,
            easing: Easing.ease,
            useNativeDriver: true,
          }),
          Animated.timing(balloonTranslateY, {
            toValue: 0,
            duration: 500,
            easing: Easing.ease,
            useNativeDriver: true,
          }),
        ]),
      ]),
    ).start();

    Animated.parallel([
      Animated.sequence([
        // Repeating sequence of animations
        Animated.timing(balloonScale, {
          toValue: 0.8, // Animate the size change to 1.2
          duration: 300,
          useNativeDriver: true,
        }),
        Animated.timing(balloonScale, {
          toValue: 1.2, // Animate the size change to 0.8
          duration: 300,
          useNativeDriver: true,
        }),
      ]),
    ]).start();
  };

  useEffect(() => {
    setTimeout(() => {
      setLayoutReady(true);
    }, 0);
    animateBalloon(selectIndex);
  }, [layoutReady, selectIndex]);

  // const renderItem = ({ item, index }) => {
  //     return (
  //         <View style={styles.carouselItem}>
  //             <Animated.View
  //                 style={{
  //                     transform: [
  //                         { translateY: index % 2 === 0 ? balloonTranslateY : oddBalloonTranslateY },
  //                         { scale: balloonScale }  // Apply scaling here
  //                     ],
  //                     zIndex: 0,
  //                     borderRadius: 50,
  //                     overflow: 'hidden',
  //                 }}
  //             >
  //                 <Baloon height={WH.width(25)} width={WH.width(25)} />
  //             </Animated.View>

  //             <Animated.View
  //                 style={{
  //                     transform: [{ translateY: index % 2 === 0 ? balloonTranslateY : oddBalloonTranslateY },
  //                     { scale: balloonScale }  // Apply scaling here
  //                     ],
  //                     position: 'absolute',
  //                     zIndex: 1,
  //                     justifyContent: 'center',
  //                     alignItems: 'center',
  //                 }}
  //             >
  //                 <item.image height={WH.width(8)} width={WH.width(8)} />
  //             </Animated.View>
  //         </View>
  //     );
  // };

  const renderItem = ({ item, index }) => {
    const isSelected = selected_categories.includes(item.category_id);
    return (
      <TouchableOpacity
        activeOpacity={1}
        onPress={() => toggleCategorySelection(item.category_id)}
        style={[styles.carouselItem]}>
        <Animated.View
          style={{
            transform: [
              {
                translateY:
                  index % 2 === 0 ? balloonTranslateY : oddBalloonTranslateY,
              },
              { scale: balloonScale }, // Apply scaling here
            ],
            zIndex: 0,
            borderRadius: 50,
            overflow: 'hidden',
          }}>
          <View
            style={{
              width: WH.width(13),
              height: height * 0.11,
              alignItems: 'center',
            }}>
            {/* <CustomImage source={{ uri: item.category_image_url }} style={{
                            width: WH.width(13),
                            height: WH.width(13),
                        }} width={WH.width(13)} height={WH.width(13)} /> */}
            <SvgUri
              uri={item.category_image_url}
              width={WH.width(11)}
              height={WH.width(11)}
              style={{ opacity: isSelected ? 1 : 0.5 }}
            />
            <CustomText
              center
              fontFamily={font.bold}
              color={'#444444'}
              fontSize={moderateScale(7)}
              marginTop={height * 0.005}
              text={item.name}
            />
          </View>
        </Animated.View>
      </TouchableOpacity>
    );
  };

  return {
    renderItem,
    dispatch,
    layoutReady,
    flatListRef,
    data,
    toggleCategorySelection,
    categories,
    loader,
    getShops,
    selected_categories,
    isFocused
  };
};

export default useIntrest;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'space-between',
    marginHorizontal: margin.horizontal,
    ...globalStyle.paddingVertical,
  },
  carouselItem: {
    justifyContent: 'center',
    alignItems: 'center',
    width: WH.width(30),
  },
});
