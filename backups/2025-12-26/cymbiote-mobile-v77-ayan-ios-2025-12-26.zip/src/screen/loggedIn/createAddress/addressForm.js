import React, {useRef} from 'react';
import {
  StyleSheet,
  View,
  KeyboardAvoidingView,
  Platform,
  TouchableOpacity,
  Dimensions,
} from 'react-native';
import {moderateScale, verticalScale} from 'react-native-size-matters';
import {globalStyle, margin, colors, font} from '@constant/contstant';
import CustomButton from '@materialComponent/customButton/customButton';
import CustomText from '@materialComponent/customText/customText';
import {goBack} from '@utils/navigationRef/navigationRef';
import Content from '@materialComponent/content/content'; // Ensure this is a ScrollView
import AuthInput from '@component/input/authInput';
import {Formik} from 'formik';
import useCreateAddress from './useCreateAddress';
import Dropdown from '../../../component/dropdown/dropdown';
import {countries} from '../../../constant/dummyData';
import FloatingLabelInput from '../../../component/input/labelInput';
import {TextInput, HelperText} from 'react-native-paper';
import CustomInput from '../../../materialComponent/customInput/customInput';
const {height} = Dimensions.get('screen');

const AddressForm = ({addressId}) => {
  const {
    _handleSubmit: submitLogin,
    _handleCurrentLocation,
    address,
    keyboardVisible,
    loader,
    schema,
    countryInputRef,
    addressInputRef,
    apartmentInputRef,
    cityInputRef,
    // provinceInputRef,
    postalCodeInputRef,
    fetch_user_detail,
    firstNameRef,
    lastNameRef,
    companyRef,
    phoneRef,
    countryCode,
    handleCountryCode,
  } = useCreateAddress({addressId});

  const dropdownRef = useRef(null);

  console.log('countryIdByData', countryCode);

  return (
    <KeyboardAvoidingView
      //   behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      style={{flex: 1}}>
      <Content
        contentContainerStyle={[
          styles.mainView,
          {
            // flexGrow: 1,
            paddingHorizontal: margin.horizontal,
            // marginBottom: verticalScale(20),
          },
        ]}>
        <Formik
          initialValues={{
            firstName: address?.firstName || fetch_user_detail?.firstname || '',
            lastName: address?.lastName || fetch_user_detail?.lastname || '',
            country: address?.country || 1,
            address: address?.fullAddress || '',
            apartment: address?.apartment || '',
            city: address?.city || '',
            postalcode: address?.postalCode || '',
            phone: address?.number || '',
          }}
          validationSchema={schema}
          onSubmit={values => submitLogin(values)}
          enableReinitialize>
          {({
            setFieldValue,
            handleChange,
            handleSubmit,
            handleBlur,
            values,
            errors,
            touched,
            isValid,
          }) => (
            <View style={styles.mainView}>
              <Dropdown
                ref={dropdownRef}
                label="Country"
                value={values.country} // Formik value for the specific field
                fieldName="country" // Dynamic field name (can be 'dropdownValue', 'country', etc.)
                setFieldValue={(field, value) => {
                  setFieldValue(field, value);
                  handleCountryCode(value);
                }} // Pass the setFieldValue function from Formik
                onBlur={handleBlur('country')}
                errorMessage={
                  touched.country && errors.country ? errors.country : null
                }
                static_data={countries} // Static data for dropdown options
                marginTop={verticalScale(10)}
              />

              {/* Email Input */}
              {/* <AuthInput
                                ref={countryInputRef}
                                label="Country"
                                placeholder="Enter Country"
                                onChangeText={handleChange('country')}
                                onBlur={handleBlur('country')}
                                value={values.country}
                                errorMessage={touched.country && errors.country ? errors.country : null}
                                returnKeyType="next"
                                onSubmitEditing={() => addressInputRef.current?.focus()} // Focus next input
                                marginTop={verticalScale(10)}
                            // editable={emptyObject}
                            /> */}

              {/* <FloatingLabelInput
                                ref={addressInputRef}
                                label="Last Name"
                                value={lastName}
                                onChangeText={setLastName}
                                placeholder="Enter your last name"
                                marginTop={height * 0.01}
                            /> */}

              {/* <TextInput
                                ref={firstNameRef}
                                label="First Name"
                                placeholder="First Name"
                                onChangeText={(text) => handleChange('firstName')(text)}
                                onBlur={() => handleBlur('firstName')}
                                value={values.firstName}
                                errorMessage={touched.firstName && errors.firstName ? errors.firstName : null}
                                returnKeyType="next"
                                onSubmitEditing={() => lastNameRef?.current?.focus()} // Safe navigation
                                marginTop={verticalScale(5)}
                                mode='outlined'
                                style={{ backgroundColor: "white", marginTop: verticalScale(10) }}
                                textColor='#000'
                                theme={{
                                    colors: {
                                        primary: colors.light_theme.theme,// Focused border/underline color (BLUE)
                                        accent: 'red', // Error color
                                        placeholder: '#888', // Default placeholder
                                        text: 'red', // Text color

                                    },
                                    roundness: 4,
                                }}
                            /> */}
              <CustomInput
                label="First Name"
                placeholder="Enter your first name"
                value={values.firstName}
                onChangeText={handleChange('firstName')}
                onBlur={handleBlur('firstName')}
                onFocus={() => dropdownRef.current?.close?.()}
                onSubmitEditing={() => lastNameRef?.current?.focus()}
                error={touched.firstName && errors.firstName}
                inputRef={firstNameRef}
                returnKeyType="next"
                required
              />

              <CustomInput
                inputRef={lastNameRef}
                label="Last Name"
                placeholder="Enter your last Name"
                onChangeText={text => handleChange('lastName')(text)}
                onBlur={() => handleBlur('lastName')}
                onFocus={() => dropdownRef.current?.close?.()}
                value={values.lastName}
                errorMessage={
                  touched.lastName && errors.lastName ? errors.lastName : null
                }
                returnKeyType="next"
                onSubmitEditing={() => addressInputRef?.current?.focus()}
                required
              />

              <CustomInput
                inputRef={addressInputRef}
                label="Address"
                placeholder="Enter address"
                onChangeText={text => handleChange('address')(text)}
                onBlur={() => handleBlur('address')}
                onFocus={() => dropdownRef.current?.close?.()}
                value={values.address}
                errorMessage={
                  touched.address && errors.address ? errors.address : null
                }
                returnKeyType="next"
                required
                onSubmitEditing={() => apartmentInputRef?.current?.focus()}
              />

              <CustomInput
                Inputref={apartmentInputRef}
                label="Apartment, suite, etc. (optional)"
                placeholder="Enter apartment, suite, etc"
                onChangeText={text => handleChange('apartment')(text)}
                onBlur={() => handleBlur('apartment')}
                onFocus={() => dropdownRef.current?.close?.()}
                value={values.apartment}
                error={
                  touched.apartment && errors.apartment
                    ? errors.apartment
                    : null
                }
                returnKeyType="next"
                onSubmitEditing={() => cityInputRef?.current?.focus()}
                marginTop={verticalScale(5)}
              />

              <CustomInput
                Inputref={cityInputRef}
                label="City"
                placeholder="Enter City"
                onChangeText={text => handleChange('city')(text)}
                onBlur={() => handleBlur('city')}
                onFocus={() => dropdownRef.current?.close?.()}
                value={values.city}
                errorMessage={touched.city && errors.city ? errors.city : null}
                returnKeyType="next"
                onSubmitEditing={() => postalCodeInputRef?.current?.focus()}
                required
              />
              {/* <CustomInput
                                Inputref={provinceInputRef}
                                label="Province"
                                placeholder="Enter Province"
                                onChangeText={(text) => handleChange('province')(text)}
                                onBlur={() => handleBlur('province')}
                                value={values.province}
                                returnKeyType="next"
                                onSubmitEditing={() => postalCodeInputRef?.current?.focus()}
                                error={touched.province && errors.province ? errors.province : null}
                               required
                            /> */}

              <CustomInput
                Inputref={postalCodeInputRef}
                label="Postal code (optional)"
                placeholder="Enter postal code"
                onChangeText={text => handleChange('postalcode')(text)}
                onBlur={() => handleBlur('postalcode')}
                onFocus={() => dropdownRef.current?.close?.()}
                value={values.postalcode}
                errorMessage={
                  touched.postalcode && errors.postalcode
                    ? errors.postalcode
                    : null
                }
                returnKeyType="next"
                onSubmitEditing={() => phoneRef?.current?.focus()} // Moved phone focus first
                keyboardType="number-pad"
              />

              <CustomInput
                key={countryCode}
                Inputref={phoneRef}
                countryCode={countryCode}
                label="Phone"
                placeholder=""
                onChangeText={text => handleChange('phone')(text)}
                onBlur={() => handleBlur('phone')}
                onFocus={() => dropdownRef.current?.close?.()}
                value={values.phone}
                returnKeyType="done"
                onSubmitEditing={handleSubmit} // Submit form when done
                errorMessage={
                  touched.phone && errors.phone ? errors.phone : null
                }
                required
                keyboardType="number-pad"
              />

              {/* Remember Me */}
              {/* <View style={[globalStyle.space_between, { marginTop: verticalScale(10) }]}>
                                <View style={globalStyle.row}>
                                    <Checkbox
                                        onPress={() => setRemember(!remember)}
                                        status={remember ? 'checked' : 'unchecked'}
                                    />
                                    <CustomText
                                        fontSize={moderateScale(14)}
                                        color={colors.light_theme.gray}
                                        // style={{ marginLeft: 0 }}
                                        text="Remember me"
                                    />
                                </View>
                                <CustomText
                                    fontSize={moderateScale(14)}
                                    color={colors.light_theme.gray}
                                    textAlign="right"
                                    text="Forgot Password"
                                />
                            </View> */}

              {/* Submit Button */}
              <CustomButton
                marginTop={verticalScale(20)}
                text={`${addressId ? 'Update' : 'Save'}`}
                onPress={handleSubmit}
                loader={loader}
                disabled={!isValid || !values.country}
              />
              {/* <CustomButton
                                marginTop={verticalScale(10)}
                                text={"Current location"}
                                onPress={_handleCurrentLocation}
                            /> */}
            </View>
          )}
        </Formik>
      </Content>
    </KeyboardAvoidingView>
  );
};

export default AddressForm;

const styles = StyleSheet.create({
  mainView: {
    flex: 1,
  },
});
