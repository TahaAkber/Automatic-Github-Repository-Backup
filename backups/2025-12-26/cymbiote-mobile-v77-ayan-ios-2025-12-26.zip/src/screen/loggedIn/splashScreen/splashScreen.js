import React, { useEffect } from 'react';
import { View, Text, Animated, StyleSheet, StatusBar, Dimensions } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import images from '@assets/images/images';
import { colors, font } from '@constant/contstant';
import AppIcon from '@assets/images/app_icon.svg';

const { width } = Dimensions.get("screen")

const SplashScreen = ({ setLoader }) => {
    const scaleAnim = new Animated.Value(0.5); // Start smaller
    const rotateAnim = new Animated.Value(0);
    const opacityAnim = new Animated.Value(0);
    const translateYAnim = new Animated.Value(100); // Starting below the screen

    // useEffect(() => {
    //     Animated.parallel([
    //         Animated.timing(scaleAnim, {
    //             toValue: 1, // Grow to original size
    //             duration: 2000, // Extended duration for smoother animation
    //             useNativeDriver: true,
    //         }),
    //         Animated.timing(rotateAnim, {
    //             toValue: 1,
    //             duration: 2000, // Extended duration for smoother animation
    //             useNativeDriver: true,
    //         }),
    //         Animated.timing(opacityAnim, {
    //             toValue: 1,
    //             duration: 1500, // Slightly faster fade-in effect
    //             useNativeDriver: true,
    //         }),
    //         Animated.timing(translateYAnim, {
    //             toValue: 0, // End position
    //             duration: 1500, // Smooth upward transition
    //             useNativeDriver: true,
    //         }),
    //     ]).start(() => {
    //         setTimeout(() => {
    //             setLoader(false);
    //         }, 200);
    //     });
    // }, []);

    const rotateInterpolate = rotateAnim.interpolate({
        inputRange: [0, 1],
        outputRange: ['0deg', '360deg'],
    });

    return (
        <LinearGradient colors={['white', 'white']} style={styles.container}>
            <StatusBar animated backgroundColor={"white"} barStyle="dark-content" />
            {/* <Animated.Image
                source={images.app}
                style={[
                    styles.logo,
                    // {
                    //     transform: [
                    //         { scale: scaleAnim }, // Animating the scale (size)
                    //         { rotate: rotateInterpolate }, // Rotating the image
                    //     ],
                    //     opacity: opacityAnim, // Animating opacity
                    // },
                ]}
            /> */}

            <AppIcon width={width * 0.5} height={width * 0.5} />

            <Animated.Text
                style={[
                    styles.appName,
                    // {
                    //     opacity: opacityAnim, // Fade-in effect for text
                    //     transform: [{ translateY: translateYAnim }], // Moving text upward
                    // },
                ]}
            >
                Powered By Cymbiote
            </Animated.Text>
        </LinearGradient>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
    },
    logo: {
        width: 400,
        height: 400,
    },
    appName: {
        fontSize: 12,
        fontFamily: font.bold,
        color: 'black',
        marginTop: 20,
        position: 'absolute',
        bottom: 0,
        width: '100%',
        textAlign: 'center',
        padding: 15,
    },
});

export default SplashScreen;
