import {moderateScale} from 'react-native-size-matters';
import {
  Dimensions,
  FlatList,
  RefreshControl,
  StatusBar,
  StyleSheet,
  TouchableOpacity,
  View,
} from 'react-native';
import React, {useRef, useState} from 'react';
import InnerHeader from '@component/header/innerHeader';
import {margin} from '@constant/contstant';
import Stories from '@component/cards/stories/stories';
import SearchInput from '@component/input/searchInput';
import CustomImage from '@materialComponent/image/image';
import BottomSheetConfirmRedemption from '../../../materialComponent/bottomSheet/bottomSheetConfirmRedemption';
import CustomText from '../../../materialComponent/customText/customText';
import {font, globalStyle} from '../../../constant/contstant';
import Icon from '../../../materialComponent/icon/icon';
import useRedeem from './useRedeem';
import PagionationLoader from '../../../component/loader/endReachLoader';
import RedeemStoreLoader from '../../../component/loader/redeemStoreLoader';
import Container from '../../../materialComponent/container/container';

const {width, height, fontScale} = Dimensions.get('screen');

const Redeem = () => {
  const {
    handlePress,
    item,
    refRBSheet,
    renderShops,
    setItem,
    fetch_store_for_redeem,
    fetch_store_loader,
    paginationAPI,
    paginationLoader,
    setSearch,
    search,
    handleSearch,
    localData,
    searchLoader,
    fetchAPI,
  } = useRedeem();

  return (
    <Container barColor={'white'}>
      <View style={styles.container}>
        <InnerHeader notification={true} setting={true} title={'Redeem'} />
        <View style={[styles.horizontalSearch, {marginTop: height * 0.02}]}>
          <SearchInput
            onChangeText={handleSearch}
            value={search}
            placeholder={'Search Your Following Store Here...'}
          />
        </View>

        {searchLoader ? (
          <RedeemStoreLoader />
        ) : (
          <>
            {/* {!(localData?.shops || []).length ? (
            <View style={{marginTop: height * 0.015, ...styles.horizontal}}>
              <Stories
                onPress={item => handlePress(item)}
                heading={'Following'}
              />
            </View>
          ) : (
            <></>
          )} */}

            <View style={{marginTop: height * 0.02}}>
              <View>
                <View
                  style={{
                    marginHorizontal: margin.horizontal,
                    marginBottom: height * 0.02,
                  }}>
                  <CustomText
                    fontFamily={font.bold}
                    fontSize={fontScale * 20}
                    text={'Choose your store'}
                    style={{marginRight: moderateScale(10)}}
                  />
                </View>
                <FlatList
                  scrollEnabled={true}
                  data={
                    search
                      ? localData?.shops || []
                      : fetch_store_for_redeem?.data?.shops || []
                  }
                  // data={[]}
                  renderItem={renderShops}
                  refreshControl={
                    <RefreshControl
                      refreshing={fetch_store_loader}
                      onRefresh={() => fetchAPI()}
                    />
                  }
                  keyExtractor={(item, index) => index.toString()}
                  showsHorizontalScrollIndicator={false}
                  contentContainerStyle={styles.shopsList}
                  columnWrapperStyle={{marginTop: height * 0.01}}
                  numColumns={3}
                  showsVerticalScrollIndicator={false}
                  onEndReached={() => !search && paginationAPI()}
                  ListFooterComponent={
                    paginationLoader ? <PagionationLoader /> : null
                  }
                />
              </View>
              <BottomSheetConfirmRedemption
                refRBSheet={refRBSheet}
                data={item}
                height={height * 0.46}
              />
            </View>
          </>
        )}
      </View>
    </Container>
  );
};

export default Redeem;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
  },
  horizontalSearch: {
    marginHorizontal: moderateScale(10),
  },
  contentContainer: {
    marginRight: moderateScale(10),
  },
  image: {
    width: '100%',
    height: height * 0.1,
    borderRadius: moderateScale(10),
  },
  shopsList: {
    paddingBottom: height * 0.3,
    marginHorizontal: margin.horizontal,
  },
  icon: {
    marginHorizontal: moderateScale(5),
  },
});

// {{url}}/api/shops/all?page=1&user_id=61&pageSize=3&categories=1,2,3
// https://cymbiotebackend.santex.com.pk/staging/shops/search?search_term=khaadi
