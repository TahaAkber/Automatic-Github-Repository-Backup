import { Dimensions, FlatList, StatusBar, StyleSheet, TextInput, TouchableOpacity, View } from "react-native"
import CustomText from "../../../materialComponent/customText/customText"
import HelpCenterHeader from "../../../component/header/helpCenterHeader";
import CustomerCareSvg from "@assets/images/customerCare.svg"
import { useRef, useState } from "react";
import { colors, font, margin } from "../../../constant/contstant";
import Icon from "../../../materialComponent/icon/icon";
import LCSCard from "../../../component/lcsCard/lcsCard";
import OrdersBottomSheet from "../../../component/Chat/ordersBottomSheet";
import images from "../../../assets/images/images";
import { accessGallery, accessCamera } from '@utils/imagePicker/imagePicker';
import GorhomBottomSheet from "../../../materialComponent/bottomSheet/GorhomBottomSheet";

const { width, height, fontScale } = Dimensions.get("screen");
const categories = [
  { id: "1", name: "Order Issues" },
  { id: "2", name: "Product Inquiries" },
  { id: "3", name: "Account Assistance" },
  { id: "4", name: "Technical Support" }
];

const questions = {
  "Order Issues": [
    "I didn't receive my parcel",
    "I want to cancel my order",
    "I want to return my order",
    "Package was damaged",
    "Other"
  ],
  "Product Inquiries": [
    "Product details clarification",
    "Availability of a product",
    "Warranty and support",
    "Other"
  ],
  "Account Assistance": [
    "Reset password",
    "Update personal details",
    "Manage subscriptions",
    "Other"
  ],
  "Technical Support": [
    "App is not working",
    "Website issues",
    "Other"
  ]
};


const orderData = [
  {
    id: '1',
    orderId: '#92287157',
    status: 'Shipped',
    itemsCount: '4',
    images: [images.t_shirt, images.t_shirt, images.t_shirt, images.t_shirt],
  },
  {
    id: '2',
    orderId: '#9977866',
    status: 'Delivered',
    itemsCount: '3',
    images: [images.t_shirt, images.t_shirt, images.t_shirt, images.t_shirt],
  },
];

const CustomerCare = ({ navigation, onSendMessage }) => {
  const [selectedCategory, setSelectedCategory] = useState(null)
  const [selectedQuestion, setSelectedQuestion] = useState(null);
  const [userMessage, setUserMessage] = useState("");
  const [message, setMessages] = useState([]);
  const bottomSheetRef = useRef(null);
  const ordersSheetRef = useRef(null);
  const [images, setImages] = useState([]);

  const handleSendMessage = () => {
    if (userMessage.trim().length === 0) return;
    const newMessage = {
      id: Date.now().toString(),
      text: userMessage,
      isOutgoing: true,
      time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })

    };
    setMessages((prevMessages) => [...prevMessages, newMessage]);
    setUserMessage("")
  }


  const openGallery = async () => {
    const response = await accessGallery(true); // Enable multiple selection
  

    bottomSheetRef.current.close();

    if (response && Array.isArray(response) && response.length > 0) {
      const imageMessages = response.map(img => ({
        id: Date.now().toString() + Math.random().toString(), // Unique ID
        type: 'image',
        image: img.uri, // Correct URI format
        isOutgoing: true,
        time: new Date().toLocaleTimeString([], {
          hour: '2-digit',
          minute: '2-digit',
        }),
      }));

      setImages(prev => [...prev, ...response.map(img => img.uri)]); // Update state with selected images
      onSendMessage(imageMessages); // Send multiple images as separate messages
    } else {
      console.warn('No images selected');
    }
  };

  // Function to open the camera
  const openCamera = async () => {
    const response = await accessCamera(false); // Capture single image
    bottomSheetRef.current.close();

    if (response && response.uri) {
      // Ensure response has a valid URI
      setImages([...images, response.uri]);
      handleSendImage(response.uri);
     
    } else {
      console.warn('Invalid image URI from camera:', response);
    }
  };
  return (
    <View style={styles.container}>
      <View>
        <StatusBar animated barStyle={"dark-content"} backgroundColor={"white"} translucent={false} />
        <HelpCenterHeader title={"Customer Care"} IconComponent={CustomerCareSvg} borderLine={1} navigation={navigation} />
        <CustomText text={"Hi, I'm your Cymbiote Virtual Assistant – here to help you with anything you need!"}
          fontSize={fontScale * 14} fontFamily={font.light} style={styles.questionText} marginTop={height * 0.02} />

      </View>
      <View>
        <CustomText text={"How Can We Assist You"} fontSize={fontScale * 21} style={styles.trackingHeading} fontFamily={font.bold} />
        <CustomText text={"We’re here to help you with any questions or issues you may have. Our dedicated support team is available to assist you with a range of services, ensuring your experience is smooth and enjoyable."}
          marginTop={height * 0.01} fontSize={fontScale * 12} style={styles.trackingHeading} fontFamily={font.light} />

        <View style={styles.categoryContainer}>
          {categories.map((category) => (
            <TouchableOpacity
              key={category.id}
              style={[
                styles.categoryButton,
                selectedCategory === category.name && styles.categoryButtonSelected
              ]}
              onPress={() => setSelectedCategory(category.name)}
            >
              <CustomText
                text={category.name}
                fontSize={fontScale * 14}
                fontFamily={font.medium}
                color={selectedCategory === category.name ? "#fff" : "#000"}
              />
            </TouchableOpacity>
          ))}
        </View>
        {selectedCategory && (
          <View style={styles.questionsContainer}>
            {questions[selectedCategory].map((question, index) => (
              <TouchableOpacity
                key={index}
                style={[
                  styles.questionButton,
                  selectedQuestion === question && styles.questionButtonSelected
                ]}
                onPress={() => setSelectedQuestion(question)}
              >
                <CustomText
                  text={question}
                  fontSize={fontScale * 14}
                  fontFamily={font.medium}
                  color={selectedQuestion === question ? "#fff" : "#000"}
                />
              </TouchableOpacity>
            ))}
          </View>
        )}

        {/* Chat Messages List */}
        <FlatList
          data={message}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <>

              <View style={[styles.messageBubble, item.isOutgoing ? styles.outgoingBubble : styles.incomingBubble]}>
                <CustomText text={item.text} fontSize={16} fontFamily={font.regular} color={item.isOutgoing ? "white" : "black"} />
              </View>
              <CustomText text={item.time} fontSize={12} color={"#797C7B"} textAlign={item.isOutgoing ? "right" : "left"} />

            </>

          )}
          contentContainerStyle={{ padding: 15 }}
        />
        <View style={styles.inputContainer}>
          <TouchableOpacity style={styles.iconButton} onPress={() => bottomSheetRef.current.open()} >
            <Icon icon_type={"Entypo"} size={24} color={"#000E08"} name={"attachment"} />
          </TouchableOpacity>
          <View style={styles.inputBox}>
            <TextInput
              value={userMessage}
              onChangeText={setUserMessage}
              style={styles.searchbar}
              placeholder={'Write your message...'}
              placeholderTextColor={colors.light_theme.gray}
              textAlignVertical="center"
            />
            <TouchableOpacity style={styles.sendButton} onPress={handleSendMessage}>
              <Icon name="send" size={20} color={"#fff"} icon_type={"MaterialIcons"} />
            </TouchableOpacity>
          </View>
          {/* <TouchableOpacity style={styles.iconButton}>
                    <Icon icon_type="Ionicons" size={26} color={"#000E08"} name={"mic-outline"} />
                </TouchableOpacity> */}

          <GorhomBottomSheet
            ref={bottomSheetRef}
            height={150}
            closeOnDragDown={true}
            closeOnPressMask={true}
            customStyles={{
              container: styles.sheetContainer,
            }}>
            <View style={styles.sheetContent}>
              <TouchableOpacity style={styles.option} onPress={openCamera}>
                <Icon
                  icon_type={'Feather'}
                  name={'camera'}
                  size={24}
                  color={'#000'}
                />
                <CustomText
                  style={styles.optionText}
                  text={'Camera'}
                  marginTop={5}
                  center
                />
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.option}
                onPress={() => {
                  bottomSheetRef.current.close();
                  ordersSheetRef.current.open();
                }}>
                <Icon
                  icon_type={'MaterialCommunityIcons'}
                  name={'pencil-circle-outline'}
                  size={24}
                  color={'#000'}
                />
                <CustomText
                  style={styles.optionText}
                  text={'Orders'}
                  marginTop={5}
                  center
                />
              </TouchableOpacity>
              {/* <TouchableOpacity
            style={styles.option}
            onPress={() => {
              navigation.navigate('ChatProduct', {
                name,
                item: item,
                uri: 'https://s3-alpha-sig.figma.com/img/fbc1/4c1d/c3a96ba57eb32020d565abdd8b64b19b?Expires=1738540800&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=Ja2u-FVfT-Wa0zev2JMx~TIffwzPrXN~Ni0I8S3gLlTLZ2lgfGa7op5--gKlRomq4GiaZAGpf-zltYZTM~8h1~ZbyUnRry-7Ds8SVeg7s2lcElj3LfWFoffDpPz1h8o4tOp7wF2AC02ReR~~QEK40ujzv0gKeFojkW8MnQMfQaZplhwG82oJrKYxlbwxQr2XnaUZYuP1mrc5bu~6uih-wzOQhm~ebLzTgSipzQpspFjqLGOqXfjt1XDCrLD3elo1886IrugOdGme5meX~ydH3nLTUbO8iLSBh6tFjhxiXyPFqGuTB9NQy5SZXHg4UWZLe2m9zMLPXrGfJ8hgDGq1Vw__',
              });
              bottomSheetRef.current.close();
            }}>
            <Icon
              icon_type={'Feather'}
              name={'watch'}
              size={24}
              color={'#000'}
            />
            <CustomText
              style={styles.optionText}
              text={'Products'}
              marginTop={5}
              center
            />
          </TouchableOpacity> */}
              <TouchableOpacity style={styles.option} onPress={openGallery}>
                <Icon
                  icon_type={'FontAwesome6'}
                  name={'image'}
                  size={24}
                  color={'#000'}
                />
                <CustomText
                  style={styles.optionText}
                  text={'Gallery'}
                  marginTop={5}
                  center
                />
              </TouchableOpacity>
            </View>
          </GorhomBottomSheet>
          <OrdersBottomSheet
            ref={ordersSheetRef}
            orders={orderData}
            buttonText="Send"
            disableSendFunction={true}

          />
        </View>
      </View>

    </View>
  )
}
export default CustomerCare;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "white",
    justifyContent: "space-between",

  },
  questionText: {
    marginHorizontal: margin.horizontal,

  },
  trackingHeading: {
    marginHorizontal: margin.horizontal,

  },
  categoryContainer: {
    flexDirection: "row",
    flexWrap: "wrap",
    marginTop: "5%",
    marginHorizontal: margin.horizontal,
  },
  categoryButton: {
    backgroundColor: "#e0e0e0",
    paddingVertical: "3%",
    paddingHorizontal: "3%",
    borderRadius: 10,
    margin: "1%"
  },
  categoryButtonSelected: {
    backgroundColor: "#5757c9"
    // backgroundColor: colors.dark_theme.theme, 
  },
  questionsContainer: {
    // flexDirection: "row", 
    flexWrap: "wrap",
    marginTop: "2%",
    marginHorizontal: margin.horizontal,
    marginBottom: "2%"
  },
  questionButton: {
    // backgroundColor: "#b2b2b2",
    paddingVertical: "3%",
    paddingHorizontal: "3%",
    borderRadius: 10,
    borderWidth: 1,
    margin: "1%",

  },
  questionButtonSelected: {
    backgroundColor: colors.dark_theme.theme,
  },
  inputContainer: {
    flexDirection: "row",
    alignItems: "center",
    padding: "2%",
    backgroundColor: "white",
    borderTopWidth: 1,
    borderTopColor: "#ddd",
  },
  iconButton: {
    padding: "1%",
  },
  searchbar: {
    flex: 1,
    paddingVertical: "3%",
    fontFamily: font.medium,
    color: "black",
  },
  sendButton: {
    backgroundColor: colors.dark_theme.theme,
    borderRadius: 20,
    padding: "3%",
    marginLeft: "2%",
  },
  iconButton: {
    padding: "2%",
  },
  inputBox: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#F3F6F6",
    borderRadius: 20,
    paddingHorizontal: "2%",
  },
  messageBubble: {
    maxWidth: "75%",
    padding: "3%",
    marginTop: "3%",
    borderRadius: 10,
  },
  outgoingBubble: {
    // backgroundColor: "blue",
    backgroundColor: colors.dark_theme.theme,
    alignSelf: "flex-end",
  },
  incomingBubble: {
    backgroundColor: "#E8E8E8",
    alignSelf: "flex-start",
  },
  sheetContainer: {
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    paddingHorizontal: 20,
    paddingVertical: 10,
    backgroundColor: '#D9D9D9',
    height: height * 0.2,
  },
  sheetContent: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  option: {
    // flexDirection: "row",
    alignItems: 'center',
    paddingVertical: 15,
  },
  optionText: {
    fontSize: 16,
    // marginLeft: 10,
    color: '#000',
  },

})
