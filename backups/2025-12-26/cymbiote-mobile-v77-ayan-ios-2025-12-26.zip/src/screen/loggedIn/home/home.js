import React, {useCallback, useRef, useState, useMemo} from 'react';
import {Dimensions, RefreshControl, StyleSheet, View} from 'react-native';
import {FlashList} from '@shopify/flash-list';

import useHome from './useHome';
import Container from '@materialComponent/container/container';
import Header from '@component/header/header';
import DealDiscount from '../../../component/cards/dealDiscount/dealDiscount';
import RecentlyViewed from '../../../component/cards/recentlyViewed/recentlyViewed';
import PagionationLoader from '@component/loader/endReachLoader';
import HomeLoader from '@component/loader/homeLoader';
import {margin} from '@constant/contstant';
import {_setVideoIndexes} from '../../../redux/actions/common/common';
import {_setHomeScrollPosition} from '../../../redux/actions/common/common';
import {useEventHomeTrigger} from '../../../helper/eventTriggers/useEventTriggers';
import useHomeAnalytics from './useHomeAnalytics';
const {height} = Dimensions.get('screen');

const Home = ({navigation, route}) => {
  const {
    fetch_recent_viewed,
    fetch_store_loader,
    pullLoader,
    search,
    fetchAPI,
    setSearch,
    renderItem,
    paginationAPI,
    paginationLoader,
    storesData,
    handleViewableItemsChanged,
    viewabilityConfigRef,
    isFocused,
    listRef,
    speedCategory,
    whiteBackground,
  } = useHome({navigation});
  useEventHomeTrigger('home', {});

  const {logShopTileView, logShopTileViewEnd, markShopAsClicked} =
    useHomeAnalytics(storesData);

  const flashListConfig = useMemo(
    () => ({
      windowSize:
        speedCategory === 'fast' ? 15 : speedCategory === 'slow' ? 5 : 10,
      estimatedItemSize:
        speedCategory === 'fast' ? 200 : speedCategory === 'slow' ? 150 : 180,
      onEndReachedThreshold:
        speedCategory === 'fast' ? 0.7 : speedCategory === 'slow' ? 0.2 : 0.5,
    }),
    [speedCategory],
  );

  const visibleTilesRef = useRef(new Set());
  const [visibleTiles, setVisibleTiles] = useState(new Set());

  const handleViewableItemsChangedWithAnalytics = useCallback(
    ({viewableItems}) => {
      handleViewableItemsChanged({viewableItems});
      const currentVisibleShopIds = new Set();
      viewableItems.forEach(viewableItem => {
        const shopId = viewableItem.item?.shop_id;
        if (shopId) {
          currentVisibleShopIds.add(shopId);
          if (!visibleTilesRef.current.has(shopId)) {
            console.log('[Home] Shop tile became visible:', {
              shopName: viewableItem.item?.shop_name,
              position: viewableItem.index,
            });
            logShopTileView(viewableItem.item, viewableItem.index);
          }
        }
      });
      visibleTilesRef.current.forEach(shopId => {
        if (!currentVisibleShopIds.has(shopId)) {
          const shopItem = storesData.find(s => s.shop_id === shopId);
          const shopIndex = storesData.findIndex(s => s.shop_id === shopId);
          if (shopItem) {
            logShopTileViewEnd(shopItem, shopIndex);
          }
        }
      });
      visibleTilesRef.current = currentVisibleShopIds;
    },
    [
      handleViewableItemsChanged,
      logShopTileView,
      logShopTileViewEnd,
      storesData,
    ],
  );

  const renderItemWithAnalytics = useCallback(
    ({item, index}) => {
      return renderItem({
        item,
        index,
        logShopTileView,
        logShopTileViewEnd,
        markShopAsClicked,
      });
    },
    [renderItem, logShopTileView, logShopTileViewEnd, markShopAsClicked],
  );

  return (
    <Container
      safeArea={true}
      dark
      isFocused={isFocused}
      barColor={whiteBackground ? 'white' : '#f4f4f4'}>
      <Header
        placeholder="Search Products or Brands"
        value={search}
        onChangeText={setSearch}
        whiteBackground={whiteBackground}
      />
      <View style={styles.mainView}>
        {fetch_store_loader && !pullLoader ? (
          <View style={{paddingHorizontal: margin.horizontal}}>
            <HomeLoader loading={fetch_store_loader} />
          </View>
        ) : (
          <>
            <FlashList
              ref={listRef}
              data={storesData}
              keyExtractor={(item, index) => {
                const key = item?.shop_id ?? item?.shop?.shop_id;
                return key ? key.toString() : `fallback-key-${index}`;
              }}
              windowSize={flashListConfig.windowSize}
              estimatedItemSize={flashListConfig.estimatedItemSize}
              renderItem={renderItemWithAnalytics}
              showsVerticalScrollIndicator={false}
              nestedScrollEnabled
              onViewableItemsChanged={handleViewableItemsChangedWithAnalytics}
              viewabilityConfig={viewabilityConfigRef.current}
              scrollEventThrottle={16}
              contentContainerStyle={{
                paddingBottom: height * 0.2,
                backgroundColor: 'white',
              }}
              ListHeaderComponent={
                <View style={{}}>
                  <DealDiscount marginTop={height * 0.02} />
                  <RecentlyViewed
                    marginTop={height * 0.02}
                    data={fetch_recent_viewed}
                  />
                </View>
              }
              ListFooterComponent={
                paginationLoader ? (
                  <View
                    style={{
                      justifyContent: 'center',
                      alignItems: 'center',
                      paddingVertical: 20,
                    }}>
                    <PagionationLoader />
                  </View>
                ) : null
              }
              onEndReached={paginationAPI}
              onEndReachedThreshold={flashListConfig.onEndReachedThreshold}
              refreshControl={
                <RefreshControl
                  refreshing={pullLoader}
                  onRefresh={() => fetchAPI(false)}
                />
              }
            />
          </>
        )}
      </View>
    </Container>
  );
};

export default Home;

const styles = StyleSheet.create({
  mainView: {
    flex: 1,
  },
});
