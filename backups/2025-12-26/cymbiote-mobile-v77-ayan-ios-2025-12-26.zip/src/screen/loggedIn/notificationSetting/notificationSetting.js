import { Dimensions, StatusBar, StyleSheet, View } from 'react-native';
import React, { useState } from 'react';
import InnerHeader from '@component/header/innerHeader';
import { margin } from '@constant/contstant';
import Toggle from '@materialComponent/toggle/toggle';
import ProfileItem from '@component/cards/profileItem/profileItem';
import Content from '../../../materialComponent/content/content';
import { font } from '../../../constant/contstant';
import useNotificationSetting from './useNotificationSetting';
import Container from '../../../materialComponent/container/container';

const { height, fontScale } = Dimensions.get('screen');

const NotificationSetting = ({ route }) => {
  const { fetch_user_details } = useNotificationSetting({});
  return (
    <Container barColor={"white"}>
      <View style={[styles.mainView]}>
        <InnerHeader title={'Notifications'} />
        <Content>
          <View style={styles.content}>
            {data.map((item, index) => {
              return (
                <>
                  {item.toggle ? (
                    <Toggle
                      text={item.desc}
                      marginTop={index == 0 ? height * 0.02 : height * 0.03}
                      item={item}
                    />
                  ) : (
                    <ProfileItem
                      fontSize={fontScale * 15}
                      marginTop={height * 0.036}
                      item={item}
                      data={[]}
                    />
                  )}
                </>
              );
            })}
          </View>
        </Content>
      </View>
    </Container>

  );
};

export default NotificationSetting;

const styles = StyleSheet.create({
  mainView: {
    flex: 1,
    backgroundColor: 'white',
  },
  content: {
    marginHorizontal: margin.horizontal,
  },
});

const data = [
  {
    toggle: true,
    desc: 'Offers and updates',
    db_value: 'notification_setting_offers_n_updates',
  },
  {
    toggle: true,
    desc: 'Mesages',
    db_value: 'notification_setting_offers_n_updates',
  },
  {
    option_name: 'Tracking',
    screen: 'TrackingNotificationSetting',
  },
  {
    option_name: 'Shopping',
    screen: 'ShoppingNotificationSetting',
  },
];
