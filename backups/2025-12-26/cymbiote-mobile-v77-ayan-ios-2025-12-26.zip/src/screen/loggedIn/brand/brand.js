import React, {useState} from 'react';
import {StyleSheet, View, StatusBar} from 'react-native';
import {moderateScale, verticalScale} from 'react-native-size-matters';
import {colors, globalStyle, margin, WH} from '@constant/contstant';
import {handleScroll} from '@utils/helper/helper';
import useBrand from './useBrand';
import GlobalLoader from '@component/loader/globalLoader';
import BrandContent from '@component/brandContent/brandContent';
import BrandLoader from '../../../component/loader/brandLoader';
import {useEventMerchantTrigger} from '../../../helper/eventTriggers/useEventTriggers';

const Brand = ({disabled, route}) => {
  const {
    paginationAPI,
    paginationLoader,
    fetch_store_products,
    fetch_store_products_loader,
    shop,
    shopsReels,
    handleSelectCollection,
    selectedCollectionId,
    collectionProducts,
    collectionLoading,
    subCategories,
    setCollectionLoading,
    mainLoader,
    selectedSubCategory,
  } = useBrand({route});
  const [showLoader] = useState(false);

 
  // console.log("fetch_store_products", (fetch_store_products?.data?.productCategories || []).length > 0 ? fetch_store_products?.data?.productCategories : subCategories?.length > 0 ? subCategories : [])

  useEventMerchantTrigger('shop', {
    merchant_id: shop?.shop_id,
    merchant_name: shop?.shop_name,
    merchant_shopify_id: shop?.shop_shopify_id,
  });


  return fetch_store_products_loader ? (
    <GlobalLoader />
  ) : (
    <View style={{flex: 1, backgroundColor: shop?.shop_color || 'white'}}>
      <StatusBar
        animated
        translucent
        backgroundColor="transparent"
        barStyle="dark-content"
      />

      {mainLoader ? (
        <BrandLoader loading={true} />
      ) : (
        <BrandContent
          shop={shop}
          upadatedShop={fetch_store_products?.data?.shop}
          products={fetch_store_products?.data?.products || []}
          fetch_store_products={fetch_store_products}
          sub_category={
            selectedCollectionId
              ? subCategories
              : fetch_store_products?.data?.productCategories || []
          }
          shopsReels={shopsReels}
          selectedSubCategory={selectedSubCategory}
          paginationAPI={paginationAPI}
          paginationLoader={paginationLoader}
          handleSelectCollection={handleSelectCollection}
          selectedCollectionId={selectedCollectionId}
          collectionProducts={collectionProducts}
          collectionLoading={collectionLoading}
          setCollectionLoading={setCollectionLoading}
          showProducts={
            selectedCollectionId
              ? collectionProducts
              : fetch_store_products?.data?.products
          }
        />
      )}
    </View>
  );
};

export default Brand;

const styles = StyleSheet.create({
  backgroundImage: {
    height: WH.height(45),
    width: '100%',
    marginTop: -WH.height('5%'),
  },
  bar: {
    marginTop: verticalScale(40),
    ...globalStyle.row,
    alignSelf: 'flex-end',
    marginHorizontal: margin.horizontal,
    position: 'static',
    right: 0,
  },
  iconView: {
    backgroundColor: 'rgba(0,0,0,0.4)',
    height: WH.height(5),
    aspectRatio: 1 / 1,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: moderateScale(10),
    marginLeft: moderateScale(5),
  },
  content: {
    paddingHorizontal: margin.horizontal,
    marginTop: -20,
    backgroundColor: 'white',
    borderTopRightRadius: moderateScale(20),
    borderTopLeftRadius: moderateScale(20),
  },
  line: {
    backgroundColor: colors.light_theme.darkBorderColor,
    height: verticalScale(5),
    alignSelf: 'center',
    width: '10%',
    marginTop: verticalScale(20),
    borderRadius: 180,
  },
  video_view: {
    justifyContent: 'center',
    alignItems: 'center',
    position: 'absolute',
    height: '100%',
    width: '100%',
    zIndex: 0,
    bottom: 0,
    right: 0,
    left: 0,
    top: 0,
  },
});
