import {_getStores, _getStoreProducts} from '@redux/actions/merchant/merchant';
import {
  useCallback,
  useEffect,
  useLayoutEffect,
  useMemo,
  useState,
} from 'react';
import HomeDualCard from '@component/cards/homeDualCard';
import {_recentViewed} from '@redux/actions/user/user';
import useReduxStore from '@utils/hooks/useReduxStore';
import {pagination} from '@utils/helper/helper';
import {WH} from '@constant/contstant';
import {View} from 'react-native';
import {
  _getFilteredByCollectionId,
  _getShopCollections,
} from '../../../redux/actions/merchant/merchant';
import {_getMerchantReels} from '../../../redux/actions/reels/reels';
import {FETCH_FILTER_COLLECTION} from '../../../redux/types/merchant/merchant';

const useBrand = ({route}) => {
  const {shop_id, shop} = route?.params;
  const {dispatch, getState} = useReduxStore();
  const {fetch_store_products, fetch_store_products_loader} =
    getState('merchant');
  const {fetch_user_detail} = getState('auth');
  const {shopsReels} = getState('reels');
  const [shopReelsLoading, setShopReelsLoading] = useState(false);
  const [selectedCollectionId, setSelectedCollectionId] = useState(null);
  const [selectedSubCategory, setSelectedSubCategory] = useState(null);
  const [collectionProducts, setCollectionProducts] = useState([]);
  const [subCategories, setSubCategories] = useState([]);
  const [collectionLoading, setCollectionLoading] = useState(false);
  const [collectionPage, setCollectionPage] = useState(1);
  const [collectionTotalPages, setCollectionTotalPages] = useState(1);
  const [mainLoader, setMainLoader] = useState(true);

  const [products, setProducts] = useState([]);

  const [pullLoader, setPullLoader] = useState(false);
  const [paginationLoader, setPaginationLoader] = useState(false);
  const [isFetchedShopReels, setIsFetchedShopReels] = useState(false);

  const [page, setPage] = useState(1);

  const fetchAPI = async isLoading => {
    dispatch(_recentViewed(fetch_user_detail?.id, 'shop', shop_id, ''));
    !isLoading && setPullLoader(true);
    setMainLoader(true);
    await dispatch(_getStoreProducts(shop_id, page));
    await dispatch(_getShopCollections(shop_id));
    setPullLoader(false);
    setMainLoader(false);
  };
  const fetchMerchantReels = useCallback(async () => {

    // if (!shopReelsLoading) {
    // setShopReelsLoading(true);

    // setPaginationLoader(true);
    await dispatch(_getMerchantReels({shopId: shop_id}));
    // setPaginationLoader(!paginationLoader);
    setShopReelsLoading(false);
    // }
  }, [dispatch]);
  const paginationAPI = async () => {

    if (selectedCollectionId) {
      const nextPage = pagination(collectionPage, collectionTotalPages);
      if (nextPage && !paginationLoader) {
        setPaginationLoader(true);
        const {products, productCategories} = await dispatch(
          _getFilteredByCollectionId(
            selectedCollectionId,
            nextPage,
            selectedSubCategory,
            shop_id,
          ),
        );

        setSubCategories(productCategories);
        setCollectionPage(nextPage);
        setCollectionProducts(prev => [...prev, ...products]);
        setPaginationLoader(false);
      }
    } else {
      const totalPages = fetch_store_products?.pagination?.totalPages;
      const nextPage = pagination(page, totalPages);
      if (nextPage && !paginationLoader) {

        setPaginationLoader(true);
        await dispatch(_getStoreProducts(shop_id, nextPage));
        setPage(nextPage);
        setPaginationLoader(false);
      }
    }
  };
  const handleSelectCollection = async (collectionId, subCategory) => {

    if (collectionId === 'ALL' && !subCategory) {
      setSelectedCollectionId(null);
      setSelectedSubCategory(null);
      setCollectionProducts([]);
      // setSubCategories([])
      return;
    }

    try {
      setSelectedCollectionId(collectionId);
      setSelectedSubCategory(subCategory);
      // setSubCategories([]);
      setCollectionLoading(true);
      setCollectionPage(1);
      const {products, pagination, productCategories} = await dispatch(
        _getFilteredByCollectionId(
          collectionId,
          1,
          subCategory,
          collectionId == 'ALL' && !Boolean(collectionId) ? '' : shop_id,
          true,
        ),
      );
 
      !subCategory && setSubCategories(productCategories);
      setCollectionProducts(products);
      setCollectionTotalPages(pagination.totalPages);
    } catch (error) {
      console.error('Error loading filtered collection:', error?.message);
    } finally {
      setCollectionLoading(false);
    }
  };

  useEffect(() => {
    fetchAPI(true);
  }, [shop_id]);

  useEffect(() => {
    fetchMerchantReels();
  }, [fetchMerchantReels]);

  useEffect(() => {
    if (fetch_store_products?.data?.products) {
      // setProducts([]);
      setProducts(fetch_store_products?.data?.products);
      setSubCategories(fetch_store_products?.data?.productCategories);
    }
  }, [fetch_store_products, shop_id]);


  const renderProduct = useCallback(({item}) => {
    return (
      <View style={{marginRight: WH.width('2')}}>
        <HomeDualCard item={item} width={WH.width('43')} color={'black'} />
      </View>
    );
  }, []);
  return {
    fetchAPI,
    renderProduct,
    paginationAPI,
    products,
    paginationLoader,
    fetch_store_products,
    fetch_store_products_loader,
    pullLoader,
    shop,
    shopsReels,
    handleSelectCollection,
    selectedCollectionId,
    collectionProducts,
    collectionLoading,
    setCollectionLoading,
    subCategories,
    mainLoader,
    selectedSubCategory,
  };
};

export default useBrand;
