import React, { useState, useEffect, useRef } from "react";
import { View, StatusBar, StyleSheet, TouchableOpacity, FlatList, Image, Dimensions, TextInput } from "react-native";
import CustomText from "../../../materialComponent/customText/customText";
import { useNavigation } from "@react-navigation/native";
import Icon from "../../../materialComponent/icon/icon";
import { colors, font, margin } from "../../../constant/contstant";
import HelpCenterHeader from "../../../component/header/helpCenterHeader";
import OrderItem from "../../../component/Chat/orderItem";
import RatingBottomSheet from "../../../component/helpCenter/ratingBottomSheet";
import ReviewSummaryBottomSheet from "../../../component/helpCenter/reviewSummaryBottomSheet ";
import CustomImage from "../../../materialComponent/image/image";
import images from "../../../assets/images/images";
import HelpSvg from "@assets/images/help.svg"

const { fontScale, width, height } = Dimensions.get("screen")
const ChatBot = ({ route }) => {
    const navigation = useNavigation();
    const [messages, setMessages] = useState([]);
    const selectedOrder = route.params?.selectedOrder || null;
    const selectedQuestion = route.params?.selectedQuestion || null;
    const [rating, setRating] = useState(0);
    const [showRedirectMessage, setShowRedirectMessage] = useState(false);
    const [chatStarted, setChatStarted] = useState(false);
    const [textInput, setTextInput] = useState("");
    const reviewSheetRef = useRef(null);
    const reviewSummaryRef = useRef(null);

    // Debugging Logs

    const handleRatingSubmit = (selectedRating) => {
        setRating(selectedRating); 
        startRedirectToRepresentative();
    };
    const handleNoClick = () => {
        startRedirectToRepresentative();
    };

    useEffect(() => {
        if (rating > 0) {
            setTimeout(() => {
                reviewSummaryRef.current.open();
            }, 500);
        }
    }, [rating]);
    const handleShowSummary = () => {
        reviewSheetRef.current.close();
    };


    useEffect(() => {
        if (selectedOrder && selectedOrder.orderId) {
            const questionMessage = {
                id: Date.now().toString() + "-q",
                type: "question",
                text: selectedQuestion || "",
                isOutgoing: true,
                time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
            };

            const orderMessage = {
                id: Date.now().toString() + "-o",
                type: "order",
                order: selectedOrder,
                isOutgoing: true,
                time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
            };

            setMessages([questionMessage, orderMessage]);
        }
    }, []);

    const startRedirectToRepresentative = () => {
        setShowRedirectMessage(true);

        // Show redirect message for 1 second, then remove it and show representative message
        setTimeout(() => {
            setShowRedirectMessage(false);

            setTimeout(() => {
                setChatStarted(true);

                const repMessage = {
                    id: Date.now().toString() + "-rep",
                    type: "text",
                    text: "Hello! John, how can I help you?",
                    isOutgoing: false,
                    time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
                    sender: {
                        name: "James Andreson",
                        profileImage: "https://yourimageurl.com/james.png", // Replace with actual URL
                    }
                };

                setMessages((prevMessages) => [...prevMessages, repMessage]);
            }, 1000); // Delay before showing the representative's message
        }, 1000); // Remove redirect message after 1 second
    };

    const handleSendTextMessage = () => {
        if (textInput.trim().length === 0) return;

        const userMessage = {
            id: Date.now().toString(),
            type: "text",
            text: textInput,
            isOutgoing: true,
            time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        };

        setMessages((prevMessages) => [...prevMessages, userMessage]);
        setTextInput(""); // Clear input field
    };

    const renderMessage = ({ item }) => {
        if (item.type === "question") {
            return (
                <View>
                <View style={[styles.messageBubble, styles.outgoingBubble]}>
                    <CustomText text={item.text} fontSize={16} fontFamily={font.bold} color="white" />
                    
                </View>
                <CustomText text={item.time} fontSize={fontScale * 12} color={"#797C7B"} textAlign={item.isOutgoing ? "right" : "center"} marginTop={5} fontFamily={font.regular}  style={styles.time}/>
                </View>
            );
        }
            
        
        if (item.type === "order" && item.order) {
            return (
                <View style={styles.orderContainer}>
                    <OrderItem
                        orderId={item.order.orderId}
                        status={item.order.status}
                        itemCount={item.order.itemsCount}
                        images={item.order.images}

                    />
                      <CustomText
             text={"Your order has been successfully shipped and is on its way! We’re pleased to inform you that it is expected to be delivered within the time frame we provided. You can track your order's progress at any time through the app for real-time updates. Rest assured, our delivery team is working hard to ensure your package arrives safely and on time. Thank you for shopping with us!"}
             marginTop={height * 0.01} fontSize={fontScale * 16} fontFamily={font.light} style={styles.botText}
             />
{ !showRedirectMessage && !chatStarted && (
    <View style={styles.helpfullView}>
                
                <CustomText text={"Was this Helpfull?"}   marginTop={height * 0.01} fontSize={fontScale * 16} fontFamily={font.bold}  style={styles.botText}/>
                <TouchableOpacity onPress={() => {
                       
                        reviewSheetRef.current.open();
                    }} >
                <CustomText text={"Yes"}  marginTop={height * 0.01} fontSize={fontScale * 16} fontFamily={font.medium}style={styles.botText} />
                </TouchableOpacity>
                <CustomText text={"or   "}  marginTop={height * 0.01} fontSize={fontScale * 16} fontFamily={font.medium}  />
                <TouchableOpacity onPress={handleNoClick}>
                <CustomText text={"NO"}  marginTop={height * 0.01} fontSize={fontScale * 16} fontFamily={font.medium} style={styles.botText} />
                </TouchableOpacity>
             </View>
)}
 {showRedirectMessage && (
                        <CustomText text={"We are redirecting your complaint to our representative..."} fontSize={16} fontFamily={font.bold} marginTop={10} />
                    )}
          
 </View>
            );
        }
        if (item.sender) {
            return (
                <>
                <CustomText text={"Chat with our Representative"} textAlign={"center"} marginTop={20} fontFamily={font.bold}/>
                <View style={styles.repMessageContainer}>
                    {/* <Image source={require("../../../assets/images/avatar2.png")} style={styles.repProfileImage} /> */}
                  
                    <CustomImage source={images.CrAvatar}  style={styles.repProfileImage}/>
                    <CustomText text={item.sender.name} fontSize={14} fontFamily={font.bold} />
                 
                </View>
                <View>
                       
                       <View style={[styles.messageBubble, styles.incomingBubble]}>
                           <CustomText text={item.text} fontSize={16} fontFamily={font.regular} />
                       </View>
                       <CustomText text={item.time} fontSize={12} color={"#797C7B"} textAlign={"center"} style={styles.timeText}  />
                   </View>
                </>
            );
        }

     
        return (
            <>
              <View style={[styles.messageBubble, item.isOutgoing ? styles.outgoingBubble : styles.incomingBubble]}>
                <CustomText text={item.text} fontSize={16} fontFamily={font.regular} color={item.isOutgoing ? "white" : "black"} />
       
            </View>
            <CustomText text={item.time} fontSize={12} color={"#797C7B"} textAlign={item.isOutgoing ? "right" : "left"} />
            </>
          
        );
    };

    return (
        <View style={styles.container}>
            <StatusBar animated barStyle={"dark-content"} backgroundColor={"white"} translucent={false} />
            <HelpCenterHeader borderLine={1} 
             onBackPress={() => navigation.navigate("OrderManagemanet")} 
           
             title={"Help Center"} IconComponent={HelpSvg}/>
            <CustomText text={"Hi, I'm your Cymbiote Virtual Assistant – here to help you with anything you need!"}
        fontSize={fontScale *18} fontFamily={font.light} style={styles.questionText} marginTop={height * 0.02}/>
            <FlatList
                data={messages}
                keyExtractor={(item) => item.id}
                renderItem={renderMessage}
                contentContainerStyle={{ padding: 15 }}
            />
             <View style={styles.inputContainer}>
                <TouchableOpacity style={styles.iconButton} >
                    <Icon icon_type={"Entypo"} size={24} color={"#000E08"} name={"attachment"} />
                </TouchableOpacity>
                <View style={styles.inputBox}>
                    <TextInput
                      value={textInput}
                      onChangeText={setTextInput}
                        style={styles.searchbar}
                        placeholder={'Write your message...'}
                        placeholderTextColor={colors.light_theme.gray}
                        textAlignVertical="center"
                    />
                    <TouchableOpacity  style={styles.sendButton} onPress={handleSendTextMessage}>
                        <Icon name="send" size={20} color={"#fff"} icon_type={"MaterialIcons"} />
                    </TouchableOpacity>
                </View>
                <TouchableOpacity style={styles.iconButton}>
                    <Icon icon_type="Ionicons" size={26} color={"#000E08"} name={"mic-outline"} />
                </TouchableOpacity>
            </View>
            
            <RatingBottomSheet 
                ref={reviewSheetRef} 
                onSubmit={handleRatingSubmit} 
                onShowSummary={handleShowSummary} 
            />

            <ReviewSummaryBottomSheet ref={reviewSummaryRef} rating={rating} />

        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: "white"
    },
    messageBubble: {
        // maxWidth: "75%",
        borderBottomEndRadius: 10,
        borderBottomLeftRadius: 10,
        borderTopRightRadius: 10,
        padding: 10,
        // marginHorizontal: margin.horizontal,
        marginTop:height *0.01
    },
    outgoingBubble: {
        backgroundColor: colors.dark_theme.theme,
        alignSelf: "flex-end",
    },
    time:{
        marginHorizontal:margin.horizontal
    },
    orderContainer: {
        backgroundColor: "white",
       
        marginTop: 10,
      
    },
    image: {
        width: 50,
        height: 50,
        marginRight: 5,
        borderRadius: 8,
    },
    botText:{
        marginHorizontal:"2%"
    },
    questionText:{
        marginHorizontal:margin.horizontal,
       
   },
     inputContainer: {
           flexDirection: "row",
           alignItems: "center",
           padding: 10,
           backgroundColor: "white",
           borderTopWidth: 1,
           borderTopColor: "#ddd",
       },
       inputBox: {
           flex: 1,
           flexDirection: "row",
           alignItems: "center",
           backgroundColor: "#F3F6F6",
           borderRadius: 20,
           paddingHorizontal: 10,
       },
       searchbar: {
           flex: 1,
           paddingVertical: 8,
           fontFamily: font.medium,
           color: "black",
       },
       sendButton: {
           backgroundColor: colors.dark_theme.theme,
           borderRadius: 20,
           padding: 8,
           marginLeft: 5,
       },
       iconButton: {
           padding: 5,
       },
       helpfullView:{
        flexDirection:"row",
        alignItems:"center",
        // borderWidth:1
        
       },
       repProfileImage: {  width: width * 0.15,
        // height: 50,
        aspectRatio: 1,
        // borderRadius: 10,
        // borderWidth:1,
        marginRight: 8,
        backgroundColor: "#fff", 
        
    },
       repMessageContainer: { flexDirection: "row", alignItems: "center",  },
       incomingBubble: { backgroundColor: "#E8E8E8", alignSelf: "center",bottom:20 },
       timeText:{
        marginLeft:width * 0.4,
        bottom:12  
       }
    
});

export default ChatBot;

// import React, { useState, useEffect, useRef } from "react";
// import { View, StatusBar, StyleSheet, TouchableOpacity, FlatList, TextInput, Animated,Dimensions } from "react-native";
// import CustomText from "../../../materialComponent/customText/customText";
// import { useNavigation } from "@react-navigation/native";
// import Icon from "../../../materialComponent/icon/icon";
// import { colors, font, margin } from "../../../constant/contstant";
// import HelpCenterHeader from "../../../component/header/helpCenterHeader";
// import OrderItem from "../../../component/Chat/orderItem";
// import RatingBottomSheet from "../../../component/helpCenter/ratingBottomSheet";

// const { fontScale, width, height } = Dimensions.get("screen");

// const ChatBot = ({ route }) => {
//     const navigation = useNavigation();
//     const [messages, setMessages] = useState([]);
//     const [showChatInput, setShowChatInput] = useState(false);
//     const [showRedirectMessage, setShowRedirectMessage] = useState(false);
//     const reviewSheetRef = useRef(null);
//     const redirectSheetRef = useRef(null);
//     const fadeAnim = useRef(new Animated.Value(0)).current;

//     const selectedOrder = route.params?.selectedOrder || null;
//     const selectedQuestion = route.params?.selectedQuestion || null;

//     useEffect(() => {
//         if (selectedOrder && selectedOrder.orderId) {
//             const questionMessage = {
//                 id: Date.now().toString() + "-q",
//                 type: "question",
//                 text: selectedQuestion || "",
//                 isOutgoing: true,
//                 time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
//             };

//             const orderMessage = {
//                 id: Date.now().toString() + "-o",
//                 type: "order",
//                 order: selectedOrder,
//                 isOutgoing: true,
//                 time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
//             };

//             setMessages([questionMessage, orderMessage]);
//         }
//     }, []);

//     const handleNoClick = () => {
//         setShowRedirectMessage(true);
//         setTimeout(() => {
//             setShowRedirectMessage(false);
//             setShowChatInput(true);
//             setMessages(prevMessages => [...prevMessages, {
//                 id: Date.now().toString() + "-rep",
//                 type: "representative",
//                 text: "Hello! How can I help you?",
//                 isOutgoing: false,
//                 time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
//             }]);
//         }, 1000);
//     };

//     return (
//         <View style={styles.container}>
//             <StatusBar animated barStyle="dark-content" backgroundColor="white" translucent={false} />
//             <HelpCenterHeader borderLine={1} navigation={navigation} />
//             <FlatList data={messages} keyExtractor={(item) => item.id} renderItem={({ item }) => (
//                 <View style={styles.messageContainer}>
//                     <CustomText text={item.text} fontSize={16} fontFamily={font.bold} color={item.isOutgoing ? "blue" : "black"} />
//                 </View>
//             )} />
            
//             <View style={styles.helpfullView}>
//                 <CustomText text={"Was this Helpful?"} fontSize={fontScale * 16} fontFamily={font.bold} style={styles.botText} />
//                 <TouchableOpacity onPress={() => reviewSheetRef.current.open()}>
//                     <CustomText text={"Yes"} fontSize={fontScale * 16} fontFamily={font.medium} style={styles.botText} />
//                 </TouchableOpacity>
//                 <TouchableOpacity onPress={handleNoClick}>
//                     <CustomText text={"No"} fontSize={fontScale * 16} fontFamily={font.medium} style={styles.botText} />
//                 </TouchableOpacity>
//             </View>
            
//             {showRedirectMessage && (
//                 <CustomText text={"We are redirecting your complaint to our customer representative..."} fontSize={fontScale * 16} fontFamily={font.bold} />
//             )}
            
//             {showChatInput && (
//                 <View style={styles.chatContainer}>
//                     <CustomText text={"Chat with our representative"} fontSize={fontScale * 16} fontFamily={font.bold} />
//                     <View style={styles.inputContainer}>
//                         <TextInput style={styles.searchbar} placeholder="Write your message..." placeholderTextColor={colors.light_theme.gray} textAlignVertical="center" />
//                         <TouchableOpacity style={styles.sendButton}>
//                             <Icon name="send" size={20} color="white" icon_type="MaterialIcons" />
//                         </TouchableOpacity>
//                     </View>
//                 </View>
//             )}
            
//             <RatingBottomSheet refRBSheet={reviewSheetRef} onSubmit={() => reviewSheetRef.current.close()} />
//         </View>
//     );
// };

// const styles = StyleSheet.create({
//     container: { flex: 1, backgroundColor: "white" },
//     chatContainer: { padding: 15, borderTopWidth: 1, borderColor: "#ddd" },
//     inputContainer: { flexDirection: "row", alignItems: "center", padding: 10, backgroundColor: "white", borderTopWidth: 1, borderTopColor: "#ddd" },
//     searchbar: { flex: 1, paddingVertical: 8, fontFamily: font.medium, color: "black" },
//     sendButton: { backgroundColor: colors.dark_theme.theme, borderRadius: 20, padding: 8, marginLeft: 5 },
// });

// export default ChatBot;
