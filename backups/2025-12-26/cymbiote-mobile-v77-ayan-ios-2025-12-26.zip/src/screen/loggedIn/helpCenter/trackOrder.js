import { StatusBar, StyleSheet, View,Dimensions, TouchableOpacity, Alert } from "react-native"
import CustomText from "../../../materialComponent/customText/customText"
import HelpCenterHeader from "../../../component/header/helpCenterHeader";
import { colors, font, margin } from "../../../constant/contstant";
import CustomButton from "../../../materialComponent/customButton/customButton";
import { useRef, useState } from "react";
import images from "../../../assets/images/images";
import OrdersBottomSheet from "../../../component/Chat/ordersBottomSheet";
import HelpSvg from "@assets/images/help.svg"   

const { width, height, fontScale } = Dimensions.get("screen")
const orderData = [
    {
        id: "1",
        orderId: "#92287157",
        status: "Shipped",
        itemsCount: "4",
        images: [images.t_shirt, images.t_shirt, images.t_shirt, images.t_shirt],
    },
    {
        id: "2",
        orderId: "#9977866",
        status: "Delivered",
        itemsCount: "3",
        images: [images.t_shirt, images.t_shirt, images.t_shirt,images.t_shirt]
    }
]

const trackingOptions = [
    "When it will be delivered",
    "Where is my order",
    "how much more time",
    "where is it right now"
  ];

const TrackOrder=({navigation})=>{
        const ordersSheetRef = useRef(null);
        const [selectedOrder, setSelectedOrder] = useState(null);
        const [messages, setMessages] = useState([]);
        const [selectedQuestion, setSelectedQuestion] = useState(null);
        const [error, setError] = useState(null); 
        const handleSendOrder = (order) => {
            if (!selectedQuestion) {
                Alert.alert(
                    "Selection Required",
                    "Please select a question before proceeding.",
                    [{ text: "OK", style: "cancel" }]
                );
                return;
            }
            navigation.navigate("ChatBot", { selectedOrder: order, selectedQuestion: selectedQuestion });
            ordersSheetRef.current.close();
        };
    return(
        <View style={styles.container}>

        <View>
        <StatusBar animated barStyle={"dark-content"} backgroundColor={"white"} translucent={false} />
        <HelpCenterHeader borderLine={1} navigation={navigation} title={"Help Center"} IconComponent={HelpSvg}/>
        <CustomText text={"Hi, I'm your Cymbiote Virtual Assistant – here to help you with anything you need!"}
        fontSize={fontScale *14} fontFamily={font.light} style={styles.questionText} marginTop={height * 0.02}/>
</View>

<View>
        <CustomText text={"Tracking Your Order"}  fontSize={fontScale * 21} style={styles.trackingHeading} fontFamily={font.bold}/>
        <CustomText text={"Tracking your order is easy and ensures you stay updated every step of the way. Once your order is placed and processed, you can monitor its status directly through our app. To track your order:"}
         marginTop={height * 0.01} fontSize={fontScale * 12} style={styles.trackingHeading} fontFamily={font.light}/>
          <View style={styles.questionsView}>
        {trackingOptions.map((option, index) => (
          <TouchableOpacity
            key={index}
            style={[
                styles.questionsBox,
                selectedQuestion === option ? styles.selectedQuestion : null // ✅ Highlight selected question
              ]}
              onPress={() => setSelectedQuestion(option)}
          >
            <CustomText text={option}  fontSize={fontScale * 14} fontFamily={font.medium} color={selectedQuestion === option ? "white": ""} />
          </TouchableOpacity>
        ))}
      </View>
      
      <CustomButton text={"Next"} buttonStyle={styles.nextButton}  onPress={() => {
                        
                        ordersSheetRef.current.open();
                    }}/>
                    </View>
                     <OrdersBottomSheet ref={ordersSheetRef} orders={orderData} buttonText="Send" onSend ={handleSendOrder}/>
        </View>
    )
}


const styles = StyleSheet.create({
    container:{
        flex:1,
        backgroundColor:"white",
        justifyContent:"space-between",
        // marginVertical:"4%"
    },
    questionText:{
         marginHorizontal:margin.horizontal,
        
    },
    trackingHeading:{
        marginHorizontal:margin.horizontal,
        
    },
    questionsBox:{
        backgroundColor: "#e0e0e0",
         paddingVertical: "3%", 
         paddingHorizontal: "3%", 
         borderRadius: 10, 
         margin: "1%"
    },
    questionsView:{ 
    flexDirection: "row", 
    flexWrap: "wrap", 
    marginTop: "5%",
    marginHorizontal:margin.horizontal,
    },
    selectedQuestion: { backgroundColor: "#5757c9" },
    nextButton:{
        marginHorizontal:margin.horizontal,
        margin:"3%"
    },
    messageContainer: {
        backgroundColor: "#f2f2f2",
        padding: 10,
        borderRadius: 10,
        marginVertical: 5,
      },
})
export default TrackOrder;


// import React, { useRef, useState } from "react";
// import { View, StatusBar, TouchableOpacity, Dimensions, StyleSheet } from "react-native";
// import CustomText from "../../../materialComponent/customText/customText";
// import HelpCenterHeader from "../../../component/header/helpCenterHeader";
// import CustomButton from "../../../materialComponent/customButton/customButton";
// import OrdersBottomSheet from "../../../component/Chat/ordersBottomSheet";
// import { font, margin } from "../../../constant/contstant";
// import images from "../../../assets/images/images";
// import { useNavigation } from "@react-navigation/native";

// const { width, height, fontScale } = Dimensions.get("screen");

// const orderData = [
//     {
//       id: "1",
//       orderId: "#92287157",
//       status: "Shipped",
//       itemsCount: "4",
//       images: [images.t_shirt, images.t_shirt, images.t_shirt, images.t_shirt],
//     },
//     {
//       id: "2",
//       orderId: "#9977866",
//       status: "Delivered",
//       itemsCount: "3",
//       images: [images.t_shirt, images.t_shirt, images.t_shirt, images.t_shirt],
//     }
//   ];
  
//   const trackingOptions = [
//     "When it will be delivered",
//     "Where is my order",
//   ];
  
//   const TrackOrder = ({ navigation }) => {
//     const ordersSheetRef = useRef(null);
//     const [selectedQuestion, setSelectedQuestion] = useState(null);
    
//     const handleSendOrder = (order) => {
//         // Ensure only JSON-safe data is passed
//         const safeOrder = {
//             id: order?.id || "",
//             orderId: order?.orderId || "Unknown Order",
//             status: order?.status || "Unknown Status",
//             itemsCount: order?.itemsCount || "0",
//             images: order?.images?.map((img) => (typeof img === "string" ? img : "")) || [],
//         };
    
//         navigation.navigate("ChatBot", { selectedOrder: safeOrder });
//         ordersSheetRef.current.close();
//     };
    
  
//     return (
//       <View style={{ flex: 1, backgroundColor: "white", paddingHorizontal: 15 }}>
//         <StatusBar animated barStyle={"dark-content"} backgroundColor={"white"} translucent={false} />
//         <HelpCenterHeader borderLine={1} navigation={navigation} />
        
//         <CustomText
//           text={"Hi, I'm your Cymbiote Virtual Assistant – here to help you with anything you need!"}
//           fontSize={fontScale * 18}
//           fontFamily={font.light}
//           style={{ marginHorizontal: margin.horizontal, marginTop: 20 }}
//         />
        
//         <CustomText text={"Tracking Your Order"} fontSize={fontScale * 22} style={styles.trackingHeading} fontFamily={font.bold} />
//         <CustomText text={"Tracking your order is easy. You can monitor its status through our app."} fontSize={fontScale * 16} style={styles.trackingHeading} fontFamily={font.light} />
        
//         {/* Tracking Questions */}
//         <View style={styles.questionsView}>
//           {trackingOptions.map((option, index) => (
//             <TouchableOpacity
//               key={index}
//               style={[styles.questionsBox, selectedQuestion === option ? styles.selectedQuestion : null]}
//               onPress={() => setSelectedQuestion(option)}
//             >
//               <CustomText text={option} fontSize={fontScale * 18} fontFamily={font.medium} />
//             </TouchableOpacity>
//           ))}
//         </View>
        
//         <CustomButton text={"Next"} buttonStyle={styles.nextButton} marginTop={30} onPress={() => ordersSheetRef.current.open()} />
        
//         {/* Orders Bottom Sheet */}
//         <OrdersBottomSheet ref={ordersSheetRef} orders={orderData} buttonText="Send" onSend={handleSendOrder} />
//       </View>
//     );
//   };
  
//   const styles = StyleSheet.create({
//     trackingHeading: {
//       marginTop: height * 0.02,
//     },
//     questionsView: {
//       flexDirection: "row",
//       flexWrap: "wrap",
//       marginTop: 15,
//     },
//     questionsBox: {
//       backgroundColor: "#ddd",
//       paddingVertical: 10,
//       paddingHorizontal: 15,
//       borderRadius: 10,
//       margin: 5,
//     },
//     selectedQuestion: {
//       backgroundColor: "blue",
//     },
//     nextButton: {
//       backgroundColor: "blue",
//       paddingVertical: 15,
//       alignItems: "center",
//       borderRadius: 10,
//     },
//   });
  
//   export default TrackOrder;
