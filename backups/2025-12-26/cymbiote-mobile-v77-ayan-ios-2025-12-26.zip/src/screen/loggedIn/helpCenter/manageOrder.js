import { StatusBar, View ,StyleSheet, Dimensions, FlatList, TouchableOpacity} from "react-native"
import HelpCenterHeader from "../../../component/header/helpCenterHeader";
import { navigate } from '@utils/navigationRef/navigationRef';
import OrderQuestions from "../../../component/helpCenter/orderQuestions";
import HelpSvg from "@assets/images/help.svg"


const { width, height, fontScale } = Dimensions.get("screen")

const ManageOrder =({navigation})=>{
    const orderManagementQuestions = [
        "How do I manage my orders?",
        "Can I edit an order after placing it?",
        "What happens if my order is delayed?",
        "How do I manage my orders?",
        "Can I edit an order after placing it?",
        "What happens if my order is delayed?",
        "How do I manage my orders?",
        "Can I edit an order after placing it?",
        "What happens if my order is delayed?",
      ];
    return(
     <View style={styles.container}>
        
        <StatusBar animated barStyle={"dark-content"} backgroundColor={"white"} translucent={false} />
        <HelpCenterHeader borderLine={1} navigation={navigation} title={"Help Center"} IconComponent={HelpSvg}/>
   
        <OrderQuestions title={"Order Management"}
        questions={orderManagementQuestions}
        onPress={()=>navigate("TrackOrder")}/>
    </View>
    )
}
export default ManageOrder;

const styles = StyleSheet.create({
    container:{
        flex:1,
        backgroundColor:"white"
    },
      
})