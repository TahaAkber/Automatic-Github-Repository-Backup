import {useCallback, useEffect, useState} from 'react';
import {_getUserSavedReels} from '../../../redux/actions/reels/reels';
import useReduxStore from '../../../utils/hooks/useReduxStore';
import {pagination} from '../../../utils/helper/helper';
import {useFocusEffect} from '@react-navigation/native';

const useUserSavedReels = () => {
  const {dispatch, getState} = useReduxStore();
  const {userSavedReels, userSavedReelsLoading, userSavedReelsError} =
    getState('reels');
  const [page, setPage] = useState(1);
  const [paginationLoader, setPaginationLoader] = useState(false);
  const [pullLoader, setPullLoader] = useState(false);
  const paginationAPI = async () => {
    try {
      if (!paginationLoader) {
    
        const totalPages =
          userSavedReels?.pagination?.totalPages ==
          userSavedReels?.pagination?.currentPage;

        const nextPagination = totalPages
          ? false
          : pagination(page, userSavedReels?.pagination?.totalPages);
   
        if (nextPagination) {
          setPaginationLoader(true);
          const response = await dispatch(
            _getUserSavedReels({page: nextPagination}),
          );
     
          setPage(nextPagination);
     
          setPaginationLoader(false);
        }
      }
    } catch (error) {
      console.error('Error in paginationAPI:', error);
    }
  };

  const fetchAPI = async isLoading => {
    !isLoading && setPullLoader(true);
    setPage(1);
    await dispatch(_getUserSavedReels({page: 1}));
    setPullLoader(false);
  };

  useFocusEffect(
    useCallback(() => {
      fetchAPI(true);
    }, []),
  );

  return {
    userSavedReels,
    userSavedReelsLoading,
    paginationAPI,
    fetchAPI,
    paginationLoader,
    pullLoader,
    userSavedReelsError,
  };
};

export default useUserSavedReels;
