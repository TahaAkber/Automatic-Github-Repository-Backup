import React, {useState, useRef, useCallback, useEffect} from 'react';
import {Dimensions, View, Animated, LayoutAnimation} from 'react-native';
// import VariantCard from '@component/cards/variantCard/variantCard';
import useReduxStore from '@utils/hooks/useReduxStore';
import {pagination} from '../../../utils/helper/helper';
import {_getUserNotifications} from '../../../redux/actions/user/user';
import {useIsFocused} from '@react-navigation/native';

const {height, width, fontScale} = Dimensions.get('screen');

const useNotification = () => {
  const {getState, dispatch} = useReduxStore();
  const {fetch_user_detail} = getState('auth');
  const {fetch_user_notifications, fetch_user_notifications_error} =
    getState('user');

  const [page, setPage] = useState(0);
  const [loader, setLoader] = useState(false);
  const [paginationLoader, setPaginationLoader] = useState(false);
  const [pullLoader, setPullLoader] = useState(false);
  const isFocused = useIsFocused();

  const fetchAPI = async loading => {
    if (!pullLoader && !loader && !paginationLoader) {
      !loading && setPullLoader(true);
      loading && setLoader(true);
      await dispatch(_getUserNotifications(1, true));
      setPage(1);
      setPullLoader(false);
      setLoader(false);
    }
  };

  const paginationAPI = async () => {
    if (!paginationLoader && !loader && !pullLoader) {
      const totalPages =
        fetch_user_notifications?.pagination?.totalPages ==
        fetch_user_notifications?.pagination?.currentPage;
      const nextPagination = totalPages
        ? false
        : pagination(page, fetch_user_notifications?.pagination?.totalPages);

      if (nextPagination) {
        setPaginationLoader(true);
        const response = await dispatch(_getUserNotifications(nextPagination));
        setPage(nextPagination);

        setPaginationLoader(false);
      }
    }
  };

  const todayNotification = (fetch_user_notifications?.data || []).find(
    item => item.date == 'Today',
  );


  useEffect(() => {
    fetchAPI(true);
  }, []);

  return {
    fetch_user_notifications,
    fetch_user_detail,
    paginationLoader,
    paginationAPI,
    fetchAPI,
    isFocused,
    pullLoader,
    todayNotification,
    loader,
    fetch_user_notifications_error,
  };
};

export default useNotification;
