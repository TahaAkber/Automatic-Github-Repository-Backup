import useReduxStore from '@utils/hooks/useReduxStore';
import {_getUserNotifications} from '@redux/actions/user/user';
import {
  _addTracking,
  _geTrackingServices,
  _getTrackings,
} from '../../../redux/actions/orders/orders';
import {useIsFocused, useNavigation} from '@react-navigation/native';
import {useEffect, useState} from 'react';
import {trackingServices} from '../../../constant/contstant';
import {showToast} from '../../../helper/reUsableMethod/reUsableMethod';

const useCreateTracking = () => {
  const {getState, dispatch} = useReduxStore();
  const {fetch_user_detail} = getState('auth');
  const {fetch_tracking_services} = getState('order');
  const [loader, setLoader] = useState(false);
  const [service, setService] = useState();
  const [trackingNumber, setTrackingNumber] = useState('');
  const [packageName, setPackageName] = useState('');
  const isFocused = useIsFocused();
  const navigation = useNavigation();



  const _handleSubmit = async values => {
    if (!service) {
      showToast('Service is required');
    } else if (!trackingNumber) {
      showToast('Tracking number is required');
    } else if (!packageName) {
      showToast('Package number is required');
    } else {
      setLoader(true);
      const res = await dispatch(
        _addTracking(service, trackingNumber, packageName),
      );
      if (res) {
        navigation.replace('TrackingDetail', {
          custom_tracking_id: res,
        });
      }
      setLoader(false);
    }
  };

  const fetchAPI = async () => {
    const response = await dispatch(_geTrackingServices());
    setService(response);
  };

  useEffect(() => {
    fetchAPI();
  }, []);

  const isDisabled = !service || !trackingNumber || !packageName;

  return {
    fetch_user_detail,
    isFocused,
    service,
    setService,
    trackingNumber,
    setTrackingNumber,
    packageName,
    setPackageName,
    isDisabled,
    loader,
    _handleSubmit,
    fetch_tracking_services,
  };
};

export default useCreateTracking;
