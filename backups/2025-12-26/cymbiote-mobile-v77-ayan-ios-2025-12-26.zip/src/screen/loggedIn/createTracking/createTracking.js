import {Dimensions, StyleSheet, View} from 'react-native';
import React, {useRef} from 'react';
import InnerHeader from '@component/header/innerHeader';
import Container from '@materialComponent/container/container';
import useCreateTracking from './useCreateTracking';
import {heightPercentageToDP} from 'react-native-responsive-screen';
import {navigate} from '../../../utils/navigationRef/navigationRef';
import AuthInput from '../../../component/input/authInput';
import {margin, trackingServices} from '../../../constant/contstant';
import Dropdown from '../../../component/dropdown/dropdown';
import DropdownInput from '../../../component/dropdown/globalDropdown';
import CustomButton from '../../../materialComponent/customButton/customButton';

const {height} = Dimensions.get('screen');

const CreateTracking = () => {
  const {
    fetch_user_detail,
    isFocused,
    service,
    setService,
    trackingNumber,
    setTrackingNumber,
    packageName,
    setPackageName,
    isDisabled,
    loader,
    _handleSubmit,
    fetch_tracking_services,
  } = useCreateTracking();
  const dropdownRef = useRef(null);

  return (
    <Container isFocused={isFocused} dark={true} barColor={'white'}>
      <View style={styles.mainView}>
        <InnerHeader
          onPressPlus={() => navigate('CreateTracking')}
          title={'Add Manually Tracking'}
        />
        <View style={{marginHorizontal: margin.horizontal}}>
          <DropdownInput
            ref={dropdownRef}
            value={service}
            onSelect={setService}
            placeholder="Select Service"
            backgroundColor={'#f4f4f4'}
            options={fetch_tracking_services}
          />
          <AuthInput
            backgroundColor={'#f4f4f4'}
            placeholder={'Tracking number'}
            marginTop={height * 0.01}
            onChangeText={setTrackingNumber}
            value={trackingNumber}
            onFocus={() => dropdownRef.current?.close?.()}
          />
          <AuthInput
            backgroundColor={'#f4f4f4'}
            placeholder={'Package name'}
            marginTop={height * 0.01}
            onChangeText={setPackageName}
            value={packageName}
            onFocus={() => dropdownRef.current?.close?.()}
          />
          <CustomButton
            loader={loader}
            disabled={isDisabled}
            marginTop={height * 0.02}
            text={'Submit'}
            onPress={_handleSubmit}
          />
        </View>
      </View>
    </Container>
  );
};

export default CreateTracking;

const styles = StyleSheet.create({
  mainView: {
    flex: 1,
    backgroundColor: 'white',
  },
});
