import React, {useState, useRef, useCallback, useEffect} from 'react';
import {Dimensions, View, Animated, LayoutAnimation} from 'react-native';
// import VariantCard from '@component/cards/variantCard/variantCard';
import VariantCard from '../../../component/cards/variantCard/variantCard';
import useReduxStore from '@utils/hooks/useReduxStore';
import {homeData} from '../../../constant/dummyData';
import OrderVariantCard from '../../../component/cards/orderVariantCard/orderVariantCard';
import {_getOrderDetail} from '../../../redux/actions/orders/orders';
import {font, statusMap} from '../../../constant/contstant';

const {height, width, fontScale} = Dimensions.get('screen');

const useOrderDetail = ({order_id, tracking_id, table_id}) => {
  const {getState, dispatch} = useReduxStore();
  const {fetch_user_detail} = getState('auth');
  const {fetch_address} = getState('user');
  const [expanded, setExpanded] = useState(false);
  const animatedHeight = useRef(new Animated.Value(0)).current;
  const rotateAnim = useRef(new Animated.Value(0)).current;
  const scrollViewRef = useRef(null);
  const {
    fetch_order_detail,
    fetch_order_detail_loader,
    fetch_order_detail_error,
  } = getState('order');

  console.log('fetch_order_detail =', fetch_order_detail);

  const defaultAddressItem =
    fetch_address.find(item => item?.address_default_select) || {};

  const toggleExpand = () => {
    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);

    Animated.timing(rotateAnim, {
      toValue: expanded ? 0 : 1,
      duration: 300,
      useNativeDriver: true,
    }).start();

    if (!expanded) {
      Animated.timing(animatedHeight, {
        toValue: 1,
        duration: 300,
        useNativeDriver: false,
      }).start(() => {
        scrollViewRef.current?.scrollTo({
          y: height * 1, // Scroll down by 40% of the screen height
          animated: true,
        });
      });
    } else {
      Animated.timing(animatedHeight, {
        toValue: 0,
        duration: 300,
        useNativeDriver: false,
      }).start();
    }

    setExpanded(!expanded);
  };

  const shop = {
    shop_is_active: true,
    shop_logo_url: fetch_order_detail?.shop_logo_url,
    shop_name: fetch_order_detail?.shop_name,
    shop_email: fetch_order_detail?.shop_email,
  };

  const renderItem = useCallback(({item, index}) => {
    const image = item?.product_image_url
      ? item?.product_image_url
      : item?.variant?.images?.length
      ? item?.variant?.images?.[0]?.preview?.image.url
      : item?.product?.product_image_url || item?.image_url;

    // item.variant.variant_price =  item?.order_item_price

    return (
      <>
        <View style={{marginTop: index == 0 ? 0 : height * 0.015}}>
          <VariantCard
            borderWidth={'100%'}
            index={0}
            isDisabled={false}
            display={true}
            product={item?.product}
            qty={item?.order_item_quantity || item?.quantity}
            variantStock={true}
            shop={shop}
            variant={item?.variant}
            image={image}
            // removeBorder={true}
            // imageStyle={{ width: width * 0.17 }}
            marginTop={height * 0.01}
            opitonsMarginTop={height * 0.013}
            // priceSize={fontScale * 11}
            // priceFontFamily={font.medium}
            // headingSize={fontScale * 11}
            imageQty={true}
            productTitle={item?.product?.product_name || item?.product_name}
            borderTopMargin={height * 0.015}
            priceText={item?.order_item_price || item?.price}
            curreny={fetch_order_detail?.shop_currency}
            // optionHeight={height * 0.02}
            // optionFontSize={fontScale * 10}
          />
        </View>
      </>
    );
  }, []);

  // const renderItem = useCallback(({ item, index }) => {
  //     console.log("🔍 Debug Order Item:", item);

  //     // Extract Image
  //     const image =
  //         item?.variant?.images?.length > 0
  //             ? item.variant.images[0]?.preview?.image?.url
  //             : item?.product?.product_image_url || null;

  //     // Extract Quantity
  //     const quantity = item?.order_item_quantity || 1;

  //     // Extract Price
  //     const price = item?.variant?.variant_price || item?.order_item_price || "N/A";

  //     // Extract Variant Name
  //     const variantName = item?.variant?.variant_name || "Default";

  //     // Extract Product Name
  //     const productName = item?.product?.product_name || "Unnamed Product";

  //     return (
  //         <View style={{ marginTop: height * (index === 0 ? 0.01 : 0.022) }}>
  //             <VariantCard
  //                 borderWidth={"100%"}
  //                 index={0}
  //                 isDisabled={false}
  //                 display={true}
  //                 product={item?.product}
  //                 qty={item.order_item_quantity}
  //                 variantStock={false}
  //                 shop={orderData?.shop_detail || {}}
  //                 variant={item?.variant}
  //                 image={image}
  //                 imageStyle={{ width: width * 0.18 }}
  //                 headingSize={fontScale * 13}
  //                 priceSize={fontScale * 13}
  //                 quantityFontSize={fontScale * 12}
  //                 marginTop={height * 0.01}
  //                 borderTopMargin={height * 0.021}
  //                 priceQuantityWidth={width * 0.67}

  //             />
  //         </View>
  //     );
  // }, []);

  const rotate = rotateAnim.interpolate({
    inputRange: [0, 1],
    outputRange: ['0deg', '180deg'], // Rotate from 0 to 180 degrees
  });

  const orderSummary = [
    {
      label: 'Contact Information',

      value: fetch_user_detail?.email,
    },
    {
      label: 'Shipping Address',
      value: `${defaultAddressItem?.address_one}, ${defaultAddressItem?.address_two}, ${defaultAddressItem?.address_city}`,
    },
    {
      label: 'Shipping Method',
      value: 'Standard',
    },
    {
      label: 'Payment Method',
      value: 'CARD · Rs 10.00, 1 · Rs 13,910.00',
    },
  ];

  const isOrderCancelled = fetch_order_detail?.order_cancelled_by;
  const currentStatus = fetch_order_detail?.status
    ? fetch_order_detail?.status?.toUpperCase()
    : fetch_order_detail?.tracking_status?.toUpperCase() || '';

  // ✅ Define valid statuses for the progress bar and cancellation rules

  // console.log(@)
  // const statusInfo = statusMap[currentStatus] || null;
  const statusInfo = isOrderCancelled
    ? {label: 'Cancelled', theme: '#EE1F23'} // your red color here
    : statusMap[currentStatus] || null;

  const isCancelled = fetch_order_detail?.status
    ? fetch_order_detail?.status?.toUpperCase() === 'CANCELLED'
    : fetch_order_detail?.order_tracking?.tracking_status?.toUpperCase() ===
        'CANCELLED' || fetch_order_detail?.status
    ? fetch_order_detail?.status?.toUpperCase() === 'CANCEL_ORDER'
    : fetch_order_detail?.order_tracking?.tracking_status?.toUpperCase() ===
      'CANCEL_ORDER';

  const statusLabel = statusInfo ? statusInfo.label : 'PENDING';
  const orderData = fetch_order_detail;
  const orderItems =
    fetch_order_detail?.order_item || fetch_order_detail?.products;
  const theme = statusInfo ? statusInfo.theme : '#fdb201';

  const initialImage = orderItems?.[0]?.product?.product_image_url || '';

  useEffect(() => {
    dispatch(_getOrderDetail(order_id, tracking_id, table_id));
  }, []);

  // const params = route?.params?.getAssets

  return {
    expanded,
    animatedHeight,
    toggleExpand,
    renderItem,
    rotate,
    orderSummary: [],
    scrollViewRef,
    statusInfo,
    isCancelled,
    statusLabel,
    orderItems,
    theme,
    orderData,
    fetch_order_detail_loader,
    shop,
    initialImage,
  };
};

export default useOrderDetail;
