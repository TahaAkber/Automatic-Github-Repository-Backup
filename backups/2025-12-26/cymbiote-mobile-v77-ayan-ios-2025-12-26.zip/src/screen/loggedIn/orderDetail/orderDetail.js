import React from 'react';
import {
  Dimensions,
  StyleSheet,
  View,
  TouchableOpacity,
  Animated,
  UIManager,
  Platform,
  FlatList,
  StatusBar,
} from 'react-native';
import Content from '@materialComponent/content/content';
import {margin, colors, font, globalStyle} from '@constant/contstant';
import LottieThankYou from '@component/lottieFiles/lottieThankYou';
import CustomText from '@materialComponent/customText/customText';
import BrandTab from '@component/brandTab/brandTab';
import MerchantChatBox from '@component/cards/merchantChat/merchantChatBox';
import SummaryTable from '@component/table/summaryTable';
import Icon from '@materialComponent/icon/icon';
import {moderateScale} from 'react-native-size-matters';
import BorderLine from '@component/borderLine/borderLine';
import OrderSummary from '@component/orderSummary/orderSummary';
import useOrderDetail from './useOrderDetail';
import {homeData} from '@constant/dummyData';
import InnerHeader from '@component/header/innerHeader';
import TrackingTimeline from '@component/trackingTimeline/trackingTimeline';
import {navigate} from '../../../utils/navigationRef/navigationRef';
import {formatPrice} from '../../../utils/helper/helper';
import Container from '../../../materialComponent/container/container';
import OrderDetailLoader from '../../../component/loader/orderDetailLoader';
import OrderLinks from '../../../component/orderLinks/orderLinks';
import moment from 'moment';

const {height, width, fontScale} = Dimensions.get('screen');

if (
  Platform.OS === 'android' &&
  UIManager.setLayoutAnimationEnabledExperimental
) {
  UIManager.setLayoutAnimationEnabledExperimental(true);
}

const OrderDetail = ({route}) => {
  const {order_id, tracking_id, table_id = false} = route.params;
  // const isCancelled = orderData?.order_tracking?.tracking_status?.toUpperCase() === "CANCELLED"
  //     || orderData?.order_tracking?.tracking_status?.toUpperCase() === "CANCEL_ORDER";
  const {
    expanded,
    animatedHeight,
    toggleExpand,
    renderItem,
    rotate,
    orderSummary,
    scrollViewRef,
    isCancelled,
    statusInfo,
    orderItems,
    statusLabel,
    theme,
    orderData,
    fetch_order_detail_loader,
    shop,
    initialImage,
  } = useOrderDetail({order_id, tracking_id, table_id});


  return (
    <>
      {fetch_order_detail_loader ? (
        <OrderDetailLoader loading={true} />
      ) : (
        <Container barColor={theme || 'red'}>
          <View style={styles.mainView}>
            <StatusBar
              animated
              barStyle="dark-content"
              backgroundColor={theme || 'red'}
              translucent={false}
            />
            <View style={{backgroundColor: theme || 'red'}}>
              <InnerHeader
                headerTextColor={'white'}
                light
                notification={true}
                setting={true}
                title={`${
                  orderData?.order_title || orderData?.order_id_display
                }`}
                titleStyle={{width: '80%'}}
              />
              <View style={styles.header}>
                <CustomText
                  fontFamily={font.bold}
                  fontSize={fontScale * 10}
                  color={'white'}
                  text={moment(orderData?.order_date).format('MMMM D, YYYY')}
                />
                {/* <CustomText marginTop={height * 0.005} fontFamily={font.bold} fontSize={fontScale * 17} color={"white"} text={orderData?.order_tracking?.tracking_status || "Cancelled"} /> */}
                <CustomText
                  marginTop={height * 0.005}
                  fontFamily={font.bold}
                  fontSize={fontScale * 17}
                  color={'white'}
                  text={statusLabel ? statusLabel.toUpperCase() : 'CANCELLED'}
                />
                <CustomText
                  marginTop={height * 0.005}
                  fontFamily={font.regular}
                  fontSize={fontScale * 14}
                  color={'white'}
                  text={
                    orderData?.order_cancelled_by
                      ? `Your order has been canceled by ${orderData?.order_cancelled_by.toUpperCase()}`
                      : statusLabel == 'Delivered'
                      ? 'Your order has been delivered successfully.'
                      : 'Your order is being prepared.'
                  }
                />
              </View>
            </View>
            <Content
              contentContainerStyle={styles.content}
              key={1}
              ref={scrollViewRef}>
              <View style={styles.mainView}>
                {/* <LottieThankYou /> */}
                {/* <View style={{ marginHorizontal: margin.horizontal }}>
                    <CustomText center fontSize={fontScale * 14} text={'Your order has been successfully placed. We appreciate your trust in us and can’t wait to serve you again.'} />
                </View> */}
                <View
                  style={[
                    styles.order,
                    {
                      borderTopRightRadius: 30,
                      borderTopLeftRadius: 30,
                      paddingTop: height * 0.02,
                    },
                  ]}>
                  <BrandTab
                    item={orderData?.shop_detail || shop}
                    followColor={colors.light_theme.theme}
                    followStyle={{paddingHorizontal: 0, paddingVertical: 0}}
                    followSize={fontScale * 15}
                    showFollowButton={false}
                  />
                  <View style={{marginTop: height * 0.015}}>
                    <FlatList
                      scrollEnabled={false}
                      data={orderItems}
                      renderItem={renderItem}
                      keyExtractor={(item, index) => index.toString()}
                    />{' '}
                  </View>
                  {/* <View style={{ marginTop: height * 0.015, marginBottom: height * 0.02 }}>
                                        <MerchantChatBox onPress={() => navigate('Chat', { name: orderData?.shop_detail?.shop_name, item: orderData?.shop_detail, uri: "https://s3-alpha-sig.figma.com/img/fbc1/4c1d/c3a96ba57eb32020d565abdd8b64b19b?Expires=1738540800&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=Ja2u-FVfT-Wa0zev2JMx~TIffwzPrXN~Ni0I8S3gLlTLZ2lgfGa7op5--gKlRomq4GiaZAGpf-zltYZTM~8h1~ZbyUnRry-7Ds8SVeg7s2lcElj3LfWFoffDpPz1h8o4tOp7wF2AC02ReR~~QEK40ujzv0gKeFojkW8MnQMfQaZplhwG82oJrKYxlbwxQr2XnaUZYuP1mrc5bu~6uih-wzOQhm~ebLzTgSipzQpspFjqLGOqXfjt1XDCrLD3elo1886IrugOdGme5meX~ydH3nLTUbO8iLSBh6tFjhxiXyPFqGuTB9NQy5SZXHg4UWZLe2m9zMLPXrGfJ8hgDGq1Vw__" })} />
                                    </View> */}
                </View>
                {isCancelled ? (
                  <View
                    style={[
                      styles.order,
                      {marginTop: height * 0.01, paddingBottom: height * 0.01},
                    ]}>
                    <CustomText
                      fontFamily={font.bold}
                      fontSize={fontScale * 15}
                      text={'Order Details'}
                    />

                    <SummaryTable
                      fontFamily={font.medium}
                      marginTop={height * 0.02}
                      label={'Order No'}
                      value={
                        orderData?.order_title || orderData?.order_id_display
                      }
                    />
                    <SummaryTable
                      fontFamily={font.medium}
                      marginTop={height * 0.02}
                      label={'Reason'}
                      value={orderData?.order_cancel_reason}
                    />
                    <SummaryTable
                      fontFamily={font.medium}
                      marginTop={height * 0.02}
                      label={'Cancelled By'}
                      value={orderData?.order_cancelled_by}
                    />
                  </View>
                ) : (
                  <>
                    <View
                      style={[
                        styles.order,
                        {
                          marginTop: height * 0.01,
                          paddingBottom: height * 0.01,
                          backgroundColor: 'white',
                        },
                      ]}>
                      <OrderLinks
                        orderTitle={orderData?.order_title}
                        shop={orderData?.shop_detail || shop}
                        orderId={orderData?.order_id}
                        socialOrderItem={table_id && orderData}
                        image={initialImage}
                      />
                      {/* <TouchableOpacity style={styles.toggleButton} onPress={toggleExpand} activeOpacity={0.7}>
                                    <CustomText text={"View Order Summary"} style={styles.toggleText} />
                                    <Animated.View style={{ transform: [{ rotate }] }}>
                                        <Icon icon_type={"Feather"} name={"chevron-down"} size={moderateScale(15)} color={colors.light_theme.theme} />
                                    </Animated.View>
                                </TouchableOpacity> */}
                    </View>

                    <View style={styles.tracking}>
                      <CustomText
                        fontFamily={font.bold}
                        fontSize={fontScale * 13}
                        text={'Tracking Number'}
                      />
                      <CustomText
                        marginTop={height * 0.002}
                        fontFamily={font.regular}
                        fontSize={fontScale * 13}
                        text={orderData?.tracking_number || 'N/A'}
                      />
                    </View>

                    <TrackingTimeline
                      trackingData={orderData?.tracking_events || []}
                    />
                  </>
                )}
              </View>
            </Content>
          </View>
        </Container>
      )}
    </>
  );
};
export default OrderDetail;

const styles = StyleSheet.create({
  mainView: {
    flex: 1,
    backgroundColor: 'white',
    // paddingBottom: globalStyle.bottomSpace.marginBottom,
  },
  content: {
    paddingBottom: globalStyle.bottomSpace.marginBottom,
  },
  header: {
    paddingHorizontal: margin.horizontal,
    marginTop: height * -0.015,
    paddingBottom: height * 0.02,
  },
  order: {
    backgroundColor: '#FAFAFA',
    paddingHorizontal: margin.horizontal,
    paddingTop: height * 0.01,
    marginTop: height * 0.01,
  },
  borderLine: {
    marginLeft: 0,
    width: '95%',
    backgroundColor: '#00000033',
    height: height * 0.003,
    alignSelf: 'center',
    opacity: 0.3,
  },
  toggleButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: height * 0.01,
    marginBottom: height * 0.005,
  },
  toggleText: {
    marginRight: width * 0.01,
    color: 'black',
    fontFamily: font.regular,
  },
  tracking: {
    backgroundColor: '#FAFAFA',
    marginHorizontal: margin.horizontal,
    marginTop: height * 0.01,
    padding: width * 0.03,
    borderRadius: 8,
    paddingHorizontal: width * 0.05,
  },
  cancelReason: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
});
