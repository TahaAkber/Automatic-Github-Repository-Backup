import React, {useEffect, useRef} from 'react';
import {StatusBar, StyleSheet, Text, View} from 'react-native';
import {scale, verticalScale} from 'react-native-size-matters';
import InnerHeader from '@component/header/innerHeader';
import {globalStyle} from '@constant/contstant';
import {WebView} from 'react-native-webview';
import Container from '../../../materialComponent/container/container';
import {heightPercentageToDP} from 'react-native-responsive-screen';
import PagionationLoader from '../../../component/loader/endReachLoader';

const CustomWebView = ({route}) => {
  return (
    <Container barColor={'white'}>
      <View style={styles.mainView}>
        <InnerHeader title={route?.params?.heading} />
        <View style={{flex: 1}}>
          <WebView
            source={{uri: route?.params?.url}}
            startInLoadingState={true}
            renderLoading={() => (
              <View
                style={{
                  flexGrow: 1,
                  justifyContent: 'center',
                  alignItems: 'center',
                  position: 'absolute',
                  height : heightPercentageToDP(85),
                  alignSelf:"center"
                }}>
                <PagionationLoader />
              </View>
            )}
            originWhitelist={['*']}
            userAgent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.97 Safari/537.36"
          />
        </View>
      </View>
    </Container>
  );
};

export default CustomWebView;

const styles = StyleSheet.create({
  mainView: {
    flex: 1,
    backgroundColor: 'white',
  },
  flatLists: {
    paddingHorizontal: scale(15),
    paddingVertical: verticalScale(10),
    paddingBottom: globalStyle.bottomSpace.marginBottom,
  },
});
