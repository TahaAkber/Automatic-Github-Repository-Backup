import useReduxStore from '@utils/hooks/useReduxStore';
import { FETCH_CART_DB_ITEM, FETCH_CART_ITEM } from '@redux/types/cart/cart';
import { useEffect, useState } from 'react';

const useCheckout = ({ route }) => {
    const { shop_id, checkoutUrl } = route.params
    const { dispatch, getState } = useReduxStore()
    const { cart, cart_item } = getState("cart")
    const { fetch_address } = getState("user")
    const [localCart, setLocalCart] = useState([])
    const [showThankYouPage, setShowThankYouPage] = useState(false)
    const handleNavigationStateChange = (navState) => {
        const currentUrl = navState.url;
        if (currentUrl.includes('/thank-you')) {
            setShowThankYouPage(true)
            const removeCartItem = cart.filter((item, index) => item.shop_id != shop_id)
            const removeItem = cart_item.filter((item, index) => item.shop.shop_id != shop_id)
            dispatch({ type: FETCH_CART_ITEM, payload: removeCartItem })
            dispatch({ type: FETCH_CART_DB_ITEM, payload: removeItem })
        }
    };

    useEffect(() => {
        const getCurrentCart = cart_item?.find(item => item?.shop?.shop_id === shop_id);
        setLocalCart(getCurrentCart)
    }, [])
    

    return {
        handleNavigationStateChange,
        showThankYouPage,
        cart,
        cart_item,
        dispatch,
        getState,
        shop_id,
        checkoutUrl,
        localCart
    }
};

export default useCheckout