import {
  _getStoreProductDetail,
  _getStoreProductDetailReview,
} from '@redux/actions/merchant/merchant';
import {
  _addToCart,
  _checkout,
  _removeCartProduct,
} from '@redux/actions/cart/cart';
import {_recentViewed, _favoriteUpdateStatus} from '@redux/actions/user/user';
import {AuthNavigating} from '@helper/reUsableMethod/reUsableMethod';
import {StyleSheet, TouchableOpacity, Vibration, View} from 'react-native';
import {WH, colors, shadow} from '@constant/contstant';
import HomeDualCard from '@component/cards/homeDualCard';
import CustomImage from '@materialComponent/image/image';
import useReduxStore from '@utils/hooks/useReduxStore';
import {getShopDetail} from '@utils/helper/helper';
import {useEffect, useRef, useState} from 'react';
import {
  _getStoreProducts,
  getRelatedStore,
} from '../../../redux/actions/merchant/merchant';
import {triggerHaptic} from '../../../utils/haptic/haptic';
import {
  _cartBottomSheet,
  _fetchSearchedList,
} from '../../../redux/actions/common/common';
import {useIsFocused, useNavigation} from '@react-navigation/native';
import useShopifyCheckoutEvents from '../../../hooks/useShopifyCheckoutEvents';

const useProductDetail = ({route}) => {
  const {
    product_id,
    shop_id,
    default_images,
    brand_screen = false,
    height: defaultHeight,
  } = route?.params; // Extract product_id from route params
  const [checkOutDetail, setCheckOutDetail] = useState({});
  const {shopifyCheckout} = useShopifyCheckoutEvents({checkOutDetail});
  const {getState, dispatch} = useReduxStore();
  const {fetch_store_product_detail_error} = getState('merchant');
  const [variant, setVariant] = useState(0);
  const [localQty, setLocalQty] = useState(1);
  const [result, setResult] = useState([]);
  const [relatedShops, setRelatedShops] = useState([]);
  const [displayImages, setDisplayImages] = useState([]);
  const [favorite, setFavorite] = useState(false);
  const [
    fetch_store_product_detail_loader,
    set_fetch_store_product_detail_loader,
  ] = useState(false);
  const scrollRef = useRef(null);
  const [productDetailReview, setProductDetailReview] = useState({});
  const [fetch_store_product_detail, set_fetch_store_product_detail] = useState(
    {},
  );
  const [fetch_store_products, set_fetch_store_products] = useState([]);
  const [relatedProductLoader, setRelatedProductLoader] = useState(true);
  const [relatedProducts, setRelatedProducts] = useState([]);
  const isFocused = useIsFocused();
  const navigation = useNavigation();

  const fetchRelatedProducts = async () => {
    setRelatedProductLoader(true);
    const response = await dispatch(
      _fetchSearchedList(
        fetch_store_product_detail?.product_detail?.product_custom_category,
        false,
        1,
        true,
        // fetch_store_product_detail?.shop_detail?.shop_name,
        '',
        fetch_store_product_detail?.shop_detail?.shop_id,
        true,
      ),
    );
    setRelatedProducts(response);
    setRelatedProductLoader(false);
  };

  const fetchProductDetailReview = async () => {
    const res = await dispatch(_getStoreProductDetailReview(product_id));
    if (res) {
      setProductDetailReview(res);
    } else {
      setProductDetailReview({});
    }
  };



  const shop_detail = getShopDetail(shop_id);

  // Fetch cart for logging purposes (if needed for debugging)
  const {cart, syncingCart} = getState('cart');
  const {fetch_user_detail} = getState('auth');
  const {fetch_address} = getState('user');
  const [checkOutLoader, setCheckOutLoader] = useState(false);

  const getSelectedVariant = () => {
    // Extract the currently selected values for each group
    const selectedValues = result.reduce((acc, group) => {
      const selectedItem = group.values.find(
        v => v.variant_id === group.selectedValue,
      );
      if (selectedItem) {
        acc[group.name.toLowerCase()] = selectedItem.value.toLowerCase(); // Normalize for comparison
      }
      return acc;
    }, {});

    // Find the variant that matches the selected values
    const matchingVariant = data?.find(variant => {
      const isMatch = variant?.selected_options?.every(opt => {
        const optionName = opt.name.toLowerCase();
        const optionValue = opt.value.toLowerCase();
        return selectedValues[optionName] === optionValue;
      });
      return isMatch;
    });

    return matchingVariant || null; // Return the full variant details or null if no match
  };

  // Render similar products card
  const renderSimilarProducts = ({item}) => (
    <View style={styles.similarProductCard}>
      <HomeDualCard
        // onPress={() => {
        //   scrollRef.current?.scrollTo({y: 0, animated: true});
        // }}
        item={item}
        color="black"
      />
    </View>
  );

  // Render product variants
  const renderVariant = ({item, index}) => (
    <TouchableOpacity
      onPress={() => setVariant(index)}
      style={[
        styles.variant,
        {borderColor: index === variant ? 'black' : colors.light_theme.gray},
      ]}>
      <CustomImage
        resizeMode="cover"
        source={{
          uri:
            item.images?.[0]?.preview?.image?.url ||
            fetch_store_product_detail?.product_detail?.product_image_url,
        }}
        style={styles.variantImage}
      />
    </TouchableOpacity>
  );

  const fetchAPI = async () => {
    set_fetch_store_product_detail_loader(true);
    const response = await dispatch(_getStoreProductDetail(product_id));
    set_fetch_store_product_detail(response);
    set_fetch_store_product_detail_loader(false);
    const storeProducts = await dispatch(
      _getStoreProducts(shop_id, 1, true, product_id),
    );
    set_fetch_store_products(storeProducts?.data?.products || []);
  };

  // Fetch product details on mount or when product_id changes
  useEffect(() => {
    if (product_id) {
      fetchAPI();
      fetchProductDetailReview();

      dispatch(_recentViewed(fetch_user_detail?.id, 'product', '', product_id));
    }
  }, [product_id]);

  const updatedData = fetch_store_product_detail?.product_variant
    ?.map(variant => {
      const [color, size, couple] = variant.variant_name
        ? variant.variant_name.split(' / ')
        : [null, null, null];

      return {
        ...variant,
        variant_color: color ? color.trim() : null, // Assign color or null
        variant_size: size ? size.trim() : null, // Assign size or null
        variant_couple: couple ? couple.trim() : null, // Assign size or null
      };
    })
    .filter(item => item.selected_options);

  const data = fetch_store_product_detail?.product_variant || [];

  const handleValue = (groupName, variantId) => {
    setResult(prevResult => {
      return prevResult.map(group => {
        if (group.name === groupName) {
         
          return {
            ...group,
            selectedValue: variantId,
            values: group.values.map(v => {
              const matchedVariant = data.find(
                d => d.variant_id === v.variant_id,
              );
              return {
                ...v,
                image_url: matchedVariant?.variant_image_url || null,
              };
            }),
          };
        }

       
        return {
          ...group,
          values: group.values.map(v => {
            const matchedVariant = data.find(
              d => d.variant_id === v.variant_id,
            );
            return {
              ...v,
              image_url: matchedVariant?.variant_image_url || null,
            };
          }),
        };
      });
    });
  };



  useEffect(() => {
    const groupedData = data?.reduce((acc, variant) => {
      // Ensure selected_options exist and contain valid entries
      if (
        variant?.selected_options?.length > 0 &&
        variant.selected_options.every(option => option?.value)
      ) {
        variant.selected_options.forEach(({name, value, selected_options}) => {
          if (!acc[name]) {
            acc[name] = {
              name,
              selectedValue: '',
              values: [],
              selected_options: variant?.selected_options,
            };
          }

          // Check for duplicates before adding
          if (!acc[name].values.some(v => v.value === value.toLowerCase())) {
            acc[name].values.push({
              variant_id: variant.variant_id,
              name,
              value: value.toLowerCase(),
              image_url: variant.variant_image_url,
              available: variant.variant_quantity,
            });
          }
        });
      }
      return acc;
    }, {});

    const formattedResult = Object.values(groupedData).map(group => {
      const firstAvailable = group.values.find(v => v.available > 0); // Optional: choose available one
      return {
        ...group,
        selectedValue:
          firstAvailable?.variant_id || group.values[0]?.variant_id || '',
      };
    });

    const productImages =
      fetch_store_product_detail?.product_detail?.product_images || [];

    // Map the product_images array to extract product_image_url for the ImageSlider
    const imageUrls =
      productImages.map(image => image.product_image_url) || images;

    setResult(formattedResult);
    setDisplayImages(imageUrls);
    return setDisplayImages([]);
  }, [fetch_store_product_detail]);

  // Fetch images for the selected variant or fallback to product detail image
  const images = getSelectedVariant()?.images?.length
    ? getSelectedVariant()?.images?.map(item => item?.preview?.image?.url)
    : // : [fetch_store_product_detail?.product_detail?.product_image_url];
      default_images;

 

  const handleQty = async (shop_id, variant_id, value) => {
    if (qty) {
      await dispatch(_addToCart(shop_id, variant_id, value));
    } else {
      setLocalQty(localQty + value);
    }
  };

  const deleteProduct = () => {
    const shopId = fetch_store_product_detail?.shop_detail?.shop_id;
    const variantId = getSelectedVariant()?.variant_id;
    dispatch(_removeCartProduct(shopId, variantId));
    setLocalQty(1);
  };

  const variantStock =
    (qty || localQty) == getSelectedVariant()?.variant_quantity;

  const _handleBuyNow = async () => {
    triggerHaptic();
    const userLogin = AuthNavigating();

    if (!userLogin) {
      dispatch(_cartBottomSheet(false));
      return;
    }

    const defaultAddressItem = fetch_address.find(
      addr => addr?.address_default_select,
    );

    if (!defaultAddressItem) {
      dispatch(_cartBottomSheet(false));
      navigation.navigate('CreateAddress'); // Navigate to create address screen
      return;
    }

    if (userLogin) {
      const item = {
        shop: fetch_store_product_detail?.shop_detail,
        products: [
          {
            product_variant: {
              product: fetch_store_product_detail?.product_detail,
              variant: getSelectedVariant(),
            },
            quantity: qty || localQty,
          },
        ],
      };

   
      setCheckOutLoader(true);
      const response = await await dispatch(
        _checkout(item, fetch_user_detail?.id, '', shopifyCheckout),
      );
      setCheckOutLoader(false);
      if (response) {
        setCheckOutDetail(response);
      }
    }
  };

  const shopId = fetch_store_product_detail?.shop_detail?.shop_id;

  const getQty = () => {
    const shopId = fetch_store_product_detail?.shop_detail?.shop_id;
    // const selectedVariant = getSelectedVariant();
    const variantId = getSelectedVariant()?.variant_id;

    if (!shopId || !variantId) {
   
      return 0;
    }
    const cartShop = cart.find(item => item.shop_id === shopId);
    if (cartShop) {
      const cartVariant = cartShop.product_variant.find(
        variant => variant.variant_id === variantId,
      );
      if (cartVariant) {
        return cartVariant?.qty;
      } else {
        return 0;
      }
    } else {
      return 0;
    }
  };

  const qty = getQty();

  const _handleFavorite = async value => {
    try {
      setFavorite(value);
      const data = {
        wishlist_product_id:
          fetch_store_product_detail?.product_detail?.product_id,
      };
      const response = await dispatch(
        _favoriteUpdateStatus(
          fetch_store_product_detail?.product_detail?.product_id,
          !favorite,
          data,
          false,
          false,
          true,
        ),
      );
    } catch (error) {
    
    }
  };

  useEffect(() => {
    if (fetch_store_product_detail?.product_detail?.product_id) {
      fetchRelatedProducts();
    }
  }, [fetch_store_product_detail]);

  return {
    renderSimilarProducts,
    renderVariant,
    dispatch,
    fetch_store_product_detail_loader,
    fetch_store_product_detail,
    variantData: updatedData,
    variant,
    images,
    qty,
    handleValue,
    result,
    getSelectedVariant,
    setLocalQty,
    localQty,
    handleQty,
    deleteProduct,
    variantStock,
    _handleBuyNow,
    checkOutLoader,
    product_id,
    _handleFavorite,
    favorite,
    shop_detail,
    default_images,
    scrollRef,
    productDetailReview,
    relatedShops,
    displayImages,
    syncingCart,
    fetch_store_products,
    relatedProductLoader,
    relatedProducts,
    defaultHeight,
    brand_screen,
    isFocused,
    fetch_store_product_detail_error,
    fetchAPI,
  };
};

export default useProductDetail;

const styles = StyleSheet.create({
  similarProductCard: {
    marginRight: WH.width('2%'),
  },
  variant: {
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: WH.width(2),
    ...shadow,
    backgroundColor: 'white',
    padding: 10,
    borderRadius: 10,
    marginBottom: 10,
  },
  variantImage: {
    width: WH.width(15),
    aspectRatio: 1,
    borderRadius: 10,
    backgroundColor: 'white',
  },
});
