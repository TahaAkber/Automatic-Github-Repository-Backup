import {
  View,
  Dimensions,
  StyleSheet,
  StatusBar,
  TouchableOpacity,
  Animated,
  FlatList,
  Text,
} from 'react-native';
import {font, globalStyle, margin} from '../../../constant/contstant';
import Icon from '../../../materialComponent/icon/icon';
import CustomImage from '../../../materialComponent/image/image';
import CustomText from '../../../materialComponent/customText/customText';
import CustomButton from '../../../materialComponent/customButton/customButton';
import {verticalScale} from 'react-native-size-matters';
import ShopTileCategories from '../../../component/shopTIleCategories/shopTIleCategories';
import {useState} from 'react';
import VariantCard from '../../../component/cards/variantCard/variantCard';
import {homeData} from '../../../constant/dummyData';
import OrderVariantCard from '../../../component/cards/orderVariantCard/orderVariantCard';

const {width, height, fontScale} = Dimensions.get('screen');

const ChatProduct = ({route, navigation}) => {
  const [scrollY] = useState(new Animated.Value(0));

  const shopTileOpacity = scrollY.interpolate({
    inputRange: [0, height * 0.3],
    outputRange: [1, 0], //fades out as you scroll
    extrapolate: 'clamp',
  });
  const shopTileHeight = scrollY.interpolate({
    inputRange: [0, height * 0.3],
    outputRange: [0, height * 0.08], // Expands into view
    extrapolate: 'clamp',
  });
  const products = [
    {
      id: 1,
      name: 'Super Cropped Button...',
      order_id: '92287157',
      image: 'IMAGE_URL',
      price: 104.99,
      rating: 4.5,
    },
    {
      id: 2,
      name: 'Casual Hoodie',
      order_id: '92287158',
      image: 'IMAGE_URL',
      price: 89.99,
      rating: 4.2,
    },
    {
      id: 3,
      name: 'Super Cropped Button...',
      order_id: '92287157',
      image: 'IMAGE_URL',
      price: 104.99,
      rating: 4.5,
    },
    {
      id: 4,
      name: 'Casual Hoodie',
      order_id: '92287158',
      image: 'IMAGE_URL',
      price: 89.99,
      rating: 4.2,
    },
    {
      id: 5,
      name: 'Super Cropped Button...',
      order_id: '92287157',
      image: 'IMAGE_URL',
      price: 104.99,
      rating: 4.5,
    },
    {
      id: 6,
      name: 'Casual Hoodie',
      order_id: '92287158',
      image: 'IMAGE_URL',
      price: 89.99,
      rating: 4.2,
    },
    {
      id: 7,
      name: 'Super Cropped Button...',
      order_id: '92287157',
      image: 'IMAGE_URL',
      price: 104.99,
      rating: 4.5,
    },
    {
      id: 8,
      name: 'Casual Hoodie',
      order_id: '92287158',
      image: 'IMAGE_URL',
      price: 89.99,
      rating: 4.2,
    },
  ];
  const [isChecked, setIsChecked] = useState(false);
  const [selectedItems, setSelectedItems] = useState([]);

  const toggleSelection = id => {
    setSelectedItems(prev =>
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id],
    );
  };
  const handleSend = () => {
    const selectedProductsData = selectedItems.map(id =>
      products.find(product => product.id === id),
    );

    navigation.replace('Chat', {
      fromChatProduct: true,
      selectedProducts: selectedProductsData,
      name: name,
    });
  };

  return (
    <View style={styles.container}>
      <StatusBar
        animated
        barStyle={'dark-content'}
        backgroundColor={'white'}
        translucent={false}
      />
      <View style={styles.header}>
        <View style={globalStyle.row}>
          <TouchableOpacity
            onPress={() => {
              if (route.params?.fromChatProduct) {
                navigation.reset({
                  index: 0,
                  // routes: [{ name: "Inbox" }] // 🔹 Ensure it goes to Inbox
                });
              } else {
                navigation.goBack();
              }
            }}>
            <Icon
              icon_type={'AntDesign'}
              name={'arrowleft'}
              color={'black'}
              size={18}
              style={{margin: '1%'}}
            />
          </TouchableOpacity>
          <CustomImage
            style={styles.image}
            source={{
              uri: 'https://s3-alpha-sig.figma.com/img/fbc1/4c1d/c3a96ba57eb32020d565abdd8b64b19b?Expires=1738540800&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=Ja2u-FVfT-Wa0zev2JMx~TIffwzPrXN~Ni0I8S3gLlTLZ2lgfGa7op5--gKlRomq4GiaZAGpf-zltYZTM~8h1~ZbyUnRry-7Ds8SVeg7s2lcElj3LfWFoffDpPz1h8o4tOp7wF2AC02ReR~~QEK40ujzv0gKeFojkW8MnQMfQaZplhwG82oJrKYxlbwxQr2XnaUZYuP1mrc5bu~6uih-wzOQhm~ebLzTgSipzQpspFjqLGOqXfjt1XDCrLD3elo1886IrugOdGme5meX~ydH3nLTUbO8iLSBh6tFjhxiXyPFqGuTB9NQy5SZXHg4UWZLe2m9zMLPXrGfJ8hgDGq1Vw__',
            }}
          />
          <View style={styles.nameView}>
            <CustomText
              text={'tester'}
              color={'#000E08'}
              fontFamily={font.bold}
              fontSize={fontScale * 16}
            />
            <View style={{flexDirection: 'row'}}>
              <CustomText
                text={'4.6 '}
                fontSize={fontScale * 13}
                fontFamily={font.bold}
              />

              <Icon icon_type={'Entypo'} name={'star'} color={'#9FCD22'} />
              <CustomText
                text={' (865)'}
                fontSize={fontScale * 13}
                fontFamily={font.bold}
              />
            </View>
          </View>
        </View>
        <CustomButton
          text={'Visit Store'}
          backgroundColor={'black'}
          buttonStyle={{height: height * 0.035, marginLeft: '40%'}}
          width={width * 0.23}
          fontSize={fontScale * 10}
          textStyle={{color: '#fff', fontFamily: font.bold}}
        />
      </View>
      <Animated.View
        style={{
          opacity: shopTileOpacity,
          height: shopTileHeight,
          overflow: 'hidden',
        }}>
        <ShopTileCategories item={[]} marginTop={height * 0.2} />
      </Animated.View>
      <ShopTileCategories item={[]} />
      <View style={{flex: 1, backgroundColor: 'white'}}>
        <FlatList
          data={products}
          keyExtractor={item => item.id.toString()}
          renderItem={({item, index}) => (
            <OrderVariantCard
              index={index}
              product={item}
              headingSize={18}
              // image={item.image}
              qty={false}
              showCheckbox={true}
              isSelected={selectedItems.includes(item.id)}
              onSelect={() => toggleSelection(item.id)}
              productName={false}
              price={item.price}
              rating={item.rating}
              showProductName={true} // Show product name instead of order ID
              showRating={true} // Display rating
            />
          )}
        />
        <View style={styles.bottomContainer}>
          {/* Total Section (Grey) */}
          <View style={styles.totalContainer}>
            <CustomText
              text={`Total ${selectedItems.length}`}
              fontSize={16}
              fontFamily={font.bold}
              color={'black'}
            />
          </View>

          {/* Diagonal Cut */}
          <View style={styles.triangleCut} />

          {/* Send Section (Blue) */}
          <TouchableOpacity
            style={styles.sendButton}
            activeOpacity={1}
            onPress={handleSend}>
            <CustomText
              text={'Send'}
              fontSize={16}
              fontFamily={font.bold}
              color={'white'}
            />
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};

export default ChatProduct;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
  },
  image: {
    width: '21%',
    aspectRatio: 1,
    marginRight: '3%',
    borderRadius: 180,
  },
  header: {
    paddingTop: verticalScale(10),
    marginBottom: height * 0.02,
    paddingHorizontal: margin.horizontal,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  // containert: {
  //     // flex: 1,
  //     alignItems: 'center',
  //     justifyContent: 'center',
  //     // paddingTop: 5,
  //     backgroundColor: '#ecf0f1',
  //     // position:"absolute"

  //     width:width * 1

  //   },
  //   triangleCorner: {
  //     // position: 'absolute',
  //     // top:0,
  //     // left:0,
  //     // bottom:0,
  //     width: width* 1,
  //     // height: 200,

  //     backgroundColor: 'transparent',
  //     borderStyle: 'solid',
  //     borderLefttWidth: 50,
  //     borderTopWidth: 80,
  //     borderRightColor: 'transparent',
  //     borderTopColor: '#004CFF',

  //   },
  //   triangleCorner1: {
  //     position: 'absolute',
  //     top:0,
  //     left:0,
  //     bottom:0,
  //     width: width * 0.6,
  //     // height: 200,
  //     backgroundColor: 'transparent',
  //     borderStyle: 'solid',
  //     borderRightWidth: 50,
  //     borderBottomWidth: 80,
  //     borderRightColor: 'transparent',
  //     borderBottomColor: '#b2b2b2'
  //   },triangleCornerLayer: {
  //     // position: 'absolute',
  //     // top:0,
  //     // left:0,
  //     // bottom:0,
  //     // width:300,
  //     // height: 200,
  //     // backgroundColor: 'transparent',
  //     // borderStyle: 'solid',
  //     // borderRightWidth: 47,
  //     // borderTopWidth: 75,
  //     // borderRightColor: 'transparent',
  //     // borderTopColor: 'white'
  //   },
  bottomContainer: {
    flexDirection: 'row',
    height: height * 0.06, // Adjusts based on screen size
    alignItems: 'center',
    backgroundColor: '#b2b2b2',
  },

  // Total Section (Grey)
  totalContainer: {
    flex: 1,
    backgroundColor: '#b2b2b2',
    justifyContent: 'center',
    alignItems: 'center',
    height: height * 0.06,
  },

  // Send Section (Blue)
  sendButton: {
    flex: 0.9,
    backgroundColor: '#004CFF',
    justifyContent: 'center',
    alignItems: 'center',
    height: height * 0.06,
  },

  // Triangle cut effect between Total & Send
  triangleCut: {
    position: 'absolute',
    left: width * 0.45, // Adjust based on proportion
    bottom: 0,
    width: 0,
    height: 0,
    top: 0,
    borderStyle: 'solid',
    borderLeftWidth: 40, // Controls diagonal size
    borderTopWidth: height * 0.08, // Same as bottomContainer height
    borderLeftColor: 'transparent',
    borderTopColor: '#004CFF', // Matches Send button color
  },
});
