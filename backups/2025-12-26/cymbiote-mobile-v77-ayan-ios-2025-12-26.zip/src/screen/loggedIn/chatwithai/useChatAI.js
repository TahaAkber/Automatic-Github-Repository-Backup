import {_getStoreProductDetail} from '@redux/actions/merchant/merchant';
import CheckOutCard from '@component/cards/CheckOutCard/CheckOutCard';
import {useCallback, useEffect, useState} from 'react';
import {_getCardItems} from '@redux/actions/cart/cart';
import useReduxStore from '@utils/hooks/useReduxStore';
import {_getAddress} from '@redux/actions/user/user';
import {_commonDispatcher} from '../../../redux/actions/common/common';
import {FETCH_CART_DB_ITEM_LOADER} from '../../../redux/types/cart/cart';

const useChatAI = ({}) => {
  const {getState, dispatch} = useReduxStore();

  const {data, loading} = getState('chatAi');

  const [pullLoader, setPullLoader] = useState(false);
  const [editAddress, setEditAddress] = useState(false);

  const fetchAPI = async isLoading => {
    !isLoading && setPullLoader(true);
    await dispatch(_getAddress(fetch_user_detail?.id));
    await dispatch(_getCardItems());
    setPullLoader(false);
  };

  return {
    fetchAPI,
    data,
    loading,
  };
};

export default useChatAI;
