import { StatusBar, StyleSheet, Text, View ,Dimensions, TouchableOpacity,ScrollView} from "react-native"
import CustomText from "../../../materialComponent/customText/customText"
import Header from "../../../component/header/header"
import HelpCenterHeader from "../../../component/header/helpCenterHeader"
import InnerHeader from "../../../component/header/innerHeader"
import { colors, font, margin } from "../../../constant/contstant"
import HelpSearch from "../../../component/helpCenter/helpSearch"
import OrderManagment from "@assets/images/OrderManagment.svg"
import TrackOrer from "@assets/images/TrackOrer.svg"
import CancelOrder from "@assets/images/CancelOrder.svg"
import OrderReward from "@assets/images/OrderReward.svg"
import ProfileIcon from "@assets/images/ProfileIcon.svg"
import CustomerCareSvg from "@assets/images/customerCare.svg"
import Icon from "../../../materialComponent/icon/icon"
import { positional } from "yargs"
import ChildLineCard from "@component/cards/childLineCard/childLineCard"
import HelpSvg from "@assets/images/help.svg"



const { width, height, fontScale } = Dimensions.get("screen")

const  HelpCenter =({navigation})=>{
    return(
       
        <View style ={styles.container}>
          <StatusBar animated barStyle={"dark-content"} backgroundColor={"white"} translucent={false} />
          
            <HelpCenterHeader navigation={navigation} title={"Help Center"} IconComponent={HelpSvg} showBackIcon={false}/>
            
            <HelpSearch/>
            <ScrollView style={{ flexGrow: 1, }} showsVerticalScrollIndicator={false}>
                <CustomText text={"Self Sevice"} marginTop={"4%"} fontSize={fontScale * 22} style={styles.SelfService} fontFamily={font.bold}/>
                <View style ={styles.orderDetailsView}> 
                    <View style ={styles.OrderManagment}>
                        <TouchableOpacity onPress={()=> navigation.navigate("OrderManagemanet")}>
                        <OrderManagment width={width * 0.07} height={height * 0.07}/>
                        </TouchableOpacity> 
                        <CustomText text={"Orders Management"} style={styles.menuText}/>
                    </View>
                    <View style ={styles.OrderManagment}>

                        <TrackOrer width={width * 0.07} height={height * 0.07}/>
                        <CustomText text={"Track My Orders"} style={styles.menuText}/>
                    </View>
                    <View style ={styles.OrderManagment}>

                        <CancelOrder width={width * 0.07} height={height * 0.07}/>
                        <CustomText text={"Canvelled My Order"} style={styles.menuText}/>
                    </View>
                    <View style ={styles.OrderManagment}>

                        <OrderReward width={width * 0.07} height={height * 0.07}/>
                        <CustomText text={"Rewards"} style={styles.menuText}/>
                    </View>
                    <View style ={styles.OrderManagment}>

                        <ProfileIcon width={width * 0.07} height={height * 0.07}/>
                        <CustomText text={"Profile"} style={styles.menuText}/>
                    </View>
                </View>
                <CustomText text={"Most Asking Questions"} marginTop={"4%"} fontSize={fontScale * 18} style={styles.SelfService} fontFamily={font.bold} />
                <View style={styles.description}>
                    <CustomText text={"What is the most popular online shopping store?"} fontFamily={font.medium} fontSize={fontScale * 14} style={styles.descriptionText}/>
                    <Icon icon_type={"MaterialIcons"} name={"expand-less"}  size={fontScale * 24} color={"black"} />
                </View>
                <CustomText text={"Morbi adipiscing gravida dolor dui tincidunt libero. Duis malesuada massa libero nec accumsan nunc gravida."} fontFamily={font.light} fontSize={fontScale * 14} style={styles.details} marginTop={5}/>
                <View style={styles.line}/>
                <View style={styles.description}>
                    <CustomText text={"Why online shopping is popular nowadays?"} fontFamily={font.medium} fontSize={fontScale * 14} style={styles.descriptionText}/>
                    <Icon icon_type={"MaterialIcons"} name={"expand-more"}  size={fontScale * 24} color={"black"} />
                </View>
                <View style={styles.line}/>
                <View style={styles.description}>
                    <CustomText text={"Is one of the largest online shopping website in the world?"} fontFamily={font.medium} fontSize={fontScale * 14} style={styles.descriptionText}/>
                    <Icon icon_type={"MaterialIcons"} name={"expand-more"}  size={fontScale * 24} color={"black"} />
                </View>
                <CustomText text={"Stil Need Help?"} marginTop={"4%"} fontSize={fontScale * 18} style={styles.SelfService} fontFamily={font.bold} />
                <View style ={styles.customerCareBox}>
                <ChildLineCard 
                firstIcon={CustomerCareSvg}
                heading={"Customer Care"}
                headingFontSize={fontScale * 14}
                firstLineCode={"Chat with our customer representative"}
                marginTop={height * 0.01}
                // style={{ padding: 0, paddingVertical: height * 0.02, paddingHorizontal: width * 0.01 }}
                fontSize={fontScale * 10}/>

                
                </View>
                </ScrollView>

        </View>
    )
}
export default HelpCenter;

const  styles= StyleSheet.create({
    container:{
        flex:1,
        backgroundColor:"white"
    },
    SelfService:{
        marginHorizontal:margin.horizontal
    },
    orderDetailsView:{
        flexDirection:"row",
        alignItems:"center",
        justifyContent:"space-between",
        marginHorizontal:margin.horizontal,
     },
    OrderManagment:{
        alignItems: "center",
        justifyContent: "center",
        width: width * 0.18,
        // borderWidth:1
    },
    menuText: {
        textAlign: "center",
        
        fontSize: fontScale * 12,
        height: height * 0.05,
      },
      description:{
        marginHorizontal:margin.horizontal,
        flexDirection:"row",
        alignItems:"center",
        justifyContent:"space-between",
        marginTop:"2%"

      },
      descriptionText:{
        width:width * 0.7,
      },
      details:{
        marginHorizontal:margin.horizontal,
        // borderWidth:1,
        
        

      },
      line:{
        // backgroundColor: colors.light_theme.borderColor,
        backgroundColor:"#b2b2b2",
        height:height * 0.001,
        marginHorizontal:margin.horizontal,
        marginTop:"5%"

      },
      customerCareBox:{
        marginHorizontal:margin.horizontal,
      }

   

})
