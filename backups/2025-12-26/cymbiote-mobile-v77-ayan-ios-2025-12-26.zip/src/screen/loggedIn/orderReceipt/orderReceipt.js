import React, {useEffect, useRef} from 'react';
import {
  Dimensions,
  StyleSheet,
  View,
  StatusBar,
  FlatList,
  TouchableOpacity,
  Platform,
  ScrollView,
} from 'react-native';
import Content from '@materialComponent/content/content';
import useOrderReceipt from './useOrderReceipt';
import Container from '@materialComponent/container/container';
import OrderDetailLoader from '@component/loader/orderDetailLoader';
import {font, globalStyle, margin, shadow} from '../../../constant/contstant';
import Header from '../../../component/header/header';
import InnerHeader from '../../../component/header/innerHeader';
import SummaryTable from '../../../component/table/summaryTable';
import BorderLine from '../../../component/borderLine/borderLine';
import CustomText from '../../../materialComponent/customText/customText';
import CustomImage from '../../../materialComponent/image/image';
import Icon from '../../../materialComponent/icon/icon';
import {moderateScale} from 'react-native-size-matters';
import CustomButton from '../../../materialComponent/customButton/customButton';
import ViewShot, {captureScreen, captureRef} from 'react-native-view-shot';
import Share from 'react-native-share';
import RNFS from 'react-native-fs';

const {height, width, fontScale} = Dimensions.get('screen');

const OrderReceipt = ({route}) => {
  const {order_id, socialOrderItem} = route.params;
  const {
    fetch_order_detail,
    fetch_order_detail_loader,
    totalCharges,
    renderItem,
    handleShare,
    scrollRef,
    showShareIcon,
  } = useOrderReceipt({order_id, socialOrderItem});

  return (
    <>
      {fetch_order_detail_loader ? (
        <OrderDetailLoader loading={true} />
      ) : (
        <Container backgroundColor={'white'} barColor={'white'}>
          <ScrollView
            collapsable={false}
            contentContainerStyle={styles.content}
            key={1}>
            <ViewShot ref={scrollRef}>
              <View style={styles.mainView}>
                <StatusBar
                  animated
                  barStyle="dark-content"
                  backgroundColor={'white'}
                  translucent={false}
                />
                <InnerHeader
                  onPressShare={handleShare}
                  share={showShareIcon}
                  style={{
                    backgroundColor: 'white',
                    marginBottom: 0,
                    paddingBottom: height * 0.02,
                  }}
                  title={`Receipt ${fetch_order_detail?.order_title || socialOrderItem?.order_id_display}`}
                />
                <View
                  style={{
                    paddingHorizontal: margin.horizontal,
                    backgroundColor: 'white',
                    paddingTop: height * 0.02,
                  }}>
                  {(
                    fetch_order_detail?.order_item ||
                    socialOrderItem?.products ||
                    []
                  ).map((item, index) => renderItem({item, index}))}
                  {/* Footer content */}
                  <View style={{marginBottom: height * 0.01}}>
                    <SummaryTable
                      marginTop={height * 0.015}
                      label={`Subtotal (${
                        fetch_order_detail?.order_item?.length ||
                        socialOrderItem?.products?.length
                      } item)`}
                      value={
                        (fetch_order_detail?.shop_detail?.shop_currency ||
                          socialOrderItem?.currency) +
                        ' ' +
                        totalCharges.subTotal
                      }
                    />
                    <SummaryTable
                      marginTop={height * 0.015}
                      label={'Discount'}
                      value={
                        (fetch_order_detail?.shop_detail?.shop_currency ||
                          socialOrderItem?.currency) +
                        ' ' +
                        totalCharges.orderDiscount
                      }
                    />
                    <SummaryTable
                      marginTop={height * 0.015}
                      label={'Shipping Fee'}
                      value={
                        totalCharges.orderShippingFee == 'Free'
                          ? totalCharges.orderShippingFee
                          : (fetch_order_detail?.shop_detail?.shop_currency ||
                              socialOrderItem?.currency) +
                            ' ' +
                            totalCharges.orderShippingFee
                      }
                    />
                    <SummaryTable
                      marginTop={height * 0.015}
                      label={'Tax'}
                      value={
                        (fetch_order_detail?.shop_detail?.shop_currency ||
                          socialOrderItem?.currency) +
                        ' ' +
                        totalCharges.orderTax
                      }
                    />
                    <BorderLine
                      style={{
                        marginLeft: 0,
                        width: '100%',
                        marginTop: height * 0.015,
                        height: height * 0.001,
                      }}
                    />
                    <SummaryTable
                      fontSize={fontScale * 16}
                      fontFamily={font.bold}
                      marginTop={height * 0.01}
                      label={'Total'}
                      value={
                        (fetch_order_detail?.shop_detail?.shop_currency ||
                          socialOrderItem?.currency) +
                        ' ' +
                        totalCharges.totalAmount
                      }
                    />
                  </View>
                </View>
                <BorderLine
                  style={{height: height * 0.012}}
                  marginTop={height * 0.02}
                />
                <View
                  style={{
                    paddingVertical: height * 0.01,
                    paddingHorizontal: margin.horizontal,
                    marginTop: height * 0.01,
                    backgroundColor: 'white',
                  }}>
                  <View>
                    <CustomText
                      fontFamily={font.bold}
                      fontSize={fontScale * 16}
                      text={'Shipping address'}
                    />
                    <CustomText
                      fontFamily={font.regular}
                      fontSize={fontScale * 15}
                      marginTop={height * 0.012}
                      text={
                        fetch_order_detail?.order_delivery_address ||
                        socialOrderItem?.shipping_address
                      }
                    />
                  </View>
                  <View style={{marginTop: height * 0.02}}>
                    <CustomText
                      fontFamily={font.bold}
                      fontSize={fontScale * 16}
                      text={'Billing address'}
                    />
                    <CustomText
                      fontFamily={font.regular}
                      fontSize={fontScale * 15}
                      marginTop={height * 0.012}
                      text={
                        'Same as shipping address' ||
                        socialOrderItem?.billing_address
                      }
                    />
                  </View>
                  <View style={{marginTop: height * 0.02}}>
                    <CustomText
                      fontFamily={font.bold}
                      fontSize={fontScale * 16}
                      text={'Shipping method'}
                    />
                    <CustomText
                      fontFamily={font.regular}
                      fontSize={fontScale * 15}
                      marginTop={height * 0.012}
                      text={'Standard'}
                    />
                  </View>
                  {showShareIcon ? (
                    <View style={{marginTop: height * 0.02}}>
                      <CustomText
                        fontFamily={font.bold}
                        fontSize={fontScale * 16}
                        text={'Email address'}
                      />
                      <CustomText
                        fontFamily={font.regular}
                        fontSize={fontScale * 15}
                        marginTop={height * 0.012}
                        text={
                          fetch_order_detail?.user_email ||
                          socialOrderItem?.customer_email
                        }
                      />
                    </View>
                  ) : (
                    <></>
                  )}

                  <View style={{marginTop: height * 0.02}}>
                    <CustomText
                      fontFamily={font.bold}
                      fontSize={fontScale * 16}
                      text={'Shop'}
                    />
                    <View
                      style={{
                        marginTop: height * 0.008,
                        flexDirection: 'row',
                        alignItems: 'center',
                      }}>
                      <CustomImage
                        style={{
                          width: width * 0.11,
                          aspectRatio: 1,
                          borderRadius: 180,
                          marginRight: width * 0.02,
                        }}
                        source={{
                          uri:
                            fetch_order_detail?.shop_detail?.shop_logo_url ||
                            socialOrderItem?.shop_logo_url,
                        }}
                      />
                      <CustomText
                        fontFamily={font.medium}
                        fontSize={fontScale * 15}
                        text={
                          fetch_order_detail?.shop_detail?.shop_name ||
                          socialOrderItem?.shop_name
                        }
                      />
                    </View>
                  </View>
                  <BorderLine
                    style={{height: height * 0.002}}
                    marginTop={height * 0.02}
                  />
                  {/* <CustomButton
                                        iconType={"FontAwesome"}
                                        name={"share"}
                                        size={moderateScale(20)}
                                        text={"Share receipt"}
                                        onPress={handleShare}
                                        marginTop={height * 0.02}
                                    /> */}
                </View>
              </View>
            </ViewShot>
          </ScrollView>
        </Container>
      )}
    </>
  );
};
export default OrderReceipt;

const styles = StyleSheet.create({
  mainView: {
    flex: 1,
    backgroundColor: 'white',
  },
  content: {
    paddingBottom: height * 0.2,
  },
});
