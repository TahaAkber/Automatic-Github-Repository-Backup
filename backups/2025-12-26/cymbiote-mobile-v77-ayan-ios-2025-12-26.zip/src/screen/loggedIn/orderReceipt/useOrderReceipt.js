import React, {useState, useRef, useCallback, useEffect} from 'react';
import {Dimensions, View, Animated, LayoutAnimation} from 'react-native';
// import VariantCard from '@component/cards/variantCard/variantCard';
import VariantCard from '../../../component/cards/variantCard/variantCard';
import useReduxStore from '@utils/hooks/useReduxStore';
import {homeData} from '../../../constant/dummyData';
import OrderVariantCard from '../../../component/cards/orderVariantCard/orderVariantCard';
import {
  _getOrderDetail,
  _getOrderReceipt,
} from '../../../redux/actions/orders/orders';
import {font, statusMap} from '../../../constant/contstant';
import {
  formatPrice,
  shareItems,
  toFixedMethod,
} from '../../../utils/helper/helper';
import {useFocusEffect} from '@react-navigation/native';
import {Permission} from '../../../utils/imagePicker/imagePicker';
import {captureRef} from 'react-native-view-shot';
import Share from 'react-native-share';

const {height, width, fontScale} = Dimensions.get('screen');

const useOrderDetail = ({order_id, socialOrderItem}) => {
  const {getState, dispatch} = useReduxStore();
  // const { fetch_order_detail, fetch_order_detail_loader } = getState('order');
  const [fetch_order_detail_loader, set_fetch_order_detail_loader] =
    useState(true);
  const [fetch_order_detail, set_fetch_order_detail] = useState({});
  const [showShareIcon, setShowShareIcon] = useState(true);
  const scrollRef = useRef();

  const fetchAPI = async () => {
    set_fetch_order_detail_loader(true);
    const response = await dispatch(_getOrderReceipt(order_id));
    set_fetch_order_detail_loader(false);
    set_fetch_order_detail(response);
  };

  // useEffect(() => {
  //     fetchAPI()
  // }, [])

  useFocusEffect(
    useCallback(() => {
      fetchAPI();
    }, []),
  );

  const shop = {
    shop_is_active: true,
    shop_logo_url: socialOrderItem?.shop_logo_url,
    shop_name: socialOrderItem?.shop_name,
    shop_email: socialOrderItem?.shop_email,
  };

  const renderItem = useCallback(
    ({item, index}) => {
      const image = item?.product_image_url
        ? item?.product_image_url
        : item?.variant?.images?.length
        ? item?.variant?.images?.[0]?.preview?.image.url
        : item.product?.product_image_url;

      // item.variant.variant_price = item?.order_item_price

      return (
        <>
          <View style={{marginTop: index == 0 ? 0 : height * 0.015}}>
            <VariantCard
              borderWidth={'100%'}
              index={0}
              isDisabled={false}
              display={true}
              product={item?.product}
              qty={item?.order_item_quantity || item?.quantity}
              variantStock={true}
              shop={fetch_order_detail.shop_detail || shop}
              variant={item?.variant}
              image={image}
              // removeBorder={true}
              imageStyle={{width: width * 0.17}}
              marginTop={height * 0.01}
              opitonsMarginTop={height * 0.013}
              priceSize={fontScale * 11}
              priceFontFamily={font.medium}
              headingSize={fontScale * 11}
              imageQty={true}
              productTitle={item?.product?.product_name || item?.product_name}
              borderTopMargin={height * 0.015}
              optionHeight={height * 0.02}
              optionFontSize={fontScale * 10}
              priceText={item?.order_item_price || item?.price}
            />
          </View>
        </>
      );
    },
    [fetch_order_detail],
  );

  const subTotal = (
    socialOrderItem?.products || fetch_order_detail?.order_item
  )?.reduce((sum, item) => {
    return (
      sum +
      (item.order_item_price || item?.price) *
        (item.order_item_quantity || item?.quantity)
    );
  }, 0);

  const totalCharges = {
    subTotal: `${formatPrice(toFixedMethod(subTotal))}`,
    orderTax: `${formatPrice(
      toFixedMethod(
        socialOrderItem?.order_tax || fetch_order_detail?.order_tax,
      ),
    )}`,
    orderShippingFee:
      fetch_order_detail?.order_shipping_fee === 0 ||
      socialOrderItem?.shipping_fee == 0.0
        ? 'Free'
        : `${formatPrice(
            toFixedMethod(
              socialOrderItem?.shipping_fee ||
                fetch_order_detail?.order_shipping_fee,
            ),
          )}`,
    orderDiscount:
      (fetch_order_detail?.order_total_discount_amount ||
        socialOrderItem?.order_discount) > 0
        ? `${formatPrice(
            toFixedMethod(
              socialOrderItem?.order_discount ||
                fetch_order_detail?.order_total_discount_amount,
            ),
          )}`
        : '0.00',
    totalAmount:
      (socialOrderItem?.total_amount ||
        fetch_order_detail?.order_total_amount) > 0
        ? `${formatPrice(
            toFixedMethod(
              socialOrderItem?.total_amount ||
                fetch_order_detail?.order_total_amount,
            ),
          )}`
        : '0.00',
  };

  console.log(socialOrderItem, '<fetch_order_detail>>>');

  const handleShare = async () => {
    setShowShareIcon(false);
    setTimeout(async () => {
      try {
        if (!scrollRef.current) {
          console.warn('ScrollView ref not ready');
          setShowShareIcon(true);
          return;
        }

        const base64 = await captureRef(scrollRef.current, {
          format: 'jpg',
          quality: 1,
          result: 'tmpfile',
          fileName: 'receipt_',
        });

        if (!base64) {
          console.warn('Base64 result is empty');
          setShowShareIcon(true);
          return;
        }

        const shareOptions = {
          title: 'Receipt Screenshot',
          url: `${base64}`,
          type: 'image/jpeg',
          message:
            'Hey, I just placed an order. Here’s my receipt if you want to take a look!',
        };

        await Share.open(shareOptions);
        setShowShareIcon(true);
      } catch (error) {
        console.log(
          'Failed to capture and share long screenshot:',
          error?.message,
        );
        setShowShareIcon(true);
      }
    }, 100);
  };

  return {
    renderItem,
    handleShare,
    fetch_order_detail,
    fetch_order_detail_loader,
    totalCharges,
    showShareIcon,
    scrollRef,
  };
};

export default useOrderDetail;
