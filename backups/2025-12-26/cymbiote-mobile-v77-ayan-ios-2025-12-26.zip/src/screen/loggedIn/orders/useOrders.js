import {useEffect, useState, useMemo, useCallback} from 'react';
import useReduxStore from '../../../utils/hooks/useReduxStore';
import {_getInternalOrder} from '../../../redux/actions/orders/orders';
import {pagination} from '../../../utils/helper/helper';
import {useFocusEffect, useIsFocused} from '@react-navigation/native';
import messaging from '@react-native-firebase/messaging';
import useOrderSocket from './useOrderSocket';

const useOrders = ({order = false}) => {
  const {dispatch, getState} = useReduxStore();
  const {
    fetch_internal_order,
    fetch_internal_order_loader,
    fetch_internal_order_error,
  } = getState('order');
  const {socialOrder} = useOrderSocket();

  const {fetch_user_detail, token} = getState('auth');
  const [id, setId] = useState(0);
  const [pullLoader, setPullLoader] = useState(false);
  const [page, setPage] = useState(1);
  const [paginationLoader, setPaginationLoader] = useState(false);
  const isFocused = useIsFocused();

  const fetchAPI = async isLoading => {
 

    if (order) {
      if (isLoading == 'refresh_remove' ? false : !isLoading)
        setPullLoader(true);
      if (!isLoading) setPage(1);

      // if (!isLoading)

      await dispatch(
        _getInternalOrder({
          page: 1,
          tab: id,
          pull: isLoading == 'refresh_remove' ? true : !isLoading,
        }),
      ); // ✅ Load first page
      setPullLoader(false);
    }
  };

  const paginationAPI = async () => {
    if (!paginationLoader) {
      try {
        const totalPages =
          fetch_internal_order?.[id]?.pagination?.totalPages || 1;
        const nextPagination = pagination(page, totalPages, setPage);
        if (nextPagination) {
          setPaginationLoader(true);
          const response = await dispatch(
            _getInternalOrder({page: nextPagination, tab: id, pull: true}),
          );
   
        }
      } catch (error) {
        console.error('Error fetching pagination data:', error);
      } finally {
        setPaginationLoader(false);
      }
    }
  };

  useEffect(() => {
    // fetchInitiateAPI();
    fetchAPI(true);
    setPage(1)
  }, [id, fetch_user_detail?.id]);

  useEffect(() => {
    const unsubscribe = messaging().onMessage(async remoteMessage => {
      if (remoteMessage?.data?.screenName === 'Orders') {
        setPage(1);
        dispatch(_getInternalOrder({page: 1, tab: id || 1, pull: true}));
      }
    });
    return unsubscribe;
  }, []);

  return {
    fetch_internal_order: fetch_internal_order,
    fetch_internal_order_loader,
    fetch_internal_order_error,
    pullLoader,
    paginationAPI,
    paginationLoader,
    fetchAPI,
    id,
    setId,
    socialOrder,
    page,
    isFocused,
  };
};

export default useOrders;
