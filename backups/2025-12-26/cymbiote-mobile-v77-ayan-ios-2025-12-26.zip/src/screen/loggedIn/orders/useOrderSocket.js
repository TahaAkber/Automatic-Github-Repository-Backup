import {useEffect, useRef, useState} from 'react';
import useReduxStore from '../../../utils/hooks/useReduxStore';
import { order_socket_url } from '../../../utils/url/url';

const useOrderSocket = () => {
  const {getState} = useReduxStore();
  const socketRef = useRef(null);
  const [isConnected, setIsConnected] = useState(false);
  const [socialOrder, setSocialOrder] = useState([]);
  const {fetch_user_detail} = getState('auth');

 

  const SOCKET_URL = `${order_socket_url}/api/auth/google/ws/${fetch_user_detail?.id}`;

  

  useEffect(() => {
    const socket = new WebSocket(SOCKET_URL);
    socketRef.current = socket;

    socket.onopen = () => {
     
      setIsConnected(true);
    };

    socket.onmessage = event => {
      try {
        const message = JSON.parse(event.data);
        if (message?.type === 'new_order' && message?.data) {
          setSocialOrder(prev => [
            ...prev,
            {
              ...message.data,
              created_at: message.data?.order_date,
              social_order: true,
            },
          ]);
        }
      } catch (err) {

      }
    };

    socket.onerror = error => {
      console.error('WebSocket error:', error);
    };

    socket.onclose = () => {

      setIsConnected(false);
    };

    return () => {
      socket.close();
    };
  }, []);

  const sendMessage = message => {
    if (socketRef.current && isConnected) {
      socketRef.current.send(JSON.stringify(message));
    } else {
      console.warn('Socket not connected. Cannot send message.');
    }
  };


  return {
    isConnected,
    sendMessage,
    socialOrder,
  };
};

export default useOrderSocket;
