import { useEffect, useState } from "react";
import useReduxStore from "../../../utils/hooks/useReduxStore";
import { _getCancellationEnums } from "../../../redux/actions/orders/orders";


const useCancellationEnums = () => {
    const { dispatch, getState } = useReduxStore();
    const { fetch_cancellation_enums, fetch_cancellation_enums_loader, fetch_cancellation_enums_error } = getState("order");

    // const fetchAPI = () => {
    //     if (!fetch_cancellation_enums.length) { // Fetch only if not already loaded
    //         dispatch(_getCancellationEnums(2));
    //     } // Fetch for shop_id = 2
    // };

    // useEffect(() => {
    //     fetchAPI();
    // }, []);

    return {
        fetch_cancellation_enums: fetch_cancellation_enums || [],
        fetch_cancellation_enums_loader,
        fetch_cancellation_enums_error
    };
};

export default useCancellationEnums;
