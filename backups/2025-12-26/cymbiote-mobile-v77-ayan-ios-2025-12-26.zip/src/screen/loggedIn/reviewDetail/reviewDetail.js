import {
  ActivityIndicator,
  Animated,
  Dimensions,
  StatusBar,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import React from 'react';
import InnerHeader from '@component/header/innerHeader';
import Content from '@materialComponent/content/content';
import OverAllReviewCard from '@component/cards/overAllReviewCard/overAllReviewCard';
import OrderVariantCard from '@component/cards/orderVariantCard/orderVariantCard';
import ReviewDetailLoader from '@component/loader/reviewDetailLoader'; // Import the loader
import useReviewDetail from './useReviewDetail';
import {colors, font, globalStyle} from '../../../constant/contstant';
import Icon from '../../../materialComponent/icon/icon';
import {moderateScale} from 'react-native-size-matters';
import CustomText from '../../../materialComponent/customText/customText';
import BottomSheetForLibrary from '../../../materialComponent/bottomSheet/cameraSheet';
import CustomImage from '../../../materialComponent/image/image';
import {timeAgo} from '../../../utils/helper/helper';
import Comment from '../../../component/cards/comment/comment';
import Container from '../../../materialComponent/container/container';

const {height, fontScale, width} = Dimensions.get('screen');

const ReviewDetail = ({route}) => {
  const {
    loader,
    reviewDetail,
    text,
    setText,
    refRBSheet,
    images,
    setImages,
    handleDeleteImage,
    setReplyComment,
    replyComment,
    handleLike,
    likeIconStyle,
    like,
    handleReplyPress,
    scrollRef,
    sendComment,
    commentLoader,
  } = useReviewDetail({route}); // Use the loader state

  console.log('reviewDetail', reviewDetail?.product?.variant);

  return (
    <Container barColor={'white'}>
      <View style={styles.container}>
        <StatusBar
          animated
          barStyle="dark-content"
          backgroundColor="white"
          translucent={false}
        />
        <InnerHeader notification={true} setting={true} title="Review Detail" />

        {/* Show loader if data is loading */}
        {loader ? (
          <ReviewDetailLoader loading={loader} />
        ) : (
          <Content
            ref={scrollRef}
            contentContainerStyle={{paddingBottom: height * 0.15}}>
            <View style={styles.reviewsCard}>
              {/* Product Details */}
              <OrderVariantCard
                heading={reviewDetail?.product?.product?.product_name}
                headingSize={fontScale * 12}
                imageStyle={{width: width * 0.15, aspectRatio: 1}}
                qty={false}
                showProductName={true}
                qtyStyle={{
                  position: 'absolute',
                  right: 0,
                  bottom: 0,
                  fontSize: fontScale * 10,
                }}
                endQty={`Qty ${reviewDetail?.order_item?.order_item_quantity}`}
                removePrice={true}
                optionsMarginTop={0.1}
                
                // removeOptions={true}
                // removeOptions={true}
                variant={reviewDetail?.product?.variant}
                image_url={reviewDetail?.product?.product?.product_image_url}
                textViewStyle={{height: width * 0.15}}
              />

              {/* Overall Reviews */}
              <View style={{marginTop: height * 0.02}}>
                <OverAllReviewCard
                  review_detail={reviewDetail}
                  slider={true}
                  comment={true}
                  likeSectionRemove={true}
                  elevation={0}
                  padding={10}
                  customWidth={width * 0.7}
                />
              </View>

              {reviewDetail?.comments?.length ? (
                reviewDetail?.comments?.map((item, index) => {
                  return (
                    <View>
                      <Comment
                        review_detail={reviewDetail}
                        item={item}
                        key={`comment_${index}`}
                        images={images}
                        handleReplyPress={() => handleReplyPress(item)}
                      />
                      {item.replies.map((childItem, childIndex) => {
                        return (
                          <Comment
                            review_detail={reviewDetail}
                            child={true}
                            item={childItem}
                            key={`child_${childIndex}`}
                            images={images}
                            handleReplyPress={() => handleReplyPress(childItem)}
                          />
                        );
                      })}
                    </View>
                  );
                })
              ) : (
                <></>
              )}

              {replyComment?.commentId ? (
                <View
                  style={{
                    marginTop: height * 0.02,
                    borderWidth: 1,
                    borderColor: '#E4E4E4',
                    borderRadius: 5,
                  }}>
                  <View style={{padding: width * 0.02}}>
                    <CustomText
                      fontSize={moderateScale(10)}
                      fontFamily={font.bold}
                      text={
                        replyComment?.commenterDetail?.shop_name ||
                        replyComment?.commenterDetail?.user_first_name +
                          ' ' +
                          replyComment?.commenterDetail?.user_last_name
                      }
                    />
                    <CustomText
                      fontSize={moderateScale(10)}
                      numberOfLines={2}
                      fontFamily={font.medium}
                      text={replyComment?.commentText}
                    />

                    <TouchableOpacity
                      onPress={() => setReplyComment({})}
                      style={{
                        position: 'absolute',
                        right: width * 0.01,
                        top: 2,
                        zIndex: 2,
                        width: 20,
                        height: 20,
                        borderRadius: 180,
                        backgroundColor: 'white',
                        alignItems: 'center',
                        justifyContent: 'center',
                        elevation: 2, // optional shadow on Android
                      }}>
                      <Icon
                        icon_type="Entypo"
                        name="cross"
                        size={14}
                        color="black"
                      />
                    </TouchableOpacity>
                  </View>
                  <View
                    style={{
                      backgroundColor: '#F3F6F6',
                      borderRadius: 5,
                      paddingHorizontal: '2%',
                      paddingBottom: '2%',
                    }}>
                    <View
                      style={{
                        width: '100%',
                        flexDirection: 'row',
                        justifyContent: 'space-between',
                      }}>
                      <TextInput
                        placeholder="Write a comment..."
                        placeholderTextColor={'#797C7B'}
                        style={styles.input}
                        onChangeText={text => setText(text)}
                        value={text}
                        multiline={true}
                        // numberOfLines={4} // optional: controls visible lines
                        // textAlignVertical="top" // ensures text starts at the top
                      />
                      <View
                        style={[
                          globalStyle.row,
                          {
                            alignItems: 'flex-start',
                            paddingTop: height * 0.015,
                          },
                        ]}>
                        <TouchableOpacity
                          onPress={() => refRBSheet?.current?.open()}
                          style={{}}>
                          <Icon
                            icon_type={'Entypo'}
                            name={'camera'}
                            color={'black'}
                            size={moderateScale(20)}
                          />
                        </TouchableOpacity>
                        {text ? (
                          commentLoader ? (
                            <ActivityIndicator
                              style={{marginLeft: 15}}
                              size={moderateScale(20)}
                              color={colors.light_theme.theme}
                            />
                          ) : (
                            <TouchableOpacity
                              onPress={sendComment}
                              style={{marginLeft: 15}}>
                              <Icon
                                icon_type={'Ionicons'}
                                name={'send'}
                                color={colors.light_theme.theme}
                                size={moderateScale(20)}
                              />
                            </TouchableOpacity>
                          )
                        ) : (
                          <></>
                        )}
                      </View>
                    </View>

                    {images.length ? (
                      <View style={globalStyle.row}>
                        {Array.isArray(images) &&
                          images.map((item, index) => (
                            <View
                              key={item?.uri || index}
                              style={{
                                marginRight: index === 0 ? width * 0.02 : 0,
                                position: 'relative',
                                zIndex: 1,
                              }}>
                              <CustomImage
                                style={styles.commentImage}
                                source={{uri: item?.uri}}
                              />

                              <View
                                style={{
                                  position: 'absolute',
                                  top: -5,
                                  right: -2,
                                  zIndex: 2,
                                  width: 12,
                                  height: 12,
                                  borderRadius: 5,
                                  backgroundColor: 'white',
                                  alignItems: 'center',
                                  justifyContent: 'center',
                                  // elevation: 2, // optional shadow on Android
                                }}>
                                <TouchableOpacity
                                  onPress={() => handleDeleteImage(index)}>
                                  <Icon
                                    icon_type="Entypo"
                                    name="cross"
                                    size={8}
                                    color="red"
                                  />
                                </TouchableOpacity>
                              </View>
                            </View>
                          ))}
                      </View>
                    ) : (
                      <></>
                    )}
                  </View>
                </View>
              ) : (
                <></>
              )}
            </View>
            <BottomSheetForLibrary
              multiple={true}
              images={images}
              setImages={setImages}
              refRBSheet={refRBSheet}
            />
          </Content>
        )}
      </View>
    </Container>
  );
};

export default ReviewDetail;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
  },
  reviewsCard: {
    marginHorizontal: 16,
    marginTop: height * 0.01,
  },
  input: {
    color: 'black',
    fontFamily: font.regular,
    fontSize: moderateScale(12),
  },
  commentImage: {
    width: width * 0.1,
    aspectRatio: 1,
    borderRadius: 8,
  },
  headerContainer: {
    flexDirection: 'row',
    // alignItems: "center",
  },
  imageWrapper: {
    width: '15%',
  },
  image: {
    width: '85%',
    aspectRatio: 1,
    borderRadius: 180,
  },
  detailsWrapper: {
    width: '70%',
  },
  starRatingContainer: {
    marginTop: height * 0.005,
  },
  timeText: {
    fontSize: fontScale * 13,
    marginLeft: '3%',
    color: '#333333',
  },
  dotsIconWrapper: {
    width: '15%',
    justifyContent: 'center',
    alignItems: 'center',
  },
  imagesContainer: {
    flexDirection: 'row',
    marginTop: height * 0.01,
  },
  thumbnailImage: {
    width: '15%',
    aspectRatio: 1,
    borderRadius: 5,
    marginRight: width * 0.02,
    borderWidth: 0.1,
    borderColor: colors.light_theme.gray,
  },
  borderLine: {
    marginLeft: 0,
    width: '95%',
    backgroundColor: '#00000033',
    height: height * 0.003,
    alignSelf: 'center',
    opacity: 0.3,
  },
  reactionContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: height * 0.01,
  },
  reactionItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: width * 0.06,
  },
  reactionText: {
    marginLeft: width * 0.02,
    fontSize: fontScale * 13,
  },
  commentBox: {
    flexDirection: 'row',
    width: '100%',
  },
});
