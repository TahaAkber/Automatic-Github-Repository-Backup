import {_getStores} from '@redux/actions/merchant/merchant';
import {_globalLoader} from '@redux/actions/common/common';
import useReduxStore from '@utils/hooks/useReduxStore';
import {_login} from '@redux/actions/auth/auth';
import {useFocusEffect, useNavigation} from '@react-navigation/native';
import {useCallback} from 'react';
import {_getUserNotificationStatuses} from '../../../redux/actions/user/user';

const useSettings = ({}) => {
  const {getState, dispatch} = useReduxStore();
  const {fetch_user_detail, token} = getState('auth');
  const navigation = useNavigation();

  useFocusEffect(
    useCallback(() => {
      dispatch(_getUserNotificationStatuses(fetch_user_detail?.id));
    }, []),
  );


  return {
    fetch_user_detail,
    token,
    navigation,
  };
};

export default useSettings;
