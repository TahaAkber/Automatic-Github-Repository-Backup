import React from 'react';
import {
    Dimensions,
    StatusBar,
    StyleSheet,
    TouchableOpacity,
    View,
} from 'react-native';
import { colors, globalStyle, shadow, margin, font, WH } from '@constant/contstant';
import useSettings from './useSettings';
import CustomText from '@materialComponent/customText/customText';
import SettingIcon from '@assets/images/setting';
import { ProfileDisplay } from '@helper/reUsableMethod/reUsableMethod';
import CustomImage from '@materialComponent/image/image';
import ProfileIcon from '@assets/images/profile.svg';
import ProfileItem from '@component/cards/profileItem/profileItem';
import Container from '../../../materialComponent/container/container';
import { useIsFocused } from '@react-navigation/native';
import { moderateScale } from 'react-native-size-matters';

const { width, height, fontScale } = Dimensions.get("screen");

const Profile = () => {
    const { fetch_user_detail, token } = useSettings({});
    const name = fetch_user_detail?.firstname ? (fetch_user_detail?.firstname + " " + fetch_user_detail?.lastname) : "Guest"
    const isFocused = useIsFocused()
    const filteredArr = arr.filter(item => !(item.option_name === "Sign out" && !token));

    return (
        <Container isFocused={isFocused} barColor={colors.light_theme.theme}>
            <View style={styles.mainView}>
                {/* <StatusBar animated barStyle="light-content" backgroundColor={colors.light_theme.theme} /> */}
                <View style={styles.header}>
                    <View style={globalStyle.row}>
                        <SettingIcon color='white' width={WH.width(4.5)} height={WH.width(4.5)} />
                        <CustomText style={styles.headerHeading} fontSize={moderateScale(18)} color="white" fontFamily={font.bold} text="Settings" />
                    </View>
                </View>
                <View style={styles.content}>
                    <View style={globalStyle.row}>
                        <TouchableOpacity activeOpacity={1} style={[styles.circle, shadow]}>
                            {fetch_user_detail?.profile ? (
                                <CustomImage source={{ uri: ProfileDisplay(token, fetch_user_detail?.profile) }} style={styles.header_image} />
                            ) : (
                                <ProfileIcon color="white" width={WH.width(3)} height={WH.width(3)} />
                            )}
                        </TouchableOpacity>
                        <View>
                            <CustomText fontSize={moderateScale(14)} text={name} />
                            <CustomText fontSize={moderateScale(12)} text={fetch_user_detail?.email || "Guest@example.com"} />
                        </View>
                    </View>
                    <View>
                        {filteredArr.map((item, index) => {
                            return (
                                <ProfileItem data={filteredArr} item={item} index={index} key={index} />
                            )
                        })}

                    </View>
                </View>
            </View>
        </Container>

    );
};

export default Profile;

const styles = StyleSheet.create({
    mainView: {
        flex: 1,
        backgroundColor: 'white',
    },
    header: {
        backgroundColor: colors.light_theme.theme,
        paddingBottom: height * 0.07,
        borderBottomRightRadius: 20,
        borderBottomLeftRadius: 20,
        paddingHorizontal: margin.horizontal,
        paddingTop: height * 0.02,
    },
    headerHeading: {
        marginLeft: width * 0.03,
    },
    content: {
        marginHorizontal: margin.horizontal,
        backgroundColor: "white",
        flex: 1,
        borderTopRightRadius: 20,
        borderTopLeftRadius: 20,
        padding: width * 0.05,
        marginTop: height * -0.05,
        // ...shadow,
        // elevation: 1,
    },
    header_image: {
        width: width * 0.06,
        height: width * 0.06,
        borderRadius: 180,
    },
    circle: {
        width: width * 0.08,
        height: width * 0.08,
        backgroundColor: "white",
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 180,
        marginRight: width * 0.03
    },
    borderLine: {
        width: "100%",
        marginLeft: 0,
    },
    options: {
        marginTop: height * 0.03
    },
    optionContainer: {
        ...globalStyle.space_between,
    }
});


const arr = [
    {
        heading: "Account Settings"
    },
    // {
    //     option_name: "Edit Profile",
    //     screen: "EditProfile"
    // },
    {
        option_name: "Address",
        screen: "Addresses"
    },
    {
        option_name: "Order tracking sources",
        screen: "TrackingSources"
    },
    {
        option_name: "Notifications",
        screen: "NotificationSetting"
    },
    {
        heading: "More"
    },
    {
        option_name: "About us",
        screen: "CustomWebView",
        params: { heading: "About Us", url: "https://cymbiote.com/about-page/" }
    },
    {
        option_name: "Privacy policy",
        screen: "CustomWebView",
        params: { heading: "Privacy policy", url: "https://cymbiote.com/privacy-policy/" }
    },
    {
        option_name: "Terms and conditions",
        screen: "CustomWebView",
        params: { heading: "Terms and condition", url: "https://cymbiote.com/terms-conditions/" }
    },
    {
        option_name: "Delete account",
        screen: "DeleteAccount"
    },
    {
        option_name: "Sign out",
        color: colors.light_theme.theme
    },
]