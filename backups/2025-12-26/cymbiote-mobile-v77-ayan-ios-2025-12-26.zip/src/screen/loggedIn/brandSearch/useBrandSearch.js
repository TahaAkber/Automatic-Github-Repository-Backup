import {_getStores, _getStoreProducts} from '@redux/actions/merchant/merchant';
import {useCallback, useEffect, useMemo, useRef, useState} from 'react';
import HomeDualCard from '@component/cards/homeDualCard';
import {_recentViewed} from '@redux/actions/user/user';
import useReduxStore from '@utils/hooks/useReduxStore';
import {pagination} from '@utils/helper/helper';
import {WH} from '@constant/contstant';
import {Dimensions, Keyboard, View} from 'react-native';
import {useNavigation} from '@react-navigation/native';
import {
  _searchMethod,
  _searchProductMethod,
} from '../../../redux/actions/common/common';
import {
  _getBrandSearchProducts,
  _getFilteredByCollectionId,
} from '../../../redux/actions/merchant/merchant';
const {width, height, fontScale} = Dimensions.get('screen');
const useBrandSearch = ({route}) => {
  const {dispatch, getState} = useReduxStore();
  // const { brandProducts } = route?.params || {}
  const brandShopId = route?.params?.shop_id;
  const {shop_id} = route?.params ?? {};

  const [value, setValue] = useState('');
  const [searchLoader, setSearchLoader] = useState(false);
  const [isKeyboardVisible, setIsKeyboardVisible] = useState(false);
  const [localData, setLocalData] = useState([]);
  const controllerRef = useRef(null);
  const debounceRef = useRef(null);
  const navigation = useNavigation();

  const {brand_search_products, brand_search_products_loader} =
    getState('merchant');

  const [products, setProducts] = useState([]);
  const [page, setPage] = useState(1);
  const [paginationLoader, setPaginationLoader] = useState(false);
  const [totalPages, setTotalPages] = useState(1);
  const [selectedCollectionId, setSelectedCollectionId] = useState(null);
  const [collectionProducts, setCollectionProducts] = useState([]);
  const [collectionPage, setCollectionPage] = useState(1);
  const [collectionTotalPages, setCollectionTotalPages] = useState(1);
  const [collectionLoading, setCollectionLoading] = useState(false);
  const [initialLoading, setInitialLoading] = useState(true);
  const [isSearching, setIsSearching] = useState(false);
  const latestSearchId = useRef(0); // 🆕 Track latest call
  const [pullLoader, setPullLoader] = useState(false);
  const [isFirstLoad, setIsFirstLoad] = useState(true);
  const handleSearch = text => {
    setIsSearching(true);
    _searchMethod(
      text,
      setValue,
      setSearchLoader,
      setLocalData,
      debounceRef,
      latestSearchId,
      controllerRef,
      'data',
      true,
      `/rag_search?shop_id=${brandShopId}&query=${value}`,
      'GET',
      null,
      () => setIsSearching(false),
    );
  };


  const _handleBlur = () => {
    // setValue('');
    setIsKeyboardVisible(false);
  };

  useEffect(() => {
    const show = Keyboard.addListener('keyboardDidShow', () =>
      setIsKeyboardVisible(true),
    );
    const hide = Keyboard.addListener('keyboardDidHide', () =>
      setIsKeyboardVisible(false),
    );
    return () => {
      show.remove();
      hide.remove();
    };
  }, []);

  const fetchAPI = async loading => {
    setInitialLoading(true);
    !loading && setPullLoader(true);
    loading && setInitialLoading(true);

    const result = await dispatch(_getBrandSearchProducts(shop_id, 1));
    console.log('Initial fetch result:', result);
    setPage(1);
    setTotalPages(result?.pagination?.totalPages || 1);
    setPullLoader(false);
    setInitialLoading(false);
    // setIsFirstLoad(false); // Mark initial load complete
  };
  // const fetchAPI = async () => {
  //   setInitialLoading(true);
  //   const result = await dispatch(_getBrandSearchProducts(brandShopId, 1));

  //   setPage(1);
  //   // setTotalPages(result?.pagination?.totalPages || 1);
  //   setInitialLoading(false);
  // };
  //  const paginationAPI = async () => {

  //   if (!paginationLoader && !isSearching) {
  //     try {
  //       const nextPage = pagination(page, totalPages, setPage);


  //       if (nextPage) {
  //         setPaginationLoader(true);
  //         const response = await dispatch(_getBrandSearchProducts(brandShopId, nextPage));

  //         // Update total pages if changed (optional)
  //         if (response?.pagination?.totalPages !== totalPages) {
  //           setTotalPages(response?.pagination?.totalPages || totalPages);
  //         }
  //       }

  //     } catch (error) {
  //       console.error('Pagination error:', error);
  //     } finally {
  //       setPaginationLoader(false);
  //     }
  //   }
  // };
  const paginationAPI = async () => {
    if (!paginationLoader && !isSearching) {
      const totalPagesFromState =
        brand_search_products?.pagination?.totalPages || 1;
      const hasMorePages = page < totalPagesFromState;
      if (hasMorePages) {
        setPaginationLoader(true);
        const nextPage = page + 1;
        await dispatch(_getBrandSearchProducts(shop_id, nextPage));
        setPage(nextPage);
        setPaginationLoader(false);
      }
    }
  };

  useEffect(() => {
    if (brand_search_products?.data?.products) {
      if (page === 1) {
        setProducts(brand_search_products.data.products);
      } else {
        setProducts(prev => [...prev, ...brand_search_products.data.products]);
      }
    }
  }, [brand_search_products]);
  // useEffect(()=>{
  //   fetchAPI(true);
  // },[]);

  const handleSelectCollection = async collectionId => {
    if (collectionId === 'ALL' || selectedCollectionId === collectionId) {
      setSelectedCollectionId(null);
      setCollectionProducts([]);
      return;
    }

    try {
      setSelectedCollectionId(collectionId);
      setCollectionLoading(true);
      setCollectionPage(1);
      const {products, pagination} = await dispatch(
        _getFilteredByCollectionId(collectionId, 1),
      );
      setCollectionProducts(products);
      setCollectionTotalPages(pagination.totalPages);
    } finally {
      setCollectionLoading(false);
    }
  };
  const renderProduct = useCallback(({item, index}) => {
    return (
      <View
        key={`brand_search_${index}`}
        style={{
          marginRight: WH.width('2'),
          marginTop: index < 2 ? 0 : height * 0.01,
        }}>
        <HomeDualCard item={item} width={WH.width('43')} color={'black'} />
      </View>
    );
  }, []);

  const isCollection = route?.params?.collection;
  const images = [];

  return {
    renderProduct,
    isCollection,
    images,
    // brandProducts,
    value,
    handleSearch,
    localData,
    searchLoader,
    isKeyboardVisible,
    _handleBlur,
    products,
    fetchAPI,
    paginationAPI,
    paginationLoader,
    selectedCollectionId,
    collectionProducts,
    collectionLoading,
    handleSelectCollection,
    brand_search_products_loader,
    pullLoader,
    brand_search_products,
    setProducts,
    initialLoading,
    setPage,
    value,
  };
};

export default useBrandSearch;
