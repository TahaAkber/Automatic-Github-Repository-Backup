import React, {useState, useEffect} from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  FlatList,
  StyleSheet,
} from 'react-native';
import firestore from '@react-native-firebase/firestore';

const ChatScreen = () => {
  const [text, setText] = useState('');
  const [messages, setMessages] = useState([]);

  const vendorId = '12'; // TEMP
  const customerId = '32'; // TEMP

  // 🔥 REALTIME LISTENER
  useEffect(() => {
    const unsubscribe = firestore()
      .collection('chats')
      .doc(vendorId)
      .collection(customerId)
      .orderBy('timestamp', 'desc')
      .onSnapshot(snapshot => {
        const allMessages = snapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data(),
        }));

        setMessages(allMessages);
      });

    return () => unsubscribe(); // stop listener
  }, []);

  // 🔥 SEND MESSAGE (PUSH TO FIRESTORE)
  const sendMessage = async () => {
    if (!text.trim()) return;

    await firestore()
      .collection('chats')
      .doc(vendorId)
      .collection(customerId)
      .add({
        text,
        isOutgoing: true,
        timestamp: firestore.FieldValue.serverTimestamp(),
      });

    setText(''); // clear input only
  };

  // 🔥 MESSAGE BUBBLE
  const renderItem = ({item}) => {
    console.log('item ==>', item);
    return (
      <View
        style={[
          styles.messageBox,
          item.isOutgoing ? styles.outgoing : styles.incoming,
        ]}>
        <Text style={styles.messageText}>{item.text}</Text>
      </View>
    );
  };

  return (
    <View style={styles.container}>
      <FlatList
        data={messages}
        inverted
        renderItem={renderItem}
        keyExtractor={item => item.id}
        contentContainerStyle={{padding: 10}}
      />

      <View style={styles.inputArea}>
        <TextInput
          placeholder="Type message..."
          value={text}
          onChangeText={setText}
          style={styles.input}
        />
        <TouchableOpacity onPress={sendMessage} style={styles.sendBtn}>
          <Text style={{color: '#fff'}}>Send</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default ChatScreen;

// ----------- Styles -------------
const styles = StyleSheet.create({
  container: {flex: 1, backgroundColor: '#fff'},

  messageBox: {
    maxWidth: '75%',
    padding: 10,
    marginVertical: 6,
    borderRadius: 10,
  },

  outgoing: {alignSelf: 'flex-end', backgroundColor: '#000'},

  incoming: {alignSelf: 'flex-start', backgroundColor: '#eee'},

  messageText: {color: '#fff'},

  inputArea: {
    flexDirection: 'row',
    padding: 10,
    borderTopWidth: 1,
    borderColor: '#ddd',
  },

  input: {
    flex: 1,
    backgroundColor: '#f1f1f1',
    padding: 12,
    borderRadius: 10,
  },

  sendBtn: {
    paddingVertical: 12,
    paddingHorizontal: 20,
    backgroundColor: '#000',
    borderRadius: 10,
    marginLeft: 10,
  },
});
