import HelpCenterHeader from '../../../component/header/helpCenterHeader';
import {font, margin} from '../../../constant/contstant';
import CustomText from '../../../materialComponent/customText/customText';
import {
  View,
  StyleSheet,
  Dimensions,
  TouchableOpacity,
  StatusBar,
} from 'react-native';
import Icon from '../../../materialComponent/icon/icon';
import HelpSvg from '@assets/images/help.svg';

const {width, height, fontScale} = Dimensions.get('screen');

const OrderManagment = ({navigation}) => {
  return (
    <View style={styles.container}>
      <StatusBar
        animated
        barStyle={'dark-content'}
        backgroundColor={'white'}
        translucent={false}
      />

      <HelpCenterHeader
        borderLine={1}
        onBackPress={() => navigation.goBack()}
        title={'Help Center'}
        IconComponent={HelpSvg}
      />
      <TouchableOpacity onPress={() => navigation.navigate('OrderPlacement')}>
        <View style={styles.description}>
          <CustomText
            text={'Order Placement'}
            fontFamily={font.medium}
            fontSize={fontScale * 14}
            style={styles.descriptionText}
          />
          <Icon
            icon_type={'AntDesign'}
            name={'right'}
            size={fontScale * 16}
            color={'black'}
          />
        </View>
      </TouchableOpacity>
      <View style={styles.line} />
      <TouchableOpacity onPress={() => navigation.navigate('ManageOrder')}>
        <View style={styles.description}>
          <CustomText
            text={'Order Management'}
            fontFamily={font.medium}
            fontSize={fontScale * 14}
            style={styles.descriptionText}
          />
          <Icon
            icon_type={'AntDesign'}
            name={'right'}
            size={fontScale * 16}
            color={'black'}
          />
        </View>
      </TouchableOpacity>
    </View>
  );
};
export default OrderManagment;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
  },

  description: {
    marginHorizontal: margin.horizontal,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: '5%',
  },
  line: {
    // backgroundColor: colors.light_theme.borderColor,
    backgroundColor: '#b2b2b2',
    height: height * 0.001,
    marginHorizontal: margin.horizontal,
    marginTop: '5%',
  },
});
