import { _register, _socialLogin, _userVerifier } from '@redux/actions/auth/auth';
import { _getStores } from '@redux/actions/merchant/merchant';
import { _globalLoader } from '@redux/actions/common/common';
import useReduxStore from '@utils/hooks/useReduxStore';
import { _getAddress } from '@redux/actions/user/user';
import { useEffect, useState } from 'react';
import { pagination } from '@utils/helper/helper';
import { _getInternalOrder } from '../../../redux/actions/orders/orders';
import { _getUserReviews } from '../../../redux/actions/reviews/reviews';

const useAllReviews = ({ route }) => {
    const { getState, dispatch } = useReduxStore()
    const { fetch_user_reviews, fetch_user_reviews_loader, fetch_user_reviews_error } = getState("reviews")
    const [pullLoader, setPullLoader] = useState(false);
    const [paginationLoader, setPaginationLoader] = useState(false);
    const [loader, setLoader] = useState(false);
    const [id, setId] = useState(0)
    const [page, setPage] = useState(1);

    const fetchAPI = async (isLoading) => {
        if (!isLoading) setPullLoader(true);
        if (isLoading) setLoader(true);
        await dispatch(_getUserReviews({ page: 1, tab: id, pull: !isLoading }));
        setPullLoader(false);
        setLoader(false);
    };

    const paginationAPI = async () => {
        if (!paginationLoader) {
            try {
                const totalPages = fetch_user_reviews?.[id]?.pagination?.totalPages || 1;
                const nextPagination = pagination(page, totalPages, setPage);
                if (nextPagination) {
                    setPaginationLoader(true);
                    const response = await dispatch(_getUserReviews({ page: nextPagination, tab: id }));
            
                }
            } catch (error) {
                console.error("Error fetching pagination data:", error);
            } finally {
                setPaginationLoader(false);
            }
        }
    };

    useEffect(() => {
        fetchAPI(true)
    }, [id])

    return {
        fetchAPI,
        paginationAPI,
        paginationLoader,
        id,
        setId,
        pullLoader,
        loader,
        fetch_user_reviews,
        fetch_user_reviews_loader,
        fetch_user_reviews_error
    };
};

export default useAllReviews;
