import {
  Dimensions,
  StatusBar,
  StyleSheet,
  View,
  Animated,
  ScrollView,
  FlatList,
  RefreshControl,
} from 'react-native';
import React, {useMemo, useState} from 'react';
import InnerHeader from '@component/header/innerHeader';
import {margin} from '@constant/contstant';
// import OverAllReviewCard from '@component/cards/overAllReviewCard/overAllReviewCard';
import {navigate} from '@utils/navigationRef/navigationRef';
import PendingReviewCard from '@component/cards/pendingReviewCard/pendingReviewCard';
import TabBar from '@component/tabBar/tabBar';
import useInnerHeaderAnimation from '../../../hooks/innerHeaderAnimation';
import Content from '@materialComponent/content/content';
import EmptyScreen from '@component/emptyScreen/emptyScreen';
import useAllReviews from './useAllReviews';
import PagionationLoader from '../../../component/loader/endReachLoader';
import {colors, globalStyle} from '../../../constant/contstant';
import OverAllReviewCard from '../../../component/cards/overAllReviewCard/overAllReviewCard';
import ProductReviewLoader from '../../../component/loader/productReviewLoader';
import ProductReviewListLoader from '../../../component/loader/productReviewListLoader';
import Container from '../../../materialComponent/container/container';
import {showErrorScreen} from '../../../utils/helper/helper';

const {height, fontScale} = Dimensions.get('screen');

const AllReviews = ({route}) => {
  const {headerOpacity, headerTranslate, onScroll} = useInnerHeaderAnimation();
  const {
    fetchAPI,
    paginationAPI,
    paginationLoader,
    id,
    setId,
    pullLoader,
    fetch_user_reviews,
    fetch_user_reviews_loader,
    fetch_user_reviews_error,
    loader,
  } = useAllReviews({route});

  const renderItem = useMemo(
    () =>
      ({item, index}) => {
        return (
          <View key={`review_${item.order_id}`}>
            <FlatList
              data={item.order_item || []} // Use item.order_item (array of order items)
              keyExtractor={(subItem, subIndex) => `subItem_${subIndex}`} // Unique key for each order item
              renderItem={({item: e, index: subIndex}) => {
                return (
                  <>
                    {e?.review_completed == false ? (
                      <PendingReviewCard
                        tab={id}
                        subIndex={subIndex}
                        marginTop={height * 0.01}
                        item={e}
                        order_detail={item}
                      />
                    ) : (
                      <OverAllReviewCard
                        item={e} // Pass each order_item to OverAllReviewCard
                        onPress={() => navigate('ReviewDetail', {item: e})} // Navigate to ReviewDetail with the item as a parameter
                        marginTop={height * 0.01} // Adjust margin for spacing between items
                        own={true} // Pass own prop to OverAllReviewCard
                        subIndex={subIndex} // Pass subIndex to OverAllReviewCard if needed
                        total_comment={e?.review_item?.total_comment} // Pass total_comment prop to OverAllReviewCard
                      />
                    )}
                  </>
                );
              }}
            />
          </View>
        );
      },
    [],
  );

  return showErrorScreen(fetch_user_reviews_error) ? (
    <View style={globalStyle.show_error}>
      <EmptyScreen
        fullWidth={true}
        reload={fetchAPI}
        loader={pullLoader}
        message={fetch_user_reviews_error}
      />
    </View>
  ) : (
    <Container barColor={'white'}>
      <View style={styles.container}>
        <StatusBar
          animated
          barStyle="dark-content"
          backgroundColor="white"
          translucent={false}
        />

        {/* Scrollable content */}
        <Content
          contentContainerStyle={{paddingBottom: height * 0.15}}
          onScroll={onScroll}
          scrollEventThrottle={16}
          stickyHeaderIndices={[1]}
          refreshControl={
            <RefreshControl
              refreshing={pullLoader} // Show loader while refreshing
              onRefresh={fetchAPI} // Trigger refresh
              colors={[colors.light_theme.theme]} // Customize loader color
            />
          }>
          <Animated.View
            style={[
              styles.headerContainer,
              {
                transform: [{translateY: headerTranslate}],
                opacity: headerOpacity, // Apply opacity interpolation here
              },
            ]}>
            <InnerHeader notification={true} setting={true} title="Reviews" />
          </Animated.View>

          <View style={styles.tabBarContainer}>
            <TabBar id={id} setId={setId} arr={tabBar} />
          </View>

          {/* <View style={styles.contentContainer}>
                    <View style={styles.reviewsCard}>
                        <View style={{ justifyContent: "center", alignItems: "center", flex: 1, marginTop: height * 0.15 }}>
                            <EmptyScreen
                                image={"empty_reviews"}
                                heading={"No Reviews Yet!"}
                                desc={"You haven’t left any reviews yet. Share your experience and help others make informed choices!"}
                            />
                        </View>
                    </View>
                </View> */}
          {/* Content */}
          {/* <View style={{ marginHorizontal: margin.horizontal, marginTop: height * 0.02 }}>
                    <PendingReviewCard />
                </View>
                <View style={styles.contentContainer}>
                    <View style={styles.reviewsCard}>
                        <OverAllReviewCard onPress={() => navigate("ReviewDetail")} marginTop={height * 0.03} />
                        <OverAllReviewCard marginTop={height * 0.03} />
                        <OverAllReviewCard marginTop={height * 0.03} />
                        <OverAllReviewCard marginTop={height * 0.03} />
                    </View>
                </View> */}

          {loader ? (
            <ProductReviewListLoader loading={loader} />
          ) : (
            <>
              {(fetch_user_reviews?.[id]?.data || [])?.length > 0 ? (
                <FlatList
                  // data={fetch_internal_order}
                  data={fetch_user_reviews?.[id]?.data}
                  keyExtractor={(item, index) => item.order_title.toString()}
                  renderItem={renderItem}
                  scrollEnabled={false}
                  ListFooterComponent={
                    paginationLoader ? <PagionationLoader /> : null
                  }
                  contentContainerStyle={{marginTop: height * 0.01}}
                  key={id}
                />
              ) : (
                <View
                  style={{
                    justifyContent: 'center',
                    alignItems: 'center',
                    marginTop: height * 0.25,
                  }}>
                  <EmptyScreen
                    image={'empty_reviews'}
                    heading={'No Reviews Yet!'}
                    desc={
                      'You haven’t left any reviews yet. Share your experience and help others make informed choices!'
                    }
                  />
                </View>
              )}
            </>
          )}
        </Content>
      </View>
    </Container>
  );
};

export default AllReviews;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
  },
  headerContainer: {
    width: '100%',
    zIndex: 2, // Ensure the header is above other content
  },
  tabBarContainer: {
    zIndex: 3, // TabBar should have the highest zIndex to stay on top
    backgroundColor: 'white',
  },
  contentContainer: {
    marginTop: height * 0.04,
  },
  reviewsCard: {
    marginHorizontal: margin.horizontal,
    marginTop: height * 0.04,
  },
});

const tabBar = ['All', 'Pending Reviews', 'Completed'];
