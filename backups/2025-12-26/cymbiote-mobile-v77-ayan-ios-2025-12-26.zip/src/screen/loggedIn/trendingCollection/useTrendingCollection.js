import { _getStores, _getStoreProducts } from '@redux/actions/merchant/merchant';
import { useCallback, useEffect, useMemo, useState } from 'react';
import HomeDualCard from '@component/cards/homeDualCard';
import { _recentViewed } from '@redux/actions/user/user';
import useReduxStore from '@utils/hooks/useReduxStore';
import { pagination } from '@utils/helper/helper';
import { WH } from '@constant/contstant';
import { View } from 'react-native';
import {
  _getShopSingleCollection,
  _getTrendingSingleCollection,
  _subCategoryProducts,
} from '../../../redux/actions/merchant/merchant';

const useBrandCollection = ({ route }) => {
  const { item } = route?.params || [];
  const { dispatch, getState } = useReduxStore();
  const {
    fetch_store_single_collection,
    fetch_store_single_collection_loader,
    fetch_store_single_collection_error,
  } = getState('merchant');


  const [page, setPage] = useState(1);
  const [paginationLoader, setPaginationLoader] = useState(false);
  const [pullLoader, setPullLoader] = useState(false);
  const [categoryProducts, setCategoryProducts] = useState({
    products: []
  });
  const [categoryProductsShow, setCategoryProductsShow] = useState(false);
  const [categoryName, setCategoryName] = useState("");
  const [categoryProductsLoader, setCategoryProductsLoader] = useState(false);

  const renderProduct = useCallback(({ item }) => {
    return (
      <View style={{ marginRight: WH.width('2') }}>
        <HomeDualCard item={item} width={WH.width('43')} color={'black'} />
      </View>
    );
  }, []);

  const fetchAPI = loading => {
    !loading && setPullLoader(true);
    if (categoryProductsShow) {
      handleSelectCategories("", categoryName, 1)
    } else {
      dispatch(_getTrendingSingleCollection(item?.trending_id, 1));
    }
    setPage(1);
    setPullLoader(false);
  };

  const paginationAPI = async () => {
    if (!paginationLoader) {
      const totalPages = categoryProductsShow ? categoryProducts?.pagination?.totalPages : fetch_store_single_collection?.data?.totalPages;
      const nextPagination = (categoryProductsShow ? categoryProducts?.pagination?.totalPages == categoryProducts?.pagination?.currentPage : fetch_store_single_collection?.data?.totalPages == fetch_store_single_collection?.data?.currentPage) ? false : pagination(page, totalPages);
      
      if (nextPagination) {
        setPaginationLoader(true);
        if (categoryProductsShow) {
          const response = await handleSelectCategories("", categoryName, nextPagination);
          setPaginationLoader(false);
        } else {
          const response = await dispatch(
            _getTrendingSingleCollection(item?.trending_id, nextPagination),
          );
          setPage(nextPagination);
          setPaginationLoader(false);
        }
        setPaginationLoader(false);
      }
    }
  };

  const handleSelectCategories = async (category, subCategory, currentPage) => {
    if (subCategory) {
      setPage(currentPage || 1)
      setCategoryProductsShow(true)
      setCategoryName(subCategory)
      !currentPage && setCategoryProductsLoader(true)
      const responseData = await dispatch(_subCategoryProducts({
        collectionId: "",
        shopId: "",
        subCategory,
        page: currentPage || 1,
        collection_type: item?.trending_id
      }));
      setCategoryProductsLoader(false)
      setCategoryProducts((categoryName == subCategory && currentPage != 1) ? { ...responseData, products: [...categoryProducts?.products, ...responseData?.products] } : responseData)
    } else {
      setPage(1)
      setCategoryProducts({})
      setCategoryName("")
      setCategoryProductsLoader(false)
      setCategoryProductsShow(false)
    }
  }

  useEffect(() => {
    fetchAPI(true);
  }, []);

  return {
    item,
    paginationLoader,
    renderProduct,
    categoryProductsShow,
    categoryProducts,
    categoryProductsLoader,
    fetch_store_single_collection,
    fetch_store_single_collection_loader,
    fetch_store_single_collection_error,
    paginationAPI,
    fetchAPI,
    pullLoader,
    handleSelectCategories
  };
};

export default useBrandCollection;
