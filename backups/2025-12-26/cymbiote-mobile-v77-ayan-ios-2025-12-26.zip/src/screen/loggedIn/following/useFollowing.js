import {_getRecentViewedList} from '@redux/actions/user/user';
import {_getStores, _getFollowingStore} from '@redux/actions/merchant/merchant';
import useReduxStore from '@utils/hooks/useReduxStore';
import {_recentViewed} from '@redux/actions/user/user';
import {useEffect, useRef, useState} from 'react';
import {
  _searchMethod,
  _searchMethodFollowing,
} from '../../../redux/actions/common/common';
import {pagination} from '../../../utils/helper/helper';
import {call} from '../../../helper/reUsableMethod/reUsableMethod';

const useFollowing = ({}) => {
  const {dispatch, getState} = useReduxStore();
  const {fetch_user_detail} = getState('auth');
  const {
    fetch_store_following_list_local,
    fetch_store_following_list,
    fetch_store_following_list_loader,
    fetch_store_following_list_error,
  } = getState('merchant');
  const [paginationLoader, setPaginationLoader] = useState(false);
  const [page, setPage] = useState(1);

  const [search, setSearch] = useState('');
  const [searchLoader, setSearchLoader] = useState('');
  const [localData, setLocalData] = useState({});
  const debounceRef = useRef(null);
  const controllerRef = useRef(null);
  const latestSearchId = useRef(0);
  const [searchPage, setSearchPage] = useState(1);
  const [searchLoadingMore, setSearchLoadingMore] = useState(false);
  const [searchHasMore, setSearchHasMore] = useState(false);
  const [pullLoader, setPullLoader] = useState(false);

  const fetchAPI = async isLoading => {
    !isLoading && setPullLoader(true);
    !isLoading && setPage(1);
    if (search) {
      const body = {
        user_id: userId,
        search: search,
        page: 1,
        pageSize: pageSize,
        product: true,
      };
      _searchMethod(
        search,
        setSearch,
        setPaginationLoader,
        payload => {
    
          setLocalData(prev => ({
            ...payload,
            data: [...(prev?.data || []), ...(payload?.data || [])],
          }));
        },
        debounceRef,
        latestSearchId,
        controllerRef,
        '',
        false,
        `/following/user-following-log`,
        'POST',
        JSON.stringify(body),
        true,
      );
    } else {
      await dispatch(_getFollowingStore(true, [], false, 1));
    }
    setPullLoader(false);
  };

  useEffect(() => {
    fetchAPI(true);
  }, []);
  const paginationAPI = async () => {

    if (!paginationLoader) {
      // const totalPages = fetch_store_following_list?.pagination?.totalPages;
      const totalPages =
        (search ? localData : fetch_store_following_list)?.pagination
          ?.totalPages ==
        (search ? localData : fetch_store_following_list)?.pagination?.page;
      const nextPagination = totalPages
        ? false
        : pagination(
            page,
            (search ? localData : fetch_store_following_list)?.pagination
              ?.totalPages,
          );
      if (nextPagination) {
        if (search) {
          try {
            const body = {
              user_id: userId,
              search: search,
              page: nextPagination,
              pageSize: pageSize,
              product: true,
            };

            _searchMethod(
              search,
              setSearch,
              setPaginationLoader,
              payload => {
           
                setLocalData(prev => ({
                  ...payload,
                  data: [...(prev?.data || []), ...(payload?.data || [])],
                }));
              },
              debounceRef,
              latestSearchId,
              controllerRef,
              '',
              false,
              `/following/user-following-log`,
              'POST',
              JSON.stringify(body),
              true,
            );
            setPage(nextPagination);
          } catch (error) {
    
            setPaginationLoader(false);
          }
        } else {
          setPaginationLoader(true);
          const res = await dispatch(
            _getFollowingStore(true, [], false, nextPagination, true),
          );
          setPage(page + 1);
          setPaginationLoader(false);
        }
      }
    }
  };

  const userId = fetch_user_detail?.id || '';
  const pageSize = 2;

  const handleSearch = text => {
    const body = {
      user_id: userId,
      search: text,
      page: page,
      pageSize: pageSize,
      product: true,
    };



    _searchMethod(
      text,
      setSearch,
      setSearchLoader,
      setLocalData,
      debounceRef,
      latestSearchId,
      controllerRef,
      '',
      false,
      `/following/user-following-log`,
      'POST',
      JSON.stringify(body),
      true,
    );
  };

  return {
    dispatch,
    fetch_store_following_list_local,
    fetch_store_following_list,
    fetch_user_detail,
    fetch_store_following_list_loader,
    paginationAPI,
    paginationLoader,
    setSearch,
    search,
    handleSearch,
    searchLoader,
    localData,
    pullLoader,
    searchLoadingMore,
    fetchAPI,
    fetch_store_following_list_error,
  };
};

export default useFollowing;
