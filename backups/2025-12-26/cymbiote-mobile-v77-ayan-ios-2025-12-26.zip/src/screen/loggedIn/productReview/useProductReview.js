import {useEffect, useState} from 'react';
import {_getStoreProductDetail} from '@redux/actions/merchant/merchant';
import {_recentViewed} from '@redux/actions/user/user';
import useReduxStore from '@utils/hooks/useReduxStore';
import {
  _addToCart,
  _checkout,
  _removeCartProduct,
} from '../../../redux/actions/cart/cart';
import {_favoriteUpdateStatus} from '../../../redux/actions/user/user';
import {_getStoreProductDetailReview} from '@redux/actions/merchant/merchant';

const useProductReview = ({route}) => {
  const {product_id} = route?.params;
  const {dispatch} = useReduxStore();

  const [productDetailReview, setProductDetailReview] = useState({});
  const [pullLoader, setPullLoader] = useState(false);

  const fetchProductDetailReview = async () => {
    const res = await dispatch(_getStoreProductDetailReview(product_id));
    // const res = await dispatch(_getStoreProductDetailReview(129));
    if (res) {
      setProductDetailReview(res);
    } else {
      setProductDetailReview({});
    }
  };

  const fetchAPI = async isLoading => {
    !isLoading && setPullLoader(true);
    await fetchProductDetailReview();
    !isLoading && setPullLoader(false);
  };

  useEffect(() => {
    fetchAPI(true);
  }, [product_id]);

  const avarageRating = productDetailReview?.averageRating || 0;

  const generateProgressBarData = (breakdown = {}, totalReviews = 0) => {
    const result = [];

    if (!breakdown || typeof breakdown !== 'object') {
      return result; // return empty array if invalid breakdown
    }

    for (const [title, count] of Object.entries(breakdown)) {
      const safeCount = typeof count === 'number' ? count : 0;
      const percent =
        totalReviews > 0
          ? ((safeCount / totalReviews) * 100).toFixed(2) + '%'
          : '0%';

      // Format title: insert space before uppercase letters and capitalize first letter
      const formattedTitle = title
        .replace(/([A-Z])/g, ' $1')
        .replace(/^./, str => str.toUpperCase());

      result.push({title: formattedTitle, percent});
    }

    return result;
  };

  const progressBarData = generateProgressBarData(
    productDetailReview?.breakdown,
    productDetailReview?.totalReviews || 0,
  );

  // const progressBarData = [
  //     { title: "Excellent", percent: "80%" },
  //     { title: "Good", percent: "70%" },
  //     { title: "Average", percent: "50%" },
  //     { title: "Poor", percent: "30%" },
  // ];

  return {
    fetchAPI,
    pullLoader,
    productDetailReview,
    progressBarData,
    avarageRating,
  };
};

export default useProductReview;
