import {Dimensions, FlatList, StatusBar, StyleSheet, View} from 'react-native';
import React from 'react';
import InnerHeader from '@component/header/innerHeader';
import CustomText from '@materialComponent/customText/customText';
import {font, globalStyle, margin} from '@constant/contstant';
import Icon from '@materialComponent/icon/icon';
import CustomProgressBar from '@materialComponent/customProgressBar/customProgressBar';
import OverAllReviewCard from '@component/cards/overAllReviewCard/overAllReviewCard';
import Content from '@materialComponent/content/content';
import {navigate} from '@utils/navigationRef/navigationRef';
import useProductReview from './useProductReview';
import {RefreshControl} from 'react-native-gesture-handler';
import RatingStars from '@materialComponent/ratingStars/ratingStars';
import {moderateScale} from 'react-native-size-matters';
import EmptyScreen from '@component/emptyScreen/emptyScreen';
import Container from '../../../materialComponent/container/container';

const {height, fontScale} = Dimensions.get('screen');

const ProductReview = ({route}) => {
  const {
    fetchAPI,
    pullLoader,
    productDetailReview,
    progressBarData,
    avarageRating,
  } = useProductReview({route});

  // Show loader if data is still being fetched
  const isLoading = pullLoader;
  return (
    <Container barColor={"white"}>
    <View style={styles.container}>
      <Content
        refreshControl={
          <RefreshControl refreshing={pullLoader} onRefresh={fetchAPI} />
        }
        contentContainerStyle={{paddingBottom: height * 0.15}}>
        <StatusBar
          animated
          barStyle="dark-content"
          backgroundColor="white"
          translucent={false}
        />
        <InnerHeader
          notification={true}
          setting={true}
          title="What People Say"
        />

        {(productDetailReview?.reviews || []).length === 0 ? (
          <View
            style={{
              justifyContent: 'center',
              alignItems: 'center',
              marginTop: height * 0.25,
            }}>
            <EmptyScreen
              image={'empty_reviews'}
              heading={'No Reviews Yet!'}
              desc={
                'You haven’t left any reviews yet. Share your experience and help others make informed choices!'
              }
            />
          </View>
        ) : (
          <>
            <View style={styles.contentContainer}>
              {/* Rating Section */}
              <View style={styles.ratingView}>
                <CustomText
                  center
                  text="Overall Rating"
                  color="#858585"
                  fontSize={fontScale * 18}
                />
                <CustomText
                  center
                  text={
                    avarageRating
                      ? productDetailReview?.averageRating?.toFixed(1)
                      : '0.0'
                  }
                  fontFamily={font.black}
                  fontSize={fontScale * 80}
                />
                {/* <View style={[globalStyle.row, styles.starRating]}>
                            {[...Array(5)].map((_, i) => (
                                <Icon key={i} icon_type="Entypo" name="star" color={i === 4 ? "#C9C9C9" : "#E4A70A"} size={fontScale * 30} />
                            ))}
                        </View> */}
                <RatingStars
                  setRating={() => console.log('')}
                  size={moderateScale(30)}
                  color={'#E4A70A'}
                  rating={avarageRating || 0}
                />
                <CustomText
                  center
                  text={`Based on ${productDetailReview?.totalReviews} reviews`}
                  marginTop={height * 0.015}
                  fontFamily={font.medium}
                  color="#adadad"
                  fontSize={fontScale * 15}
                />
              </View>

              <View style={styles.progressBarContainer}>
                {progressBarData.map((item, index) => (
                  <CustomProgressBar
                    key={index}
                    marginTop={index === 0 ? 0 : height * 0.025}
                    title={item.title}
                    percent={item.percent}
                  />
                ))}
              </View>

              {/* Overall Reviews */}
              {/* <View style={styles.reviewsCard}>
                        <OverAllReviewCard onPress={() => navigate("ReviewDetail")} />
                        <OverAllReviewCard marginTop={height * 0.05} />
                        <OverAllReviewCard marginTop={height * 0.05} />
                        <OverAllReviewCard marginTop={height * 0.05} />
                    </View> */}

              <FlatList
                data={productDetailReview?.reviews || []}
                keyExtractor={item => item.id}
                contentContainerStyle={styles.reviewsCard}
                renderItem={({item, index}) => (
                  <OverAllReviewCard
                    key={`product_review_${index}`}
                    onPress={() => navigate('ReviewDetail', {item})}
                    marginTop={index === 0 ? 0 : height * 0.05}
                    item={item}
                    total_comment={productDetailReview?.total_comment || 0}
                  />
                )}
              />
            </View>
          </>
        )}
      </Content>
    </View>
    </Container>

  );
};

export default ProductReview;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
  },
  contentContainer: {
    marginTop: height * 0.04,
  },
  ratingView: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  starRating: {
    marginTop: height * -0.005,
  },
  progressBarContainer: {
    marginTop: height * 0.04,
    marginHorizontal: margin.horizontal,
  },
  reviewsCard: {
    // marginHorizontal: margin.horizontal,
    marginTop: height * 0.04,
  },
});
