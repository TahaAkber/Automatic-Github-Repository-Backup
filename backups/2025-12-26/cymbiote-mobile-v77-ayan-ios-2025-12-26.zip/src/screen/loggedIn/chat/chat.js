import React, {useEffect, useState, useRef} from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  FlatList,
  KeyboardAvoidingView,
  Platform,
  Keyboard,
  Dimensions,
} from 'react-native';
import {styles} from './chatStyles';
import ChatHeader from './chatHeader';
import {useChat} from './useChat';
import Container from '../../../materialComponent/container/container';
import Icon from '../../../materialComponent/icon/icon';
import {moderateScale, verticalScale} from 'react-native-size-matters';
import {font} from '../../../constant/contstant';
import ChatLoader from '../../../component/loader/chatLoader';
import {formatTimestampToTime} from '../../../utils/helper/helper';
import useReduxStore from '../../../utils/hooks/useReduxStore';
import EmptyScreen from '../../../component/emptyScreen/emptyScreen';

const {height, width} = Dimensions.get('window');

const ChatScreen = ({route, navigation}) => {
  const {
    orderId,
    vendorId,
    customerId,
    title,
    image = '',
    orderTitle = '',
  } = route.params;

  const {getState} = useReduxStore();
  const {fetch_user_detail} = getState('auth');

  const currentUserId = customerId;

  const {messages, sendMessage, markSeen, status, loading} = useChat(
    orderId,
    vendorId,
    customerId,
    currentUserId,
    image,
    title,
    orderTitle,
  );

  console.log('messages', messages[0]?.timestamp);

  const [text, setText] = useState('');
  const flatListRef = useRef(null);

  useEffect(() => {
    markSeen();
  }, []);

  const handleSend = () => {
    if (text.trim().length > 0) {
      sendMessage(text.trim());
      setText('');
    }
  };

  const renderMsg = ({item, index}) => {
    const isOutgoing = item.sender_id === currentUserId;

    let messageTime = formatTimestampToTime(item?.timestamp);

    return (
      <View style={{marginVertical: moderateScale(3)}}>
        <View
          style={[
            styles.messageBox,
            isOutgoing ? styles.outgoing : styles.incoming,
            {maxWidth: width * 0.7},
          ]}>
          <Text style={[styles.messageText, !isOutgoing && {color: 'black'}]}>
            {item.text}
          </Text>
        </View>
        <View
          style={[
            {flexDirection: isOutgoing ? 'row' : 'row-reverse'},
            isOutgoing
              ? {alignSelf: 'flex-end', marginRight: 2}
              : {alignSelf: 'flex-start', marginLeft: 2},
          ]}>
          {index == messages?.length - 1 && isOutgoing && item.seen && (
            <Text style={[styles.seenText, {marginHorizontal: 3}]}>Seen</Text>
          )}
          <Text style={[styles.seenText]}>{messageTime}</Text>
        </View>
      </View>
    );
  };

  return (
    <Container dark isFocused={true} barColor={'white'}>
      <KeyboardAvoidingView
        style={{flex: 1}}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 90 : 0}>
        <View style={styles.container}>
          {/* Header */}
          <ChatHeader
            onBack={() => navigation.goBack()}
            title={title}
            image={image}
            orderTitle={orderTitle}
            shopId={vendorId}
          />

          {/* Messages List */}
          <View style={{flex: 1}}>
            {loading ? (
              <ChatLoader />
            ) : messages?.length > 0 ? (
              <FlatList
                ref={flatListRef}
                data={messages}
                renderItem={renderMsg}
                keyExtractor={item => item.id.toString()}
                contentContainerStyle={{
                  paddingVertical: verticalScale(10),
                }}
                inverted // scroll from bottom
              />
            ) : (
              <View
                style={{
                  flex: 1,
                  justifyContent: 'center',
                  alignItems: 'center',
                }}>
                <EmptyScreen
                  heading={'No messages yet'}
                  desc={'Chat with your favorite store when you need help'}
                  image={'empty_messages'}
                />
              </View>
            )}
          </View>

          {/* Input Bar */}
          <View style={styles.inputArea}>
            <TextInput
              placeholder="Type message..."
              value={text}
              onChangeText={setText}
              placeholderTextColor={'#797C7B'}
              style={styles.input}
              multiline
            />
            <TouchableOpacity onPress={handleSend} style={styles.sendBtn}>
              <Icon
                icon_type={'Ionicons'}
                name={'send'}
                size={moderateScale(20)}
              />
            </TouchableOpacity>
          </View>
        </View>
      </KeyboardAvoidingView>
    </Container>
  );
};

export default ChatScreen;
