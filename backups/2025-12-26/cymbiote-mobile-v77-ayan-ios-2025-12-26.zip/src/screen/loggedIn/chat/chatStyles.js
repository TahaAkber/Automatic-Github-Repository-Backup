import {StyleSheet, Dimensions} from 'react-native';
import {moderateScale, verticalScale} from 'react-native-size-matters';
import {colors, font, margin} from '../../../constant/contstant';

const {width} = Dimensions.get('window');

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    paddingHorizontal: margin.horizontal,
  },

  // HEADER
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    borderBottomWidth: 1,
    borderColor: '#eee',
    paddingVertical: margin.horizontal - 5,
    justifyContent: 'space-between',
  },

  backArrow: {
    fontSize: moderateScale(22),
    marginRight: moderateScale(10),
    fontWeight: 'bold',
    color: '#000',
  },

  profileImage: {
    width: moderateScale(38),
    aspectRatio: 1,
    borderRadius: 50,
  },

  headerName: {
    fontSize: moderateScale(12),
    fontWeight: font.regular,
    color: '#000',
  },

  active: {
    fontSize: moderateScale(12),
    color: 'green',
  },

  offline: {
    fontSize: moderateScale(12),
    color: 'red',
  },

  // CHAT BUBBLES
  messageBox: {
    maxWidth: width * 0.75,
    padding: moderateScale(8),
    paddingHorizontal: moderateScale(12),

    borderRadius: moderateScale(10),
    // borderTopRightRadius: 0,
  },

  outgoing: {
    alignSelf: 'flex-end',
    backgroundColor: colors.light_theme.theme,
  },

  incoming: {
    alignSelf: 'flex-start',
    backgroundColor: '#F2F7FB',
  },

  messageText: {
    fontSize: moderateScale(12),
    color: '#fff',
    fontFamily: font.regular,
  },

  seenText: {
    fontFamily: font.regular,
    fontSize: moderateScale(8),
    color: '#797C7B',
    opacity: 0.5,
    marginTop: verticalScale(5),
  },

  // INPUT BAR
  inputArea: {
    flexDirection: 'row',
    paddingVertical: moderateScale(15),
    borderTopWidth: 1,
    borderColor: '#EEFAF8',
    alignItems: 'center',
  },

  input: {
    flex: 1,
    backgroundColor: '#F3F6F6',
    padding: moderateScale(12),
    borderRadius: moderateScale(10),
    fontSize: moderateScale(14),
    fontFamily: font.medium,
    color: 'black',
  },

  sendBtn: {
    marginLeft: moderateScale(15),
  },

  sendText: {
    color: '#fff',
    fontSize: moderateScale(14),
    fontWeight: '600',
  },
});
