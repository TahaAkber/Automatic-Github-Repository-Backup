import React from 'react';
import {
  StyleSheet,
  View,
  StatusBar,
  FlatList,
  Alert,
  ActivityIndicator,
  Dimensions,
  RefreshControl,
} from 'react-native';
import {colors, globalStyle, margin, WH} from '@constant/contstant';
import {SafeAreaView} from 'react-native-safe-area-context';
import HomeFilter from '@component/homeFilter/homeFilter';
import {dashboardFilters} from '@constant/dummyData';
import useSearchedItems from './useSearchedItems';
import {dashboardCollections} from '@constant/dummyData';
import CustomText from '@materialComponent/customText/customText';
import Content from '@materialComponent/content/content';
import SearchScreenInput from '@component/input/searchScreenInput';
import ActiveSearch from '@component/activeSearch/activeSearch';
import SearchedItemsLoader from '@component/loader/searchedItemsLoader';
import {font} from '@constant/contstant';
import {handleScroll} from '../../../utils/helper/helper';
import PagionationLoader from '../../../component/loader/endReachLoader';
import EmptyScreen from '../../../component/emptyScreen/emptyScreen';
import CustomImage from '../../../materialComponent/image/image';
import CustomBackgoundImage from '../../../materialComponent/image/bgImage';
import BrandTab from '../../../component/brandTab/brandTab';
import {moderateScale} from 'react-native-size-matters';
import BrandCard from '../../../component/cards/brandCard/brandCard';
import {FlashList} from '@shopify/flash-list';

const {width, height, fontScale} = Dimensions.get('screen');

const SearchedItems = ({disabled, route}) => {
  const {
    renderProduct,
    value,
    handleSearch,
    localData,
    searchLoader,
    isKeyboardVisible,
    _handleBlur,
    products,
    loader,
    searchedTerm,
    fetchAPI,
    paginationAPI,
    paginationLoader,
    searchedImage,
    isCameraOpen,
    setIsCameraOpen,
    brand,
    setBrand,
    pullLoader,
    renderBrandCard,
  } = useSearchedItems({route});

  return (
    <SafeAreaView
      style={{
        flex: 1,
        backgroundColor: 'white',
        paddingHorizontal: margin.horizontal,
        paddingTop: height * 0.02,
      }}>
      <StatusBar
        animated
        barStyle="dark-content"
        backgroundColor="white"
        translucent={false}
      />

      {/* <SearchInput placeholder={"Search from outfitter"} /> */}

      <View
        style={{
          alignItems: 'center',
          justifyContent: 'center',
          marginBottom: height * -0.01,
        }}>
        <SearchScreenInput
          onBlur={_handleBlur}
          onChangeText={handleSearch}
          setIsCameraOpen={setIsCameraOpen}
          value={value}
          searchedImage={searchedImage}
        />
      </View>

      {isCameraOpen || isKeyboardVisible || value ? (
        <ActiveSearch
          value={value}
          searchLoader={searchLoader}
          localData={localData}
        />
      ) : (
        <>
          {loader ? (
            <SearchedItemsLoader />
          ) : (
            <>
              <View
                style={{
                  marginBottom: height * 0.02,
                  marginHorizontal: -margin.horizontal,
                }}>
                {searchedImage?.uri ? (
                  <HomeFilter
                    fetchAPI={fetchAPI}
                    marginTop={height * 0.02}
                    screen={'main_search'}
                    removeFilters={[
                      'cloth_size',
                      'shoe_size',
                      'colors',
                      'brands',
                    ]}
                    brands={products?.available_brands}
                    brand={brand}
                    setBrand={setBrand}
                  />
                ) : (
                  <>
                    <HomeFilter
                      fetchAPI={fetchAPI}
                      marginTop={height * 0.02}
                      screen={'main_search'}
                      removeFilters={[
                        'cloth_size',
                        'shoe_size',
                        products?.available_brands
                          ? !products?.available_brands?.length
                            ? 'brands'
                            : ''
                          : '',
                      ]}
                      brands={products?.available_brands}
                      brand={brand}
                      setBrand={setBrand}
                    />
                  </>
                )}
              </View>
              <FlashList
                showsVerticalScrollIndicator={false}
                data={products?.data?.products || products?.data || []}
                refreshControl={
                  <RefreshControl
                    refreshing={pullLoader}
                    onRefresh={() => fetchAPI(false, true)} // this uses the last brand
                  />
                }
                // data={[]}
                renderItem={renderProduct}
                keyExtractor={(item, index) => index.toString()}
                showsHorizontalScrollIndicator={false}
                numColumns={2}
                contentContainerStyle={styles.flatListContainerWithoutImage}
                ListHeaderComponent={() => (
                  <>
                    {products?.data?.shops || [].length > 0 ? (
                      <View style={{marginBottom: height * 0.02}}>
                        <FlashList
                          horizontal
                          data={products?.data?.shops || []}
                          keyExtractor={(item, index) =>
                            item?.id?.toString() || index.toString()
                          }
                          renderItem={renderBrandCard}
                          ItemSeparatorComponent={() => (
                            <View style={{width: width * 0.02}} />
                          )}
                          showsHorizontalScrollIndicator={false}
                        />
                      </View>
                    ) : searchedTerm ? (
                      <View style={{marginBottom: height * 0.03}}>
                        <CustomText
                          fontFamily={font.light}
                          center
                          text={searchedTerm}
                        />
                      </View>
                    ) : null}
                  </>
                )}
                ListEmptyComponent={
                  <View
                    style={{
                      justifyContent: 'center',
                      alignItems: 'center',
                      marginTop: height * 0.15,
                    }}>
                    <EmptyScreen
                      image={'empty_search'}
                      heading={'We couldn’t find a match'}
                      desc={
                        searchedImage?.uri
                          ? 'Try another image or search in'
                          : 'Try another keyword or search in'
                      }
                      // imageSize={width * 0.16}
                      // headingSize={fontScale * 14}
                      // descSize={fontScale * 12}
                    />
                  </View>
                }
                ListFooterComponent={() =>
                  paginationLoader && <PagionationLoader />
                }
                onEndReached={paginationAPI} // Pagination on scroll
                onEndReachedThreshold={0.2} // Trigger when nearing the end
                scrollEnabled={true} // Make the list scrollable
              />
            </>
          )}
        </>
      )}
    </SafeAreaView>
  );
};

export default SearchedItems;

const styles = StyleSheet.create({
  flatListContainerWithoutImage: {
    paddingBottom: height * 0.2,
  },
});
