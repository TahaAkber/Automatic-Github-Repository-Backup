import {_getStoreProductDetail} from '@redux/actions/merchant/merchant';
import CheckOutCard from '@component/cards/CheckOutCard/CheckOutCard';
import {useCallback, useEffect, useState} from 'react';
import {_getCardItems} from '@redux/actions/cart/cart';
import useReduxStore from '@utils/hooks/useReduxStore';
import {_getAddress} from '@redux/actions/user/user';
import {_commonDispatcher} from '../../../redux/actions/common/common';
import {FETCH_CART_DB_ITEM_LOADER} from '../../../redux/types/cart/cart';

const useCart = ({route}) => {
  const {getState, dispatch} = useReduxStore();

  // Fetch cart for logging purposes (if needed for debugging)
  const {cart, cart_item, cart_item_loader, check_out} = getState('cart');
  const {fetch_address} = getState('user');
  const {fetch_user_detail} = getState('auth');
  const getDefaultAddress = fetch_address?.find(
    item => item.address_default_select,
  );

  const [pullLoader, setPullLoader] = useState(false);
  const [editAddress, setEditAddress] = useState(false);

  const fetchAPI = async isLoading => {
    !isLoading && setPullLoader(true);
    
    await dispatch(_getAddress(fetch_user_detail?.id));
    await dispatch(_getCardItems());
    setPullLoader(false);
  };

  useEffect(() => {
    let isMounted = true; // Track if the component is still mounted
    const fetchData = async () => {
      if (isMounted) {
        dispatch(_commonDispatcher(FETCH_CART_DB_ITEM_LOADER, true));
        await fetchAPI(true);
        dispatch(_commonDispatcher(FETCH_CART_DB_ITEM_LOADER, false));
      }
    };

    fetchData();

    return () => {
      isMounted = false; // Cleanup function to prevent state updates after unmount
    };
  }, []);

  const renderItem = useCallback(
    ({item, index}) => {
   
      return <CheckOutCard item={item} index={index} />;
    },
    [cart_item],
  );

  return {
    renderItem,
    fetchAPI,
    getDefaultAddress,
    pullLoader,
    check_out,
    cart_item,
    dispatch,
    cart,
    setEditAddress,
    editAddress,
    fetch_address,
    cart_item_loader,
  };
};

export default useCart;
