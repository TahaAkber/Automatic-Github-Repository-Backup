import { _getStores } from '@redux/actions/merchant/merchant';
import { _globalLoader } from '@redux/actions/common/common';
import useReduxStore from '@utils/hooks/useReduxStore';
import { _login } from '@redux/actions/auth/auth';

const useProfile = ({ }) => {
    const { getState, dispatch } = useReduxStore()
    const { fetch_user_detail } = getState("auth")

    return {
        fetch_user_detail
    };
};

export default useProfile;
