import {Dimensions, StatusBar, StyleSheet, Text, View} from 'react-native';
import CustomText from '../../../materialComponent/customText/customText';
import {colors, font, margin, WH} from '../../../constant/contstant';
import InnerHeader from '../../../component/header/innerHeader';
import CustomButton from '../../../materialComponent/customButton/customButton';
import Google from '@assets/images/google.svg';
import facebook from '@assets/images/facebook.svg';
import emailBlack from '@assets/images/emailBlack.svg';
import BorderLine from '../../../component/borderLine/borderLine';
import CustomImage from '../../../materialComponent/image/image';
import images from '../../../assets/images/images';
import useTrackingSources from '../trackingSources/useTrackingSources';
import useLogin from '../../authentication/login/useLogin';
import {AuthNavigatingProfile} from '../../../helper/reUsableMethod/reUsableMethod';
import {navigate} from '../../../utils/navigationRef/navigationRef';
import Container from '../../../materialComponent/container/container';

const {width, height, fontScale} = Dimensions.get('screen');
const ProfileLogin = () => {
  // const { _handleGoogleLogin, } = useTrackingSources({})
  const {isFocused} = useLogin({});

  const _handleLogin = async () => {
    const userLogin = AuthNavigatingProfile();
  };

  return (
    <Container
      dark={true}
      barColor={"white"}
      backgroundColor={colors.light_theme.theme}
      isFocused={isFocused}>
      <View style={[styles.mainView, {paddingHorizontal: 0}]}>
        {/* <StatusBar
          animated
          barStyle="dark-content"
          backgroundColor={'white'}
          translucent={false}
        /> */}
        <View style={styles.header}>
          <InnerHeader
            title={'Login Your Account'}
            notification={true}
            setting={true}
            fontSize={fontScale * 20}
            headingfontSize={fontScale * 20}
          />
          <BorderLine style={styles.borderLine} marginTop={height * 0.009} />
        </View>

        <View style={styles.headingView}>
          <CustomText
            text={'Login to Continue'}
            fontSize={fontScale * 18}
            fontFamily={font.bold}
            textAlign={'center'}
          />
          <CustomText
            text={'Access your orders, wishlist, and exclusive offers!'}
            fontSize={fontScale * 13}
            fontFamily={font.light}
            textAlign={'center'}
            marginTop={height * 0.01}
          />
        </View>
        <View style={styles.ButtonView}>
          {/* <CustomButton
                    backgroundColor="white"
                    outline
                    marginTop={height * 0.02}
                    ImageComponentSize={width * 0.06}
                    ImageComponent={Google}
                    text="Continue with Google"
                    imageComponentStyle={{ left: '15%' }}
                    onPress={_handleGoogleLogin}
                    textStyle={{
                        color: 'black',
                        fontFamily: font.medium,
                        fontSize: fontScale * 14,
                    }}
                    width={width * 0.9}
                /> */}

          {/* <CustomButton
            backgroundColor="white"
            outline
            marginTop={WH.height(4)}
            ImageComponentSize={width * 0.06}
            ImageComponent={Google}
            text="Continue with Google"
            imageComponentStyle={{ left: '15%' }}
            onPress={_handleGoogleLogin}
            textStyle={{
              color: 'black',
              fontFamily: font.medium,
              fontSize: fontScale * 15,
            }}
          /> */}

          {/* <CustomButton
                    backgroundColor="white"
                    outline
                    marginTop={height * 0.02}
                    ImageComponentSize={width * 0.06}
                    ImageComponent={facebook}
                    text="Continue with Facebook"
                    imageComponentStyle={{ left: '14%' }}
                    onPress={_handleFacebookLogin}
                    textStyle={{
                        color: 'black',
                        fontFamily: font.medium,
                        fontSize: fontScale * 15,
                    }}
                /> */}

          <CustomButton
            backgroundColor="white"
            outline
            marginTop={height * 0.02}
            ImageComponentSize={width * 0.06}
            ImageComponent={emailBlack}
            text="Log or sign up"
            imageComponentStyle={{marginRight:  "3%"}}
            onPress={_handleLogin}
            textStyle={{
              color: 'black',
              fontFamily: font.medium,
              fontSize: fontScale * 15,
            }}
          />
        </View>
        {/* <View style={styles.orView}>
                <BorderLine style={styles.borderOr} />
                <CustomText text={"Or"} color={"#b2b2b2"} />
                <BorderLine style={styles.borderOr} />
            </View> */}
        <View style={styles.newHere}>
          {/* <CustomText text={"New here? "} /> */}
          {/* <Text style={{ color: colors.light_theme.theme, fontWeight: "800" }}>Sign Up</Text> */}
        </View>
      </View>
    </Container>
  );
};
export default ProfileLogin;

const styles = StyleSheet.create({
  mainView: {
    flex: 1,
    backgroundColor: 'white',
    paddingHorizontal: margin.horizontal,
  },
  header: {
    paddingVertical: height * 0.01,
  },
  headingView: {
    paddingVertical: margin.horizontal,
  },
  borderLine: {
    marginLeft: 0,
    width: '100%',
    backgroundColor: colors.light_theme.borderColor,
    height: height * 0.002,
  },
  ButtonView: {
    marginHorizontal: margin.horizontal,
  },
  borderOr: {
    marginLeft: 0,
    width: width * 0.4,

    backgroundColor: colors.light_theme.borderColor,
    height: height * 0.002,
  },
  orView: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginHorizontal: margin.horizontal,
    paddingVertical: margin.horizontal,
  },
  newHere: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
