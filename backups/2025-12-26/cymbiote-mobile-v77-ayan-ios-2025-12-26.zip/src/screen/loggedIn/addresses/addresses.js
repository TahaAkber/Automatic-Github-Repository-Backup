import {
  Dimensions,
  FlatList,
  RefreshControl,
  StatusBar,
  StyleSheet,
  TouchableOpacity,
  View,
} from 'react-native';
import React from 'react';
import {moderateScale, scale, verticalScale} from 'react-native-size-matters';
import InnerHeader from '@component/header/innerHeader';
import {globalStyle} from '@constant/contstant';
import useAddresses from './useAddresses';
import AddressCardForCart from '@component/cards/addressCardForCart/addressCardForCart';
import EmptyScreen from '../../../component/emptyScreen/emptyScreen';
import CustomText from '../../../materialComponent/customText/customText';
import CircleIcon from '../../../materialComponent/circleIcon/circleIcon';
import {colors, font, margin} from '../../../constant/contstant';
import AddressCard from '../../../component/cards/address/address';
import Container from '../../../materialComponent/container/container';

const {height, width, fontScale} = Dimensions.get('screen');

const Addresses = ({route}) => {
  const {fetch_address, isFocused, isGoBack, _handleAddress} = useAddresses({
    route,
  });

  return (
    <Container isFocused={isFocused} barColor={"white"} dark={true}>
      <View style={styles.mainView}>
        <InnerHeader title={'Addresses'} />
        <StatusBar
          animated
          barStyle="dark-content"
          backgroundColor="white"
          translucent={false}
        />
        <View style={{flex: 1}}>
          {fetch_address.length == 0 ? (
            <TouchableOpacity
              style={styles.addAddressContainer}
              onPress={() => _handleAddress('CreateAddress')}>
              <CustomText
                fontSize={fontScale * 14}
                fontFamily={font.bold}
                text="Add New Address"
              />
              <CircleIcon
                style={styles.addIcon}
                size={width * 0.03}
                icon_type={'FontAwesome'}
                name={'plus'}
              />
            </TouchableOpacity>
          ) : (
            <></>
          )}

          {fetch_address && fetch_address.length ? (
            // <AddressCard isGoBack={isGoBack} address={true} data={fetch_address} />
            <AddressCardForCart
              isGoBack={isGoBack}
              address={true}
              data={fetch_address}
            />
          ) : (
            <View
              style={{
                justifyContent: 'center',
                alignItems: 'center',
                flex: 1,
                marginTop: height * -0.1,
              }}>
              <EmptyScreen
                image={'empty_address'}
                heading={'No Address Yet!'}
                desc={'Add your delivery address to continue shopping smoothly'}
              />
            </View>
          )}
        </View>
      </View>
    </Container>
  );
};

export default Addresses;

const styles = StyleSheet.create({
  mainView: {
    flex: 1,
    backgroundColor: 'white',
  },
  flatLists: {
    paddingHorizontal: scale(15),
    paddingVertical: verticalScale(10),
    paddingBottom: globalStyle.bottomSpace.marginBottom,
  },
  addAddressContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginHorizontal: margin.horizontal,
    borderColor: colors.light_theme.theme,
    borderWidth: 1,
    padding: width * 0.04,
    borderRadius: moderateScale(10),
    // padding: width * 0.04,
    // borderRadius: 10,
    // backgroundColor: "#F9F9F9",
  },
  addIcon: {
    width: width * 0.06,
  },
});
