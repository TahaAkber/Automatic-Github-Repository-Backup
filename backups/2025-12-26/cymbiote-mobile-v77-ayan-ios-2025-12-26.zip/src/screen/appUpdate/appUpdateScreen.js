import React, {useMemo} from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Platform,
  Linking,
  Alert,
} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import {
  heightPercentageToDP,
  widthPercentageToDP,
} from 'react-native-responsive-screen';
import DeviceInfo from 'react-native-device-info';
import AppIcon from '@assets/images/app_icon.svg';
import {colors, font, margin, shadow} from '@constant/contstant';

const defaultStoreLinks = {
  ios: 'https://apps.apple.com',
  android: 'https://play.google.com/store/apps',
};

const AppUpdateScreen = ({
  onSkip = () => {},
  storeUrl,
  canSkip = true,
  latestVersion,
}) => {
  const currentVersion = useMemo(() => DeviceInfo.getVersion?.() || '', []);

  console.log('currentVersion', currentVersion);

  const handleUpdate = () => {
    const targetUrl =
      storeUrl ||
      (Platform.OS === 'ios'
        ? defaultStoreLinks.ios
        : defaultStoreLinks.android);
    if (targetUrl) {
      if (targetUrl) {
        if (targetUrl == 'testflight') {
          Alert.alert('Open TestFlight and update the build.');
        } else {
          Linking.openURL(targetUrl).catch(() => {});
        }
      }
    }
  };

  return (
    <LinearGradient
      colors={['#0b1d55', colors.light_theme.theme]}
      style={styles.container}>
      <View style={styles.card}>
        <View style={styles.logoWrap}>
          <AppIcon
            width={widthPercentageToDP(26)}
            height={widthPercentageToDP(26)}
          />
        </View>

        <Text style={styles.title}>New update available</Text>
        <Text style={styles.subTitle}>
          You are on v{currentVersion || '—'}. The latest version v
          {latestVersion || '—'} is available.
        </Text>

        <TouchableOpacity style={styles.primaryBtn} onPress={handleUpdate}>
          <Text style={styles.primaryText}>Update now</Text>
        </TouchableOpacity>

        {canSkip ? (
          <TouchableOpacity style={styles.secondaryBtn} onPress={onSkip}>
            <Text style={styles.secondaryText}>Continue to app</Text>
          </TouchableOpacity>
        ) : null}
      </View>
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
  },
  card: {
    marginHorizontal: margin.horizontal,
    borderRadius: 24,
    paddingHorizontal: widthPercentageToDP(6),
    paddingVertical: heightPercentageToDP(4),
    backgroundColor: 'white',
    ...shadow,
  },
  logoWrap: {
    alignSelf: 'center',
    marginBottom: heightPercentageToDP(3),
  },
  title: {
    fontFamily: font.bold,
    fontSize: widthPercentageToDP(6.2),
    textAlign: 'center',
    color: '#0b1d55',
    marginBottom: heightPercentageToDP(1.5),
  },
  subTitle: {
    fontFamily: font.medium,
    fontSize: widthPercentageToDP(3.7),
    textAlign: 'center',
    color: '#3c4a67',
    lineHeight: 22,
    marginBottom: heightPercentageToDP(4),
  },
  primaryBtn: {
    backgroundColor: colors.light_theme.theme,
    paddingVertical: heightPercentageToDP(2.2),
    borderRadius: 14,
    alignItems: 'center',
  },
  primaryText: {
    fontFamily: font.bold,
    fontSize: widthPercentageToDP(4.2),
    color: 'white',
  },
  secondaryBtn: {
    paddingVertical: heightPercentageToDP(2),
    alignItems: 'center',
    marginTop: heightPercentageToDP(1.6),
  },
  secondaryText: {
    fontFamily: font.medium,
    fontSize: widthPercentageToDP(3.8),
    color: '#0b1d55',
  },
});

export default AppUpdateScreen;
