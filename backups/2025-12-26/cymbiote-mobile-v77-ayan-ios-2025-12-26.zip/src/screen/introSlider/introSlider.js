import {
  StyleSheet,
  View,
  FlatList,
  TouchableOpacity,
  Dimensions,
  Animated,
} from 'react-native';
import {moderateScale, verticalScale} from 'react-native-size-matters';
import CustomButton from '@materialComponent/customButton/customButton';
import CustomText from '@materialComponent/customText/customText';
import Container from '@materialComponent/container/container';
import SnakeWave from '@materialComponent/snakeWave/snakeWave';
import {navigate} from '@utils/navigationRef/navigationRef';
import {globalStyle, margin} from '@constant/contstant';
import useIntroSlider from './useIntroSlider';
import {font} from '@constant/contstant';
import {WH} from '@constant/contstant';
import React, {useEffect, useRef, useState} from 'react';
import {isAndroid} from '../../constant/contstant';
import { heightPercentageToDP } from 'react-native-responsive-screen';

const {height} = Dimensions.get('screen');

const IntroSlider = () => {
  const {
    renderPagination,
    data,
    fadeAnimNew,
    fadeAnimOld,
    // translateY,
    selectIndex,
    prevIndex,
    Image,
    setSelectindex,
    scrollX,
    isFocused,
  } = useIntroSlider({});
  const flatListRef = useRef(null);

  const CurrentImage = data[selectIndex].image;
  const PrevImage = data[prevIndex].image;

  const handleMomentumScrollEnd = event => {
    const contentOffsetX = event.nativeEvent.contentOffset.x;
    const width = event.nativeEvent.layoutMeasurement.width;
    const index = Math.round(contentOffsetX / width);
    setSelectindex(index);
  };

  return (
    <Container
      barColor={'transparent'}
      translucent={true}
      isFocused={isFocused}
      dark>
      <SnakeWave />
      <View style={styles.container}>
        <View style={[{marginHorizontal: margin.horizontal}]}>
          <View
            style={[
              globalStyle.space_between,
              {
                width: '100%',
                alignItems: 'center',
                marginTop:isAndroid ? -WH.height(3) :  -WH.height(2.8),
                position: 'absolute',
                // top: WH.height(6),
                // left: margin.horizontal,
              },
            ]}>
            {/* Skip Text */}
            <CustomText
              hide={true}
              text={`skip`}
              color={'rgba(0,0,0,0)'}
              style={styles.skipText}
            />
            {renderPagination()}
            {/* {data.length - 1 == selectIndex ? (
            <TouchableOpacity onPress={() => navigate('Intrest')}>
              <CustomText text={'skip'} style={styles.skipText} />
              </TouchableOpacity>
            ) : (
              <CustomText hide={true} text={`    `} style={styles.skipText} />
            )} */}
            <TouchableOpacity onPress={() => navigate('Intrest')}>
              <CustomText text={'skip'} style={styles.skipText} />
            </TouchableOpacity>
          </View>
        </View>

        {/* Carousel with Pagination */}
        {/* <FlatList
          ref={flatListRef}
          data={data}
          renderItem={renderItem}
          keyExtractor={(item, index) => index.toString()}
          showsHorizontalScrollIndicator={false}
          horizontal
          // pagingEnabled
          onScroll={handleOnScroll}
          onMomentumScrollEnd={handleMomentumScrollEnd}
          onScrollToIndexFailed={handleScrollToIndexFailed} // Handle scroll errors
          snapToAlignment="center"
          snapToInterval={WH.width(100)}
          decelerationRate="fast"
          contentContainerStyle={{paddingRight: WH.width(100)}}
          initialScrollIndex={0}
          onLayout={() => setLayoutReady(true)}
        /> */}
        <View
          style={{
            flex: 1,
            marginTop: verticalScale(20),
            alignItems: 'center',
            justifyContent: 'center',
          }}>
          <Animated.FlatList
            ref={flatListRef}
            data={data}
            horizontal
            pagingEnabled
            showsHorizontalScrollIndicator={false}
            scrollEventThrottle={16}
            keyExtractor={(_, index) => index.toString()}
            onScroll={Animated.event(
              [{nativeEvent: {contentOffset: {x: scrollX}}}],
              {useNativeDriver: false},
            )}
            onMomentumScrollEnd={handleMomentumScrollEnd}
            renderItem={({item}) => (
              <View
                style={{
                  width: Dimensions.get('screen').width,
                  alignItems: 'center',
                  marginTop: verticalScale(50),
                }}>
                <item.image height={WH.width(70)} width={WH.width(70)} />
                <CustomText
                  marginTop={verticalScale(25)}
                  fontSize={moderateScale(25)}
                  fontFamily={font.bold}
                  text={item.heading}
                  center
                />
                <View style={{width: WH.width(50), alignItems: 'center'}}>
                  <CustomText
                    center
                    marginTop={verticalScale(5)}
                    fontSize={moderateScale(14)}
                    fontFamily={font.light}
                    text={item.text}
                  />
                </View>
              </View>
            )}
          />
        </View>

        {/* Get Started Button */}
        <View
          style={[
            {marginHorizontal: margin.horizontal, marginTop: height * 0.02},
          ]}>
          <View style={styles.getStartedButtonContainer}>
            <CustomButton
              onPress={() => navigate('AuthNavigator')}
              width={'100%'}
              text={'Get Started'}
            />
            <View style={styles.descriptionContainer}>
              <CustomText
                center
                marginTop={verticalScale(5)}
                fontSize={moderateScale(13)}
                fontFamily={font.light}
                text={'Browse and discover amazing deals.'}
              />
            </View>
          </View>
        </View>
      </View>
    </Container>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    ...globalStyle.paddingVertical,
    paddingBottom : heightPercentageToDP(3),
    width: '100%',
  },
  skipText: {
    fontFamily: font.bold,
    fontSize: moderateScale(16),
    color: 'black',
  },
  getStartedButtonContainer: {
    width: '100%',
  },
  descriptionContainer: {
    justifyContent: 'center',
    alignItems: 'center',
    width: WH.width(40),
    alignSelf: 'center',
    marginTop: 10,
  },
  carouselItem: {
    justifyContent: 'center',
    alignItems: 'center',
    width: WH.width(100), // Ensures each item takes the full width of the screen
  },
});

export default IntroSlider;

// const styles = StyleSheet.create({
//   carouselItem: {
//     justifyContent: 'center',
//     alignItems: 'center',
//     width: WH.width(100), // Ensures each item takes the full width of the screen
//   },
//   pagination: {
//     flexDirection: 'row',
//     marginVertical: verticalScale(10),
//   },
//   paginationDot: {
//     height: verticalScale(4),
//     width: WH.width(6),
//     borderRadius: 10,
//     marginLeft: 5,
//   },
// });
