import { useEffect, useRef, useState } from 'react';
import { Animated, Dimensions, StyleSheet, View } from 'react-native';
import { moderateScale, verticalScale } from 'react-native-size-matters';
import CustomText from '@materialComponent/customText/customText';
import IntroSlider1Svg from '@assets/images/browse.svg';
import IntroSlider2Svg from '@assets/images/tracking_asset.svg';
import IntroSliderSvg from '@assets/images/cashback_asset.svg';
import { font, colors, WH } from '@constant/contstant';
import {
  useSharedValue,
  useAnimatedStyle,
  withTiming,
  Easing,
} from 'react-native-reanimated';
import { useIsFocused } from '@react-navigation/native';

const useIntroSlider = ({ route }) => {
  const flatListRef = useRef(null); // Reference for FlatList
  const isFocused = useIsFocused()
  const [layoutReady, setLayoutReady] = useState(false);
  const scrollX = useRef(new Animated.Value(0)).current;
  const [selectIndex, setSelectindex] = useState(0);
  const [prevIndex, setPrevIndex] = useState(0); // Store previous index for crossfade

  const fadeNew = useSharedValue(0);
  const fadeOld = useSharedValue(1);

  const fadeAnimNew = useAnimatedStyle(() => ({
    opacity: fadeNew.value,
  }));

  const fadeAnimOld = useAnimatedStyle(() => ({
    opacity: fadeOld.value,
  }));

  const data = [
    {
      image: IntroSlider1Svg,
      heading: 'Browse Categories',
      text: 'Find everything you need in one place.',
    },
    {
      image: IntroSlider2Svg,
      heading: 'Track Orders',
      text: 'Stay updated with real time order tracking.',
    },
    {
      image: IntroSliderSvg,
      heading: 'Earn Cashback',
      text: 'Earn rewards on every purchase you make.',
    },
  ];

  // Handle page change (manual scroll or auto slide)
  const handleOnScroll = event => {
    // const contentOffsetX = event.nativeEvent.contentOffset.x;
    // const width = event.nativeEvent.layoutMeasurement.width;
    // const index = Math.floor(contentOffsetX / width);
    // setSelectindex(index); // Update the index to show the correct page
  };

  // Handle momentum scroll end for quicker scrolls
  const handleMomentumScrollEnd = event => {
    const contentOffsetX = event.nativeEvent.contentOffset.x;
    const width = event.nativeEvent.layoutMeasurement.width;
    const index = Math.floor(contentOffsetX / width);
    setSelectindex(index); // Update the index to show the correct page
  };

  // Handle button press for next page
  const handleButtonPress = () => {
    // console.log('Index', selectIndex, data);
    const nextIndex = selectIndex + 1;
    setSelectindex(nextIndex); // Update the index to show the correct page
  };

  // Automatically scroll to the selected index when selectIndex changes
  // useEffect(() => {
  //   if (layoutReady && flatListRef.current) {
  //     // Scroll only when layout is ready and index changes
  //     flatListRef.current.scrollToIndex({index: selectIndex, animated: true});
  //   }
  // }, [selectIndex, layoutReady, handleButtonPress]);

  const handleScrollToIndexFailed = info => {
    const { index } = info;
    // Handle scroll to index failure (e.g., index out of range)
    console.warn(`Failed to scroll to index ${index}`);
  };

  const backgroundColors = {
    0: colors.light_theme.confirmed,
    1: colors.light_theme.theme,
    2: colors.light_theme.lightBlue,
  };

  // Render item for the carousel
  const renderItem = ({ item }) => (
    <View style={styles.carouselItem}>
      <item.image height={WH.width(70)} width={WH.width(70)} />
      <CustomText
        marginTop={verticalScale(25)}
        fontSize={moderateScale(18)}
        fontFamily={font.bold}
        text={item.heading}
      />
      <View style={{ width: WH.width(50) }}>
        <CustomText
          center
          marginTop={verticalScale(5)}
          fontSize={moderateScale(13)}
          fontFamily={font.light}
          text={item.text}
        />
      </View>
    </View>
  );

  // Render Pagination Dots
  const renderPagination = () => {

    const inputRange = data.map((_, i) => i * Dimensions.get('screen').width);

    return (
      <View style={styles.pagination}>
        {data.map((_, i) => {
          const dotWidth = scrollX.interpolate({
            inputRange: [
              (i - 1) * Dimensions.get('screen').width,
              i * Dimensions.get('screen').width,
              (i + 1) * Dimensions.get('screen').width
            ],
            outputRange: [8, 16, 8], // active dot bigger
            extrapolate: 'clamp'
          });

          const dotColor = scrollX.interpolate({
            inputRange,
            outputRange: data.map((_, index) =>
              index === i ? backgroundColors[index] : '#606060'
            ),
          });

          return (
            <Animated.View
              key={i}
              style={[
                styles.paginationDot,
                {
                  width: dotWidth,
                  backgroundColor: dotColor
                }
              ]}
            />
          );
        })}
      </View>
    );
  };

  // useEffect(() => {
  //   // Animation reset karein
  //   fadeAnim.setValue(0);
  //   translateY.setValue(20);

  //   Animated.parallel([
  //     Animated.timing(fadeAnim, {
  //       toValue: 1,
  //       duration: 500, // Smooth fade-in effect
  //       useNativeDriver: true,
  //     }),
  //     Animated.timing(translateY, {
  //       toValue: 0,
  //       duration: 500, // Slide-up effect
  //       useNativeDriver: true,
  //     }),
  //   ]).start();
  // }, [selectIndex]);

  useEffect(() => {
    const interval = setInterval(() => {
      setSelectindex(prevIndex => {
        let newIndex = prevIndex + 1;
        if (newIndex >= data.length) {
          newIndex = 0; // Reset to start when reaching last index
        }
        setPrevIndex(prevIndex); // Store previous index for crossfade effect
        return newIndex;
      });
    }, 2000); // Change slide every 3 seconds

    return () => clearInterval(interval); // Cleanup interval
  }, []);

  useEffect(() => {
    // initial state
    fadeNew.value = 0;
    fadeOld.value = 1;

    // dissolve effect
    fadeNew.value = withTiming(1, {
      duration: 800,
      easing: Easing.out(Easing.ease),
    });
    fadeOld.value = withTiming(0, {
      duration: 800,
      easing: Easing.out(Easing.ease),
    });
  }, [selectIndex]);
  const Image = data[selectIndex].image;

  return {
    handleScrollToIndexFailed,
    handleMomentumScrollEnd,
    renderPagination,
    setLayoutReady,
    handleOnScroll,
    handleButtonPress,
    renderItem,
    flatListRef,
    selectIndex,
    data,
    // translateY,
    fadeAnimNew,
    fadeAnimOld,
    // translateY,
    setSelectindex,
    prevIndex,
    Image,
    scrollX,
    isFocused
  };
};

const styles = StyleSheet.create({
  carouselItem: {
    justifyContent: 'center',
    alignItems: 'center',
    width: WH.width(100), // Ensures each item takes the full width of the screen
  },
  pagination: {
    flexDirection: 'row',
    // marginVertical: verticalScale(10),
  },
  paginationDot: {
    height: verticalScale(6),
    width: WH.width(8),
    borderRadius: 10,
    marginLeft: 5,
  },
});

export default useIntroSlider;
