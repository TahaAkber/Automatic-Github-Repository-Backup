import React, {useEffect, useState} from 'react';
import {View, StyleSheet, Dimensions} from 'react-native';
import {homeData} from '../../constant/dummyData';
import CustomImage from '../../materialComponent/image/image';
import CustomText from '../../materialComponent/customText/customText';
import {font, globalStyle} from '../../constant/contstant';
import CustomButton from '../../materialComponent/customButton/customButton';
import Icon from '@materialComponent/icon/icon';
import useReduxStore from '../../utils/hooks/useReduxStore';
import {_storeFollowingUpdateStatus} from '../../redux/actions/merchant/merchant';
import {_cartBottomSheet} from '../../redux/actions/common/common';
import {navigate} from '../../utils/navigationRef/navigationRef';

const {width, height, fontScale} = Dimensions.get('screen');

const ReelsBrand = ({shop, item}) => {
  const {getState, dispatch} = useReduxStore();

  const {fetch_store_following_list_local, fetch_store_following_list} =
    getState('merchant');

  const existingIndex = fetch_store_following_list_local?.findIndex(
    el => el.shop_id === shop?.shop_id,
  );
  const liveListRaw = fetch_store_following_list;
  const liveStores = Array.isArray(liveListRaw)
    ? liveListRaw.map(el => el?.shop_detail?.shop_id)
    : Array.isArray(liveListRaw?.data)
    ? liveListRaw.data.map(el => el?.shop_detail?.shop_id)
    : [];
  const localStores = fetch_store_following_list_local?.map(el => el.shop_id);
  const finalArray = [...liveStores, ...localStores];

  const [follow, setFollow] = useState(finalArray.includes(shop?.shop_id)); // Change initial state to boolean
  const [followLoader, setFollowLoader] = useState(false);

  const _handleFollow = async () => {
    try {
      setFollowLoader(true);
      setFollow(prevFollow => !prevFollow);
      await dispatch(
        _storeFollowingUpdateStatus(
          shop?.shop_id,
          !follow,
          item,
          false,
          false,
          true,
        ),
      );
    } catch (error) {
      // Revert state in case of error
      setFollow(prevFollow => !prevFollow);
    } finally {
      setFollowLoader(false);
    }
  };
  const _handleNavigate = async () => {
    dispatch(_cartBottomSheet(false));
    navigate('Brand', {shop_id: shop?.shop_id, shop: item});
  };

  useEffect(() => {
    setFollow(finalArray.includes(shop?.shop_id));
  }, [finalArray.length]);
  return (
    <View style={styles.brandContainer}>
      <CustomImage
        source={{uri: shop?.shop_logo_url}}
        style={styles.brandLogo}
      />
      <CustomText
        text={shop?.shop_name}
        style={styles.brandText}
        fontFamily={font.bold}
        fontSize={fontScale * 20}
      />
      <View style={[globalStyle.row, styles.ratingContainer]}>
        <CustomText
          text={shop?.rating ? shop?.rating.toFixed(1) : '0'}
          style={{
            fontSize: fontScale * 12,
            color: 'black',
            fontFamily: font.bold,
            marginRight: 5,
          }}
        />

        <Icon icon_type={'AntDesign'} name={'star'} color={'black'} size={14} />

        <CustomText
          text={`(${shop?.total_reviews || 0})`}
          style={{
            fontSize: fontScale * 12,
            color: 'black',
            fontFamily: font.bold,
            marginLeft: 5,
          }}
        />
      </View>

      {/* Follow Button */}
      <View style={[globalStyle.row, styles.buttonView]}>
        <CustomButton
          // text={'Follow'}
          width={width * 0.4}
          height={width * 0.12}
          backgroundColor={'#000000'}
          marginTop={20}
          textStyle={{
            fontSize: fontScale * 14,
            color: 'white',
            fontFamily: font.bold,
          }}
          text={follow ? 'Following' : 'Follow'}
          onPress={_handleFollow}
        />
        <CustomButton
          width={width * 0.4}
          height={width * 0.12}
          marginTop={20}
          textStyle={{
            fontSize: fontScale * 14,
            color: 'white',
            fontFamily: font.bold,
          }}
          text={'Go to Store'}
          onPress={_handleNavigate}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  brandContainer: {
    width: '100%',
    alignItems: 'center',
    paddingVertical: 20,
    backgroundColor: '#f9f9f9',
  },
  brandLogo: {
    width: width * 0.3,
    height: width * 0.3,
    resizeMode: 'contain',
    marginBottom: 10,
    borderRadius: (width * 0.4) / 2,
  },
  brandText: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#000000',
  },
  ratingContainer: {
    alignItems: 'center',
    marginBottom: 15,
  },
  buttonView: {
    width: '100%',
    flexDirection: 'row', // <-- Add this
    justifyContent: 'space-between', // <-- Add this
    alignItems: 'flex-start',
    paddingHorizontal: 30, // <-- Optional: add some left and right padding
  },
});

export default ReelsBrand;
