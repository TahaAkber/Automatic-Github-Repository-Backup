import React, {useEffect, useState} from 'react';
import {
  StyleSheet,
  View,
  Dimensions,
  TouchableOpacity,
  Animated,
} from 'react-native';
import {moderateScale} from 'react-native-size-matters';
import {globalStyle} from '@constant/contstant';
import Icon from '../../materialComponent/icon/icon';
import useReduxStore from '../../utils/hooks/useReduxStore';
import CustomText from '../../materialComponent/customText/customText';
import {
  _likeReel,
  _savedReel,
  updateShopReel,
} from '../../redux/actions/reels/reels';
import {TOGGLE_VOLUME} from '../../redux/types/reels/reels';
import {getStoreState} from '../../utils/helper/helper';

const {fontScale, width, height} = Dimensions.get('screen');

const ReelsLSC = ({
  data,
  horizontal,
  dark,
  iconContainerStyle,
  containerStyle,
  fontSize,
  product_id,
  isActive, // 👈 used to trigger animation
  // isMuted,
  toggleVolume,
  onPress,
  // setIsMuted,
}) => {
  const {dispatch} = useReduxStore();
  const {fetch_user_detail} = getStoreState('auth');
  const [like, setLike] = useState(data?.isLiked || false);
  const [saved, setSaved] = useState(data?.isSaved || false);
  const [likeCount, setLikeCount] = useState(data?.video_likes_count || 0);
  const [savedCount, setSavedCount] = useState(data?.savedCount || 0);
  const [likeLoading, setLikeLoading] = useState(false);
  const [saveLoading, setSaveLoading] = useState(false);

  const [scale] = useState(new Animated.Value(1));
  const [translateX] = useState(new Animated.Value(100)); // Start off to the right

  useEffect(() => {
    if (isActive) {
      translateX.setValue(100); // reset
      Animated.timing(translateX, {
        toValue: 0,
        duration: 500,
        useNativeDriver: true,
      }).start();
    }
  }, [isActive]);

  const handleLike = async () => {
    try {
      setLikeLoading(true);
      const newLikeState = !like;
      const updatedLikeCount = newLikeState
        ? likeCount + 1
        : Math.max(likeCount - 1, 0);
      setLike(newLikeState);
      setLikeCount(updatedLikeCount);

      // Dispatch API
      await dispatch(_likeReel(data?.id, newLikeState));

      // Update Redux store to persist state
      dispatch(
        updateShopReel(data?.id, {
          isLiked: newLikeState,
          video_likes_count: updatedLikeCount,
        }),
      );
    } catch (error) {

    } finally {
      setLikeLoading(false);
    }
  };

  const handleSave = async () => {
    try {
      setSaveLoading(true);
      const newSavedState = !saved;
      const updatedSaveCount = newSavedState
        ? savedCount + 1
        : Math.max(savedCount - 1, 0);
      setSaved(newSavedState);
      setSavedCount(updatedSaveCount);

      await dispatch(_savedReel(data?.id, newSavedState));

      dispatch(
        updateShopReel(data?.id, {
          isSaved: newSavedState,
          savedCount: updatedSaveCount,
        }),
      );
    } catch (error) {
  
    } finally {
      setSaveLoading(false);
    }
  };
  useEffect(() => {
    setLike(data?.isLiked || false);
    setSaved(data?.isSaved || false);
    setLikeCount(data?.video_likes_count || 0);
    setSavedCount(data?.savedCount || 0);
  }, [data]);
  return (
    <Animated.View
      style={{transform: [{translateX}], opacity: isActive ? 1 : 0.5}}>
      <View
        style={[
          horizontal
            ? {right: 0, alignSelf: 'flex-end', marginBottom: height * 0.02}
            : [globalStyle.row, styles.bottom, containerStyle],
          containerStyle,
        ]}>
        {/* {fetch_user_detail?.id && ( */}
        <View
          style={[
            styles.iconWrapper,
            !fetch_user_detail?.id && {
              opacity: 0,
            },
          ]}>
          <TouchableOpacity
            onPress={fetch_user_detail?.id && handleLike}
            disabled={likeLoading}
            style={[
              styles.iconContainer,
              horizontal && {height: width * 0.1, width: width * 0.1},
              iconContainerStyle,
            ]}>
            <Animated.View style={{transform: [{scale}]}}>
              <Icon
                icon_type={'AntDesign'}
                name={'heart'}
                size={fontSize || fontScale * 20}
                color={like ? 'red' : dark ? 'black' : 'white'}
              />
            </Animated.View>
          </TouchableOpacity>
          <CustomText
            text={likeCount}
            color={'#EDEDED'}
            style={styles.iconText}
          />
        </View>
        {/* )} */}

        {/* {fetch_user_detail?.id && ( */}
        <View
          style={[
            styles.iconWrapper,
            !fetch_user_detail?.id && {
              opacity: 0,
            },
          ]}>
          <TouchableOpacity
            onPress={fetch_user_detail?.id && handleSave}
            disabled={saveLoading}
            style={[
              styles.iconContainer,
              horizontal && {height: width * 0.1, width: width * 0.1},
              iconContainerStyle,
            ]}>
            <Icon
              icon_type={'MaterialIcons'}
              name={saved ? 'bookmark' : 'bookmark-border'}
              size={fontSize || fontScale * 20}
              color={saved ? 'yellow' : dark ? 'black' : 'white'}
            />
          </TouchableOpacity>
          <CustomText
            text={savedCount}
            color={'#EDEDED'}
            style={styles.iconText}
          />
        </View>
        <View style={[styles.iconWrapper]}>
          <TouchableOpacity
            onPress={onPress}
            disabled={saveLoading}
            style={[
              styles.iconContainer,
              horizontal && {height: width * 0.1, width: width * 0.1},
              iconContainerStyle,
            ]}>
            <Icon
              icon_type={'Entypo'}
              name={'share'}
              size={fontSize || fontScale * 20}
              color={'white'}
            />
          </TouchableOpacity>
          <CustomText
            text={savedCount}
            color={'rgba(0, 0, 0, 0)'}
            style={[styles.iconText , {marginTop : 1}]}
          />
        </View>
        {/* )} */}
        {/* <View style={styles.iconWrapper}>
          <TouchableOpacity
            onPress={handleToggleVolume}
            // disabled={saveLoading}
            style={[
              styles.iconContainer,
              horizontal && {height: width * 0.13, width: width * 0.13},
              iconContainerStyle,
            ]}>
            <Icon
              icon_type={'MaterialIcons'}
              name={toggleVolume ? 'volume-off' : 'volume-up'}
              size={fontSize || fontScale * 15}
              color={dark ? 'black' : 'white'}
            />
          </TouchableOpacity>
        </View> */}
      </View>
    </Animated.View>
  );
};

export default ReelsLSC;

const styles = StyleSheet.create({
  bottom: {
    position: 'absolute',
    bottom: height * 0.15,
    justifyContent: 'center',
    alignItems: 'center',
    alignSelf: 'center',
  },
  iconContainer: {
    width: width * 0.16,
    height: height * 0.16,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
    borderRadius: (width * 0.15) / 2,
  },
  iconText: {
    marginTop: 4,
    fontSize: fontScale * 12,
    color: '#EDEDED',
  },
  iconWrapper: {
    alignItems: 'center',
    justifyContent: 'center',
    // marginHorizontal: moderateScale(1),
  },
});
