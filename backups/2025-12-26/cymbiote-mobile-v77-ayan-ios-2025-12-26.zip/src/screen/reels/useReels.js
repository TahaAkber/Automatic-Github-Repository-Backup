import {useCallback, useEffect, useLayoutEffect, useRef, useState} from 'react';
import {useDispatch, useSelector} from 'react-redux';
import {
  _getShopReels,
  _getStories,
  _getShopAndSavedReels,
} from '../../redux/actions/reels/reels';
import {useFocusEffect} from '@react-navigation/native';
import useReduxStore from '@utils/hooks/useReduxStore';
import {Animated} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const useReels = ({shop_id, video_id}) => {
  const {dispatch, getState} = useReduxStore();
  const {
    reels,
    shopReels,
    stories,
    pagination,
    shopAndSavedReels,
    toggleVolume,
  } = getState('reels');
  const {fetch_user_detail} = getState('auth');
  const [scrollY, setScrollY] = useState(new Animated.Value(0));
  const [page, setPage] = useState(1);

  const [shopReelsLoading, setShopReelsLoading] = useState(false);
  const [storiesLoading, setStoriesLoading] = useState(false);
  const [shopSavedReelsLoading, setShopSavedReelsLoading] = useState(false);
  const [showScrollThumb, setShowScrollThumb] = useState(false);
  const [isFetchedShopReels, setIsFetchedShopReels] = useState(false);
  const [isFetchedStories, setIsFetchedStories] = useState(false);
  const [isFetchedShopAndSavedReels, setIsFetchedShopAndSavedReels] =
    useState(false);

  const [paginationLoader, setPaginationLoader] = useState(false);
  const paginationAPI = async () => {
    if (paginationLoader) return;

    const totalPages = pagination.totalPages;
    const nextPage = pagination.currentPage + 1;
    if (nextPage <= totalPages) {
      setPaginationLoader(true);
      await dispatch(
        _getShopReels({
          videoId: video_id,
          page: nextPage,
          shopId: shop_id,
          pageSize: 6,
        }),
      );
      setPaginationLoader(false);
    }
  };

  const fetchShopReels = useCallback(async () => {
    if (!shopReelsLoading && !isFetchedShopReels) {
      setShopReelsLoading(true);
     
      // setPaginationLoader(true);
      await dispatch(_getShopReels({videoId: video_id, shopId: shop_id}));
      // setPaginationLoader(!paginationLoader);
      setShopReelsLoading(false);
      setIsFetchedShopReels(true);
    }
  }, [dispatch, shop_id, shopReelsLoading, isFetchedShopReels]);

  const fetchStories = useCallback(async () => {
    if (!storiesLoading && !isFetchedStories) {
      setStoriesLoading(true);
      const userId = fetch_user_detail?.id;
      await dispatch(_getStories({shopId: shop_id, userId}));
      setStoriesLoading(false);
      setIsFetchedStories(true);
    }
  }, [dispatch, shop_id, storiesLoading, isFetchedStories, fetch_user_detail]);

  const fetchShopAndSavedReels = useCallback(async () => {
    if (!shopSavedReelsLoading && !isFetchedShopAndSavedReels) {
      setShopSavedReelsLoading(true);
      await dispatch(_getShopAndSavedReels({shopId: shop_id}));
      setShopSavedReelsLoading(false);
      setIsFetchedShopAndSavedReels(true);
    }
  }, [dispatch, shop_id, shopSavedReelsLoading, isFetchedShopAndSavedReels]);

  useLayoutEffect(
    useCallback(() => {
      fetchShopReels();
    }, [fetchShopReels]),
  );

  useFocusEffect(
    useCallback(() => {
      fetchShopAndSavedReels();
    }, [fetchShopAndSavedReels]),
  );

  // const paginationAPI = async () => {
  //   const totalPages = pagination.totalPages;
  //   const nextPage = pagination.currentPage + 1;
  //   if (nextPage <= totalPages) {
  //     setPage(nextPage);
  //   }
  // };

  const viewabilityConfigRef = useRef({
    viewAreaCoveragePercentThreshold: 50,
  });
  useFocusEffect(
    useCallback(() => {
      const checkScrollThumbSeen = async () => {
        try {
          const seen = await AsyncStorage.getItem('hasSeenScrollThumb');
          if (seen === 'true') {
            setShowScrollThumb(false); // Don’t show again
          } else {
            setShowScrollThumb(true); // Show only the first time
            await AsyncStorage.setItem('hasSeenScrollThumb', 'true');
          }
        } catch (err) {
          setShowScrollThumb(false); // fallback
        }
      };
      checkScrollThumbSeen();
    }, []),
  );

  return {
    reels,
    shopReels,
    stories,
    shopAndSavedReels,
    pagination,
    scrollY,
    page,
    fetchShopAndSavedReels,
    fetchStories,
    paginationAPI,
    fetchShopReels,
    shopReelsLoading,
    storiesLoading,
    paginationLoader,
    shopSavedReelsLoading,
    viewabilityConfigRef,
    showScrollThumb,
    setShowScrollThumb,
    toggleVolume,
  };
};

export default useReels;
