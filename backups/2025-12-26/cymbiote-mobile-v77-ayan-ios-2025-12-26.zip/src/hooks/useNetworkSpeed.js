import {useState, useEffect} from 'react';
import NetInfo from '@react-native-community/netinfo';

const useNetworkSpeed = () => {
  const [pageSize, setPageSize] = useState(5); // default medium
  const [speedCategory, setSpeedCategory] = useState('medium');

  useEffect(() => {
    const unsubscribe = NetInfo.addEventListener(state => {
      const effectiveType = state.details?.cellularGeneration;
      const isWifi = state.type === 'wifi';


      // Determine speed category based on connection type
      let category = 'medium';
      let size = 5;

      if (isWifi) {
        // WiFi is considered fast
        category = 'fast';
        size = 10;
      } else if (effectiveType === '5g' || effectiveType === '4g') {
        // 4G/5G is fast
        category = 'fast';
        size = 10;
      } else if (effectiveType === '3g') {
        // 3G is medium
        category = 'medium';
        size = 7;
      } else if (
        effectiveType === '2g' ||
        state.details?.isConnectionExpensive
      ) {
        // 2G or expensive connection is slow
        category = 'slow';
        size = 3;
      }

      // Check if connection is slow based on bandwidth (if available)
      if (state.details?.downlinkMax) {
        const bandwidth = state.details.downlinkMax;
        if (bandwidth > 10) {
          category = 'fast';
          size = 7;
        } else if (bandwidth > 2) {
          category = 'medium';
          size = 5;
        } else {
          category = 'slow';
          size = 3;
        }
      }

      setSpeedCategory(category);
      setPageSize(size);
    });

    return () => unsubscribe();
  }, []);

  return {pageSize, speedCategory};
};

export default useNetworkSpeed;
