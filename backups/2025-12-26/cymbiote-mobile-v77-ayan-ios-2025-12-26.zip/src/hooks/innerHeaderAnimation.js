import { Dimensions, StatusBar, StyleSheet, View, Animated, ScrollView } from 'react-native';
import React, { useState } from 'react';

const { height, fontScale } = Dimensions.get("screen");

const useInnerHeaderAnimation = () => {

    const [scrollY] = useState(new Animated.Value(0));

    const headerTranslate = scrollY.interpolate({
        inputRange: [0, height * 0.2],
        outputRange: [0, -height * 0.1],
        extrapolate: 'clamp',
    });

    const headerOpacity = scrollY.interpolate({
        inputRange: [0, height * 0.2],
        outputRange: [1, 0],
        extrapolate: 'clamp',
    });

    const onScroll = Animated.event(
        [{ nativeEvent: { contentOffset: { y: scrollY } } }],
        { useNativeDriver: false }
    )

    return {
        headerTranslate,
        headerOpacity,
        scrollY,
        onScroll
    }
};

export default useInnerHeaderAnimation;