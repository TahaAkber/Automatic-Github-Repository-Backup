import {moderateScale} from 'react-native-size-matters';
import images from '@assets/images/images';
import {currency} from './signature';

export const dashboardData = [
  {
    id: 1,
    brand_name: 'Nike',
    title: 'Shoes & Fashion',
    image: images.nike,
    bgimage: true,
    video: true,
  },
  {
    id: 2,
    brand_name: 'Adidas',
    title: 'Shoes & Fashion',
    image: images.adidas,
    bgimage: false,
  },
  {
    id: 3,
    brand_name: 'Puma',
    title: 'Shoes & Fashion',
    image: images.puma,
    bgimage: true,
  },
  {
    id: 4,
    brand_name: 'Polo',
    title: 'Shirts & Fashion',
    image: images.alcost,
    bgimage: false,
  },
];

export const countries = [
  {id: 1, value: 'Pakistan', code: 'PK', country_code: '+92'},
  {id: 2, value: 'United States', code: 'US', country_code: '+44'},
  // {id: 2, value: 'United States', code: 'US'},
  // {id: 3, value: 'India', code: 'IN'},
  // {id: 4, value: 'Canada', code: 'CA'},
  // {id: 5, value: 'United Kingdom', code: 'GB'},
  // {id: 6, value: 'Australia', code: 'AU'},
  // {id: 7, value: 'Germany', code: 'DE'},
  // {id: 8, value: 'France', code: 'FR'},
  // {id: 9, value: 'Japan', code: 'JP'},
  // {id: 10, value: 'South Korea', code: 'KR'},
  // {id: 11, value: 'Brazil', code: 'BR'},
];

export const homeData = [
  // {
  //   "shop_name": "Nike",
  //   "shop_description": "This is a new description",
  //   "shop_shopify_id": "59523792944",
  //   "shop_id": 3,
  //   "shop_access_token": "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",
  //   "shop_domain": "quickstart-653ed797.myshopify.pk",
  //   "shop_selected_order_view": null,
  //   "shop_selectedOrder": "gid://shopify/Order/5795031613488",
  //   "shop_banner_url": "https://s3-figma-videos-production-sig.figma.com/video/1129410888986960049/TEAM/7f9d/6ada/-a0df-4f6a-a336-a88933dda861?Expires=1736726400&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=bROHNnnLR4WIrEwqRMBe65zAUiMoh0~KD6FpFhSAE9PYr7VIBHGAV7lDMOYT6me6PdZ6Gb~hsyROX3xJeurNNme7I~IoEPdjq2JL2VzHGD~g7gIDO~rvraW~qiE~LKaeljvpl4sTpIhNC-liaT-bfw1U2JgYP1IQN6LHdlACsqjh0Ac3KyyE0H~ZxSIoTsEHSMgEXfmP4gQx-hiYojMVM~1RgotSXkk037z4WSBiUhnjO4tXWO6LlTvM~G3xJiQvXbQ6CiZWtNUsnkgEf1Z-fghpzgRTBcva3BrBObhFJYNFgcbrCuuM3q1PTB4CkQGwmNsYNP~VgHunGPpepoTN1w__",
  //   "shop_logo_url": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQQgOJ4hfh4bMMVAA1lRoWz-ZdNpcrtiuYbgdDBwgoWkUs0yHpAoVSbNmAZDRTtQ8dcpuY&usqp=CAU",
  //   "shop_tile_type": "10",
  //   "shop_header_type": null,
  //   "shop_delisted": false,
  //   "shop_is_active": true,
  //   "shop_inventory_update_webhook_id": "0",
  //   "shop_order_create_webhook_id": "0",
  //   "shop_fulfillment_create_webhook_id": null,
  //   "shop_order_cancellation_webhook_id": null,
  //   "created_at": "2024-11-19T13:18:54.853Z",
  //   "updated_at": "2024-11-19T13:18:54.853Z",
  //   "products": [
  //     {
  //       "product_id": 167,
  //       "product_name": "The Out of Stock Snowboard",
  //       "product_shopify_category": "Not available",
  //       "product_custom_category": "Snowboards",
  //       "product_shopify_id": "gid://shopify/Product/7629852016692",
  //       "product_shop_id": 9,
  //       "product_description": "",
  //       "product_image_url": "https://cdn.shopify.com/s/files/1/0667/2711/6852/files/Main_f44a9605-cd62-464d-b095-d45cdaa0d0d7.jpg?v=1727083785",
  //       "product_is_active": true,
  //       "created_date": "2024-12-18T12:44:13.007Z",
  //       "created_at": "2024-12-18T12:44:13.007Z",
  //       "updated_at": "2024-12-18T12:44:13.007Z",
  //       "product_variant": [
  //         {
  //           "variant_id": 110,
  //           "variant_shopify_id": "gid://shopify/ProductVariant/45043614974004",
  //           "variant_price": 885,
  //           "variant_quantity": 0,
  //           "variant_color": null,
  //           "variant_product_id": 167,
  //           "variant_name": "Default Title",
  //           "variant_inventory_id": "0",
  //           "created_at": "2024-12-18T12:44:13.090Z",
  //           "updated_at": "2024-12-18T12:44:13.090Z"
  //         }
  //       ]
  //     },
  //     {
  //       "product_id": 167,
  //       "product_name": "The Out of Stock Snowboard",
  //       "product_shopify_category": "Not available",
  //       "product_custom_category": "Snowboards",
  //       "product_shopify_id": "gid://shopify/Product/7629852016692",
  //       "product_shop_id": 9,
  //       "product_description": "",
  //       "product_image_url": "https://cdn.shopify.com/s/files/1/0667/2711/6852/files/Main_f44a9605-cd62-464d-b095-d45cdaa0d0d7.jpg?v=1727083785",
  //       "product_is_active": true,
  //       "created_date": "2024-12-18T12:44:13.007Z",
  //       "created_at": "2024-12-18T12:44:13.007Z",
  //       "updated_at": "2024-12-18T12:44:13.007Z",
  //       "product_variant": [
  //         {
  //           "variant_id": 110,
  //           "variant_shopify_id": "gid://shopify/ProductVariant/45043614974004",
  //           "variant_price": 885,
  //           "variant_quantity": 0,
  //           "variant_color": null,
  //           "variant_product_id": 167,
  //           "variant_name": "Default Title",
  //           "variant_inventory_id": "0",
  //           "created_at": "2024-12-18T12:44:13.090Z",
  //           "updated_at": "2024-12-18T12:44:13.090Z"
  //         }
  //       ]
  //     },
  //     {
  //       "product_id": 167,
  //       "product_name": "The Out of Stock Snowboard",
  //       "product_shopify_category": "Not available",
  //       "product_custom_category": "Snowboards",
  //       "product_shopify_id": "gid://shopify/Product/7629852016692",
  //       "product_shop_id": 9,
  //       "product_description": "",
  //       "product_image_url": "https://cdn.shopify.com/s/files/1/0667/2711/6852/files/Main_f44a9605-cd62-464d-b095-d45cdaa0d0d7.jpg?v=1727083785",
  //       "product_is_active": true,
  //       "created_date": "2024-12-18T12:44:13.007Z",
  //       "created_at": "2024-12-18T12:44:13.007Z",
  //       "updated_at": "2024-12-18T12:44:13.007Z",
  //       "product_variant": [
  //         {
  //           "variant_id": 110,
  //           "variant_shopify_id": "gid://shopify/ProductVariant/45043614974004",
  //           "variant_price": 885,
  //           "variant_quantity": 0,
  //           "variant_color": null,
  //           "variant_product_id": 167,
  //           "variant_name": "Default Title",
  //           "variant_inventory_id": "0",
  //           "created_at": "2024-12-18T12:44:13.090Z",
  //           "updated_at": "2024-12-18T12:44:13.090Z"
  //         }
  //       ]
  //     },
  //     {
  //       "product_id": 167,
  //       "product_name": "The Out of Stock Snowboard",
  //       "product_shopify_category": "Not available",
  //       "product_custom_category": "Snowboards",
  //       "product_shopify_id": "gid://shopify/Product/7629852016692",
  //       "product_shop_id": 9,
  //       "product_description": "",
  //       "product_image_url": "https://cdn.shopify.com/s/files/1/0667/2711/6852/files/Main_f44a9605-cd62-464d-b095-d45cdaa0d0d7.jpg?v=1727083785",
  //       "product_is_active": true,
  //       "created_date": "2024-12-18T12:44:13.007Z",
  //       "created_at": "2024-12-18T12:44:13.007Z",
  //       "updated_at": "2024-12-18T12:44:13.007Z",
  //       "product_variant": [
  //         {
  //           "variant_id": 110,
  //           "variant_shopify_id": "gid://shopify/ProductVariant/45043614974004",
  //           "variant_price": 885,
  //           "variant_quantity": 0,
  //           "variant_color": null,
  //           "variant_product_id": 167,
  //           "variant_name": "Default Title",
  //           "variant_inventory_id": "0",
  //           "created_at": "2024-12-18T12:44:13.090Z",
  //           "updated_at": "2024-12-18T12:44:13.090Z"
  //         }
  //       ]
  //     },
  //     {
  //       "product_id": 167,
  //       "product_name": "The Out of Stock Snowboard",
  //       "product_shopify_category": "Not available",
  //       "product_custom_category": "Snowboards",
  //       "product_shopify_id": "gid://shopify/Product/7629852016692",
  //       "product_shop_id": 9,
  //       "product_description": "",
  //       "product_image_url": "https://cdn.shopify.com/s/files/1/0667/2711/6852/files/Main_f44a9605-cd62-464d-b095-d45cdaa0d0d7.jpg?v=1727083785",
  //       "product_is_active": true,
  //       "created_date": "2024-12-18T12:44:13.007Z",
  //       "created_at": "2024-12-18T12:44:13.007Z",
  //       "updated_at": "2024-12-18T12:44:13.007Z",
  //       "product_variant": [
  //         {
  //           "variant_id": 110,
  //           "variant_shopify_id": "gid://shopify/ProductVariant/45043614974004",
  //           "variant_price": 885,
  //           "variant_quantity": 0,
  //           "variant_color": null,
  //           "variant_product_id": 167,
  //           "variant_name": "Default Title",
  //           "variant_inventory_id": "0",
  //           "created_at": "2024-12-18T12:44:13.090Z",
  //           "updated_at": "2024-12-18T12:44:13.090Z"
  //         }
  //       ]
  //     },
  //     {
  //       "product_id": 162,
  //       "product_name": "The Inventory Not Tracked Snowboard",
  //       "product_shopify_category": "Not available",
  //       "product_custom_category": "Snowboards",
  //       "product_shopify_id": "gid://shopify/Product/7629851820084",
  //       "product_shop_id": 9,
  //       "product_description": "",
  //       "product_image_url": "https://cdn.shopify.com/s/files/1/0667/2711/6852/files/snowboard_purple_hydrogen.png?v=1727083776",
  //       "product_is_active": true,
  //       "created_date": "2024-12-18T12:44:12.997Z",
  //       "created_at": "2024-12-18T12:44:12.997Z",
  //       "updated_at": "2024-12-18T12:44:12.997Z",
  //       "product_variant": [
  //         {
  //           "variant_id": 102,
  //           "variant_shopify_id": "gid://shopify/ProductVariant/45043614744628",
  //           "variant_price": 949,
  //           "variant_quantity": 0,
  //           "variant_color": null,
  //           "variant_product_id": 162,
  //           "variant_name": "Default Title",
  //           "variant_inventory_id": "0",
  //           "created_at": "2024-12-18T12:44:13.047Z",
  //           "updated_at": "2024-12-18T12:44:13.047Z"
  //         }
  //       ]
  //     },
  //     {
  //       "product_id": 161,
  //       "product_name": "The Collection Snowboard: Oxygen",
  //       "product_shopify_category": "Not available",
  //       "product_custom_category": "Snowboards",
  //       "product_shopify_id": "gid://shopify/Product/7629851754548",
  //       "product_shop_id": 9,
  //       "product_description": "",
  //       "product_image_url": "https://cdn.shopify.com/s/files/1/0667/2711/6852/files/Main_d624f226-0a89-4fe1-b333-0d1548b43c06.jpg?v=1727083770",
  //       "product_is_active": true,
  //       "created_date": "2024-12-18T12:44:12.997Z",
  //       "created_at": "2024-12-18T12:44:12.997Z",
  //       "updated_at": "2024-12-18T12:44:12.997Z",
  //       "product_variant": [
  //         {
  //           "variant_id": 109,
  //           "variant_shopify_id": "gid://shopify/ProductVariant/45043614679092",
  //           "variant_price": 1025,
  //           "variant_quantity": 0,
  //           "variant_color": null,
  //           "variant_product_id": 161,
  //           "variant_name": "Default Title",
  //           "variant_inventory_id": "0",
  //           "created_at": "2024-12-18T12:44:13.050Z",
  //           "updated_at": "2024-12-18T12:44:13.050Z"
  //         }
  //       ]
  //     },
  //     {
  //       "product_id": 160,
  //       "product_name": "The Multi-managed Snowboard",
  //       "product_shopify_category": "Not available",
  //       "product_custom_category": "Snowboards",
  //       "product_shopify_id": "gid://shopify/Product/7629851787316",
  //       "product_shop_id": 9,
  //       "product_description": "",
  //       "product_image_url": "https://cdn.shopify.com/s/files/1/0667/2711/6852/files/Main_9129b69a-0c7b-4f66-b6cf-c4222f18028a.jpg?v=1727083772",
  //       "product_is_active": true,
  //       "created_date": "2024-12-18T12:44:12.997Z",
  //       "created_at": "2024-12-18T12:44:12.997Z",
  //       "updated_at": "2024-12-18T12:44:12.997Z",
  //       "product_variant": [
  //         {
  //           "variant_id": 100,
  //           "variant_shopify_id": "gid://shopify/ProductVariant/45043614711860",
  //           "variant_price": 629,
  //           "variant_quantity": 0,
  //           "variant_color": null,
  //           "variant_product_id": 160,
  //           "variant_name": "Default Title",
  //           "variant_inventory_id": "0",
  //           "created_at": "2024-12-18T12:44:13.040Z",
  //           "updated_at": "2024-12-18T12:44:13.040Z"
  //         }
  //       ]
  //     }
  //   ]
  // },
  {
    shop_name: 'Nike',
    shop_description: 'This is a new description',
    shop_shopify_id: '59523792944',
    shop_id: 3,
    shop_access_token: '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',
    shop_domain: 'quickstart-653ed797.myshopify.pk',
    shop_selected_order_view: null,
    shop_selectedOrder: 'gid://shopify/Order/5795031613488',
    shop_banner_url:
      'https://s3-figma-videos-production-sig.figma.com/video/1129410888986960049/TEAM/7f9d/6ada/-a0df-4f6a-a336-a88933dda861?Expires=1736726400&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=bROHNnnLR4WIrEwqRMBe65zAUiMoh0~KD6FpFhSAE9PYr7VIBHGAV7lDMOYT6me6PdZ6Gb~hsyROX3xJeurNNme7I~IoEPdjq2JL2VzHGD~g7gIDO~rvraW~qiE~LKaeljvpl4sTpIhNC-liaT-bfw1U2JgYP1IQN6LHdlACsqjh0Ac3KyyE0H~ZxSIoTsEHSMgEXfmP4gQx-hiYojMVM~1RgotSXkk037z4WSBiUhnjO4tXWO6LlTvM~G3xJiQvXbQ6CiZWtNUsnkgEf1Z-fghpzgRTBcva3BrBObhFJYNFgcbrCuuM3q1PTB4CkQGwmNsYNP~VgHunGPpepoTN1w__',
    shop_logo_url:
      'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQQgOJ4hfh4bMMVAA1lRoWz-ZdNpcrtiuYbgdDBwgoWkUs0yHpAoVSbNmAZDRTtQ8dcpuY&usqp=CAU',
    shop_tile_type: '7',
    shop_header_type: null,
    shop_delisted: false,
    shop_is_active: true,
    shop_inventory_update_webhook_id: '0',
    shop_order_create_webhook_id: '0',
    shop_fulfillment_create_webhook_id: null,
    shop_order_cancellation_webhook_id: null,
    created_at: '2024-11-19T13:18:54.853Z',
    updated_at: '2024-11-19T13:18:54.853Z',
    products: [
      {
        product_id: 167,
        product_name: 'The Out of Stock Snowboard',
        product_shopify_category: 'Not available',
        product_custom_category: 'Snowboards',
        product_shopify_id: 'gid://shopify/Product/7629852016692',
        product_shop_id: 9,
        product_description: '',
        product_image_url:
          'https://s3-alpha-sig.figma.com/img/dfc3/dd72/6e0f810b0310ac03baa5a0afa501097b?Expires=1740355200&Key-Pair-Id=APKAQ4GOSFWCW27IBOMQ&Signature=inj1GIy8n0gDesZ5xlGvFWB8kVq0E9-JqSM84c6sMGsTW0ghhvGIo0eA~F33O7Dl0gNN~0WbxIVpStiIk6oO-SpPOp5ShiHIaTr~iJ~vQXzfora3y79QSaIPlYLc4bqoB3SfFJA7mGuBwZ3omunWlJB3Qsl7E5uSMQGcc2CV16~6bHkeBvsUY-AJP7LcleAbRJokZvAr2JKX5CU0IUo~fCTrxsZtwj2DwNn5Z719CTvznjsA0WT~fw2sKCli161Ai5P6dfkTGPov2T1M5I6Keng~6sKkiIM9JsbGeypuABeQLveHCEL-f0kkcKj2RaaCpY1e2Q5zGcYohmpk1RF7Tw__',
        product_is_active: true,
        created_date: '2024-12-18T12:44:13.007Z',
        created_at: '2024-12-18T12:44:13.007Z',
        updated_at: '2024-12-18T12:44:13.007Z',
        product_variant: [
          {
            variant_id: 110,
            variant_shopify_id: 'gid://shopify/ProductVariant/45043614974004',
            variant_price: 885,
            variant_quantity: 1,
            variant_color: null,
            variant_product_id: 167,
            variant_name: 'Default Title',
            variant_inventory_id: '0',
            created_at: '2024-12-18T12:44:13.090Z',
            updated_at: '2024-12-18T12:44:13.090Z',
            selected_options: [
              {
                name: 'Color',
                value: 'Yellow',
              },
            ],
          },
        ],
      },
      {
        product_id: 167,
        product_name: 'The Out of Stock Snowboard',
        product_shopify_category: 'Not available',
        product_custom_category: 'Snowboards',
        product_shopify_id: 'gid://shopify/Product/7629852016692',
        product_shop_id: 9,
        product_description: '',
        product_image_url:
          'https://cdn.shopify.com/s/files/1/0667/2711/6852/files/Main_f44a9605-cd62-464d-b095-d45cdaa0d0d7.jpg?v=1727083785',
        product_is_active: true,
        created_date: '2024-12-18T12:44:13.007Z',
        created_at: '2024-12-18T12:44:13.007Z',
        updated_at: '2024-12-18T12:44:13.007Z',
        product_variant: [
          {
            variant_id: 110,
            variant_shopify_id: 'gid://shopify/ProductVariant/45043614974004',
            variant_price: 885,
            variant_quantity: 1,
            variant_color: null,
            variant_product_id: 167,
            variant_name: 'Default Title',
            variant_inventory_id: '0',
            created_at: '2024-12-18T12:44:13.090Z',
            updated_at: '2024-12-18T12:44:13.090Z',
          },
        ],
      },
      {
        product_id: 167,
        product_name: 'The Out of Stock Snowboard',
        product_shopify_category: 'Not available',
        product_custom_category: 'Snowboards',
        product_shopify_id: 'gid://shopify/Product/7629852016692',
        product_shop_id: 9,
        product_description: '',
        product_image_url:
          'https://cdn.shopify.com/s/files/1/0667/2711/6852/files/Main_f44a9605-cd62-464d-b095-d45cdaa0d0d7.jpg?v=1727083785',
        product_is_active: true,
        created_date: '2024-12-18T12:44:13.007Z',
        created_at: '2024-12-18T12:44:13.007Z',
        updated_at: '2024-12-18T12:44:13.007Z',
        product_variant: [
          {
            variant_id: 110,
            variant_shopify_id: 'gid://shopify/ProductVariant/45043614974004',
            variant_price: 885,
            variant_quantity: 1,
            variant_color: null,
            variant_product_id: 167,
            variant_name: 'Default Title',
            variant_inventory_id: '0',
            created_at: '2024-12-18T12:44:13.090Z',
            updated_at: '2024-12-18T12:44:13.090Z',
          },
        ],
      },
      {
        product_id: 162,
        product_name: 'The Inventory Not Tracked Snowboard',
        product_shopify_category: 'Not available',
        product_custom_category: 'Snowboards',
        product_shopify_id: 'gid://shopify/Product/7629851820084',
        product_shop_id: 9,
        product_description: '',
        product_image_url:
          'https://cdn.shopify.com/s/files/1/0667/2711/6852/files/snowboard_purple_hydrogen.png?v=1727083776',
        product_is_active: true,
        created_date: '2024-12-18T12:44:12.997Z',
        created_at: '2024-12-18T12:44:12.997Z',
        updated_at: '2024-12-18T12:44:12.997Z',
        product_variant: [
          {
            variant_id: 102,
            variant_shopify_id: 'gid://shopify/ProductVariant/45043614744628',
            variant_price: 949,
            variant_quantity: 1,
            variant_color: null,
            variant_product_id: 162,
            variant_name: 'Default Title',
            variant_inventory_id: '0',
            created_at: '2024-12-18T12:44:13.047Z',
            updated_at: '2024-12-18T12:44:13.047Z',
          },
        ],
      },
      {
        product_id: 161,
        product_name: 'The Collection Snowboard: Oxygen',
        product_shopify_category: 'Not available',
        product_custom_category: 'Snowboards',
        product_shopify_id: 'gid://shopify/Product/7629851754548',
        product_shop_id: 9,
        product_description: '',
        product_image_url:
          'https://cdn.shopify.com/s/files/1/0667/2711/6852/files/Main_d624f226-0a89-4fe1-b333-0d1548b43c06.jpg?v=1727083770',
        product_is_active: true,
        created_date: '2024-12-18T12:44:12.997Z',
        created_at: '2024-12-18T12:44:12.997Z',
        updated_at: '2024-12-18T12:44:12.997Z',
        product_variant: [
          {
            variant_id: 109,
            variant_shopify_id: 'gid://shopify/ProductVariant/45043614679092',
            variant_price: 1025,
            variant_quantity: 10,
            variant_color: null,
            variant_product_id: 161,
            variant_name: 'Default Title',
            variant_inventory_id: '0',
            created_at: '2024-12-18T12:44:13.050Z',
            updated_at: '2024-12-18T12:44:13.050Z',
          },
        ],
      },
      {
        product_id: 160,
        product_name: 'The Multi-managed Snowboard',
        product_shopify_category: 'Not available',
        product_custom_category: 'Snowboards',
        product_shopify_id: 'gid://shopify/Product/7629851787316',
        product_shop_id: 9,
        product_description: '',
        product_image_url:
          'https://cdn.shopify.com/s/files/1/0667/2711/6852/files/Main_9129b69a-0c7b-4f66-b6cf-c4222f18028a.jpg?v=1727083772',
        product_is_active: true,
        created_date: '2024-12-18T12:44:12.997Z',
        created_at: '2024-12-18T12:44:12.997Z',
        updated_at: '2024-12-18T12:44:12.997Z',
        product_variant: [
          {
            variant_id: 100,
            variant_shopify_id: 'gid://shopify/ProductVariant/45043614711860',
            variant_price: 629,
            variant_quantity: 10,
            variant_color: null,
            variant_product_id: 160,
            variant_name: 'Default Title',
            variant_inventory_id: '0',
            created_at: '2024-12-18T12:44:13.040Z',
            updated_at: '2024-12-18T12:44:13.040Z',
          },
        ],
      },
    ],
  },
  {
    shop_name: 'Outfitters',
    shop_description: 'This is a new description',
    shop_shopify_id: '59523792944',
    shop_id: 3,
    shop_access_token: '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',
    shop_domain: 'quickstart-653ed797.myshopify.pk',
    shop_selected_order_view: null,
    shop_selectedOrder: 'gid://shopify/Order/5795031613488',
    shop_banner_url:
      'https://s3-figma-videos-production-sig.figma.com/video/1129410888986960049/TEAM/7f9d/6ada/-a0df-4f6a-a336-a88933dda861?Expires=1736726400&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=bROHNnnLR4WIrEwqRMBe65zAUiMoh0~KD6FpFhSAE9PYr7VIBHGAV7lDMOYT6me6PdZ6Gb~hsyROX3xJeurNNme7I~IoEPdjq2JL2VzHGD~g7gIDO~rvraW~qiE~LKaeljvpl4sTpIhNC-liaT-bfw1U2JgYP1IQN6LHdlACsqjh0Ac3KyyE0H~ZxSIoTsEHSMgEXfmP4gQx-hiYojMVM~1RgotSXkk037z4WSBiUhnjO4tXWO6LlTvM~G3xJiQvXbQ6CiZWtNUsnkgEf1Z-fghpzgRTBcva3BrBObhFJYNFgcbrCuuM3q1PTB4CkQGwmNsYNP~VgHunGPpepoTN1w__',
    shop_logo_url:
      'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQQgOJ4hfh4bMMVAA1lRoWz-ZdNpcrtiuYbgdDBwgoWkUs0yHpAoVSbNmAZDRTtQ8dcpuY&usqp=CAU',
    shop_tile_type: '11',
    shop_header_type: null,
    shop_delisted: false,
    shop_is_active: true,
    shop_inventory_update_webhook_id: '0',
    shop_order_create_webhook_id: '0',
    shop_fulfillment_create_webhook_id: null,
    shop_order_cancellation_webhook_id: null,
    created_at: '2024-11-19T13:18:54.853Z',
    updated_at: '2024-11-19T13:18:54.853Z',
  },
  {
    shop_name: 'Amazon',
    shop_description: 'This is a new description',
    email: 'ayan123@gmail.com',
    shop_shopify_id: '59523792944',
    shop_id: 4,
    shop_access_token: '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',
    shop_domain: 'quickstart-653ed797.myshopify.pk',
    shop_selected_order_view: null,
    shop_selectedOrder: 'gid://shopify/Order/5795031613488',
    shop_banner_url:
      'https://s3-figma-videos-production-sig.figma.com/video/1129410888986960049/TEAM/7f9d/6ada/-a0df-4f6a-a336-a88933dda861?Expires=1736726400&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=bROHNnnLR4WIrEwqRMBe65zAUiMoh0~KD6FpFhSAE9PYr7VIBHGAV7lDMOYT6me6PdZ6Gb~hsyROX3xJeurNNme7I~IoEPdjq2JL2VzHGD~g7gIDO~rvraW~qiE~LKaeljvpl4sTpIhNC-liaT-bfw1U2JgYP1IQN6LHdlACsqjh0Ac3KyyE0H~ZxSIoTsEHSMgEXfmP4gQx-hiYojMVM~1RgotSXkk037z4WSBiUhnjO4tXWO6LlTvM~G3xJiQvXbQ6CiZWtNUsnkgEf1Z-fghpzgRTBcva3BrBObhFJYNFgcbrCuuM3q1PTB4CkQGwmNsYNP~VgHunGPpepoTN1w__',
    shop_logo_url:
      'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQDwMtfSDs_eomaWB3hca352yoq9TGCgGgS6g&s',
    shop_tile_type: '7',
    shop_header_type: null,
    shop_delisted: false,
    shop_is_active: true,
    shop_inventory_update_webhook_id: '0',
    shop_order_create_webhook_id: '0',
    shop_fulfillment_create_webhook_id: null,
    shop_order_cancellation_webhook_id: null,
    created_at: '2024-11-19T13:18:54.853Z',
    updated_at: '2024-11-19T13:18:54.853Z',
  },
];

export const dashboardFilters = [
  {
    id: 1,
    value: 'Filter',
    icon: true,
    data: [],
  },
  {
    id: 2,
    value: 'Sort By',
    data: [
      {
        id: 1,
        value: 'Relevance (default)',
      },
      {
        id: 2,
        value: 'Latest',
      },
      {
        id: 3,
        value: 'Oldest',
      },
    ],
  },
  {
    id: 3,
    value: 'Category',
    data: [
      {
        id: 1,
        value: 'Fashion/Apparel',
      },
      {
        id: 2,
        value: 'Electronics',
      },
      {
        id: 3,
        value: 'Beauty & Personal Care',
      },
    ],
  },
  {
    id: 4,
    value: 'Featured',
    data: [
      {
        id: 1,
        value: 'Trending',
      },
    ],
  },
  {
    id: 4,
    value: 'On sale',
    data: [
      {
        id: 1,
        value: 'Trending',
      },
    ],
  },
];

export const dashboardCollections = [
  {
    id: 1,
    value: 'On Sale',
  },
  {
    id: 2,
    value: 'Trending',
  },
  // {
  //   id: 3,
  //   value: 'Shirts',
  // },
  // {
  //   id: 4,
  //   value: 'Top',
  // },
];

export const searchData = [
  {
    id: 1,
    value: 'Sweat Shirt',
    image:
      'https://babynestboutique.com/cdn/shop/products/Whats-App-Image-2023-01-18-at-5-46-05-PM.jpg?v=1710322096',
  },
  {
    id: 2,
    value: 'T-Shirt',
    image:
      'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQYBqz2ikwcBOKCEBFg9vCW7H3rt-8S6LElSw&s',
  },
  {
    id: 2,
    value: 'Shirt',
    image:
      'https://mytshirtprinting.store/wordpress/wp-content/uploads/2020/07/birthday-boy-kids-tshirt-for-boys-web.jpg',
  },
  {
    id: 2,
    value: 'Birth Day Shirt',
    image:
      'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ3rc1YMzI6o1WJJxFkjNTeXyjGWEKAmno06zjeDUJEgVhRE09EtNfR7xpnOWYInWaJDWs&usqp=CAU',
  },
];

export const following = [
  {
    id: 1,
    image:
      'https://cdn.shopify.com/s/files/1/0595/2379/2944/files/dabc.png?v=1738433402',
    brandName: 'FashionNova',
  },

  {
    id: 2,
    image:
      'https://cdn.shopify.com/s/files/1/0595/2379/2944/files/bcda.png?v=1738433402',
    brandName: 'Vitality',
  },
  {
    id: 3,
    image:
      'https://cdn.shopify.com/s/files/1/0595/2379/2944/files/cdab.png?v=1738433401',
    brandName: 'WoodFiber',
  },
  {
    id: 4,
    image:
      'https://cdn.shopify.com/s/files/1/0595/2379/2944/files/abcd.png?v=1738433841',
    brandName: 'Tree Bark',
  },
];

export const recentlyViewedProduct = [
  {
    id: 1,
    image:
      'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTctfE4oDwcLSCqohQGcprcSflUdtWRWmbIww&s',
  },
  {
    id: 2,
    image:
      'https://condomshop.pk/cdn/shop/products/plain-red-tshirt_grande.jpg?v=1449214693',
    isProduct: true,
  },
  {
    id: 3,
    image:
      'https://condomshop.pk/cdn/shop/products/plain-red-tshirt_grande.jpg?v=1449214693',
    isProduct: true,
  },
  {
    id: 4,
    image:
      'https://img.freepik.com/premium-vector/tree-bark-logo-wood-tree-simple-texture-vector-design-symbol-illustration_557439-17323.jpg?semt=ais_hybrid',
  },
];

export const brandThreeDots = [
  {id: 1, value: 'Visit Shop', iconType: 'Entypo', iconName: 'shop'},
  {id: 1, value: 'Follow', iconType: 'AntDesign', iconName: 'pluscircleo'},
  {
    id: 2,
    value: 'Not Intrested',
    iconType: 'Feather',
    iconName: 'thumbs-down',
    form: {
      heading: 'Not Intrested',
      subHeading: 'Please select a reason',
      fields: [
        {
          type: 'radio',
          text: "I just don't like it",
          value: false,
        },
        {
          type: 'radio',
          text: 'Products are too expensive',
          value: false,
        },
        {
          type: 'radio',
          text: 'Want to see fewer shops like this',
          value: false,
        },
        {
          type: 'radio',
          text: 'Want to see less of Thats So Fetch US',
          value: false,
        },
      ],
    },
  },
  {
    id: 1,
    value: 'Report Shop',
    iconType: 'MaterialIcons',
    iconName: 'report',
    size: moderateScale(25),
    color: 'red',
    form: {
      heading: 'Report Shop',
      subHeading: 'Please select a reason',
      fields: [
        {
          type: 'radio',
          text: 'Misleading',
          value: false,
        },
        {
          type: 'radio',
          text: 'Inapropriate content',
          value: false,
        },
        {
          type: 'radio',
          text: 'Other',
          value: false,
        },
      ],
    },
  },
];
