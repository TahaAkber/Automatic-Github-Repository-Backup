import {moderateScale} from 'react-native-size-matters';
import {
  heightPercentageToDP,
  widthPercentageToDP,
} from 'react-native-responsive-screen';
import {Dimensions} from 'react-native';
import PetSupply from '@assets/images/search_pet_supply.svg';
import Fashion from '@assets/images/search_fashion_apparel.svg';
import Entertainment from '@assets/images/ArtsEntertainmaen.svg';
import Toys from '@assets/images/babyToodler.svg';
import GroceryFood from '@assets/images/gocery_food.svg';
import Electronic from '@assets/images/search_electronic.svg';
import Furniture from '@assets/images/Furniture.svg';
import Business from '@assets/images/BusinessIndustrial.svg';
import CameraOptics from '@assets/images/CameraOptics.svg';
import BeautyPersonal from '@assets/images/search_beauty_personal_care.svg';
import HomeGarden from '@assets/images/home_garden.svg';
import LuggagesBags from '@assets/images/luggageBags.svg';
import OfficeSuplies from '@assets/images/OfficeSuplies.svg';
// import Mature from '@assets/images/search_mature.svg';
import Media from '@assets/images/search_media.svg';
import Religious from '@assets/images/Religious&Ceremonial.svg';
import Software from '@assets/images/Software.svg';
import ProductAddOns from '@assets/images/ProductAdd-Ons.svg';
import Bundles from '@assets/images/Bundles.svg';
import Sports from '@assets/images/search_sports.svg';
import Automotive from '@assets/images/automotive.svg';
import Hardware from '@assets/images/Hardware.svg';
import Gift from '@assets/images/search_gift.svg';
import Miscellenous from '@assets/images/Miscellenous.svg';
import services from '@assets/images/services.svg';
import artsEntertainment from '@assets/images/Arts&Entertainment.svg';
import BabyToddler from '@assets/images/Baby&Toddler.svg';
import Mature from '@assets/images/Mature.svg';

const {width, height, fontScale} = Dimensions.get('screen');

export const tileHeight = heightPercentageToDP(61);
// export const tileHeight = height * 0.61;
export const tileLandScapeHeight = height * 0.5;
export const tileBasicHeight = tileHeight || height * 0.5;
export const tileBasicNoOfThreeHeight = tileHeight || height * 0.5;
export const tileBasicThirdHeight = tileHeight || height * 0.52;

export const colors = {
  light_theme: {
    rgbaTheme: 'rgba(84, 112, 199,0.5)',
    darkBorderColor: '#dcdcdc',
    borderColor: '#f4f4f4',
    // theme: '#6966CD',
    theme: '#223ea4',
    gray: '#b6b6b6',
    text: 'black',
    backgroundColor: '#F5F5F5',
    themeBackgroundColor: '#fff',
    confirmed: '#00CE83',
    pending: '#FF9624',
    lightBlue: '#1A97CD',
    themeGray: '#A7A7A7',
  },
  dark_theme: {
    rgbaTheme: 'rgba(84, 112, 199,0.5)',
    darkBorderColor: '#dcdcdc',
    borderColor: '#f4f4f4',
    theme: '#6966CD',
    gray: '#1A1C1E',
    text: 'black',
    backgroundColor: '#edf1f3',
    confirmed: '##00CE83',
    pending: '#FF9624',
    lightBlue: '#1A97CD',
    themeGray: '#A7A7A7',
  },
};

export const fontSizes = {
  extra_small: moderateScale(8),
  regular: moderateScale(15),
  medium: moderateScale(20),
  large: moderateScale(25),
  small: moderateScale(10),
};

export const font = {
  italicBold: 'Satoshi-BoldItalic',
  italic: 'Satoshi-LightItalic',
  regular: 'Satoshi-Regular',
  medium: 'Satoshi-Medium',
  // medium:'Satoshi-Regular',
  black: 'Satoshi-Black',
  bold: 'Satoshi-Bold',
  // bold:'Satoshi-Medium',
  light: 'Satoshi-Light',
};

export const margin = {
  horizontal: width * 0.05,
};

export const shadow = {
  shadowColor: '#000',
  shadowOffset: {width: 0, height: 2}, // smaller vertical offset
  shadowOpacity: 0.06, // lighter opacity
  shadowRadius: 4, // smaller blur
  elevation: 5, // less intense shadow on Android
};

export const bottomTabShadow = {
  shadowColor: 'rgba(0,0,0,0.35)',
  shadowOffset: {width: 0, height: 8},
  shadowOpacity: 0.3,
  shadowRadius: 12,
  elevation: 14,
};

export const tileShadow = {
  shadowColor: '#000',
  shadowOffset: {width: 0, height: 3}, // a bit shallower
  shadowOpacity: 0.12, // lighter opacity
  shadowRadius: 5,
};

export const WH = {
  height: heightPercentageToDP,
  width: widthPercentageToDP,
};

export const globalStyle = {
  row: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  show_error: {
    height: WH.height(100),
    backgroundColor: 'white',
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: '20%',
  },
  space_between: {
    justifyContent: 'space-between',
    flexDirection: 'row',
    alignItems: 'center',
  },
  bottomSpace: {
    marginBottom: WH.height(10),
  },
  paddingVertical: {
    paddingVertical: WH.height(8),
  },
};
export const isAndroid = Platform.OS === 'android';

export const vibrationDuration = 50; // Duration for vibration in milliseconds

export const filtersData = [
  // {
  //   id: 1,
  //   heading: 'Following',
  //   db_value: 'following',
  //   type: 'single-select',
  //   value: '',
  //   default_value: '',
  // },
  // {
  //   id: 2,
  //   heading: 'On Sale',
  //   db_value: 'on_sale',
  //   type: 'single-select',
  //   value: '',
  //   default_value: '',
  // },
  {
    id: 3,
    heading: 'Ratings',
    db_value: 'ratings',
    type: 'radio',
    value: '',
    default_value: '',
    data: [
      {
        id: '',
        value: 'All Select',
        main_search: '',
      },
      {
        id: 5,
        value: '& Up',
        main_search: '4',
      },
      {
        id: 4,
        value: '& Up',
        main_search: '3',
      },
      {
        id: 3,
        value: '& Up',
        main_search: '2',
      },
      {
        id: 2,
        value: '& Up',
        main_search: '1',
      },
    ],
  },
  {
    id: 3,
    heading: 'Brands',
    db_value: 'brands',
    type: 'radio',
    value: '',
    default_value: '',
    data: [],
  },
  {
    id: 6,
    heading: 'Cloth Size',
    db_value: 'cloth_size',
    type: 'radio',
    value: '',
    default_value: '',
    data: [
      {id: 1, value: 'XS', main_search: 'XS'},
      {id: 2, value: 'S', main_search: 'S'},
      {id: 3, value: 'M', main_search: 'M'},
      {id: 4, value: 'L', main_search: 'L'},
      {id: 5, value: 'XL', main_search: 'XL'},
      {id: 6, value: 'XXL', main_search: 'XXL'},
    ],
  },
  {
    id: 5,
    heading: 'Colors',
    db_value: 'colors',
    type: 'radio',
    value: '',
    default_value: '',
    data: [
      {id: 1, value: 'Red', main_search: 'Red'},
      {id: 2, value: 'Blue', main_search: 'Blue'},
      {id: 3, value: 'Green', main_search: 'Green'},
      {id: 4, value: 'Black', main_search: 'Black'},
      {id: 5, value: 'White', main_search: 'White'},
      {id: 6, value: 'Brown', main_search: 'Brown'},
      {id: 7, value: 'Purple', main_search: 'Purple'},
      {id: 8, value: 'Orange', main_search: 'Orange'},
      {id: 9, value: 'Yellow', main_search: 'Yellow'},
      {id: 10, value: 'Pink', main_search: 'Pink'},
      {id: 11, value: 'Beige', main_search: 'Beige'},
      {id: 12, value: 'Grey', main_search: 'Grey'},
      {id: 13, value: 'Gray', main_search: 'Gray'},
      {id: 14, value: 'Maroon', main_search: 'Maroon'},
      {id: 15, value: 'Navy', main_search: 'Navy'},
      {id: 16, value: 'Gold', main_search: 'Gold'},
      {id: 17, value: 'Silver', main_search: 'Silver'},
      {id: 18, value: 'Ivory', main_search: 'Ivory'},
      {id: 19, value: 'Cream', main_search: 'Cream'},
      {id: 20, value: 'Charcoal', main_search: 'Charcoal'},
      {id: 21, value: 'Khaki', main_search: 'Khaki'},
      {id: 22, value: 'Olive', main_search: 'Olive'},
      {id: 23, value: 'Teal', main_search: 'Teal'},
      {id: 24, value: 'Cyan', main_search: 'Cyan'},
      {id: 25, value: 'Magenta', main_search: 'Magenta'},
    ],
  },
  {
    id: 6,
    heading: 'Shoe Size',
    db_value: 'shoe_size',
    type: 'radio',
    value: '',
    default_value: '',
    data: [
      {id: 1, value: '38', main_search: '38'},
      {id: 2, value: '39', main_search: '39'},
      {id: 3, value: '40', main_search: '40'},
      {id: 4, value: '41', main_search: '41'},
      {id: 5, value: '42', main_search: '42'},
      {id: 6, value: '43', main_search: '43'},
    ],
  },
  {
    id: 6,
    heading: 'Price',
    db_value: 'price',
    type: 'range',
    value: '',
    default_value: [0, 200000],
  },
  {
    id: 7,
    heading: 'Sort By',
    db_value: 'sort_by',
    type: 'radio',
    value: '',
    default_value: '',
    data: [
      {
        id: 2,
        value: 'Price: Low to High',
        collection_price_filter: 'ASC',
      },
      {
        id: 3,
        value: 'Price: High to Low',
        collection_price_filter: 'DESC',
      },
      {
        id: 4,
        value: 'Newest First',
        collection_filter: ['DESC', 'created'],
      },
      {
        id: 5,
        value: 'Oldest First',
        collection_filter: ['ASC', 'created'],
      },
    ],
  },
];

export const taxonomiesFiltered = {
  'Animals & Pet Supplies': {
    fullName: 'Pet Supplies',
    backgroundColor: '#44BA7F',
    SvgImage: PetSupply,
  },

  'Apparel & Accessories': {
    fullName: 'Fashion & Apparel',
    backgroundColor: '#44BA7F',
    SvgImage: Fashion,
  },
  'Arts & Entertainment': {
    fullName: 'Arts & Entertainment',
    backgroundColor: '#1E97CE',
    SvgImage: Entertainment,
  },
  'Baby & Toddler': {
    fullName: 'Baby & Toddler',
    backgroundColor: '#1E97CE',
    SvgImage: Toys,
  },
  'Business & Industrial': {
    fullName: 'Business & Industrial',
    backgroundColor: '#1E97CE',
    SvgImage: Business,
  },
  'Cameras & Optics': {
    fullName: 'Cameras & Optics',
    backgroundColor: '#1E97CE',
    SvgImage: CameraOptics,
  },
  Electronics: {
    fullName: 'Electronics',
    backgroundColor: '#EC2424',
    SvgImage: Electronic,
  },
  'Food, Beverages & Tobacco': {
    fullName: 'Grocery & Food',
    backgroundColor: '#EC2424',
    SvgImage: GroceryFood,
  },
  Furniture: {
    fullName: 'Furniture',
    backgroundColor: '#1E97CE',
    SvgImage: Furniture,
  },
  Hardware: {
    fullName: 'Hardware',
    backgroundColor: '#1E97CE',
    SvgImage: Hardware,
  },
  'Health & Beauty': {
    fullName: 'Beauty & Personal Care',
    backgroundColor: '#F57F20',
    SvgImage: BeautyPersonal,
  },
  'Home & Garden': {
    fullName: 'Home & Garden',
    backgroundColor: '#44BA7F',
    SvgImage: HomeGarden,
  },
  'Luggage & Bags': {
    fullName: 'Luggage & Bags',
    backgroundColor: '#1E97CE',
    SvgImage: LuggagesBags,
  },
  Mature: {
    fullName: 'Mature',
    backgroundColor: '#1E97CE',
    SvgImage: Mature,
    // noicon: true,
  },
  Media: {
    fullName: 'Media',
    backgroundColor: '#1E97CE',
    SvgImage: Media,
    noicon: true,
  },
  'Office Supplies': {
    fullName: 'Office Supplies',
    backgroundColor: '#1E97CE',
    SvgImage: OfficeSuplies,
  },
  'Religious & Ceremonial': {
    fullName: 'Religious & Ceremonial',
    backgroundColor: '#1E97CE',
    SvgImage: Religious,
    noicon: true,
  },
  Software: {
    fullName: 'Software',
    backgroundColor: '#1E97CE',
    SvgImage: Software,
    noicon: true,
  },
  'Sporting Goods': {
    fullName: 'Sporting & Outdoors',
    backgroundColor: '#F57F20',
    SvgImage: Sports,
  },
  'Toys & Games': {
    fullName: 'Toys & Games',
    backgroundColor: '#1E97CE',
    SvgImage: Toys,
  },
  'Vehicles & Parts': {
    fullName: 'Automotive',
    backgroundColor: '#F57F20',
    SvgImage: Automotive,
  },
  'Gift Cards': {
    fullName: 'Gift & Speciality',
    backgroundColor: '#6867AF',
    SvgImage: Gift,
  },
  Uncategorized: {
    fullName: 'Miscellaneous',
    backgroundColor: '#6867AF',
    SvgImage: Miscellenous,
  },
  Services: {
    fullName: 'Services',
    backgroundColor: '#6867AF',
    SvgImage: services,
  },
  'Product Add-Ons': {
    fullName: 'Product Add-Ons',
    backgroundColor: '#6867AF',
    SvgImage: ProductAddOns,
    noicon: true,
  },
  Bundles: {
    fullName: 'Bundles',
    backgroundColor: '#6867AF',
    SvgImage: Bundles,
    noicon: true,
  },
};

export const cercleRgbColors = [
  'rgb(246, 153, 76)',
  'rgb(75, 172, 215)',
  'rgb(104, 200, 154)',
  'rgb(240, 80, 80)',
  'rgb(134, 133, 191)',
];

export const statusMap = {
  IN_PROGRESS: {label: 'In Progress', color: '#2E7DC1', theme: '#2E7DC1'},
  OUT_FOR_DELIVERY: {label: 'Shipped', color: '#FCB914', theme: '#FCB914'},
  IN_TRANSIT: {label: 'In Transit', color: '#F57F21', theme: '#F57F21'},
  CONFIRMED: {label: 'Delivered', color: '#23B477', theme: '#23B477'},
  DELIVERED: {label: 'Delivered', color: '#23B477', theme: '#23B477'},
  DELAYED: {label: 'Delayed', color: 'black', theme: 'black'},
  LABEL_PRINTED: {label: 'Label Printed', color: '#A0A0A0', theme: 'black'},
  LABEL_PURCHASED: {label: 'Label Purchased', color: 'black', theme: 'black'},
  READY_FOR_PICKUP: {label: 'Pickup', color: 'black', theme: 'black'},
  FAILURE: {label: 'Failed', color: 'black', theme: 'black'},
};

export const noImageUrl =
  'https://cdn.shopify.com/s/files/1/0595/2379/2944/files/img_not_found_cercle.jpg?v=1757333158';

export const trackingServices = [
  {
    id: 1,
    value: 'DHL',
    image:
      'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQBGrIa9CAXFKQ72Ixu6TvBwn39rFXE3OUgkA&s',
  },
  {
    id: 2,
    value: 'TCS',
    image:
      'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcScRNu4QoitmsopE3PtUu_v2PHLgcVL1bnmpA&s',
  },
];
