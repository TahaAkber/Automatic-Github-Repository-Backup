import React, { createContext, useContext, useRef } from 'react';

const ScrollToTopContext = createContext();

export const ScrollToTopProvider = ({ children }) => {
  const scrollRefs = useRef({});

  const setScrollHandler = (key, handler) => {
    scrollRefs.current[key] = handler;
  };

  const triggerScroll = (key) => {
    if (scrollRefs.current[key]) {
      scrollRefs.current[key]();
    }
  };

  return (
    <ScrollToTopContext.Provider value={{ setScrollHandler, triggerScroll }}>
      {children}
    </ScrollToTopContext.Provider>
  );
};

export const useScrollToTop = () => useContext(ScrollToTopContext);
