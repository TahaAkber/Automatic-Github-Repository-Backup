export const currency = 'PKR';
