import React from "react";
import { Svg, Path } from "react-native-svg";

const CartBackgroundSvg = ({ width = 162, height = 20 }) => {
  return (
    <Svg width={width} height={height} viewBox={`0 0 162 20`} fill="none">
      <Path
        d="M35.9898 18C37.4425 19 38.9475 19.5 40.4598 19.5H116.46C117.808 19.5 119.152 19.2 120.46 18.5L157.46 2C158.75 1.2 160.077 1 161.41 1H159.41L118.49 2.5H38.1898L2.28976 1H0.00976562C1.5195 1 3.02168 1.5 4.46976 2L35.9898 18Z"
        fill="white"
      />
    </Svg>
  );
};

export default CartBackgroundSvg;
