import React from "react";
import { Svg, Path } from "react-native-svg";

const CartTotalSvg = ({ width = 332, height = 151, fillColor = "black" }) => {
  return (
    <Svg width={width} height={height} viewBox="0 0 332 151" fill="none">
      <Path
        d="M0 16C0 7.16344 7.16344 0 16 0H86.0512C88.8576 0 91.6146 0.738117 94.0455 2.14028L122.527 18.5681C124.958 19.9703 127.714 20.7084 130.521 20.7084H165.614H202.717C205.227 20.7084 207.702 20.1178 209.941 18.9844L244.049 1.72392C246.289 0.59055 248.764 0 251.274 0H316C324.837 0 332 7.16344 332 16V111C332 133.091 314.091 151 292 151H40C17.9086 151 0 133.091 0 111V16Z"
        fill={fillColor}
      />
    </Svg>
  );
};

export default CartTotalSvg;
