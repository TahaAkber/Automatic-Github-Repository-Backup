import React, {useEffect, useRef} from 'react';
import {View, StyleSheet, Animated, Dimensions} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';

const {width} = Dimensions.get('screen');

const LEG = 200; // move duration per leg
const PAUSE = 100; // pause at center

const VideoBufferIndicator = ({isBuffering, isVisible}) => {
  // shimmerAnim ranges -1 .. 0 .. 1 (0 = centered)
  const shimmerAnim = useRef(new Animated.Value(0)).current;
  const opacityAnim = useRef(new Animated.Value(0)).current;
  const loopRef = useRef(null);

  useEffect(() => {
    if (isBuffering && isVisible) {
      Animated.timing(opacityAnim, {
        toValue: 1,
        duration: 200,
        useNativeDriver: true,
      }).start();

      shimmerAnim.setValue(0);

      const loop = Animated.loop(
        Animated.sequence([
          // center -> right
          Animated.timing(shimmerAnim, {
            toValue: 1,
            duration: LEG,
            useNativeDriver: true,
          }),
          // pause at center on the way out? (already past center), so pause when we return:
          Animated.delay(PAUSE),

          // right -> center (pause!)
          Animated.timing(shimmerAnim, {
            toValue: 0,
            duration: LEG,
            useNativeDriver: true,
          }),
          Animated.delay(PAUSE),

          // center -> left
          Animated.timing(shimmerAnim, {
            toValue: -1,
            duration: LEG,
            useNativeDriver: true,
          }),
          Animated.delay(PAUSE),

          // left -> center (pause!)
          Animated.timing(shimmerAnim, {
            toValue: 0,
            duration: LEG,
            useNativeDriver: true,
          }),
          Animated.delay(PAUSE),
        ]),
      );

      loopRef.current = loop;
      loop.start();
    } else {
      Animated.timing(opacityAnim, {
        toValue: 0,
        duration: 300,
        useNativeDriver: true,
      }).start();

      if (loopRef.current?.stop) {
        loopRef.current.stop();
        loopRef.current = null;
      }
    }

    return () => {
      if (loopRef.current?.stop) {
        loopRef.current.stop();
        loopRef.current = null;
      }
    };
  }, [isBuffering, isVisible, shimmerAnim, opacityAnim]);

  // Translate around center: -1 => left, 0 => center, 1 => right
  const translateX = shimmerAnim.interpolate({
    inputRange: [-1, 0, 1],
    outputRange: [-width * 0.6, 0, width * 0.6],
  });

  if (!isVisible) return null;

  return (
    <Animated.View
      style={[styles.container, {opacity: opacityAnim}]}
      pointerEvents="none">
      <View style={styles.bufferLine}>
        <Animated.View
          style={[
            styles.shimmerContainer,
            {
              left: width * 0.3, // center at rest (width/2 - (0.4*width)/2)
              transform: [{translateX}],
            },
          ]}>
          <LinearGradient
            colors={['transparent', 'rgba(255,255,255,0.8)', 'transparent']}
            start={{x: 0, y: 0}}
            end={{x: 1, y: 0}}
            style={styles.shimmerGradient}
          />
        </Animated.View>
      </View>
    </Animated.View>
  );
};

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    bottom: 50, // unchanged
    left: 0,
    right: 0,
    height: 3,
    zIndex: 100,
  },
  bufferLine: {
    width: '100%',
    height: '100%',
    backgroundColor: 'rgba(255,255,255,0.2)',
    overflow: 'hidden',
    borderRadius: 2,
  },
  shimmerContainer: {
    position: 'absolute',
    width: width * 0.4,
    height: '100%',
  },
  shimmerGradient: {
    flex: 1,
    width: '100%',
    height: '100%',
  },
});

export default VideoBufferIndicator;
