import React, {useMemo} from 'react';
import {View, Dimensions, Platform, StyleSheet} from 'react-native';
import {moderateScale} from 'react-native-size-matters';

import CustomText from '../../materialComponent/customText/customText';
import {margin} from '../../constant/contstant';
import ShopTileCategories from '../shopTIleCategories/shopTIleCategories';
import BrandContentProducts from './brandContentProducts';
import TabView from '../tabView/tabView';

const {width, height} = Dimensions.get('screen');
const isAndroid = Platform.OS === 'android';

const StickyFilters = React.memo(function StickyFilters({
  filterOptions = [],
  selectedCollectionId,
  collectionProducts = [],
  products = [],
  fetch_store_product_detail_loader = false,
  collectionLoading = false,
  paginationLoader = false,
  shop = {},
  handleSelectCollection = () => {},
  sub_category = [],
  showProducts = [],
}) {
  const hasFilters = useMemo(() => {
    return Array.isArray(filterOptions) && filterOptions.length > 0;
  }, [filterOptions]);

  const hasSubCategories = useMemo(() => {
    return Array.isArray(sub_category) && sub_category.length > 0;
  }, [sub_category]);

  const showCustomTabView = hasFilters || hasSubCategories;

  const dataToShow = useMemo(() => {
    return selectedCollectionId ? collectionProducts : products;
  }, [selectedCollectionId, collectionProducts, products]);

  const shopColor = shop?.shop_color || '#fff';

  return (
    <View style={[styles.container, {backgroundColor: shopColor}]}>
      <View style={[styles.innerContainer]}>
        {showCustomTabView ? (
          <>
            {filterOptions?.length > 0 ? (
              <TabView
                handleSelectCollection={handleSelectCollection}
                sub_category={sub_category}
                selectedCollectionId={selectedCollectionId}
                category={filterOptions}
                loader={fetch_store_product_detail_loader || collectionLoading}
                paginationLoader={paginationLoader}
                data={showProducts}
              />
            ) : (
              <View>
                <ShopTileCategories
                  item={[]}
                  onSelect={handleSelectCollection}
                  subCategory={sub_category}
                  selectedCollectionId={selectedCollectionId}
                />
                <BrandContentProducts
                  shop={shop}
                  loader={
                    fetch_store_product_detail_loader || collectionLoading
                  }
                  data={showProducts}
                  paginationLoader={paginationLoader}
                  selectedCollectionId={selectedCollectionId}
                />
              </View>
            )}
          </>
        ) : (
          <CustomText text="All Products" style={styles.allProductsText} />
        )}
      </View>
    </View>
  );
});

export default StickyFilters;

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  loaderContainer: {
    bottom: 0,
  },
  innerContainer: {
    marginHorizontal: 0,
    // marginTop: isAndroid ? height * 0.1 : height * 0.1,
    // flexGrow: 1,
  },
  allProductsText: {
    fontSize: moderateScale(16),
    fontWeight: 'bold',
    color: '#000',
    marginHorizontal: margin.horizontal,
    paddingVertical: 20,
  },
});
