import React, {useCallback} from 'react';
import {View, FlatList, Dimensions} from 'react-native';
import SearchedItemsLoader from '../loader/searchedItemsLoader';
import PagionationLoader from '../loader/endReachLoader';
import HomeDualCard from '../cards/homeDualCard';
import {margin, WH} from '../../constant/contstant';
import useReduxStore from '../../utils/hooks/useReduxStore';

const {height} = Dimensions.get('screen');

const BrandContentProducts = React.memo(
  ({
    data = [],
    paginationLoader = false,
    shop = {},
    selectedCollectionId,
    selectedSubCategory,
    loader,
  }) => {
    const {getState} = useReduxStore();
    const {fetch_store_collection_loader} = getState('merchant');

    const renderProductItem = useCallback(
      ({item}) => (
        <View style={{}}>
          <HomeDualCard
            item={item}
            width={WH.width('44')}
            color={'black'}
            brandScreen={true}
          />
        </View>
      ),
      [shop?.shop_font_color, selectedSubCategory],
    );


    const keyExtractor = useCallback(
      (item, index) => item?.product_id?.toString?.() || index.toString(),
      [selectedCollectionId, selectedSubCategory],
    );

    if (loader) {
      return (
        <View style={{backgroundColor: shop?.shop_color, height: 1000000}}>
          <View
            style={{
              marginHorizontal: margin.horizontal,
              paddingBottom: height * 0.05,
            }}>
            <SearchedItemsLoader />
          </View>
        </View>
      );
    }

    return (
      <View style={{backgroundColor: shop?.shop_color}}>
        <View
          style={{
            marginHorizontal: margin.horizontal,
            paddingBottom: data?.length <= 4 ? height * 0.6 : height * 0.05,
          }}>
          {fetch_store_collection_loader ? (
            <SearchedItemsLoader />
          ) : (
            <>
              <FlatList
                data={data}
                extraData={{selectedSubCategory, data: data?.length}}
                renderItem={renderProductItem}
                keyExtractor={keyExtractor}
                contentContainerStyle={{paddingBottom: height * 0.11}}
                showsVerticalScrollIndicator={false}
                numColumns={2}
                scrollEnabled={false}
                columnWrapperStyle={{justifyContent: 'space-between'}}
                ListFooterComponent={
                  paginationLoader ? <PagionationLoader /> : null
                }
                initialNumToRender={6}
                maxToRenderPerBatch={10}
                windowSize={7}
                removeClippedSubviews={true}
              />
            </>
          )}
        </View>
      </View>
    );
  },
);

export default BrandContentProducts;
