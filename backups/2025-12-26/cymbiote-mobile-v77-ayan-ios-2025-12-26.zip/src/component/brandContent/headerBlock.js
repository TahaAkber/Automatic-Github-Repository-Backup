import {Dimensions, StyleSheet, TouchableOpacity, View} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Animated from 'react-native-reanimated';
import CustomImage from '../../materialComponent/image/image';
import CustomText from '../../materialComponent/customText/customText';
import Icon from '../../materialComponent/icon/icon';
import CustomButton from '../../materialComponent/customButton/customButton';
import {
  font,
  globalStyle,
  margin,
  noImageUrl,
  WH,
} from '../../constant/contstant';
import ReelList from '../cards/reelCard/reelList';
import {moderateScale} from 'react-native-size-matters';
import CollectionLoader from '../loader/collectionLoader';
import Collection from './collection';
import ReelsLoader from '../loader/reelsLoader';

const {width, height, fontScale} = Dimensions.get('screen');

const HeaderBlock = ({
  IMG_HEIGHT,
  imageAnimatedStyle,
  shop,
  startRingAnimation,
  animatedRingStyle,
  upadatedShop,
  handleFollow,
  isFollowing,
  isLoggedIn,
  refRBNotificationSheet,
  fetch_store_product_detail_loader,
  fetch_store_collection,
  fetch_store_collection_loader,
  shopsReels,
  _handleNavigatetoReels,
  onSearchPress,
}) => {
  return (
    <View style={{}}>
      <View>
        <Animated.Image
          style={[
            styles.backgroundImage,
            {height: IMG_HEIGHT},
            imageAnimatedStyle,
          ]}
          source={{uri: upadatedShop?.shop_cover_url || noImageUrl}}
          resizeMode="cover"
        />
      </View>
      <View
        style={{
          backgroundColor: upadatedShop?.shop_color,
          // paddingBottom: height * 0.02,
          // bottom:0
        }}>
        {upadatedShop?.shopHaveStory && (
          <TouchableOpacity
            onPress={startRingAnimation}
            style={styles.gradientWrapper}>
            <Animated.View style={[styles.animatedRing, animatedRingStyle]}>
              <LinearGradient
                colors={['#ED1D1D', '#1A97CD', '#00CE83', '#FF7F00']}
                start={{x: 0.1, y: 0.2}}
                end={{x: 0.9, y: 0.8}}
                locations={[0, 0.3, 0.7, 1]}
                style={styles.gradientRing}
              />
            </Animated.View>
            <View style={styles.brandViewWithRing}>
              <CustomImage
                source={{uri: upadatedShop?.shop_logo_url}}
                style={styles.brandProfile}
                size="small"
              />
            </View>
          </TouchableOpacity>
        )}
        {/* Default Logo */}
        {!upadatedShop?.shopHaveStory && (
          <View style={styles.secondView}>
            <CustomImage
              source={{uri: upadatedShop?.shop_logo_url}}
              style={styles.brandProfile}
              size="small"
            />
          </View>
        )}

        <View
          style={[
            styles.ContentBox,
            upadatedShop?.shopHaveStory
              ? styles.storySpacing
              : styles.noStorySpacing,
          ]}>
          <CustomText
            text={upadatedShop?.shop_name}
            fontSize={fontScale * 17}
            fontFamily={font.bold}
            color={upadatedShop?.shop_font_color}
          />
          <View style={[globalStyle.row, {marginTop: height * 0.01}]}>
            <CustomText
              text={
                upadatedShop?.shop_rating
                  ? upadatedShop?.shop_rating.toFixed(1)
                  : '0'
              }
              fontFamily={font.medium}
              color={upadatedShop?.shop_font_color}
              fontSize={fontScale * 10}
            />
            <Icon
              icon_type="AntDesign"
              name="star"
              style={{marginLeft: width * 0.012}}
              size={8}
              color={upadatedShop?.shop_font_color}
            />
            <CustomText
              text={`(${upadatedShop?.total_reviews || 0})`}
              style={{marginLeft: width * 0.012}}
              fontFamily={font.medium}
              color={upadatedShop?.shop_font_color}
              fontSize={fontScale * 10}
            />
          </View>
          <CustomText
            text={upadatedShop?.shop_description}
            fontFamily={font.light}
            color={upadatedShop?.shop_font_color}
            fontSize={12}
            marginTop={height * 0.01}
          />
          <View style={[globalStyle.row, styles.actionsRow]}>
            <CustomButton
              onPress={handleFollow}
              text={isFollowing ? 'Following' : 'Follow'}
              backgroundColor={'black'}
              marginTop={0}
              width={width * 0.4}
              height={height * 0.05}
            />
            {isLoggedIn && (
              <CustomButton
                onPress={() => refRBNotificationSheet?.current?.open()}
                iconType="FontAwesome"
                name="bell-o"
                color="black"
                backgroundColor="#E8E8E8"
                marginTop={0}
                width={width * 0.11}
                height={height * 0.05}
                buttonStyle={{
                  marginLeft: 10,
                  width: width * 0.11,
                  aspectRatio: 1,
                }}
                size={16}
              />
            )}

            <CustomButton
              onPress={onSearchPress}
              iconType="Fontisto"
              name="search"
              color="black"
              backgroundColor="#E8E8E8"
              marginTop={0}
              width={width * 0.11}
              height={height * 0.05}
              buttonStyle={{
                marginLeft: 10,
                width: width * 0.11,
                aspectRatio: 1,
              }}
              size={16}
            />
          </View>
          {/* <CustomText text={"Collections"} fontSize={fontScale*20} fontFamily={font.bold} color={"white"} marginTop={height * 0.02}/> */}
        </View>
        {fetch_store_product_detail_loader ? (
          <CollectionLoader />
        ) : (
          <View style={{}}>
            <Collection
              marginBottom={height * 0.02}
              marginTop={height * 0.00001}
              textColor={shop?.shop_font_color}
              collection={fetch_store_collection}
              loading={fetch_store_collection_loader}
              
            />
          </View>
        )}

        {/* <ReelCard/> */}
        {fetch_store_product_detail_loader ? (
          <ReelsLoader />
        ) : (
          <View>
            {shopsReels?.reels?.reels?.length > 0 && (
              <>
                <View style={[globalStyle.space_between, styles.textView]}>
                  <CustomText
                    fontSize={fontScale * 20}
                    fontFamily={font.bold}
                    color={shop?.shop_font_color}
                    text={'Videos'}
                  />

                  <TouchableOpacity onPress={_handleNavigatetoReels}>
                    <CustomText
                      color={shop?.shop_font_color}
                      fontSize={fontScale * 14}
                      fontFamily={font.medium}
                      text={'View All'}
                    />
                  </TouchableOpacity>
                </View>
                <View style={styles.reelsSection}>
                  <ReelList item={shopsReels?.reels} isMerchantScreen={true} />
                </View>
              </>
            )}
          </View>
        )}
      </View>
    </View>
  );
};

export default HeaderBlock;

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  backgroundImage: {
    width: width,
    // height: IMG_HEIGHT,
    // bottom: 80,
  },
  gradientOverlay: {
    height: height * 0.4,
    width: '100%',
    position: 'absolute',
    top: 0,
    zIndex: 2,
  },
  brandTab: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginHorizontal: margin.horizontal,
  },
  secondView: {
    width: width * 0.27,
    height: height * 0.12,
    borderWidth: 3,
    borderColor: '#fff',
    borderRadius: 100,
    alignItems: 'center',
    justifyContent: 'center',
    position: 'absolute',
    top: -50,
    bottom: 0,
    left: 10,
    right: 0,
    zIndex: 99,
    backgroundColor: '#fff',
  },
  ContentBox: {
    marginHorizontal: margin.horizontal,
  },
  storySpacing: {
    paddingTop: height * 0.04,
  },
  noStorySpacing: {
    paddingTop: height * 0.09,
  },
  video_view: {
    // position: 'absolute',
    height: '100%',
    width: '100%',
    zIndex: 99,
    bottom: 0,
    right: 0,
    left: 0,
    top: 0,
  },

  logoUrl: {
    width: '58%',
    aspectRatio: 1,
    borderRadius: 180,
  },
  textView: {
    marginHorizontal: margin.horizontal,
    // marginTop: height * 0.02,
    // marginTop: height * 0.02,
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  gradientWrapper: {
    justifyContent: 'center',
    alignItems: 'center',
    height: WH.width('10%'),
    width: WH.width('10%'),
    marginRight: moderateScale(10),
  },
  actionsRow: {
    marginBottom: height * 0.02,
  },
  animatedRing: {
    position: 'absolute',
    width: width * 0.27,
    height: height * 0.12,
    borderRadius: WH.width('22%') / 2,
    overflow: 'hidden',
    top: -50,
    bottom: 0,
    left: 10,
    right: 0,
  },
  gradientRing: {
    width: width * 0.27,
    height: height * 0.12,
  },
  brandViewWithRing: {
    width: width * 0.27,
    height: height * 0.12,
    borderWidth: 3,
    borderColor: '#fff',
    borderRadius: 100,
    alignItems: 'center',
    justifyContent: 'center',
    position: 'absolute',
    top: -50,
    bottom: 0,
    left: 10,
    right: 0,
    zIndex: 99,
    backgroundColor: '#fff',
  },
  brandProfile: {
    width: width * 0.26,
    aspectRatio: 1,
    borderRadius: 100,
  },
  brandView: {
    borderRadius: moderateScale(180),
    marginRight: moderateScale(10),
    backgroundColor: 'white',
    height: WH.width('10%'),
    width: WH.width('10%'),
    overflow: 'hidden',
  },
  reelsSection: {
    // marginHorizontal: margin.horizontal,
    marginBottom: height * 0.02,
  },
  header: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 95, // Height of the header
    backgroundColor: '#fff', // Default transparent, becomes opaque via animation
    // borderBottomWidth: StyleSheet.hairlineWidth, // Thin bottom border
    borderBottomColor: '#ccc', // Border color
    zIndex: 10, // Ensure it's above the scroll view content
    justifyContent: 'flex-end', // Align content to the bottom
    alignItems: 'center', // Center horizontally
    paddingBottom: 0, // Padding at the bottom for content
    paddingTop: 10, // Adjust for status bar height,
  },
  absoluteHeader: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
  },
  relativeHeader: {
    position: 'relative',
  },
});
