import {
  StyleSheet,
  TouchableOpacity,
  Animated,
  View,
  Text,
  Dimensions,
} from 'react-native';
import React, {useRef, useEffect} from 'react';
import {
  heightPercentageToDP,
  widthPercentageToDP,
} from 'react-native-responsive-screen';
import {goBack} from '../../utils/navigationRef/navigationRef';
import Icon from '../../materialComponent/icon/icon';
import CartIcon from '../../assets/images/cartIcon';
import useReduxStore from '../../utils/hooks/useReduxStore';
import {colors, isAndroid, shadow} from '../../constant/contstant';
import {
  _cartBottomSheet,
  triggerCartBounce,
} from '../../redux/actions/common/common';
import {triggerHaptic} from '../../utils/haptic/haptic';
import {useSafeAreaInsets} from 'react-native-safe-area-context';

const {height, fontScale} = Dimensions.get('screen');

const BottomTabBackAndCart = ({height: tabHeight}) => {
  const {getState, dispatch} = useReduxStore();
  const {focusHomeScreen, cartBottomSheet, cartBounce} = getState('common');
  const {cart_item} = getState('cart');

  // Back button animation
  const backTranslateX = useRef(new Animated.Value(0)).current;
  const backOpacity = useRef(new Animated.Value(1)).current;

  // Cart button animation
  const cartTranslateX = useRef(new Animated.Value(100)).current;
  const cartScale = useRef(new Animated.Value(1)).current;
  const insets = useSafeAreaInsets();

  // Back button slide + fade
  useEffect(() => {
    if (focusHomeScreen) {
      Animated.parallel([
        Animated.timing(backTranslateX, {
          toValue: -widthPercentageToDP(20),
          duration: 300,
          useNativeDriver: true,
        }),
        Animated.timing(backOpacity, {
          toValue: 0,
          duration: 300,
          useNativeDriver: true,
        }),
      ]).start();
    } else {
      Animated.parallel([
        Animated.timing(backTranslateX, {
          toValue: 0,
          duration: 300,
          useNativeDriver: true,
        }),
        Animated.timing(backOpacity, {
          toValue: 1,
          duration: 300,
          useNativeDriver: true,
        }),
      ]).start();
    }
  }, [focusHomeScreen]);

  // Cart button slide in/out based on cart length
  useEffect(() => {
    Animated.timing(cartTranslateX, {
      toValue: cart_item?.length > 0 ? 0 : 300,
      duration: 500,
      useNativeDriver: true,
    }).start();
  }, [cart_item?.length, cartBottomSheet]);

  // Cart bounce animation
  useEffect(() => {
    if (cartBounce) {
      Animated.sequence([
        Animated.spring(cartScale, {
          toValue: 1.5,
          friction: 3,
          tension: 100,
          useNativeDriver: true,
        }),
        Animated.spring(cartScale, {
          toValue: 1,
          friction: 7,
          tension: 100,
          useNativeDriver: true,
        }),
      ]).start(() => {
        dispatch(triggerCartBounce(false));
      });
    }
  }, [cartBounce]);

  const bottom = isAndroid
    ? heightPercentageToDP(4) + insets.bottom - heightPercentageToDP(2)
    : heightPercentageToDP(4);

  return (
    <>
      {/* Back Button */}
      <Animated.View
        style={[
          styles.backButtonContainer,
          {
            transform: [{translateX: backTranslateX}],
            opacity: backOpacity,
            height: tabHeight,
            bottom: bottom,
          },
        ]}>
        <TouchableOpacity
          onPress={() => {
            triggerHaptic();
            goBack();
          }}
        style={styles.button}>
          <Icon
            icon_type={'AntDesign'}
            name="arrowleft"
            size={20}
            color="black"
          />
        </TouchableOpacity>
      </Animated.View>

      {/* Cart Button */}
      <Animated.View
        style={[
          styles.cartContainer,
          {
            transform: [{translateX: cartTranslateX}, {scale: cartScale}],
            height: tabHeight,
            bottom: bottom
          },
        ]}>
        <TouchableOpacity
          onPress={() => {
            triggerHaptic();
            dispatch(_cartBottomSheet(true));
          }}
          style={[styles.button, {backgroundColor: colors.light_theme.theme}]}>
          <CartIcon color="white" />
          {cart_item?.length ? (
            <View style={styles.badge}>
              <Text style={styles.badgeText}>{`${cart_item.length}`}</Text>
            </View>
          ) : null}
        </TouchableOpacity>
      </Animated.View>
    </>
  );
};

export default BottomTabBackAndCart;

const styles = StyleSheet.create({
  backButtonContainer: {
    position: 'absolute',
    bottom: heightPercentageToDP(4),
    left: widthPercentageToDP(15),
    aspectRatio: 1,
    zIndex: 2,
    backgroundColor: 'white',
    borderRadius: 180,
    ...shadow,
    shadowOffset: {width: 0, height: 4},
    shadowColor: '#000',
    shadowOpacity: 0.15,
    shadowRadius: 8,
  },
  cartContainer: {
    position: 'absolute',
    // bottom: heightPercentageToDP(4),
    right: widthPercentageToDP(15),
    zIndex: 2,

    height: heightPercentageToDP(4.5),
    aspectRatio: 1,
    borderRadius: 180,
    ...shadow,
    shadowOffset: {width: 0, height: 4},
    shadowColor: '#000',
    shadowOpacity: 0.15,
    shadowRadius: 8,
  },
  button: {
    aspectRatio: 1,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 180,
    padding: 6,
  },
  badge: {
    position: 'absolute',
    top: 3,
    right: 5,
    backgroundColor: 'red',
    borderRadius: 8,
    paddingHorizontal: 0.5,

    paddingBottom: 1,
    height: heightPercentageToDP(1.4),
    aspectRatio: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  badgeText: {
    color: 'white',
    fontSize: fontScale * 7,
    fontWeight: 'bold',
  },
});
