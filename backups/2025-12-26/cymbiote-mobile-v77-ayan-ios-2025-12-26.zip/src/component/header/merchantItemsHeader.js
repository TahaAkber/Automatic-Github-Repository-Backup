import CustomText from '@materialComponent/customText/customText';
import { Dimensions, StyleSheet, View } from 'react-native';
import { font, WH } from '@constant/contstant';
import React from 'react';
import CustomImage from '../../materialComponent/image/image';
import { margin } from '../../constant/contstant';

const { width, height, fontScale } = Dimensions.get("screen")

const MerchantItemsHeader = ({ shop, subtitle }) => {
    return (
        <View style={styles.header}>
            <CustomImage source={{ uri: shop?.shop_logo_url }} style={styles.image} />
            <View>
                <CustomText fontFamily={font.bold} fontSize={fontScale * 16} text={shop?.shop_name} />
                <CustomText fontFamily={font.medium} marginTop={height * 0.005} fontSize={fontScale * 14} color={"#A0A0A0"} text={subtitle} />
            </View>
        </View>
    );
};

export default MerchantItemsHeader;

const styles = StyleSheet.create({
    header: {
        flexDirection: "row",
        alignItems: "center",
        borderBottomWidth: 1,
        borderColor: "#A0A0A0",
        paddingBottom: height * 0.02,
        paddingHorizontal: margin.horizontal
    },
    image: {
        width: width * 0.15,
        aspectRatio: 1,
        borderRadius: 180,
        marginRight: width * 0.03
    },
});
