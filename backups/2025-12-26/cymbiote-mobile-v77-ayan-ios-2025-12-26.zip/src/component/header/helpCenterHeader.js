import {  StyleSheet, View ,Dimensions,Image, TouchableOpacity} from "react-native";

import { moderateScale, verticalScale } from "react-native-size-matters";
import { font, margin, WH } from "../../constant/contstant";
import Icon from "../../materialComponent/icon/icon";


import HelpSvg from "@assets/images/help.svg"
import CustomText from "@materialComponent/customText/customText";
import CustomerBlue from "@assets/images/CustomerBlue.svg"


const { width, height, fontScale } = Dimensions.get("screen")

const HelpCenterHeader =({navigation,borderLine,onBackPress,IconComponent,title, showBackIcon=true})=>{
    return(
        <View style={[styles.customerCare, {borderBottomWidth:borderLine}]}>
<View style={styles.header}> 
{showBackIcon && (
                    <TouchableOpacity onPress={onBackPress ? onBackPress : () => navigation.goBack()}>
                        <Icon
                            size={moderateScale(16)}
                            icon_type={"Ionicons"}
                            name={"arrow-back"}
                            color={"black"}
                        />
                    </TouchableOpacity>
                )}
              
         {/* <ChildLineCard  firstIcon= {HelpSvg} heading={"Help Center"}/> */}
     { IconComponent && <IconComponent width={width *0.05} height={height*0.05 } marginLeft={"5%"}/>}
         <CustomText text={title} style={styles.helpCenter} fontSize={fontScale* 16} fontFamily={font.bold}/>
         
</View>

        {/* <CustomerBlue width={width * 0.07} height={height*0.07 } /> */}
        {/* <Image source ={require("../../assets/images/customerCareImage.png")}/> */}
</View>
    )
}
export default HelpCenterHeader;

const styles = StyleSheet.create({
    header: {
     
        alignItems: 'center',
        flexDirection: "row",
        marginVertical:"2%"
      
    },
    helpCenter:{
        marginLeft:"6%"
    },
    customerCare:{
        paddingHorizontal: margin.horizontal,
        
        flexDirection:"row",
        alignItems:"center",
        justifyContent:"space-between",
        borderColor:"#b2b2b2"

    }
});