import { moderateScale, verticalScale } from 'react-native-size-matters';
import CustomText from '@materialComponent/customText/customText';
import Icon from '@materialComponent/icon/icon';
import { StyleSheet, View } from 'react-native';
import { font, WH } from '@constant/contstant';
import { margin } from '@constant/contstant';
import React from 'react';

const BackHeader = ({ title }) => {
    return (
        <View style={styles.header}>
            <Icon
                size={moderateScale(20)}
                icon_type={"Ionicons"}
                name={"arrow-back"}
                color={"black"}
            />
            <CustomText
                fontFamily={font.bold}
                text={title}
            />
        </View>
    );
};

export default BackHeader;

const styles = StyleSheet.create({
    header: {
        paddingHorizontal: margin.horizontal,
        paddingVertical: verticalScale(10),
        marginBottom: WH.height(1),
        alignItems: 'center',
        flexDirection: "row"
    },
});
