import React from 'react';
import {
  View,
  TouchableOpacity,
  StyleSheet,
  Dimensions,
  FlatList,
  ScrollView,
} from 'react-native';
import CustomText from '@materialComponent/customText/customText';
import { font } from '@constant/contstant';
import useProductDetailVariants from './useProductDetailVariants';
import { colors, globalStyle } from '../../constant/contstant';
import { verticalScale } from 'react-native-size-matters';
import BorderLine from '../borderLine/borderLine';
import CustomImage from '../../materialComponent/image/image';

const { width, height, fontScale } = Dimensions.get('screen');

const ITEM_WIDTH = width * 0.09

const ProductDetailVariants = ({ data: result, handleValue }) => {
  return result.length ? (
    <FlatList
      data={result}
      keyExtractor={(item, index) => index.toString()}
      renderItem={({ item }) => {
        const firstIndexValue = item?.selected_options?.[0]?.value
          ? item?.selected_options?.[0]?.value?.toLowerCase() == 'default title'
          : '';
        const findSelectedIndex = (item?.values || []).find(e => e.variant_id == item?.selectedValue)
        const isColor =
          findSelectedIndex?.name?.includes('Color') ||
          findSelectedIndex?.name?.includes('color') && findSelectedIndex?.image_url
        return (
          !firstIndexValue && (
            <>
              <View style={styles.container}>
                <View style={styles.rowContainer}>
                  <View style={[globalStyle.row, { marginBottom: height * 0.01, marginTop: -height * 0.004 }]}>
                    <CustomText
                      fontFamily={font.bold}
                      text={`${item.name}`}
                      style={styles.label}
                      fontSize={fontScale * 13}
                    />
                    {isColor ?
                      <CustomText
                        fontFamily={font.bold}
                        text={`- ${findSelectedIndex.value}`}
                        // style={styles.label}
                        fontSize={fontScale * 13}
                        color={"gray"}
                      /> : null
                    }

                  </View>
                  <ScrollView
                    horizontal
                    showsHorizontalScrollIndicator={false}
                    style={styles.scrollContainer}>
                    <View style={styles.valuesContainer}>
                      {item.values.map(value => {
                        const isColor =
                          item?.name?.includes('Color') ||
                          item?.name?.includes('color');

                        const isImage = value?.image_url && isColor
                        const selected = item.selectedValue === value.variant_id
                        return (
                          <TouchableOpacity
                            key={value.variant_id}
                            activeOpacity={1}
                            style={[
                              // value?.image_url && isColor ? styles.selectedSizeImage : styles.sizeButton,
                              // item.selectedValue === value.variant_id &&
                              //   value?.image_url && isColor ? styles.selectedImageButton : styles.selectedSizeButton,
                              // !value.available &&
                              // !isColor && value?.image_url &&
                              // styles.disabledSizeButton,
                              { marginRight: fontScale * 10, zIndex: 1 },
                              //  { borderWidth: 1, borderRadius: 180, borderColor: selected ? "black" : "#f4f4f4", },
                              { borderWidth: selected && !isImage ? 0 : 1, borderRadius: isImage ? 180 : 180, borderColor: selected ? "black" : "#e6e6e6", backgroundColor: !value.available ? "#cccccc" : isColor ? "white" : selected ? colors.light_theme.theme : "white" },
                              !value.available && { opacity: 0.5, borderWidth: 1, borderColor: "#e6e6e6" }
                            ]}
                            onPress={() =>
                              value.available && handleValue(item.name, value.variant_id)
                            }>
                            {value?.image_url && isColor ? (
                              <CustomImage style={[styles.item, { width: ITEM_WIDTH, aspectRatio: 1, }
                              ]} source={{ uri: value.image_url }} />
                            ) : (
                              <View
                                style={[
                                  styles.item,
                                  {
                                    paddingHorizontal: width * 0.04,
                                    borderRadius: 180,
                                    height: ITEM_WIDTH,
                                    overflow:"hidden"
                                  },
                                ]}
                              >
                                <CustomText
                                  text={value.value}
                                  style={
                                    !value.available
                                      ? styles.disabledSizeText
                                      : item.selectedValue === value.variant_id
                                        ? styles.selectedSizeText
                                        : styles.sizeText
                                  }
                                  fontSize={fontScale * 12}
                                  color={selected ? "white" : "black"}
                                />
                              </View>
                            )}

                            {/* {value.available &&
                              <View style={{ position: "absolute", justifyContent: "center", alignItems: "center", width: ITEM_WIDTH, aspectRatio: 1, zIndex: 2 }}>
                                <View style={{ width: width * 0.002, height: ITEM_WIDTH, backgroundColor: "#999999", transform: [{ rotate: '320deg' }], }} />
                              </View>} */}

                          </TouchableOpacity>
                        );
                      })}
                    </View>
                  </ScrollView>
                </View>
              </View>
              <BorderLine style={styles.borderLine} />
            </>
          )
        );
      }}
    />
  ) : (
    <></>
  );
};

const styles = StyleSheet.create({
  container: {
    // marginTop: height * 0.02,
    marginVertical: height * 0.015
  },
  rowContainer: {
    // flexDirection: 'row',
    // alignItems: 'center',
    // flexWrap: "wrap"
  },
  label: {
    fontSize: fontScale * 16,
    // marginRight: width * 0.02,
    minWidth: width * 0.1,
  },
  scrollContainer: {
    flexGrow: 0,
  },
  valuesContainer: {
    flexDirection: 'row',
    flexWrap: 'nowrap',
    alignItems: 'center',
    justifyContent: 'flex-start',
    // marginVertical: height * 0.02,
  },
  colorButton: {
    marginRight: width * 0.02,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 5,
    overflow: 'hidden',
  },
  selectedColorButton: {
    borderWidth: 50,
    // borderRadius: 180,
    justifyContent: 'center',
    alignItems: 'center',
    alignSelf: 'center',
    // padding: 2,
    borderColor: colors.light_theme.theme,
    borderRadius: 5,
    overflow: 'hidden',
  },
  colorCircle: {
    width: width * 0.07,
    aspectRatio: 1,
    // borderRadius: 180,
    justifyContent: 'center',
    alignItems: 'center',
  },
  selectedColorStroke: {
    // borderWidth: 2,
    borderColor: colors.light_theme.theme,
  },
  sizeButton: {
    borderWidth: 1,
    borderColor: '#e5e5e5',
    borderRadius: 5,
    // paddingVertical: height * 0.006,
    paddingHorizontal: width * 0.032,
    marginRight: fontScale * 10,
    backgroundColor: 'white',
  },
  selectedSizeButton: {
    backgroundColor: colors.light_theme.theme,
  },
  selectedImageButton: {
    borderWidth: 2,
    // padding:1,
    // paddingHorizontal:2
    borderRadius: 180
  },
  selectedSizeImage: {
    // backgroundColor: colors.light_theme.theme,
    borderRadius: 180,
    paddingHorizontal: 0,
    marginRight: fontScale * 10,
    // paddingVertical: height * 0.006,
    // paddingHorizontal: width * 0.032,
  },
  disabledSizeButton: {
    borderColor: '#ccc',
    // backgroundColor: '#F0F0F0',
  },
  sizeText: {
    fontSize: fontScale * 12,
    color: 'black',
    fontFamily: font.bold,
  },
  selectedSizeText: {
    fontSize: fontScale * 12,
    color: 'white',
    fontFamily: font.bold,
  },
  disabledSizeText: {
    fontSize: fontScale * 12,
    color: '#A9A9A9',
    fontFamily: font.bold,
  },
  borderLine: {
    marginLeft: 0,
    width: '100%',
    justifyContent: 'center',
    alignItems: 'center',
    height: verticalScale(1),
    // marginTop: height * 0.02,
  },
  item: {
    // width: ITEM_WIDTH,

    borderRadius: 180,
    justifyContent: "center",
    alignItems: "center"
  }
});

export default ProductDetailVariants;
