import React, { useState } from 'react';
import { View, TouchableOpacity, StyleSheet, Dimensions, Animated, FlatList } from 'react-native';
import CustomText from '@materialComponent/customText/customText';
import { colors, font } from '@constant/contstant';
import { verticalScale } from 'react-native-size-matters';
import BorderLine from '../borderLine/borderLine';

const { width, fontScale, height } = Dimensions.get('screen');

const ProductDetailSizes = ({ data }) => {
    const [selectedSize, setSelectedSize] = useState('S'); // Default selected size
    const [slideAnimation] = useState(new Animated.Value(0)); // For sliding animation

    const sizes = data.map((item) => ({
        label: item.variant_size,
        available: item.available,
        ...item
    }));

    const removeNullData = sizes.filter((item) => item.label !== null);

    const handleSizePress = (size) => {
        if (size.available) {
            Animated.sequence([
                Animated.timing(slideAnimation, {
                    toValue: 10,
                    duration: 150,
                    useNativeDriver: true,
                }),
                Animated.timing(slideAnimation, {
                    toValue: 0,
                    duration: 150,
                    useNativeDriver: true,
                }),
            ]).start();
            setSelectedSize(size.label);
        }
    };

    const renderSizeItem = ({ item, index }) => (
        <TouchableOpacity
            key={index}
            style={[
                styles.sizeButton,
                selectedSize === item.label && item.available && styles.selectedSizeButton,
                !item.available && styles.disabledSizeButton,
            ]}
            onPress={() => handleSizePress(item)}
            disabled={!item.available}
        >
            <Animated.View
                style={{
                    transform: [{ translateY: selectedSize === item.label ? slideAnimation : 0 }],
                }}
            >
                <CustomText
                    text={item.label}
                    style={
                        !item.available
                            ? styles.disabledSizeText
                            : selectedSize === item.label
                                ? styles.selectedSizeText
                                : styles.sizeText
                    }
                />
            </Animated.View>
        </TouchableOpacity>
    );

    return removeNullData.length ? (
        <>
            <View style={styles.container}>
                <View style={styles.sizesContainer}>
                    <CustomText fontFamily={font.bold} text="Sizes:" style={styles.label} />
                    <FlatList
                        horizontal
                        data={removeNullData}
                        keyExtractor={(item, index) => `${item.label}-${index}`} // Unique key
                        renderItem={renderSizeItem}
                        showsHorizontalScrollIndicator={false}
                    />
                </View>
            </View>
            <BorderLine style={styles.borderLine} />
        </>
    ) : null;
};

const styles = StyleSheet.create({
    container: {
        marginTop: height * 0.02,
    },
    headerRow: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    label: {
        fontSize: fontScale * 16,
        marginRight: width * 0.04,
    },
    sizesContainer: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    sizeButton: {
        borderWidth: 1,
        borderColor: '#cfcfcf',
        borderRadius: 5,
        paddingVertical: height * 0.002,
        paddingHorizontal: width * 0.032,
        marginRight: fontScale * 10,
        backgroundColor: 'white',
    },
    selectedSizeButton: {
        backgroundColor: colors.light_theme.theme,
    },
    disabledSizeButton: {
        borderColor: '#ccc',
        backgroundColor: '#F0F0F0',
    },
    sizeText: {
        fontSize: fontScale * 12,
        color: 'black',
        fontFamily: font.bold,
    },
    selectedSizeText: {
        fontSize: fontScale * 12,
        color: 'white',
        fontFamily: font.bold,
    },
    disabledSizeText: {
        fontSize: fontScale * 12,
        color: '#A9A9A9',
        fontFamily: font.bold,
    },
    borderLine: {
        marginLeft: 0,
        width: "100%",
        justifyContent: "center",
        alignItems: "center",
        height: verticalScale(1),
        marginTop: height * 0.02,
    },
});

export default ProductDetailSizes;
