import React, { useState } from 'react';
import { View, TouchableOpacity, StyleSheet, Dimensions } from 'react-native';
import CustomText from '@materialComponent/customText/customText';
import { font } from '@constant/contstant';

const { width, height, fontScale } = Dimensions.get('screen');

const ProductDetailColors = () => {
    const [selectedColor, setSelectedColor] = useState('blue'); // Default selected color

    const colors = [
        { label: 'blue', colorCode: '#0000FF' },
        { label: 'pink', colorCode: '#FFC0CB' },
        { label: 'green', colorCode: '#00FF00' },
        { label: 'purple', colorCode: '#800080' },
        { label: 'red', colorCode: '#FF0000' },
        { label: 'black', colorCode: '#000000' },
    ];

    const handleColorPress = (color) => {
        setSelectedColor(color.label);
    };

    return (
        <View style={styles.container}>
            <View style={styles.rowContainer}>
                <CustomText fontFamily={font.bold} text="Colors:" style={styles.label} />
                <View style={styles.colorsContainer}>
                    {colors.map((color) => (
                        <TouchableOpacity
                            key={color.label}
                            style={[
                                styles.colorButton,
                                selectedColor === color.label && styles.selectedColorButton,
                            ]}
                            onPress={() => handleColorPress(color)}
                        >
                            <View
                                style={[
                                    styles.colorCircle,
                                    { backgroundColor: color.colorCode },
                                    selectedColor === color.label && styles.selectedColorStroke,
                                ]}
                            />
                        </TouchableOpacity>
                    ))}
                </View>
            </View>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        marginTop: height * 0.02,
    },
    rowContainer: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    label: {
        fontSize: fontScale * 16,
        marginRight: width * 0.04,
    },
    colorsContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
    },
    colorButton: {
        marginRight: width * 0.02,
        justifyContent: 'center',
        alignItems: 'center',
    },
    selectedColorButton: {
        borderWidth: 1,
        borderRadius: 180,
        justifyContent: 'center',
        alignItems: 'center',
        alignSelf:"center",
        padding:2
    },
    colorCircle: {
        width: width * 0.05,
        aspectRatio: 1,
        borderRadius: 180,
        justifyContent: 'center',
        alignItems: 'center',
    },
    selectedColorStroke: {
        // borderColor: 'black',
        // borderWidth: 2,
    },
});

export default ProductDetailColors;
