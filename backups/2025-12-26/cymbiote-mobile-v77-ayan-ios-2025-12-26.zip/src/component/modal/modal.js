import { useNavigation } from '@react-navigation/native';
import React, { useState } from 'react';
import {
    Alert,
    Modal,
    StyleSheet,
    Text,
    Pressable,
    View,
    Image,
} from 'react-native';
import { scale, verticalScale, moderateScale } from 'react-native-size-matters';
import CustomButton from '@materialComponent/customButton/customButton';
import { colors, font, WH } from '@constant/contstant';
const CommonModal = (props) => {
    const navigation = useNavigation();

    return (
        <View style={styles.centeredView}>
            <Modal
                animationType="slide"
                // backdropColor={'transparent'}

                transparent={true}
                visible={props.visible}
                onRequestClose={props.onRequestClose}
            >
                <View style={styles.overlay}>
                    <View style={styles.centeredView}>
                        <View style={[styles.modalView, { width: '85%' }]}>
                            <View style={styles.imageView}>
                                {/* {props?.editSvg ?
                                        <EditIcon /> :
                                        <Image style={styles.imageView2} source={images.success} />
                                    } */}
                            </View>
                            {props.modalText ?
                                <Text style={[styles.modalText, props.modalText]}>{props.modalText}</Text>
                                : <></>
                            }
                            <Text style={[styles.subtitle, props.subTitleStyle]}>{props.subtitle}</Text>
                            {props.twoButton ?

                                <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: "space-between", width: "85%" }}>
                                    <View style={{ width: '47%' }}>
                                        <CustomButton
                                            onPress={props.onPressCancel}
                                            outline={'true'}
                                            text={props.buttonTextCancel}
                                            fontSize={moderateScale(12)}
                                            height={WH.height(5)}
                                            buttonStyle={{ backgroundColor: 'gray', borderRadius: 5 }}
                                        />
                                    </View>
                                    <View style={{ width: '47%' }}>
                                        <CustomButton
                                            onPress={props.onPressOk}
                                            text={props.buttonText}
                                            fontSize={moderateScale(12)}
                                            height={WH.height(5)}
                                            buttonStyle={{ borderRadius: 5 }}
                                        />
                                    </View>
                                </View> :
                                <View style={{ width: '85%' }}>

                                    <CustomButton
                                        onPress={props.onPressOk}
                                        text={props.buttonText}
                                        buttonStyle={{ paddingVertical: verticalScale(8) }}
                                    />

                                </View>
                            }

                        </View>
                    </View>
                </View>
            </Modal>
        </View>
    );
};

const styles = StyleSheet.create({
    centeredView: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        // backgroundColor: 'rgba(0,0,0,0.70)',

    },
    modalView: {
        backgroundColor: 'white',
        borderRadius: moderateScale(10),
        paddingVertical: verticalScale(20),
        justifyContent: 'center',
        // height: '50%',
        width: '80%',
        alignItems: 'center',
        shadowColor: '#000',
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 4,
        elevation: 5,
    },
    button: {
        borderRadius: moderateScale(20),
        paddingHorizontal: scale(10),
        paddingVertical: verticalScale(10),
        elevation: 2,
    },
    buttonOpen: {
        backgroundColor: '#F194FF',
    },
    buttonClose: {
        backgroundColor: '#2196F3',
    },
    textStyle: {
        color: 'white',
        fontWeight: 'bold',
        textAlign: 'center',
    },
    modalText: {
        textAlign: 'center',
        color: "black",
        fontSize: moderateScale(18),
        // fontFamily:PoppinsSemiBold,
        fontFamily: font.bold,
        paddingHorizontal: scale(10),
        width: '85%'
        // marginBottom:verticalScale(-5)
        // marginBottom: verticalScale(10)
    },
    imageView: {
        // marginBottom: verticalScale(20),
        marginBottom: verticalScale(10)
        // width: '30%',
        // borderRadius:100,
        // height: '40%',
    },
    imageView2: {
        // width: '100%',
        // height: '100%',
        // borderRadius: 200,
        resizeMode: 'contain',
        height: moderateScale(90),
        width: moderateScale(90)
    },

    subtitle: {
        color: colors.light_theme.theme,
        fontFamily: font.regular,
        fontSize: moderateScale(14),
        marginVertical: verticalScale(15),
        textAlign: 'center',
        width: '85%'

    },








    overlay: {
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundColor: 'rgba(0, 0, 0, 0.6)', // Dark and dull background
    },

});

export default CommonModal;