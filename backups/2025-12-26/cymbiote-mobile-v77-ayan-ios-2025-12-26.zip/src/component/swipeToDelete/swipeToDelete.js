import React from 'react';
import {View, StyleSheet, TouchableOpacity, Dimensions} from 'react-native';
import {PanGestureHandler} from 'react-native-gesture-handler';
import Animated, {
  useAnimatedGestureHandler,
  useAnimatedStyle,
  useSharedValue,
  withTiming,
  runOnJS,
  interpolate,
  Extrapolate,
} from 'react-native-reanimated';
import DeleteCart from '@assets/images/cart_delete.svg';
import {colors} from '../../constant/contstant';

const {width} = Dimensions.get('window');

const SwipeToDelete = ({children, onDelete}) => {
  const translateX = useSharedValue(0);
  const AnimatedTouchable = Animated.createAnimatedComponent(TouchableOpacity);

  const SWIPE_THRESHOLD = width * 0.2;
  const MAX_SWIPE = width * 0.3;

  const panGesture = useAnimatedGestureHandler({
    onStart: (_, ctx) => {
      ctx.startX = translateX.value;
    },
    onActive: (event, ctx) => {
      // --- Only allow left swipe ---
      const isHorizontal =
        Math.abs(event.translationX) > Math.abs(event.translationY);

      if (isHorizontal && event.translationX + ctx.startX <= 0) {
        translateX.value = event.translationX + ctx.startX;
      }
    },
    onEnd: () => {
      if (-translateX.value > SWIPE_THRESHOLD) {
        translateX.value = withTiming(-MAX_SWIPE);
      } else {
        translateX.value = withTiming(0);
      }
    },
  });

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{translateX: translateX.value}],
  }));

  const deleteButtonStyle = useAnimatedStyle(() => ({
    opacity: interpolate(
      -translateX.value,
      [0, SWIPE_THRESHOLD * 0.5, SWIPE_THRESHOLD],
      [0, 0.5, 1],
      Extrapolate.CLAMP,
    ),
    transform: [
      {
        scale: interpolate(
          -translateX.value,
          [0, SWIPE_THRESHOLD],
          [0.8, 1.2],
          Extrapolate.CLAMP,
        ),
      },
    ],
  }));

  const handleDelete = () => {
    translateX.value = withTiming(-width, {}, () => {
      runOnJS(onDelete)();
    });
  };

  return (
    <View style={styles.swipeContainer}>
      {/* Delete Background (visible on swipe) */}
      <Animated.View style={[styles.deleteBackground, deleteButtonStyle]}>
        <AnimatedTouchable style={styles.deleteButton} onPress={handleDelete}>
          <DeleteCart width={width * 0.08} height={width * 0.08} />
        </AnimatedTouchable>
      </Animated.View>

      {/* Swipeable Content */}
      <PanGestureHandler
        activeOffsetX={[-20, 20]} // only trigger after horizontal move > 20px
        activeOffsetY={[-40, 40]}
        onGestureEvent={panGesture}>
        <Animated.View style={animatedStyle}>{children}</Animated.View>
      </PanGestureHandler>
    </View>
  );
};

const styles = StyleSheet.create({
  swipeContainer: {
    overflow: 'hidden',
    marginVertical: 4,
  },
  deleteBackground: {
    position: 'absolute',
    right: 0,
    top: 0,
    bottom: 0,
    width: '30%',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: colors.light_theme.theme,
  },
  deleteButton: {
    alignSelf: 'center',
    marginRight: width * 0.02,
  },
});

export default SwipeToDelete;
