import React, {forwardRef, useState} from 'react';
import {View, TouchableOpacity, StyleSheet} from 'react-native';
import DatePickerComponent from 'react-native-date-picker';
import {moderateScale, verticalScale} from 'react-native-size-matters';
import CustomText from '@materialComponent/customText/customText';
import {colors, font, WH} from '@constant/contstant';
import Icon from '@materialComponent/icon/icon';

const DatePicker = forwardRef(
  (
    {
      placeholder = 'Select date',
      errorMessage = null,
      backgroundColor,
      marginTop = 0,
      editable = false,
      onChange,
      value,
      hide,
      mode = 'date', // can be 'date', 'time', or 'datetime'
      label,
    },
    ref,
  ) => {
    const [open, setOpen] = useState(false);

    if (hide) return null;

    return (
      <View style={{marginTop}}>
        {/* Optional label */}
        {label && (
          <CustomText
            text={label}
            fontSize={moderateScale(14)}
            color={colors.light_theme.gray}
            fontFamily={font.bold}
            marginBottom={verticalScale(5)}
          />
        )}

        {/* Touchable container mimicking TextInput */}
        <View style={[styles.container, backgroundColor && {backgroundColor}]}>
          <TouchableOpacity
            onPress={() => !editable && setOpen(true)}
            style={[
              styles.input,
              editable && {
                backgroundColor: colors.light_theme.darkBorderColor,
                color: colors.light_theme.gray,
              },
              errorMessage && styles.errorBorder,
            ]}>
            <CustomText
              text={value ? new Date(value).toLocaleDateString() : placeholder}
              color={value ? colors.light_theme.text : colors.light_theme.gray}
              fontSize={moderateScale(14)}
              fontFamily={font.medium}
            />
          </TouchableOpacity>

          {/* Calendar icon */}
          <TouchableOpacity
            onPress={() => !editable && setOpen(true)}
            style={styles.iconContainer}>
            <Icon
              icon_type="Feather"
              name="calendar"
              size={moderateScale(17)}
              color="#ACB5BB"
            />
          </TouchableOpacity>
        </View>

        {/* Error message */}
        {errorMessage && (
          <CustomText
            marginTop={verticalScale(5)}
            fontSize={moderateScale(12)}
            text={`* ${errorMessage}`}
            color="red"
          />
        )}

        {/* Date Picker */}
        <DatePickerComponent
          modal
          open={open}
          date={value ? new Date(value) : new Date()}
          mode={mode}
          onConfirm={selectedDate => {
            setOpen(false);
            onChange && onChange(selectedDate);
          }}
          onCancel={() => setOpen(false)}
        />
      </View>
    );
  },
);

export default DatePicker;

const styles = StyleSheet.create({
  container: {
    width: '100%',
    backgroundColor: 'white',
    overflow: 'hidden',
    borderRadius: moderateScale(10),
    height: WH.height(6.5),
    justifyContent: 'center',
  },
  input: {
    fontSize: moderateScale(14),
    padding: moderateScale(10),
    paddingHorizontal: moderateScale(15),
    borderColor: colors.light_theme.gray,
    fontFamily: font.medium,
  },
  errorBorder: {
    borderColor: colors.light_theme.red,
  },
  iconContainer: {
    position: 'absolute',
    right: 15,
  },
});
