import {View, StyleSheet, Dimensions} from 'react-native';
import React from 'react';

// Importing SVG Images
import Order from '@assets/images/ordersEmpty.svg';
import Reviews from '@assets/images/reviewsEmpty.svg';
import Points from '@assets/images/cash_back_history.svg';
import Messages from '@assets/images/messagesEmpty.svg';
import Following from '@assets/images/folllowingEmpty.svg';
import Favorite from '@assets/images/favoritesEmpty.svg';
import NoInternet from '@assets/images/no_internet.svg';
import ServerError from '@assets/images/server_error.svg';
import Cart from '@assets/images/cartEmpty.svg';
import ReelEmpty from '@assets/images/videoIcon.svg';
import Address from '@assets/images/addressEmpty.svg';
import Voucher from '@assets/images/voucher_empty.svg';
import NotificationEmpty from '@assets/images/notification_empty.svg';
import SearchEmpty from '@assets/images/searchEmpty.svg';
import CustomText from '../../materialComponent/customText/customText';
import {font} from '../../constant/contstant';
import {heightPercentageToDP} from 'react-native-responsive-screen';
import CustomButton from '../../materialComponent/customButton/customButton';
import { moderateScale } from 'react-native-size-matters';

const {width, fontScale} = Dimensions.get('screen');

const imageMap = {
  empty_order: Order,
  empty_reviews: Reviews,
  empty_points: Points,
  empty_messages: Messages,
  empty_following: Following,
  empty_favorite: Favorite,
  empty_cart: Cart,
  empty_address: Address,
  empty_voucher: Voucher,
  empty_search: SearchEmpty,
  empty_notification: NotificationEmpty,
  empty_reels: ReelEmpty,
};

const EmptyScreen = ({
  image,
  heading,
  desc,
  imageSize,
  headingSize,
  descSize,
  removeImage,
  fullWidth,
  reload,
  message,
  loader,
}) => {
  const checkAPIStatus = () => {
    if (message === 'Network request failed') {
      return {
        heading: 'No Internet',
        description: 'Internet is not available. Please check your connection.',
        image: NoInternet,
        reload: true,
      };
    } else if (message === 'Internal server error.') {
      return {
        heading: 'Technical Issue',
        description:
          'There seems to be a problem on our side. Please try again later.',
        image: ServerError,
        reload: true,
      };
    } else {
      return {
        heading: heading || 'Something went wrong',
        description: desc || 'Please try again later.',
      };
    }
  };

  const SelectedImage = checkAPIStatus().image || imageMap[image] || Cart;
  // const

  return (
    <View style={[styles.mainView, fullWidth && {width: '100%'}]}>
      {removeImage ? (
        <></>
      ) : (
        <SelectedImage
          width={imageSize || width * 0.3}
          height={imageSize || width * 0.25}
        />
      )}

      <CustomText
        text={checkAPIStatus().heading}
        marginTop={heightPercentageToDP(0.5)}
        center={'center'}
        fontFamily={font.bold}
        fontSize={headingSize || fontScale * 20}
      />
      <CustomText
        color={'#4d4d4d'}
        text={checkAPIStatus().description}
        marginTop={heightPercentageToDP(0.7)}
        center={'center'}
        fontFamily={font.regular}
        fontSize={descSize || fontScale * 14}
      />
      {checkAPIStatus().reload ? (
        <View style={{width: '50%', marginTop: heightPercentageToDP(1)}}>
          <CustomButton
            onPress={reload}
            loader={loader}
            loaderSize={moderateScale(8)}
            backgroundColor={'black'}
            forceHeight={heightPercentageToDP(4)}
            fontSize={fontScale * 14}
            text={'Tap to reload'}
          />
        </View>
      ) : (
        <></>
      )}
    </View>
  );
};

export default EmptyScreen;

const styles = StyleSheet.create({
  mainView: {
    width: '80%',
    justifyContent: 'center',
    alignItems: 'center',
  },
});
