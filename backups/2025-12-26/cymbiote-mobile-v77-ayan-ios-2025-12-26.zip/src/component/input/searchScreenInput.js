import React, {useState, useEffect, useRef} from 'react';
import {
  Animated,
  Dimensions,
  Keyboard,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import Icon from '@materialComponent/icon/icon';
import {colors, font, globalStyle, margin, WH} from '@constant/contstant';
import {moderateScale, verticalScale} from 'react-native-size-matters';
import CustomText from '@materialComponent/customText/customText';
import BottomSheetForLibrary from '../../materialComponent/bottomSheet/cameraSheet';
import CustomImage from '../../materialComponent/image/image';
import {goBack} from '../../utils/navigationRef/navigationRef';
import SearchLens from '@assets/images/search_lens.svg';

const {height, width} = Dimensions.get('screen');

const SearchScreenInput = ({
  onChangeText,
  value,
  onBlur,
  setIsCameraOpen,
  isCameraOpen,
  searchedImage,
}) => {
  const [isKeyboardVisible, setIsKeyboardVisible] = useState(false); // State to track keyboard visibility.
  const refRBSheet = useRef(); // Reference for the bottom sheet.
  // const animatedWidth = useRef(new Animated.Value(WH.width(95))).current; // Initial width is 70% of screen width.

  useEffect(() => {
    const keyboardDidShowListener = Keyboard.addListener(
      'keyboardDidShow',
      () => {
        setIsKeyboardVisible(true); // Show "Cancel" button.
        refRBSheet?.current?.close();
        // animateWidth(WH.width(70)); // Expand input width to 85%.
      },
    );

    const keyboardDidHideListener = Keyboard.addListener(
      'keyboardDidHide',
      () => {
        setIsKeyboardVisible(false); // Hide "Cancel" button.
        // animateWidth(WH.width(90)); // Collapse input width back to 70%.
      },
    );

    return () => {
      keyboardDidShowListener.remove();
      keyboardDidHideListener.remove();
    };
  }, [isKeyboardVisible]);

  // const animateWidth = toValue => {
  //   Animated.timing(animatedWidth, {
  //     toValue, // Target width value.
  //     duration: 300, // Animation duration in milliseconds.
  //     useNativeDriver: false, // Must be false for non-transform properties.
  //   }).start();
  // };

  const dismissKeyboard = () => {
    Keyboard.dismiss(); // Close the keyboard.
  };

  const handleSearchBlur = image => {
    Keyboard.dismiss();
    if (onBlur && typeof onBlur == 'function' && (value || image)) {
      onBlur(image?.uri ? image : false);
      refRBSheet?.current?.close();
    }
  };

  const handleOpenCamera = () => {
    Keyboard.dismiss();
    refRBSheet?.current?.open();
    setIsCameraOpen(true);
  };

  const getImages = image => {
    handleSearchBlur(image);
    refRBSheet?.current?.close();
  };

  return (
    <View style={styles.searchContainer}>
      <View
        style={[
          styles.inputContainer,
          {
            width: isKeyboardVisible ? '85%' : 'auto',
            marginRight: isKeyboardVisible ? '5%' : 0,
          },
        ]}>
        <Icon
          icon_type={'FontAwesome'}
          name={'search'}
          color={colors.light_theme.gray}
          size={moderateScale(16)}
        />
        <TextInput
          style={styles.searchbar}
          placeholder={'Search...'}
          placeholderTextColor={colors.light_theme.gray}
          onChangeText={onChangeText}
          value={value}
          textAlignVertical="center"
          keyboardType="web-search"
          onSubmitEditing={handleSearchBlur}
          // onBlur={handleSearchBlur} // Optionally handle blur event
          // Trigger function on click
        />
        {value ? (
          <TouchableOpacity
            style={{position: 'absolute', right: margin.horizontal - 10}}
            onPress={() => onChangeText('')}>
            <Icon
              icon_type={'AntDesign'}
              name={'closecircle'}
              color={'black'}
              size={moderateScale(20)}
            />
          </TouchableOpacity>
        ) : searchedImage?.uri && !isKeyboardVisible ? (
          <View
            style={{
              // marginTop: height * 0.02,
              position: 'absolute',
              right: 5,
              flexDirection: 'row',
              alignItems: 'center',
              backgroundColor: 'white',
              // paddingHorizontal: 10,
              borderRadius: 180,
              justifyContent: 'space-between',
              overflow: 'hidden',
            }}>
            <CustomImage
              source={{uri: searchedImage?.uri}}
              style={styles.searchedImage}
            />
            <TouchableOpacity
              style={{marginHorizontal: 6}}
              onPress={() => goBack()}>
              <Icon
                icon_type={'Ionicons'}
                name={'close-outline'}
                color={'black'}
                size={moderateScale(15)}
              />
            </TouchableOpacity>
          </View>
        ) : (
          <TouchableOpacity
            style={{position: 'absolute', right: margin.horizontal - 5}}
            onPress={handleOpenCamera}>
            {/* <Icon
              icon_type={'MaterialCommunityIcons'}
              name={'google-lens'}
              color={colors.light_theme.gray}
              size={moderateScale(20)}
            /> */}
            <SearchLens width={moderateScale(20)} height={moderateScale(20)} />
          </TouchableOpacity>
        )}
      </View>

      {/* Cancel Text */}
      {isKeyboardVisible && ( // Only render "Cancel" when the keyboard is visible.
        <TouchableOpacity
          onPress={() => {
            setIsKeyboardVisible(false);
            dismissKeyboard();
          }}
          style={styles.cancelText}>
          <CustomText
            fontSize={moderateScale(16)}
            fontFamily={font.medium}
            text={'Cancel'}
          />
        </TouchableOpacity>
      )}
      <BottomSheetForLibrary setImages={getImages} refRBSheet={refRBSheet} />
    </View>
  );
};

export default SearchScreenInput;

const styles = StyleSheet.create({
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between', // Ensure proper spacing.
    marginHorizontal: margin.horizontal,
    marginVertical: verticalScale(10),
  },
  inputContainer: {
    borderRadius: 180,
    ...globalStyle.row,
    height: WH.height(5),
    paddingHorizontal: margin.horizontal,
    backgroundColor: 'rgba(201, 210, 239 , 0.4)',
    // width: '80%',
  },
  searchbar: {
    fontFamily: font.medium,
    width: '100%',
    height: '100%',
    marginLeft: moderateScale(10),
    paddingRight: moderateScale(15),
    color: 'black',
  },
  cancelText: {
    fontFamily: font.medium,
    fontSize: moderateScale(16),
    color: colors.primary,
  },
  searchedImage: {
    width: width * 0.12,
    // aspectRatio: 1,
    borderRadius: 10,
    borderTopRightRadius: 0,
    borderBottomRightRadius: 0,
    height: WH.height(3.9),
    // width :
  },
});
