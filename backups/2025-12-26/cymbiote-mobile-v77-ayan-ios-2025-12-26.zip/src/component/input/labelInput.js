import { moderateScale, verticalScale } from 'react-native-size-matters';
import { View, StyleSheet, TouchableOpacity, TextInput as RNTextInput, Text, Dimensions } from 'react-native';
import { colors, font } from '@constant/contstant';
import React, { forwardRef, useState } from 'react';
import { WH } from '@constant/contstant';
import Icon from '@materialComponent/icon/icon';
import CustomText from '../../materialComponent/customText/customText';

const { fontScale } = Dimensions.get("screen");

const AuthInput = forwardRef(({
    keyboardType = 'default',
    secureTextEntry = false,
    returnKeyType = 'done',
    errorMessage = null,
    onSubmitEditing,
    marginTop = 0,
    onChangeText,
    placeholder,
    editable,
    onBlur,
    label,
    value,
    hide,
    placeholderTextColor
}, ref) => {
    // State to toggle password visibility
    const [isSecure, setIsSecure] = useState(secureTextEntry);
    const [isFocused, setIsFocused] = useState(false);

    const togglePasswordVisibility = () => {
        setIsSecure(!isSecure);
    };

    // Handle focus and blur events
    const handleFocus = () => {
        setIsFocused(true);
    };

    const handleBlur = () => {
        setIsFocused(false);
        if (onBlur) onBlur();
    };

    return hide ? null : (
        <View style={{ marginTop }}>
            <View style={[styles.container]}>
                {/* Custom TextInput */}
                <View style={[styles.inputContainer, errorMessage && styles.errorBorder]}>
                    {label && (
                        <CustomText
                            color={"#757575"}
                            text={label}
                            fontSize={(isFocused || value) ? fontScale * 11 : moderateScale(14)}
                            style={[styles.label, (isFocused || value) && { top: 2 }]}
                        />
                    )}
                    <RNTextInput
                        ref={ref}
                        style={[styles.input, editable && { backgroundColor: colors.light_theme.darkBorderColor, color: colors.light_theme.gray }]}
                        placeholderTextColor={placeholderTextColor}
                        secureTextEntry={isSecure} // Controlled by isSecure state
                        onSubmitEditing={onSubmitEditing}
                        returnKeyType={returnKeyType}
                        keyboardType={keyboardType}
                        onBlur={handleBlur}  // Handle blur event
                        onFocus={handleFocus} // Handle focus event
                        // placeholder={placeholder}
                        onChangeText={onChangeText}
                        editable={editable}
                        // onBlur={onBlur}
                        value={value}
                        allowFontScaling={true}
                       
                    />
                </View>

                {/* Password visibility toggle for secureTextEntry */}
                {secureTextEntry && (
                    <TouchableOpacity onPress={togglePasswordVisibility} style={styles.iconContainer}>
                        <Icon
                            icon_type="Feather"
                            name={isSecure ? "eye-off" : "eye"} // Toggle icon based on state
                            size={moderateScale(17)}
                            color="#ACB5BB"
                        />
                    </TouchableOpacity>
                )}
            </View>

            {/* Display error message if present */}
            {errorMessage && (
                <Text style={styles.errorText}>* {errorMessage}</Text>
            )}
        </View>
    );
});

export default AuthInput;

const styles = StyleSheet.create({
    container: {
        width: '100%',
        backgroundColor: "white",
        overflow: "hidden",
        borderRadius: moderateScale(10),
        justifyContent: "center",
        height: WH.height(6.5),
        borderWidth: 1,
        borderColor: "#9e9e9e",
        // backgroundColor: "#f3f8fe",

    },
    label: {
        marginBottom: moderateScale(5),
        fontSize: moderateScale(14),
        color: "black",
        fontFamily: font.regular,
        position: "absolute",
        left: moderateScale(15),

        fontSize: moderateScale(14),
    },
    inputContainer: {
        width: '100%',
        borderRadius: moderateScale(10),
        justifyContent: 'center',
        paddingHorizontal: moderateScale(11),
    },
    input: {
        // fontSize: fontScale * 15,
        fontFamily: font.medium,
        height: WH.height(6.5),  // Set the height here
        // paddingVertical: moderateScale(10),  // Added padding to the input
        color: "black",
        marginBottom: WH.height(-2),
        fontSize: moderateScale(14),
    },
    errorBorder: {
        borderColor: colors.light_theme.red,
        borderWidth: 1,
    },
    errorText: {
        fontSize: moderateScale(12),
        marginTop: moderateScale(5),
        color: colors.light_theme.red,
    },
    iconContainer: {
        position: "absolute",
        right: 15,
        top: WH.height(2),
    },
});
