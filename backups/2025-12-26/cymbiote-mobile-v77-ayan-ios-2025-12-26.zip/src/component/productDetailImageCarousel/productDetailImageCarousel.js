import React, { useState, useEffect, useRef } from 'react';
import { View, StyleSheet, Dimensions, Text } from 'react-native';
import { moderateScale } from 'react-native-size-matters';
import CustomImage from '@materialComponent/image/image';
import Overlay from '@materialComponent/overlay/overlay';
import BrandTab from '@component/brandTab/brandTab';
import Carousel from 'react-native-snap-carousel';

const { width } = Dimensions.get('window');

const ProductDetailImageCarousel = ({
    customWidth,
    brand,
    customHeight,
    style,
    imageRadius,
    dotStyle,
    stylePagination,
    activeIndex,
    onPress,
}) => {
    const imageWidth = customWidth || width * 0.8;
    const height = customHeight || imageWidth * 0.7;

    const [active, setActive] = useState(0);
    const carouselRef = useRef(null);

    const images = [
        "https://cdn.shopify.com/s/files/1/0913/0354/3081/files/images_1.jpg?v=1736235380",
        "https://cdn.shopify.com/s/files/1/0913/0354/3081/files/images_1.jpg?v=1736235380",
        "https://cdn.shopify.com/s/files/1/0913/0354/3081/files/images_1.jpg?v=1736235380",
        "https://cdn.shopify.com/s/files/1/0913/0354/3081/files/images_1.jpg?v=1736235380"
    ];

    const renderItem = ({ item, index }) => {
        return (
            <View style={styles.imageContainer}>
                <CustomImage
                    source={{ uri: item }}
                    style={[styles.image, { width: width * 0.7, height, borderRadius: imageRadius || 20, }]}
                >
                    <Overlay />
                </CustomImage>
            </View>
        );
    };

    const onScrollChange = (index) => {
        setActive(index);
        if (onPress) {
            onPress(index);
        }
    };

    useEffect(() => {
        if (carouselRef.current && activeIndex !== undefined) {
            carouselRef.current.snapToItem(activeIndex);
        }
    }, [activeIndex]);

    return (
        <View style={[styles.container, style]}>
            {brand ? (
                <View style={{ width: width * 0.90 }}>
                    <BrandTab mainViewStyle={{ paddingHorizontal: 0 }} dot={true} item={brand} />
                </View>
            ) : null}

            <Carousel
                ref={carouselRef}
                data={images}
                renderItem={renderItem}
                sliderWidth={width}
                itemWidth={imageWidth} // Slightly smaller than the screen width to show part of the next image
                onSnapToItem={onScrollChange}
                activeSlideAlignment="start" // Align active item to the left
                containerCustomStyle={styles.carouselContainer}
                loop
                loopClonesPerSide={3} // Ensure there are images to show on the sides
                autoplay={false}
                activeAnimationType="spring"
                activeAnimationOptions={{
                    friction: 4,
                    tension: 40,
                }}
                useScrollView={true}
                contentContainerCustomStyle={styles.contentContainer} // Adjust the style to allow side visibility of the next image
            />

            {images.length > 1 && (
                <View style={[styles.pagination, stylePagination]}>
                    {images.map((_, k) => (
                        <View
                            key={k}
                            style={[
                                styles.dot,
                                k === active && styles.activeDot,
                                dotStyle,
                            ]}
                        />
                    ))}
                </View>
            )}
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        alignItems: 'center',
        marginVertical: 20,
    },
    imageContainer: {
        alignItems: 'center',
        justifyContent:"center"
        // paddingHorizontal: 10, // Padding to allow some side visibility of the next image
    },
    image: {
        resizeMode: 'cover',
    },
    carouselContainer: {
        // alignItems: 'center',
    },
    contentContainer: {
        paddingLeft: 20, // Adds spacing on the left to show the next image partially
    },
    pagination: {
        position: 'absolute',
        flexDirection: 'row',
        alignSelf: 'center',
        bottom: 10,
    },
    dot: {
        backgroundColor: "#0000004D",
        marginHorizontal: 2,
        borderRadius: 180,
        width: moderateScale(7),
        aspectRatio: 1,
    },
    activeDot: {
        backgroundColor: "black",
        width: moderateScale(7),
        aspectRatio: 1,
    },
});

export default ProductDetailImageCarousel;
