// import * as React from 'react';
// import {useWindowDimensions, View} from 'react-native';
// import useReduxStore from '../../utils/hooks/useReduxStore';
// import SearchedItemsLoader from '../loader/searchedItemsLoader';
// import {margin} from '../../constant/contstant';

// export default function useTabView({
//   shop,
//   loader,
//   data,
//   paginationLoader,
//   category = [],
//   handleSelectCollection,
//   BrandContentProductsMemo,
//   selectedCollectionId,
// }) {
//   const layout = useWindowDimensions();
//   const {getState} = useReduxStore();
//   const {fetch_store_product_detail_loader} = getState('merchant');

//   // Build routes (memoized)
//   const routes = React.useMemo(() => {
//     return Array.isArray(category) && category.length > 0
//       ? category.map((item, idx) => ({
//           key: `screen_${idx}`,
//           title: item?.filter_option_value || `Tab ${idx + 1}`,
//         }))
//       : [{key: 'screen_0', title: 'All'}];
//   }, [category]);

//   // Index with bounds guard
//   const [index, setIndex] = React.useState(0);
//   const [customHeight, setCustomHeight] = React.useState(0);
//   React.useEffect(() => {
//     if (index >= routes.length) setIndex(0);
//   }, [routes.length, index]);

//   const memoData = React.useMemo(() => {
//     // only change reference when content changes
//     return data;
//     // Or if `data` is rebuilt, guard by ids:
//   }, [
//     data?.length,
//     data?.[0]?.product_id,
//     data?.[data.length - 1]?.product_id,
//     paginationLoader,
//   ]);

//   const findActiveTabTitle = category?.[index];

//   const renderScene = React.useCallback(
//     ({route}) =>
//       route.title == findActiveTabTitle?.filter_option_value && (
//         <>
//           <BrandContentProductsMemo
//             shop={shop}
//             loader={loader}
//             data={data}
//             paginationLoader={paginationLoader}
//             selectedCategory={
//               route.title == findActiveTabTitle?.filter_option_value
//             }
//             selectedCollectionId={selectedCollectionId}
//             selectedCategoryName={findActiveTabTitle?.filter_option_value}
//             onHeightChange={height => setCustomHeight(height)}
//           />
//         </>
//       ),
//     // : (
//     //   <View style={{marginHorizontal: margin.horizontal}}>
//     //     <SearchedItemsLoader />
//     //   </View>
//     // )
//     [data],
//   );

//   // Active tab object

//   // 🚫 Prevent loops: only call when id actually changes and category is ready
//   const lastFilterIdRef = React.useRef(null);

//   React.useEffect(() => {
//     if (!Array.isArray(category) || category.length === 0) return;

//     const currentId = category[index]?.filter_option_id;
//     if (!currentId) return;

//     if (lastFilterIdRef.current !== currentId) {
//       lastFilterIdRef.current = currentId;
//       // This can trigger parent state updates; but we call it ONLY when id changes.
//       handleSelectCollection?.(currentId, false);
//     }
//   }, [index, category, handleSelectCollection]);

//   // When category list changes, ensure ref doesn’t hold stale id
//   React.useEffect(() => {
//     lastFilterIdRef.current = null;
//   }, [routes.length]);

//   return {
//     renderScene,
//     setIndex,
//     layout,
//     routes,
//     index,
//     findActiveTabTitle,
//     fetch_store_product_detail_loader,
//     customHeight,
//   };
// }
