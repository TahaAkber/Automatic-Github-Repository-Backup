import {useState, useRef} from 'react';
import {Dimensions} from 'react-native';
import {
  useSharedValue,
  useAnimatedScrollHandler,
  interpolate,
} from 'react-native-reanimated';

const {width} = Dimensions.get('window');

export function useAnimatedTabs(tabs) {
  const [selectedTab, setSelectedTab] = useState(0);
  const [tabWidths, setTabWidths] = useState([]);
  const scrollViewRef = useRef(null);
  const flatListRef = useRef(null);
  const scrollX = useSharedValue(0);

  // Center active tab in scrollview
  const centerActiveTab = index => {
    if (!scrollViewRef.current || !tabWidths[index]) return;

    const screenCenter = width / 2;
    const scrollTo =
      tabWidths.slice(0, index).reduce((a, b) => a + b, 0) +
      tabWidths[index] / 2 -
      screenCenter;

    scrollViewRef.current.scrollTo({
      x: Math.max(0, scrollTo),
      animated: true,
    });
  };

  // On tab press
  const handleTabPress = index => {
    setSelectedTab(index);
    flatListRef.current?.scrollToIndex({index, animated: true});
    centerActiveTab(index);
  };

  // On horizontal scroll
  const onScroll = useAnimatedScrollHandler({
    onScroll: event => {
      scrollX.value = event.contentOffset.x;
    },
    onMomentumEnd: event => {
      const index = Math.round(event.contentOffset.x / width);
      setSelectedTab(index);
      centerActiveTab(index);
    },
  });

  // Underline calculation
  const getUnderlineStyle = () => {
    if (!tabWidths || tabWidths.length !== tabs.length) {
      return {translateX: 0, width: 0};
    }
    const translateX = interpolate(
      scrollX.value,
      tabs.map((_, i) => i * width),
      tabs.map((_, i) => tabWidths.slice(0, i).reduce((a, b) => a + b, 0)),
    );
    const w = interpolate(
      scrollX.value,
      tabs.map((_, i) => i * width),
      tabs.map((_, i) => tabWidths[i] || 0),
    );
    return {translateX, width: w};
  };

  return {
    selectedTab,
    setSelectedTab,
    tabWidths,
    setTabWidths,
    scrollViewRef,
    flatListRef,
    handleTabPress,
    onScroll,
    getUnderlineStyle,
    width,
  };
}
