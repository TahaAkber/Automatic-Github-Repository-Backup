import React, {useCallback, useEffect, useRef, useState} from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  ScrollView,
  Dimensions,
  ActivityIndicator,
} from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedScrollHandler,
  useAnimatedStyle,
  interpolate,
  runOnJS,
} from 'react-native-reanimated';
import {colors, font, margin, WH} from '../../constant/contstant';
import HomeDualCard from '../cards/homeDualCard';
import ShopTileCategories from '../shopTIleCategories/shopTIleCategories';
import PagionationLoader from '../loader/endReachLoader';
import EmptyScreen from '../emptyScreen/emptyScreen';

const {width, height} = Dimensions.get('window');

export default function TabContent({
  TABS,
  DATA,
  selectedTab,
  loader,
  renderItem,
  flatListRef,
  onScroll,
  paginationLoader,
  selectedSubCategory,
  onViewableItemsChanged,
  viewabilityConfig,
}) {
  const dataIsEmpty = DATA && DATA.length === 0;
  useEffect(() => {
    if (!loader && flatListRef?.current) {
      flatListRef?.current?.scrollToIndex({
        index: selectedTab,
        animated: false, // ya true if you want animation
      });
    }
  }, [loader]);

  
  return (
    <View style={{flex: 1}}>
      <Animated.FlatList
        ref={flatListRef}
        horizontal={!loader}
        pagingEnabled
        data={TABS}
        keyExtractor={item => item.key}
        contentContainerStyle={{paddingBottom: height * 0.15}}
        getItemLayout={(data, index) => ({
          length: width,
          offset: width * index,
          index,
        })}
        key={selectedSubCategory}
        renderItem={({item, index}) =>
          selectedTab === index && !loader ? (
            <View style={{width}}>
              <View style={{marginHorizontal: margin.horizontal}}>
                {dataIsEmpty ? (
                  <View
                    style={{
                      height: height * 0.8,
                      justifyContent: 'center',
                      alignItems: 'center',
                    }}>
                    <EmptyScreen
                      heading={'No products'}
                      desc={'No products available in current tab'}
                      image={'empty_order'}
                    />
                  </View>
                ) : (
                  <FlatList
                    data={DATA}
                    scrollEnabled={false}
                    keyExtractor={prod => prod.id}
                    numColumns={2}
                    renderItem={renderItem}
                    initialNumToRender={10}
                    windowSize={5}
                    removeClippedSubviews
                    onViewableItemsChanged={onViewableItemsChanged}
                    viewabilityConfig={viewabilityConfig}
                    ListFooterComponent={
                      paginationLoader ? (
                        <View
                          style={
                            {
                              // position: 'absolute',
                              // bottom: 0,
                              // alignSelf: 'center',
                            }
                          }>
                          <PagionationLoader />
                        </View>
                      ) : (
                        <></>
                      )
                    }
                  />
                )}
              </View>
            </View>
          ) : (
            <View style={{width}}>
              <View
                style={{
                  height: height * 1,
                  backgroundColor: 'white',
                  justifyContent: 'center',
                  alignItems: 'center',
                }}>
                <ActivityIndicator color={colors.light_theme.theme} />
              </View>
            </View>
          )
        }
        showsHorizontalScrollIndicator={false}
        onScroll={onScroll}
        scrollEventThrottle={16}
      />
      {/* {paginationLoader && !loader && (
        <View
          style={{
            position: 'absolute',
            bottom: 0,
            alignSelf: 'center',
          }}>
          <PagionationLoader />
        </View>
      )} */}
    </View>
  );
}
