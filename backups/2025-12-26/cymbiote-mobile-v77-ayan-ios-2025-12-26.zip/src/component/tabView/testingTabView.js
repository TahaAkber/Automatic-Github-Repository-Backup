import React, {useCallback, useEffect, useRef, useState} from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  ScrollView,
  Dimensions,
  ActivityIndicator,
} from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedScrollHandler,
  useAnimatedStyle,
  interpolate,
  runOnJS,
} from 'react-native-reanimated';
import {colors, font, margin, WH} from '../../constant/contstant';
import HomeDualCard from '../cards/homeDualCard';
import ShopTileCategories from '../shopTIleCategories/shopTIleCategories';
import PagionationLoader from '../loader/endReachLoader';

const {width, height} = Dimensions.get('window');


export default function AnimatedTabsTest({
  handleSelectCollection,
  selectedCollectionId,
  paginationLoader,
  sub_category,
  category,
  loader,
  data,
}) {
  const TABS = category?.map((item, index) => {
    return {key: `${index}`, title: item?.filter_option_value};
  });

  const DATA = data;

  const [selectedTab, setSelectedTab] = useState(0);
  const [lazyLoader, setLazyLoader] = useState(false);
  const [tabWidths, setTabWidths] = useState([]);
  const flatListRef = useRef(null);
  const scrollViewRef = useRef(null);

  const scrollX = useSharedValue(0);

  const centerActiveTab = index => {
    if (!scrollViewRef.current || !tabWidths[index]) return;

    const screenCenter = width / 2;
    const scrollTo =
      tabWidths.slice(0, index).reduce((a, b) => a + b, 0) +
      tabWidths[index] / 2 -
      screenCenter;

    scrollViewRef.current.scrollTo({
      x: Math.max(0, scrollTo),
      animated: true,
    });
  };

  const handleTabPress = index => {
    setSelectedTab(index);
    flatListRef.current?.scrollToIndex({index, animated: true});
    centerActiveTab(index);
  };

  const onScroll = useAnimatedScrollHandler({
    onScroll: event => {
      scrollX.value = event.contentOffset.x;
    },
    onMomentumEnd: event => {
      const index = Math.round(event.contentOffset.x / width);
      runOnJS(setSelectedTab)(index);
      runOnJS(centerActiveTab)(index);
    },
  });

  const renderItem = useCallback(
    ({item}) => (
      <View style={{}}>
        <HomeDualCard
          item={item}
          width={WH.width('44')}
          color={'black'}
          brandScreen={true}
        />
      </View>
    ),
    [],
  );

  const underlineStyle = useAnimatedStyle(() => {
    if (tabWidths.length !== TABS.length) return {};
    const translateX = interpolate(
      scrollX.value,
      TABS.map((_, i) => i * width),
      TABS.map((_, i) => tabWidths.slice(0, i).reduce((a, b) => a + b, 0)),
    );
    const w = interpolate(
      scrollX.value,
      TABS.map((_, i) => i * width),
      TABS.map((_, i) => tabWidths[i] || 0),
    );
    return {
      transform: [{translateX}],
      width: w,
    };
  });

  const lastFilterIdRef = React.useRef(null);

  React.useEffect(() => {
    if (!Array.isArray(category) || category.length === 0) return;

    const currentId = category[selectedTab]?.filter_option_id;
    if (!currentId) return;

    if (lastFilterIdRef.current !== currentId) {
      lastFilterIdRef.current = currentId;
      handleSelectCollection?.(currentId, false);
    }
  }, [selectedTab, category, handleSelectCollection]);

  return (
    <View style={{flex: 1, paddingTop: 40}}>
      {/* Tab Bar */}
      <View style={{marginHorizontal: margin.horizontal}}>
        <ScrollView
          ref={scrollViewRef}
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{position: 'relative'}}>
          {TABS.map((tab, index) => {
            const textStyle = useAnimatedStyle(() => {
              const progress = interpolate(
                scrollX.value,
                [
                  (index - 1) * width - margin.horizontal,
                  index * (width - margin.horizontal),
                  (index + 1) * (width - margin.horizontal),
                ],
                [0, 1, 0],
                'clamp',
              );
              return {
                color: progress === 1 ? colors.light_theme.theme : 'black',
              };
            });

            return (
              <TouchableOpacity
                key={tab.key}
                onPress={() => handleTabPress(index)}
                onLayout={e => {
                  const w = e.nativeEvent.layout.width;
                  setTabWidths(prev => {
                    const newWidths = [...prev];
                    newWidths[index] = w;
                    return newWidths;
                  });
                }}
                style={{
                  paddingHorizontal: 16,
                  alignItems: 'center',
                  paddingVertical: 12,
                }}>
                <Animated.Text style={[{fontFamily: font.bold}, textStyle]}>
                  {tab.title}
                </Animated.Text>
              </TouchableOpacity>
            );
          })}

          {tabWidths.length === TABS.length && (
            <Animated.View
              style={[
                {
                  position: 'absolute',
                  bottom: 0,
                  height: 2,
                  backgroundColor: colors.light_theme.theme,
                },
                underlineStyle,
              ]}
            />
          )}
        </ScrollView>
      </View>

      <ShopTileCategories
        item={[]}
        onSelect={handleSelectCollection}
        subCategory={sub_category}
        selectedCollectionId={selectedCollectionId}
        tabView={true}
      />

      {/* Horizontal Pager */}
      <Animated.FlatList
        ref={flatListRef}
        horizontal
        pagingEnabled
        data={TABS}
        keyExtractor={item => item.key}
        contentContainerStyle={{paddingBottom: 200}}
        renderItem={({item, index}) =>
          selectedTab == index ? (
            <View style={{width}}>
              <View style={{marginHorizontal: margin.horizontal}}>
                {loader ? (
                  <View
                    style={{
                      height: height * 0.4,
                      backgroundColor: 'white',
                      justifyContent: 'center',
                      alignItems: 'center',
                    }}>
                    <ActivityIndicator color={colors.light_theme.theme} />
                  </View>
                ) : (
                  <FlatList
                    data={DATA}
                    scrollEnabled={false}
                    keyExtractor={prod => prod.id}
                    numColumns={2}
                    renderItem={renderItem}
                    initialNumToRender={10}
                    windowSize={5}
                    removeClippedSubviews
                  />
                )}
              </View>
            </View>
          ) : (
            <View style={{width}}>
              <View
                style={{
                  height: height * 0.4,
                  backgroundColor: 'white',
                  justifyContent: 'center',
                  alignItems: 'center',
                  // flexGrow: 1,
                }}>
                <ActivityIndicator color={colors.light_theme.theme} />
              </View>
            </View>
          )
        }
        showsHorizontalScrollIndicator={false}
        onScroll={onScroll}
        scrollEventThrottle={16}
      />
      {paginationLoader && (
        <View
          style={{
            position: 'absolute',
            bottom: 0,
            alignSelf: 'center',
          }}>
          <PagionationLoader />
        </View>
      )}
    </View>
  );
}
