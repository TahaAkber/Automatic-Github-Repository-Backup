import React, { useCallback, useRef, useState } from 'react';
import { View, StyleSheet, Dimensions, Animated } from 'react-native';
import { font, shadow, colors } from '@constant/contstant';
import HomeDualCard from '../homeDualCard';
import { WH } from '@constant/contstant';
import { homeData } from '@constant/dummyData';

const { fontScale } = Dimensions.get('window');

const useCategoryCard = (shopItem, tilePosition, markShopAsClicked) => {

    const renderItem = useCallback(({ item, index }) => (
        <HomeDualCard
            key={`number-of-three-card-${index}`}
            headingNumOfLines={1}
            headingSize={fontScale * 12}
            item={item}
            width={WH.width('38')}
            color={"black"}
            priceSize={fontScale * 12}
            priceFontFamily={font.bold}
            discountPriceSize={fontScale * 6}
            home={true}
            shopItem={shopItem}
            tilePosition={tilePosition}
            productPosition={index}
            markShopAsClicked={markShopAsClicked}
        />
    ), [shopItem, tilePosition, markShopAsClicked]);

    return {
        renderItem,
    }
};

export default useCategoryCard;
