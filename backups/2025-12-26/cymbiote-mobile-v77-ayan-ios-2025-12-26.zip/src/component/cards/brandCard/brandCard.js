// BrandCard.js
import React, { memo } from 'react';
import { Dimensions, TouchableOpacity } from 'react-native';
import CustomBackgoundImage from '../../../materialComponent/image/bgImage';
import BrandTab from '../../brandTab/brandTab';
import { moderateScale } from 'react-native-size-matters';
import Overlay from '../../../materialComponent/overlay/overlay';
import useReduxStore from '../../../utils/hooks/useReduxStore';
import { _cartBottomSheet } from '../../../redux/actions/common/common';
import { navigate } from '../../../utils/navigationRef/navigationRef';

const { width, height, fontScale } = Dimensions.get('window');

const BrandCard = ({
    item = {},
    cardHeight = height * 0.2,
    cardWidth = width * 0.4,
    onPress,
}) => {

    const { dispatch } = useReduxStore()

    const _handleNavigate = async () => {
        // Call onPress callback if provided (for analytics)
        if (onPress) {
            await onPress();
        }
        dispatch(_cartBottomSheet(false));
        navigate('Brand', { shop_id: item.shop_id, shop: item });
    };

    return (
        <TouchableOpacity onPress={_handleNavigate} activeOpacity={1}>
            <CustomBackgoundImage
                source={{ uri: item?.shop_cover_url }}
                style={{
                    height: cardHeight,
                    width: cardWidth,
                    justifyContent: "flex-end"
                }}
            >
                <Overlay />
                <BrandTab
                    ratingSize={fontScale * 8}
                    ratingIconSize={moderateScale(6)}
                    iconHorizontal={width * 0.01}
                    ratingStyle={{ marginTop: height * -0.004 }}
                    item={item}
                    imageStyle={{ width: width * 0.09, aspectRatio: 1 }}
                    light="white"
                    shopNameFontSize={fontScale * 9}
                    removeFollowText
                />
            </CustomBackgoundImage>
        </TouchableOpacity>
    );
};

export default memo(BrandCard);
