import React, {useRef, useState} from 'react';
import {
  View,
  StyleSheet,
  Dimensions,
  Animated,
  TouchableOpacity,
  FlatList,
} from 'react-native';
import useBasicCard from './useBasicCard';
import ShopTileCategories from '@component/shopTIleCategories/shopTIleCategories';
import {margin, WH} from '@constant/contstant';
import VerticalProducts from '../homeVerticalCard/verticalProducts';
import SingleCard from '../singleCard/singleCard';
import CustomCarousel from '../../../materialComponent/customCarousel/customCarousel';

const {height, width, fontScale} = Dimensions.get('window');

const BasicCard = ({data, item}) => {
  const {
    currentIndex,
    setCurrentIndex,
    getCurrentProduct,
    getCurrentProductVariantId,
    getCurrentVariant,
  } = useBasicCard({data});

  return (
    <View style={{zIndex: 1}}>
      <View
        style={{
          height: height * 0.5,
          justifyContent: 'center',
          marginHorizontal: width * 0.06,
        }}>
        <View style={{}}>
          <SingleCard
            textContainerStyle={{width: width * 0.5}}
            headingFontSize={fontScale * 12}
            descFontSize={fontScale * 8}
            imageStyle={{width: width * 0.5, alignSelf: 'center'}}
            style={{width: width * 0.55, elevation: 0}}
            image={getCurrentProduct?.product_image_url}
            product_description={getCurrentProduct?.product_description}
            product_name={getCurrentProduct?.product_name}
            key={500}
            variant_id={getCurrentProductVariantId}
            shop_id={item.shop_id}
            current_variant={getCurrentVariant}
            product={getCurrentProduct}
          />
        </View>
        {/* <View style={styles.flatlist}>
                    <FlatList
                        scrollEnabled={true}
                        data={data}
                        renderItem={renderItem}
                        keyExtractor={(item, index) => index.toString()}
                        showsHorizontalScrollIndicator={false}
                        columnWrapperStyle={{ marginTop: height * 0.01 }}
                        numColumns={3}
                        showsVerticalScrollIndicator={false}
                    />
                </View> */}
        <View style={styles.container}>
          <VerticalProducts
            productHeight={height * 0.053}
            customHeight={height * 0.3}
            imageSize={height * 0.02}
            style={{
              bottom: height * -0.008,
            }}
            data={data}
            currentIndex={currentIndex}
            setCurrentIndex={setCurrentIndex}
          />
          {/* <CustomCarousel  /> */}
        </View>
      </View>
    </View>
  );
};

export default BasicCard;

const styles = StyleSheet.create({
  container: {
    // alignItems: 'center',
    // marginTop: height * 0.15,
    // marginHorizontal: margin.horizontal,
  },
  arrowButton: {
    width: WH.width(8),
    aspectRatio: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.6)',
    borderRadius: 180,
    justifyContent: 'center',
    alignItems: 'center',
    marginVertical: height * 0.01,
    position: 'absolute',
    top: 10,
    zIndex: 2,
  },
  flatlist: {
    marginHorizontal: margin.horizontal,
  },
});
