import {moderateScale, verticalScale} from 'react-native-size-matters';
import CustomText from '@materialComponent/customText/customText';
import {colors, globalStyle, WH} from '@constant/contstant';
import CustomImage from '@materialComponent/image/image';
import {useNavigation} from '@react-navigation/native';
import Like from '@materialComponent/like/like';
import Icon from '@materialComponent/icon/icon';
import {currency} from '@constant/signature';
import {font} from '@constant/contstant';
import React, {memo, useEffect, useState} from 'react';
import {
  Animated,
  Dimensions,
  StyleSheet,
  TouchableOpacity,
  View,
} from 'react-native';
import {toFixedMethod} from '@utils/helper/helper';
import {
  _favoriteUpdateStatus,
  _getFavorite,
} from '../../redux/actions/user/user';
import {useDispatch} from 'react-redux';
import useReduxStore from '../../utils/hooks/useReduxStore';
import {
  defaultShopImages,
  formatPrice,
  getShopDetail,
  getStoreState,
  showingVaraintPrice,
} from '../../utils/helper/helper';
import useImageHeight from '../../utils/hooks/useImageHeight';
import {noImageUrl} from '../../constant/contstant';
import {logHomeProductClickEvent} from '../../helper/eventTriggers/useEventTriggers';

const {width: dimentionWidth, height, fontScale} = Dimensions.get('screen');

const HomeDualCard = ({
  color,
  width,
  item,
  headingSize,
  priceSize,
  discountPriceSize,
  headingNumOfLines,
  priceFontFamily,
  marginRight,
  onPress,
  showShopName = false,
  home,
  brandScreen,
  isFromSearch = false,
  searchQuery = '',
  shopItem,
  tilePosition,
  productPosition,
  markShopAsClicked,
}) => {
  const dynamicWith = width || dimentionWidth * 0.43;
  const dynamicHeight = width || dimentionWidth * 0.4;
  const navigation = useNavigation();
  const {getState, dispatch} = useReduxStore();
  const {height} = useImageHeight(defaultShopImages(item)?.[0]);

  const {fetch_favorite_list_local, fetch_favorite_list} = getState('user');
  const finalArray = [
    ...fetch_favorite_list
      .flatMap(shop => shop.products || [])
      .map(p => p.product_id),
    ...fetch_favorite_list_local.map(p => p.wishlist_product_id),
  ];

  // We assume `fetch_favorite_list` contains product details along with `shop_name`
  const productShopId = item.product_shop_id; // This is the shop ID for the current product
  const favoriteShop = fetch_favorite_list.find(
    shop =>
      shop.products.some(product => product.product_id === item.product_id), // Match the product
  );

  const shop_name = favoriteShop ? favoriteShop.shop_name : 'Shop Not Found'; //

  const handleProductPress = async () => {
    if (
      shopItem &&
      tilePosition !== undefined &&
      productPosition !== undefined
    ) {
      await logHomeProductClickEvent(
        item,
        shopItem,
        productPosition,
        tilePosition,
      );
    }

    if (markShopAsClicked && shopItem?.shop_id) {
      markShopAsClicked(shopItem.shop_id);
    }

    if (home) {
      navigation.navigate('ProductDetail', {
        product_id: item.product_id,
        shop_id: item.product_shop_id,
        default_images: defaultShopImages(item),
        height,
        isFromSearch,
        searchQuery,
      });
    } else {
      navigation.push('ProductDetail', {
        product_id: item.product_id,
        shop_id: item.product_shop_id,
        default_images: defaultShopImages(item),
        brand_screen: brandScreen,
        height,
        isFromSearch,
        searchQuery,
      });
    }
    onPress && onPress();
  };

  return (
    <TouchableOpacity
      activeOpacity={1}
      onPress={handleProductPress}
      style={[styles.brand_slider, {width: dynamicWith}]}>
      <View>
        <CustomImage
          style={[
            styles.brand_slider_image,
            {width: dynamicWith, height: dynamicHeight},
            marginRight && {marginRight: marginRight == 0 ? 0 : WH.width('2%')},
          ]}
          source={{
            uri:
              item?.product_image_url_medium ||
              item?.product_image_url ||
              noImageUrl,
          }}
          // source={{ uri: "https://s3-alpha-sig.figma.com/img/dfc3/dd72/6e0f810b0310ac03baa5a0afa501097b?Expires=1737936000&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=TkG7SNvHBSqfWc7iRxmx4j8FwbVO78KUrKfaNUJmSR-NCXqkrzo6snita5p9BAv6lHku4S0x42nUxDkGr6zgFapL95X6Txehu449EJ2MCbNBHuTxbAzEOldiL~E9Eq7oJcntlLP5sojOD0~OJ6OJ4PoJhKC~DFNVY3VgfzlQo4~nbAnxeI0areed3ySYPCuYR9crNxWqKolarVjMI1FsHojEVsEDzjOMb~El7Teo382BLYURnZl1DSAs7vofdNtZLZYs0PnRddVzapAlcvGH1OC4dBEeTHKEkbL3wBFTMxMxHqtPbSWovYnFC563dplD8VQ8nNw9OEEp7JziB~6aeg__" }}
        />
        <Like key={finalArray.length} product_id={item?.product_id} />
      </View>
      <View style={styles.content}>
        {/* <CustomText
          fontSize={headingSize || fontScale * 14}
          text={item.product_name}
          color={color || 'white'}
          fontFamily={font.medium}
          numberOfLines={2}
        /> */}

        <Animated.Text
          numberOfLines={headingNumOfLines || 2}
          style={{
            fontSize: headingSize || fontScale * 12,
            color: color || 'white',
            fontFamily: font.medium,
          }}>
          {item.product_name}
        </Animated.Text>
        {showShopName && (
          <Animated.Text
            numberOfLines={headingNumOfLines || 2}
            style={{
              fontSize: headingSize || fontScale * 12,
              color: colors.light_theme.themeGray,
              fontFamily: font.medium,
            }}>
            by {shop_name} {/* Show shop name if showShopName is true */}
          </Animated.Text>
        )}
        <View style={[globalStyle.row, {marginTop: verticalScale(2)}]}>
          <Animated.Text
            numberOfLines={1}
            style={{
              fontSize: priceSize || fontScale * 10,
              color: color || 'white',
              fontFamily: font.bold,
            }}>
            {`${item.product_currency || currency} ${formatPrice(
              toFixedMethod(
                showingVaraintPrice(
                  item.product_variant?.variant_price ||
                    item.product_variant?.[0]?.variant_price ||
                    item?.variant_price,
                  item.product_variant?.variant_discounted_price ||
                    item.product_variant?.[0]?.variant_discounted_price ||
                    item?.variant_price,
                ).discounted_price,
              ),
            )} `}
          </Animated.Text>

          {item?.product_variant?.[0]?.variant_discounted_price ? (
            <Animated.Text
              numberOfLines={1}
              style={{
                fontSize: discountPriceSize || fontScale * 10,
                color: color || '#00000080',
                fontFamily: font.bold,
                textDecorationLine: 'line-through',
                marginLeft: dimentionWidth * 0.01,
                opacity: 0.8,
              }}>
              {`${item?.product_currency || currency} ${formatPrice(
                toFixedMethod(
                  showingVaraintPrice(
                    item.product_variant?.variant_price ||
                      item.product_variant?.[0]?.variant_price ||
                      item?.variant_price,
                    item.product_variant?.variant_discounted_price ||
                      item.product_variant?.[0]?.variant_discounted_price ||
                      item?.variant_discounted_price,
                  ).original_price,
                ),
              )} `}
            </Animated.Text>
          ) : (
            <></>
          )}

          {/* <View style={globalStyle.row}>
            <Icon
              size={moderateScale(10)}
              icon_type="AntDesign"
              color={"orange"}
              name="star"
            />
            <CustomText
              fontSize={moderateScale(11)}
              fontFamily={font.regular}
              style={{ marginLeft: 5 }}
              color={color || "white"}
              text={"4.5"}
            />
          </View> */}
        </View>
      </View>
    </TouchableOpacity>
  );
};

export default memo(HomeDualCard);

const styles = StyleSheet.create({
  brand_slider: {
    zIndex: 1,
    borderRadius: moderateScale(5),
    marginRight: WH.width('2%'),
    width: WH.width('35%'),
    borderColor: colors.light_theme.darkBorderColor,
    justifyContent: 'center',
    overflow: 'hidden',
  },
  content: {
    marginHorizontal: moderateScale(5),
    marginVertical: verticalScale(15),
    marginTop: verticalScale(8),
  },
  brand_slider_image: {
    // height: WH.width('35%'),
    // width: WH.width('35%'),
    borderRadius: 10,
    // marginRight: dimentionWidth * 0.01,
    backgroundColor: '#efefef',
    borderWidth: 1,
    borderColor: '#f7f7f7',
    alignItems: 'center',
    justifyContent: 'center',
    // alignSelf: 'center',
  },
  wishlist: {
    height: moderateScale(25),
    width: moderateScale(25),
    backgroundColor: 'rgba(0,0,0,0.2)',
    justifyContent: 'center',
    position: 'absolute',
    alignItems: 'center',
    borderRadius: 180,
    bottom: 10,
    right: 5,
  },
  rating: {
    paddingHorizontal: moderateScale(3),
    paddingVertical: moderateScale(3),
    borderRadius: moderateScale(2),
    justifyContent: 'center',
    backgroundColor: 'white',
    alignItems: 'center',
    position: 'absolute',
    ...globalStyle.row,
    opacity: 0.7,
    bottom: 10,
    right: 5,
  },
});
