import { Dimensions, StatusBar, StyleSheet, TextInput, View, TouchableOpacity, Animated, ScrollView } from 'react-native';
import React, { useRef, useState } from 'react';
import CustomText from '@materialComponent/customText/customText';
import { font, globalStyle, margin } from '@constant/contstant';
import CustomImage from '@materialComponent/image/image';
import BrandTab from '@component/brandTab/brandTab';
import { homeData } from '@constant/dummyData';
import Icon from '@materialComponent/icon/icon';
import BottomSheetForLibrary from '@materialComponent/bottomSheet/cameraSheet';
import { shadow } from '@constant/contstant';
import OrderVariantCard from '../orderVariantCard/orderVariantCard';
import RatingStars from '../../../materialComponent/ratingStars/ratingStars';
import useReduxStore from '../../../utils/hooks/useReduxStore';
import { _getUserReviews, _sendUserReview } from '../../../redux/actions/reviews/reviews';
import CustomButton from '../../../materialComponent/customButton/customButton';
import { moderateScale } from 'react-native-size-matters';
import { FETCH_REVIEWS } from '../../../redux/types/reviews/reviews';

const { height, fontScale, width } = Dimensions.get("screen");

const PendingReviewCard = ({ marginTop, paddingHorizontal, paddingVertical, item, order_detail, subIndex, tab }) => {
    const [comment, setComment] = useState("");
    const [images, setImages] = useState([]); // State to track the rating
    const [rating, setRating] = useState(0); // State to track the rating
    const { dispatch, getState } = useReduxStore()
    const [loader, setLoader] = useState(false)
    const { fetch_user_reviews } = getState("reviews")


    const refRBSheet = useRef();

    const deleteImage = (index) => {
        const removeItem = images.filter((item, i) => i != index)
        setImages(removeItem)
    }

    const sendReview = async () => {
        setLoader(true)
        const res = await dispatch(_sendUserReview({ comment, local_images: images, order_item_id: item?.order_item_id, rating }))
        if (res) {
            await dispatch(_getUserReviews({ page: 1, tab: 0 }));
            await dispatch(_getUserReviews({ page: 1, tab: 1 }));
            await dispatch(_getUserReviews({ page: 1, tab: 2 }));
            setLoader(false)
        }
        setLoader(false)
    }

    const disabledButton = () => {
        if (rating && comment) {
            return true
        }
    }

    const updateOrdersItem = (item) => {
        const updatedOrders = order_detail?.order_item?.map((el) => {
            if (el.order_item_id == item.order_item_id) {
                return { ...el, review_completed: true };
            }
            return el;
        });
        return updatedOrders
    }


    const updateReview = () => {
        const updated = JSON.parse(JSON.stringify(fetch_user_reviews)); // Deep clone to avoid mutating original

        Object.keys(updated).forEach(key => {
            const items = updated[key]?.data || [];

            const image = images.map((item) => item.uri)

            items.forEach(item => {
                if (item.order_item_id === item?.order_item_id) {
                    item.review_completed = true;
                    item.review_item = {
                        "order_item_review_id": Math.random().toString(36).substring(2, 15),
                        "order_item_review_rating": rating,
                        "order_item_review_comment": comment,
                        "order_item_id": item?.order_item_id,
                        "images": image,
                        created_at: new Date().toISOString(),
                    };
                }
            });
        });

        return updated;
    };

    return (
        <View style={{ marginTop: marginTop || 0, backgroundColor: "white", padding:width*0.03,margin:width*0.03,elevation:3,shadowColor:"#000", boxShadowColor:"#000", borderRadius:4, ...shadow }}>
            {subIndex == 0 ?
                <BrandTab removeFollowText={true} mainViewStyle={{ paddingHorizontal: 0 }} item={order_detail?.shop_detail} />
                : <></>
            }
            <View>
                <View style={styles.container}>
                    <CustomImage style={styles.image} source={{ uri: item?.product?.product?.product_image_url || "https://s3-alpha-sig.figma.com/img/32b2/fed3/dd6e97ca36cbcbf5ca57596f7c6547d3?Expires=1738540800&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=V~jDIWqUYDPihFGdfXe8gwsb63jE6POuTOY-HjySwUlz8kF4mFI8acmDCtXPVOw6ZDznowMowQ7g8QBuvmmwxCG6M7wwDc8fvSm4giY4nzLSPc6EwfT8h8rdSCL9OsL1gcInUBmrq0EhWwSdyfxpIhkYwEHrOyMzgoyQ2i~sFTmwtGyES7TbQheUkX5hCox~3vtW8q6nPJlanU5CVA2xS9sucInadVXFlUQA9xlI48vZnWzxAjAxC-XB3t0X8j~rnJC-TGJrX~OYff4kZ4p4CC83ym2cgJKDF0MKK3P~BRZ~2~UhQ62fsbbBlL93UR9DKeRIsU9FOQdh7LnGoBrnUA__" }} />
                    <View style={styles.textContainer}>
                        <CustomText numberOfLines={1} fontSize={fontScale * 12} text={(item?.product?.product?.product_name || "Lorem ipsum dolor sit amet consectetur.") + " | " + order_detail?.shop_detail?.shop_name}/>
                        <CustomText fontFamily={font.bold} fontSize={fontScale * 12} text={order_detail?.order_title ? `Order ${order_detail?.order_title}` : "Order #92287157"} marginTop={2} />
                    </View>
                </View>
                <View style={[styles.reviewContainer]}>
    <View style={styles.reviewSection}>
        <View style={styles.inputContainer}>
            <TextInput
                placeholder='Write your review here...'
                placeholderTextColor={"gray"}
                style={styles.input}
                onChangeText={(e) => setComment(e)}
                value={comment}
                multiline={true}
                numberOfLines={4}
                textAlignVertical="top"
            />
        </View>
        <View>
            <View style={[globalStyle.row, styles.starRating]}>
                <RatingStars showRating={true} marginRight={-2} setRating={setRating} rating={rating} size={fontScale * 20} />
            </View>
            {!images.length && disabledButton() ? (
                <View style={{ width: width * 0.2, alignSelf: "flex-start", justifyContent: "flex-end", marginTop: height * 0.01 ,  marginHorizontal:height*0.01}}>
                    <CustomButton loaderSize={"small"} loader={loader} onPress={sendReview} text={"Submit"} marginTop={1} buttonStyle={{ height: height * 0.030, borderRadius: 5 }} textStyle={{ fontSize: fontScale * 10, color: "white" }} disabledOpacity={1} forceHeight={height* 0.03} />
                </View>
            ) : null}
        </View>
        {images.length > 0 ? (
            <View>

            
            <View style={[globalStyle.row, { marginTop: height * 0.02, width: "132%",  marginHorizontal:height*0.01 }]}>
                <ScrollView horizontal>
                    {images.map((item, i) => (
                        <View style={{ width: width * 0.12, aspectRatio: 1, marginRight: 10, borderRadius: 10, overflow: "hidden", zIndex: 1 }}>
                            <TouchableOpacity onPress={() => deleteImage(i)} style={{ ...shadow, position: "absolute", top: 0, right: 0, width: width * 0.05, aspectRatio: 1, backgroundColor: "white", zIndex: 2, justifyContent: "center", alignItems: "center" }}>
                                <Icon
                                    icon_type="FontAwesome"
                                    name={"close"}
                                    color={"black"}
                                    size={fontScale * 10}
                                />
                            </TouchableOpacity>
                            <CustomImage style={{ width: "100%", height: "100%" }} source={{ uri: item.uri }} />
                        </View>
                    ))}
                    {images.length <= 4 ? (
                        <View style={{ width: width * 0.12, aspectRatio: 1, marginRight: 10, borderRadius: 10, overflow: "hidden", zIndex: 1, borderWidth: 1, opacity: 0.4 }}>
                            <TouchableOpacity activeOpacity={1} onPress={() => refRBSheet?.current?.open()} style={[styles.uploadMedia, { backgroundColor: "white" }]}>
                                <Icon
                                    icon_type="Entypo"
                                    name={"plus"}
                                    color={"black"}
                                    size={fontScale * 25}
                                />
                            </TouchableOpacity>
                        </View>
                    ) : null}
                </ScrollView>

            </View>
                {disabledButton() ? (
                    <View style={{ width: width * 0.2, height: width * 0.12, alignSelf: "flex-start", justifyContent: "flex-end",   marginHorizontal:height*0.01 }}>
                        <CustomButton loaderSize={"small"} loader={loader} onPress={sendReview} text={"Submit"} buttonStyle={{ height: height * 0.030, borderRadius: 4 }} textStyle={{ fontSize: fontScale * 10, color: "white" }} disabledOpacity={1} forceHeight={height * 0.03} />
                    </View>
                ) : null}
            </View>
        ) : null}
    </View>

    {!images.length ? (
        <View style={[styles.imageContainer, images.length > 0 && { height: height * 0.09, position: "absolute", top: 2, right: 2 }, { marginRight: 8 }]}>
            <TouchableOpacity activeOpacity={1} onPress={() => refRBSheet?.current?.open()} style={styles.uploadMedia}>
                <Icon
                    icon_type="Entypo"
                    name={"camera"}
                    color={"#a6a6a6"}
                    size={fontScale * 25}
                    onPress={() => refRBSheet?.current?.open()}
                />
            </TouchableOpacity>
        </View>
    ) : null}
</View>
            </View >

            <BottomSheetForLibrary multiple={true} images={images} setImages={setImages} refRBSheet={refRBSheet}  />
        </View >
    );
};

export default PendingReviewCard;

const styles = StyleSheet.create({
    container: {
        flexDirection: "row",
        alignItems: "center",
        marginTop: height * 0.01
    },
    image: {
        width: "15%",
        aspectRatio: 1,
        marginRight: "3%",
        borderRadius: 5,
        borderWidth:1,
        backgroundColor:"#efefef",
        borderColor:"#f7f7f7"
    },
    textContainer: {
        // Add any desired styling for the text container here
        width: "85%",
    
    },
    inputContainer: {
        width: "100%",
        height: height * 0.045,
        flexDirection: 'column',
        // height:null
        // borderWidth: 1,
    },
    input: {
        height: "100%",
        width: "100%",
        fontFamily: font.medium,
        fontSize: fontScale * 12,
        
        
        color: "black",
        // borderWidth:1,
        padding: moderateScale(10), // Add padding to make it more user-friendly
        flexGrow: 1, // Allows TextInput to grow with content
        textAlignVertical: 'top', // Ensures text starts at the top
    },
    reviewContainer: {
        borderWidth: 1,
        borderColor: "#cdcbcd",
        paddingLeft: 5,
        marginTop: height * 0.01,
        borderRadius: 10,
        flexDirection: "row",
        flexWrap: "wrap",  // Allows the container to grow with the content
        overflow: "hidden",
        alignItems: "center",
        justifyContent: "space-between",
        paddingVertical: moderateScale(10),  // Ensures padding even if content grows
    },
    reviewSection: {
        width: "75%",
    },
    inputContainer: {
        width: "100%",
        flexDirection: 'column',
        marginBottom: moderateScale(10),  // Adds spacing between the input and the star rating
    },
    input: {
        width: "100%",
        fontFamily: font.medium,
        fontSize: fontScale * 12,
        color: "black",
        padding: moderateScale(10),
        flexGrow: 1,  // Allows TextInput to grow with content
        textAlignVertical: 'top',  // Ensures text starts at the top of the TextInput
    },
    starRating: {
        // marginTop: height * 0.01,  // Adjusts the spacing between the rating stars and the input box
        marginHorizontal:height*0.01
    },
    imageContainer: {
        width: "18%",
        aspectRatio: 1,
        borderRadius: 6,
        overflow: "hidden",
        backgroundColor: "#f6f4f4",
    },
    productImage: {
        width: "100%",
        height: "100%",
    },
    uploadMedia: {
        width: "100%",
        height: "100%",
        justifyContent: "center",
        alignItems: "center",
    },
});
