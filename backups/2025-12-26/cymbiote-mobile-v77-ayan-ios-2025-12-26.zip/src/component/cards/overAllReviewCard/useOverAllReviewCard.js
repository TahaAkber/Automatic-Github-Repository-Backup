import useReduxStore from '@utils/hooks/useReduxStore';
import { useEffect, useState } from 'react';
import { Animated } from 'react-native';
import { _reviewReaction } from '../../../redux/actions/reviews/reviews';

const useOverAllReviewCard = ({ review_detail, item }) => {
    const { getState, dispatch } = useReduxStore()
    const { fetch_user_detail } = getState("auth")

    const [like, setLike] = useState(false)
    const [likeCount, setLikeCounter] = useState(0)
    const scaleAnim = useState(new Animated.Value(1))[0];

    const handleLike = async () => {
        setLike(prev => !prev);
        setLikeCounter(prev => prev + (like ? -1 : 1)); // Increment or decrement like count based on current state
        await dispatch(_reviewReaction(item?.order_item_review_id || item?.review_item?.order_item_review_id, like))
        Animated.sequence([
            Animated.spring(scaleAnim, { toValue: 1.3, useNativeDriver: true }),  // Enlarge
            Animated.spring(scaleAnim, { toValue: 1, useNativeDriver: true }),    // Return to normal
        ]).start();
    };

    const likeIconStyle = {
        transform: [{ scale: scaleAnim }],
    };


    useEffect(() => {
        // Update the 'like' state whenever 'item' changes
        setLike(Boolean(item?.review_item?.self_reaction) || Boolean(item?.selfReaction));
    }, [item]); // This will trigger when 'item' changes

    const images = item?.review_item?.images || review_detail?.review_detail?.images || item?.images || []


    return {
        fetch_user_detail,
        like,
        handleLike,
        likeIconStyle,
        images,
        likeCount
    };
};

export default useOverAllReviewCard;
