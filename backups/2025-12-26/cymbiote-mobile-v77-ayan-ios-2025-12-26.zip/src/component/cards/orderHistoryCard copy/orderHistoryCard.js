// import { Dimensions, StatusBar, StyleSheet, View, Animated, ScrollView, TouchableOpacity } from 'react-native';
// import React from 'react';
// import { navigate } from '@utils/navigationRef/navigationRef';
// // import OrderVariantCard from '@component/cards/orderVariantCard/orderVariantCard';
// import BrandTab from '../../brandTab/brandTab';
// import CustomProgressIndicator from '@materialComponent/customProgressIndicator/customProgressIndicator';
// import CustomText from '@materialComponent/customText/customText';
// import { colors, font, margin } from '@constant/contstant';
// import CustomButton from '@materialComponent/customButton/customButton';
// import BottomSheetOrderCancellation from '@materialComponent/bottomSheet/bottomSheetOrderCancellation';
// import useOrderHistoryCard from './useOrderHistoryCard';
// import OrderVariantCard from '../orderVariantCard/orderVariantCard';

// const { height, fontScale } = Dimensions.get("screen");

// const OrderHistoryCard = ({ item }) => {
//     const { getIndexStatus, refRBSheet, openSheet } = useOrderHistoryCard({ item })
//     return (
//         <TouchableOpacity activeOpacity={1} onPress={() => navigate("OrderDetail", { getAssets: getIndexStatus() })} style={styles.container}>
//             <BrandTab text={item?.shop?.email} item={item.shop_detail} followColor={"white"} followText={item.orderStatus} followStyle={{ backgroundColor: getIndexStatus()?.backgroundColor || "white", fontSize: fontScale * 12, borderRadius: 5 }} />
//             <CustomProgressIndicator currentStep={getIndexStatus()?.index} />
//             {item.order_item.map((item, index) => {
//                 return (
//                     <OrderVariantCard
//                         showProductName={true}
//                         removeBorder={true} />
//                 )
//             })}
//             {/* <OrderVariantCard removeBorder={true} /> */}
//             <View style={styles.price}>
//                 <CustomText fontFamily={font.bold} fontSize={fontScale * 11} text={`Total (${item.order_item.length} Items)`} />
//                 <CustomText color={colors.light_theme.theme} style={{ marginLeft: 5 }} fontFamily={font.bold} fontSize={fontScale * 17} text={"url 208.50"} />
//             </View>
//             {getIndexStatus()?.index == 0 ?
//                 <View style={{ width: "35%", alignSelf: "flex-end", marginTop: height * 0.02 }}>
//                     <CustomButton onPress={openSheet} text={"Cancel Order"} textStyle={{ fontSize: fontScale * 12, color: "black" }} buttonStyle={{ height: height * 0.035, paddingHorizontal: 0, borderRadius: 5 }} backgroundColor={"#E5E5E5"} />
//                 </View> : <></>
//             }

//             {getIndexStatus()?.index == 3 ?
//                 <View style={{ width: "35%", alignSelf: "flex-end", marginTop: height * 0.02 }}>
//                     <CustomButton text={"Buy Again"} onPress={() => alert("Buy Again")} textStyle={{ fontSize: fontScale * 12, color: "white" }} buttonStyle={{ height: height * 0.035, paddingHorizontal: 0, borderRadius: 5 }} backgroundColor={"black"} />
//                 </View> : <></>
//             }


//             <BottomSheetOrderCancellation
//                 refRBSheet={refRBSheet}
                
//             />
//         </TouchableOpacity>
//     );
// };

// export default OrderHistoryCard;

// const styles = StyleSheet.create({
//     container: {
//         flex: 1,
//         backgroundColor: "white",
//         paddingHorizontal: margin.horizontal,
//         paddingVertical: height * 0.02
//     },
//     price: {
//         flexDirection: "row",
//         justifyContent: "flex-end",
//         alignItems: "center",
//         marginTop: height * 0.02
//     }
// });