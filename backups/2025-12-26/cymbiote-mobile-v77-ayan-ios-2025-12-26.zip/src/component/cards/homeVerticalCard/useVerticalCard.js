import { useEffect, useRef, useState } from 'react';
import { Dimensions, View } from 'react-native';
import CustomImage from '@materialComponent/image/image';

const { height, width, fontScale } = Dimensions.get('window');

const dynaimcWidthHeight = height * 0.07;

const useVerticalCard = ({ data }) => {
    const carouselRef = useRef(null);

    // State to handle data
    // const [carouselData, setCarouselData] = useState(data); // Start with first 5 items
    const [carouselData, setCarouselData] = useState(data.slice(0, 5)); // Start with first 5 items
    const [isLoading, setIsLoading] = useState(false);
    const [currentIndex, setCurrentIndex] = useState(2);
    const [variant, setVariant] = useState(0);

    // Simulate fetching more data
    const loadMoreData = () => {
        if (!isLoading && carouselData.length < data.length) {
            setIsLoading(true);

            // Simulate API or fetching data delay
            setTimeout(() => {
                const newData = data.slice(carouselData.length, carouselData.length + 5); // Load next 5 items
                setCarouselData([...carouselData, ...newData]);
                setIsLoading(false);
            }, 1500); // Delay for fetching
        }
    };

    // Render Carousel Item
    const renderItem = ({ item }) => (
        <View style={styles.carouselItem}>
            {/* <CustomImage style={{ height: dynaimcWidthHeight, aspectRatio: 1 }} source={{ uri: item.product_image_url }} /> */}
            <CustomImage style={{ height: dynaimcWidthHeight, aspectRatio: 1 }} source={{ uri: "https://s3-alpha-sig.figma.com/img/fc7c/2bb9/f03128d44cff283af23e7cca249ddeac?Expires=1736121600&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=L86hH-VyXt-0nvvooDoI7TrfD6xOTR0s0WxkDk9wA22aNr83z3IuxcBC3j9I9muV5XNqdajVlEQocWKHtleSKIu9GlL5Is6OAClXBiFT3XuhOlwL2cTczheqxeR6htWl4i3PsMfKoDUOm~rdceZp0acF54m5dtJiNDwv8aBcCslWkWD4d5-IUEDsGYqUyekXzTcUZw1sNQrakVs3TG6g~759DlpQVBmXAfUEDRb1KajZ2Edd9SOV-p1uttBzPVQZPLM9oy1p7nO1dF~DKRyQB28K46kM-4XYD0zQrF8sRku-RDThDJPCVP1hYrB3Swn~5lPLYeDTWtpl0C0EAvcOxg__" }} />
        </View>
    );

    const findIndex = data?.[currentIndex]?.product_variant.findIndex(item => item.variant_id == variant)

    const getCurrentProduct = data?.[currentIndex] || {}
    const getCurrentProductVariant = data?.[currentIndex]?.product_variant?.[findIndex] || {}
    const getCurrentProductVariantColors = getCurrentProduct?.product_variant?.map((item) => {
        // Check if item.variant_name is valid and split it safely
        const color = item.variant_name?.split('/')?.[0]?.trim()?.toLowerCase(); // Safely get first part and convert to lowercase
        return color || null; // Return color or null if invalid
    });

    // Filter out colors that contain spaces or are null
    const colorCode = getCurrentProductVariantColors?.filter(
        (color) => color !== null && !color.includes(' ') // Exclude if the color contains a space
    ) || [];

    const uniqueArray = [...new Set(colorCode)];

    const variants = getCurrentProduct?.product_variant || []

    const groupedData = variants?.reduce((acc, variant) => {
        // Ensure selected_options exist and contain valid entries
        if (variant?.selected_options?.length > 0 && variant.selected_options.every(option => option?.value)) {
            variant.selected_options.forEach(({ name, value, selected_options }) => {
                if (!acc[name]) {
                    acc[name] = {
                        name,
                        selectedValue: '',
                        values: [],
                        selected_options: variant?.selected_options,
                        images: variant?.images?.[0]?.preview?.image?.url
                    };
                }

                // Check for duplicates before adding
                if (!acc[name].values.some((v) => v.value === value.toLowerCase())) {
                    acc[name].values.push({
                        variant_id: variant.variant_id,
                        name,
                        value: value.toLowerCase(),
                        available: variant.variant_quantity,
                        images: variant?.images?.[0]?.preview?.image?.url
                    });
                }
            });
        }
        return acc;
    }, {});

    const formattedResult = Object.values(groupedData).map((group) => ({
        ...group,
        selectedValue: group.values[0]?.variant_id || '', // Default to the first value if available
    }));

    const getColors = formattedResult?.find(item => item.name?.includes("Color") || item.name?.includes("color"))

    const images = (getColors?.values || []).length > 0 ? getColors?.values.map((item, index) => item?.images) : [getCurrentProduct?.product_image_url]




    const setVaraintItem = (index) => {
        setVariant(getColors?.values?.[index]?.variant_id)
    }

    return {
        currentIndex,
        setCurrentIndex,
        carouselRef,
        loadMoreData,
        renderItem,
        colorCode: colorCode,
        variant,
        setVariant,
        getCurrentProduct,
        getCurrentProductVariant,
        getCurrentProductVariantColors,
        getColors,
        images,
        findIndex,
        setVaraintItem
    };
};

export default useVerticalCard;
