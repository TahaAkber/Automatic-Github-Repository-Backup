import React, {useMemo, useCallback, memo} from 'react';
import {
  View,
  StyleSheet,
  Dimensions,
  TouchableOpacity,
  FlatList,
} from 'react-native';
import {moderateScale, verticalScale} from 'react-native-size-matters';
import CustomImage from '../../../materialComponent/image/image';
import LinearGradient from 'react-native-linear-gradient';
import Animated, {
  interpolate,
  useSharedValue,
  useAnimatedStyle,
  useAnimatedScrollHandler,
  useDerivedValue,
} from 'react-native-reanimated';
import {colors, font, margin, noImageUrl} from '../../../constant/contstant';
import CustomText from '../../../materialComponent/customText/customText';
import {
  defaultShopImages,
  formatPrice,
  showingVaraintPrice,
  toFixedMethod,
} from '../../../utils/helper/helper';
import {useNavigation} from '@react-navigation/native';
import {currency} from '../../../constant/signature';
import Like from '../../../materialComponent/like/like';
import useImageHeight from '../../../utils/hooks/useImageHeight';
import {logHomeProductClickEvent} from '../../../helper/eventTriggers/useEventTriggers';

const AnimatedFlatList = Animated.createAnimatedComponent(FlatList);

const {width, height} = Dimensions.get('screen');

const _imageWidth = width * 0.6;
const _imageHeight = height * 0.25;
const _spacing = 12;
const _carouselPadding = (width - _imageWidth) / 3;

const PhotoItem = React.memo(
  ({item, index, scrollX, getCurrentProduct, fontColor}) => {
    return (
      <View style={[styles.imageView]}>
        <View style={styles.imageContainer}>
          <CustomImage
            source={{uri: `${item.product_image_url_medium || noImageUrl}`}}
            resizeMode={'cover'}
            style={styles.image}
          />
          <Like
            product_id={item?.product_id}
            style={styles.likeIcon}
            size={moderateScale(10)}
          />
        </View>
        <View style={styles.textContainer}>
          <CustomText
            text={item?.product_name}
            fontSize={13}
            style={styles.nameText}
            numberOfLines={1}
            color={fontColor || 'white'}
            fontFamily={font.medium}
          />
          <View style={styles.priceContainer}>
            <CustomText
              text={`${item?.product_currency || currency} ${formatPrice(
                toFixedMethod(
                  showingVaraintPrice(
                    item.product_variant[0]?.variant_price,
                    item.product_variant[0]?.variant_discounted_price,
                  ).discounted_price,
                ),
              )} `}
              fontFamily={font.medium}
              fontSize={12}
              color={fontColor || 'white'}
            />
            {item.product_variant[0]?.variant_discounted_price ? (
              <CustomText
                text={`${item?.product_currency || currency} ${formatPrice(
                  toFixedMethod(
                    showingVaraintPrice(
                      item.product_variant[0]?.variant_price,
                      item.product_variant[0]?.variant_discounted_price,
                    ).original_price,
                  ),
                )} `}
                style={{textDecorationLine: 'line-through', opacity: 0.8}}
                fontFamily={font.medium}
                fontSize={10}
                color={fontColor || 'white'}
              />
            ) : (
              <></>
            )}
          </View>
        </View>
      </View>
    );
  },
);

const AnimatedCard = ({
  products,
  item,
  backgroundColor,
  fontColor,
  tilePosition,
  markShopAsClicked,
}) => {
  const scrollX = useSharedValue(0);
  const navigation = useNavigation();
  const {height} = useImageHeight(defaultShopImages(item)?.[0]);

  const onScroll = useAnimatedScrollHandler({
    onScroll: event => {
      scrollX.value = event.contentOffset.x;
    },
  });

  const renderItem = useCallback(
    ({item: productItem, index: productIndex}) => {
      const handleProductPress = async () => {
        // Log product click analytics
        await logHomeProductClickEvent(
          productItem,
          item,
          productIndex,
          tilePosition,
        );

        // Mark shop as clicked
        if (markShopAsClicked) {
          markShopAsClicked(item.shop_id);
        }

        navigation.navigate('ProductDetail', {
          product_id: productItem.product_id,
          shop_id: productItem.product_shop_id,
          default_images: defaultShopImages(productItem),
          height,
        });
      };

      return (
        <TouchableOpacity
          onPress={handleProductPress}
          activeOpacity={1}
          style={styles.itemContainer}>
          <CardContainer
            item={productItem}
            index={productIndex}
            scrollX={scrollX}
            backgroundColor={backgroundColor}
            fontColor={fontColor}
          />
        </TouchableOpacity>
      );
    },
    [item, tilePosition, markShopAsClicked, navigation, height],
  );

  return (
    <View style={styles.container}>
      <AnimatedFlatList
        data={products}
        keyExtractor={item => `animated-card-${item?.product_id}`}
        renderItem={renderItem}
        horizontal
        contentContainerStyle={{
          paddingHorizontal: _carouselPadding,
          alignItems: 'center',
        }}
        snapToInterval={_imageWidth + _spacing}
        decelerationRate={'fast'}
        showsHorizontalScrollIndicator={false}
        onScroll={onScroll}
        scrollEventThrottle={16}
        initialNumToRender={3} // Control number of initially rendered items
        maxToRenderPerBatch={5} // Limit number of items rendered per batch
      />
    </View>
  );
};

const CardContainer = React.memo(
  ({item, index, scrollX, backgroundColor, fontColor}) => {
    const shopColor = backgroundColor || item?.shop_color || '#848484';
    // const animatedStyle = useAnimatedStyle(() => {
    //   // Calculate the inputRange directly inside the hook
    //   const inputRange = [
    //     (index - 1) * (_imageWidth + _spacing),
    //     index * (_imageWidth + _spacing),
    //     (index + 1) * (_imageWidth + _spacing),
    //   ];

    //   // Smoothly interpolate scale and opacity
    //   const scale = interpolate(
    //     scrollX.value,
    //     inputRange,
    //     [0.9, 1, 0.9],
    //     'clamp',
    //   );

    //   const opacity = interpolate(
    //     scrollX.value,
    //     inputRange,
    //     [0.3, 1, 0.3],
    //     'clamp',
    //   );

    //   return {
    //     transform: [{ scale }],
    //     opacity,
    //   };
    // }, [scrollX, index]); // Only memoize based on scrollX and index

    return (
      <Animated.View
        style={[
          styles.cardContainer,
          {backgroundColor: 'white'},
          // animatedStyle,
        ]}>
        <PhotoItem
          fontColor={fontColor}
          item={item}
          index={index}
          scrollX={scrollX}
        />
      </Animated.View>
    );
  },
);

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  itemContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 5,
    // marginTop: height * 0.2,
    marginTop: height * 0.05,
  },
  cardContainer: {
    width: width * 0.6,
    height: height * 0.31,
    borderRadius: moderateScale(12),
    elevation: 5,
    shadowColor: 'black',
    shadowOpacity: 0.9,
    shadowRadius: 25,
    shadowOffset: {width: 0, height: 2},
    marginTop: height * 0.07,
  },
  imageView: {
    flex: 1,
    marginTop: 10,
    borderRadius: moderateScale(12),
  },
  imageContainer: {
    width: width * 0.55,
    height: height * 0.22,
    overflow: 'hidden',
    justifyContent: 'center',
    borderRadius: moderateScale(12),
    alignSelf: 'center',
  },
  image: {
    flex: 1,
    width: '100%',
    justifyContent: 'center',
    alignSelf: 'center',
    backgroundColor: '#efefef',
  },
  textContainer: {
    marginHorizontal: margin.horizontal,
    marginTop: 10,
  },
  priceContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 6,
    width: '100%',
  },
  nameText: {},
  cancelText: {
    textDecorationLine: 'line-through',
  },
  colorTouchable: {
    padding: 3, // Adds touchable area around the color dot
  },
  colorOuterCircle: {
    width: 16,
    height: 16,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'transparent',
  },
  selectedColorOuterCircle: {
    borderColor: 'white',
  },
  colorDot: {
    width: 11,
    height: 11,
    borderRadius: 8,
  },
  colorOptions: {
    flexDirection: 'row',
  },
  likeIcon: {
    bottom: 0,
    right: 0,
    width: moderateScale(25),
    height: moderateScale(25),
  },
});

export default memo(AnimatedCard);
