import React, { useCallback, useRef, useState } from 'react';
import { View, StyleSheet, Dimensions, TouchableOpacity, ActivityIndicator } from 'react-native';
import Carousel from 'react-native-snap-carousel';
import CustomImage from '@materialComponent/image/image';
import Icon from '@materialComponent/icon/icon';
import { WH } from '@constant/contstant';
import { moderateScale } from 'react-native-size-matters';

const { height, width } = Dimensions.get('window');
const dynaimcWidthHeight = height * 0.07;
const dynaimcImageWidthHeight = height * 0.06;

const VerticalProducts = ({ data, setCurrentIndex, currentIndex, horizontal, style, imageSize, customHeight, productHeight, bottomArrowMargin }) => {
    const carouselRef = useRef(null);
    const [carouselData, setCarouselData] = useState(data.slice(0, 5)); // Start with first 5 ite
    const [isLoading, setIsLoading] = useState(false);

    // Simulate fetching more data
    const loadMoreData = () => {
        if (!isLoading && carouselData.length < data.length) {
            setIsLoading(true);
            setTimeout(() => {
                const newData = data.slice(carouselData.length, carouselData.length + 5);
                setCarouselData([...carouselData, ...newData]);
                setIsLoading(false);
            }, 1500);
        }
    };


    const renderItem = useCallback(({ item, index }) => {
        return (
            <View style={[styles.carouselItem, { height: productHeight || dynaimcWidthHeight, }]}>
                <CustomImage
                    style={{ height: index == currentIndex ? productHeight || height * 0.065 : productHeight || dynaimcImageWidthHeight, aspectRatio: 1, borderRadius: 5, overflow: "hidden" }}
                    // source={{ uri: "https://s3-alpha-sig.figma.com/img/fc7c/2bb9/f03128d44cff283af23e7cca249ddeac?Expires=1736726400&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=dHZ2P-Np4qu6huq1l3tC0vGP8ARPsUn~v7AoyT0mHhUFeBwJBXvmRrCtqI7V0vw1XtMNJ-zfmTc2O3CCGyCd25nO3kE4~I4dB5pUhskMa2Hw-qMPAYIHDGYE~-2QNNENhL4G0qWAwFJDcrpriShyavv34rGfNv337KOpjEZ9jlkEoz6qc-fnDB~PtPgY-iJpdiqqSgVbdid-pUf-Qe2G4~LbCfnNFkl1gIFQMKT1XrTKVjCaNI1lIM7ra6ndP3XN-uNr7luaF1BYR8-UMeTZ1JdZzEhVgIjY9eBUYrbf21faabI~o9MZpZxvDqVjqU0W5jYtyPS0icxzxZsuDroukg__" }}
                    source={{ uri: item.product_image_url }}
                />
            </View>
        );
    }, []);

    return (
        <View style={[horizontal ? styles.containerHorizontal : styles.container, style]}>
            <TouchableOpacity
                onPress={() => carouselRef.current.snapToPrev()}
                style={styles.arrowButton}
            >
                <Icon icon_type="MaterialIcons" name={horizontal ? "keyboard-arrow-left" : "keyboard-arrow-up"} color="white" size={moderateScale(20)} />
            </TouchableOpacity>

            <View style={[!horizontal && styles.carouselContainer, !horizontal && { height: customHeight || height * 0.3, }]}>
                <Carousel
                    ref={carouselRef}
                    data={carouselData}
                    renderItem={renderItem}
                    sliderWidth={horizontal ? width * 0.5 : undefined}
                    itemWidth={horizontal ? dynaimcWidthHeight : undefined}
                    sliderHeight={!horizontal ? customHeight || height * 0.36 : undefined}
                    itemHeight={!horizontal ? productHeight ? height * 0.06 : dynaimcWidthHeight : undefined}
                    horizontal={horizontal}
                    vertical={!horizontal}
                    inactiveSlideOpacity={0.4}
                    inactiveSlideScale={dynaimcWidthHeight}
                    activeSlideScale={0.2}
                    loop={true}
                    useScrollView
                    firstItem={2}
                    nestedScrollEnabled
                    contentContainerCustomStyle={styles.carouselContent}
                    onSnapToItem={(index) => {
                        setCurrentIndex(index);
                        if (index === 3) loadMoreData();
                    }}
                />
            </View>

            {isLoading && <ActivityIndicator size="small" color="#3498db" style={styles.loader} />}

            <TouchableOpacity
                onPress={() => carouselRef.current.snapToNext()}
                style={[styles.arrowButton, { marginVertical: bottomArrowMargin || height * 0.01, }]}
            >
                <Icon icon_type="MaterialIcons" name={horizontal ? "keyboard-arrow-right" : "keyboard-arrow-down"} color="white" size={moderateScale(20)} />
            </TouchableOpacity>
        </View>
    );
};

export default VerticalProducts;

const styles = StyleSheet.create({
    containerHorizontal: {
        flexDirection: "row",
        alignItems: 'center',
        justifyContent: 'space-between',
        // position: 'absolute',
        // bottom: height * 0.01,
        // right: 0,
    },
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        position: 'absolute',
        bottom: height * 0.06,
        right: 0,
    },
    carouselItem: {
        // backgroundColor: '#3498db',
        height: dynaimcWidthHeight,
        justifyContent: 'center',
        alignItems: 'center',
        marginVertical: 10,
        overflow: 'hidden',
    },
    arrowButton: {
        width: WH.width(7),
        aspectRatio: 1,
        backgroundColor: 'rgba(0, 0, 0, 0.6)',
        borderRadius: 180,
        justifyContent: 'center',
        alignItems: 'center',
        marginVertical: height * 0.01,
    },
    carouselContainer: {
        height: height * 0.37,
        justifyContent: 'center',
        alignItems: 'center',
    },
    carouselContent: {
        // marginBottom: 10,
    },
    loader: {
        marginVertical: 10,
    },
});
