import {useEffect, useRef, useState} from 'react';
import {Animated, Dimensions, Easing, Vibration} from 'react-native';
import useReduxStore from '@utils/hooks/useReduxStore';
import {
  _addToCart,
  _getCardItems,
  _checkout,
  _removeShop,
} from '@redux/actions/cart/cart';
import {AuthNavigating} from '@helper/reUsableMethod/reUsableMethod';
import {_cartBottomSheet} from '../../../redux/actions/common/common';
import {
  UPDATE_CART_QUANTITY,
  UPDATE_CART_QUANTITY_OPTIMISTIC,
} from '../../../redux/types/cart/cart';
import {useNavigation} from '@react-navigation/native';
import {triggerHaptic} from '../../../utils/haptic/haptic';
import {_removeCartProduct} from '../../../redux/actions/cart/cart';
import useShopifyCheckoutEvents from '../../../hooks/useShopifyCheckoutEvents';

const {fontScale, height, width} = Dimensions.get('screen');

const useCheckoutCard = ({item, index}) => {
  const [checkOutDetail, setCheckOutDetail] = useState({});
  const {shopifyCheckout} = useShopifyCheckoutEvents({checkOutDetail});
  const {getState, dispatch} = useReduxStore();
  const {cart, cart_item} = getState('cart');
  const {fetch_user_detail, token} = getState('auth');
  const [qtyLoader, setQtyLoader] = useState(false);
  const [value, setValue] = useState('');
  const refRBSheet = useRef();
  const [checkOutLoader, setCheckOutLoader] = useState(false);
  const [voucher, setVoucher] = useState({});
  const debounceTimeoutRef = useRef(null);
  const abortControllerRef = useRef(null);
  const animatedValues = [
    useRef(new Animated.Value(0)).current,
    useRef(new Animated.Value(0)).current,
    useRef(new Animated.Value(0)).current,
  ];
  const navigation = useNavigation();
  const {fetch_address} = getState('user');

  const _handleSubmit = async () => {
    triggerHaptic();
    const userLogin = AuthNavigating(); // Returns true if logged in, else navigates to Login

    if (!userLogin) {
      dispatch(_cartBottomSheet(false));
      return;
    }

    const defaultAddressItem = fetch_address.find(
      addr => addr?.address_default_select,
    );

    if (!defaultAddressItem) {
      dispatch(_cartBottomSheet(false));
      navigation.navigate('CreateAddress'); // Navigate to create address screen
      return;
    }

    setCheckOutLoader(true);

    const response = await dispatch(
      _checkout(
        item,
        fetch_user_detail?.id,
        voucher?.voucher_code,
        shopifyCheckout,
      ),
    );
    if (response) {
      setCheckOutDetail(response);
      dispatch(_cartBottomSheet(false));
    }

    setCheckOutLoader(false);
  };
  const totalPrice = item.products?.reduce((acc, productItem) => {
    const isDisabled =
      !productItem.product_variant?.product?.product_is_active ||
      !productItem.product_variant?.variant?.variant_quantity ||
      !item.shop?.shop_is_active ||
      item.shop?.shop_delisted;

    if (isDisabled) return acc; // skip disabled products

    const price = productItem.product_variant?.variant?.variant_price || 0;
    const quantity = productItem.quantity || 0;
    return acc + price * quantity;
  }, 0);

  const prices = {
    total: voucher?.voucher_value
      ? totalPrice - voucher?.voucher_value
      : totalPrice,
    subTotal: voucher?.voucher_value ? totalPrice : 0,
    discount: voucher?.voucher_value || 0,
  };

  const handleRemoveProduct = shop_id => {
    dispatch(_removeCartProduct(shop_id, cartItemId));
  };

  // UPDATE your handleQty like this:
  const handleQty = (
    shop_id,
    variantOrItemId,
    newQuantity,
    isDelete = false,
    itemId,
    prevQuantity, // <-- NEW: pass the previous UI quantity for rollback
  ) => {
    // Optimistic Redux update only for non-delete
    if (!isDelete) {
      dispatch({
        type: UPDATE_CART_QUANTITY,
        payload: {shop_id, variant_id: variantOrItemId, quantity: newQuantity},
      });
    }

    if (debounceTimeoutRef.current) clearTimeout(debounceTimeoutRef.current);
    if (abortControllerRef.current) abortControllerRef.current.abort();
    abortControllerRef.current = new AbortController();

    return new Promise(resolve => {
      debounceTimeoutRef.current = setTimeout(async () => {
        setQtyLoader(true);
        try {
          if (isDelete) {
            await dispatch(_removeCartProduct(shop_id, itemId));
          } else {
            await dispatch(
              _addToCart(shop_id, variantOrItemId, newQuantity, true, {
                signal: abortControllerRef.current.signal,
              }),
            );
          }
          resolve({ok: true, aborted: false});
        } catch (err) {
          if (err?.name === 'AbortError') {
            // do not rollback on abort; a newer request superseded this one
            resolve({ok: false, aborted: true});
          } else {
            // ❗ API FAILED → rollback Redux to prevQuantity
            if (isDelete) {
              // restore the item’s previous qty (at least 1)
              dispatch({
                type: UPDATE_CART_QUANTITY,
                payload: {
                  shop_id,
                  variant_id: variantOrItemId,
                  quantity: prevQuantity ?? 1,
                },
              });
            } else {
              dispatch({
                type: UPDATE_CART_QUANTITY,
                payload: {
                  shop_id,
                  variant_id: variantOrItemId,
                  quantity: prevQuantity,
                },
              });
            }
            // you can show a toast/snackbar here
            // showToast('Could not update quantity. Please try again.');
            resolve({ok: false, aborted: false});
          }
        } finally {
          setQtyLoader(false);
        }
      }, 100);
    });
  };

  // const handleQty = async (value, item, product) => {
  //   setQtyLoader(true);
  //   await dispatch(
  //     _addToCart(
  //       item?.shop?.shop_id,
  //       product?.product_variant?.variant?.variant_id,
  //       value,
  //     ),
  //   );
  //   await dispatch(_getCardItems());
  //   setQtyLoader(false);
  // };

  useEffect(() => {
    const startAnimation = () => {
      Animated.loop(
        Animated.stagger(
          150,
          animatedValues.map(anim =>
            Animated.sequence([
              Animated.timing(anim, {
                toValue: 1,
                duration: 300,
                easing: Easing.linear,
                useNativeDriver: false,
              }),
              Animated.timing(anim, {
                toValue: 0.5,
                duration: 300,
                easing: Easing.linear,
                useNativeDriver: false,
              }),
            ]),
          ),
        ),
      ).start();
    };

    startAnimation();
  }, []);

  const defaultAddressItem =
    fetch_address.find(item => item?.address_default_select) || false;

  const isDisabled = !item.shop?.shop_is_active || item.shop?.shop_delisted;

  return {
    token,
    qtyLoader,
    checkOutLoader,
    animatedValues,
    _handleSubmit,
    totalPrice,
    handleQty,
    defaultAddressItem,
    cart,
    value,
    setValue,
    dispatch,
    refRBSheet,
    setVoucher,
    voucher,
    prices,
    cart_item,
    setQtyLoader,
    isDisabled,
  };
};

export default useCheckoutCard;
