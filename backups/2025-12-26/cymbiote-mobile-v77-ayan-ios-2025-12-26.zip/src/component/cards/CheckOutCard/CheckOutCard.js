import React, {useEffect, useState} from 'react';
import {
  ActivityIndicator,
  Dimensions,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import {moderateScale, scale, verticalScale} from 'react-native-size-matters';
import CustomText from '@materialComponent/customText/customText';
import BrandTab from '@component/brandTab/brandTab';
import {font, shadow, WH, globalStyle} from '@constant/contstant';
import {
  _addToCart,
  _getCardItems,
  _checkout,
  _removeShop,
} from '@redux/actions/cart/cart';
import {toFixedMethod} from '@utils/helper/helper';
import CustomButton from '@materialComponent/customButton/customButton';
import CartBackgroundSvg from '@assets/images/cart_background';
import SwipeToDelete from '../../swipeToDelete/swipeToDelete';
import VariantCard from '../variantCard/variantCard';
import useCheckoutCard from './useCheckoutCard';
import BottomSheetVoucherList from '../../../materialComponent/bottomSheet/bottomSheetVoucherList';
import VoucherSvg from '@assets/images/voucher.svg';
import RedeemCheckoutSvg from '@assets/images/redeem_checkout.svg';
import Icon from '../../../materialComponent/icon/icon';
import {
  heightPercentageToDP,
  widthPercentageToDP,
} from 'react-native-responsive-screen';
import {colors} from '../../../constant/contstant';
import {
  formatPrice,
  getDeviceId,
  toFixedMethodAmount,
} from '../../../utils/helper/helper';
import {_removeCartProduct} from '../../../redux/actions/cart/cart';
import {currency} from '../../../constant/signature';

const {fontScale, height, width} = Dimensions.get('screen');

const CheckOutCard = ({item, index}) => {
  const {
    qtyLoader,
    checkOutLoader,
    _handleSubmit,
    handleQty,
    defaultAddressItem,
    dispatch,
    refRBSheet,
    setVoucher,
    voucher,
    prices,
    setQtyLoader,
    isDisabled,
  } = useCheckoutCard({item, index});

  // useEffect(() => {
  //    refRBSheet2?.current?.open()
  // },[])

  return (
    <View
      pointerEvents={isDisabled ? 'none' : 'auto'}
      style={{
        marginTop: index == 0 ? height * 0.002 : height * 0.02,
        borderRadius: 15,
        borderWidth: 0,
        elevation: 10,
        backgroundColor: 'white',
      }}>
      {/* <TouchableOpacity
        style={styles.crossIcon}
        onPress={() => dispatch(_removeShop(item.shop?.shop_id, item.cartId))}>
        <Icon
          icon_type="AntDesign"
          name="close"
          size={moderateScale(14)}
          color="white"
        />
      </TouchableOpacity> */}

      <View
        colors={['#f9fcff', '#f7fbff', '#f1f7fe', '#ebf4fe']} // Very light to soft blue
        locations={[0, 0.3, 0.7, 1]} // Gradual transition from top to bottom
        start={{x: 0.5, y: 0}} // Gradient starts from the top-center
        end={{x: 0.5, y: 1}} // Ends at bottom-center
        style={[
          styles.flatlistView,
          (item.shop?.shop_is_active === false || item.shop?.shop_delisted) && {
            opacity: 0.5,
          },
        ]}>
        {/* <View style={{ position: "absolute", top: -5, alignSelf: "center", zIndex: 1 }}>
          <CartBackgroundSvg />
        </View> */}
        {/* <View style={{ position: "absolute", top: 0, alignSelf: "center", width: 80, height: height * 0.005, backgroundColor: "black", zIndex: 2, borderRadius: 180 }} /> */}
        {/* Shop Details */}
        <View style={styles.brand}>
          <BrandTab
            disabled={!item.shop?.shop_is_active}
            item={item.shop}
            followStyle={{backgroundColor: 'black'}}
            followColor={'white'}
          />
        </View>
        {/* Products List */}
        {item.products?.map((product, index) => {
          // const filteredItems = cart
          //   .map(cartItem => ({
          //     ...cartItem,
          //     product_variant: cartItem.product_variant.filter(
          //       variant =>
          //         variant.variant_id ===
          //         product.product_variant?.variant?.variant_id,
          //     ),
          //   }))
          //   .filter(cartItem => cartItem.product_variant.length > 0);
          const variantStock =
            product?.quantity ==
            product?.product_variant?.variant.variant_quantity;
          const isDisabled =
            !product.product_variant?.product?.product_is_active ||
            !product.product_variant?.variant?.variant_quantity ||
            !item.shop?.shop_is_active ||
            item.shop?.shop_delisted;
          return product ? (
            <>
              <SwipeToDelete
                key={product.cart_item_id}
                onDelete={() =>
                  dispatch(
                    _removeCartProduct(
                      item.shop?.shop_id,
                      product?.cart_item_id,
                    ),
                  )
                }>
                <VariantCard
                  image={
                    product.product_variant?.variant?.images?.[0]?.preview
                      ?.image?.url ||
                    product.product_variant?.product?.product_image_url
                  }
                  index={index}
                  qtyLoader={qtyLoader}
                  product={product}
                  qty={product.quantity}
                  shop={item.shop}
                  cartId={item.cartId}
                  cartItemId={product?.cart_item_id}
                  variant={product.product_variant?.variant}
                  handleQty={handleQty}
                  isDisabled={isDisabled}
                  variantStock={variantStock}
                  onDecreasePress={() =>
                    !isDisabled && handleQty(-1, item, product)
                  }
                  onIncreasePress={() =>
                    !isDisabled && handleQty(1, item, product)
                  }
                  imageStyle={{width: width * 0.18, aspectRatio: 1}}
                  headingSize={fontScale * 12}
                  priceSize={fontScale * 12}
                  setQtyLoader={setQtyLoader}
                />
              </SwipeToDelete>
            </>
          ) : (
            <></>
          );
        })}

        {voucher?.voucher_id ? (
          <View style={[globalStyle.space_between, {marginTop: height * 0.02}]}>
            <View
              style={{
                width: '70%',
                borderRadius: 100,
                backgroundColor: '#E5EBFC',
                height: height * 0.04,
                paddingHorizontal: 10,
                justifyContent: 'center',
                ...globalStyle.space_between,
              }}>
              <View style={globalStyle.row}>
                <VoucherSvg width={WH.width(4)} height={WH.width(4)} />
                <CustomText
                  fontFamily={font.bold}
                  style={{marginLeft: 5}}
                  fontSize={fontScale * 12}
                  text={voucher?.voucher_code}
                />
              </View>
              <TouchableOpacity
                onPress={() => setVoucher({})}
                style={styles.close}>
                <Icon
                  icon_type={'AntDesign'}
                  name={'close'}
                  color={'white'}
                  size={moderateScale(14)}
                />
              </TouchableOpacity>
            </View>
            <View style={{width: '27%'}}>
              <CustomButton
                forceHeight={height * 0.04}
                buttonStyle={{
                  borderRadius: 180,
                  backgroundColor: 'black',
                }}
                textStyle={{fontSize: fontScale * 12}}
                text={'Applied'}
              />
            </View>
          </View>
        ) : (
          <></>
        )}
        {/* <View style={{ height: height * 0.07, flexDirection: "row", borderWidth: 1, justifyContent: "space-around", alignItems: "center", borderColor: "#0000004D", borderRadius: 180, marginTop: height * 0.02, overflow: "hidden", backgroundColor: "white" }}>
          <TextInput
            style={{ height: "100%", width: "60%", fontFamily: font.bold, fontSize: fontScale * 18, paddingLeft: 20, color: "black" }}
            placeholderTextColor={"#0000004D"}
            placeholder='Voucher Code'
          // onChangeText={(text) => setValue(text)}
          // value={value}
          />
          <View style={{ width: "30%" }}>
            <CustomButton buttonStyle={{ height: height * 0.05, width: "100%", borderRadius: 180, backgroundColor: "#000000B2", paddingBottom: 2 }} text={"Apply"} />
          </View>
        </View> */}

        <View
          style={[
            {zIndex: 1},
            defaultAddressItem ? {opacity: 1} : {opacity: 1},
          ]}>
          {/* <CartTotalSvg width={"100%"} height={160} fillColor={item?.shop?.shop_color || "#000"} /> */}
          {/* <View style={{ zIndex: 2, position: "absolute", top: 50, width: "100%", }}> */}
          {prices.subTotal ? (
            <View
              style={[globalStyle.space_between, {marginTop: height * 0.02}]}>
              <CustomText
                fontSize={fontScale * 15}
                fontFamily={font.bold}
                color={'black'}
                text={'Sub Amount'}
                textAlign="center"
              />
              {qtyLoader ? (
                <ActivityIndicator color={'red'} size={'small'} />
              ) : (
                <CustomText
                  fontSize={fontScale * 15}
                  fontFamily={font.bold}
                  color={colors.light_theme.theme}
                  text={`${item.shop?.shop_currency || currency} ${formatPrice(
                    toFixedMethod(prices.subTotal),
                  )}`}
                  textAlign="center"
                />
              )}
            </View>
          ) : (
            <></>
          )}

          {prices?.discount ? (
            <View
              style={[globalStyle.space_between, {marginTop: height * 0.01}]}>
              <CustomText
                fontSize={fontScale * 15}
                fontFamily={font.bold}
                color={'black'}
                text={'Discount'}
                textAlign="center"
              />
              {qtyLoader ? (
                <ActivityIndicator color={'white'} size={'small'} />
              ) : (
                <CustomText
                  fontSize={fontScale * 15}
                  fontFamily={font.bold}
                  color={colors.light_theme.theme}
                  text={`${item.shop?.shop_currency || 'PKR'} ${formatPrice(
                    toFixedMethod(prices?.discount),
                  )}`}
                  textAlign="center"
                />
              )}
            </View>
          ) : (
            <></>
          )}

          <View
            style={[
              globalStyle.space_between,
              {marginTop: height * 0.01, padding: height * 0.005},
            ]}>
            <CustomText
              fontSize={fontScale * 15}
              fontFamily={font.bold}
              color={'black'}
              text={'Total Amount'}
              textAlign="center"
            />
            {qtyLoader ? (
              <View style={{marginRight: 30}}>
                <ActivityIndicator
                  color={colors.light_theme.theme}
                  size="small"
                />
              </View>
            ) : (
              <CustomText
                fontSize={fontScale * 15}
                fontFamily={font.bold}
                color={colors.light_theme.theme}
                text={`${item.shop?.shop_currency || 'PKR'} ${formatPrice(
                  toFixedMethodAmount(prices?.total),
                )}`}
                textAlign="center"
              />
            )}
          </View>
          {!voucher?.voucher_id ? (
            <TouchableOpacity
              activeOpacity={1}
              onPress={() => refRBSheet?.current?.open()}
              style={{
                marginTop: height * 0.01,
                flexDirection: 'row',
                alignItems: 'center',
                padding: height * 0.005,
              }}>
              <RedeemCheckoutSvg width={WH.width(5.5)} height={WH.width(5.5)} />
              <CustomText
                fontFamily={font.medium}
                style={{marginLeft: 10}}
                fontSize={fontScale * 15}
                text={'Redeem your points'}
              />
            </TouchableOpacity>
          ) : (
            <></>
          )}

          <CustomButton
            loaderSize={'small'}
            backgroundColor={
              !item.shop?.shop_is_active || item.shop?.shop_delisted
                ? '#ff0202ff' // Disabled gray color
                : 'black' // Active black color
            }
            loader={checkOutLoader}
            buttonStyle={{
              borderRadius: 180,
              marginTop: height * 0.02,
              height: height * 0.05,
            }}
            // disabled={Boolean(!defaultAddressItem || checkOutLoader)}
            onPress={
              !item.shop?.shop_is_active || item.shop?.shop_delisted
                ? undefined
                : _handleSubmit
            }
            text={
              checkOutLoader
                ? ''
                : !item.shop?.shop_is_active || item.shop?.shop_delisted
                ? 'Store has been Delisted'
                : 'Checkout'
            }
          />
        </View>
      </View>
      <BottomSheetVoucherList
        heading={'Vouchers'}
        refRBSheet={refRBSheet}
        shop_detail={item.shop}
        setVoucher={setVoucher}
        voucher={voucher}
        orderAmount={prices?.total}
      />
    </View>
  );
};

export default CheckOutCard;

const styles = StyleSheet.create({
  image: {
    width: WH.width(20),
    aspectRatio: 1,
    borderRadius: 5,
  },
  flatlistView: {
    paddingVertical: verticalScale(20),
    paddingTop: verticalScale(10),
    paddingBottom: verticalScale(10),
    // marginTop: verticalScale(15),
    paddingHorizontal: scale(10),
    // backgroundColor: 'white',
    borderRadius: 30,
    marginTop: 2,
  },
  brand: {
    marginBottom: 10,
    // marginTop: 20,
  },
  imageView: {
    marginRight: scale(10),
  },
  textView: {
    width: WH.width(60),
    // backgroundColor: "red"
  },
  descText: {
    fontSize: fontScale * 15,
    fontFamily: font.bold,
    color: 'black',
  },
  priceText: {
    fontSize: moderateScale(13),
    fontFamily: font.bold,
    color: 'black',
  },
  actionButtons: {
    width: '30%',

    // position: 'absolute',
    // bottom: 10,
    // right: 10,
  },
  productStatus: {
    position: 'absolute',
    zIndex: 2,
    right: 10,
    top: 20,
  },
  qtyButton: {
    borderRadius: 5,
    width: width * 0.06,
    aspectRatio: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#E5EBFC',
  },
  borderLine: {
    marginLeft: 0,
    width: '95%',
    backgroundColor: '#00000033',
    height: height * 0.003,
    alignSelf: 'center',
    opacity: 0.3,
  },
  brandTabMainViewStyle: {
    // paddingHorizontal: 0,
  },
  brandTabImageStyle: {
    // width: width * 0.1,
    // height: width * 0.1,
    ...shadow,
    backgroundColor: 'white',
    // elevation: 2,
  },
  close: {
    backgroundColor: 'black',
    width: widthPercentageToDP(6),
    aspectRatio: 1,
    borderRadius: 180,
    // bottom: heightPercentageToDP(3),
    alignSelf: 'center',
    justifyContent: 'center',
    alignItems: 'center',
    ...shadow,
  },
  crossIcon: {
    position: 'absolute',
    top: 10,
    right: 10,
    zIndex: 10,
    backgroundColor: '#000',
    borderRadius: 15,
    padding: 5,
  },
});
