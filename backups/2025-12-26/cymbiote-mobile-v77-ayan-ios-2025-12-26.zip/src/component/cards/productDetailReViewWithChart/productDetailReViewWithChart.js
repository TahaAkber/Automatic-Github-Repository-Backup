import { Dimensions, FlatList, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import React, { useCallback, useState } from 'react';
import LinearGradient from 'react-native-linear-gradient';
import GiftedChart from '../../../materialComponent/pointHistoryChart/pointHistoryChart';
import ReviewGraph from '../../../materialComponent/reviewGraph/reviewGraph';
import CustomText from '../../../materialComponent/customText/customText';
import Icon from '../../../materialComponent/icon/icon';
import { colors, font, globalStyle } from '../../../constant/contstant';
import CustomImage from '../../../materialComponent/image/image';
import Carousel from 'react-native-snap-carousel';
import ProductReviewCard from '../productReviewCard/productReviewCard';
import { navigate } from '../../../utils/navigationRef/navigationRef';

const { width, height, fontScale } = Dimensions.get("screen");

const ProductDetailReViewWithChart = ({ productDetailReview, product_id }) => {
    const [active, setActive] = useState(0)

    const renderItem = useCallback(({ item, index, }) => {
        return (
            <ProductReviewCard setActive={setActive} item={item} />
        );
    }, []);


    return (
        <View style={styles.container}>
            {/* Gradient Border */}
            <ReviewGraph productDetailReview={productDetailReview} />
            {/* <ReviewGraph productDetailReview={{}} /> */}
            {(productDetailReview?.reviews || [])?.length ?
                <View style={[globalStyle.space_between, { marginTop: height * 0.02 }]}>
                    <CustomText fontSize={fontScale * 15} fontFamily={font.black} text={"Top Reviews"} />
                    <TouchableOpacity
                        onPress={() => navigate("ProductReview", { product_id })}
                    >
                        <CustomText color={colors.light_theme.theme} fontSize={fontScale * 12} fontFamily={font.bold} text={"View All"} />
                    </TouchableOpacity>
                </View> :
                <></>
            }


            {/* <View style={{ marginTop: height * 0.02 }}>
                <View style={globalStyle.row}>
                    {arr.map((item, index) => {
                        return (
                            <TouchableOpacity onPress={() => setActive(index)} style={index == active ? styles.activeTab : styles.tab}>
                                <CustomText fontFamily={font.bold} fontSize={fontScale * 12} text={item.title} />
                            </TouchableOpacity>
                        )
                    })}
                </View>
            </View> */}


            {/* <FlatList
                data={productDetailReview?.reviews?.slice(0, 10) || []}
                renderItem={renderItem}
                keyExtractor={(item, index) => index.toString()}
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={{ marginTop: height * 0.02 }}
                horizontal
            /> */}

            {/* <FlatList
                data={productDetailReview?.reviews?.slice(0, 10) || []}
                renderItem={renderItem}
                keyExtractor={(item, index) => index.toString()}
                horizontal
                pagingEnabled // 🔥 Enables snapping like a carousel
                showsHorizontalScrollIndicator={false}
                snapToAlignment="center"
                decelerationRate="fast" // makes swipe feel smooth
                contentContainerStyle={{
                    marginTop: height * 0.02,
                }}
            /> */}

            {(productDetailReview?.reviews || [])?.length ?
                <>
                    <Carousel
                        data={productDetailReview?.reviews?.slice(0, 3) || []}
                        renderItem={renderItem}
                        sliderWidth={width * 0.9}
                        itemWidth={width * 0.9}
                        inactiveSlideScale={0.94}
                        inactiveSlideOpacity={0.7}
                        autoplay={false}
                        autoplayDelay={500}
                        autoplayInterval={3000}
                        onSnapToItem={(index) => setActive(index)}
                    />

                    <View style={{ flexDirection: "row", marginTop: height * 0.02, justifyContent: "center", alignItems: "center" }}>
                        {(productDetailReview?.reviews?.slice(0, 3) || []).map((item, index) => {
                            return (
                                <View key={index} style={{ width: width * 0.02, aspectRatio: 1, borderRadius: 180, backgroundColor: index == active ? "#FF7F00" : "gray", marginRight: index == 2 ? 0 : width * 0.02 }} />
                            )
                        })}

                    </View>
                </> :
                <>
                </>
            }

        </View >
    );
};

export default ProductDetailReViewWithChart;

const styles = StyleSheet.create({
    container: {
        // flex: 1,
        // justifyContent: 'center',
        // alignItems: 'center',
        backgroundColor: 'white',

    },
    tab: {
        backgroundColor: "white",
        borderWidth: 1,
        borderColor: "#E4E9EE",
        padding: width * 0.02,
        borderRadius: 5,
        marginRight: 10
    },
    activeTab: {
        backgroundColor: "#ebebeb",
        borderWidth: 1,
        borderColor: "black",
        padding: width * 0.02,
        borderRadius: 5,
        marginRight: 10
    },
    reviewCard: {
        marginTop: height * 0.02
    }
});

const arr = [
    {
        title: "All Reviews"
    },
    {
        title: "With Photo & Video"
    },
]