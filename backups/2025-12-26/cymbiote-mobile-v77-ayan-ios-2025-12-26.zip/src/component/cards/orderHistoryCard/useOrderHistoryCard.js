import { Dimensions, StyleSheet } from 'react-native';
import { useRef, useState } from 'react';
import { margin } from '@constant/contstant';

const { height } = Dimensions.get('screen');

const useOrderHistoryCard = ({ item }) => {
  const refRBSheet = useRef();
  const refConfirmationSheet = useRef();
  const refReviewSheet = useRef();
  const refReviewFormSheet = useRef();
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [selectedOrderProduct, setSelectedOrderProduct] = useState(null);
  const [selectedOrderProductId, setSelectedOrderProductId] = useState(null);

  const getIndexStatus = () => {
    const status = item?.order_tracking?.tracking_status?.toUpperCase(); // ✅ Read from correct API property
    if (status === 'IN_PROGRESS') {
      return {
        index: 0,
        backgroundColor: '#2E7DC1',
        textColor: '#735515',
        subtitleColor: 'white',
      };
    } else if (item.orderStatus == 'Shipped') {
      return {
        index: 1,
        backgroundColor: '#FCB914',
        textColor: 'black',
        subtitleColor: '#616161   ',
      };
    } else if (item.orderStatus == 'In Transit') {
      return {
        index: 2,
        backgroundColor: '#F57F21',
        textColor: 'white',
        subtitleColor: 'white',
      };
    } else if (item.orderStatus == 'Delivered') {
      return {
        index: 3,
        backgroundColor: '#23B477',
        textColor: '#257625',
        subtitleColor: 'white',
      };
    } else if (item.orderStatus == 'Cancelled') {
      return {
        index: 4,
        backgroundColor: '#23B477',
        textColor: 'white',
        subtitleColor: 'white',
      };
    } else {
      return null;
    }
  };

  const openSheet = order => {
    setSelectedOrder(order);
    refRBSheet?.current?.open();
  };
  const openReviewSheet = item => {

    if (refReviewSheet.current) {
      setSelectedOrderProduct(item);
      refReviewSheet.current.open(); // Open the bottom sheet
    } else {
    
    }
  };
  const openReviewForm = id => {
    if (refReviewFormSheet.current) {
      setSelectedOrderProductId(id);
      refReviewFormSheet.current.open(); // Open the bottom sheet
    } else {
 
    }
  };

  return {
    getIndexStatus,
    openSheet,
    openReviewSheet,
    openReviewForm,
    selectedOrderProduct,
    setSelectedOrderProduct,
    refReviewFormSheet,
    refRBSheet,
    refReviewSheet,
    selectedOrder,
    selectedOrderProductId,
    refConfirmationSheet
  };
};

export default useOrderHistoryCard;
