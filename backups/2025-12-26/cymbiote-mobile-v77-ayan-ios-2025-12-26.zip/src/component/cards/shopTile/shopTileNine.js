import {moderateScale, verticalScale} from 'react-native-size-matters';
import Overlay from '@materialComponent/overlay/overlay';
import BrandTab from '@component/brandTab/brandTab';
import React from 'react';
import {colors, margin} from '@constant/contstant';
import {Dimensions, StyleSheet, View} from 'react-native';
import CustomBackgoundImage from '@materialComponent/image/bgImage';
import HomeHorizontalCard from '../homeHorizontalCard/homeHorizontalCard';
import Video from 'react-native-video';
import {tileLandScapeHeight} from '../../../constant/contstant';
// import CustomVideo from '../../video/video';

const {height} = Dimensions.get('window');

const ShopTileNine = ({
  item,
  index,
  activeVideoIndex,
  setActiveVideoIndex,
  showProduct,
}) => {
  return (
    <View style={{paddingHorizontal: margin.horizontal}}>
      <View
        handleTouchEnd={index => setActiveVideoIndex(index)}
        onStartShouldSetResponder={() => setActiveVideoIndex(index)}
        style={[
          {height: tileLandScapeHeight, backgroundColor: 'white'},
          index != 0 && {marginTop: verticalScale(20)},
        ]}>
        <View style={styles.backgroundImage}>
          {/* <Video
            source={{uri: item.shop_banner_url}}
            style={styles.video_view}
            resizeMode="cover"
            muted={true}
            repeat={true}
            paused={!Boolean(activeVideoIndex == index)}
          /> */}
          {/* <CustomVideo
            item={item}
            paused={!Boolean(activeVideoIndex == index)}
          /> */}

          <Overlay />
          <View style={styles.contentContainer}>
            <BrandTab light={'white'} item={item} />
          </View>
        </View>

        <View style={[styles.contentContainer]}>
          <HomeHorizontalCard
            removeLogo={true}
            horizontal={true}
            data={item.products}
            item={item}
          />
        </View>
      </View>
    </View>
  );
};

export default ShopTileNine;

const styles = StyleSheet.create({
  backgroundImage: {
    width: '100%',
    height: height * 0.35,
    zIndex: 1,
    borderRadius: moderateScale(10),
    overflow: 'hidden',
    // marginTop: verticalScale(20),
    backgroundColor: 'white',
    borderColor: colors.light_theme.darkBorderColor,
  },
  video_view: {
    justifyContent: 'center',
    alignItems: 'center',
    position: 'absolute',
    height: '100%',
    width: '100%',
    zIndex: 0,
    bottom: 0,
    right: 0,
    left: 0,
    top: 0,
  },
  imageStyle: {
    borderRadius: moderateScale(20),
    overflow: 'hidden',
  },
  contentContainer: {
    marginHorizontal: moderateScale(20),
    marginTop: verticalScale(15),
    justifyContent: 'space-between',
    flex: 1,
  },
});
