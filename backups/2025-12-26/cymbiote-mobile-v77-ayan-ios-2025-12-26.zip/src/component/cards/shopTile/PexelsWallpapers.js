import React, {memo, useMemo, useCallback, useEffect, useState} from 'react';
import {View, StyleSheet, Dimensions, TouchableOpacity} from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedScrollHandler,
  useAnimatedStyle,
  interpolate,
} from 'react-native-reanimated';
import {moderateScale} from 'react-native-size-matters';
import CustomText from '../../../materialComponent/customText/customText';
import CustomImage from '../../../materialComponent/image/image';
import BrandTab from '../../brandTab/brandTab';
import {useNavigation} from '@react-navigation/native';
import {
  defaultShopImages,
  downloadAndCacheImage,
  formatPrice,
  getImageHeightFromItem,
  showingVaraintPrice,
} from '../../../utils/helper/helper';
import {
  font,
  margin,
  noImageUrl,
  shadow,
  tileHeight,
  tileShadow,
} from '../../../constant/contstant';
import {currency} from '../../../constant/signature';
import {logHomeProductClickEvent} from '../../../helper/eventTriggers/useEventTriggers';
import Like from '../../../materialComponent/like/like';

const {width, height} = Dimensions.get('screen');

const _imageWidth = width * 0.6;
const _spacing = 12;

// -------------------- PHOTO ITEM --------------------
const PhotoItem = memo(({item, index, scrollX}) => {
  const imageSource = useMemo(() => {
    return (
      item.product_image_url_medium || item.product_image_url || noImageUrl
    );
  }, [item.product_image_url, item.product_image_url_medium]);

  return (
    <View style={styles.imageView}>
      <View style={styles.cardContainer}>
        <View style={styles.imageWrapper}>
          <CustomImage
            source={{uri: imageSource}}
            resizeMode="cover"
            style={styles.imageStyle}
          />
          <Like
            product_id={item?.product_id}
            style={styles.likeIcon}
            size={moderateScale(10)}
          />
        </View>

        <View style={{marginHorizontal: margin.horizontal}}>
          <CustomText
            text={item?.product_name}
            fontSize={14}
            style={styles.nameText}
            numberOfLines={1}
          />
          <View style={styles.priceContainer}>
            <CustomText
              text={
                item.product_variant.length > 0
                  ? `${item?.product_currency || currency} ${formatPrice(
                      showingVaraintPrice(
                        item.product_variant[0]?.variant_price,
                        item.product_variant[0]?.variant_discounted_price,
                      ).discounted_price,
                    )}`
                  : ''
              }
              fontFamily={font.medium}
              fontSize={12}
              style={{flex: 1}}
            />
            {item.product_variant?.[0]?.variant_discounted_price && (
              <CustomText
                text={`${item?.product_currency || currency} ${formatPrice(
                  showingVaraintPrice(
                    item.product_variant[0]?.variant_price,
                    item.product_variant[0]?.variant_discounted_price,
                  ).original_price,
                )}`}
                fontFamily={font.medium}
                style={[
                  styles.cancelText,
                  {flex: 1, textAlign: 'right', opacity: 0.8},
                ]}
                color="#787878"
                fontSize={12}
              />
            )}
          </View>
        </View>
      </View>
    </View>
  );
});

// -------------------- BACKDROP PHOTO --------------------
const BackDropPhoto = memo(({item, index, scrollX}) => {
  const [localUri, setLocalUri] = useState(null);

  const imageUri = useMemo(() => {
    return (
      item.product_image_url_medium || item.product_image_url || noImageUrl
    );
  }, [item.product_image_url, item.product_image_url_medium]);

  useEffect(() => {
    downloadAndCacheImage(imageUri).then(uri => {
      setLocalUri(uri);
    });
  }, [imageUri]);

  const animatedStyle = useAnimatedStyle(() => ({
    opacity: interpolate(
      scrollX.value,
      [index - 1, index, index + 1],
      [0, 1, 0],
    ),
  }));
  return (
    <Animated.View style={[StyleSheet.absoluteFill]}>
      <Animated.Image
        source={{uri: localUri}}
        style={[
          {
            flex: 1,
            width: '100%',
            borderRadius: moderateScale(20),
          },
          animatedStyle,
        ]}
        blurRadius={30}
      />
    </Animated.View>
  );
});

// -------------------- BACKDROP LIST --------------------
const BackdropList = memo(({data, scrollX}) => {
  const renderedBackdrops = useMemo(
    () =>
      data?.map((item, index) => (
        <BackDropPhoto
          key={`bg-${item.product_id}`}
          item={item}
          index={index}
          scrollX={scrollX}
        />
      )),
    [data, scrollX],
  );

  return <View style={StyleSheet.absoluteFill}>{renderedBackdrops}</View>;
});

// -------------------- MAIN COMPONENT --------------------
export const PexelsWallpapers = memo(
  ({products, item, tilePosition, markShopAsClicked}) => {
    const scrollX = useSharedValue(0);
    const navigation = useNavigation();

    const onScroll = useAnimatedScrollHandler(e => {
      scrollX.value = e.contentOffset.x / (_imageWidth + _spacing);
    });

    const [productHeights, setProductHeights] = useState([]);

    useEffect(() => {
      if (!products || products.length === 0) return; // 👈 guard clause
      const loadHeights = async () => {
        const heightsMap = {};

        await Promise.all(
          products.map(async item => {
            try {
              const imageUrl = defaultShopImages(item)?.[0];
              const height = await getImageHeightFromItem(imageUrl);
              heightsMap[item.product_id] = height;
            } catch (err) {
              console.error('Failed to get height for', item, err);
            }
          }),
        );

        setProductHeights(heightsMap);
      };

      loadHeights();
    }, [products]);

    const renderItem = useCallback(
      ({item: productItem, index: productIndex}) => {
        const handleProductPress = async () => {
          if (item && tilePosition !== undefined) {
            await logHomeProductClickEvent(
              productItem,
              item,
              productIndex,
              tilePosition,
            );
          }

          if (markShopAsClicked && item?.shop_id) {
            markShopAsClicked(item.shop_id);
          }

          navigation.navigate('ProductDetail', {
            product_id: productItem.product_id,
            shop_id: productItem.product_shop_id,
            default_images: defaultShopImages(productItem),
            height: productHeights[productItem?.product_id],
          });
        };

        return (
          <TouchableOpacity
            activeOpacity={1}
            onPress={handleProductPress}
            style={{
              width: _imageWidth,
              height: height * 0.48,
              marginTop: height * 0.2,
            }}>
            <PhotoItem
              item={productItem}
              index={productIndex}
              scrollX={scrollX}
            />
          </TouchableOpacity>
        );
      },
      [
        navigation,
        scrollX,
        item,
        tilePosition,
        markShopAsClicked,
        productHeights,
      ],
    );

    return (
      <View style={styles.center}>
        <BackdropList data={products} scrollX={scrollX} />
        <View
          style={{
            width: width * 0.85,
            overflow: 'hidden',
            justifyContent: 'center',
            alignSelf: 'center',
          }}>
          <BrandTab
            item={item}
            shopNameFontSize={12.5}
            tilePosition={tilePosition}
            markShopAsClicked={markShopAsClicked}
          />
        </View>
        <Animated.FlatList
          data={products}
          keyExtractor={item => item?.product_id?.toString()}
          renderItem={renderItem}
          horizontal
          snapToInterval={_imageWidth + _spacing}
          decelerationRate="fast"
          showsHorizontalScrollIndicator={false}
          onScroll={onScroll}
          scrollEventThrottle={16}
          initialNumToRender={3}
          maxToRenderPerBatch={3}
          windowSize={5}
          contentContainerStyle={{
            gap: _spacing,
            paddingHorizontal: width * 0.14,
            alignItems: 'center',
            paddingTop: height * 0.1,
          }}
        />
      </View>
    );
  },
);

// -------------------- STYLES --------------------
const styles = StyleSheet.create({
  center: {
    flex: 1,
    justifyContent: 'space-between',
    paddingVertical: width * 0.04,
    alignItems: 'center',
    borderColor: '#f7f7f7',
    borderRadius: moderateScale(40),
    height: tileHeight,
    borderWidth: 1,
  },
  imageView: {},
  cardContainer: {
    width: _imageWidth,
    height: height * 0.32,
    borderRadius: moderateScale(12),
    borderWidth: 1,
    borderColor: '#f7f7f7',
    backgroundColor: 'white',
    alignSelf: 'baseline',
    ...shadow,
    elevation: 5,
  },
  imageWrapper: {
    width: width * 0.52,
    height: height * 0.21,
    overflow: 'hidden',
    justifyContent: 'center',
    alignSelf: 'center',
    margin: 15,
    borderRadius: moderateScale(15),
  },
  imageStyle: {
    flex: 1,
    width: '100%',
    justifyContent: 'center',
    alignSelf: 'center',
  },
  nameText: {},
  priceContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 6,
  },
  cancelText: {
    textDecorationLine: 'line-through',
  },
  likeIcon: {
    // bottom: 0,
    // right: 0,
    // width: moderateScale(25),
    // height: moderateScale(25),
    // backgroundColor:"red"
  },
});
