import {moderateScale, verticalScale} from 'react-native-size-matters';
import BrandTab from '@component/brandTab/brandTab';
import React from 'react';
import {colors, WH} from '@constant/contstant';
import {Dimensions, StyleSheet, View} from 'react-native';
import CustomBackgoundImage from '@materialComponent/image/bgImage';
import HomeHorizontalCard from '../homeHorizontalCard/homeHorizontalCard';
import CategoryCard from '../categoryCard/categoryCard';
import {shadow} from '@constant/contstant';
import {margin, tileBasicHeight, tileHeight} from '../../../constant/contstant';
import ShopTileCategories from '../../shopTIleCategories/shopTIleCategories';

const {width, height} = Dimensions.get('window');

const ShopTileTen = ({item, index}) => {
  return (
    <View
      style={[
        index != 0 && {marginTop: verticalScale(20)},
        {
          // width: "100%",
          height: item?.filters?.length ? tileHeight : tileBasicHeight,
          justifyContent: 'space-evenly',
          borderTopWidth: 1,
          borderBottomWidth: 1,
          borderColor: colors.light_theme.borderColor,
          marginHorizontal: margin.horizontal,
          borderWidth: 1,
          borderRadius: moderateScale(20),
          overflow: 'hidden',
        },
      ]}>
      <View style={[styles.backgroundImage]} resizeMode="cover">
        <View style={{marginHorizontal: moderateScale(10)}}>
          <BrandTab
            mainViewStyle={{
              marginBottom: 0,
              paddingHorizontal: moderateScale(0),
            }}
            followColor={'white'}
            followStyle={{backgroundColor: 'black'}}
            item={item}
          />
        </View>
      </View>
      {item?.filters?.length ? (
        <View style={[styles.contentContainer]}>
          <ShopTileCategories item={item?.filters} />
        </View>
      ) : (
        <></>
      )}

      <View style={[styles.contentContainer]}>
        <CategoryCard horizontal={true} data={item.products} item={item} />
      </View>
    </View>
  );
};

export default ShopTileTen;

const styles = StyleSheet.create({
  backgroundImage: {
    // width: '100%',
    // height: height * 0.3,
    zIndex: 1,
    borderRadius: moderateScale(10),
    overflow: 'hidden',
    // marginTop: verticalScale(20),
    backgroundColor: 'white',
    borderColor: colors.light_theme.darkBorderColor,
    // marginHorizontal: width * 0.01,
  },
  imageStyle: {
    borderRadius: moderateScale(20),
    overflow: 'hidden',
  },
  contentContainer: {
    // marginHorizontal: moderateScale(20),
    // marginTop: verticalScale(15),
    // justifyContent: 'space-between',
    // alignItems:"center"
  },
});
