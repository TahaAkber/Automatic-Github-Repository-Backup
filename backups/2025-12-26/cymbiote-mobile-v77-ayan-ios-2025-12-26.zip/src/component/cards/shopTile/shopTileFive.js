import {moderateScale, verticalScale} from 'react-native-size-matters';
import Overlay from '@materialComponent/overlay/overlay';
import BrandTab from '@component/brandTab/brandTab';
import React from 'react';
import {colors, margin} from '@constant/contstant';
import {Dimensions, StyleSheet, View, Animated, Pressable} from 'react-native';
import CustomBackgoundImage from '@materialComponent/image/bgImage';
import HomeHorizontalCard from '../homeHorizontalCard/homeHorizontalCard';
import {isAndroid, tileHeight, tileShadow} from '../../../constant/contstant';
import {navigate} from '../../../utils/navigationRef/navigationRef';
import useTilePressAnimation from './useTilePressAnimation';

const {height} = Dimensions.get('window');

const ShopTileFive = ({item, index, markShopAsClicked}) => {
  const {scale, pressHandlers} = useTilePressAnimation();

  return (
    <Animated.View
      style={[{paddingHorizontal: margin.horizontal}, {transform: [{scale}]}]}>
      <Pressable
        {...pressHandlers}
        onPress={() => navigate('Brand', {shop_id: item.shop_id, shop: item})}
        style={{flex: 1}}>
        <CustomBackgoundImage
          style={[
            index != 0 && {marginTop: verticalScale(20)},
            styles.backgroundImage,
          ]}
          imageStyle={styles.imageStyle}
          source={{
            uri: item.shop_banner_url,
          }}
          resizeMode="cover">
          <Overlay />
          <View style={styles.contentContainer}>
            <BrandTab
              light={'white'}
              item={item}
              shopNameFontSize={12.5}
              tilePosition={index}
              markShopAsClicked={markShopAsClicked}
            />
          </View>
          <HomeHorizontalCard
            horizontal={true}
            data={item.products}
            item={item}
            tilePosition={index}
            markShopAsClicked={markShopAsClicked}
          />
        </CustomBackgoundImage>
      </Pressable>
    </Animated.View>
  );
};

export default React.memo(ShopTileFive);

const styles = StyleSheet.create({
  backgroundImage: {
    width: '100%',
    height: tileHeight,
    zIndex: 1,
    borderRadius: moderateScale(20),
    overflow: 'hidden',
    // marginTop: verticalScale(20),
    backgroundColor: 'white',
    borderColor: colors.light_theme.darkBorderColor,
    elevation: 10,
    // paddingHorizontal: margin.horizontal
  },
  imageStyle: {
    borderRadius: moderateScale(20),
    overflow: 'hidden',
  },
  contentContainer: {
    marginHorizontal: moderateScale(10),
    marginTop: verticalScale(12),
    justifyContent: 'space-between',
    flex: 1,
  },
});
