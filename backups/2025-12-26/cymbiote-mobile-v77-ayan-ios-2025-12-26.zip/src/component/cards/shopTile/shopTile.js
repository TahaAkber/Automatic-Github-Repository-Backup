import React from 'react';
import {Dimensions, View} from 'react-native';
import ShopTileOne from './shopTileOne';
import ShopTileFour from './shopTileFour';
import ShopTileFive from './shopTileFive';
import ShopTileSix from './shopTileSix';
import ShopTileTwelve from './shopTileTwelve';
import ShopTileWithCarousel from './shopTileWithCarousel';
import ReelList from '../reelCard/reelList';

const {width} = Dimensions.get('screen');

// const tileComponents = {
//   1: ShopTileSix,
//   2: ShopTileSix,
//   4: ShopTileSix,
//   6: ShopTileSix,
//   7: ShopTileSix,
//   9: ShopTileSix,
//   10: ReelList,
// };
const tileComponents = {
  1: ShopTileWithCarousel,
  2: ShopTileTwelve,
  4: ShopTileFour,
  6: ShopTileFive, // airkart
  7: ShopTileOne, // haier
  9: ShopTileSix,
  10: ReelList,
};
const {height} = Dimensions.get('screen');

// const ShopTile = React.memo(({ item, index }) => {
//   return renderTile(item, index);
// });
//  Helper function
const ShopTile = React.memo(
  ({item, index, logShopTileView, logShopTileViewEnd, markShopAsClicked}) => {
    const TileComponent = tileComponents[item?.shop_tile_type];
    return TileComponent ? (
      <View style={index == 0 && {marginTop: height * 0.02}}>
        <TileComponent
          item={item}
          index={index}
          key={item?.shop_id}
          logShopTileView={logShopTileView}
          logShopTileViewEnd={logShopTileViewEnd}
          markShopAsClicked={markShopAsClicked}
        />
      </View>
    ) : null;
  },
);

export default React.memo(ShopTile);
