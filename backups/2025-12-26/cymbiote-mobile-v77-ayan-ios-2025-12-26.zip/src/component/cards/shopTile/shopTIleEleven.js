import { moderateScale, verticalScale } from 'react-native-size-matters';
import Overlay from '@materialComponent/overlay/overlay';
import BrandTab from '@component/brandTab/brandTab';
import React from 'react';
import { colors, margin } from '@constant/contstant';
import {
    Dimensions,
    FlatList,
    StyleSheet,
    View,
} from 'react-native';
import CustomBackgoundImage from '@materialComponent/image/bgImage';
import HomeHorizontalCard from '../homeHorizontalCard/homeHorizontalCard';
import CustomImage from '../../../materialComponent/image/image';
import CustomText from '../../../materialComponent/customText/customText';
import { font, globalStyle, shadow } from '../../../constant/contstant';
import Like from '../../../materialComponent/like/like';

const { height, width, fontScale } = Dimensions.get('window');


const Content = ({ item, index }) => {
    return (
        <View style={[styles.backgroundImage]}>
            <View style={styles.contentContainer}>
                <View style={styles.imageWrapper}>
                    <CustomBackgoundImage
                        source={{ uri: "https://s3-alpha-sig.figma.com/img/124f/6015/c9d10039a29167d9d0c0ad76c41eb591?Expires=1737331200&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=bScXClJ02VbixeEoXft5dAmckE0K7f2e6e3avWEciaba2d8-I7MtQ4jI3Ne23VZeJVR4-ycWYVvYRY4J3H~nsWQrzPVbtFoNe0mkRq8tWOOyHsPN9UDcJHgNFsmpkySeI8M9lZJLPRRdn6OE31Bj2nrWJrVqbIkbW5TTpc6wPsONCutWctEyNkCNpj6U13M8DUYqhJfNSf8EwXlqz7URdQFG4J6XKB2ozd-Ky9yqJQS1gYFHPPC8jZ0FQls9655A6saNgn~g3JpTVjOAnid7wWw~2yoknJRJTk9QQBxrxjHn4QAZV0kDPfknPWxCbN~sTT8v2sbabxvVoZw9GdihEw__" }}
                        style={styles.customImageStyle}
                        size={"small"}
                        imageStyle={styles.imageBorderRadius}>
                        <CustomText
                            color={"white"}
                            fontSize={fontScale * 9}
                            text={"Super Cropped Fitted Polo"}
                        />
                        <View style={styles.priceAndLikeContainer}>
                            <CustomText
                                fontFamily={font.bold}
                                color={"white"}
                                fontSize={fontScale * 10}
                                text={"$17.90"}
                            />
                            <Like
                                style={styles.likeIcon}
                                size={moderateScale(10)}
                            />
                        </View>
                    </CustomBackgoundImage>
                    <CustomBackgoundImage
                        source={{ uri: "https://s3-alpha-sig.figma.com/img/3ad6/5535/3543163e7923ed0879a6a43a2d0874d2?Expires=1736726400&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=neQhaHbXIrlzz7WTJAICJPRhd3HXcMQMLqUJ3HxxOQL~Dj2y3oFYaYW1njFTZ-C5QQlq5uBG0TYMluBIQt5XuZqN-7YBn1cb-Xbd~aLoJjsLt3iUYTH83Y9af9zHbDMLgjeGhHCBVCYIbpNreqquMMfxjobmwIn7XikDo3c6CspjWzkqtttDjjKRrOE4cyOQWlwlTylT7e~xwCUVVr7vcnJ7sYu0ss2fkLMrW2cmKcCtMKC~kNawHliCyqfoPo4zo0R8xe0BQXfRs4-AChHLu46zHgGyGLSDDrgQ0nXNttjnL45EVOuaj0Xxwf0BfcTRb7f1oqQav-dPfDXCAdTJ2Q__" }}
                        style={styles.customImageStyle}
                        size={"small"}
                        imageStyle={styles.imageBorderRadius}>
                        <CustomText
                            color={"white"}
                            fontSize={fontScale * 9}
                            text={"Super Cropped Fitted Polo"}
                        />
                        <View style={styles.priceAndLikeContainer}>
                            <CustomText
                                fontFamily={font.bold}
                                color={"white"}
                                fontSize={fontScale * 10}
                                text={"$17.90"}
                            />
                            <Like
                                style={styles.likeIcon}
                                size={moderateScale(10)}
                            />
                        </View>
                    </CustomBackgoundImage>
                    <CustomBackgoundImage
                        source={{ uri: "https://s3-alpha-sig.figma.com/img/4255/c3d5/5af4d2bf5fb32d96303a1780d9473aed?Expires=1737331200&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=SCz9QCzuiDbbSBm7aAr6EIAnYpJSSQcuJb~5kEWjeplQ6MnoT8cblx~0MP5lcat6ZeH2kjKHGZwJHkmVklDem6Dq3iLFMVaNpgId1RY-jUfTWWFoRB-rz~ip3z~7YlrJ6Kq6IMY0cqjVfa5d26Ksp19jN3t9DCefVsSSRdyc~6J2gX1zWoHXlux5RPAaY4~HAlUiHWZyuHQnzo8DP45ejA2cUb0foN180XEEUUts3aD6XsiR4KkvjXWWZoSS9wqhcG8HfEvvnDdgAAqtv1FWzOhsSgNHrnY7kcH-D7lHo6D0rDYcWMyZiTlsxeksMxVPLTCFcAxifLUYOJIoCKhTAQ__" }}
                        style={[styles.customImageStyle, { marginTop: height * 0.01 }]}
                        size={"small"}
                        imageStyle={styles.imageBorderRadius}>
                        <CustomText
                            color={"white"}
                            fontSize={fontScale * 9}
                            text={"Super Cropped Fitted Polo"}
                        />
                        <View style={styles.priceAndLikeContainer}>
                            <CustomText
                                fontFamily={font.bold}
                                color={"white"}
                                fontSize={fontScale * 10}
                                text={"$17.90"}
                            />
                            <Like
                                style={styles.likeIcon}
                                size={moderateScale(10)}
                            />
                        </View>
                    </CustomBackgoundImage>
                    <CustomBackgoundImage
                        source={{ uri: "https://s3-alpha-sig.figma.com/img/991d/8877/42cbc5607a00b934ce15f45148471e12?Expires=1737331200&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=dyVbtRuaSpW6IDaq3MK4Vne84BGrvezcEo2~M8kXK~jr61radEZHd5FEXUCX~GjJsH~sTiRG7TRMd57myLRpm8hoLAgHwlsJsa6-uj~ApBXu7eCQ9GfslHg-Zn-v1tqCQ5Km-rrHbedLRI7zsz2lTQcW0P~hY7XEZ9tYOoXJO3m4XV9bMmjWCdxldF7gVxHSE01SLlJYgGzEpzE-b7gJSe8qfd59rE2FlqCm8ADq2vcok7sYnxAmcf-YJCuw33kx77cC8amHeJZLxQKfmaSHF8Wi1dj8CUVu2sdnaSOfnF8AtkZQ5iJnbVC82rRklNyEjAcUFVrAXu98U8Lwg1svrw__" }}
                        style={[styles.customImageStyle, { marginTop: height * 0.01 }]}
                        size={"small"}
                        imageStyle={styles.imageBorderRadius}>
                        <CustomText
                            color={"white"}
                            fontSize={fontScale * 9}
                            text={"Super Cropped Fitted Polo"}
                        />
                        <View style={styles.priceAndLikeContainer}>
                            <CustomText
                                fontFamily={font.bold}
                                color={"white"}
                                fontSize={fontScale * 10}
                                text={"$17.90"}
                            />
                            <Like
                                style={styles.likeIcon}
                                size={moderateScale(10)}
                            />
                        </View>

                    </CustomBackgoundImage>
                </View>
                <View style={styles.brandTabContainer}>
                    <BrandTab
                        shopNameFontSize={fontScale * 8}
                        mainViewStyle={styles.brandTabMainViewStyle}
                        imageStyle={styles.brandTabImageStyle}
                        item={item}
                        followStyle={{ backgroundColor: "black" }}
                        followColor={"white"}
                    />
                </View>
            </View>
        </View>
    );
};
const ShopTileEleven = ({ item, index }) => {
    return (
        <View style={index != 0 && { marginTop: verticalScale(20), paddingHorizontal: margin.horizontal }}>
            <CustomText
                // marginTop={verticalScale(10)}
                fontFamily={font.bold}
                fontSize={moderateScale(22)}
                text={"New Arrivals"}
            />
            <FlatList data={[1, 2, 3, , 4]}
                horizontal
                contentContainerStyle={{ marginTop: height * 0.03, paddingBottom: 5 }}
                renderItem={({ e, v }) => {
                    return (
                        <Content item={item} />
                    )
                }}
            />
        </View>
    );
};

export default ShopTileEleven;

const styles = StyleSheet.create({
    backgroundImage: {
        width: width * 0.55,
        zIndex: 1,
        borderRadius: moderateScale(10),
        overflow: 'hidden',
        backgroundColor: 'white',
        ...shadow,
        elevation: 1,
        justifyContent: "center",
        alignItems: "center",
        paddingTop: height * 0.01,
        borderWidth: 1,
        borderCurve: "continuous",
        borderColor: colors.light_theme.borderColor,
        borderBottomWidth: 0,
        marginRight: width * 0.02,
        // paddingHorizontal: width * 0.05,
        // paddingHorizontal: width * 0.02,
    },
    imageStyle: {
        borderRadius: moderateScale(20),
        overflow: 'hidden',
    },
    contentContainer: {
        justifyContent: 'space-between',
        flex: 1,
    },
    imageWrapper: {
        width: width * 0.5,
        flexDirection: 'row',
        flexWrap: 'wrap',
        justifyContent: 'space-between',
    },
    customImageStyle: {
        // marginTop: height * 0.01,
        width: width * 0.24,
        aspectRatio: 1,
        justifyContent: 'flex-end',
        paddingVertical: height * 0.01,
        paddingHorizontal: width * 0.02,
        overflow: 'hidden',
        borderRadius: 10,
    },
    imageBorderRadius: {
        borderRadius: 10,
    },
    priceAndLikeContainer: {
        ...globalStyle.space_between,
        marginTop: height * 0.002,
    },
    likeIcon: {
        bottom: 0,
        right: 0,
        width: moderateScale(18),
        height: moderateScale(18),
    },
    brandTabContainer: {
        marginTop: height * 0.02,
        width: width * 0.5
    },
    brandTabMainViewStyle: {
        paddingHorizontal: 0,
    },
    brandTabImageStyle: {
        width: width * 0.1,
        height: width * 0.1,
        ...shadow,
        backgroundColor: 'white',
        elevation: 2,
    },
});
