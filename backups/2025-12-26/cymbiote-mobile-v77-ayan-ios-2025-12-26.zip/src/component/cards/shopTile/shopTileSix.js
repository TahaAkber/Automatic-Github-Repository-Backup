import {moderateScale, verticalScale} from 'react-native-size-matters';
import Overlay from '@materialComponent/overlay/overlay';
import BrandTab from '@component/brandTab/brandTab';
import React from 'react';
import {colors, margin} from '@constant/contstant';
import Video from 'react-native-video';
import {Dimensions, StyleSheet, View, Animated, Pressable} from 'react-native';
import HomeHorizontalCard from '../homeHorizontalCard/homeHorizontalCard';
import {isAndroid, tileHeight, tileShadow} from '../../../constant/contstant';
import {navigate} from '../../../utils/navigationRef/navigationRef';
import CustomVideo from '../../video/video';
import useReduxStore from '../../../utils/hooks/useReduxStore';
import useTilePressAnimation from './useTilePressAnimation';
// import CustomVideo from '../../video/video';

const {height, fontScale} = Dimensions.get('window');

const ShopTileSix = ({
  item,
  index,
  // activeVideoIndex,
  setActiveVideoIndex,
  showProduct,
  markShopAsClicked,
}) => {
  const {getState} = useReduxStore();
  const {activeVideoIndex} = getState('common');
  const {scale, pressHandlers} = useTilePressAnimation();

  return (
    <Animated.View
      style={[{paddingHorizontal: margin.horizontal}, {transform: [{scale}]}]}>
      <Pressable {...pressHandlers} style={{flex: 1}}>
        <View
          // handleTouchEnd={index => setActiveVideoIndex(index)}
          onStartShouldSetResponder={() => setActiveVideoIndex(index)}
          style={[
            styles.video_container,
            index != 0 && {marginTop: verticalScale(20)},
          ]}>
          <Pressable
            {...pressHandlers}
            onPress={() =>
              navigate('Brand', {shop_id: item.shop_id, shop: item})
            }
            style={{flex: 1}}>
            <CustomVideo item={item} paused={activeVideoIndex !== index} />
            <View style={styles.contentContainer}>
              <BrandTab
                light={'white'}
                item={item}
                shopNameFontSize={12.5}
                tilePosition={index}
                markShopAsClicked={markShopAsClicked}
              />
            </View>
            <HomeHorizontalCard
              horizontal={true}
              data={item.products}
              item={item}
              tilePosition={index}
              markShopAsClicked={markShopAsClicked}
            />
          </Pressable>
        </View>
      </Pressable>
    </Animated.View>
  );
};

export default React.memo(ShopTileSix);

const styles = StyleSheet.create({
  video_container: {
    borderRadius: moderateScale(20),
    height: tileHeight,
    borderColor: colors.light_theme.darkBorderColor,
    backgroundColor: 'black',
    position: 'relative',
    overflow: 'hidden',
    // marginTop:20,
    width: '100%',
    flex: 1,
    elevation: 10,
    // paddingHorizontal: margin.horizontal
  },
  video_view: {
    justifyContent: 'center',
    alignItems: 'center',
    position: 'absolute',
    height: '100%',
    width: '100%',
    zIndex: 0,
    bottom: 0,
    right: 0,
    left: 0,
    top: 0,
  },
  contentContainer: {
    marginHorizontal: moderateScale(10),
    marginTop: verticalScale(12),
    justifyContent: 'space-between',
    flex: 1,
  },
});
