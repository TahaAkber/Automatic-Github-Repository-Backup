import React from 'react';
import {Animated, View, StyleSheet, Dimensions, Pressable} from 'react-native';
import {moderateScale, verticalScale} from 'react-native-size-matters';
import {colors, margin} from '@constant/contstant';
import CustomBackgoundImage from '@materialComponent/image/bgImage';
import LinearGradient from 'react-native-linear-gradient';
import Overlay from '@materialComponent/overlay/overlay';
import AnimatedCard from '../homeVerticalCard/animatedCard';
import BrandTab from '@component/brandTab/brandTab';
import {PexelsWallpapers} from './PexelsWallpapers';
import {isAndroid, tileShadow} from '../../../constant/contstant';
import useTilePressAnimation from './useTilePressAnimation';
import {navigate} from '../../../utils/navigationRef/navigationRef';

const {height} = Dimensions.get('window');
const tileHeight = height * 0.3; // Adjust tile height as per your design

// Memoize the ShopTileWithCarousel component to avoid re-renders unless necessary
const ShopTileWithCarousel = React.memo(
  ({item, index, activeVideoIndex, setActiveVideoIndex, markShopAsClicked}) => {
    const {scale, pressHandlers} = useTilePressAnimation();

    return (
      <Animated.View
        style={[
          {paddingHorizontal: margin.horizontal},
          {transform: [{scale}]},
        ]}>
        <Pressable
          {...pressHandlers}
          onPress={() => navigate('Brand', {shop_id: item.shop_id, shop: item})}
          style={{flex: 1}}>
          <View
            style={[
              styles.video_container,
              index !== 0 && {marginTop: verticalScale(20)},
            ]}>
            <PexelsWallpapers
              products={item.products}
              item={item}
              tilePosition={index}
              markShopAsClicked={markShopAsClicked}
            />
          </View>
        </Pressable>
      </Animated.View>
    );
  },
);

const styles = StyleSheet.create({
  backgroundImage: {
    width: '100%',
    height: tileHeight,
    zIndex: 1,
    borderRadius: moderateScale(20),
    overflow: 'hidden',
    backgroundColor: 'white',
    borderColor: colors.light_theme.darkBorderColor,
    ...tileShadow,
  },
  imageStyle: {
    borderRadius: moderateScale(20),
    overflow: 'hidden',
  },
  contentContainer: {
    marginHorizontal: moderateScale(20),
    marginTop: verticalScale(15),
    justifyContent: 'space-between',
    flex: 1,
    borderRadius: moderateScale(20),
  },
});

export default React.memo(ShopTileWithCarousel);
