import { useRef, useState } from 'react';

const useShopTile = () => {
  const [follow, setFollow] = useState(false);
  const [paused, setPaused] = useState(false);
  const refRBSheet = useRef(null);

  return {
    setFollow,
    setPaused,
    refRBSheet,
    follow,
    paused,
  };
};

export default useShopTile;
