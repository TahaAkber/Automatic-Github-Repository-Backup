import {moderateScale, verticalScale} from 'react-native-size-matters';
import Overlay from '@materialComponent/overlay/overlay';
import BrandTab from '@component/brandTab/brandTab';
import React from 'react';
import {colors, WH} from '@constant/contstant';
import Video from 'react-native-video';
import {Dimensions, StyleSheet, View, Animated, Pressable} from 'react-native';
import HomeVerticalCard from '../homeVerticalCard/homeVerticalCard';
import {margin} from '@constant/contstant';
import {isAndroid, tileHeight, tileShadow} from '../../../constant/contstant';
import {navigate} from '../../../utils/navigationRef/navigationRef';
import AnimatedCard from '../homeVerticalCard/animatedCard';
import LinearGradient from 'react-native-linear-gradient';
import CustomVideo from '../../video/video';
import useReduxStore from '../../../utils/hooks/useReduxStore';
import useTilePressAnimation from './useTilePressAnimation';
// import CustomVideo from '../../video/video';

const {height, width} = Dimensions.get('window');

const ShopTileOne = ({
  item,
  index,
  // activeVideoIndex,
  setActiveVideoIndex,
  showProduct,
  markShopAsClicked,
}) => {
  const {getState} = useReduxStore();
  const {scale, pressHandlers} = useTilePressAnimation();

  const shopColor = item?.shop_color;
  const fontColor = item?.shop_font_color;
  const lightenColor = (color, percent) => {
    // Convert hex to RGB
    const amt = Math.round(2.55 * percent);
    const num = parseInt(color.replace('#', ''), 16);
    const R = (num >> 16) + amt;
    const G = ((num >> 8) & 0x00ff) + amt;
    const B = (num & 0x0000ff) + amt;

    return `rgba(${R},${G},${B},0.5)`; // Adding some transparency
  };
  const {activeVideoIndex} = getState('common');

  const lighterShopColor = lightenColor(shopColor, 30); // Lighten by 30%
  return (
    <Animated.View
      style={[{paddingHorizontal: margin.horizontal}, {transform: [{scale}]}]}>
      <Pressable
        {...pressHandlers}
        style={[
          styles.video_container,
          index != 0 && {marginTop: verticalScale(20)},
        ]}
        onPress={() => navigate('Brand', {shop_id: item.shop_id, shop: item})}>
        {/* <Video
            source={{uri: item.shop_banner_url}}
            // source={require("../../../assets/images/video.mp4")}
            style={styles.video_view}
            resizeMode="cover"
            muted={true}
            repeat={true}
            autoplay={true}
            // paused={!Boolean(activeVideoIndex == index)} // Pause the video when it's not the active one
          /> */}
        <CustomVideo item={item} paused={activeVideoIndex !== index} />
        {/* <LinearGradient
          colors={[
            'rgba(200, 199, 202, 0)',
            'rgba(200, 199, 202, 0.3)',
            'rgb(196, 191, 193)',
            'rgb(95, 95, 95)',
          ]}
          locations={[0.3, 0.4, 0.7, 1]}
          start={{x: 0.5, y: 0}}
          end={{x: 0.5, y: 1}}
          style={styles.gradientOverlay}
        /> */}

        <LinearGradient
          colors={['transparent', lighterShopColor, shopColor]}
          locations={[0.5, 0.8, 1]}
          start={{x: 0.5, y: 0}}
          end={{x: 0.5, y: 1}}
          style={styles.gradientOverlay}
        />
        <Overlay />
        {/* <View style={styles.contentContainer}>
            <BrandTab light={'white'} item={item} />
            <HomeVerticalCard data={item.products} item={item} />
          </View> */}
        <View style={styles.contentContainer}>
          <View style={{marginHorizontal: width * 0.03}}>
            <BrandTab
              light={'white'}
              item={item}
              shopNameFontSize={12.5}
              tilePosition={index}
              markShopAsClicked={markShopAsClicked}
            />
          </View>

          <AnimatedCard
            products={item.products}
            item={item}
            backgroundColor={shopColor}
            fontColor={fontColor}
            tilePosition={index}
            markShopAsClicked={markShopAsClicked}
          />
        </View>
      </Pressable>
    </Animated.View>
  );
};

export default React.memo(ShopTileOne);

const styles = StyleSheet.create({
  video_container: {
    borderRadius: moderateScale(20),
    height: tileHeight,
    borderColor: colors.light_theme.darkBorderColor,
    backgroundColor: 'white',
    position: 'relative',
    overflow: 'hidden',
    // borderWidth: 1,
    width: '100%',
    flex: 1,
    elevation: 10,
    // marginTop:20
  },
  video_view: {
    justifyContent: 'center',
    alignItems: 'center',
    position: 'absolute',
    height: '100%',
    width: '100%',
    zIndex: 0,
    bottom: 0,
    right: 0,
    left: 0,
    top: 0,
  },
  contentContainer: {
    // marginHorizontal: moderateScale(20),
    marginTop: verticalScale(12),
    justifyContent: 'space-between',
    flex: 1,
  },
  gradientOverlay: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    borderRadius: moderateScale(20),
  },
});
