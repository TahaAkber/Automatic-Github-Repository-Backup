import React, {memo} from 'react';
import {Animated, View, StyleSheet, Dimensions, Pressable} from 'react-native';
import {moderateScale, verticalScale} from 'react-native-size-matters';
import CustomBackgoundImage from '@materialComponent/image/bgImage';
import LinearGradient from 'react-native-linear-gradient';
import Overlay from '@materialComponent/overlay/overlay';
import AnimatedCard from '../homeVerticalCard/animatedCard';
import BrandTab from '@component/brandTab/brandTab';
import {colors, margin} from '@constant/contstant';
import {isAndroid, tileHeight, tileShadow} from '../../../constant/contstant';
import useTilePressAnimation from './useTilePressAnimation';
import {navigate} from '../../../utils/navigationRef/navigationRef';

const {height} = Dimensions.get('window');

// Memoize the ShopTileFour component
const ShopTileFour = React.memo(({item, index, markShopAsClicked}) => {
  const shopColor = item?.shop_color;
  const fontColor = item?.shop_font_color;

  // Use useMemo to optimize the lightenColor function
  // const lightenColor = useMemo(() => {
  //   const amt = Math.round(2.55 * 30); // Lighten by 30%
  //   const num = parseInt(shopColor.replace('#', ''), 16);
  //   const R = (num >> 16) + amt;
  //   const G = ((num >> 8) & 0x00ff) + amt;
  //   const B = (num & 0x0000ff) + amt;

  //   return `rgba(${R},${G},${B},0.5)`; // Adding some transparency
  // }, [shopColor]); // Only recalculate when shopColor changes

  const {scale, pressHandlers} = useTilePressAnimation();

  return (
    <Animated.View
      style={[{paddingHorizontal: margin.horizontal}, {transform: [{scale}]}]}>
      <Pressable
        {...pressHandlers}
        onPress={() => navigate('Brand', {shop_id: item.shop_id, shop: item})}
        style={{flex: 1}}>
        <CustomBackgoundImage
          style={[
            index !== 0 && {marginTop: verticalScale(20)},
            styles.backgroundImage,
          ]}
          imageStyle={styles.imageStyle}
          source={{uri: item.shop_banner_url}}
          resizeMode="cover">
          {/* <LinearGradient
          colors={['transparent', lightenColor, shopColor]}
          locations={[0.5, 0.8, 1]}
          start={{x: 0.5, y: 0}}
          end={{x: 0.5, y: 1}}
          style={styles.gradientOverlay}
        /> */}
          <Overlay />
          <View style={styles.contentContainer}>
            <View style={{marginHorizontal: margin.horizontal}}>
              <BrandTab
                light="white"
                item={item}
                shopNameFontSize={12.5}
                tilePosition={index}
                markShopAsClicked={markShopAsClicked}
              />
            </View>
            <AnimatedCard
              products={item.products}
              item={item}
              backgroundColor={shopColor}
              fontColor={fontColor}
              tilePosition={index}
              markShopAsClicked={markShopAsClicked}
            />
          </View>
        </CustomBackgoundImage>
      </Pressable>
    </Animated.View>
  );
});

const styles = StyleSheet.create({
  backgroundImage: {
    width: '100%',
    height: tileHeight,
    zIndex: 1,
    borderRadius: moderateScale(20),
    overflow: 'hidden',
    backgroundColor: 'white',
    borderColor: colors.light_theme.darkBorderColor,
    elevation: 10,
  },
  imageStyle: {
    borderRadius: moderateScale(20),
    overflow: 'hidden',
    opacity: 0.5,
  },
  contentContainer: {
    marginTop: verticalScale(18),
    justifyContent: 'space-between',
    flex: 1,
  },
  gradientOverlay: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    borderRadius: moderateScale(20),
  },
});

export default memo(ShopTileFour);
