import {useMemo, useRef} from 'react';
import {Animated} from 'react-native';

const useTilePressAnimation = () => {
  const scale = useRef(new Animated.Value(1)).current;

  const pressHandlers = useMemo(
    () => ({
      onPressIn: () =>
        Animated.spring(scale, {
          toValue: 0.97,
          useNativeDriver: true,
          speed: 20,
          bounciness: 6,
        }).start(),
      onPressOut: () =>
        Animated.spring(scale, {
          toValue: 1,
          useNativeDriver: true,
          speed: 20,
          bounciness: 6,
        }).start(),
    }),
    [scale],
  );

  return {scale, pressHandlers};
};

export default useTilePressAnimation;
