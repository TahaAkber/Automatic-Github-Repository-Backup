import React, { useState } from 'react';
import {
  FlatList,
  Modal,
  StyleSheet,
  TouchableOpacity,
  View,
  Image,
  Text,
} from 'react-native';
import { moderateScale, verticalScale } from 'react-native-size-matters';
import { font, globalStyle, WH } from '@constant/contstant';
import CustomText from '@materialComponent/customText/customText';
import CustomImage from '@materialComponent/image/image';
import Product from '@assets/images/discount.svg';
import Filter from '@assets/images/filter.svg';
import { colors, margin, shadow } from '../../../constant/contstant';
import { currency } from '../../../constant/signature';

import useReduxStore from '@utils/hooks/useReduxStore';
import { navigate } from '@utils/navigationRef/navigationRef';
import { logHomeDealClickEvent } from '../../../helper/eventTriggers/useEventTriggers';

const DealDiscount = ({ marginTop }) => {
  const { getState } = useReduxStore();
  const { trending_collection } = getState('merchant');


  const handlePress = async (item, index) => {
    // Log analytics event
    await logHomeDealClickEvent(item, index);

    navigate('TrendingCollection', { item });
  };

  return (trending_collection || [])?.length ? (
    <View style={{ marginTop: marginTop }}>
      <View style={[globalStyle.space_between, { marginHorizontal: margin.horizontal }]}>
        <CustomText
          //   marginTop={verticalScale(10)}
          fontFamily={font.bold}
          fontSize={moderateScale(17)}
          text={'Deal & Discount'}
        />
      </View>
      <FlatList
        data={trending_collection}
        horizontal
        showsHorizontalScrollIndicator={false}
        renderItem={({ item, index }) => (
          <TouchableOpacity
            activeOpacity={1}
            style={styles.contentContainer}
            onPress={() => handlePress(item, index)}>
            <View
              style={{
                justifyContent: 'center',
                alignItems: 'center',
                width: WH.width(40),
                height: WH.width(30),
                borderRadius: 10,
                backgroundColor: 'white',
                // ...shadow,
                zIndex: 1,
                overflow: 'hidden',

                // marginLeft:20

              }}>
              <CustomImage
                resizeMode={'cover'}
                source={{ uri: item.trending_banner_url }}
                style={{ width: WH.width(40), height: WH.width(30) }}
              />
            </View>
            <CustomText
              color={'black'}
              marginTop={verticalScale(5)}
              fontSize={moderateScale(12)}
              text={item.trending_name}
            />
            {/* <CustomText
              color={'black'}
              fontFamily={font.bold}
              marginTop={verticalScale(2)}
              fontSize={moderateScale(9)}
              text={'by Khaadi'}
            /> */}
            {/* <LinearGradient
              colors={['#F81140', '#FF5790']} // Pink to White
              start={{x: 0, y: 0}} // Top-left corner
              end={{x: 1, y: 0}} // Top-right corner
              style={styles.gradient}>
              <CustomText
                fontFamily={font.bold}
                fontSize={moderateScale(8)}
                color={'white'}
                text={'-20%'}
              />
            </LinearGradient> */}
            {/* <View style={[globalStyle.row, {marginTop: verticalScale(2)}]}>
              <CustomText
                color={'#202020'}
                fontFamily={font.bold}
                fontSize={moderateScale(12)}
                text={currency + ' ' + 100}
              />
              <CustomText
                color={'#F1AEAE'}
                fontFamily={font.bold}
                fontSize={moderateScale(8)}
                text={currency + ' ' + 100}
                style={{marginLeft: 5, textDecorationLine: 'line-through'}}
              />
            </View> */}
          </TouchableOpacity>
        )}
        keyExtractor={(item, index) => index.toString()}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.flatlist}
      />
    </View>
  ) : (
    <></>
  );
};

export default DealDiscount;

const styles = StyleSheet.create({
  contentContainer: {
    borderRadius: 180,
    marginRight: moderateScale(10),
    // padding: moderateScale(2),
    // marginTop: verticalScale(10),
    width: WH.width(40),
  },
  flatlist: {
    // marginBottom: verticalScale(20),
    // height: WH.width(16),
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: verticalScale(5),
    paddingLeft: 20
  },
  gradient: {
    position: 'absolute',
    top: 0,
    right: 0,
    borderRadius: 5,
    borderTopRightRadius: 10,
    width: WH.width(10),
    height: WH.height(3),
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 2,
  },
});
