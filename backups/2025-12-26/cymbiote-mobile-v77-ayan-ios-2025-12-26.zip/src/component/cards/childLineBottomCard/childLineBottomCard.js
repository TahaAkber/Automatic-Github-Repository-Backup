import {Dimensions, StyleSheet, View} from 'react-native';
import React from 'react';
import {colors, margin, font} from '@constant/contstant';
import GiftIcon from '@assets/images/giftIcon.svg';
import VideoIcon from '@assets/images/videoIcon.svg';
import CustomText from '@materialComponent/customText/customText';
import CustomButton from '../../../materialComponent/customButton/customButton';
import {moderateScale} from 'react-native-size-matters';

const {width, height, fontScale} = Dimensions.get('screen');

const ChildLineCard = ({
  heading,
  secondHeading,
  firstLineCode,
  secondineCode,
  reward,
  marginTop,
  firstIcon: FirstIcon,
  style,
  headingFontSize,
  fontSize,
  onPress,
}) => {
  return (
    <View style={[styles.content, {marginTop}]}>
      <View style={[styles.redeem, reward && {alignItems: 'center'}, style]}>
        <View style={[styles.redeemContent, {alignItems: 'center'}]}>
          <CustomText
            style={[
              {textAlign: 'center'}, // Ensuring text is centered
              {marginBottom: height * 0.005}, // Only apply margin when reward is true
            ]}
            fontFamily={font.medium}
            fontSize={headingFontSize || moderateScale(13)}
            text={heading}
          />
          <CustomText
            style={[
              {textAlign: 'center'}, // Ensuring text is centered
              {marginBottom: height * 0.005, marginTop: -height * 0.006}, // Only apply margin when reward is true
            ]}
            fontFamily={font.medium}
            fontSize={headingFontSize || moderateScale(13)}
            text={secondHeading}
          />
          <CustomText
            text={firstLineCode}
            style={[styles.redeemText, fontSize && {fontSize}]}
          />
        </View>
        <View
          style={{
            height: width * 0.14,
            width: width * 0.14,
            alignItems: 'center',
            justifyContent: 'center',
          }}>
          {reward ? (
            <GiftIcon width={width * 0.12} height={width * 0.12} />
          ) : (
            <VideoIcon width={width * 0.12} height={width * 0.12} />
          )}
        </View>
        <View>
          <CustomButton
            text={secondineCode}
            buttonStyle={styles.redeemNowButton}
            textStyle={styles.redeemNowText}
            onPress={onPress}
            forceHeight={height * 0.045}
          />
        </View>
      </View>
    </View>
  );
};

export default ChildLineCard;

const styles = StyleSheet.create({
  content: {
    width: '47%',
    marginHorizontal: width * 0.02,
    marginBottom: height * 0.02,
    alignItems: 'center',
    justifyContent: 'center',
  },
  redeem: {
    borderWidth: 1,
    borderColor: '#e6e9ef',
    borderRadius: 20,
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
    // backgroundColor: '#E8EDFB',
    height: height * 0.25,
  },
  redeemContent: {
    alignItems: 'center',
    justifyContent: 'center',
    flex: 1,
  },
  redeemText: {
    fontFamily: font.light,
    color: 'black',
    fontSize: moderateScale(10),
    paddingHorizontal: 6, //

    textAlign: 'center', // Ensure the text is centered
    justifyContent: 'center', // Center text vertically
  },
  button: {
    borderRadius: 50,
    width: '80%',
    // paddingHorizontal: 10,
  },
  redeemNowButton: {
    backgroundColor: colors.light_theme.theme, // solid blue background
    borderRadius: 999,
    width: '100%',
    height: height * 0.045,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 0,
    marginVertical: 10,
  },

  redeemNowText: {
    color: colors.light_theme.backgroundColor,
    fontSize: fontScale * 11.5,
    fontFamily: font.medium,
    textAlign: 'center',
  },
});
