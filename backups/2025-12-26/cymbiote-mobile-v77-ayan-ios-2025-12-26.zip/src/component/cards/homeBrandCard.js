import CustomImage from '@materialComponent/image/image';
import { moderateScale } from 'react-native-size-matters';
import { StyleSheet, View } from 'react-native';
import images from '@assets/images/images';
import { colors } from '@constant/contstant';
import React from 'react';

const HomeBrandCard = () => {
  return (
    <View style={styles.brand_slider}>
      <CustomImage
        style={styles.brand_slider_image}
        source={images.adidas}
        resizeMode="contain"
        size={'small'}
      />
    </View>
  );
};

export default HomeBrandCard;

const styles = StyleSheet.create({
  brand_slider: {
    marginRight: moderateScale(20),
    borderRadius: moderateScale(5),
    height: moderateScale(120),
    width: moderateScale(120),
    borderColor: colors.light_theme.darkBorderColor,
    backgroundColor: 'white',
    marginBottom: 10,
    borderWidth: 1,
    padding: 10,
  },
  brand_slider_image: {
    height: moderateScale(100),
    width: moderateScale(100),
    alignSelf: 'center',
  },
});
