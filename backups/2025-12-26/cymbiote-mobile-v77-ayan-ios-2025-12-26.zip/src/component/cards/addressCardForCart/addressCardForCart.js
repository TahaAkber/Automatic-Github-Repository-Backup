import {
  Dimensions,
  StyleSheet,
  TouchableOpacity,
  View,
  Animated,
  LayoutAnimation,
  UIManager,
  Platform,
  ActivityIndicator,
} from 'react-native';
import React, { useState, useRef, useEffect } from 'react';
import { font, margin } from '@constant/contstant';
import CustomText from '@materialComponent/customText/customText';
import BorderLine from '@component/borderLine/borderLine';
import CustomRadioButton from '@materialComponent/radioButton/radioButton';
import CircleIcon from '@materialComponent/circleIcon/circleIcon';
import { navigate } from '@utils/navigationRef/navigationRef';
import useAddressCardForCart from './useAddressCardForCart';
import CustomButton from '@materialComponent/customButton/customButton';
import { AuthNavigating } from '@helper/reUsableMethod/reUsableMethod';
import { colors, globalStyle, WH } from '../../../constant/contstant';
import { useNavigation } from '@react-navigation/native';
import { _cartBottomSheet } from '../../../redux/actions/common/common';
import { moderateScale } from 'react-native-size-matters';
import Icon from '../../../materialComponent/icon/icon';
import DeleteCart from '@assets/images/cart_delete.svg';
import PagionationLoader from '../../loader/endReachLoader';

const { fontScale, height, width } = Dimensions.get('screen');

// Enable LayoutAnimation for Android
if (
  Platform.OS === 'android' &&
  UIManager.setLayoutAnimationEnabledExperimental
) {
  UIManager.setLayoutAnimationEnabledExperimental(true);
}

const AddressCardForCart = ({
  data = [],
  address,
  style,
  updatedDesign = false,
  defaultDesign = true,
  cart,
}) => {
  const {
    defaultAddress,
    defaultAddressItem,
    animatedHeight,
    handleShowAddresses,
    showAllAddresses,
    loadingAddressId,
    _handleAddress,
    isGoBack,
    dispatch,
    deleteAddress,
    deleteLoader,
  } = useAddressCardForCart({ data });

  return data.length == 0 ? (
    <TouchableOpacity
      style={styles.addAddressContainer}
      onPress={() => _handleAddress('CreateAddress')}>
      <CustomText
        fontSize={fontScale * 14}
        fontFamily={font.bold}
        text="Add New Address"
      />
      <CircleIcon
        style={styles.addIcon}
        size={width * 0.03}
        icon_type={'FontAwesome'}
        name={'plus'}
      />
    </TouchableOpacity>
  ) : (
    <View>
      <View
        style={[
          styles.container,
          data.length === 0 && { paddingBottom: height * 0.02 },
          style,
        ]}>
        {/* Handle empty address list */}
        {data.length === 0 ? (
          defaultDesign ? (
            <>
              <CustomText
                style={{ marginBottom: height * 0.01 }}
                text={'You need to add an address.'}
              />
              <CustomButton
                onPress={() => _handleAddress('Addresses')}
                text={'Add Address'}
              />
            </>
          ) : (
            <TouchableOpacity
              style={styles.addAddressContainer}
              onPress={() => _handleAddress('Addresses')}>
              <CustomText
                fontSize={fontScale * 14}
                fontFamily={font.bold}
                text="Add New Address"
              />
              <CircleIcon
                style={styles.addIcon}
                size={width * 0.03}
                icon_type={'FontAwesome'}
                name={'plus'}
              />
            </TouchableOpacity>
          )
        ) : (
          <>
            {/* Show Default Address */}
            <View key={defaultAddressItem?.address_id}>
              <View style={[styles.addressItem]}>
                {/* Shipping Address Label */}
                {defaultAddressItem.address_default_select && (
                  <CustomText
                    color={'#202020'}
                    fontFamily={font.bold}
                    fontSize={fontScale * 15}
                    text={'Shipping Address'}
                  />
                )}

                <View style={styles.row}>
                  <CustomText
                    style={styles.addressText}
                    marginTop={height * 0.005}
                    fontFamily={font.regular}
                    fontSize={fontScale * 11}
                    text={`${defaultAddressItem?.address_one}, ${defaultAddressItem?.address_two}, ${defaultAddressItem?.address_city}`}
                  />
                  {/* Show Pencil Icon for editing */}
                  {!address && !showAllAddresses ? (
                    <CircleIcon
                      style={styles.pencilIcon}
                      size={width * 0.04}
                      icon_type={'FontAwesome'}
                      name={'pencil'}
                      onPress={handleShowAddresses}
                    />
                  ) : (
                    !address && (
                      <CustomRadioButton
                        loader={false}
                        onPress={() =>
                          defaultAddress(defaultAddressItem.address_id)
                        }
                        selected={defaultAddressItem.address_default_select}
                      />
                    )
                  )}
                </View>
                {address && (
                  <TouchableOpacity
                    onPress={handleShowAddresses}
                    style={{
                      borderWidth: 1,
                      padding: 3,
                      paddingHorizontal: 10,
                      borderRadius: 180,
                      borderColor: colors.light_theme.theme,
                      alignSelf: 'baseline',
                      position: 'absolute',
                      top: 0,
                      right: 0,
                    }}>
                    <CustomText
                      color={'black'}
                      fontSize={fontScale * 9}
                      text={'Default'}
                    />
                  </TouchableOpacity>
                )}
              </View>
            </View>

            {/* Display all remaining addresses */}
          </>
        )}
      </View>
      <View style={styles.listView}>
        {data
          .filter(item => item !== defaultAddressItem)
          .map((item, index) => (
            <View key={item?.address_id}>
              <View style={styles.addressItem}>
                <View style={styles.row}>
                  {!cart ? (
                    <CustomRadioButton
                      loader={loadingAddressId === index}
                      onPress={() => defaultAddress(item.address_id, index)}
                      selected={item.address_default_select}
                      size={width * 0.05}
                    />
                  ) : (
                    <></>
                  )}

                  <CustomText
                    style={styles.addressText}
                    // marginTop={height * 0.005}
                    fontFamily={font.regular}
                    fontSize={fontScale * 11}
                    text={`${item?.address_one}, ${item?.address_two}, ${item?.address_city}`}
                  />

                  {!cart ? (
                    loadingAddressId === item.address_id ? (
                      <ActivityIndicator size={'small'} color={'black'} />
                    ) : (
                      <View style={globalStyle.row}>
                        <TouchableOpacity
                          onPress={() => _handleAddress('CreateAddress', { address_id: item.address_id })}
                          style={{ marginRight: 10 }}
                          activeOpacity={1}>
                          <Icon
                            icon_type={'AntDesign'}
                            name={'edit'}
                            color={colors.light_theme.theme}
                            size={moderateScale(15)}
                          />
                        </TouchableOpacity>
                        <TouchableOpacity
                          onPress={() => {
                            deleteAddress(item.address_id);
                          }}
                          activeOpacity={1}>
                          <Icon
                            icon_type={'AntDesign'}
                            name={'delete'}
                            color={colors.light_theme.theme}
                            size={moderateScale(15)}
                          />
                        </TouchableOpacity>

                      </View>
                    )
                  ) : (
                    <CustomRadioButton
                      loader={loadingAddressId === index}
                      onPress={() => defaultAddress(item.address_id, index)}
                      selected={item.address_default_select}
                    />
                  )}
                </View>
                <BorderLine
                  style={styles.borderLine}
                  marginTop={height * 0.015}
                />
              </View>
            </View>
          ))}

        {/* Add More Address Section */}
        <TouchableOpacity
          onPress={() => _handleAddress('CreateAddress')}
          style={styles.addMoreContainer}>
          <Icon
            style={styles.plusIcon}
            size={width * 0.06}
            icon_type={'AntDesign'}
            name={'pluscircle'}
            color={colors.light_theme.theme}
          />
          <CustomText
            style={{ marginBottom: height * 0.004 }}
            fontFamily={font.bold}
            fontSize={fontScale * 14}
            text={'Add More Address'}
          />
        </TouchableOpacity>
      </View>
    </View >
  );
};

export default AddressCardForCart;

const styles = StyleSheet.create({
  container: {
    marginHorizontal: margin.horizontal,
    backgroundColor: '#F9F9F9',
    padding: width * 0.05,
    paddingVertical: height * 0.02,
    borderRadius: 10,
  },
  addressItem: {
    paddingBottom: height * 0.01,
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  addressText: {
    width: width * 0.59,
  },
  borderLine: {
    marginLeft: 0,
    width: '100%',
    backgroundColor: '#e9e9e9',
    height: height * 0.0002,
  },
  showMoreContainer: {
    marginTop: height * 0.015,
    alignSelf: 'center',
  },
  addMoreContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: height * 0.009,
  },
  plusIcon: {
    // width: width * 0.055,
    marginRight: width * 0.03,
    alignItems: 'center',
    justifyContent: 'center',
  },
  pencilIcon: {
    marginLeft: width * 0.02,
  },
  addAddressContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginHorizontal: margin.horizontal,
    borderColor: colors.light_theme.theme,
    borderWidth: 1,
    padding: width * 0.04,
    borderRadius: moderateScale(10),
    // padding: width * 0.04,
    // borderRadius: 10,
    // backgroundColor: "#F9F9F9",
  },
  addIcon: {
    width: width * 0.06,
  },
  listView: {
    marginHorizontal: margin.horizontal,
    // backgroundColor: "#F9F9F9",
    padding: width * 0.05,
    paddingVertical: height * 0.02,
    borderRadius: 10,
  },
});
