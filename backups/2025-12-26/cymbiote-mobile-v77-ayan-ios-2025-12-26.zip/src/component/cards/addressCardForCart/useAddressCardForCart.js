import { _getAddress, _deleteAddress, _setDefaultAddress } from '@redux/actions/user/user';
import { _getStores } from '@redux/actions/merchant/merchant';
import { _globalLoader } from '@redux/actions/common/common';
import useReduxStore from '@utils/hooks/useReduxStore';
import { useEffect, useRef, useState } from 'react';
import { Animated, LayoutAnimation } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { _cartBottomSheet } from '../../../redux/actions/common/common';
import { AuthNavigating } from '../../../helper/reUsableMethod/reUsableMethod';
import { navigate } from '../../../utils/navigationRef/navigationRef';


const useAddressCardForCart = ({ data, isGoBack, cart }) => {
    const { getState, dispatch } = useReduxStore()
    const { fetch_user_detail } = getState("auth")
    const [deleteLoader, setDeleteLoader] = useState(false);
    const [defaultLoader, setDefaultLoader] = useState(false);
    const [showAllAddresses, setShowAllAddresses] = useState(false);
    const [loadingAddressId, setLoadingAddressId] = useState(null);
    const animatedHeight = useRef(new Animated.Value(0)).current;
    const { cartBottomSheet } = getState("common");
    const navigation = useNavigation();


    const defaultAddress = async (address_id, index) => {
        setLoadingAddressId(index);
        setDefaultLoader(true)
        await dispatch(_setDefaultAddress(fetch_user_detail?.id, address_id))
        await dispatch(_getAddress(fetch_user_detail?.id))
        handleShowAddresses()
        setDefaultLoader(false)
        setLoadingAddressId(null);
        if (isGoBack) {
            navigation.goBack();
        }

    }

    const deleteAddress = async (address_id) => {
        setDeleteLoader(true)
        setLoadingAddressId(address_id);
        await dispatch(_deleteAddress(address_id))
        await dispatch(_getAddress(fetch_user_detail?.id))
        setDeleteLoader(false)
        setLoadingAddressId(null);
    }


    const defaultAddressItem = data.find((item) => item?.address_default_select) || data[0];

    const handleShowAddresses = () => {
        LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);

        if (!showAllAddresses) {
            Animated.timing(animatedHeight, {
                toValue: showAllAddresses ? 0 : 1, // Fully expand
                duration: 300,
                useNativeDriver: false,
            }).start();
        } else {
            Animated.timing(animatedHeight, {
                toValue: 0, // Collapse
                duration: 300,
                useNativeDriver: false,
            }).start();
        }

        setShowAllAddresses(!showAllAddresses);
    };


    const _handleAddress = async (screen, address_id) => {
        dispatch(_cartBottomSheet(false))
        const userLogin = AuthNavigating()
        if (userLogin) {
            dispatch(_cartBottomSheet(false))
            navigate(screen, { address_id })
        }
    }


    return {
        defaultAddress,
        defaultLoader,
        defaultAddressItem,
        animatedHeight,
        handleShowAddresses,
        showAllAddresses,
        loadingAddressId,
        dispatch,
        _handleAddress,
        deleteAddress,
        deleteLoader
    };
};

export default useAddressCardForCart;
