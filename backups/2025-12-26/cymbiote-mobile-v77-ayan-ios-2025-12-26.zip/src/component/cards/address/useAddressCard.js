import { _getAddress, _deleteAddress, _setDefaultAddress } from '@redux/actions/user/user';
import { _getStores } from '@redux/actions/merchant/merchant';
import { _globalLoader } from '@redux/actions/common/common';
import useReduxStore from '@utils/hooks/useReduxStore';
import { Alert } from 'react-native';
import { useState } from 'react';

const useAddressCard = ({ address_id }) => {
    const { getState, dispatch } = useReduxStore()
    const { fetch_user_detail } = getState("auth")
    const [loader, setLoader] = useState(false);
    const [defaultLoader, setDefaultLoader] = useState(false);

    const deleteAddress = async () => {
        setLoader(true)
        await dispatch(_deleteAddress(address_id))
        await dispatch(_getAddress(fetch_user_detail?.id))
        setLoader(false)
    }

    const defaultAddress = async () => {
        setDefaultLoader(true)
        await dispatch(_setDefaultAddress(fetch_user_detail?.id, address_id))
        await dispatch(_getAddress(fetch_user_detail?.id))
        setDefaultLoader(false)
    }

    const showConfirmationAlert = () => {
        Alert.alert(
            "Confirmation",
            "Are you sure you want to delete this address?",
            [
                {
                    text: "No",
                    style: "cancel",
                },
                {
                    text: "Yes",
                    onPress: () => deleteAddress(),
                },
            ],
            { cancelable: false }
        );
    };


    return {
        showConfirmationAlert,
        defaultAddress,
        deleteAddress,
        defaultLoader,
        loader,
    };
};

export default useAddressCard;
