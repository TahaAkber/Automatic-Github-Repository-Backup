import {moderateScale, scale, verticalScale} from 'react-native-size-matters';
import {colors, font, shadow} from '@constant/contstant';
import CustomImage from '@materialComponent/image/image';
import {FlatList, StyleSheet, Text, TouchableOpacity, View} from 'react-native';
import React, {useMemo} from 'react';
import {margin} from '../../../constant/contstant';
import {timeAgo} from '../../../utils/helper/helper';
import {navigate} from '../../../utils/navigationRef/navigationRef';
import useReduxStore from '../../../utils/hooks/useReduxStore';
import {_notificationRead} from '../../../redux/actions/user/user';
import {handleNotificationPress} from '../../../helper/reUsableMethod/reUsableMethod';

// Memoizing NotificationCard to prevent re-rendering when props haven't changed
const NotificationCard = React.memo(({item, index}) => {
  const {dispatch} = useReduxStore();

  const _handleNavigate = item => {
    const notificateDetail = item?.app_notification_payload
      ? JSON.parse(item.app_notification_payload)
      : '';
    const data = {
      data: {
        screenName: item?.app_notification_screen_name,
        payload: item?.app_notification_payload,
      },
    };

    dispatch(_notificationRead(item.app_notification_id));
    handleNotificationPress(data, dispatch);
  };

  const date = item?.date;
  // Memoizing data to avoid unnecessary re-renders
  const flatListData = useMemo(() => item?.data || [], [item?.data]);

  return (
    <>
      <View style={{marginHorizontal: margin.horizontal}}>
        <Text
          style={[
            styles.date,
            {
              marginTop: index == 0 ? 0 : verticalScale(8),
            },
          ]}>
          {item?.date}
        </Text>
      </View>
      <FlatList
        showsVerticalScrollIndicator={false}
        data={flatListData}
        keyExtractor={item => item.app_notification_id}
        renderItem={({item, index}) => {
          return (
            <TouchableOpacity
              activeOpacity={1}
              onPress={() => _handleNavigate(item)}
              style={[
                styles.flatlistView,
                {
                  borderTopWidth: index == 0 ? 1 : 0,
                  backgroundColor:
                    item.app_notification_read == false ? '#f6f8f9' : 'white',
                },
              ]}>
              {item?.app_notification_image_url ? (
                <View style={styles.imageView}>
                  <CustomImage
                    source={{uri: item.app_notification_image_url}}
                    style={styles.image}
                  />
                </View>
              ) : (
                <></>
              )}
              <View style={styles.textView}>
                <Text style={styles.descText}>
                  {item.app_notification_title + ' '}
                  <Text style={styles.timeText}>
                    {item.app_notification_body}
                  </Text>
                </Text>
                <Text style={styles.timeAgo}>{timeAgo(item.created_at)}</Text>
              </View>
            </TouchableOpacity>
          );
        }}
      />
    </>
  );
});

export default NotificationCard;

const styles = StyleSheet.create({
  image: {
    height: moderateScale(50),
    width: moderateScale(50),
    borderRadius: 180,
  },
  mainView: {
    backgroundColor: 'white',
    flex: 1,
  },
  flatlistView: {
    paddingVertical: verticalScale(10),
    paddingHorizontal: scale(10),
    flexDirection: 'row',
    backgroundColor: '#f6f8f9',
    borderBottomWidth: 1, // border is consistent now
    borderColor: '#E0E0E0', // specify a consistent color for the bottom border
  },
  textView: {
    marginLeft: scale(10),
    width: '75%',
  },
  descText: {
    fontSize: moderateScale(15),
    fontFamily: font.bold,
    color: 'black',
  },
  timeText: {
    color: colors.light_theme.gray,
    marginTop: verticalScale(2),
    fontSize: moderateScale(15),
    fontFamily: font.regular,
  },
  timeAgo: {
    color: colors.light_theme.gray,
    marginTop: verticalScale(5),
    fontSize: moderateScale(13),
    fontFamily: font.regular,
  },
  date: {
    color: colors.light_theme.gray,
    fontSize: moderateScale(15),
    fontFamily: font.regular,
    marginBottom: verticalScale(10),
    marginTop: verticalScale(8),
  },
});
