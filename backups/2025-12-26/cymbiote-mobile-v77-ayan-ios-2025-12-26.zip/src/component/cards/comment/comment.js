import React from 'react';
import { Animated, Dimensions, StyleSheet, TouchableOpacity, View } from 'react-native';
import CustomText from '@materialComponent/customText/customText';
import CustomImage from '@materialComponent/image/image';
import Icon from '@materialComponent/icon/icon';
import { colors, font, globalStyle } from '@constant/contstant';
import { timeAgo } from '@utils/helper/helper';
import useComment from './useComment';

const { height, fontScale, width } = Dimensions.get('screen');

const Comment = ({ images, handleReplyPress, item, child, review_detail }) => {
    const { handleLike, likeIconStyle, like, fetch_user_detail } = useComment({});

    return (
        <View>
            <View style={[styles.headerContainer, { marginTop: !images?.length && height * 0.02 }]}>
                {child ?
                    <View style={{ width: "15%" }} /> :
                    <View style={{ width: "15%" }}>
                        <CustomImage
                            style={styles.image}
                            source={{
                                uri:
                                    item?.commenterDetail?.shop_logo_url ||
                                    item?.commenterDetail?.user_image_url ||
                                    "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTXoUtVJmsyvY9RYFg53qQnttry62VtwtbaKA&s"
                            }}
                        />
                    </View>
                }


                <View style={{ width: "76%" }}>
                    <CustomText
                        fontSize={child ? fontScale * 11 : fontScale * 14}
                        fontFamily={font.bold}
                        text={
                            item?.commenterDetail?.shop_name ||
                            `${item?.commenterDetail?.user_first_name} ${item?.commenterDetail?.user_last_name}`
                        }
                    />

                    <View style={{ marginTop: child ? height * 0.003 : height * 0.005 }}>
                        <CustomText fontSize={child ? fontScale * 11 : fontScale * 13} text={item.commentText} />
                    </View>

                    {(item?.commentImages || []).length > 0 ?
                        <View style={{ marginTop: child ? height * 0.003 : height * 0.005, flexDirection: "row", alignItems: "center" }}>
                            {item?.commentImages?.map((item, index) => {
                                return (
                                    <CustomImage
                                        key={`commnet_image_${index}`}
                                        style={{ width: child ? width * 0.08 : width * 0.12, aspectRatio: 1, borderRadius: 5, marginRight: 5 }}
                                        source={{
                                            uri:
                                                item?.commenterDetail?.shop_logo_url ||
                                                item?.commenterDetail?.user_image_url ||
                                                "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTXoUtVJmsyvY9RYFg53qQnttry62VtwtbaKA&s"
                                        }}
                                    />
                                )
                            })}
                        </View> : <></>
                    }


                    <View style={{ flexDirection: 'row', marginTop: child ? 0 : height * 0.005, alignItems: "center" }}>
                        <CustomText fontSize={fontScale * 10} text={timeAgo(item.created_at)} />
                        {fetch_user_detail?.id === item?.commenterDetail?.order_user_id && !child ?
                            <TouchableOpacity onPress={() => handleReplyPress(item)} activeOpacity={1}>
                                <CustomText
                                    style={{ marginLeft: 5 }}
                                    fontFamily={font.bold}
                                    color={"#333333"}
                                    fontSize={fontScale * 12}
                                    text="Reply"
                                />
                            </TouchableOpacity> : <></>
                        }

                    </View>
                </View>

                {/* <TouchableOpacity onPress={handleLike} activeOpacity={1} style={{ justifyContent: 'center' }}>
                    <Animated.View style={likeIconStyle}>
                        <Icon
                            icon_type="AntDesign"
                            name={like ? "like1" : "like2"}
                            color={like ? colors.light_theme.theme : "black"}
                            size={fontScale * 20}
                        />
                    </Animated.View>
                </TouchableOpacity> */}
            </View>
        </View>
    );
};

export default Comment;

const styles = StyleSheet.create({
    headerContainer: {
        flexDirection: "row",
        justifyContent: "space-between",
    },
    image: {
        width: "85%",
        aspectRatio: 1,
        borderRadius: 180,
    },
});
