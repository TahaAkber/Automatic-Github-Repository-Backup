import React, {useState} from 'react';
import {
  ActivityIndicator,
  Dimensions,
  StyleSheet,
  TouchableOpacity,
  View,
} from 'react-native';
import {moderateScale} from 'react-native-size-matters';

import {font, margin} from '@constant/contstant';
import CustomImage from '@materialComponent/image/image';
import CustomText from '@materialComponent/customText/customText';
import {navigate} from '../../../utils/navigationRef/navigationRef';
import Icon from '../../../materialComponent/icon/icon';
import {widthPercentageToDP} from 'react-native-responsive-screen';
import useReduxStore from '../../../utils/hooks/useReduxStore';
import {_removeTracking} from '../../../redux/actions/orders/orders';
import {colors} from '../../../constant/contstant';

const {height} = Dimensions.get('screen');

const image = {
  dhl: 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5OjcBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N//AABEIAJQAzgMBEQACEQEDEQH/xAAbAAEBAQEBAQEBAAAAAAAAAAABAAIFBgQHA//EAEIQAAEDAwEDBwcKBAcBAAAAAAABAgMEBREGEiFBFBUxUWGT0QcXIiNVgZQTFjIzUlNWcZGxQ0XB8DVCVGJjZOEl/8QAGgEBAQEAAwEAAAAAAAAAAAAAAQIAAwQFBv/EADMRAQABAwEFBwMDBAMBAAAAAAABAgMRBBITITFSBRQVUWGRoUFx8CIyUzOSsdFDgcEj/9oADAMBAAIRAxEAPwD9kPJy7DIZIIlgpKkpmCkyQpLMKTKoBEsCZIUmSCWCkSWFIlQ4hJZUiWRMlkkwypEkKRJZUkhSSypMlEsypEkEl3z7TLy0DMkZUgYBMkEyzITJCkSYZUiZKJYEyWVJkhSCwvSTJCkyQoSQpBgKTJZUiSzwIYKBZUkgiSCZYKRJAF3sn2TzBknJQMAmSCWZJmSFJMAmZIJywJmSCWCkyWVIlTAZIUiWCkzJCkmApMyWTjmSySQoSQSQTLBSJIVSWBJd0+wy80ZNkpSZlhklmVUMkKpOTAyTMkEsCZkgnLDJMyQqkzJYVScqZJlkpMkEZMBQmSzkiWZUghVAskkEyQQwUmSFJIJLun1+XmgMsFXcGSzkJlsJVJOApMyQSwUJkglgRMkZJLKqTJZUmSAIUmZYEEKpMyWckZLKkkBkgmSMkMFJmSzknLAkoC7eT63LzWchlWEqg2ApOSAmWSksFJmSFDLBSJkjIFlVIksqoTJCkywJmSFJk4CkzJZVSCCWGSZk4ZAgmSCGSkyWSSCZZBkuzk+sefgEsMhkpSWAMlCZIUlgTMkKpMyzKqCmVJmSFUkgJlgTMkETJGScsypOSFJkxAJkgJIIywVSZLOSckEsgkglnZyfVZdABlkSwUMl/Ctq4aGllqql6MhibtPcvUaImqcKooquVxRTHGX55J5T5Ue5GWxmzlcZkXOOB2e7er347C4ca2fOhP7Mj7xTd29T4FHX8Lznz+y4+8UnusebeBR1/A8506/yyPvFDukeZ8Djr+C3ymv2vWWxuzx2ZFyHdI82nsPhwr+HqtO6lob/ABu5Mro52Jl8L+lE6+1Dq3bNVuePJ5Wq0d3TT+rk7LnIidOOKqpw8eUOtzeCuPlGZBWzRUVG2eCN2Gyufja7cdR3KNDM05mXtWex5roiqurEvm85cq/y2LvFHuEebm8Fjr+HrNN3Sru9ByyppG07H/VIjlVXJ1nR1Fum3XsxOXlauzRYr2IqzMc3H1JraO03BaOmgbUPYnrVV2EavUc9nRTcp2qpw7mk7Mqv29uqceTk+cib2bH3inL4bHU7Xg0dfw72ltQ1l/fLI6iZDSx+ism2qq53Un9fd1nT1WnpsRjazLo6zSUabEbWZlz75rqO33GSlpKdlS2P0XSbWE2uKIctjs+blO1VOHPpuzJu0RXXOMuf5x5fZ0feKcnhcdTseDx1/Dt6X1HV36aReQshpovpy7Srv4InadPV6WjTxH6szP0dLWaSjTRH6szP0ekPOmXRBJBLICCWdfcfUZdBBkrIZYLngDPPassNRqCKOmbXcnp2LtOYjMq93DP5HJbubHF3tDq6dNM1bOZl4q56Jt1p+TS4X1kCyZ2EdH046f3Oem/VV+2l7NntS7f/AKdqZw+HmDT/AOJou7Ud7c6XP3vVfwz7vpt+kbVcp1gob+2aRG7Wy2JegKr9dMZmlxXu0b1mNqu1iPu+bVOk4dP0jJX3FsssjsMi2MK5OK+4qzem5PJyaLtGrVV7MU4jzeXxvOw9V6ryc09TLqSKeFMRQMcsy8MKioifrhfcdXV1Ru5j6vK7XrojTTTPOeT0XlE1JyWFbTRv9dI31zk/yN6vzU62ksbU7cvP7K0W8q31fKOT8zPTfSvpti0ja+F1w21pmrl6MTKrjgRc2tmdnm4r282J3fN7y56+om26SK1QyMn2NiLbbhrO33HnUaG5NUbcvCs9k3N5E3Zj1fnb3K9yucquVVyquXKqvWeo+hiIjhD7rHaprxcI6SBMZXL3/YbxU4b92LVE1y4NTfpsW9up7zVN0g01aIrTa8NnezDcfw28XL2rvweXpbU6i5Nyvk8LRWKtXem7c5R+Yfmi71PafSw+y02+e610VHSp6b13qvQ1OKr+RxXr1Nmia6uThv36bNE11fR+x2u3wWuhjo6ZuI2JvXi5eLl7VPl796q7XNVT5O9dqvVzXVzl9OTgQiZYEkAwJLqyyNijfI/OyxquXCZ3IfTujEZnEOF88bP95VfBy+Be6q/Jd3w7UeUf3QPnhZ/vKr4STwNuqvyW8O1Hp/dCXWFnX+JVfCSeAbqr8lvDtR6e8PobqG3uts9wa+RKaDpc+JWZXqRF6Sd3VtYcc6S7F2LWOM/9vxu/Xae9XOWtqVXLlwxnBjOCIejRRFFOH1+l01GntxRS56dpTsv0HRl503Y7Z62qVK6bfMvyTt3U1Fx0IdK/bu3JxEcHz3aGm1mpuft/THLi+PUMun75c31k+oZmJhGsj5I5UYicE/f3lW4u24xFHy59LTq9Nb2ItR7vipbFp6tqY6amv88k0jtlrW0Tt6/qVVdu0RmaOH3c1zV6u3Tt12ox93t4m2vRdnZTuqmxSSuX1zo9pz3/AGlanBDpZuaivOHizv8AtC9NUU5x9M/+vCzUWnaiZ882pZ5JZHK57nUbsqq8TuxVepjEUfL3Kburop2abMY+7+tv0/YrjVspaK+Tyyu6GpRqnvzkmu/eopzVR8puazU2qNuu3ER93RuOg7fbaR9TWXp8UTMZd8h18Ok4aNdcuVbNNLr2u1rt6rYot8fu4vNumvxDLv8A+m7xOfean+P5dzf6yf8Aij3ajtOnZZGxx36d73qjWtSidlVXh0hvdRHGaPkVajV0xmbUe72ttoLbo63SST1K5lfh0z2b16kRvYebduXNZcxTHJ4167e192Iinl9MvH18Nhr6uWpqtSTPlkdly8kdj8uk79FV+imKabcY+717VWqt0RRTZjEer5+bdNfiCb4R3iVvdV/H8uTf6z+KPd39N3HTFiilSK4Ommk6ZXQORccE6Dp6m1q78x+nER6uhq7Os1NUTNOIj1dr552H/WO7p3gdLw7UdP8Ah1fDtV0/4fTbtRWy51PJ6KZ0kmyrt0btydarg4rujvWqdquP8OK7pL1qnarjDEuprZHI6N0k6uaqouzTvVN3bg0aG9VxiPmDTo70xnEe8MfOm1fbqfhZPAO4X/T3hXcb3p7wY9TWyWRsbH1G05URM0z0/oTOhvUxmYj3gVaO9EZ4e8OvxwdJ1odKrdilmVNvKRu+r+l0cO0+lieLqUfuh+fpWVOPrtXfDw+J2OHo9zd0+Vv3lcsqfvtXfDw+JuHo27p8rfvL6belXX1bKdtZqeDa3/KTxQtY3HWoTMRGeDivbFuja2aJ+2XJ1vLdbpUtoaGirHUFL6KOWNcyuTcrl6zksbumNqZjMu52bTYs07yuqNqfh5bmO7cbdVd0pz72jzh6ferHXC5ju3s2q7tTb235w3erPXHwuY7tu/8AnVXdKbe2+qG73Y64+HRt+jL5Wvbmk5PGq73zrs493Spx16q1RHPLgu9p6a39cz6P0DT+nKHTNLJUelU1KM9OXZ3qn2WpwT++o869frvTEfT85vA1WtuauqKeUfnN4LUbb3fblJVSW6rbGm6KNY19Bv8AfSehZqtWqYiKoe5pJ02ntxRFcevq5fMl1RP8Oqe6U5N/b6odzvVnrh+k6I0/zPQfLVTE5bOmX/8AG3g3x7d3A8nV6neVbMTwh852jrd/c2aP2xy/3/p5nWs91vVckVNQ1XIoNzPVqm27i7w/9O1pKbVmnNUxtS9Hs6mxp6NqqqNqfh5vmS6ez6nu1O3v7XVD0Z1Vnrh7TQemn07lulwhVsqboI3J9Hrcqfsedr9XE/ool4/aeu2//jbnh9ZfR5QLLcbpyWahRZmQtVHRIu9FXinX0Kn6HF2fqLdrNNXBHZeptWdqK+GXhHWS6ouOb6nPH1Snrd5tdUe72+9WPpXA5luns+p7tQ7xa6o9z3qz1wuZbp7Pqe7U3eLPVDd6s9cFLLdFXCW+o6t8am7zZx++Pcd6s85rh7Smo007a20TIrg6tqE25qiiiRys/wBqK7d2fqu48eu53q7tzMbMcIiZePXc71d25mNmOERMv4cqqPvdT9xF4lbFPlR7y5N3T5Ue8rlVR97qfuIvEN3R5W/eW3dPlR7y/pTVM7qiJFl1HhXp9ZDGjenj2EV26Nmf6fvKa6I2Z4Ue8vZ8VPEl5Tq5Po8uktoMtgbQHAVQbAyEyQqgyyEyRknLADAJyyyBZyTJZJZZUCMkyWchkohkqhLMqpBGVBlkJIJIyoMMqSVklgYulk+idNZJywDLI2SFCZZEzLBQyYQEBlgTlgTksgyDJBMkKGSCJYBkhScsFCSCWQEEsAKBgSQDOkfQOojMAZEzLYAZKAgJYKGWWSZks5JywybJBOWQEEyQGWAFKpEsyoSQTlkBQZYEkAwJKBgpmdE97LqYQZbCA4AFBMsAywVQYEyQDADgBlsIkgMkEsAmSlUmZZlQmSCcsgKBgSwyGSCWQEGYAXRPcdVGywVQywzgJlgqkzJGQyyDLDJsnAJycIMsMgUGWBOWATJCqRlgqmyQGWRJAMgywAglkSQZgBATLOhk9rLrLJmGQYZDLIGGQyYhZCZOAGWGTFZJywJyyyZhknJBJGQYAyCZKBhkMsAIJyyAgGQEBlgDPuPYdZGZZAjJmCqEycAMssmyVkJlgTlkGWAZZElkCsgwJmWShkg0yyUnLAJkgMsgIBkYgnLAGRi+09d1gYonLA2WSgQZkTMsgYAUDAkjJssgYEzJSgwUGAFKEsAZAQDIxBLAGRijM//Z',
  tcs: 'https://e7.pngegg.com/pngimages/811/632/png-clipart-pakistan-tcs-courier-tata-consultancy-services-logistics-logistic-company-text.png',
  no_logo: 'https://cdn-icons-png.flaticon.com/512/227/227045.png',
};

const TrackingCard = ({item, onPressDelete}) => {
  const {dispatch} = useReduxStore();
  const [loading, setLoader] = useState(false);
  // const currentStatus =
  //   (item?.manual_tracking_payload &&
  //     JSON.parse(item?.manual_tracking_payload)?.track_info?.latest_status
  //       ?.sub_status) ||
  //   '';
  const currentStatus =
    (item?.manual_tracking_payload &&
      JSON.parse(item?.manual_tracking_payload)?.track_info?.latest_status
        ?.sub_status) ||
    '';

  const handleDelete = async () => {
    setLoader(true);
    await dispatch(_removeTracking(item?.manual_tracking_id));
    setLoader(false);
  };

  const STATUS_FLOW = ['pre‑transit', 'transit', 'delivered'];

  return (
    <TouchableOpacity
      activeOpacity={1}
      onPress={() =>
        navigate('TrackingDetail', {
          custom_tracking_id: item?.manual_tracking_id,
        })
      }
      style={styles.container}>
      <View style={styles.cardWrapper}>
        {/* Left: Image */}
        <View style={styles.imageWrapper}>
          <CustomImage
            style={styles.image}
            source={{
              uri: image[item?.courier] || image.no_logo,
            }}
          />
        </View>

        {/* Right: Text & Steps */}
        <View style={styles.textWrapper}>
          <CustomText
            fontSize={moderateScale(18)}
            fontFamily={font.bold}
            text={item?.manual_tracking_name}
          />
          {/* <View style={styles.progressRow}>
            {STATUS_FLOW.map((status, index) => {
              const isActive = STATUS_FLOW.indexOf(currentStatus) >= index; // activate up to current
              const isFailed =
                currentStatus === 'failed' && status === 'delivered'; // failed instead of delivered

              return (
                <View
                  key={status}
                  style={[
                    styles.stepDot,
                    isActive && styles.stepActive,
                    isFailed && {backgroundColor: 'red'},
                  ]}
                />
              );
            })}
          </View> */}
          <CustomText
            fontSize={moderateScale(12)}
            fontFamily={font.bold}
            marginTop={height * 0.005}
            text={`${item?.manual_tracking_courier || ''}`}
          />
          <CustomText
            fontSize={moderateScale(12)}
            fontFamily={font.regular}
            marginTop={height * 0.005}
            text={`Status: ${item?.manual_tracking_status || ''}`}
          />
        </View>
      </View>
      <TouchableOpacity
        disabled={loading}
        style={styles.deleteIcon}
        onPress={handleDelete}>
        {loading ? (
          <ActivityIndicator color={'red'} size={moderateScale(20)} />
        ) : (
          <Icon
            icon_type={'AntDesign'}
            name={'delete'}
            size={moderateScale(15)}
            color={'red'}
          />
        )}
      </TouchableOpacity>
    </TouchableOpacity>
  );
};

export default TrackingCard;

const styles = StyleSheet.create({
  container: {},
  cardWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    width: '100%',
    borderWidth: 1,
    paddingHorizontal: margin.horizontal,
    paddingVertical: height * 0.02,
    borderColor: '#f3f3f3f3',
  },
  imageWrapper: {
    width: '20%',
    aspectRatio: 1,
    backgroundColor: '#f4f4f4',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 10,
  },
  image: {
    width: '60%',
    aspectRatio: 1,
    borderTopRightRadius: 10,
    borderBottomRightRadius: 10,
  },
  textWrapper: {
    width: '78%',
  },
  progressRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: height * 0.01,
  },
  stepDot: {
    width: '20%',
    height: height * 0.005,
    backgroundColor: '#f4f4f4',
    borderRadius: 180,
    marginRight: '5%',
  },
  stepActive: {
    backgroundColor: colors.light_theme.confirmed,
  },
  deleteIcon: {
    borderWidth: 1,
    position: 'absolute',
    right: margin.horizontal,
    top: 10,
    width: widthPercentageToDP(7),
    aspectRatio: 1,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 180,
    borderColor: 'red',
  },
});
