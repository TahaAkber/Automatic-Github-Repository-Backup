import {useEffect, useState} from 'react';
import useReduxStore from '@utils/hooks/useReduxStore';
import {_getLatestReels} from '@redux/actions/reels/reels';

const useReelCard = ({route}) => {
  const {getState, dispatch} = useReduxStore();
  const {latestReel} = getState('reels');
  const [latestReelLoader, setLatestReelLoader] = useState(false);
  const [latestReelError, setLatestReelError] = useState(null);

  const fetchLatestReel = async (offset = 0) => {
    try {
      setLatestReelLoader(true);
      const res = await dispatch(_getLatestReels({offset}));
      if (res) {
        setLatestReelError(null);
      } else {
        setLatestReelError('Failed to fetch the latest reel.');
      }
    } catch (error) {
      console.error('Error fetching latest reel:', error);
      setLatestReelError(error.message || 'An error occurred.');
    } finally {
      setLatestReelLoader(false);
    }
  };

  useEffect(() => {
    fetchLatestReel();
  }, []);

  return {
    latestReel,
    latestReelLoader,
    latestReelError,
    fetchLatestReel,
  };
};

export default useReelCard;
