import React from 'react';
import {
  FlatList,
  ActivityIndicator,
  StyleSheet,
  View,
  Text,
} from 'react-native';
import useReelCard from './useReelCard';
import ReelCard from './reelCard';

const ReelCardList = () => {
  const {reels, latestReelLoader, latestReelError, fetchLatestReel, hasMore} =
    useReelCard();

  const renderFooter = () => {
    if (!latestReelLoader) return null;
    return (
      <View style={styles.footer}>
        <ActivityIndicator size="large" color="#0000ff" />
      </View>
    );
  };

  const handleLoadMore = () => {
    if (hasMore && !latestReelLoader) {
      fetchLatestReel(); // Fetch more reels when reaching the end
    }
  };

  if (latestReelError) {
    return <Text style={styles.errorText}>Error: {latestReelError}</Text>;
  }

  return (
    <FlatList
      data={reels}
      keyExtractor={(item, index) => index.toString()}
      renderItem={({item, index}) => (
        <ReelCard
          index={index}
          activeVideoIndex={null} // Pass active video index logic if needed
          setActiveVideoIndex={() => {}} // Handle active video index logic
          showProduct={true}
        />
      )}
      onEndReached={handleLoadMore} // Trigger when reaching the end
      onEndReachedThreshold={0.5} // Trigger when 50% of the list is visible
      ListFooterComponent={renderFooter} // Show loader at the bottom
    />
  );
};

export default ReelCardList;

const styles = StyleSheet.create({
  footer: {
    paddingVertical: 20,
    alignItems: 'center',
  },
  errorText: {
    color: 'red',
    textAlign: 'center',
    marginVertical: 20,
  },
});
