import { globalStyle, shadow, font } from '@constant/contstant';
import { moderateScale, verticalScale } from 'react-native-size-matters';
import CustomText from '@materialComponent/customText/customText';
import CustomImage from '@materialComponent/image/image';
import Icon from '@materialComponent/icon/icon';
import { Dimensions, StyleSheet, View } from 'react-native';
import React from 'react';
import CustomButton from '@materialComponent/customButton/customButton';
import { navigate } from '@utils/navigationRef/navigationRef';

const { fontScale, width, height } = Dimensions.get("screen");

const ProductDetailReview = ({ product_id }) => {
    return (
        <View>
            <View style={{ padding: width * 0.03, borderWidth: 1, borderColor: "#00000033", borderRadius: 10 }}>
                <View style={{ flexDirection: "row" }}>
                    <View
                        style={[styles.circle]}>
                        <CustomImage source={{ uri: "https://s3-alpha-sig.figma.com/img/32b2/fed3/dd6e97ca36cbcbf5ca57596f7c6547d3?Expires=1737936000&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=L6OaRcV1su0tO1GHR8AdoPzAYFDKuMUggGSB-O5Kzs3B3nlNQQM2ebuyGh1v2xzDwV06iHnfb1s5QxTJaLiozMinE1rMj3xec9qVh3vRWN1iJTZJEDg2b6OkRcnNm~FupCWP8Qr5KCvL9K~is7UtR6UVu7pyZBE28XfsQdoxItHLLvDLaENYLWkWL1wjiOQYsCIrgXnK6f8~kmqw6l3qavYeVXA1oOv8xhBMoqJhzTGnXZRBhwmKxTGuEgIUwTQRlsRQOVR~wgPfznt1Bo00HDRp9U9RprOpwHv8JcVvLV-bnf-0Up63C59Ng2XaDxRi51nfVRCbTFYWbxVMtuJuKQ__" }} style={styles.header_image} />
                    </View>
                    <View>
                        <CustomText fontFamily={font.bold} text={"Veronika"} />
                        <View style={[globalStyle.row,]}>
                            {[...Array(5)].map((_, i) => (
                                <Icon key={i} icon_type="Entypo" name={i == 4 ? "star-outlined" : "star"} color="#ECA61B" size={fontScale * 20} />
                            ))}
                        </View>
                        <CustomText
                            fontSize={fontScale * 12}
                            numberOfLines={3}
                            fontFamily={font.regular}
                            marginTop={height * 0.01}
                            color="black"
                            text={"Super CroppUnleash your inner fashionista with our Super Cropped Button Down Shirt! This boxy, CroppUnleash your inner fashionista"}
                        />
                    </View>
                </View>
            </View>
            <CustomButton
                buttonStyle={{ borderRadius: 180, marginTop: height * 0.03, }}
                onPress={() => navigate("ProductReview", { product_id })}
                marginTop={verticalScale(10)}
                text={"View All Reviews"}
            />
        </View>
    );
};

export default ProductDetailReview;

const styles = StyleSheet.create({
    circle: {
        backgroundColor: "white",
        width: width * 0.1,
        aspectRatio: 1,
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 180,
        marginRight: width * 0.02,
        ...shadow,
    },
    header_image: {
        width: width * 0.08,
        aspectRatio: 1,
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 180,
    },
});
