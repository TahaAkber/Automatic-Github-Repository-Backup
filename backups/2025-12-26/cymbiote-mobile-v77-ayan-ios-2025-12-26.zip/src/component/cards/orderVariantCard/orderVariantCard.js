import React from 'react';
import {
    Dimensions,
    FlatList,
    StyleSheet,
    Text,
    TouchableOpacity,
    View,
} from 'react-native';
import { moderateScale, scale, verticalScale } from 'react-native-size-matters';
import CustomText from '@materialComponent/customText/customText';
import CustomImage from '@materialComponent/image/image';
import Icon from '@materialComponent/icon/icon';
import { colors, font, shadow, WH, globalStyle } from '@constant/contstant';
import { navigate } from '@utils/navigationRef/navigationRef';
import { _addToCart, _getCardItems, _checkout, _removeShop } from '@redux/actions/cart/cart';
import { toFixedMethod } from '@utils/helper/helper';
import BorderLine from '../../borderLine/borderLine';
import { currency } from '@constant/signature';
import { defaultShopImages } from '../../../utils/helper/helper';
import { _cartBottomSheet } from '../../../redux/actions/common/common';
import { useDispatch } from 'react-redux';
import useImageHeight from '../../../utils/hooks/useImageHeight';


const { fontScale, height, width } = Dimensions.get("screen")

const OrderVariantCard = ({ productName = true, qtyFontSize, mainWIdth, optionsMarginTop, index, variant, product, image, shop, qty = true, rating, isDisabled, variantStock, onDecreasePress, onIncreasePress, display, borderWidth, showReviews, showSocialIcons, headingSize, priceSize, imageStyle, marginTop, borderTopMargin, removeBorder, showProductName = false, showRating = false, showCheckbox = false, isSelected = false, onSelect, heading, qtyStyle, endQty, removePrice, removeOptions, image_url, textViewStyle }) => {
    const { dispatch } = useDispatch()
    const { height } = useImageHeight(defaultShopImages(product)?.[0])
    return (
        <>
            <TouchableOpacity
                key={index}
                activeOpacity={1}

                onPress={() => {
                    if (!isDisabled) {
                        navigate('ProductDetail', {
                            product_id: product?.product_id,
                            shop_id: product?.product_shop_id,
                            default_images: defaultShopImages(product),
                            height
                        });

                        dispatch(_cartBottomSheet(false));
                    }
                }}
                disabled={isDisabled}
                style={[
                    isDisabled ? { opacity: 0.3 } : {},
                    { flexDirection: 'row', marginTop: index == 0 ? 0 : height * 0.02, alignItems: "center", paddingHorizontal: "2%", },
                ]}
            >
                {showCheckbox && (
                    <TouchableOpacity onPress={onSelect} style={[styles.checkbox, { borderColor: isSelected ? "black" : "#b2b2b2" }]} >
                        {isSelected && <View style={styles.checkedInnerCircle} />}
                    </TouchableOpacity>
                )}
                {/* Product Image */}
                <View style={styles.imageView}>
                    <CustomImage
                        source={{
                            uri: image_url || "https://s3-alpha-sig.figma.com/img/dfc3/dd72/6e0f810b0310ac03baa5a0afa501097b?Expires=1739750400&Key-Pair-Id=APKAQ4GOSFWCW27IBOMQ&Signature=dr3ORmjXmpNwzp74P875jyTvuvKWh-5dd-UNjlneQae4oDVgGFRAnz0geAXukkr3UWD0lx7nhPUMGcmUT3zzyDPZrAwYConZ8KXpaYa6wBaD3kX67kPP73cwa9voL1Z7zi090CCvRqKaqf5VCXxr8iVKgJ8Y5-L0t2I1XmvvEio0worvhaHiBAXxSmV3JwJZK8usGEklhBJq8AZ50qPMzR4q7-U5FHFgQ~Tf7AWq8sxbQWhKhdEo5hSJYFgkkvYGDiC3Z3xGQJ-4SwFMweVay5~h2GsijCRfmJmSYcsUEngaHPDM0OaL-ixsF8DPkykkzAB2nbBGFU2pfHiB~ck~AA__"
                        }}
                        style={[styles.image, imageStyle]}
                    />
                </View>

                {/* Product Details */}
                <View style={[styles.textView, mainWIdth && { width: mainWIdth }, showSocialIcons && { width: WH.width(70) }, textViewStyle]}>
                    <View style={globalStyle.space_between}>

                        <Text numberOfLines={1} style={[styles.descText, headingSize && { fontSize: headingSize }]}>
                            {showProductName ? heading || product?.name : `Order #${product?.order_id}`}
                        </Text>
                        {qty && (
                            <CustomText fontSize={qtyFontSize || fontScale * 15} fontFamily={font.bold} text={"Qty 1"} />
                        )}
                    </View>
                    {
                        !removeOptions && (variant?.selected_options?.length > 1) && (
                            <FlatList
                                data={variant?.selected_options || []}
                                horizontal
                                renderItem={({ item, index }) => (
                                    <View
                                        style={{
                                            backgroundColor: "#E5EBFC",
                                            marginRight: 5,
                                            paddingHorizontal: 10,
                                            borderRadius: 180,
                                            paddingVertical: 2,
                                            marginTop: optionsMarginTop || (marginTop || height * 0.01),
                                            alignSelf:"center"
                                            // height : "auto",

                                        }}
                                    >
                                        <CustomText color={"black"} fontSize={fontScale * 10} text={item?.value} />
                                    </View>
                                )}
                                keyExtractor={(item, index) => index.toString()}
                                showsHorizontalScrollIndicator={false}
                            />
                        )
                    }

                    {showRating && (
                        <View style={styles.starView}>
                            <CustomText text={rating} fontSize={fontScale * 16} fontFamily={font.bold} />
                            <View style={styles.starIcon}>
                                {[...Array(5)].map((_, i) => (
                                    <Icon key={i} icon_type="Entypo" name="star" color={i === 4 ? "#C9C9C9" : "#E4A70A"} size={fontScale * 15} />
                                ))}
                            </View>
                        </View>
                    )}
                    {!removePrice && (
                        <View style={[globalStyle.space_between, { width: "100%" }]}>
                            <CustomText
                                fontFamily={font.bold}
                                fontSize={priceSize || fontScale * 12}
                                text={`${product?.product_currency || currency} ${toFixedMethod(100)}`}
                                color={colors.light_theme.theme}
                            />
                        </View>
                    )}

                </View>


                {endQty && (
                    <CustomText style={{ position: "absolute", bottom: 0, right: 0 }} fontSize={qtyFontSize || fontScale * 12} fontFamily={font.bold} text={endQty} />
                )}

            </TouchableOpacity>
            {removeBorder ?
                <></> :
                <BorderLine marginTop={borderTopMargin || height * 0.025} style={[styles.borderLine, { width: borderWidth || "95%", }]} />
            }
        </>
    );
};

export default OrderVariantCard;

const styles = StyleSheet.create({
    image: {
        width: WH.width(18),
        aspectRatio: 1,
        borderRadius: 5,
    },
    flatlistView: {
        paddingVertical: verticalScale(20),
        paddingBottom: verticalScale(5),
        marginTop: verticalScale(15),
        paddingHorizontal: scale(10),
        // backgroundColor: 'white',
        borderRadius: 45,
        // ...shadow,
    },
    brand: {
        marginBottom: 10,
    },
    imageView: {
        marginRight: scale(10),
        borderWidth: 1,
        borderRadius: 10,
        borderRadius: 5,
        borderColor: "#f7f7f7"
    },
    textView: {
        width: WH.width(65),
        justifyContent: "space-between",
        // backgroundColor: "red",
        height: WH.width(18),

    },
    descText: {
        fontSize: fontScale * 17,
        fontFamily: font.bold,
        color: 'black',
    },
    priceText: {
        fontSize: moderateScale(13),
        fontFamily: font.bold,
        color: 'black',
    },
    actionButtons: {
        width: '30%',

        // position: 'absolute',
        // bottom: 10,
        // right: 10,
    },
    productStatus: {
        position: 'absolute',
        zIndex: 2,
        right: 10,
        top: 20,
    },
    qtyButton: {
        borderRadius: 5,
        width: width * 0.06,
        aspectRatio: 1,
        justifyContent: "center",
        alignItems: "center",
        backgroundColor: "#E5EBFC",
    },
    borderLine: {
        marginLeft: 0,
        width: "95%",
        backgroundColor: "#00000033",
        height: height * 0.003,
        alignSelf: "center",
        opacity: 0.3
    },
    brandTabMainViewStyle: {
        // paddingHorizontal: 0,
    },
    brandTabImageStyle: {
        // width: width * 0.1,
        // height: width * 0.1,
        ...shadow,
        backgroundColor: 'white',
        // elevation: 2,
    },
    ratingValue: {
        marginRight: width * 0.01,
        fontSize: fontScale * 14
    },
    iconContainer: {
        width: width * 0.31,
        // marginTop: height * 0.01,
        alignItems: "flex-end"
    },
    lcsIcon: {
        bottom: 0,
        position: "relative",
    },
    starView: {
        flexDirection: "row",
        // marginBottom: "3%",
        alignItems: "center"

    },
    starIcon: {
        marginLeft: "2%",
        flexDirection: "row"
    },
    checkbox: {
        width: width * 0.058,
        height: height * 0.025,
        borderRadius: 50,
        borderWidth: 2,

        justifyContent: "center",
        alignItems: "center",
        marginRight: 10,
    },
    checkedInnerCircle: {
        width: width * 0.039,
        height: height * 0.018,
        borderRadius: 50,
        backgroundColor: "black",
    },
});
