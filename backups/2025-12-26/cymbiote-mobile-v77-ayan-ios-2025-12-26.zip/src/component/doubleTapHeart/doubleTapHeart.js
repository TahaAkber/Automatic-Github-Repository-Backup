// DoubleTapHeart.js
import React, {useEffect, useRef} from 'react';
import {StyleSheet, Animated} from 'react-native';
import Icon from '../../materialComponent/icon/icon';

// token ensures exactly one animation per double tap
const DoubleTapHeart = ({visible, x, y, token, onAnimationEnd}) => {
  const scaleAnim = useRef(new Animated.Value(0)).current;
  const opacityAnim = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    if (!visible) return;
    scaleAnim.setValue(0);
    opacityAnim.setValue(1);
    Animated.parallel([
      Animated.sequence([
        Animated.spring(scaleAnim, {
          toValue: 1,
          friction: 3,
          tension: 40,
          useNativeDriver: true,
        }),
        Animated.timing(scaleAnim, {
          toValue: 1.2,
          duration: 50,
          useNativeDriver: true,
        }),
      ]),
      Animated.timing(opacityAnim, {
        toValue: 0,
        duration: 800,
        delay: 200,
        useNativeDriver: true,
      }),
    ]).start(() => onAnimationEnd?.());
  }, [token]); // ← animate once per token

  if (!visible) return null;

  return (
    <Animated.View
      style={[
        styles.heartContainer,
        {
          left: (x || 0) - 50,
          top: (y || 0) - 50,
          transform: [{scale: scaleAnim}],
          opacity: opacityAnim,
        },
      ]}
      pointerEvents="none">
      <Icon icon_type="AntDesign" name="heart" size={100} color="#ff4458" />
    </Animated.View>
  );
};

const styles = StyleSheet.create({
  heartContainer: {
    position: 'absolute',
    width: 100,
    height: 100,
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 999,
  },
});

export default React.memo(DoubleTapHeart);
