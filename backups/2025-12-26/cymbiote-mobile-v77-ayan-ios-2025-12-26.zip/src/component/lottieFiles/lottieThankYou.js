import { moderateScale } from 'react-native-size-matters';
import Lottie from '@assets/lottie/thankYou.json';
import { Dimensions, StyleSheet, View } from 'react-native';
import LottieView from 'lottie-react-native';
import React, { useRef } from 'react';

const { width, height } = Dimensions.get('screen');

const LottieThankYou = () => {
    const lottieRef = useRef(null);

    return (
        <View style={styles.lottieContainer}>
            <LottieView
                ref={lottieRef}
                style={styles.lootie}
                source={Lottie}
                autoPlay
                loop={false} // Ensures it plays only once
                speed={1} // Set to 1 to play at normal speed
            />
        </View>
    );
};

export default LottieThankYou;

const styles = StyleSheet.create({
    lootie: {
        overflow: 'hidden',
        borderRadius: 180,
        width: width * 0.5,
        height: width * 0.5,
    },
    lottieContainer: {
        backgroundColor: "rgba(0,0,0,0)",
        overflow: 'hidden',
        alignSelf: "center",
        height: width * 0.39,
        marginTop : -height * 0.05
    },
});
