import React, { useState, useRef } from 'react';
import { TouchableOpacity, Text, StyleSheet, View } from 'react-native';
import LottieView from 'lottie-react-native';

const AddToCartButton = ({ onPress, disabled, animationSource, buttonStyle, textStyle, idleText }) => {
  const [playing, setPlaying] = useState(false);
  const animationRef = useRef(null);

  const handlePress = () => {
    if (disabled || playing) return;

    setPlaying(true);
    animationRef.current?.play();

    if (onPress) onPress();

    // You can adjust this timeout to your Lottie animation length (in ms)
    setTimeout(() => {
      setPlaying(false);
    }, 1500);
  };

  return (
    <TouchableOpacity
      onPress={handlePress}
      disabled={disabled || playing}
      style={[styles.button, buttonStyle, disabled && styles.disabled]}
      activeOpacity={0.8}
    >
      {playing ? (
        <LottieView
          ref={animationRef}
          source={animationSource}
          autoPlay={false}
          loop={false}
          style={styles.lottie}
          resizeMode="contain"
        />
      ) : (
        <Text style={[styles.text, textStyle]}>
          {idleText || (disabled ? 'Disabled' : 'Add To Cart')}
        </Text>
      )}
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  button: {
    backgroundColor: 'black',
    height: 50,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 10,
  },
  disabled: {
    backgroundColor: '#555',
  },
  text: {
    color: 'white',
    fontSize: 16,
    fontWeight: '600',
  },
  lottie: {
    width: '100%',
    height: '100%',
  },
});

export default AddToCartButton;
