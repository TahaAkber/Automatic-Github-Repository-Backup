import React, {useImperativeHandle, useState, forwardRef} from 'react';
import {
  View,
  TouchableOpacity,
  StyleSheet,
  FlatList,
  Dimensions,
  ActivityIndicator,
} from 'react-native';
import { moderateScale, verticalScale } from 'react-native-size-matters';
import CustomText from '../../materialComponent/customText/customText';
import Icon from '../../materialComponent/icon/icon';
import { colors, font } from '../../constant/contstant';

const { fontScale } = Dimensions.get("screen");

const Dropdown = forwardRef(
({
  inputView,
  color,
  textStyle,
  setFieldValue,
  value,
  label,
  fieldName,
  static_data,
  marginTop = 0,
  disabled,
  errorMessage,
  onBlur,
  height,
}, ref) => {
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [loader, setLoader] = useState(false);
  const [data, setData] = useState(static_data || []);

  useImperativeHandle(ref, () => ({
    close: () => setDropdownOpen(false),
    open: () => setDropdownOpen(true),
    toggle: () => setDropdownOpen(prev => !prev),
  }));

  const handleSelect = (selectedValue) => {
    setFieldValue(fieldName, selectedValue);
    setDropdownOpen(false);
  };

  const getLabel = () => {
    const selectedItem = data?.find((item) => item.id == value);
    return selectedItem?.value || '';
  };

  const displayLabel = getLabel();
  const IsView = disabled ? View : TouchableOpacity;

  return (
    <View style={{ marginTop }}>
      {/* Floating label */}
      <CustomText style={styles.label} text={"Select Country"}>
        <CustomText style={styles.asterisk}>*</CustomText>
      </CustomText>

      <IsView
        onBlur={onBlur}
        onPress={() => {
          if (!disabled && data.length > 0) setDropdownOpen(!dropdownOpen);
        }}
        style={[styles.container, inputView]}
        activeOpacity={0.9}
      >
        <View style={styles.blueLine} />

        <View style={{ flex: 1, paddingLeft: moderateScale(12) }}>
          <CustomText
            color={!value ? '#999' : colors.light_theme.text}
            text={displayLabel || `Select ${label}`}
            style={[styles.valueText, textStyle]}
          />
        </View>

        <View style={styles.iconWrapper}>
          {loader ? (
            <ActivityIndicator size="small" color={colors.light_theme.theme} />
          ) : (
            <Icon
              icon_type="AntDesign"
              name={dropdownOpen ? "caretup" : "caretdown"}
              size={moderateScale(10)}
              color={colors.light_theme.gray}
            />
          )}
        </View>
      </IsView>

      {/* Dropdown menu */}
 {dropdownOpen && (
  <View style={[styles.dropdownAbsolute, { maxHeight: height || 400 }]}>
    <FlatList
      nestedScrollEnabled
      data={data}
      keyExtractor={(item) => item.id.toString()}
      renderItem={({ item }) => (
        <TouchableOpacity
          onPress={() => handleSelect(item.id)}
          style={styles.dropdownItem}
        >
          <CustomText text={item.value} style={styles.dropdownText} />
        </TouchableOpacity>
      )}
    />
  </View>
)}


      {/* Error message */}
      {errorMessage && (
        <CustomText
          marginTop={verticalScale(5)}
          fontSize={moderateScale(12)}
          text={`* ${errorMessage}`}
          color="red"
        />
      )}
    </View>
  );
});

const styles = StyleSheet.create({
  label: {
    position: 'absolute',
    top: -10,
    left: 12,
    zIndex: 1,
    backgroundColor: '#fff',
    paddingHorizontal: 4,
    fontSize: 12,
    fontFamily: font.medium,
    color: '#000',
  },
  asterisk: {
    color: 'green',
  },
  container: {
    borderWidth: 2,
    borderColor: '#ebebeb',
    borderRadius: 8,
    backgroundColor: '#fff',
    paddingHorizontal: 12,
    paddingTop: 16,
    paddingBottom: 10,
    flexDirection: 'row',
    alignItems: 'center',
    height: 60,
  },
  blueLine: {
    width: 3,
    height: '100%',
    backgroundColor: '#0066FF',
    borderRadius: 8,
  },
  valueText: {
    fontSize: moderateScale(14),
    fontFamily: font.medium,
  },
  iconWrapper: {
    position: "absolute",
    right: moderateScale(15),
  },
  dropdown: {
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 8,
    marginTop: 4,
    overflow: 'hidden',
  },
  dropdownItem: {
    padding: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  dropdownText: {
    fontSize: moderateScale(14),
    fontFamily: font.regular,
    color: '#000',
  },
  dropdownAbsolute: {
  position: 'absolute',
  top: 65, // adjust if your input height changes
  left: 0,
  right: 0,
  backgroundColor: '#fff',
  borderWidth: 1,
  borderColor: '#ccc',
  borderRadius: 8,
  zIndex: 9999, // important to stay above parent scrolls
  elevation: 5, // for Android
},

});

export default Dropdown;



// import { StyleSheet, View, ActivityIndicator, TouchableOpacity, Dimensions } from 'react-native';
// import React, { useState, useRef } from 'react';
// import { moderateScale, verticalScale } from 'react-native-size-matters';
// import CustomText from '../../materialComponent/customText/customText';
// import Icon from '../../materialComponent/icon/icon';
// import BottomSheetReUsable from '../../materialComponent/bottomSheet/bottomSheet';
// import { colors, font, WH } from '../../constant/contstant';

// const { fontScale } = Dimensions.get("screen");

// const Dropdown = ({
//     inputView,
//     color,
//     textStyle,
//     setFieldValue,
//     value,
//     label,
//     fieldName,
//     static_data,
//     marginTop = 0,
//     disabled,
//     errorMessage,
//     onBlur,
//     height
// }) => {
//     const refRBSheet = useRef();
//     const [loader, setLoader] = useState(false);
//     const [data, setData] = useState(static_data || []);

//     const handleSelect = (selectedValue) => {
//         setFieldValue(fieldName, selectedValue);
//         refRBSheet.current?.close();
//     };

//     const getLabel = () => {
//         const selectedItem = data?.find(item => item.id == value);
//         return selectedItem?.value || '';
//     };

//     const displayLabel = getLabel();
//     const IsView = disabled ? View : TouchableOpacity;

//     return (
//         <View style={{ marginTop }}>
//             {/* Floating label */}
//             <CustomText style={styles.label} text={"Select Country"}>
              
//                 <CustomText style={styles.asterisk}>*</CustomText>
//             </CustomText>

//             <IsView
//                 onBlur={onBlur}
//                 onPress={() => data.length > 0 && refRBSheet?.current?.open()}
//                 style={[styles.container, inputView]}
//                 activeOpacity={0.9}
//             >
//                 {/* Blue inner line */}
//                 <View style={styles.blueLine} />

//                 {/* Content */}
//                 <View style={{ flex: 1, paddingLeft: moderateScale(12) }}>
//                     <CustomText
//                         color={!value ? '#999' : colors.light_theme.text}
//                         text={displayLabel || `Select ${label}`}
//                         style={[styles.valueText, textStyle]}
//                     />
//                 </View>

//                 {/* Loader or Dropdown icon */}
//                 <View style={styles.iconWrapper}>
//                     {loader ? (
//                         <ActivityIndicator size="small" color={colors.light_theme.theme} />
//                     ) : (
//                         <Icon
//                             icon_type="AntDesign"
//                             name="caretdown"
//                             size={moderateScale(10)}
//                             color={colors.light_theme.gray}
//                         />
//                     )}
//                 </View>
//             </IsView>

//             {/* Bottom sheet */}
//             <BottomSheetReUsable
//                 refRBSheet={refRBSheet}
//                 title={label || ''}
//                 data={data}
//                 height={height || 400}
//                 setValue={handleSelect}
//                 value={value}
//             />

//             {/* Error */}
//             {errorMessage && (
//                 <CustomText
//                     marginTop={verticalScale(5)}
//                     fontSize={moderateScale(12)}
//                     text={`* ${errorMessage}`}
//                     color="red"
//                 />
//             )}
//         </View>
//     );
// };

// const styles = StyleSheet.create({
//     label: {
//         position: 'absolute',
//         top: -10,
//         left: 12,
//         zIndex: 1,
//         backgroundColor: '#fff',
//         paddingHorizontal: 4,
//         fontSize: 12,
//         fontFamily: font.medium,
//         color: '#000',
//     },
//     asterisk: {
//         color: 'green',
//     },
//     container: {
//          borderWidth: 2,
//     borderColor: '#ebebeb', // Always focused style
//     borderRadius: 8,
//     backgroundColor: '#fff',
//     paddingHorizontal: 12,
//     paddingTop: 16,
//     paddingBottom: 10,
//     flexDirection: 'row',
//     alignItems: 'center',
//     height: 60, // Set a fixed height for the input box
    
       
//     },
//     blueLine: {
//         width: 3,
//         height: '100%',
//         backgroundColor: '#0066FF',
//         borderRadius:8,
         
        
//     },
//     valueText: {
//         fontSize: moderateScale(14),
//         fontFamily: font.medium,
     
//     },
//     iconWrapper: {
//         position: "absolute",
//         right: moderateScale(15),
//     }
// });

// export default Dropdown;
