import { moderateScale, verticalScale } from 'react-native-size-matters';
import CustomText from '@materialComponent/customText/customText';
import { StyleSheet, View } from 'react-native';
import Icon from '@materialComponent/icon/icon';
import { font } from '@constant/contstant';
import React from 'react';

const EmptySearchRecord = ({ marginTop, text }) => {
  return (
    <View style={[styles.mainView, marginTop && { marginTop: marginTop }]}>
      <Icon
        icon_type={'MaterialIcons'}
        size={moderateScale(70)}
        name={'search-off'}
        color={'gray'}
      />
      <CustomText
        marginTop={verticalScale(10)}
        fontFamily={font.bold}
        color={'gray'}
        text={text}
      />
    </View>
  );
};
export default EmptySearchRecord;

const styles = StyleSheet.create({
  mainView: {
    justifyContent: 'center',
    alignItems: 'center',
    flex: 1,
  },
  lootie: {
    borderRadius: 180,
    overflow: 'hidden',
    height: '100%',
    width: '100%',
  },
  lottieContainer: {
    height: moderateScale(100),
    width: moderateScale(100),
    backgroundColor: 'white',
    borderRadius: 180,
    overflow: 'hidden',
  },
});
