import {useState, useEffect} from 'react';
import {Animated, View, TouchableOpacity, Dimensions} from 'react-native';
import useReduxStore from '@utils/hooks/useReduxStore';
import {font, WH} from '@constant/contstant';
import {SvgUri} from 'react-native-svg';
import CustomText from '@materialComponent/customText/customText';
import {moderateScale} from 'react-native-size-matters';
import {navigate} from '../../utils/navigationRef/navigationRef';
import {_getTaxonomies} from '../../redux/actions/common/common';
import {useNavigation} from '@react-navigation/native';
import {cercleRgbColors, taxonomiesFiltered} from '../../constant/contstant';
import Sports from '@assets/images/search_gift.svg';
import {widthPercentageToDP} from 'react-native-responsive-screen';

const {height} = Dimensions.get('screen');

const useSearchCategories = ({categories, params}) => {
  const navigation = useNavigation();
  const [showAll, setShowAll] = useState(false);

  const _handleNavigate = item => {
    if (item?.isLeaf == false) {
      navigation.push('Search', {item});
    } else {
      navigation.push('SearchedItems', {
        searchTerm: item.name,
      });
    }
  };

  const renderItem = ({item, index}) => {
    const bgColor = cercleRgbColors[index % cercleRgbColors.length];
   
    const ImageSvg = taxonomiesFiltered[item.name]?.SvgImage;

 

    return (
      <TouchableOpacity
        key={item.category_id}
        onPress={() => _handleNavigate(item)}
        // onPress={() =>
        //   navigate('SearchSecondDegree', {
        //     first_degree_category: item.category_id,
        //   })
        // }
        activeOpacity={1}
        style={{
          backgroundColor: bgColor,
          width: '48%',
          marginTop: index !== 1 && index !== 0 ? height * 0.01 : 0,
          height: !params ? height * 0.1 : height * 0.1,
          borderRadius: 10,
          justifyContent: 'center',
          alignItems: 'center',
          marginHorizontal: '1.5%',
        }}>
        {!params &&
          (ImageSvg ? (
            <ImageSvg
              width={widthPercentageToDP(9)}
              height={widthPercentageToDP(9)}
            />
          ) : (
            <Sports
              width={widthPercentageToDP(9)}
              height={widthPercentageToDP(9)}
            />
          ))}

        <CustomText
          center
          fontFamily={font.medium}
          color="white"
          fontSize={moderateScale(12)}
          marginTop={height * 0.005}
          text={!params ? taxonomiesFiltered[item.name]?.fullName : item.name}
          style={{
            marginHorizontal: '5%',
            alignSelf: 'center',
          }}
        />
      </TouchableOpacity>
    );
  };

  const toggleShowAll = () => {
    setShowAll(!showAll);
  };

  const categoriesToShow = showAll
    ? categories || []
    : !params
    ? (categories || []).slice(0, 8)
    : categories;

  return {
    renderItem,
    toggleShowAll,
    categoriesToShow,
    showAll,
  };
};

export default useSearchCategories;
