import React, { useState } from 'react';
import { Dimensions, FlatList, View } from 'react-native';
import useSearchCategories from './useSearchCategories';
import CustomButton from '@materialComponent/customButton/customButton';
import { moderateScale } from 'react-native-size-matters';
import { font, taxonomiesFiltered } from '../../constant/contstant';
import CustomText from '../../materialComponent/customText/customText';

const { height } = Dimensions.get('screen');

const SearchCategories = ({ categories = [], params }) => {
  const { renderItem, toggleShowAll, showAll, categoriesToShow } =
    useSearchCategories({
      categories,
      params,
    });

  return categoriesToShow?.length > 0 && (
    <View>
      {params ? (
        <CustomText
          center
          fontFamily={font.bold}
          color="#444444"
          fontSize={moderateScale(16)}
          // marginTop={height * 0.005}
          text={
            taxonomiesFiltered[params?.item.name]?.fullName ||
            params?.item?.name
          }
          style={{
            marginHorizontal: '5%',
            alignSelf: 'center',
            marginVertical: height * 0.01,
            marginTop: height * 0.006,
          }}
        />
      ) : (
        <></>
      )}

      <FlatList
        numColumns={2}
        scrollEnabled={false}
        columnWrapperStyle={{
          justifyContent: 'space-between',
          alignItems: 'center',
          alignSelf: 'center',
          // width: '100%',
        }}
        data={categoriesToShow}
        showsVerticalScrollIndicator={false}
        keyExtractor={(item, index) => index.toString()}
        renderItem={renderItem}
        contentContainerStyle={{
          marginTop: height * 0.01,
        }}
      />
      {!params ? (
        <CustomButton
          marginTop={height * 0.01}
          onPress={toggleShowAll}
          text={showAll ? 'Show Less' : 'View More'}
          backgroundColor={'#D9D9D9'}
          textStyle={{ color: 'black', fontSize: moderateScale(14) }}
        />
      ) : (
        <></>
      )}
    </View>
  );
};

export default SearchCategories;
