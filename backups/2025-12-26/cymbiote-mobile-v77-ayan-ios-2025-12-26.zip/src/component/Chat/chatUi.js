import React, {useEffect, useRef, useState} from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  FlatList,
  Image,
  Dimensions,
  KeyboardAvoidingView,
  Platform,
  Animated,
} from 'react-native';
import {Ionicons, MaterialIcons} from '@expo/vector-icons';
import Icon from '../../materialComponent/icon/icon';
import CustomImage from '../../materialComponent/image/image';
import {colors, font, margin} from '../../constant/contstant';
import {moderateScale} from 'react-native-size-matters';
import CustomText from '../../materialComponent/customText/customText';
import BottomSheetReUsable from '../../materialComponent/bottomSheet/bottomSheet';
import OrdersBottomSheet from './ordersBottomSheet';
import VariantCard from '../cards/variantCard/variantCard';
import images from '../../assets/images/images';
import {useNavigation} from '@react-navigation/native';
import OrderVariantCard from '../cards/orderVariantCard/orderVariantCard';
import {accessGallery, accessCamera} from '@utils/imagePicker/imagePicker';
import GorhomBottomSheet from '../../materialComponent/bottomSheet/GorhomBottomSheet';
// import firestore from '@react-native-firebase/firestore';

const {fontScale, width, height} = Dimensions.get('screen');

const orderData = [
  {
    id: '1',
    orderId: '#92287157',
    status: 'Shipped',
    itemsCount: '4',
    images: [images.t_shirt, images.t_shirt, images.t_shirt, images.t_shirt],
  },
  {
    id: '2',
    orderId: '#9977866',
    status: 'Delivered',
    itemsCount: '3',
    images: [images.t_shirt, images.t_shirt, images.t_shirt, images.t_shirt],
  },
];

const ChatUI = ({messages, onSendMessage, profilePicture, name, item}) => {
  const [text, setText] = useState('');
  const bottomSheetRef = useRef(null);
  const ordersSheetRef = useRef(null);
  const navigation = useNavigation();
  const [images, setImages] = useState([]);

  const handleSend = () => {
    if (text.trim().length > 0) {
      onSendMessage(text);
      setText('');
    }
  };

  const handleSendImage = imageUri => {
    if (!imageUri) {
      console.warn('handleSendImage received an invalid URI:', imageUri);
      return;
    }

    // Ensure file URI is properly formatted
    let formattedUri = imageUri;
    if (Platform.OS === 'android' && !imageUri.startsWith('file://')) {
      formattedUri = 'file://' + imageUri; // Ensure Android uses "file://"
    }

    const newMessage = {
      id: Date.now().toString(),
      type: 'image',
      image: formattedUri, // Use formatted URI
      isOutgoing: true,
      time: new Date().toLocaleTimeString([], {
        hour: '2-digit',
        minute: '2-digit',
      }),
    };

    onSendMessage(newMessage);
  };

  const openGallery = async () => {
    const response = await accessGallery(true); // Enable multiple selection

    bottomSheetRef.current.close();

    if (response && Array.isArray(response) && response.length > 0) {
      const imageMessages = response.map(img => ({
        id: Date.now().toString() + Math.random().toString(), // Unique ID
        type: 'image',
        image: img.uri, // Correct URI format
        isOutgoing: true,
        time: new Date().toLocaleTimeString([], {
          hour: '2-digit',
          minute: '2-digit',
        }),
      }));

      setImages(prev => [...prev, ...response.map(img => img.uri)]); // Update state with selected images
      onSendMessage(imageMessages); // Send multiple images as separate messages
    } else {
      console.warn('No images selected');
    }
  };

  const openCamera = async () => {
    const response = await accessCamera(false); // Capture single image
    bottomSheetRef.current.close();
    

    if (response && response.uri) {
      setImages([...images, response.uri]);
      handleSendImage(response.uri);
    } else {
      console.warn('Invalid image URI from camera:', response);
    }
  };

  const renderMessage = ({item}) => {
    if (item.isDivider) {
      return <Text style={styles.dayDivider}>{item.text}</Text>;
    }
    if (item.type === 'image') {
      return (
        <View
          style={[
            styles.messageContainer,
            item.isOutgoing ? styles.outgoingMessage : styles.incomingMessage,
          ]}>
          {item.image ? (
            <CustomImage
              style={{
                width: 200,
                height: 200,
                borderRadius: 10,
                resizeMode: 'cover',

                marginBottom: 5,
                borderWidth: 1,
              }}
              source={{uri: item.image}}
            />
          ) : (
            <Text style={{color: 'red'}}>Error loading image</Text>
          )}
          <CustomText
            text={item.time}
            fontSize={12}
            color={'#797C7B'}
            textAlign={item.isOutgoing ? 'right' : 'left'}
          />
        </View>
      );
    }
    if (item.type === 'product') {
      return (
        <View
          style={[
            styles.messageContainer,
            item.isOutgoing ? styles.outgoingMessage : styles.incomingMessage,
          ]}>
          <View
            style={{
              backgroundColor: '#D9D9D994',
              alignItems: 'center',
              borderRadius: 10,
              height: height * 0.11,
            }}>
            <OrderVariantCard
              product={item.product}
              headingSize={18}
              qty={false}
              showCheckbox={false} // No checkbox in chat messages
              isSelected={false} // No selection in chat
              productName={false}
              price={item.product.price}
              rating={item.product.rating}
              showProductName={true}
              showRating={true}
              removeBorder={true}
              mainWIdth={width * 0.5}
            />
          </View>
          <CustomText
            text={item.time}
            fontSize={fontScale * 12}
            color={'#797C7B'}
            textAlign={item.isOutgoing ? 'right' : 'left'}
          />
        </View>
      );
    }

    return (
      <View
        style={[
          styles.messageContainer,
          item.isOutgoing ? styles.outgoingMessage : styles.incomingMessage,
        ]}>
        {!item.isOutgoing && (
          <View style={styles.userInfoContainer}>
            <CustomImage
              style={styles.image}
              source={{
                uri: 'https://s3-alpha-sig.figma.com/img/fbc1/4c1d/c3a96ba57eb32020d565abdd8b64b19b?Expires=1738540800&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=Ja2u-FVfT-Wa0zev2JMx~TIffwzPrXN~Ni0I8S3gLlTLZ2lgfGa7op5--gKlRomq4GiaZAGpf-zltYZTM~8h1~ZbyUnRry-7Ds8SVeg7s2lcElj3LfWFoffDpPz1h8o4tOp7wF2AC02ReR~~QEK40ujzv0gKeFojkW8MnQMfQaZplhwG82oJrKYxlbwxQr2XnaUZYuP1mrc5bu~6uih-wzOQhm~ebLzTgSipzQpspFjqLGOqXfjt1XDCrLD3elo1886IrugOdGme5meX~ydH3nLTUbO8iLSBh6tFjhxiXyPFqGuTB9NQy5SZXHg4UWZLe2m9zMLPXrGfJ8hgDGq1Vw__',
              }}
            />
            <CustomText
              text={name}
              color={'#000E08'}
              fontFamily={font.bold}
              style={styles.userName}
            />
          </View>
        )}
        <View
          style={[
            styles.messageBubble,
            item.isOutgoing ? styles.outgoingBubble : styles.incomingBubble,
          ]}>
          <CustomText
            text={item.text}
            fontSize={fontScale * 14}
            color={item.isOutgoing ? '#fff' : '#000E08'}
            fontFamily={font.regular}
          />
        </View>

        <View style={{width: '90%', alignSelf: 'center'}}>
          <CustomText
            text={item.time}
            fontSize={fontScale * 12}
            color={'#797C7B'}
            textAlign={item.isOutgoing ? 'right' : 'center'}
            marginTop={5}
            fontFamily={font.regular}
          />
        </View>
      </View>
    );
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : ''}
      style={styles.container}>
      <FlatList
        data={messages.filter(msg => msg && msg.id)}
        renderItem={renderMessage}
        keyExtractor={(item, index) => item.id?.toString() || index.toString()}
        inverted
        contentContainerStyle={{paddingBottom: 20}}
      />
      <GorhomBottomSheet
        ref={bottomSheetRef}
        height={150}
        closeOnDragDown={true}
        closeOnPressMask={true}
        customStyles={{
          container: styles.sheetContainer,
        }}>
        <View style={styles.sheetContent}>
          <TouchableOpacity style={styles.option} onPress={openCamera}>
            <Icon
              icon_type={'Feather'}
              name={'camera'}
              size={24}
              color={'#000'}
            />
            <CustomText
              style={styles.optionText}
              text={'Camera'}
              marginTop={5}
              center
            />
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.option}
            onPress={() => {
              bottomSheetRef.current.close();
              ordersSheetRef.current.open();
            }}>
            <Icon
              icon_type={'MaterialCommunityIcons'}
              name={'pencil-circle-outline'}
              size={24}
              color={'#000'}
            />
            <CustomText
              style={styles.optionText}
              text={'Orders'}
              marginTop={5}
              center
            />
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.option}
            onPress={() => {
              navigation.navigate('ChatProduct', {
                name,
                item: item,
                uri: 'https://s3-alpha-sig.figma.com/img/fbc1/4c1d/c3a96ba57eb32020d565abdd8b64b19b?Expires=1738540800&Key-Pair-Id=APKAQ4GOSFWCVNEHN3O4&Signature=Ja2u-FVfT-Wa0zev2JMx~TIffwzPrXN~Ni0I8S3gLlTLZ2lgfGa7op5--gKlRomq4GiaZAGpf-zltYZTM~8h1~ZbyUnRry-7Ds8SVeg7s2lcElj3LfWFoffDpPz1h8o4tOp7wF2AC02ReR~~QEK40ujzv0gKeFojkW8MnQMfQaZplhwG82oJrKYxlbwxQr2XnaUZYuP1mrc5bu~6uih-wzOQhm~ebLzTgSipzQpspFjqLGOqXfjt1XDCrLD3elo1886IrugOdGme5meX~ydH3nLTUbO8iLSBh6tFjhxiXyPFqGuTB9NQy5SZXHg4UWZLe2m9zMLPXrGfJ8hgDGq1Vw__',
              });
              bottomSheetRef.current.close();
            }}>
            <Icon
              icon_type={'Feather'}
              name={'watch'}
              size={24}
              color={'#000'}
            />
            <CustomText
              style={styles.optionText}
              text={'Products'}
              marginTop={5}
              center
            />
          </TouchableOpacity>
          <TouchableOpacity style={styles.option} onPress={openGallery}>
            <Icon
              icon_type={'FontAwesome6'}
              name={'image'}
              size={24}
              color={'#000'}
            />
            <CustomText
              style={styles.optionText}
            text={'Gallery'}
            marginTop={5}
            center
          />
        </TouchableOpacity>
        </View>
      </GorhomBottomSheet>
      <OrdersBottomSheet
        ref={ordersSheetRef}
        orders={orderData}
        buttonText="Send"
        disableSendFunction={true}
      />

      <View style={styles.inputContainer}>
        <TouchableOpacity
          style={styles.iconButton}
          onPress={() => bottomSheetRef.current.open()}>
          <Icon
            icon_type={'Entypo'}
            size={24}
            color={'#000E08'}
            name={'attachment'}
          />
        </TouchableOpacity>
        <View style={styles.inputBox}>
          <TextInput
            value={text}
            onChangeText={setText}
            style={styles.searchbar}
            placeholder={'Write your message...'}
            placeholderTextColor={colors.light_theme.gray}
            textAlignVertical="center"
          />
          <TouchableOpacity onPress={handleSend} style={styles.sendButton}>
            <Icon
              name="send"
              size={20}
              color={'#fff'}
              icon_type={'MaterialIcons'}
            />
          </TouchableOpacity>
        </View>
        {/* <TouchableOpacity style={styles.iconButton}>
          <Icon
            icon_type="Ionicons"
            size={26}
            color={'#000E08'}
            name={'mic-outline'}
          />
        </TouchableOpacity> */}
      </View>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  dayDivider: {
    alignSelf: 'center',
    backgroundColor: '#F8FBFA',
    color: '#000E08',
    borderRadius: 10,
    paddingHorizontal: 10,
    paddingVertical: 5,
    marginVertical: 10,
    fontSize: 14,
    fontWeight: '700',
  },
  messageContainer: {
    marginVertical: 5,
    paddingHorizontal: 10,
  },
  outgoingMessage: {
    alignItems: 'flex-end',
  },
  incomingMessage: {
    alignItems: 'flex-start',
  },
  userInfoContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 5,
  },
  image: {
    width: width * 0.12,
    // height: 50,
    aspectRatio: 1,
    borderRadius: 30,
    marginRight: 8,
  },
  userName: {
    fontSize: 14,
    bottom: 12,
  },
  messageBubble: {
    maxWidth: '75%',
    borderBottomEndRadius: 10,
    borderBottomLeftRadius: 10,
    borderTopLeftRadius: 10,
    padding: 10,
    marginHorizontal: margin.horizontal,
  },
  outgoingBubble: {
    backgroundColor: colors.dark_theme.theme,
    alignSelf: 'flex-end',
  },
  incomingBubble: {
    backgroundColor: '#f2f7fb',
    marginHorizontal: 55,
    bottom: 20,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 10,
    backgroundColor: 'white',
    borderTopWidth: 1,
    borderTopColor: '#ddd',
  },
  inputBox: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#',
    borderRadius: 20,
    paddingHorizontal: 10,
  },
  searchbar: {
    flex: 1,
    paddingVertical: 8,
    fontFamily: font.medium,
    color: 'black',
  },
  sendButton: {
    backgroundColor: colors.dark_theme.theme,
    borderRadius: 20,
    padding: 8,
    marginLeft: 5,
  },
  iconButton: {
    padding: 5,
  },
  sheetContainer: {
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    paddingHorizontal: 20,
    paddingVertical: 10,
    backgroundColor: '#D9D9D9',
  },
  sheetContent: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  option: {
    // flexDirection: "row",
    alignItems: 'center',
    paddingVertical: 15,
  },
  optionText: {
    fontSize: 16,
    // marginLeft: 10,
    color: '#000',
  },
  productCard: {
    backgroundColor: '#D9D9D994',
    padding: 10,
    borderRadius: 10,
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 5,
    width: '80%',
  },
  productImage: {
    width: width * 0.14,
    aspectRatio: 1,
    borderRadius: 5,
    marginRight: '5%',
  },
  productDetails: {
    flex: 1,
    borderWidth: 1,
  },
  starView: {
    starView: {
      flexDirection: 'row',
      // marginBottom: "3%",
      alignItems: 'center',
    },
    starIcon: {
      marginLeft: '2%',
      flexDirection: 'row',
    },
    chatimage: {
      width: 200,
      height: 200,
      borderRadius: 10,
      resizeMode: 'cover',
      alignSelf: 'center',
      marginBottom: 5,
      borderWidth: 1,
    },
  },
});

export default ChatUI;
