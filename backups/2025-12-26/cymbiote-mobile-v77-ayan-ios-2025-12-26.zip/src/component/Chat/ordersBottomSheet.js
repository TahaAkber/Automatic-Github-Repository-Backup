import React, { forwardRef } from 'react';
import { View, StyleSheet, ActivityIndicator, Dimensions } from 'react-native';
import GorhomBottomSheet from '../../materialComponent/bottomSheet/GorhomBottomSheet';
import useActiveOrders from './useActiveOrder';
import OrderHistoryCard from '../cards/orderHistoryCard/orderHistoryCard';
import { navigate } from '../../utils/navigationRef/navigationRef';
import EmptyScreen from '../emptyScreen/emptyScreen';
import { margin } from '../../constant/contstant';
import { BottomSheetFlatList, BottomSheetView } from '@gorhom/bottom-sheet';
import CustomText from '../../materialComponent/customText/customText';

const { width, height } = Dimensions.get('screen');

// Reusable list item component
const OrderListItem = ({ item }) => {
  if (typeof item === 'number') {
    // For testing purposes (you can replace with actual order object)
    return <CustomText text={`Order ID: ${item}`} color="black" />;
  }

  return (
    <OrderHistoryCard
      item={item}
      onPress={() => navigate('ReviewDetail')}
      isBordered={true}
    />
  );
};

const OrdersBottomSheet = forwardRef(({ }, ref) => {
  const { fetch_active_order, fetch_active_order_loader } = useActiveOrders();

  return (
    <GorhomBottomSheet
      ref={ref}>
      <BottomSheetView style={styles.ordersContainer}>
        {fetch_active_order_loader ? (
          <ActivityIndicator size="large" color="#0000ff" />
        ) : fetch_active_order?.length === 0 ? (
          <View style={{ justifyContent: 'center', alignItems: 'center' }}>
            <EmptyScreen
              image={'empty_order'}
              heading={'No Orders Yet!'}
              desc={
                'Looks like you haven’t placed any orders. Start shopping now and track your purchases here!'
              }
            />
          </View>
        ) : (
          <BottomSheetFlatList
            data={fetch_active_order?.length ? fetch_active_order : [12, 34, 5]}
            keyExtractor={(item, index) =>
              item?.id?.toString() || index.toString()
            }
            renderItem={({ item }) => <OrderListItem item={item} />}
            contentContainerStyle={{ paddingBottom: 20 }}
            showsVerticalScrollIndicator={false}
          />
        )}
      </BottomSheetView>
    </GorhomBottomSheet>
  );
});

const styles = StyleSheet.create({
  sheetContainer: {
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
  },
  ordersContainer: { flex: 1 },
});

export default OrdersBottomSheet;
