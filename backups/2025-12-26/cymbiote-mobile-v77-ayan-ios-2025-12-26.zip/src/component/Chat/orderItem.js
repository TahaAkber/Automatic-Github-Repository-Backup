import React from 'react';
import {
  View,
  Text,
  FlatList,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
} from 'react-native';
import CustomImage from '../../materialComponent/image/image';
import CustomText from '../../materialComponent/customText/customText';
import {colors, font} from '../../constant/contstant';

const {fontScale, width, height} = Dimensions.get('screen');

const OrderItem = ({
  orderId,
  status,
  onSend,
  disableSendFunction = false,
  itemCount,
  images,
  showSendButton = false,
  onPressSend,
  buttonText = 'Send',
}) => {
  const renderItem = ({item, index}) => {
    const isLastItem = index === 2 && images.length === 2;
    return (
      <View style={[styles.imageWrapper]}>
        <CustomImage style={styles.image} source={item} size="small" />
      </View>
    );
  };
  const handleSendPress = () => {
    if (!disableSendFunction && onSend) {
      onSend({
        id: orderId,
        orderId,
        status,
        itemsCount: itemCount,
        images: images?.length > 0 ? images : [],
      });
    }
  };

  return (
    <>
      <View style={styles.orderBox}>
        <View style={styles.orderCard}>
          {/* Image Grid */}
          <FlatList
            data={images}
            numColumns={2}
            keyExtractor={(item, index) => index.toString()}
            renderItem={renderItem}
          />
        </View>
        <View style={styles.orderDetails}>
          <View>
            <CustomText
              text={`Order ${orderId}`}
              fontFamily={font.bold}
              fontSize={fontScale * 12}
            />
            <CustomText
              text={'Standard Delivery'}
              style={styles.standardDelivery}
              fontSize={fontScale * 12}
              fontFamily={font.medium}
            />
          </View>
          <CustomText
            text={status}
            fontSize={fontScale * 16}
            fontFamily={font.bold}
          />
        </View>
        <View style={styles.thirdView}>
          <View style={styles.itemCountContainer}>
            <CustomText
              text={'3 items'}
              fontFamily={font.medium}
              fontSize={fontScale * 11}
            />
          </View>
          {showSendButton && (
            <TouchableOpacity onPress={handleSendPress}>
              <View style={styles.sendButton}>
                <CustomText
                  text={buttonText}
                  color={'#fff'}
                  fontSize={fontScale * 14}
                  fontFamily={font.medium}
                />
              </View>
            </TouchableOpacity>
          )}
        </View>
      </View>
    </>
  );
};

const styles = StyleSheet.create({
  orderCard: {
    backgroundColor: '#fff',
    borderRadius: 10,

    width: width * 0.26,
    // height: height * 0.13,
    padding: '0.6%',
    // borderColor: "#F9F9F9"
  },
  orderBox: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: '5%',
  },
  orderDetails: {
    marginVertical: '1%',
    // marginLeft: "1%",
    flexDirection: 'column',
    // alignSelf: "flex-start",
    // alignItems: "flex-start",
    height: height * 0.11,
    justifyContent: 'space-between',
    // paddingVertical: "2%",
  },
  standardDelivery: {
    // marginBottom: 35
  },

  itemCountContainer: {
    backgroundColor: '#F9F9F9',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
    alignSelf: 'flex-end',
  },

  imageWrapper: {
    flex: 1,
    margin: '1%',
    marginTop: '2.5%',
    marginLeft: '2.2%',
    overflow: 'hidden',
  },
  fullWidthImage: {
    flexBasis: '100%',
  },
  image: {
    // width: width * 0.121,
    aspectRatio: 1,
    borderRadius: 8,
  },
  sendButton: {
    backgroundColor: colors.light_theme.theme,
    borderRadius: 8,
    padding: 6,
    alignItems: 'center',
    width: width * 0.18,
    justifyContent: 'center',
  },
  sendText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  thirdView: {
    height: height * 0.11,
    alignItems: 'center',
    justifyContent: 'space-between',
    alignSelf: 'center',
    width: width * 0.25,
    flexDirection: 'column',
    // borderWidth:1
  },
  borderLine: {
    marginLeft: 0,
    width: '95%',
    backgroundColor: '#00000033',
    height: height * 0.003,
    alignSelf: 'center',
    opacity: 0.3,
    height: '1%',
  },
});

export default OrderItem;
