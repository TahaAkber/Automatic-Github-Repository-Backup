import React from 'react';
import {
  StyleSheet,
  View,
  TouchableOpacity,
  Animated,
  Dimensions,
} from 'react-native';
import Container from '@materialComponent/container/container';
import SnakeWave from '@materialComponent/snakeWave/snakeWave';
import CustomText from '@materialComponent/customText/customText';
import AppIcon from '@assets/images/app_icon.svg';
import {font, globalStyle, margin, WH, colors} from '@constant/contstant';
import {moderateScale, verticalScale} from 'react-native-size-matters';
import LoginForm from '@screen/authentication/login/loginForm';
import RegisterForm from '@screen/authentication/register/registerForm';
import BottomSheetReUsable from '@materialComponent/bottomSheet/bottomSheet';
import {forgotPasswordData} from '@constant/bottomSheetData';
import useAuthControl from './useAuthControl';
import TopBackOverLay from '../../materialComponent/backOverlay/topBackOverlay';
import Content from '../../materialComponent/content/content';

const AuthControl = () => {
  const {
    setSelectedButton,
    handleButtonPress,
    selectedButton,
    slideAnimation,
    refRBSheet,
    isFocused,
    IsView,
  } = useAuthControl({});

  return (
    <IsView style={{flex: 1}}>
      <Container
        isFocused={isFocused}
        dark
        barColor={'transparent'}
        translucent={true}>
        <SnakeWave />
        <TopBackOverLay />

        <View style={styles.headerContainer}>
          <AppIcon width={WH.height(6)} height={WH.height(6)} />
          <View style={styles.titleContainer}>
            <CustomText
              center
              fontFamily={font.bold}
              text={
                selectedButton == 'signup'
                  ? 'Sign up to your Account'
                  : 'Sign in to your Account'
              }
              style={styles.titleText}
            />
          </View>
          <View style={styles.subtitleContainer}>
            <CustomText
              center
              fontSize={moderateScale(12)}
              fontFamily={font.light}
              text={
                selectedButton == 'login'
                  ? 'Enter your email and password to log in'
                  : 'Enter your details to sign up '
              }
            />
          </View>
        </View>
        <View style={styles.buttonContainer}>
          <Animated.View
            style={[styles.slider, {transform: [{translateX: slideAnimation}]}]}
          />
          <TouchableOpacity
            activeOpacity={0.8}
            onPress={() => handleButtonPress('login')}
            style={styles.button}>
            <CustomText
              text={'Log In'}
              style={[
                styles.buttonText,
                selectedButton !== 'login' && {color: '#7D7D91'},
              ]}
            />
          </TouchableOpacity>
          <TouchableOpacity
            activeOpacity={0.8}
            onPress={() => handleButtonPress('signup')}
            style={styles.button}>
            <CustomText
              text={'Sign Up'}
              style={[
                styles.buttonText,
                selectedButton !== 'signup' && {color: '#7D7D91'},
              ]}
            />
          </TouchableOpacity>
        </View>
        {selectedButton == 'login' ? (
          <LoginForm
            handleButtonPress={handleButtonPress}
            refRBSheet={refRBSheet}
          />
        ) : (
          <RegisterForm />
        )}

        <BottomSheetReUsable
          height={WH.height(20)}
          refRBSheet={refRBSheet}
          data={forgotPasswordData}
        />
      </Container>
    </IsView>
  );
};

export default AuthControl;

const styles = StyleSheet.create({
  headerContainer: {
    marginHorizontal: margin.horizontal,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: globalStyle.paddingVertical.paddingVertical,
  },
  titleContainer: {
    width: '80%',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: WH.height(2),
  },
  titleText: {
    fontFamily: font.bold,
    fontSize: moderateScale(25),
    color: 'black',
  },
  subtitleContainer: {
    width: '80%',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: verticalScale(10),
  },
  buttonContainer: {
    flexDirection: 'row',
    marginHorizontal: margin.horizontal,
    marginTop: WH.height(4),
    paddingHorizontal: WH.width(1),
    borderRadius: 15,
    backgroundColor: colors.light_theme.backgroundColor,
    borderWidth: 2,
    borderColor: '#f1f1f1',
    position: 'relative',
    marginBottom: verticalScale(20),
  },
  slider: {
    position: 'absolute',
    width: '50%',
    height: '100%',
    backgroundColor: 'white',
    borderRadius: 15,
  },
  button: {
    flex: 1,
    marginVertical: WH.height(0.3),
    paddingVertical: WH.height(1),
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 10,
  },
  buttonText: {
    fontFamily: font.medium,
  },
});
