import {_sendOtp} from '@redux/actions/auth/auth';
import {useRef, useState} from 'react';
import {Animated, View} from 'react-native';
import {WH} from '@constant/contstant';
import {useIsFocused} from '@react-navigation/native';
import Content from '../../materialComponent/content/content';

const useAuthControl = ({route}) => {
  const [selectedButton, setSelectedButton] = useState('login');
  const slideAnimation = useRef(new Animated.Value(0)).current;
  const isFocused = useIsFocused();
  const refRBSheet = useRef(null);
  const handleButtonPress = button => {
    if (button === selectedButton) return;

    // const buttonWidth = screenWidth * 0.45; // Calculate 45% of the screen width
    const toValue = button === 'signup' ? WH.width(45.3) : 0;

    Animated.timing(slideAnimation, {
      toValue,
      duration: 300,
      useNativeDriver: true,
    }).start(() => {
      setSelectedButton(button);
    });
  };

  const IsView = selectedButton == 'login' ? View : Content;

  return {
    setSelectedButton,
    handleButtonPress,
    selectedButton,
    slideAnimation,
    refRBSheet,
    isFocused,
    IsView
  };
};

export default useAuthControl;
