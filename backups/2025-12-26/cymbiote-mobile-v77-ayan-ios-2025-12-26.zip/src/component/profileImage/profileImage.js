import React, { useRef } from 'react';
import { Dimensions, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { moderateScale, scale, verticalScale } from 'react-native-size-matters';

import BottomSheetForLibrary from '@materialComponent/bottomSheet/cameraSheet';
import CustomButton from '@materialComponent/customButton/customButton';
import CustomImage from '@materialComponent/image/image';
import Icon from '@materialComponent/icon/icon';

import { colors, font, shadow, globalStyle, WH } from '@constant/contstant';
import useReduxStore from '@utils/hooks/useReduxStore';
import { ProfileDisplay } from '../../helper/reUsableMethod/reUsableMethod';
import CustomText from '../../materialComponent/customText/customText';

const { width, height, fontScale } = Dimensions.get("screen")

const ProfileImage = ({ item, edit, onPress, email, username, photo }) => {
    const navigation = useNavigation();
    const refRBSheet = useRef();
    const { getState } = useReduxStore();
    const { token, guest_name } = getState("auth");

    return (
        <React.Fragment>
            <View style={[styles.container, edit && { alignSelf: "center" }]}>
                <View style={styles.imageContainer}>
                    {/* <CustomImage source={{ uri: ProfileDisplay(token, photo) }} style={styles.image} /> */}
                    <CustomImage source={{ uri: item.image }} style={styles.image} />
                    {edit && (
                        <TouchableOpacity
                            onPress={() => refRBSheet?.current?.open()}
                            style={styles.editIconContainer}>
                            <Icon
                                icon_type="AntDesign"
                                name="edit"
                                size={moderateScale(14)}
                                color="black"
                            />
                        </TouchableOpacity>
                    )}
                </View>
                {edit ? null : (
                    <View style={styles.textContainer}>
                        {token ? (
                            <>
                                <Text style={styles.name}>{username}</Text>
                                <Text style={styles.email}>{email}</Text>
                                <CustomButton
                                    onPress={() => navigation.navigate("EditProfile")}
                                    buttonStyle={styles.editProfileButton}
                                    fontSize={moderateScale(10)}
                                    height={WH.height(3)}
                                    width={WH.width(30)}
                                    text="Edit Profile"
                                />
                            </>
                        ) : (
                            <>
                                <Text style={[styles.name, styles.guestUserName]}>Guest user</Text>
                                <CustomButton
                                    onPress={() => navigation.navigate("AuthNavigator")}
                                    buttonStyle={styles.signInButton}
                                    outline
                                    fontSize={moderateScale(10)}
                                    height={WH.height(3)}
                                    width={WH.width(30)}
                                    text="Sign in"
                                />
                            </>
                        )}
                    </View>
                )}
                <BottomSheetForLibrary refRBSheet={refRBSheet} />
            </View>

            <CustomText fontSize={fontScale * 19} fontFamily={font.medium} center text={"John Doe"} />

        </React.Fragment>
    );
};

export default ProfileImage;

const styles = StyleSheet.create({
    container: {
        paddingVertical: verticalScale(10),
        // marginBottom: verticalScale(10),
        paddingHorizontal: scale(10),
        backgroundColor: 'white',
        ...globalStyle.row,
    },
    imageContainer: {
        width: width * 0.29,
        aspectRatio: 1,
        backgroundColor: 'white',
        padding: 10,
        ...shadow,
        justifyContent: "center",
        alignItems: "center",
        borderRadius: 180,
        marginTop: height * 0.02
    },
    image: {
        width: width * 0.26,
        borderRadius: 180,
        aspectRatio: 1,
    },
    editIconContainer: {
        width: WH.width(7),
        aspectRatio: 1,
        backgroundColor: 'white',
        alignItems: 'center',
        justifyContent: 'center',
        position: 'absolute',
        right: 10,
        bottom: 5,
        borderRadius: 180,
        ...shadow,
    },
    textContainer: {
        marginLeft: scale(10),
        width: '75%',
    },
    name: {
        fontSize: moderateScale(12),
        fontFamily: font.bold,
        color: 'black',
    },
    guestUserName: {
        fontFamily: font.medium,
    },
    email: {
        fontSize: moderateScale(10),
        fontFamily: font.medium,
        color: 'black',
    },
    editProfileButton: {
        borderRadius: 5,
        marginTop: WH.height(1),
    },
    signInButton: {
        borderRadius: 5,
        marginTop: WH.height(1),
    },
});
