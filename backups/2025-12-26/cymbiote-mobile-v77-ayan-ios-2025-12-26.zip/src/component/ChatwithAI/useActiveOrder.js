import {useEffect, useState, useCallback} from 'react';
import {_getActiveOrders} from '../../redux/actions/orders/orders';
import {useFocusEffect} from '@react-navigation/native';
import useReduxStore from '../../utils/hooks/useReduxStore';

const useActiveOrders = () => {
  const {dispatch, getState} = useReduxStore();

  const {
    fetch_active_order,
    fetch_active_order_loader,
    fetch_active_order_error,
  } = getState('order');
  const [pullLoader, setPullLoader] = useState(false);

  const fetchAPI = async isLoading => {
    await dispatch(_getActiveOrders());
  };

  useFocusEffect(
    useCallback(() => {
      fetchAPI(true);
    }, []),
  );

  return {
    fetch_active_order,
    fetch_active_order_loader,
    fetch_active_order_error,
    pullLoader,
    fetchAPI,
  };
};

export default useActiveOrders;
