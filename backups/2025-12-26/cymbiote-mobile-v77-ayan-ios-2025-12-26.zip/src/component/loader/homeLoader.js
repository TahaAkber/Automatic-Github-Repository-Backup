import {Image, StyleSheet, Text, View} from 'react-native';
import React from 'react';
import {colors, globalStyle, WH} from '@constant/contstant';
import Container from '@materialComponent/container/container';
import CustomSkeleton from '@materialComponent/customSkeleton/customSkeleton';
import {moderateScale, verticalScale} from 'react-native-size-matters';
import {tileHeight} from '../../constant/contstant';
import {
  heightPercentageToDP,
  widthPercentageToDP,
} from 'react-native-responsive-screen';

const HomeLoader = ({loading}) => {
  return (
    <Container barColor={'#f4f4f4'}>
      {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((_, index) => (
        <View
          style={{
            marginTop: verticalScale(20),
            height: tileHeight,
            borderRadius: moderateScale(20),
            overflow: 'hidden',
            backgroundColor: 'white',
            borderWidth: 1,
            borderColor: '#f7f7f7',
          }}>
          <View style={{flex: 1, justifyContent: 'space-between', padding: 10}}>
            <View
              style={{
                flexDirection: 'row',
                justifyContent: 'space-between',
                alignItems: 'center',
              }}>
              <View
                style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                }}>
                <CustomSkeleton
                  loading={loading}
                  style={{
                    width: widthPercentageToDP(15),
                    aspectRatio: 1,
                    borderRadius: 180,
                  }} // Rectangular shape
                />
                <View style={{marginLeft: 5}}>
                  <CustomSkeleton
                    loading={loading}
                    style={{
                      width: widthPercentageToDP(15),
                      height: 10,
                      borderRadius: 5,
                    }} // Rectangular shape
                  />
                  <View style={{marginTop: 5}}>
                    <CustomSkeleton
                      loading={loading}
                      style={{
                        width: widthPercentageToDP(12),
                        height: 10,
                        borderRadius: 5,
                      }} // Rectangular shape
                    />
                  </View>
                </View>
              </View>

              <CustomSkeleton
                loading={loading}
                style={{
                  width: widthPercentageToDP(20),
                  height: heightPercentageToDP(3.5),
                  borderRadius: 10,
                }} // Rectangular shape
              />
            </View>
            <View style={{flexDirection: 'row', alignItems: 'center'}}>
              <View style={{width: '70%', marginRight: '3%'}}>
                <CustomSkeleton
                  loading={loading}
                  style={styles.tile} // Rectangular shape
                />
              </View>
              <View style={{width: '70%'}}>
                <CustomSkeleton
                  loading={loading}
                  style={styles.tile} // Rectangular shape
                />
              </View>
            </View>
          </View>
        </View>
      ))}
    </Container>
  );
};

export default HomeLoader;

const styles = StyleSheet.create({
  storyText: {
    width: WH.width(17),
    height: WH.width(3),
    borderRadius: 10,
  },
  story: {
    marginRight: moderateScale(10),
    height: WH.width(17),
    width: WH.width(17),
    borderRadius: 180,
  },
  following: {
    borderRadius: moderateScale(12),
    marginRight: moderateScale(5),
    height: WH.width(15),
    width: WH.width(15),
  },
  recentlyViewed: {
    borderRadius: moderateScale(12),
    marginRight: moderateScale(10),
    height: WH.width(25),
    width: WH.width(25),
  },
  tile: {
    height: heightPercentageToDP(25),
    width: '100%',
    borderRadius: 10,
  },
});
