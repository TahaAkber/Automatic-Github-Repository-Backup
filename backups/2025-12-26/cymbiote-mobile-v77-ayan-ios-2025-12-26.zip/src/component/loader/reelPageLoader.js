import React from 'react';
import {View, StyleSheet, Dimensions} from 'react-native';
import CustomSkeleton from '@materialComponent/customSkeleton/customSkeleton'; // Import CustomSkeleton

const {width} = Dimensions.get('screen');

const ReelPageLoader = () => (
  <View style={styles.skeletonContainer}>
    {/* Brand Skeleton (Rounded Image) */}
    <View style={styles.brandContainer}>
      <CustomSkeleton loading={true} style={styles.skeletonBrand} />
      {/* Skeleton for Brand Name */}
      <CustomSkeleton loading={true} style={styles.skeletonText} />
    </View>

    {/* Thumbnails Skeleton */}
    <View style={styles.skeletonThumbnailContainer}>
      {[...Array(6)].map((_, index) => (
        <View key={index} style={styles.thumbnailItem}>
          <CustomSkeleton loading={true} style={styles.skeletonThumbnail} />
          <CustomSkeleton loading={true} style={styles.skeletonOverlay} />
          <CustomSkeleton loading={true} style={styles.skeletonViewCount} />
        </View>
      ))}
    </View>
  </View>
);

const styles = StyleSheet.create({
  skeletonContainer: {
    paddingHorizontal: width * 0.01,
    paddingTop: 20,
  },
  skeletonHeader: {
    height: 150,
    backgroundColor: '#e0e0e0',
    borderRadius: 10,
    marginBottom: 20,
  },
  skeletonTab: {
    height: 40,
    backgroundColor: '#e0e0e0',
    borderRadius: 5,
    marginBottom: 20,
  },
  brandContainer: {
    alignItems: 'center', // Center the image and text
    marginBottom: 20,
  },
  skeletonBrand: {
    width: 100, // Width for the circular brand skeleton
    height: 100, // Height to make it circular
    backgroundColor: '#e0e0e0',
    borderRadius: 50, // Make it round
  },
  skeletonText: {
    marginTop: 10,
    width: 120, // Set width for the skeleton text
    height: 20, // Set height for the skeleton text
    backgroundColor: '#e0e0e0', // Skeleton color
    borderRadius: 10, // Rounded corners for the skeleton text
  },
  skeletonThumbnailContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'flex-start',
  },
  thumbnailItem: {
    width: width * 0.31,
    height: width * 0.4,
    marginBottom: width * 0.01,
    marginLeft: 3,
  },
  skeletonThumbnail: {
    width: '100%',
    height: '100%',
    backgroundColor: '#e0e0e0',
    borderRadius: 10,
  },
  skeletonOverlay: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    width: '100%',
    height: 20,
    backgroundColor: 'rgba(0, 0, 0, 0.4)',
    borderRadius: 10,
  },
  skeletonViewCount: {
    position: 'absolute',
    bottom: 10,
    left: 5,
    backgroundColor: '#e0e0e0',
    width: 50,
    height: 20,
    borderRadius: 10,
  },
});

export default ReelPageLoader;
