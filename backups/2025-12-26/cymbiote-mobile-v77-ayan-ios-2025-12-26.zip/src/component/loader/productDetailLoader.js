import { Dimensions, StyleSheet, View } from 'react-native';
import React from 'react';
import { WH } from '@constant/contstant';
import CustomSkeleton from '@materialComponent/customSkeleton/customSkeleton';
import { moderateScale, verticalScale } from 'react-native-size-matters';
import { globalStyle, margin } from '../../constant/contstant';

const { height } = Dimensions.get("screen")

const ProductDetailLoader = ({ loading }) => {
  return (
    <View style={styles.container}>
      <View style={styles.cardSkeleton}>
        <View style={styles.rightContainer}>
          <View style={[styles.topRow,]}>
            <CustomSkeleton
              loading={loading}
              style={styles.orderTitleSkeleton}
            />
            <CustomSkeleton
              loading={loading}
              style={[styles.orderTitleSkeleton, { width: WH.width(20) }]}
            />
          </View>

          <View style={{ marginTop: height * 0.01, ...globalStyle.space_between }}>
            <CustomSkeleton
              loading={loading}
              style={styles.detailsSkeleton}
            />
          </View>

          <View style={{ marginTop: height * 0.03, ...globalStyle.row }}>
            <CustomSkeleton
              loading={loading}
              style={[styles.detailsSkeleton, { height: verticalScale(15), width: WH.width(15) }]}
            />
            <View style={{ marginLeft: WH.width(5), ...globalStyle.row }}>
              {[1, 2, 3, 4].map((_, index) => (
                <View style={{ marginRight: 10 }}>
                  <CustomSkeleton
                    loading={loading}
                    style={[styles.detailsSkeleton, { width: WH.width(8), height: WH.width(5) }]}
                  />
                </View>
              ))}
            </View>
          </View>


          <View style={{ marginTop: height * 0.03, ...globalStyle.space_between }}>
            <View style={{ width: "100%" }}>
              <CustomSkeleton
                loading={loading}
                style={[styles.detailsSkeleton, { height: height * 0.054, width: "100%" ,borderRadius: 180 }]}
              />
            </View>
          </View>
          <View style={{ marginTop: height * 0.01, ...globalStyle.space_between }}>
            <View style={{ width: "100%" }}>
              <CustomSkeleton
                loading={loading}
                style={[styles.detailsSkeleton, { height: height * 0.054, width: "100%", borderRadius: 180 }]}
              />
            </View>
          </View>


          <View style={{ marginTop: height * 0.03, }}>
            <CustomSkeleton
              loading={loading}
              style={[styles.detailsSkeleton, { height: height * 0.02, width: WH.width(40), }]}
            />
          </View>
          <View style={{ marginTop: height * 0.02 }}>
            <CustomSkeleton
              loading={loading}
              style={[styles.detailsSkeleton, { height: height * 0.015, width: WH.width(90), }]}
            />
            <View style={{ marginTop: height * 0.01 }}>
              <CustomSkeleton
                loading={loading}
                style={[styles.detailsSkeleton, { height: height * 0.015, width: WH.width(90), }]}
              />
            </View>
            <View style={{ marginTop: height * 0.01 }}>
              <CustomSkeleton
                loading={loading}
                style={[styles.detailsSkeleton, { height: height * 0.015, width: WH.width(90), }]}
              />
            </View>
          </View>
          <View style={{ marginTop: height * 0.03, flexDirection: "row", alignItems: "center" }}>
            <CustomSkeleton
              loading={loading}
              style={[styles.detailsSkeleton, { height: height * 0.02, width: WH.width(40), }]}
            />
            <View style={{ marginLeft: 10 }}>
              <CustomSkeleton
                loading={loading}
                style={[styles.detailsSkeleton, { height: height * 0.025, width: height * 0.025, aspectRatio: 1, borderRadius: 180 }]}
              />
            </View>
          </View>
          <View style={{ marginTop: height * 0.03, flexDirection: "row", flexWrap: "wrap", justifyContent: "space-between" }}>
            <View style={{ width: "48%" }}>
              <CustomSkeleton
                loading={loading}
                style={[styles.detailsSkeleton, { height: height * 0.15, width: WH.width(42), borderRadius: 10 }]}
              />
              <View style={{ marginTop: height * 0.01 }}>
                <CustomSkeleton
                  loading={loading}
                  style={[styles.detailsSkeleton, { height: height * 0.015, width: WH.width(30), borderRadius: 10 }]}
                />
              </View>
              <View style={{ marginTop: height * 0.01 }}>
                <CustomSkeleton
                  loading={loading}
                  style={[styles.detailsSkeleton, { height: height * 0.01, width: WH.width(10), borderRadius: 10 }]}
                />
              </View>
            </View>
            <View style={{ width: "48%" }}>
              <CustomSkeleton
                loading={loading}
                style={[styles.detailsSkeleton, { height: height * 0.15, width: WH.width(42), borderRadius: 10 }]}
              />
              <View style={{ marginTop: height * 0.01 }}>
                <CustomSkeleton
                  loading={loading}
                  style={[styles.detailsSkeleton, { height: height * 0.015, width: WH.width(30), borderRadius: 10 }]}
                />
              </View>
              <View style={{ marginTop: height * 0.01 }}>
                <CustomSkeleton
                  loading={loading}
                  style={[styles.detailsSkeleton, { height: height * 0.01, width: WH.width(10), borderRadius: 10 }]}
                />
              </View>
            </View>
            <View style={{ width: "48%", marginTop: height * 0.01 }}>
              <CustomSkeleton
                loading={loading}
                style={[styles.detailsSkeleton, { height: height * 0.15, width: WH.width(44), borderRadius: 10 }]}
              />
              <View style={{ marginTop: height * 0.01 }}>
                <CustomSkeleton
                  loading={loading}
                  style={[styles.detailsSkeleton, { height: height * 0.015, width: WH.width(30), borderRadius: 10 }]}
                />
              </View>
              <View style={{ marginTop: height * 0.01 }}>
                <CustomSkeleton
                  loading={loading}
                  style={[styles.detailsSkeleton, { height: height * 0.01, width: WH.width(10), borderRadius: 10 }]}
                />
              </View>
            </View>
            <View style={{ width: "48%", marginTop: height * 0.01 }}>
              <CustomSkeleton
                loading={loading}
                style={[styles.detailsSkeleton, { height: height * 0.15, width: WH.width(44), borderRadius: 10 }]}
              />
              <View style={{ marginTop: height * 0.01 }}>
                <CustomSkeleton
                  loading={loading}
                  style={[styles.detailsSkeleton, { height: height * 0.015, width: WH.width(30), borderRadius: 10 }]}
                />
              </View>
              <View style={{ marginTop: height * 0.01 }}>
                <CustomSkeleton
                  loading={loading}
                  style={[styles.detailsSkeleton, { height: height * 0.01, width: WH.width(10), borderRadius: 10 }]}
                />
              </View>
            </View>
          </View>
        </View>
      </View >
    </View >
  );
};

export default ProductDetailLoader;

const styles = StyleSheet.create({
  container: {
    marginTop: height * 0.01,
    marginHorizontal: margin.horizontal
  },
  cardSkeleton: {
    flexDirection: 'row', // Align image and content in a row
  },
  imageSkeleton: {
    // width: WH.width(15), // Adjust width for the image placeholder
    // height: WH.width(15), // Adjust height for the image placeholder
    // borderRadius: moderateScale(10), // Rounded corners for the image
    // marginRight: moderateScale(10), // Spacing between image and content
    width: "15%", aspectRatio: 1, borderRadius: 5
  },
  rightContainer: {
    flex: 1, // Take remaining space
    justifyContent: "space-evenly",
  },
  topRow: {
    flexDirection: 'row', // Align order title and button in a row
    justifyContent: 'space-between', // Space between title and button
  },
  orderTitleSkeleton: {
    width: WH.width(50), // Adjust width for the order title
    height: verticalScale(15), // Adjust height for the order title
    borderRadius: moderateScale(5),
    // marginTop: moderateScale(5)
  },
  buttonSkeleton: {
    width: WH.width(20), // Adjust width for the button
    height: verticalScale(20), // Adjust height for the button
    borderRadius: moderateScale(5),
    marginTop: moderateScale(2)
  },
  detailsSkeleton: {
    width: WH.width(30), // Adjust width for the order title
    height: verticalScale(15), // Adjust height for the details
    borderRadius: moderateScale(5),
  },
});