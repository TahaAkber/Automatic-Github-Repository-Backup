import React from 'react';
import {Dimensions, View, StyleSheet} from 'react-native';
import CustomSkeleton from '@materialComponent/customSkeleton/customSkeleton';


const {height, width} = Dimensions.get('screen');

const ReelsLoader = () => {
  return (

    <View style={styles.container}>
      <View style={styles.header}>
        <CustomSkeleton
          loading={true}
          highlightColor={'#F9F9F9'}
          style={styles.title}
        />
        <CustomSkeleton
          loading={true}
          highlightColor={'#F9F9F9'}
          style={styles.viewAll}
        />
      </View>
      <View style={styles.reelsContainer}>
        {[1, 2, 3].map((_, index) => (
          <View key={index} style={styles.reelItem}>
            <CustomSkeleton
              loading={true}
              highlightColor={'#F9F9F9'}
              style={styles.reelImage}
            />
          </View>
        ))}
      </View>
    </View>

  );
};

const styles = StyleSheet.create({
  container: {
    marginTop: height * 0.03,
    paddingHorizontal: width * 0.04,
   
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: height * 0.02,
  },
  title: {
    width: width * 0.2,
    height: height * 0.025,
    borderRadius: 4,
  },
  viewAll: {
    width: width * 0.15,
    height: height * 0.02,
    borderRadius: 4,
  },
  reelsContainer: {
    flexDirection: 'row',
  },
  reelItem: {
    marginRight: width * 0.03,
  },
  reelImage: {
    width: width * 0.3,
    height: width * 0.5,
    borderRadius: 10,
  },
});

export default ReelsLoader;