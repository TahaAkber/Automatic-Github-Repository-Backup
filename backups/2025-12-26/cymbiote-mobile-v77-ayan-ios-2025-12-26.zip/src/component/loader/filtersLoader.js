import React from 'react';
import {Dimensions, View, StyleSheet} from 'react-native';
import CustomSkeleton from '@materialComponent/customSkeleton/customSkeleton';


const {height, width} = Dimensions.get('screen');

const FiltersLoader = () => {
  return (
  
    <View style={styles.container}>
      <CustomSkeleton
        loading={true}
        highlightColor={'#F9F9F9'}
        style={styles.title}
      />
      <View style={styles.filtersContainer}>
        {[1, 2, 3,4,5].map((_, index) => (
          <View key={index} style={styles.filterItem}>
            <CustomSkeleton
              loading={true}
              highlightColor={'#F9F9F9'}
              style={styles.filterButton}
            />
          </View>
        ))}
      </View>
    </View>

  );
};

const styles = StyleSheet.create({
  container: {
    // marginTop: height * 0.02,
    paddingHorizontal: width * 0.04,
    marginBottom: height * 0.02,
  },
  title: {
    width: width * 0.25,
    height: height * 0.025,
    borderRadius: 4,
    marginBottom: height * 0.02,
  },
  filtersContainer: {
    flexDirection: 'row',
  },
  filterItem: {
    marginRight: width * 0.03,
  },
  filterButton: {
    width: width * 0.2,
    height: height * 0.035,
    borderRadius: 15,
  },
});

export default FiltersLoader;