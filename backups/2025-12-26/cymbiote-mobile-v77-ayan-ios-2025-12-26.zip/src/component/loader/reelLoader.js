// src/screens/reels/ReelLoader.js
import React from 'react';
import {View, StyleSheet, Dimensions} from 'react-native';
import {moderateScale, scale, verticalScale} from 'react-native-size-matters';
import CustomSkeleton from '@materialComponent/customSkeleton/customSkeleton';

const {width, height} = Dimensions.get('screen');

const ReelLoader = () => {
  return (
    <View style={styles.container}>
      {/* Fullscreen Video Area */}
      <CustomSkeleton
        loading
        style={styles.videoArea}
        borderRadius={0}
        color="#1a1a1a"
        highlightColor="#424141ff"
      />

      {/* Right-side Profile + LCS buttons */}
      {/* <View style={styles.lcsContainer}>
        <CustomSkeleton
          loading
          style={styles.profileIcon}
          borderRadius={50}
          color="#1a1a1a"
          highlightColor="#3d3d3d"
        />
        <CustomSkeleton
          loading
          style={styles.lcsIcon}
          borderRadius={50}
          color="#1a1a1a"
          highlightColor="#3d3d3d"
        />
        <CustomSkeleton
          loading
          style={styles.lcsIcon}
          borderRadius={50}
          color="#1a1a1a"
          highlightColor="#3d3d3d"
        />
        <CustomSkeleton
          loading
          style={styles.lcsIcon}
          borderRadius={50}
          color="#1a1a1a"
          highlightColor="#3d3d3d"
        />
      </View> */}

      {/* Bottom info (avatar + username + caption lines) */}
      <View style={styles.bottomSection}>
        <CustomSkeleton
          loading
          style={styles.avatar}
          borderRadius={50}
          color="#1a1a1a"
          highlightColor="#3d3d3d"
        />
        <View style={styles.textBlock}>
          <CustomSkeleton
            loading
            style={styles.line}
            borderRadius={6}
            color="#1a1a1a"
            highlightColor="#3d3d3d"
          />
          <CustomSkeleton
            loading
            style={[styles.line, {width: width * 0.3}]}
            borderRadius={6}
            color="#1a1a1a"
            highlightColor="#3d3d3d"
          />
        </View>
      </View>

      {/* Product Card Skeleton (extra for your app) */}
      <View style={styles.productCard}>
        <CustomSkeleton
          loading
          style={styles.productImage}
          borderRadius={7}
          color="#1a1a1a"
          highlightColor="#3d3d3d"
        />
        <View style={styles.productText}>
          <CustomSkeleton
            loading
            style={styles.productLine}
            borderRadius={6}
            color="#1a1a1a"
            highlightColor="#3d3d3d"
          />
          <CustomSkeleton
            loading
            style={[styles.productLine, {width: width * 0.3}]}
            borderRadius={6}
            color="#1a1a1a"
            highlightColor="#3d3d3d"
          />
        </View>
        {/* <CustomSkeleton
          loading
          style={styles.likeButton}
          borderRadius={50}
          color="#1a1a1a"
          highlightColor="#3d3d3d"
        /> */}
      </View>
    </View>
  );
};

export default ReelLoader;

const styles = StyleSheet.create({
  container: {
    width,
    height,
    backgroundColor: '#000', // Dark reel background
    position: 'relative',
  },
  videoArea: {
    width,
    height,
  },
  // Right-side stacked icons
  lcsContainer: {
    position: 'absolute',
    right: scale(15),
    bottom: verticalScale(150),
    alignItems: 'center',
  },
  profileIcon: {
    width: moderateScale(45),
    height: moderateScale(45),
    marginBottom: verticalScale(20),
  },
  lcsIcon: {
    width: moderateScale(40),
    height: moderateScale(40),
    marginVertical: verticalScale(10),
  },
  // Bottom profile + caption
  bottomSection: {
    position: 'absolute',
    bottom: verticalScale(130),
    left: scale(20),
    flexDirection: 'row',
    alignItems: 'center',
  },
  avatar: {
    width: moderateScale(45),
    height: moderateScale(45),
    marginRight: scale(10),
    borderRadius: 100,
  },
  textBlock: {
    flexDirection: 'column',
  },
  line: {
    height: moderateScale(12),
    width: width * 0.5,
    marginBottom: verticalScale(6),
  },
  // Music bar
  musicBar: {
    position: 'absolute',
    bottom: verticalScale(90),
    left: scale(15),
  },
  musicLine: {
    height: moderateScale(10),
    width: width * 0.4,
  },
  // Product card skeleton
  productCard: {
    position: 'absolute',
    bottom: verticalScale(50),
    left: scale(15),
    right: scale(15),
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(30,30,30,0.6)',
    borderRadius: 10,
    padding: scale(10),
  },
  productImage: {
    width: moderateScale(55),
    height: moderateScale(55),
    borderRadius: 7,
  },
  productText: {
    flex: 1,
    marginLeft: scale(10),
  },
  productLine: {
    height: moderateScale(12),
    width: width * 0.4,
    marginBottom: verticalScale(6),
  },
  likeButton: {
    width: moderateScale(30),
    height: moderateScale(30),
    marginLeft: scale(10),
  },
});
