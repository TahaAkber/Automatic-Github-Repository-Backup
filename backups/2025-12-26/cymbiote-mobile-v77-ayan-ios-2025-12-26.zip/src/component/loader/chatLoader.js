// src/component/loader/CollectionLoader.js

import React from 'react';
import {View, StyleSheet, Dimensions, FlatList} from 'react-native';
import CustomSkeleton from '@materialComponent/customSkeleton/customSkeleton';
import {margin, WH} from '@constant/contstant';

const {width, height} = Dimensions.get('screen');

const ChatLoader = () => {
  const dummyItems = Array(10).fill(null);

  const renderItem = ({index}) => {
    const isRight = index % 2 === 0; // even index → right, odd → left

    return (
      <View
        style={[
          styles.skeletonCard,
          {alignSelf: isRight ? 'flex-start' : 'flex-end'},
        ]}>
        <CustomSkeleton loading style={styles.image} />
        <CustomSkeleton
          loading
          style={[
            styles.text,
            {alignSelf: isRight ? 'flex-start' : 'flex-end'},
          ]}
        />
      </View>
    );
  };

  return (
    <FlatList
      data={dummyItems}
      inverted
      showsHorizontalScrollIndicator={false}
      keyExtractor={(_, index) => index.toString()}
      renderItem={renderItem}
    />
  );
};

const styles = StyleSheet.create({
  skeletonCard: {
    width: WH.width(70),
    marginBottom: height * 0.04,
    alignSelf: 'flex-end',
  },
  image: {
    width: '100%',
    height: WH.width(10),
    borderRadius: 10,
  },
  text: {
    width: '20%',
    height: WH.width(3),
    borderRadius: 10,
    marginTop: 10,
  },
});

export default ChatLoader;
