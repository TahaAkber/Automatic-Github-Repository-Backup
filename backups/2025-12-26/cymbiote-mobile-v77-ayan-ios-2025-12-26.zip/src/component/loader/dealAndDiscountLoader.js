import {StyleSheet, View} from 'react-native';
import React from 'react';
import CustomSkeleton from '@materialComponent/customSkeleton/customSkeleton';
import {widthPercentageToDP} from 'react-native-responsive-screen';
import {WH} from '../../constant/contstant';
import {moderateScale, verticalScale} from 'react-native-size-matters';

const DealAndDiscountLoader = ({marginTop}) => {
  return (
    <View style={{marginVertical: marginTop}}>
      <View style={{marginBottom: verticalScale(5)}}>
        <CustomSkeleton
          loading={true}
          style={{
            width: WH.width(30),
            height: WH.height(1.5),
            borderRadius: 10,
          }} // Rectangular shape
        />
      </View>
      <View style={{flexDirection: 'row'}}>
        {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((_, index) => (
          <View style={{marginRight: moderateScale(10)}}>
            <CustomSkeleton
              loading={true}
              style={{
                width: WH.width(40),
                height: WH.width(30),
                borderRadius: 10,
              }} // Rectangular shape
            />
          </View>
        ))}
      </View>
    </View>
  );
};

export default DealAndDiscountLoader;

const styles = StyleSheet.create({});
