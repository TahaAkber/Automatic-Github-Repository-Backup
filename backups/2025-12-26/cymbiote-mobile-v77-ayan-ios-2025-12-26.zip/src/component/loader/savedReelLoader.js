// import React from 'react';
// import {StyleSheet, View, Dimensions, TouchableOpacity} from 'react-native';
// import CustomSkeleton from '@materialComponent/customSkeleton/customSkeleton';
// import {navigate} from '../../../utils/navigationRef/navigationRef';
// import {moderateScale} from 'react-native-size-matters';

// const {width} = Dimensions.get('screen');
// const CARD_WIDTH = width / 2 - 20;
// const LOGO_SIZE = CARD_WIDTH * 0.23;

// const SavedReelCardLoader = () => {
//   return (
//     <TouchableOpacity activeOpacity={0.85}>
//       <View style={styles.card}>
//         {/* Skeleton for Video Thumbnail */}
//         <CustomSkeleton loading style={styles.image} />

//         {/* Bottom Overlay Row */}
//         <View style={styles.overlayRow}>
//           {/* Brand Info */}
//           <View style={styles.brandPill}>
//             {/* Skeleton for Brand Logo */}
//             <CustomSkeleton loading style={styles.brandLogo} />
//             <View style={{flex: 1}}>
//               {/* Skeleton for Shop Name */}
//               {/* <CustomSkeleton loading style={styles.shopName} /> */}
//               {/* Skeleton for Rating */}
//               {/* <CustomSkeleton loading style={styles.rating} /> */}
//             </View>
//           </View>
//           {/* Skeleton for Badge Image */}
//           <View style={styles.badgeContainer}>
//             <CustomSkeleton loading style={styles.badgeImage} />
//           </View>
//         </View>
//       </View>
//     </TouchableOpacity>
//   );
// };

// export default SavedReelCardLoader;

// const styles = StyleSheet.create({
//   card: {
//     width: CARD_WIDTH,
//     aspectRatio: 0.74,
//     borderRadius: 12,
//     margin: 5,
//     overflow: 'hidden',
//     backgroundColor: '#fff',
//   },
//   image: {
//     width: '100%',
//     height: '100%',
//     borderRadius: 12,
//   },
//   overlayRow: {
//     position: 'absolute',
//     left: 0,
//     right: 0,
//     bottom: 0,
//     paddingHorizontal: 6,
//     paddingBottom: 6,
//     flexDirection: 'row',
//     justifyContent: 'space-between',
//   },
//   brandPill: {
//     flexDirection: 'row',
//     alignItems: 'center',
//     backgroundColor: 'transparent',
//     minWidth: CARD_WIDTH * 0.65,
//   },
//   brandLogo: {
//     width: LOGO_SIZE,
//     height: LOGO_SIZE,
//     borderRadius: 180,
//     borderWidth: 1,
//     borderColor: '#F4F4F4',
//   },
//   shopName: {
//     width: moderateScale(120),
//     height: moderateScale(14),
//     borderRadius: 10,
//     marginTop: 10,
//   },
//   rating: {
//     width: moderateScale(50),
//     height: moderateScale(12),
//     borderRadius: 8,
//     marginTop: 5,
//   },
//   badgeContainer: {
//     borderRadius: 10,
//     padding: 3,
//     justifyContent: 'center',
//     alignItems: 'center',
//   },
//   badgeImage: {
//     width: LOGO_SIZE * 0.99,
//     height: LOGO_SIZE * 0.99,
//     borderRadius: 7,
//   },
// });

import React from 'react';
import {Dimensions, FlatList, StyleSheet, View} from 'react-native';
import {moderateScale} from 'react-native-size-matters';
import CustomSkeleton from '../../materialComponent/customSkeleton/customSkeleton';

const dummyArray = Array(6).fill(0); // 6 items dummy array

const {width} = Dimensions.get('screen');
const CARD_WIDTH = width / 2 - 20;
const LOGO_SIZE = CARD_WIDTH * 0.23;

const SavedReelCardLoaderList = () => {
  return (
    <FlatList
      data={dummyArray}
      keyExtractor={(_, index) => index.toString()}
      renderItem={() => {
        return (
          <View activeOpacity={0.85}>
            <View style={styles.card}>
              {/* Skeleton for Video Thumbnail */}
              <CustomSkeleton loading style={styles.image} />

              {/* Bottom Overlay Row */}
              <View style={styles.overlayRow}>
                {/* Brand Info */}
                <View style={styles.brandPill}>
                  {/* Skeleton for Brand Logo */}
                  <CustomSkeleton loading style={styles.brandLogo} />
                  <View style={{flex: 1}}>
                    {/* Skeleton for Shop Name */}
                    {/* <CustomSkeleton loading style={styles.shopName} /> */}
                    {/* Skeleton for Rating */}
                    {/* <CustomSkeleton loading style={styles.rating} /> */}
                  </View>
                </View>
                {/* Skeleton for Badge Image */}
                <View style={styles.badgeContainer}>
                  <CustomSkeleton loading style={styles.badgeImage} />
                </View>
              </View>
            </View>
          </View>
        );
      }}
      numColumns={2} // Since card width is 50%, show 2 per row
      contentContainerStyle={styles.listContainer}
    />
  );
};

export default SavedReelCardLoaderList;

// const styles = StyleSheet.create({
//   listContainer: {
//     paddingHorizontal: 10,
//     paddingTop: 10,
//   },
// });

const styles = StyleSheet.create({
  listContainer: {
    paddingHorizontal: 10,
    paddingTop: 10,
  },
  card: {
    width: CARD_WIDTH,
    aspectRatio: 0.74,
    borderRadius: 12,
    margin: 5,
    overflow: 'hidden',
    backgroundColor: '#fff',
  },
  image: {
    width: '100%',
    height: '100%',
    borderRadius: 12,
  },
  overlayRow: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    paddingHorizontal: 6,
    paddingBottom: 6,
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  brandPill: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'transparent',
    minWidth: CARD_WIDTH * 0.65,
  },
  brandLogo: {
    width: LOGO_SIZE,
    height: LOGO_SIZE,
    borderRadius: 180,
    borderWidth: 1,
    borderColor: '#F4F4F4',
  },
  shopName: {
    width: moderateScale(120),
    height: moderateScale(14),
    borderRadius: 10,
    marginTop: 10,
  },
  rating: {
    width: moderateScale(50),
    height: moderateScale(12),
    borderRadius: 8,
    marginTop: 5,
  },
  badgeContainer: {
    borderRadius: 10,
    padding: 3,
    justifyContent: 'center',
    alignItems: 'center',
  },
  badgeImage: {
    width: LOGO_SIZE * 0.99,
    height: LOGO_SIZE * 0.99,
    borderRadius: 7,
  },
});
