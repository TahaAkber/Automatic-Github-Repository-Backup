import { View,StyleSheet,Dimensions } from "react-native"
import CustomText from "../../materialComponent/customText/customText";
import { colors, font, margin } from "../../constant/contstant";
import Search from "../../screen/loggedIn/search/search";
import SearchInput from "../input/searchInput";


const { width, height, fontScale } = Dimensions.get("screen")

const HelpSearch=()=>{
    return(
        <View style={styles.Container}>
            <View style={styles.SecondView}>  

<CustomText text={"Welcome"} fontSize={fontScale *22} color={"white"} fontFamily={font.bold}/>
<CustomText text={"to Cymbiote Help Center"} fontSize={fontScale *16} color={"white"} fontFamily={font.light}/>
<CustomText text={ "Hi john Doe! How Can we help you?"} fontSize={fontScale *17} color={"white"} fontFamily={font.bold} marginTop={height* 0.01 }/>

            </View>
            <View style={styles.serchView}>
<SearchInput placeholder={"Search Your Store Here..."} marginTop={height * 0.01} 
/>
</View>

        </View>
    )
}
export default HelpSearch;
const styles=StyleSheet.create({
    Container:{
              backgroundColor: colors.light_theme.theme,
                   paddingBottom: height * 0.02,
                   borderTopRightRadius: 12,
                   borderTopLeftRadius: 12,
                   
       },
       SecondView:{
       marginHorizontal:margin.horizontal,
       marginTop:"4%"
       
   
       },
       serchView:{
        marginHorizontal:"2%",
     
       }
})