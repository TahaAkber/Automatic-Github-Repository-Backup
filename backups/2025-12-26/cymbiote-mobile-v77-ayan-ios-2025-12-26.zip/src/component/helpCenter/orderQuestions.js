import { View,StyleSheet,Dimensions, FlatList, TouchableOpacity } from "react-native"
import CustomText from "../../materialComponent/customText/customText";
import { font, margin } from "../../constant/contstant";
import Icon from "../../materialComponent/icon/icon";



const { width, height, fontScale } = Dimensions.get("screen")

const OrderQuestions=({title,questions,onPress })=>{
    return(
        <View style={styles.container}>
              <CustomText text={title} marginTop={"4%"} fontSize={fontScale * 18} style={styles.SelfService} fontFamily={font.bold}/>
              <FlatList 
        data={questions}
        keyExtractor={(item, index )=>index.toString()}
        renderItem={({item})=>(
            <>
            <TouchableOpacity onPress={onPress}>
            <View style={styles.description}>
                    <CustomText text={item} fontFamily={font.medium} fontSize={fontScale * 14} />
                    <Icon icon_type={"AntDesign"} name={"right"}  size={fontScale * 16} color={"black"} />
                </View>
                </TouchableOpacity>
                 <View style={styles.line}/>
              </>  
        )}/>
        </View>
    )
}
export default OrderQuestions;

const styles = StyleSheet.create({
    container:{
        flex:1,
        backgroundColor:"white"
    },
    SelfService:{
                marginHorizontal:margin.horizontal
            },
            description:{  marginHorizontal:margin.horizontal,
                flexDirection:"row",
                alignItems:"center",
                justifyContent:"space-between",
                marginTop:"5%"
       },
       line:{
        // backgroundColor: colors.light_theme.borderColor,
        backgroundColor:"#b2b2b2",
        height:height * 0.001,
        marginHorizontal:margin.horizontal,
        marginTop:"5%"
    
      },
})
