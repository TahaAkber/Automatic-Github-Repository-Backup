import React, {useEffect, useMemo, useRef, useState} from 'react';
import {Platform, StyleSheet, View} from 'react-native';
import Video from 'react-native-video';
import * as RNFS from 'react-native-fs';
import NetInfo from '@react-native-community/netinfo';
import CustomImage from '../../materialComponent/image/image';

const cacheDir = Platform.select({
  ios: RNFS.LibraryDirectoryPath,
  android: RNFS.CachesDirectoryPath,
});

const SUPPORTED_EXTS = ['mp4', 'mov', 'm4v', 'webm', 'mkv', 'm3u8'];
const CACHEABLE_EXTS = ['mp4', 'mov', 'm4v', 'webm', 'mkv'];

const cleanUrl = url => (url || '').split('?')[0].split('#')[0].toLowerCase();
const getUniqueFileNameFromUrl = url =>
  (url || '').replace(/^https?:\/\//, '').replace(/[\/:.?&=]/g, '_');

const isHLS = url => cleanUrl(url).endsWith('.m3u8');

const isCacheableFile = url => {
  const u = cleanUrl(url);
  return !!u && CACHEABLE_EXTS.some(ext => u.endsWith(ext));
};

const getExtFromUrl = url => {
  const cleaned = cleanUrl(url);
  const last = cleaned.split('/').pop() || '';
  const dot = last.lastIndexOf('.');
  if (dot !== -1) {
    const ext = last.slice(dot + 1);
    if (SUPPORTED_EXTS.includes(ext)) {
      return ext;
    }
  }
  return 'mp4';
};

const ReelPreviewVideo = ({
  uri,
  thumbnailUri,
  paused = false,
  resizeMode = 'cover',
  style,
  muted = true,
  repeat = true,
  onCachedReady,
  onError,
  onReady,
  onLoad: onLoadProp,
  onLoadStart: onLoadStartProp,
  // ---- NEW: bandwidth controls (effective for HLS) ----
  targetKbps = 600, // HLS max bitrate cap (~600 kbps). Tune 400–1200.
  bufferMs = {
    // Android ExoPlayer buffering (small buffers = less prefetch)
    minBufferMs: 1500,
    maxBufferMs: 3000,
    bufferForPlaybackMs: 500,
    bufferForPlaybackAfterRebufferMs: 1000,
  },
  // iOS forward buffer duration in seconds (try 2–4). Ignored if platform doesn’t support.
  preferredForwardBufferDuration = 2,
  ...videoProps
}) => {
  const [cachedUri, setCachedUri] = useState(null);
  const [loading, setLoading] = useState(true);
  const [videoLoaded, setVideoLoaded] = useState(false);
  const [isOnline, setIsOnline] = useState(true);
  const lastCached = useRef({uri: null, path: null});

  useEffect(() => {
    const sub = NetInfo.addEventListener(state => {
      setIsOnline(Boolean(state.isConnected && state.isInternetReachable));
    });
    return () => sub && sub();
  }, []);

  const hls = useMemo(() => isHLS(uri), [uri]);
  const cacheable = useMemo(() => isCacheableFile(uri), [uri]);

  // Cache for file-based formats; stream HLS
  useEffect(() => {
    let cancelled = false;

    const cacheIt = async () => {
      if (!uri) {
        setLoading(false);
        return;
      }

      // Skip if we already have a cached path for this URI
      if (lastCached.current.uri === uri && lastCached.current.path) {
        setCachedUri(lastCached.current.path);
        setLoading(false);
        return;
      }

      if (!cacheable) {
        setCachedUri(null);
        setLoading(false);
        return;
      }

      try {
        await RNFS.mkdir(cacheDir);

        const ext = getExtFromUrl(uri);
        const uniqueFileName = `${getUniqueFileNameFromUrl(uri)}.${ext}`;
        const destPath = `${cacheDir}/${uniqueFileName}`;

        const exists = await RNFS.exists(destPath);
        if (exists) {
          const stat = await RNFS.stat(destPath).catch(() => null);
          const isValid = stat && Number(stat.size) > 0;
          if (isValid) {
            if (!cancelled) {
              const localUri = `file://${destPath}`;
              setCachedUri(localUri);
              lastCached.current = {uri, path: localUri};
              onCachedReady && onCachedReady(localUri);
              setLoading(false);
              return;
            }
          } else {
            await RNFS.unlink(destPath).catch(() => {});
          }
        }

        if (!isOnline) {
          if (!cancelled) {
            setCachedUri(null);
            setLoading(false);
          }
          return;
        }

        const res = await RNFS.downloadFile({
          fromUrl: uri,
          toFile: destPath,
          background: true,
          discretionary: true,
        }).promise;

        if (cancelled) return;

        if (res.statusCode >= 200 && res.statusCode < 300) {
          const localUri = `file://${destPath}`;
          setCachedUri(localUri);
          lastCached.current = {uri, path: localUri};
          onCachedReady && onCachedReady(localUri);
        } else {
          setCachedUri(null);
          onError && onError(new Error(`HTTP ${res.statusCode}`));
        }
      } catch (e) {
        if (!cancelled) {
          setCachedUri(null);
          onError && onError(e);
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    };

    cacheIt();
    return () => {
      cancelled = true;
    };
  }, [uri, cacheable, onCachedReady, onError, isOnline]);

  const canPlayRemote = Boolean(isOnline && uri);
  const chooseRemote = !cachedUri && canPlayRemote;
  const videoSource = chooseRemote ? {uri} : cachedUri ? {uri: cachedUri} : null;

  const maxBitRateBits = Math.max(200, targetKbps) * 1000; // RNVideo expects bits/sec
  const selectedVideoTrack = hls
    ? {type: 'bitrate', value: maxBitRateBits}
    : undefined;
  const maxBitRateProp = hls ? {maxBitRate: maxBitRateBits} : {};

  // Android ExoPlayer buffer config (harmless on iOS)
  const bufferConfig = {
    minBufferMs: bufferMs.minBufferMs,
    maxBufferMs: bufferMs.maxBufferMs,
    bufferForPlaybackMs: bufferMs.bufferForPlaybackMs,
    bufferForPlaybackAfterRebufferMs: bufferMs.bufferForPlaybackAfterRebufferMs,
  };

  return (
    <View style={[styles.container, style]}>
      {videoSource && (
        <Video
          source={videoSource}
          style={StyleSheet.absoluteFill}
          resizeMode={resizeMode}
          paused={paused}
          muted={muted}
          repeat={repeat}
          selectedVideoTrack={selectedVideoTrack}
          {...maxBitRateProp}
          bufferConfig={bufferConfig}
          preferredForwardBufferDuration={preferredForwardBufferDuration}
          playInBackground={false}
          playWhenInactive={false}
          ignoreSilentSwitch="ignore"
          progressUpdateInterval={1000}
          onLoadStart={event => {
            setVideoLoaded(false);
            onLoadStartProp && onLoadStartProp(event);
          }}
          onLoad={event => {
            setVideoLoaded(true);
            onLoadProp && onLoadProp(event);
            onReady && onReady(event);
          }}
          onError={onError}
          {...videoProps}
        />
      )}

      {(loading || !videoLoaded || !videoSource) && !!thumbnailUri && (
        <CustomImage source={{uri: thumbnailUri}} style={StyleSheet.absoluteFill} />
      )}
    </View>
  );
};

export default ReelPreviewVideo;

const styles = StyleSheet.create({
  container: {
    overflow: 'hidden',
  },
});
