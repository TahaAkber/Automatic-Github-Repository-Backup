import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { StatusBar, StyleSheet, Text, View } from "react-native";
import { PexelsWallpapers } from "./PexelsWallpapers";


const queryClient = new QueryClient();
export default function Animatoon() {
  return (
    <QueryClientProvider client={queryClient}>
      <View style={styles.container}>
        {/* <Text>Open up App.js to start working on your app!</Text> */}
        <PexelsWallpapers />
     
        <StatusBar style="auto" />
      </View>
    </QueryClientProvider>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#fff",
  },
})