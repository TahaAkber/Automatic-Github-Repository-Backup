import React, {useMemo, useRef, useState, useCallback, useEffect} from 'react';
import {
  FlatList,
  StyleSheet,
  View,
  Dimensions,
  TouchableOpacity,
  Animated,
} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import {moderateScale} from 'react-native-size-matters';

import {colors, WH, font} from '@constant/contstant';
import CustomText from '@materialComponent/customText/customText';

const {fontScale, height, width} = Dimensions.get('screen');

const ShopTileCategories = React.memo(
  ({
    item = [],
    marginTop,
    onSelect,
    subCategory = [],
    remove_margin_left = false,
    selectedCollectionId,
    tabView,
  }) => {
    const [activeIndex, setActiveIndex] = useState('ALL');
    const [activeCategory, setActiveCategory] = useState('');
    const bgOpacity = useRef(new Animated.Value(0)).current;
    const flatListRef = useRef(null);

    const memoizedItemData = useMemo(() => item, [item]);
    const memoizedSubCategoryData = useMemo(() => subCategory, [subCategory]);

    const handlePress = useCallback(
      collectionId => {
        setActiveCategory('');
        flatListRef.current?.scrollToOffset({offset: 0, animated: true});

        if (activeIndex === collectionId) return;

        const isAll = collectionId === 'ALL';
        setActiveIndex(isAll ? 'ALL' : collectionId);

        if (onSelect && typeof onSelect === 'function') {
          onSelect(isAll ? null : collectionId, null);
        }
      },
      [activeIndex, onSelect],
    );

    const handlePressSubCategory = useCallback(
      subCategoryId => {
        const isSame = activeCategory === subCategoryId;
        const newCategory = isSame ? null : subCategoryId;

        setActiveCategory(newCategory);

        if (onSelect && typeof onSelect === 'function') {
          onSelect(tabView ? selectedCollectionId : activeIndex, newCategory);
        }
      },
      [activeCategory, onSelect, activeIndex, selectedCollectionId],
    );

    const renderCategoryItem = useCallback(
      ({item, index}) => {
        const isActive = item.filter_option_id === activeIndex;
        return (
          <TouchableOpacity
            activeOpacity={1}
            onPress={() => handlePress(item.filter_option_id)}
            style={[
              styles.contentContainer,
              index === 0 && {marginLeft: width * 0.05},
              isActive && styles.activeCategory,
            ]}>
            <CustomText
              color={'black'}
              fontSize={fontScale * 14}
              fontFamily={font.medium}
              text={item.filter_option_value}
            />
          </TouchableOpacity>
        );
      },
      [activeIndex, handlePress],
    );

    const renderSubCategoryItem = useCallback(
      ({item, index}) => {
        const isActive = item === activeCategory;
        return (
          <TouchableOpacity
            activeOpacity={1}
            onPress={() => handlePressSubCategory(item)}
            style={[
              styles.contentContainer,
              index === 0 && {
                marginLeft: remove_margin_left ? 0 : width * 0.05,
              },
              {paddingHorizontal: isActive ? width * 0.01 : width * 0.05},
            ]}>
            <View style={isActive && styles.active}>
              <CustomText
                color={isActive ? 'white' : 'black'}
                fontSize={fontScale * 14}
                fontFamily={font.medium}
                text={item}
              />
            </View>
          </TouchableOpacity>
        );
      },
      [
        activeCategory,
        handlePressSubCategory,
        remove_margin_left,
        selectedCollectionId,
      ],
    );

    useEffect(() => {
      if(selectedCollectionId != "ALL"){
        setActiveCategory('');
      }
    }, [selectedCollectionId]);

    if (!memoizedItemData?.length && !memoizedSubCategoryData?.length)
      return null;

    return (
      <View style={[styles.wrapper, marginTop && {marginTop}]}>
        <Animated.View
          style={[StyleSheet.absoluteFillObject, {opacity: bgOpacity}]}>
          <LinearGradient
            colors={['rgba(255, 255, 255, 1)', 'rgba(255, 255, 255, 0)']}
            start={{x: 0.5, y: 1}}
            end={{x: 0.5, y: 0}}
            style={StyleSheet.absoluteFillObject}
          />
        </Animated.View>

        {memoizedItemData?.length && (
          <FlatList
            data={memoizedItemData}
            renderItem={renderCategoryItem}
            keyExtractor={item => String(item.filter_option_id)}
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.flatlistContainer}
          />
        )}

        {memoizedSubCategoryData?.length &&
        memoizedSubCategoryData?.length > 1 ? (
          <FlatList
            ref={flatListRef}
            data={memoizedSubCategoryData}
            renderItem={renderSubCategoryItem}
            keyExtractor={(item, index) => `${item}_${index}`}
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.flatlistContainer}
          />
        ) : (
          <View style={{marginTop: height * 0.02}} />
        )}
      </View>
    );
  },
);

export default ShopTileCategories;

const styles = StyleSheet.create({
  wrapper: {
    width: '100%',
    zIndex: 1,
  },
  contentContainer: {
    borderRadius: moderateScale(180),
    marginRight: moderateScale(5),
    backgroundColor: '#F1EDED',
    // paddingHorizontal: width * 0.05,
    height: height * 0.04,
    justifyContent: 'center',
    alignItems: 'center',
  },
  active: {
    backgroundColor: 'black',
    paddingHorizontal: width * 0.045,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 180,
    height: height * 0.03,
  },
  activeCategory: {
    borderBottomWidth: 2,
    borderColor: colors.light_theme.theme,
  },
  flatlistContainer: {
    paddingRight: width * 0.02,
    // borderBottomWidth: 1,
    borderColor: '#f4f4f4',
    justifyContent: 'center',
    alignItems: 'center',
    height: WH.width(16),
  },
});
