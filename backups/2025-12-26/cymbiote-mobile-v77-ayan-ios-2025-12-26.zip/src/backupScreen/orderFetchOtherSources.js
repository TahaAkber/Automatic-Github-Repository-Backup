import React, { useState } from 'react';
import { View, Text, Button, ScrollView, StyleSheet, Image } from 'react-native';
import { GoogleSignin } from '@react-native-google-signin/google-signin';
import { Buffer } from 'buffer';

// Configure Google Sign-In
GoogleSignin.configure({
    scopes: ['https://www.googleapis.com/auth/gmail.readonly'], // Gmail API scope
    webClientId: "1045679124479-aqeukkjlkf80aim1i44dlul46cgp3upn.apps.googleusercontent.com",
});

const OrderFetchOtherSources = () => {
    const [emails, setEmails] = useState([]);

    // Function to fetch order emails
    async function fetchOrderEmails(accessToken) {
        try {
            const query = 'subject:order';
            const response = await fetch(
                `https://gmail.googleapis.com/gmail/v1/users/me/messages?q=${query}`, // Replace with your query
                {
                    method: 'GET',
                    headers: {
                        Authorization: `Bearer ${accessToken}`,
                    },
                }
            );

            if (!response.ok) {
                throw new Error(`Error fetching emails: ${response.status}`);
            }

            const data = await response.json();
            const messages = data.messages;

            if (!messages) {
        
                return [];
            }

           
            return messages; // Message IDs and details
        } catch (error) {
            
            return [];
        }
    }

    // Function to fetch detailed email content and parse relevant details
    async function getOrderEmailContent(messageId, accessToken) {
        try {
            const response = await fetch(
                `https://gmail.googleapis.com/gmail/v1/users/me/messages/${messageId}`,
                {
                    method: 'GET',
                    headers: {
                        Authorization: `Bearer ${accessToken}`,
                    },
                }
            );

            if (!response.ok) {
                const errorDetails = await response.json();
                throw new Error(`Error fetching email content: ${response.status} - ${errorDetails.error.message}`);
            }

            const data = await response.json();

            // Extract sender field (e.g., "Indeed <alert@indeed.com>")
            const sender = data.payload.headers.find(
                (header) => header.name.toLowerCase() === 'from'
            )?.value || 'Unknown Sender';

            // Extract brand name from the sender (part before '<')
            const brandNameMatch = sender.match(/^([\w\s]+)\s*</);
            const brandNameFromSender = brandNameMatch ? brandNameMatch[1].trim() : null;

            // Fallback: Extract brand from email domain if sender format is not matched
            const senderEmailMatch = sender.match(/<([^>]+)>/);
            const senderEmail = senderEmailMatch ? senderEmailMatch[1] : sender;
            const domainMatch = senderEmail.match(/@([a-zA-Z0-9.-]+)\./);
            const brandNameFromDomain = domainMatch ? domainMatch[1].charAt(0).toUpperCase() + domainMatch[1].slice(1) : null;

            // Final brand name: Prefer sender name, fallback to domain name
            const brandName = brandNameFromSender || brandNameFromDomain || 'Unknown Brand';

            // Extract email content
            const parts = data.payload.parts || [];
            let emailContent = '';

            parts.forEach((part) => {
                if (part.mimeType === 'text/plain' || part.mimeType === 'text/html') {
                    const decodedData = Buffer.from(part.body.data, 'base64').toString(
                        'utf-8'
                    );
                    emailContent += decodedData;
                }
            });

            // Extract other order details
            const orderNumberMatch = emailContent.match(/Order No:\s*(\d+)/i);
            const quantityMatch = emailContent.match(/Qty:\s*(\d+)/i);
            const priceMatch = emailContent.match(/Price:\s*\$\s*([\d.]+)/i);
            const imageUrlMatch = emailContent.match(/https?:\/\/[^\s]+(\.jpg|\.png|\.jpeg)/i);
            const productNameMatch = emailContent.match(/Product:\s*([\w\s]+)/i) || emailContent.match(/Item:\s*([\w\s]+)/i);

            const orderNumber = orderNumberMatch ? orderNumberMatch[1] : 'Unknown Order Number';
            const quantity = quantityMatch ? quantityMatch[1] : 'Unknown Quantity';
            const price = priceMatch ? `$${priceMatch[1]}` : 'Unknown Price';
            const imageUrl = imageUrlMatch ? imageUrlMatch[0] : null;
            const productName = productNameMatch ? productNameMatch[1] : 'Unknown Product';


            return {
                sender,
                brandName,
                productName,
                orderNumber,
                quantity,
                price,
                imageUrl,
            };
        } catch (error) {
            console.error('Error fetching email content:', error);
        }
    }



    const handleFetchOrders = async () => {
        try {
            // Step 1: Ensure Google Play Services are available
            await GoogleSignin.hasPlayServices();

            // Step 2: Sign in to Google and get the tokens
            const userInfo = await GoogleSignin.signIn();
            const tokens = await GoogleSignin.getTokens(); // Get access token
            const accessToken = tokens.accessToken;


            // Step 3: Fetch order-related emails
            const messages = await fetchOrderEmails(accessToken);

            // Step 4: Fetch content for each email
            const emailDetails = await Promise.all(
                messages.map((message) =>
                    getOrderEmailContent(message.id, accessToken)
                )
            );

            // Update state with the fetched emails and their details
            setEmails(emailDetails);
        } catch (error) {
            console.error('Error fetching orders:', error);
        }
    };

    return (
        <View style={styles.container}>
            <Button title="Fetch Order Emails" onPress={handleFetchOrders} />
            <ScrollView style={styles.scrollView}>
                {emails.map((email, index) => (
                    <View key={index} style={styles.emailCard}>
                        <Text style={styles.label}>Sender:</Text>
                        <Text>{email.sender}</Text>
                        <Text style={styles.label}>Brand:</Text>
                        <Text>{email.brandName}</Text>
                        <Text style={styles.label}>Order No:</Text>
                        <Text>{email.orderNumber}</Text>
                        <Text style={styles.label}>Quantity:</Text>
                        <Text>{email.quantity}</Text>
                        <Text style={styles.label}>Price:</Text>
                        <Text>{email.price}</Text>
                        <Text style={styles.label}>Product Name:</Text>
                        <Text>{email.productName}</Text>
                        {email.imageUrl && (
                            <Image
                                source={{ uri: email.imageUrl }}
                                style={styles.image}
                                resizeMode="contain"
                            />
                        )}
                    </View>
                ))}
            </ScrollView>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 20,
    },
    scrollView: {
        marginTop: 20,
    },
    emailCard: {
        marginBottom: 20,
        padding: 10,
        backgroundColor: '#f9f9f9',
        borderRadius: 5,
        borderWidth: 1,
        borderColor: '#ddd',
    },
    label: {
        fontWeight: 'bold',
        marginTop: 5,
    },
    image: {
        width: '100%',
        height: 200,
        marginTop: 10,
    },
});

export default OrderFetchOtherSources;
