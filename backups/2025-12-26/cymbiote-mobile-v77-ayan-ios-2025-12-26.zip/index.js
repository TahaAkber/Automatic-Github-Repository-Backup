/**
 * @format
 */
import 'react-native-gesture-handler';
import {GestureHandlerRootView} from 'react-native-gesture-handler';
import React from 'react';
import {AppRegistry} from 'react-native';
import App from './App';
import {name as appName} from './app.json';
import {Provider as StoreProvider} from 'react-redux';
import {PersistGate} from 'redux-persist/integration/react';
import {store, persistor} from './src/redux/store/store';
import {
  ColorScheme,
  ShopifyCheckoutSheetProvider,
} from '@shopify/checkout-sheet-kit';

const Root = () => (
  <GestureHandlerRootView style={{flex: 1}}>
    <ShopifyCheckoutSheetProvider configuration={configuration}>
      <StoreProvider store={store}>
        <PersistGate persistor={persistor}>
          <App />
        </PersistGate>
      </StoreProvider>
    </ShopifyCheckoutSheetProvider>
  </GestureHandlerRootView>
);

AppRegistry.registerComponent(appName, () => Root);

const configuration = {
  colors: {
    android: {
      dark: true,
    },
  },
  colorScheme: ColorScheme.dark,
};
