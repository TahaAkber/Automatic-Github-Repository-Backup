import express, { Request, Response } from "express";
import dotenv from "dotenv";
import path from "path";
import shopifyRoutes from "./src/routes/shopify";
import productsRoutes from "./src/routes/productRoutes";
import webhookRoutes from "./src/routes/webhookRoutes";
import authRoutes from "./src/routes/authRoutes";
import cron from "node-cron";
import {
  checkAndSendFulfillmentEmail,
  checkAndUpdateFulfillment,
} from "./src/services/orders";
import { sendAbandonedCartNotifications } from "./src/functions/abandonedCartNotification";
import shopRoutes from "./src/routes/shopRoutes";
import cartRoutes from "./src/routes/cartRoutes";
import userRoute from "./src/routes/userRoute";
import searchRoutes from "./src/routes/search";
import tracking from "./src/routes/trackingRoutes";
import pointsRoutes from "./src/routes/pointsRoutes";
import followingRoutes from "./src/routes/followingRoutes";
import wishlistRoutes from "./src/routes/wishlistRoutes";
import socialAccountRoutes from "./src/routes/socialAccountRoutes";
import orderRoutes from "./src/routes/orderRoutes";
import reviewRoutes from "./src/routes/reviewRoutes";
import uploadRoutes from "./src/routes/uploadRoutes";
import videoWorkerRoutes from "./src/routes/videoWorkerRoutes";
import reelsAndStoriesRoutes from "./src/routes/reelsAndStoriesRoutes";
import notificationRoutes from "./src/routes/notificationRoutes";
import analyticsRoutes from "./src/routes/analyticsRoutes";
import compressToolRoutes from "./src/routes/compressToolRoutes";
import notificationPreferenceRoutes from "./src/routes/notificationPreferenceRoutes";
import merchantWebhookRoutes from "./src/routes/merchantWebhookRoutes";
import metafieldRoutes from "./src/routes/metafieldRoutes";
import reportRoutes from "./src/routes/reportRoutes";
import appUpdateRoutes from "./src/routes/appUpdateRoutes";
import { setDatabaseEnv } from "./src/functions/common";
import { checkAndRemoveTrendingCollection } from "./src/services/collectionService";
import { checkAndRemoveNotifications } from "./src/services/notificationService";
import { productIsActive } from "./src/models/products/productModel";
import { updateAllManualTrackings } from "./src/services/cronTrackingService";
import { deleteOldReelsAndStories } from "./src/functions/cleanupReelsAndStories";

dotenv.config();

const ENVIRONMENT = process.env.ENVIRONMENT;
// refreshAccessToken()

const app = express();
const port = process.env.PORT || 3002;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(setDatabaseEnv);

// Serve uploaded files statically
const joinedPath = path.join(__dirname, "/src/uploads");
console.log("joinedPath", joinedPath);
app.use("/uploads", express.static(joinedPath));

// Shopify Routes
app.use("/api/shopify", shopifyRoutes);
app.use("/staging/shopify", shopifyRoutes);
app.use("/api/products", productsRoutes);
app.use("/staging/products", productsRoutes);
app.use("/api/webhook", webhookRoutes);
app.use("/staging/webhook", webhookRoutes);
app.use("/api/auth", authRoutes);
app.use("/staging/auth", authRoutes);
app.use("/api/shops", shopRoutes);
app.use("/staging/shops", shopRoutes);
app.use("/api/carts", cartRoutes);
app.use("/staging/carts", cartRoutes);
app.use("/api/user", userRoute);
app.use("/staging/user", userRoute);
app.use("/api/search", searchRoutes);
app.use("/staging/search", searchRoutes);
app.use("/api/tracking", tracking);
app.use("/staging/tracking", tracking);
app.use("/api/points", pointsRoutes);
app.use("/staging/points", pointsRoutes);
app.use("/api/following", followingRoutes);
app.use("/staging/following", followingRoutes);
app.use("/api/wishlist", wishlistRoutes);
app.use("/staging/wishlist", wishlistRoutes);
app.use("/api/social-account", socialAccountRoutes);
app.use("/staging/social-account", socialAccountRoutes);
app.use("/api/order", orderRoutes);
app.use("/staging/order", orderRoutes);
app.use("/api/review", reviewRoutes);
app.use("/staging/review", reviewRoutes);
app.use("/api/upload", uploadRoutes);
app.use("/staging/upload", uploadRoutes);
app.use("/api/reels-stories", reelsAndStoriesRoutes);
app.use("/staging/reels-stories", reelsAndStoriesRoutes);
app.use("/api/notification", notificationRoutes);
app.use("/staging/notification", notificationRoutes);
app.use("/api/analytics", analyticsRoutes);
app.use("/staging/analytics", analyticsRoutes);
app.use("/api/compress", compressToolRoutes);
app.use("/staging/compress", compressToolRoutes);
app.use("/staging/metafield", metafieldRoutes);
app.use("/api/metafield", metafieldRoutes);
app.use("/api/notification-preference", notificationPreferenceRoutes);
app.use("/staging/notification-preference", notificationPreferenceRoutes);
app.use("/api/merchant-webhook", merchantWebhookRoutes);
app.use("/staging/merchant-webhook", merchantWebhookRoutes);
app.use("/api/video-worker", videoWorkerRoutes);
app.use("/staging/video-worker", videoWorkerRoutes);
app.use("/api/reports", reportRoutes);
app.use("/staging/reports", reportRoutes);
app.use("/api/app-update", appUpdateRoutes);
app.use("/staging/app-update", appUpdateRoutes);

// Root Route
app.get("/", (req: Request, res: Response) => {
  res.send("Cymbiote Sales Channel Backend");
});

app.get("/api", (req: Request, res: Response) => {
  res.send("Please define an API route after api/");
});

// Start Server
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
  console.log("Running for environment:", ENVIRONMENT);

  if (ENVIRONMENT === "production") {
    cron.schedule("* * * * *", async () => {
      await checkAndUpdateFulfillment();
    });
  }

  if (ENVIRONMENT === "production") {
    cron.schedule("0 */12 * * *", async () => {
      await checkAndRemoveNotifications();
      await productIsActive();
      await checkAndRemoveTrendingCollection();
      await checkAndSendFulfillmentEmail();
      await sendAbandonedCartNotifications();
      await deleteOldReelsAndStories();
    });
  }
  // Tracking update cron - runs every 5 minutes
  if (ENVIRONMENT === "production") {
    cron.schedule("*/5 * * * *", async () => {
      await updateAllManualTrackings();
    });
  }
});
