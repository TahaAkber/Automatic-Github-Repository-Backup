import sql from "mssql";
import dotenv from "dotenv";
import { sendErrorEmail } from "../services/emailService";

dotenv.config();

const dbConfig: sql.config = {
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  server: process.env.DB_SERVER ? process.env.DB_SERVER : "localhost:1433",
  database: process.env.DB_NAME,
  port: process.env.DB_PORT ? parseInt(process.env.DB_PORT) : 1433,
  options: {
    encrypt: false, // for Azure
    trustServerCertificate: true, // change to true for local dev / self-signed certs
    enableArithAbort: true,
  },
};

export const poolPromise = new sql.ConnectionPool(dbConfig)
  .connect()
  .then((pool) => {
    console.log("Connected to SQL Server");
    return pool;
  })
  .catch((err) => {
    sendErrorEmail("Database connection failed:",err);
    console.error("Database connection failed: ", err);
    throw err;
  });
