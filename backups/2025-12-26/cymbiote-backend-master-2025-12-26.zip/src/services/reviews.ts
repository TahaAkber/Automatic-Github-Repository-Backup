import dotenv from "dotenv";
import {
  getOrderById,
  getOrderByUserId,
  getOrderItemById,
  getOrderItemByOrderId,
  getReviewByUserId,
} from "../models/orders/dbOrders";
import {
  CreateOrderItemReview,
  getGroupedReviewImages,
  getOrderItemReviewById,
  getReviewById,
  getProductReviews,
  getProductReviewsStats,
  userReviews,
  createReviewComment,
  createOrUpdateReaction,
  createOrUpdateReviewReaction,
  getReviewReactionsGrouped,
  getCommentsForReviewIds,
  getCommentReactionsGrouped,
  getCommentReactionForReviewId,
} from "../models/reviews/reviewsModel";
import { applyOrderStatus } from "../functions/common";
import {
  getVariantById,
  ProductRatingUpdate,
} from "../models/products/productModel";
import { getUserById } from "../models/users/user";
import { CreateCommentParams } from "../types/reviews/CreateCommentParams";
import { ReactionPayload } from "../types/reviews/ReactionPayload";
import { ReviewReactionPayload } from "../types/reviews/ReviewReactionPayload";
import { getShopWithRatingUsingShopId } from "../models/shops/shopModel";
import { shopRatingUpdate } from "../functions/shop";
import { sendErrorEmail } from "./emailService";

dotenv.config();

export const addOrderItemReview = async (
  orderItemId: number,
  reviewRating: number,
  reviewComment: string,
  images?: []
) => {
  const session = await getOrderItemById(orderItemId);
  const orderDetail = await getOrderById(session?.order_id);
  if (session) {
    const reviewExist = await getOrderItemReviewById(orderItemId);
    const varaintDetail = await getVariantById(session?.order_item_variant_id);

    console.log("session", varaintDetail);

    if (reviewExist) {
      return {
        status: 400,
        message: "You’ve already reviewed this item.",
      };
    }

    const response = await CreateOrderItemReview(
      orderItemId,
      reviewRating,
      reviewComment,
      images
    );

    console.log("response", orderDetail);
    if (response) {
      await shopRatingUpdate(orderDetail?.order_shop_id);
      await ProductRatingUpdate(varaintDetail?.variant?.variant_product_id);
      return {
        status: 200,
        message: "Your review has been sent",
        // reviews
      };
    } else {
      return {
        status: 400,
        message: "Something went wrong!",
      };
    }
  } else {
    return {
      status: 400,
      message: "Order Item Not Found",
    };
  }
};

export const fetchUserReviews = async (
  user_id: number,
  page: number,
  pageSize: number,
  status: number
): Promise<any> => {
  try {
    const result = await getReviewByUserId(user_id, page, pageSize, status);

    const modifiedData = await Promise.all(
      result.map(async (item, index) => {
        const findOrderItems = await getOrderItemByOrderId(item.order_id);
        const shopResult = await getShopWithRatingUsingShopId(
          item?.order_shop_id
        );
        const childData = await Promise.all(
          findOrderItems.map(async (e, v) => {
            const product = await getVariantById(e.order_item_variant_id);
            const review_item = await getOrderItemReviewById(e.order_item_id);

            if (review_item) {
              const allComments = await getCommentsForReviewIds([
                review_item?.order_item_review_id,
              ]);

              const reviewDetail = await getCommentReactionForReviewId(
                review_item?.order_item_review_id,
                user_id,
                "user"
              );

              review_item.total_comment = (allComments || [])?.length || 0;
              review_item.total_reaction = reviewDetail?.reactionCount;
              review_item.self_reaction = reviewDetail?.selfReaction;
            }

            return {
              ...e,
              product,
              review_completed: Boolean(review_item),
              review_item,
            };
          })
        );

        return {
          ...item,
          order_item: childData,
          shop_detail: shopResult,
          // order: findOrder,
          // variant : findOrderVariant
        };
      })
    );

    const sortedOrders = modifiedData.sort((a, b) => {
      const nowUTC = Date.now();
      const msIn7Days = 7 * 24 * 60 * 60 * 1000;

      const aCreatedUTC = new Date(a.created_at).getTime();
      const bCreatedUTC = new Date(b.created_at).getTime();

      // ✅ If any item is reviewed, don't pin — just sort by date
      const aHasReviewedItem = a.order_item?.some(
        (item: any) => item.review_completed === true
      );
      const bHasReviewedItem = b.order_item?.some(
        (item: any) => item.review_completed === true
      );

      if (aHasReviewedItem && !bHasReviewedItem) return 1;
      if (!aHasReviewedItem && bHasReviewedItem) return -1;

      // ✅ Now check if unreviewed and within 7 days → pin to top
      const aHasUnreviewed = a.order_item?.some(
        (item: any) => item.review_completed === false
      );
      const bHasUnreviewed = b.order_item?.some(
        (item: any) => item.review_completed === false
      );

      const aPinned = aHasUnreviewed && nowUTC - aCreatedUTC <= msIn7Days;
      const bPinned = bHasUnreviewed && nowUTC - bCreatedUTC <= msIn7Days;

      if (aPinned && !bPinned) return -1;
      if (!aPinned && bPinned) return 1;

      return bCreatedUTC - aCreatedUTC;
    });

    if (status == 2) {
      const filteredOrders = sortedOrders.map((item: any) => {
        return {
          ...item,
          order_item: item.order_item.filter((orderItem: any) => {
            return orderItem.review_completed === true;
          }),
        };
      });
      return filteredOrders;
    } else if (status == 1) {
      const filteredOrders = sortedOrders.map((item: any) => {
        return {
          ...item,
          order_item: item.order_item.filter((orderItem: any) => {
            return orderItem.review_completed === false;
          }),
        };
      });
      return filteredOrders;
    } else {
      return sortedOrders;
    }
  } catch (error: any) {
    sendErrorEmail("Error fethcing recent view record: ", error);

    throw new Error("Error fethcing recent view record: " + error.message);
  }
};

export const fetchReviewDetail = async (
  order_item_review_id: number,
  user_id: number
): Promise<any> => {
  try {
    const result = await getReviewById(order_item_review_id);
    if (!result) {
      return {
        status: 400,
        message: "Review not found.",
      };
    } else {
      const getOrderItem = await getOrderItemById(result.order_item_id);
      const getOrder = await getOrderById(getOrderItem?.order_id);
      const shop_detail = await getOrderById(getOrder?.order_shop_id);
      const userDetail = await getUserById(getOrder.order_user_id);
      const product = await getVariantById(getOrderItem.order_item_variant_id);

      const allComments = await getCommentsForReviewIds([order_item_review_id]);
      const allCommentIds = allComments.map((c) => c.comment_id);
      const commentReactionsMap = await getCommentReactionsGrouped(
        allCommentIds,
        user_id
      );

      // Nest comments
      const nestedCommentsMap: Record<number, any[]> = {};
      for (const comment of allComments) {
        const commenterDetail =
          comment?.commenter_type == "shop"
            ? await getShopWithRatingUsingShopId(comment.commenter_id)
            : await getUserById(comment.commenter_id);
        const base = {
          commentId: comment.comment_id,
          commentText: comment.comment_text,
          commenterType: comment.commenter_type,
          commenterId: comment.commenter_id,
          createdAt: comment.created_at,
          commenterDetail,
          likeCount: commentReactionsMap[comment.comment_id]?.likeCount || 0,
          dislikeCount:
            commentReactionsMap[comment.comment_id]?.dislikeCount || 0,
          selfReaction:
            commentReactionsMap[comment.comment_id]?.selfReaction || null,
          replies: [],
          order_user_id: getOrder.order_user_id,
        };

        if (!comment.parent_comment_id) {
          if (!nestedCommentsMap[comment.review_id])
            nestedCommentsMap[comment.review_id] = [];
          nestedCommentsMap[comment.review_id].push(base);
        } else {
          const parent = allComments.find(
            (c) => c.comment_id === comment.parent_comment_id
          );
          if (parent) {
            const parentGroup = nestedCommentsMap[parent.review_id] || [];
            const parentComment = parentGroup.find(
              (c) => c.commentId === parent.comment_id
            );
            if (parentComment) parentComment.replies.push(base);
          }
        }
      }

      const data = {
        review_detail: result,
        user_detail: userDetail,
        order_item: getOrderItem,
        shop_detail,
        total_comment: (allComments || [])?.length || 0,
        comments: nestedCommentsMap[order_item_review_id] || [],
        product,
      };
      return {
        status: 200,
        message: "fetch review detail successfully.",
        data,
      };
    }
  } catch (error: any) {
    sendErrorEmail("Error fethcing recent view record: ", error);

    throw new Error("Error fethcing recent view record: " + error.message);
  }
};

export const getProductReviewS = async (
  productId: number,
  currentUserId: number
) => {
  const reviews = await getProductReviews(productId);
  const reviewStats = await getProductReviewsStats(productId);
  const reviewIds = reviews.map((r) => r.order_item_review_id).filter(Boolean);
  const reviewImagesMap = await getGroupedReviewImages(reviewIds);
  const reviewReactionsMap = await getReviewReactionsGrouped(
    reviewIds,
    currentUserId
  );

  const allComments = await getCommentsForReviewIds(reviewIds);
  const allCommentIds = allComments.map((c) => c.comment_id);
  const commentReactionsMap = await getCommentReactionsGrouped(
    allCommentIds,
    currentUserId
  );

  // Nest comments
  const nestedCommentsMap: Record<number, any[]> = {};
  for (const comment of allComments) {
    const base = {
      commentId: comment.comment_id,
      commentText: comment.comment_text,
      commenterType: comment.commenter_type,
      commenterId: comment.commenter_id,
      createdAt: comment.created_at,
      likeCount: commentReactionsMap[comment.comment_id]?.likeCount || 0,
      dislikeCount: commentReactionsMap[comment.comment_id]?.dislikeCount || 0,
      selfReaction:
        commentReactionsMap[comment.comment_id]?.selfReaction || null,
      replies: [],
    };

    if (!comment.parent_comment_id) {
      if (!nestedCommentsMap[comment.review_id])
        nestedCommentsMap[comment.review_id] = [];
      nestedCommentsMap[comment.review_id].push(base);
    } else {
      const parent = allComments.find(
        (c) => c.comment_id === comment.parent_comment_id
      );
      if (parent) {
        const parentGroup = nestedCommentsMap[parent.review_id] || [];
        const parentComment = parentGroup.find(
          (c) => c.commentId === parent.comment_id
        );
        if (parentComment) parentComment.replies.push(base);
      }
    }
  }

  return {
    averageRating: reviewStats.average_rating || 0,
    totalReviews: reviewStats.total_reviews || 0,
    breakdown: {
      excellent: reviewStats.excellent || 0,
      good: reviewStats.good || 0,
      average: reviewStats.average || 0,
      poor: reviewStats.poor || 0,
      veryPoor: reviewStats.verypoor || 0,
    },
    total_comment: reviews.length,
    reviews: reviews.map((r) => ({
      order_item_review_id: r.order_item_review_id,
      order_item_review_rating: r.order_item_review_rating || 0,
      order_item_review_comment: r.order_item_review_comment || "",
      created_at: r.created_at,
      images: reviewImagesMap[r.order_item_review_id] || [],
      likeCount: reviewReactionsMap[r.order_item_review_id]?.likeCount || 0,
      dislikeCount:
        reviewReactionsMap[r.order_item_review_id]?.dislikeCount || 0,
      selfReaction:
        reviewReactionsMap[r.order_item_review_id]?.selfReaction || null,
      user: {
        name: r.user_first_name
          ? `${r.user_first_name} ${r.user_last_name}`
          : "Anonymous",
        id: r.user_id || null,
        avatar: r.user_image_url || "",
      },
      comments: nestedCommentsMap[r.order_item_review_id] || [],
    })),
  };
};

export const createReviewCommentService = async (
  params: CreateCommentParams
) => {
  if (!params.reviewId || !params.commenterId || !params.commentText.trim()) {
    throw new Error("Invalid comment payload");
  }

  return await createReviewComment(params);
};

export const handleReactionService = async (payload: ReactionPayload) => {
  return await createOrUpdateReaction(payload);
};

export const handleReviewReactionService = async (
  payload: ReviewReactionPayload
) => {
  return await createOrUpdateReviewReaction(payload);
};
