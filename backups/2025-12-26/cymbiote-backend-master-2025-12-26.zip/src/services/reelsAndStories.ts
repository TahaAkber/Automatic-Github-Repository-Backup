import { poolPromise } from "../config/db";
import {
  getLatestReelByOffset,
  getReelsByShop,
  getReelsByShopId,
  getReelsByVideoId,
  GetSavedReels,
  getStories,
  isHaveStories,
  SavedReel,
  updateReelViewCount,
} from "../models/reelsAndStories/reelsAndStories";
import { sendErrorEmail } from "./emailService";

export const fetchReelsByShopId = async (shopId: number, userId?: number) => {
  try {
    const reels = await getReelsByShopId(shopId, userId);
    if (!reels) {
      return {
        status: 404,
        message: "No reels found for this shop",
      };
    }
    const reelsData = {
      reels,
    };
    return {
      status: 200,
      data: reelsData,
    };
  } catch (error: any) {
    sendErrorEmail("Error in fetchReelsByShopId service:", error);

    console.error("Error in fetchReelsByShopId service:", error);
    throw new Error("Failed to fetch reels for the shop");
  }
};
export const fetchReelsByVideoId = async (
  videoId: number,
  userId?: number,
  page = 1,
  pageSize = 6,
  shopId?: number
) => {
  try {
    const reels = await getReelsByVideoId(
      videoId,
      userId,
      page,
      pageSize,
      shopId
    );
    if (!reels) {
      return {
        status: 404,
        message: "No reels found for this video",
      };
    }

    const pool = await poolPromise;
    const countQuery = `
      SELECT COUNT(*) AS total
      FROM ReelsNStories rs
      JOIN Videos v ON rs.video_url_id = v.video_id
      WHERE rs.video_type = 'REEL';
    `;
    const countResult = await pool.request().query(countQuery);
    const total = countResult.recordset[0].total;
    const totalPages = Math.ceil(total / pageSize);

    return {
      status: 200,
      data: reels,
      pagination: {
        totalReelCount: total,
        totalPages,
        currentPage: page,
      },
    };
  } catch (error: any) {
    sendErrorEmail("Error in fetchReelsByVideoId service:", error);

    console.error("Error in fetchReelsByVideoId service:", error);
    throw new Error("Failed to fetch reels by video ID");
  }
};

export const fetchLatestReelByOffset = async (offset: number) => {
  try {
    const reel = await getLatestReelByOffset(offset);
    if (!reel) {
      return {
        status: 404,
        message: "No more reels available",
      };
    }

    return {
      status: 200,
      data: reel,
    };
  } catch (error: any) {
    sendErrorEmail("Error in fetchLatestReelByOffset service:", error);

    console.error("Error in fetchLatestReelByOffset service:", error);
    throw new Error("Failed to fetch the latest reel");
  }
};

export const fetchReelsByShop = async (shopId: number, userId?: number) => {
  try {
    const reels = await getReelsByShop(shopId, userId);
    if (!reels) {
      return {
        status: 204, // No Content
        data: [],
        message: "No reels found for this shop.",
      };
    }

    return {
      status: 200,
      data: reels,
    };
  } catch (error: any) {
    sendErrorEmail("Error in fetchReelsByShopId service:", error);
    console.error("Error in fetchReelsByShopId service:", error);
    throw new Error("Failed to fetch reels for the shop");
  }
};

export const SavedReelService = async (
  user_id: number,
  video_id: number,
  status: boolean
) => {
  try {
    const result = await SavedReel(user_id, video_id, status);
    return {
      status: 200,
      data: result,
    };
  } catch (error: any) {
    sendErrorEmail("SavedReelService error", error);

    return {
      status: 500,
      message: error.message || "Internal server error",
    };
  }
};

// services/re  elsService.ts

export const incrementReelViewCountService = async (videoId: number) => {
  try {
    await updateReelViewCount(videoId);

    return {
      status: 200,
      message: "View count updated successfully",
    };
  } catch (error: any) {
    sendErrorEmail("Service error updating video view count:", error);

    console.error("Service error updating video view count:", error);
    return {
      status: 500,
      message: "Failed to update view count",
    };
  }
};

export const StoryService = async (shopId: number, userId?: number) => {
  const stories = await getStories(shopId, userId);
  return stories;
};
export const isShopHaveStories = async (shopId: number): Promise<boolean> => {
  try {
    const stories = await isHaveStories(shopId);
    return stories;
  } catch (error: any) {
    sendErrorEmail("Error checking shop stories:", error);

    console.error("Error checking shop stories:", error);
    return false;
  }
};

export const GetSavedReelsService = async (
  user_id: number,
  page: number,
  pageSize: number
) => {
  try {
    const result = await GetSavedReels(user_id, page, pageSize);
    return {
      status: 200,
      data: result.data,
      totalCount: result.total,
    };
  } catch (error: any) {
    sendErrorEmail("GetSavedReelsService error", error);

    return {
      status: 500,
      message: error.message || "Internal server error",
    };
  }
};
