import axios from "axios";
import https from "https";
import { sendErrorEmail } from "./emailService";
const API_URL = process.env.EXCHANGE_RATE_API_URL;
const API_KEY = process.env.EXCHANGE_RATE_API_KEY;

export const getCurrentCurrencyRate = async (
  currency: string,
  convertingCurrency: string
): Promise<number> => {
  const CURRENCY_RATES_API = `${API_URL}/${API_KEY}/latest/${currency}`;
  console.log("CURRENCY_RATES_API", CURRENCY_RATES_API);
  let currentUSDRate = 0;

  try {
    const agent = new https.Agent({ family: 4 }); // Force IPv4

    const currentRates = await axios.get(CURRENCY_RATES_API, {
      httpsAgent: agent,
    });

    if (
      currentRates.status === 200 &&
      currentRates.data?.conversion_rates?.[convertingCurrency]
    ) {
      currentUSDRate = parseFloat(
        currentRates.data.conversion_rates[convertingCurrency]
      );

      console.log(
        `Current ${currency} to ${convertingCurrency} rate:`,
        currentUSDRate
      );
    } else {
      console.warn("Conversion rate not found in response");
    }
  } catch (error: any) {
    sendErrorEmail("Failed to fetch currency rates:", error);

    console.error("Failed to fetch currency rates:", error.message);
  }

  return currentUSDRate;
};
