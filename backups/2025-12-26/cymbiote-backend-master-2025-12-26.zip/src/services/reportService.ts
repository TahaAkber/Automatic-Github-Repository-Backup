import {
  createReport,
  CreateReportParams,
  Report,
} from "../models/reports/reportModel";
import { sendErrorEmail } from "./emailService";

export const submitReportService = async (
  params: CreateReportParams
): Promise<Report> => {
  try {
    const report = await createReport(params);
    return report;
  } catch (error: any) {
    sendErrorEmail("Error in submitReportService", error);
    console.error("Error in submitReportService:", error);
    throw error;
  }
};
