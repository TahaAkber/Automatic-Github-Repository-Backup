import {
  getActiveManualTrackingsForUpdate,
  updateManualTrackingFromCron,
  getActiveNonAutomatedTrackings,
} from "../models/tracking/dbTracking";
import {
  getTcsTracking,
  parseTCSResponse,
  getDhlTracking,
  parseDHLResponse,
  getBarqRaftarTracking,
  parseBarqRaftarResponse,
  normalizeTCSStatus,
  getBlueExTracking,
  parseBlueExResponse,
  normalizeBlueExStatus,
  getFlyCourierTracking,
  parseFlyCourierResponse,
  normalizeFlyCourierStatus,
} from "../functions/courierTrackings";
import { captureTrackingService } from "./trackingService";
import { ParsedDHLResponse } from "../types/courier/ParsedDHLResponse";

// Configuration
const BATCH_SIZE = 50; // Process 50 trackings per run
const MIN_UPDATE_INTERVAL_MINUTES = 10; // Skip if updated within last 10 min
const API_DELAY_MS = 100; // 100ms delay between API calls

// Helper function to add delay between API calls
const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

// Main cron function to update all active manual trackings (existing functionality)
export async function updateAllManualTrackings() {
  const startTime = Date.now();
  console.log(
    `[CRON] Starting manual tracking update job at ${new Date().toISOString()}`
  );

  try {
    // Fetch active trackings (batch)
    const trackings = await getActiveManualTrackingsForUpdate(
      BATCH_SIZE,
      MIN_UPDATE_INTERVAL_MINUTES
    );

    if (!trackings || trackings.length === 0) {
      console.log("[CRON] No active manual trackings to update");
    } else {
      console.log(`[CRON] Processing ${trackings.length} manual trackings...`);

      let successCount = 0;
      let failureCount = 0;

      // Process each tracking
      for (const tracking of trackings) {
        try {
          // Add delay between API calls for rate limiting
          if (successCount + failureCount > 0) {
            await delay(API_DELAY_MS);
          }

          const updated = await updateSingleTracking(tracking);

          if (updated) {
            successCount++;
            console.log(
              `[CRON] ✓ Updated manual tracking ${tracking.manual_tracking_number} (${tracking.manual_tracking_status})`
            );
          } else {
            failureCount++;
          }
        } catch (error: any) {
          failureCount++;
          console.error(
            `[CRON] ✗ Failed to update manual tracking ${tracking.manual_tracking_number}:`,
            error.message
          );
          // Continue processing other trackings even if one fails
        }
      }

      const duration = ((Date.now() - startTime) / 1000).toFixed(2);
      console.log(
        `[CRON] Completed Manual Trackings: ${successCount} success, ${failureCount} failed in ${duration}s`
      );
    }

    // Also run the new non-automated tracking update
    await updateNonAutomatedTrackings();
  } catch (error: any) {
    console.error("[CRON] Error in tracking update job:", error);
  }
}

// New cron function for non-automated trackings (Tracking table)
export async function updateNonAutomatedTrackings() {
  console.log(`[CRON] Starting non-automated tracking update job...`);
  const startTime = Date.now();

  try {
    const trackings = await getActiveNonAutomatedTrackings(
      BATCH_SIZE,
      MIN_UPDATE_INTERVAL_MINUTES
    );

    if (!trackings || trackings.length === 0) {
      console.log("[CRON] No active non-automated trackings to update");
      return;
    }

    console.log(
      `[CRON] Processing ${trackings.length} non-automated trackings...`
    );
    let successCount = 0;
    let failureCount = 0;

    for (const tracking of trackings) {
      try {
        if (successCount + failureCount > 0) await delay(API_DELAY_MS);

        const { tracking_number, tracking_carrier_code } = tracking;
        let parsed: ParsedDHLResponse | null = null;
        let courierId = parseInt(tracking_carrier_code);

        // Fetch from courier
        switch (courierId) {
          case 1: // DHL
            const dhlRes = await getDhlTracking(tracking_number);
            if (dhlRes?.status === 200) parsed = parseDHLResponse(dhlRes.data);
            break;
          case 2: // TCS
            const tcsRes = await getTcsTracking(tracking_number);
            if (tcsRes?.status === 200) parsed = parseTCSResponse(tcsRes.data);
            break;
          case 3: // BarqRaftar
            const barqRes = await getBarqRaftarTracking(tracking_number);
            if (barqRes?.status === 200)
              parsed = parseBarqRaftarResponse(barqRes.data);
            break;
          case 4: // BlueEX
            const blueRes = await getBlueExTracking(tracking_number);
            if (blueRes?.status === 200)
              parsed = parseBlueExResponse(blueRes.data);
            break;
          case 5: // FlyCourier
            const flyRes = await getFlyCourierTracking(tracking_number);
            if (flyRes?.status === 200)
              parsed = parseFlyCourierResponse(flyRes.data);
            break;
          default:
            console.warn(
              `[CRON] Unknown carrier code ${tracking_carrier_code} for ${tracking_number}`
            );
            continue;
        }

        console.log("parsed", parsed);

        if (parsed) {
          // Adapter: Map to 17track format expected by captureTrackingService
          const trackInfo = {
            latest_status: {
              status: parsed?.track_info?.latest_status?.status, // Map raw status
            },
            tracking: {
              providers: [
                {
                  events:
                    parsed?.track_info?.milestone?.map((m: any) => ({
                      status: m.description,
                      time_iso: m.time_iso,
                      description: m.description,
                      // Map other fields if needed for updateTrackingEvents
                      location: m.location || "",
                      stage: m.sub_status || "",
                    })) || [],
                },
              ],
            },
          };

          // captureTrackingService expects (trackingNumber, trackInfo, carrier)
          const result = await captureTrackingService(
            tracking_number,
            trackInfo,
            tracking_carrier_code
          );

          if (result.status === 200) {
            successCount++;
            console.log(
              `[CRON] ✓ Updated non-automated tracking ${tracking_number}`
            );
          } else {
            throw new Error(result.message);
          }
        } else {
          // console.log(`[CRON] No data found for ${tracking_number} via courier ${tracking_carrier_code}`);
          failureCount++;
        }
      } catch (error: any) {
        failureCount++;
        console.error(
          `[CRON] ✗ Failed non-automated ${tracking.tracking_number}: ${error.message}`
        );
      }
    }
    const duration = ((Date.now() - startTime) / 1000).toFixed(2);
    console.log(
      `[CRON] Completed Non-Automated: ${successCount} success, ${failureCount} failed in ${duration}s`
    );
  } catch (error: any) {
    console.error("[CRON] Error in non-automated tracking update:", error);
  }
}

// Update a single manual tracking based on courier type (Manual_Trackings table)
async function updateSingleTracking(tracking: any): Promise<boolean> {
  const { manual_tracking_id, manual_tracking_number, courier_id } = tracking;

  try {
    let result: any = null;
    let parsed: any = null;
    let newStatus: string = "";

    // Route to appropriate courier service based on courier_id
    switch (courier_id) {
      case 1: // DHL
        result = await getDhlTracking(manual_tracking_number);
        if (result?.status === 200) {
          parsed = parseDHLResponse(result.data);
          newStatus =
            parsed?.track_info?.latest_event?.description ||
            parsed?.track_info?.latest_status?.status ||
            "Unknown";
        }
        break;

      case 2: // TCS
        result = await getTcsTracking(manual_tracking_number);
        if (result?.status === 200) {
          parsed = parseTCSResponse(result.data);
          newStatus = normalizeTCSStatus(
            parsed?.track_info?.latest_event?.description ||
              parsed?.track_info?.latest_status?.status
          );
        }
        break;

      case 3: // BarqRaftar
        result = await getBarqRaftarTracking(manual_tracking_number);
        if (result?.status === 200) {
          parsed = parseBarqRaftarResponse(result.data);
          newStatus =
            parsed?.track_info?.latest_event?.description ||
            parsed?.track_info?.latest_status?.status ||
            "Unknown";
        }
        break;

      case 4: // BlueEX
        result = await getBlueExTracking(manual_tracking_number);
        if (result?.status === 200) {
          parsed = parseBlueExResponse(result.data);
          newStatus = normalizeBlueExStatus(
            parsed?.track_info?.latest_event?.description ||
              parsed?.track_info?.latest_status?.status ||
              "Unknown"
          );
        }
        break;

      case 5: // FlyCourier
        result = await getFlyCourierTracking(manual_tracking_number);
        if (result?.status === 200) {
          parsed = parseFlyCourierResponse(result.data);
          newStatus = normalizeFlyCourierStatus(
            parsed?.track_info?.latest_event?.description ||
              parsed?.track_info?.latest_status?.sub_status_descr || // Fly uses sub_status_descr often
              "Unknown"
          );
        }
        break;

      default:
        console.warn(
          `[CRON] Unknown courier_id ${courier_id} for tracking ${manual_tracking_number}`
        );
        return false;
    }

    // Update database if we got valid data
    if (parsed && newStatus) {
      await updateManualTrackingFromCron(manual_tracking_id, newStatus, parsed);
      return true;
    }

    return false;
  } catch (error: any) {
    throw new Error(
      `Failed to update tracking ${manual_tracking_number}: ${error.message}`
    );
  }
}
