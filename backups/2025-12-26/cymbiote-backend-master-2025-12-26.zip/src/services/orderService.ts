import {
  fetchShopifyOrderSource,
  getStaffNote,
} from "../graphql/orders/orderQueries";
import {
  checkCancellationRate,
  createOrder,
  getOrderByShopifyId,
  getPointLogIdByOrderId,
  getUserOrdersCountByShopDomain,
  OrderPointConnect,
  saveErrorOrderData,
  updateOrderCancelStatus,
  updateOrderStaffNote,
  updateShopDelistedStatus,
} from "../models/orders/dbOrders";
import {
  getShop,
  getShopDetailsByShopId,
  getShopFromOtherDomain,
} from "../models/shops/shopModel";
import { getUserByEmailOrUsername } from "../models/users/user";
import { DBOrder } from "../types/order/DBOrder";
import { ShopifyOrderResponse } from "../types/shopify_orders/Order";
import {
  calculateAndAddPoints,
  determinePointsCriteria,
} from "./pointsService";
import * as pointsModel from "../models/points/userPoints";
import { getFcmTokens } from "../models/notifications/notificationModel";
import {
  createAppNotificationsService,
  sendFCMNotification,
} from "./notificationService";
import { fetchProductVariantID } from "../models/productVariants/variantModel";
import { checkNotification } from "../functions/notificationSettings";
import { fetchShopifyProductVariant } from "../graphql/product/productQueries";
import { sendErrorEmail } from "./emailService";

export const processAndSaveOrderDetails = async (
  createdOrder: ShopifyOrderResponse
): Promise<void> => {
  let shopDomain: string | null = null;
  try {
    const orderid = createdOrder?.order?.id;
    const noteAttributes = createdOrder.order?.note_attributes || [];
    const cercleUserAttr = noteAttributes.find(
      (attr: any) => attr.name === "cercle_user_id"
    );
    const cercleUserId = cercleUserAttr
      ? Number(cercleUserAttr.value)
      : undefined;

    console.log("🔍 Webhook cercle_user_id:", cercleUserId);

    // Extract domain from order_status_url first, fallback to referring_site
    const urlToCheck =
      createdOrder?.order?.order_status_url ||
      createdOrder?.order?.referring_site;

    if (urlToCheck) {
      // This regex captures the domain part of any URL
      const m = urlToCheck.match(/^https?:\/\/([^/]+)/);
      if (m) shopDomain = m[1];
    }

    if (!shopDomain) throw new Error("Shop domain not found in order JSON.");

    let shopDetails = await getShop(shopDomain);
    if (!shopDetails?.[0])
      shopDetails = await getShopFromOtherDomain(shopDomain);

    if (!shopDetails?.[0])
      throw new Error(
        `No shop found for domain and other domain: ${shopDomain}`
      );

    const orderSource = await fetchShopifyOrderSource(
      createdOrder?.order?.id,
      shopDetails[0].shop_domain,
      shopDetails[0].shop_access_token
    );
    console.log("Order Source", orderSource?.app.name);

    const saved = await saveOrderDetails(
      createdOrder,
      shopDetails[0].shop_id,
      shopDetails[0].package_rate,
      orderSource?.app.name,
      cercleUserId || undefined
    );
    if (!saved?.length) throw new Error("Failed to save order details.");

    const order = await getOrderByShopifyId(Number(orderid));
    if (!order) throw new Error("Order not found.");

    if (order.order_user_id) {
      const pointsCriteria = await determinePointsCriteria(order);
      const pointId = await calculateAndAddPoints(
        order.order_user_id,
        order.order_shop_id,
        pointsCriteria,
        order.order_total_amount
      );
      await OrderPointConnect(saved[0].order_id, pointId);
    }

    let VariantImageUrl = await fetchProductVariantID(order.order_id);

    if (!VariantImageUrl) {
      const variant = (await fetchShopifyProductVariant(
        `gid://shopify/ProductVariant/` +
          createdOrder.order?.line_items[0].variant_id.toString() || "",
        shopDetails[0].shop_domain,
        shopDetails[0].shop_access_token
      )) as any;
      if (variant.media.nodes.length > 0) {
        VariantImageUrl = variant.media.nodes[0]?.preview?.image?.url || "";
      }
    }

    const canNotify = await checkNotification(
      order.order_user_id,
      "notification_setting_order_create"
    );

    if (!canNotify) {
      console.log(
        `User ${order.order_user_id} disabled order_create notifications.`
      );
      console.log(
        "Order details processed and saved successfully (no notification sent)."
      );
      return;
    }

    // 8) Send notification
    const fcmTokens = await getFcmTokens(order.order_user_id);
    if (!fcmTokens?.length) {
      console.log(
        `No FCM tokens for user ${order.order_user_id}. Skipping push.`
      );
      console.log("Order details processed and saved successfully.");
      return;
    }

    const MessageData = {
      title: "Order Placed Successfully",
      body: `Your order ${order.order_title} has been placed successfully. Track your order now.`,
      DeviceToken: JSON.stringify(fcmTokens),
      screenName: "Orders",
      orderId: order.order_id.toString(),
      notificationImageUrl: `${shopDetails[0].shop_logo_url}`,
      type: "token",
      payload: JSON.stringify({
        orderId: order.order_id,
        status: "Order Placed",
        ProductVariant: VariantImageUrl ?? "",
      }),
    };

    await createAppNotificationsService(order.order_user_id, MessageData);
    const notificationResult = await sendFCMNotification(
      fcmTokens,
      MessageData
    );
    console.log("notification Result in order capture", notificationResult);
    console.log("Order details processed and saved successfully.");
  } catch (error: any) {
    sendErrorEmail("Error processing and saving order details:", error);
    saveErrorOrderData(createdOrder.order as object, shopDomain);
    console.error("Error processing and saving order details:", error.message);
    throw error;
  }
};

export const saveOrderDetails = async (
  createdOrder: ShopifyOrderResponse,
  shopId: number,
  packageRate: number,
  ordersource: string,
  cercleUserId?: number
) => {
  let finalUserId: number | 0 = 0;

  // 1️⃣ Agar cercleUserId aaya hai, wohi use karo
  if (cercleUserId && !Number.isNaN(Number(cercleUserId))) {
    console.log("chala", cercleUserId);
    finalUserId = Number(cercleUserId);
  } else {
    console.log("andar chala ");
    // 2️⃣ Warna purana email-based resolve fallback
    const user = await getUserByEmailOrUsername(
      createdOrder.order?.customer?.email?.toString() || ""
    );
    finalUserId = user?.user_id ?? 0;
  }

  const order: DBOrder = {
    order_user_id: finalUserId,
    order_date: new Date(),
    order_delivery_address: createdOrder.order?.shipping_address
      ? createdOrder.order.shipping_address.address1 +
        ", " +
        createdOrder.order.shipping_address.city +
        ", " +
        createdOrder.order.shipping_address.country
      : "",
    order_fulfillment_status: createdOrder.order?.fulfillment_status
      ? createdOrder.order?.fulfillment_status
      : "",
    order_shop_id: shopId,
    order_shopify_id: createdOrder.order?.id
      ? createdOrder.order.id.toString()
      : "",
    order_total_amount: createdOrder.order?.total_price
      ? parseFloat(createdOrder.order?.total_price)
      : 0,
    order_charge_rate: packageRate ? packageRate : 0,
    order_title: createdOrder.order?.name ? createdOrder.order.name : "",
    order_payment_status: createdOrder.order?.financial_status || "pending",
    order_channel: ordersource,
    order_shipping: Number(
      createdOrder.order?.total_shipping_price_set?.presentment_money?.amount
    ),
    order_tax:
      (createdOrder.order?.tax_lines?.length &&
        Number(createdOrder.order?.tax_lines[0]?.price)) ||
      0,
    order_tax_rate:
      (createdOrder.order?.tax_lines?.length &&
        Number(createdOrder.order?.tax_lines[0]?.rate)) ||
      0,
    order_total_discount_amount: createdOrder.order?.current_total_discounts
      ? parseFloat(createdOrder.order?.current_total_discounts)
      : 0,
  };
  const discountCodes = createdOrder?.order?.discount_codes || [];
  try {
    console.log("orders", order);
    const response = await createOrder(
      discountCodes,
      order,
      createdOrder.order?.line_items ? createdOrder.order.line_items : []
    );
    console.log("order result response", response);
    return response;
  } catch (error: any) {
    sendErrorEmail("error", error);

    console.log("error", error);
  }
};

export const cancelOrderStatusService = async (
  shopify_order_id: string,
  cancel_reason: string,
  fulfillment_status: string,
  order_cancelled_at: Date
) => {
  // 1) Persist cancellation on the order
  const result = await updateOrderCancelStatus(
    shopify_order_id,
    cancel_reason,
    order_cancelled_at,
    fulfillment_status
  );

  if (result.rowsAffected[0] === 0) {
    return false;
  }

  // 2) Load context
  const shopDomain = result.shopDetails?.[0]?.shop_domain;
  const order = await getOrderByShopifyId(Number(shopify_order_id));
  if (!order) throw new Error("Order not found.");

  const shop = await getShopDetailsByShopId(order.order_shop_id);
  const staffNote = await getStaffNote(
    shopDomain,
    shop?.shop_access_token ?? "",
    shopify_order_id
  );
  if (staffNote) {
    await updateOrderStaffNote(shopify_order_id, staffNote);
  }

  const cancellationData = await checkCancellationRate(shopDomain);
  // 3) Update points status if user exists
  if (order.order_user_id) {
    const connect = await getPointLogIdByOrderId(order.order_id);
    await pointsModel.UpdatePointStatus(
      connect.connect_point_log_id,
      "cancelled"
    );
  }

  // 4) Build cancellation message (dynamic by reason)
  let title = `Your order #${order.order_title} has been cancelled`;
  let body = `Your order has been successfully cancelled. If this wasn’t intended or you need assistance, please contact our support team.`;
  let payloadStatus = "Order Cancelled";

  switch (cancel_reason) {
    case "inventory":
      title = `Your order #${order.order_title} has been cancelled due to stock unavailability`;
      body = `We’re sorry, but one or more items in your order are no longer in stock, and your order has been cancelled. Please contact our support team for alternative options or assistance.`;
      payloadStatus = "Order Cancelled - Out of Stock";
      break;

    case "fraud":
      title = `Your order #${order.order_title} has been cancelled for security reasons`;
      body = `We detected unusual activity and, for your protection, your order has been cancelled. If you believe this is a mistake or need assistance, please contact our support team immediately.`;
      payloadStatus = "Order Cancelled - Security Issue";
      break;

    case "other":
      title = `Your order #${order.order_title} has been cancelled`;
      body = `Your order has been cancelled due to unforeseen circumstances. If you have any questions or need help, please contact our support team.`;
      payloadStatus = "Order Cancelled - Other Reason";
      break;

    case "declined":
      title = `Your order #${order.order_title} has been declined and cancelled`;
      body = `Unfortunately, your order could not be processed and has been cancelled. Please contact our support team for more details or assistance with placing a new order.`;
      payloadStatus = "Order Declined";
      break;

    case "staff":
      title = `Your order #${order.order_title} has been cancelled by our team`;
      body = `Your order was cancelled by our staff due to internal reasons. If you have any questions or need assistance, please contact our support team.`;
      payloadStatus = "Order Cancelled - Staff Initiated";
      break;
  }

  // 5) 🔔 Notification gate — just like before (use order_update toggle for cancellations)
  if (order.order_user_id) {
    const canNotify = await checkNotification(
      order.order_user_id,
      "notification_setting_order_update"
    );

    if (!canNotify) {
      console.log(
        `User ${order.order_user_id} disabled order_update notifications.`
      );
    } else {
      // Only fetch heavy stuff if we will notify
      const VariantImageUrl = await fetchProductVariantID(order.order_id);
      const fcmTokens = await getFcmTokens(order.order_user_id);

      if (!fcmTokens?.length) {
        console.log(
          `No FCM tokens for user ${order.order_user_id}. Skipping push.`
        );
      } else {
        const MessageData = {
          title,
          body,
          image: VariantImageUrl || null,
          DeviceToken: JSON.stringify(fcmTokens),
          screenName: "Orders",
          orderId: order.order_id.toString(),
          notificationImageUrl: `${shop?.shop_logo_url ?? ""}`,
          type: "token",
          payload: JSON.stringify({
            status: payloadStatus,
            ProductVariant: VariantImageUrl,
            orderId: order.order_id,
          }),
        };

        // Save + Send
        await createAppNotificationsService(order.order_user_id, MessageData);
        const notificationResult = await sendFCMNotification(
          fcmTokens,
          MessageData
        );
        console.log("notification Result", notificationResult);
      }
    }
  }

  // 6) Delist / risk checks
  const orderCount = await getUserOrdersCountByShopDomain(shopDomain);
  if (cancellationData.canceledOrders >= 10 && orderCount.order_count > 5) {
    const response = await updateShopDelistedStatus(shopDomain);
    if (response.success) {
      console.log(`Shop with domain ${shopDomain} was successfully delisted.`);
    }
  } else {
    if (cancellationData.canceledOrders >= 7) {
      console.log("Channel active status at risk");
    } else {
      console.log("Channel status safe");
    }
  }

  return result.rowsAffected[0] !== 0;
};
