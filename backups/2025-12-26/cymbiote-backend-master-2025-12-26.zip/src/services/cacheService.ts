import { addUserCache, getUserCache } from "../models/users/user";
import { sendErrorEmail } from "./emailService";

export const checkForUserCache = async (userId: number) => {
  try {
    const usercache = await getUserCache(userId);

    if (!usercache) {
      return null;
    }

    return JSON.parse(usercache.cache_json);
  } catch (error: any) {
    sendErrorEmail("User cache check issue. ", error);

    throw new Error("User cache check issue. " + error.any);
  }
};

export const insertCacheInformation = (userId: number, cacheJson: string) => {
  try {
    addUserCache(userId, cacheJson);
  } catch (error: any) {
    sendErrorEmail("Cache could not be loaded", error);

    throw new Error("Cache could not be loaded");
  }
};
