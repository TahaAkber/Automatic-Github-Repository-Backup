import {
  createRecentView,
  getRecentView,
} from "../models/recentView/recentView";
import { RecentView } from "../types/RecentView";
import { sendErrorEmail } from "./emailService";

export const recentView = async ({
  user_id,
  recent_view_type,
  recent_view_product_id,
  recent_view_shop_id,
}: RecentView): Promise<number> => {
  try {
    // Call model function to create a recent view record
    await createRecentView({
      user_id,
      recent_view_type,
      recent_view_product_id,
      recent_view_shop_id,
    });

    return 1;
  } catch (error: any) {
    sendErrorEmail("Error creating recent view record: ", error);

    throw new Error("Error creating recent view record: " + error.message);
  }
};

export const fetchRecentView = async (
  user_id: number,
  local_recent_view: any[],
  page: number,
  pageSize: number
): Promise<any[]> => {
  try {
    // Call model function to create a recent view record
    const result = await getRecentView(
      user_id,
      local_recent_view,
      page,
      pageSize
    );
    return result;
  } catch (error: any) {
    sendErrorEmail("Error fethcing recent view record: ", error);

    throw new Error("Error fethcing recent view record: " + error.message);
  }
};
