import { getAnalyticsFromFirebase } from "../models/analytics/analyticsModel";
import { AnalyticsParams } from "../types/analytics/Analytics";
import { sendErrorEmail } from "./emailService";
export const fetchAnalyticsFromFirebase = async (
  searchParams?: AnalyticsParams
) => {
  try {
    const rows = await getAnalyticsFromFirebase(searchParams);
    const cleaned = rows.map((event: any) => {
      const params = event.event_params?.reduce((acc: any, p: any) => {
        acc[p.key] = p.value;
        return acc;
      }, {});

      const result: Record<string, any> = {};

      // Helper function to add field only if it has a value
      const addField = (key: string, value: any) => {
        if (value !== null && value !== undefined) {
          result[key] = value;
        }
      };

      // Event metadata
      addField('event_timestamp', event.event_timestamp);
      addField('event_date', event.event_date);
      addField('event_name', event.event_name);
      addField('event_type', params?.event_type?.string_value);
      addField('timestamp', params?.timestamp?.string_value);

      // User information
      addField('user_id', params?.user_id?.string_value);
      addField('user_name', params?.user_name?.string_value);
      addField('device_id', params?.device_id?.string_value);

      // Platform and device info
      addField('platform', params?.platform?.string_value);
      addField('device_os', event.device_os);
      addField('device_brand', event.device_brand);
      addField('device_model', event.device_model);

      // Geo location
      addField('city', event.city);
      addField('country', event.country);
      addField('region', event.region);

      // App info
      addField('app_version', event.app_version);
      addField('app_package_name', event.app_package_name);
      addField('firebase_app_id', event.firebase_app_id);

      // Merchant/Shop information
      addField('merchant_id', params?.merchant_id?.double_value);
      addField('merchant_name', params?.merchant_name?.string_value);
      addField('merchant_shopify_id', params?.merchant_shopify_id?.string_value);
      addField('shop_id', params?.shop_id?.double_value);
      addField('shop_name', params?.shop_name?.string_value);
      addField('shop_tile_type', params?.shop_tile_type?.string_value);

      // Product information
      addField('product_id', params?.product_id?.double_value);
      addField('product_name', params?.product_name?.string_value);
      addField('product_price', params?.product_price?.double_value);

      // Screen and view data
      addField('screen_name', params?.screen_name?.string_value);
      addField('screen_time_seconds', params?.screen_time_seconds?.double_value);
      addField('product_view', params?.product_view?.double_value);
      addField('merchant_view', params?.merchant_view?.double_value);
      addField('view_duration_seconds', params?.view_duration_seconds?.double_value);

      // Search data
      addField('search_query', params?.search_query?.string_value);
      addField('result_type', params?.result_type?.string_value);
      addField('is_from_search', params?.is_from_search?.string_value);
      addField('total_results', params?.total_results?.double_value);
      addField('products_count', params?.products_count?.double_value);
      addField('shops_count', params?.shops_count?.double_value);

      // Position tracking
      addField('position_in_results', params?.position_in_results?.double_value);
      addField('position_in_list', params?.position_in_list?.double_value);
      addField('tile_position', params?.tile_position?.double_value);
      addField('product_position_in_tile', params?.product_position_in_tile?.double_value);

      // Deal information
      addField('deal_id', params?.deal_id?.double_value);
      addField('deal_banner_url', params?.deal_banner_url?.string_value);

      // Skipped items data
      addField('skipped_count', params?.skipped_count?.double_value);
      addField('skipped_items', params?.skipped_items?.string_value);
      addField('skipped_shop_ids', params?.skipped_shop_ids?.string_value);
      addField('skipped_product_ids', params?.skipped_product_ids?.string_value);
      addField('skipped_shops_count', params?.skipped_shops_count?.double_value);
      addField('skipped_products_count', params?.skipped_products_count?.double_value);

      // Navigation data
      addField('from_screen', params?.from_screen?.string_value);
      addField('to_screen', params?.to_screen?.string_value);
      addField('from_tab', params?.from_tab?.string_value);
      addField('to_tab', params?.to_tab?.string_value);

      // Filter change data
      addField('filter_type', params?.filter_type?.string_value);
      addField('filter_value', params?.filter_value?.string_value);
      addField('previous_value', params?.previous_value?.string_value);

      // Item metadata
      addField('item_id', params?.item_id?.string_value);
      addField('item_name', params?.item_name?.string_value);
      addField('item_type', params?.item_type?.string_value);

      // All count fields
      addField('all_count', params?.all_count?.double_value);
      addField('total_displayed', params?.total_displayed?.double_value);
      addField('total_viewed', params?.total_viewed?.double_value);
      addField('total_clicked', params?.total_clicked?.double_value);
      addField('total_products', params?.total_products?.double_value);
      addField('products_count_tile', params?.products_count_tile?.double_value);

      return result;
    });

    return {
      status: 200,
      data: cleaned,
      total: cleaned.length,
    };
  } catch (error: any) {
    sendErrorEmail("Service Error - BigQuery fetch failed:", error);

    console.error("Service Error - BigQuery fetch failed:", error);
    return {
      status: 500,
      message: "Failed to fetch analytics data",
    };
  }
};
