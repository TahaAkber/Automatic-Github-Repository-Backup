import { retryOperation } from "../functions/common";
import { uploadToGumlet } from "../functions/gumlet";
import {
  getAllProductImage,
  getNextProductRow,
  getNextShopRow,
  getVideoNextRow,
  updateProductImageUrls,
  updateShopUrl,
  updateVideoUrl,
} from "../models/videoCompressor/compressToolModal";
import dotenv from "dotenv";
import { imageDimensionsFromStream } from "image-dimensions";
import { sendErrorEmail } from "./emailService";
import { getAspectRatio } from "../functions/aspectRatio";

dotenv.config();

export const compressShopTileVideos = async () => {
  try {
    let row = await getNextShopRow();

    while (row) {
      console.log("Row", row);
      try {
        const newUrl = await uploadToGumlet("tile", row.shop_banner_url, "MP4");
        await updateShopUrl(row.shop_id, newUrl);
        console.log(`Updated shop_id ${row.shop_id}`);
      } catch (err: any) {
        // Error handling for each row, logs the error and continues to the next row
        console.error(`Error processing shop_id ${row.shop_id}:`, err);
      }

      row = await getNextShopRow();
    }

    return true;
  } catch (err: any) {
    sendErrorEmail("Error in compressShopTileVideos function:", err);

    // Error handling for the overall function
    console.error("Error in compressShopTileVideos function:", err);
    return false;
  }
};

export const compressShopProductImages = async () => {
  try {
    const productImages = await getAllProductImage();
    const BATCH_SIZE = 100; // safe batch size

    if (productImages.length > 0) {
      for (let i = 0; i < productImages.length; i += BATCH_SIZE) {
        const batch = productImages.slice(i, i + BATCH_SIZE);

        for (const productImage of batch) {
          try {
            let sliceIndex = 0;
            if (productImage.product_image_url.includes("cdn.shopify.com")) {
              sliceIndex = 23;
            } else if (
              productImage.product_image_url.includes("cdn.cercle.one")
            ) {
              sliceIndex = 22;
            } else if (
              productImage.product_image_url.includes("cercleone32.gumlet.io")
            ) {
              sliceIndex = 29;
            }

            const newUrl = productImage.product_image_url.slice(sliceIndex);


            const { body } = await fetch(productImage.product_image_url);
            let lowUrl: string =
              "https://cdn.shopify.com/s/files/1/0595/2379/2944/files/No_image_available.webp?v=1756886203";
            let averageUrl: string =
              "https://cdn.shopify.com/s/files/1/0595/2379/2944/files/No_image_available.webp?v=1756886203";
            let highUrl: string =
              "https://cdn.shopify.com/s/files/1/0595/2379/2944/files/No_image_available.webp?v=1756886203";

            if (body) {
              const dimensions = await imageDimensionsFromStream(body);

              //   if (dimensions) {
              //     const info = getAspectRatio(
              //       dimensions.width,
              //       dimensions.height,
              //       2
              //     ); // 2% tolerance
              //     console.log("aspect Ratio", info);
              //   }
              //   if (dimensions) {
              //     const dimensionWidthSmall = dimensions.width * 0.3;
              //     const dimensionHeightSmall = dimensions.height * 0.3;

              //     const dimensionWidthMedium = dimensions.width * 0.5;
              //     const dimensionHeightMedium = dimensions.height * 0.5;

              //     const dimensionWidthHigh = dimensions.width * 0.8;
              //     const dimensionHeightHigh = dimensions.height * 0.8;

              //     lowUrl = `https://${
              //       process.env.GUMLET_IMAGE_SUBDOMAIN
              //     }${newUrl}&width=${dimensionWidthSmall.toFixed(
              //       2
              //     )}&height=${dimensionHeightSmall.toFixed(2)}`;

              //     averageUrl = `https://${
              //       process.env.GUMLET_IMAGE_SUBDOMAIN
              //     }${newUrl}&width=${dimensionWidthMedium.toFixed(
              //       2
              //     )}&height=${dimensionHeightMedium.toFixed(2)}`;

              //     highUrl = `https://${
              //       process.env.GUMLET_IMAGE_SUBDOMAIN
              //     }${newUrl}&width=${dimensionWidthHigh.toFixed(
              //       2
              //     )}&height=${dimensionHeightHigh.toFixed(2)}`;
              //   } else {
              //     // fallback when dimensions are null
              //     lowUrl = averageUrl =
              //       "https://cdn.shopify.com/s/files/1/0595/2379/2944/files/No_image_available.webp?v=1756886203";
              //   }
              // } else {
              //   // fallback when fetch body is null
              //   lowUrl = averageUrl =
              //     "https://cdn.shopify.com/s/files/1/0595/2379/2944/files/No_image_available.webp?v=1756886203";
              //   console.warn("No body returned from fetch for", newUrl);
              // }

              if (dimensions) {
                const { width: W, height: H } = dimensions;

                const LONG_EDGE = Math.max(W, H);
                const useOriginal = LONG_EDGE <= 500;

                const scaleDims = (factor: number) => {
                  const w = Math.max(1, Math.round(W * factor));
                  const h = Math.max(1, Math.round(H * factor));
                  return { w, h };
                };

                let small = { w: W, h: H };
                let medium = { w: W, h: H };
                let high = { w: W, h: H };

                if (!useOriginal) {
                  small = scaleDims(0.3);
                  medium = scaleDims(0.5);
                  high = scaleDims(0.8);
                }

                const base = `https://${process.env.GUMLET_IMAGE_SUBDOMAIN}${newUrl}`;


                lowUrl = `${base}&width=${small.w}&height=${small.h}`;
                averageUrl = `${base}&width=${medium.w}&height=${medium.h}`;
                highUrl = `${base}&width=${high.w}&height=${high.h}`;

                const isLandscape = W > H;
                const buildByLongEdge = (d: { w: number; h: number }) => {
                  if (isLandscape) {
                    return `${base}&width=${d.w}`;
                  } else if (W < H) {
                    return `${base}&height=${d.h}`;
                  } else {
                    return `${base}&width=${d.w}`;
                  }
                };

                lowUrl = buildByLongEdge(small);
                averageUrl = buildByLongEdge(medium);
                highUrl = buildByLongEdge(high);
              } else {
                lowUrl = averageUrl =
                  "https://cdn.shopify.com/s/files/1/0595/2379/2944/files/No_image_available.webp?v=1756886203";
              }
            }

            await updateProductImageUrls(
              productImage.product_image_id,
              lowUrl,
              averageUrl,
              highUrl
            );

            console.log(`Updated product ${productImage.product_image_id}`);
          } catch (rowError: any) {
            sendErrorEmail(
              `Error updating product ${productImage.product_image_id}:`,
              rowError
            );

            console.error(
              `Error updating product ${productImage.product_image_id}:`,
              rowError
            );
          }
        }

        console.log(`Batch ${i / BATCH_SIZE + 1} processed`);

        await new Promise((resolve) => setTimeout(resolve, 200));
      }
    }

    console.log("All product images processed.");
  } catch (error: any) {
    sendErrorEmail("Error in compressShopProductImages:", error);
    console.error("Error in compressShopProductImages:", error);
    return false;
  }
};

export const compressShopRNSVideos = async () => {
  try {
    let videoRow = await getVideoNextRow();

    while (videoRow) {
      try {
        const newUrl = await uploadToGumlet("rns", videoRow.video_url);
        await updateVideoUrl(videoRow.video_id, newUrl);
        console.log(`Updated video_id ${videoRow.video_id}`);
      } catch (err) {
        console.error(`Error processing video_id ${videoRow.video_id}:`, err);
      }

      videoRow = await getVideoNextRow();
    }
    return true;
  } catch (error: any) {
    sendErrorEmail("Error in compressShopRNSVideos function:", error);

    console.error("Error in compressShopRNSVideos function:", error.message);
    return false;
  }
};
