import jwt from "jsonwebtoken";
// import {
//   manageUserFollowing,
//   userFollowingLogs
// } from "../models/following/following";
import dotenv from "dotenv";
import {
  ManageUserWishlist,
  userWishlistLogs,
} from "../models/wishlist/wishlist";
import { getSpecificProduct } from "../models/products/productModel";
import { getShopWithRatingUsingShopId } from "../models/shops/shopModel";
import { sendErrorEmail } from "./emailService";
// import { getProducts, getUsingShopId } from "../models/products/productModel";

dotenv.config();

export const createWishlistLogs = async (
  userId: number,
  productId: number,
  isAdded: boolean,
  createdAt: string
): Promise<any> => {
  try {
    // Call model function to create a new user
    const response = await ManageUserWishlist(
      userId,
      productId,
      isAdded,
      createdAt
    );

    return { status: 200, message: response };
  } catch (error: any) {
    sendErrorEmail("Error creating following logs: ", error);

    throw new Error("Error creating following logs: " + error.message);
  }
};

export const wishlistLogs = async (
  userId: number,
  wishlist_local?: any
): Promise<any> => {
  try {
    const response = await userWishlistLogs(userId, wishlist_local);

    const modifiedArr = (
      await Promise.all(
        response.map(async (item: any) => {
          const product_detail = await getSpecificProduct(
            item.wishlist_product_id
          );

          if (!product_detail) {
            return null;
          }

          const shop_detail = await getShopWithRatingUsingShopId(
            product_detail.product_shop_id
          );

          return {
            ...item,
            product_detail,
            shop_detail,
          };
        })
      )
    ).filter(Boolean);

    // Grouping by shop_id
    const groupedShops = modifiedArr.reduce((shops: any, item: any) => {
      const shopId = item.shop_detail.shop_id;

      if (!shops[shopId]) {
        shops[shopId] = {
          ...item.shop_detail,
          products: [],
        };
      }

      shops[shopId].products.push({
        ...item.product_detail,
      });

      return shops;
    }, {});

    const finalResult = Object.values(groupedShops);

    return { status: 200, message: "Success", data: finalResult };
  } catch (error: any) {
    sendErrorEmail("Error fetching wishlist logs: ", error);

    throw new Error("Error fetching wishlist logs: " + error.message);
  }
};
