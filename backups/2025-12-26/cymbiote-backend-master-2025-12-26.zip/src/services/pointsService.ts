import { toFixedMethod } from "../functions/common";
import {
  applyAllOrderCriteria,
  applyProductOrderCriteria,
} from "../functions/pointsCriteria";
import { createCreditsOnMerchant } from "../graphql/credits/mutation";
import { getNextSubscriptionBillingDate } from "../graphql/subscription/subscriptionQueries";
import { createVoucherOnMerchant } from "../graphql/voucher/mutation";
import {
  checkVoucherEligibility,
  insertCreditInformation,
} from "../models/credits/creditsModel";
import { getOrderItemsWithCategory } from "../models/orders/dbOrders";
import { getAllPointsCriteria } from "../models/points/pointsCriteria";
import * as pointsModel from "../models/points/userPoints";
import {
  getShopWithActiveSubByShopId,
  updateShopCreds,
} from "../models/shops/shopModel";
import { createTransaction } from "../models/transactions/dbTransactions";
import { getUserById } from "../models/users/user";
import { Criteria } from "../types/points/criteria";
import { getCurrentCurrencyRate } from "./currencyService";
import dotenv from "dotenv";
import { sendErrorEmail } from "./emailService";
dotenv.config();
export const fetchActiveCriteria = async (): Promise<any> => {
  return await pointsModel.getActiveCriteria();
};

export const calculateAndAddPoints = async (
  userId: number,
  shopId: number,
  criteria: Criteria[],
  transactionValue: number
): Promise<any> => {
  let points = 0;
  let pointId = 0;
  // Fetch the criteria
  const activeCriteria = await pointsModel.getActiveCriteria();

  for (const item of criteria) {
    const dbCriteria = activeCriteria.find(
      (c: any) => c.criteria_id === item.criteriaId
    );
    if (!dbCriteria) {
      throw new Error("Invalid criteria or criteria is not active.");
    }
    if (item.applyType === "All") {
      const data = await applyAllOrderCriteria(
        dbCriteria,
        points,
        transactionValue,
        userId,
        shopId
      );
      points = data.currentPoints;
      pointId = data.pointsLogId;
      console.log("Points Id", pointId);
      return pointId;
    } else if (item.applyType === "Product") {
      const data = await applyProductOrderCriteria(
        dbCriteria,
        item.orderItemPrice as number,
        points,
        userId,
        shopId
      );
      points = data.currentPoints;
      pointId = data.pointsLogId;
      return pointId;
    }
  }

  console.log("points", points, "userId", userId);

  await pointsModel.addPointsToUser(userId, points);
};

export const fetchUserTotalPoints = async (userId: number): Promise<number> => {
  return await pointsModel.getUserTotalPoints(userId);
};

export const fetchUserPointsLog = async (
  userId: number,
  page: number,
  pageSize: number,
  status?: string
) => {
  return await pointsModel.logPointsToUser(userId, page, pageSize, status);
};

export const fetchUserVouchers = async (
  userId: number,
  page: number,
  pageSize: number,
  shopId?: number
) => {
  return await pointsModel.userVouchers(userId, page, pageSize, shopId);
};

export const creatingPointsLog = async (
  userId: number,
  shopId: number,
  pointsToDeduct: number,
  description: string,
  criteriaId = 5,
  checkPoints = true
): Promise<void> => {
  if (checkPoints) {
    const totalPoints = await pointsModel.getUserTotalPoints(userId);

    if (totalPoints < pointsToDeduct) {
      throw new Error("Insufficient points.");
    }
  }

  // Log deduction as a negative transaction
  await pointsModel.logUserPoints(
    userId,
    shopId,
    criteriaId,
    -pointsToDeduct,
    description,
    "redeemed"
  );
};

export const createVoucher = async (
  userId: number,
  pointsToDeduct: number,
  shopId: number
): Promise<{
  status: number;
  message: string;
  data?: string;
}> => {
  const user = await getUserById(userId);
  const shop = await getShopWithActiveSubByShopId(shopId);
  const currencyRate = await getCurrentCurrencyRate("USD", "PKR");
  const convertedPoints = pointsToDeduct / currencyRate;
  const formattedPointstodeduct = parseFloat(toFixedMethod(pointsToDeduct));

  if (!user) {
    return {
      status: 400,
      message: "User not found",
      data: "",
    };
  }

  if (user?.user_points < pointsToDeduct) {
    return {
      status: 400,
      message: "Insufficient points.",
      data: "",
    };
  }

  if (!shop) {
    return {
      status: 400,
      message: "Shop not available",
      data: "",
    };
  }

  const billingDate = await getNextSubscriptionBillingDate(
    shop.shop_access_token,
    shop.shop_domain
  );

  const shopCreds = await updateShopCreds(shopId, billingDate);
  console.log("billing date", billingDate, shopCreds);
  if (!billingDate) {
    return {
      status: 400,
      message: "Failed to get billing date",
      data: "",
    };
  }

  const voucherEligibility = await checkVoucherEligibility(
    shopId,
    billingDate,
    convertedPoints
  );

  if (!voucherEligibility) {
    return {
      status: 400,
      message: "Voucher limit exceeded for this store",
      data: "",
    };
  }

  const voucher = await createVoucherOnMerchant(
    shop?.shop_domain,
    shop.shop_access_token,
    formattedPointstodeduct,
    user
  );

  console.log("new voucher", voucher);
  console.log("APP_ID:", process.env.APP_ID);

  const creditDescription = `Voucher redemption on Cercle for customer ${user.user_email}`;

  const creditMerchant = await createCreditsOnMerchant(
    process.env.APP_ID!,
    `${shop.shop_shopify_id}`,
    convertedPoints,
    creditDescription
  );

  if (creditMerchant) {
    await insertCreditInformation(
      creditMerchant.amount.amount,
      creditMerchant.amount.currencyCode,
      shopId,
      creditDescription
    );
  }

  const description = `Redeemed ${formattedPointstodeduct} points for a voucher at ${shop.shop_name}`;

  await creatingPointsLog(
    userId,
    shop.shop_id,
    formattedPointstodeduct,
    description,
    4,
    false
  );

  console.log("id", voucher?.id);
  console.log("giftCardCode", voucher?.code);
  console.log("expiresOn", voucher?.discountCardCode?.endsAt);
  await pointsModel.insertVoucher(
    userId,
    formattedPointstodeduct,
    shopId,
    voucher?.id,
    voucher?.code,
    voucher?.discountCardCode?.endsAt
  );

  await createTransaction(
    shopId,
    formattedPointstodeduct,
    creditMerchant.amount.amount,
    "CREDIT",
    "Credits against voucher created",
    undefined,
    shop.subscription_id as number,
    shop.shop_currency,
    "adjustment"
  );

  const voucherDetail = await pointsModel.getVoucherByCode(voucher?.code);

  return {
    status: 200,
    message: "Voucher created successfully",
    data: voucherDetail,
  };
};

export const determinePointsCriteria = async (
  order: any
): Promise<Criteria[]> => {
  try {
    const order_items = await getOrderItemsWithCategory(order.order_id);

    if (!order_items || order_items.length === 0) {
      console.log("No order items found.");
      return [{ applyType: "All", criteriaId: 2 }];
    }

    const pointsCriteria = await getAllPointsCriteria();
    const allCriterias: Criteria[] = [];

    // Traverse order items and find a matching criteria
    for (const item of order_items) {
      const itemCategory = item.order_item_category;

      for (const criteria of pointsCriteria) {
        if (criteria.criteria_identifier.includes(itemCategory)) {
          console.log(
            `Match found: ${itemCategory} -> ${criteria.criteria_name}`
          );
          allCriterias.push({
            applyType: "Product",
            criteriaId: criteria.criteria_id,
            orderItemPrice: item.order_item_price - item.order_item_disc_amount,
          });
        }
      }
    }

    if (allCriterias.length < 1) {
      return [{ applyType: "All", criteriaId: 2 }];
    }

    return allCriterias;
  } catch (error: any) {
    sendErrorEmail("Error determining points criteria:", error);

    console.error("Error determining points criteria:", error);
    throw new Error("Failed to determine points criteria.");
  }
};
