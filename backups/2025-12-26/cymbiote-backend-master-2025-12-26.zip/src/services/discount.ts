import { createCercleOnlyDiscount } from "../graphql/discount/mutation";
import {
  checkVariantsForDiscount,
  getLatestDiscountId,
  insertDiscountCode,
} from "../models/discount/discountModel";
import { CreateDiscountCodeReturn } from "../types/discounts/CreateDiscountCodeReturn";
import { OrderLineItem } from "../types/order/OrderLineItem";
import { sendErrorEmail } from "./emailService";

export const createDiscountForLineItems = async (
  variantItems: OrderLineItem[],
  accessToken: string,
  shopDomain: string
) => {
  try {
    const discountAppliedVariants = await checkVariantsForDiscount(
      variantItems
    );

    if (discountAppliedVariants.length < 1) {
      return [];
    }

    const currentDiscountId = await getLatestDiscountId();

    const discountCodes = await Promise.all(
      discountAppliedVariants.map(async (variant, index) => {
        try {
          // Call createCercleOnlyDiscount for each variant
          const newDiscount = await createCercleOnlyDiscount(
            variant.variant_price_off,
            variant.variant_shopify_id,
            currentDiscountId ? currentDiscountId + index : index,
            accessToken,
            shopDomain
          );
          return newDiscount as CreateDiscountCodeReturn;
        } catch (error) {
          console.error(
            `Error creating discount for variant ${variant.variant_shopify_id}:`,
            error
          );
          return null;
        }
      })
    );

    console.log("Successfully created discount codes");
    return discountCodes;
  } catch (error: any) {
    sendErrorEmail("Error in createDiscountForLineItems:", error);

    console.error("Error in createDiscountForLineItems:", error);
    throw new Error("Failed to create discount codes for line items");
  }
};
