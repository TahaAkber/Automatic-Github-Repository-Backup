import admin from 'firebase-admin';

admin.initializeApp({
  credential: admin.credential.cert({
    projectId: 'your-project-id',
    privateKey: 'your-private-key',
    clientEmail: 'your-client-email',
  }),
});

export const sendFirebaseNotification = async (userEmail: string, title: string, body: string) => {
  // Assuming you have a way to get the device token for the user
  const userDeviceToken = await getUserDeviceToken(userEmail);

  const message = {
    notification: {
      title: title,
      body: body,
    },
    token: userDeviceToken,
  };

  try {
    await admin.messaging().send(message);
    console.log('Notification sent successfully.');
  } catch (error) {
    console.error('Error sending notification:', error);
  }
};

const getUserDeviceToken = async (email: string) => {
  // Fetch device token based on email (your logic to get this info)
  return 'user-device-token'; // Replace with actual logic to retrieve device token
};
