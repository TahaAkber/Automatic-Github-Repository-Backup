import nodemailer from "nodemailer";
import dotenv from "dotenv";

dotenv.config();

const auth = {
  user: process.env.EMAIL_USER,
  pass: process.env.EMAIL_PASS,
};

const transporter = nodemailer.createTransport({
  host: "mail.cymbiote.com",
  port: 465,
  secure: true,
  auth,
});

export const sendOtpEmail = async (email: string, otp: string) => {
  console.log("auth", auth);

  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: email,
    subject: "Your OTP Code",
    text: `Your OTP code is: ${otp}`,
  };

  await transporter.sendMail(mailOptions);
};

export const sendErrorEmail = async (
  title: string,
  error: string,
  payload = {},
  retries = 3, // Number of retry attempts
  delayMs = 30000 // Delay between retries (30s)
) => {
  const dbName = process.env.DB_NAME || "cymbiote";

  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: "bilal.khan@bestselection.pk",
    cc: "hira.rehman@bestselection.pk",
    subject: `Your ${dbName} Backend Error Report`,
    text: `Title: ${title} \nBody: ${error} \n\n${
      Object.keys(payload).length > 0
        ? "Payload: " + JSON.stringify(payload)
        : ""
    }`,
  };

  // Retry loop
  for (let attempt = 1; attempt <= retries; attempt++) {
    try {
      const info = await transporter.sendMail(mailOptions);
      console.log("Error email sent successfully:", info.response);
      return info;
    } catch (err: any) {
      console.error(`Attempt ${attempt} failed:`, err.message || err);

      // If last attempt, throw the error
      if (attempt === retries) {
        console.error("All retry attempts failed. Email not sent.");
        throw err;
      }

      // If it's a temporary Gmail error, wait and retry
      if (err.code === "EENVELOPE" || err.responseCode === 421) {
        console.log(`Retrying in ${delayMs / 1000}s...`);
        await new Promise((res) => setTimeout(res, delayMs));
      } else {
        // Other errors, no retry
        throw err;
      }
    }
  }
};

export const sendDuplicateTransactionEmail = async (
  shopId: number,
  transactionDetail: string,
  title = "Duplicate Transaction Attempt",
  retries = 3,
  delayMs = 30000
) => {
  const dbName = process.env.DB_NAME || "cymbiote";

  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: "bilal.khan@bestselection.pk",
    cc: "hira.rehman@bestselection.pk",
    subject: `[${dbName}] ${title}`,
    text: `A duplicate transaction attempt was detected.\n\nShop ID: ${shopId}\nTransaction Detail: ${transactionDetail}\n\nPlease review this action.`,
  };

  for (let attempt = 1; attempt <= retries; attempt++) {
    try {
      const info = await transporter.sendMail(mailOptions);
      console.log(
        "Duplicate transaction email sent successfully:",
        info.response
      );
      return info;
    } catch (err: any) {
      console.error(`Attempt ${attempt} failed:`, err.message || err);

      if (attempt === retries) {
        console.error("All retry attempts failed. Email not sent.");
        throw err;
      }

      if (err.code === "EENVELOPE" || err.responseCode === 421) {
        console.log(`Retrying in ${delayMs / 1000}s...`);
        await new Promise((res) => setTimeout(res, delayMs));
      } else {
        throw err;
      }
    }
  }
};
