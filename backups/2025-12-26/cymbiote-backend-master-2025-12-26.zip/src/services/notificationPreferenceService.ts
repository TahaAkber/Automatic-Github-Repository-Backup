import { upsertMerchantNotifPref } from "../models/notificationPreference/notificationPreferenceModel";
import { Preference } from "../types/notifyPerference/notificationPreference";
import { sendErrorEmail } from "./emailService";

export const upsertMerchantNotifPrefService = async (
  userId: number,
  merchantId: number,
  preference: Preference,
  rules?: any[]
) => {
  try {
    return await upsertMerchantNotifPref(userId, merchantId, preference, rules);
  } catch (error: any) {
    sendErrorEmail("Error upserting merchant notification preference:", error);

    const msg = error instanceof Error ? error.message : String(error);
    console.error("Error upserting merchant notification preference:", msg);
    throw new Error("Failed to upsert merchant notification preference");
  }
};
