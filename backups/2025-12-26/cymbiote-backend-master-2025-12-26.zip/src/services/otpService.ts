import { saveOtp, verifyOtp } from "../models/otp/otpModel";
import {
  getUserByEmailOrUsername,
  updateUserVerified
} from "../models/users/user";
import { generateToken } from "./authService";

export const generateOtp = () => {
  return Math.floor(100000 + Math.random() * 900000).toString(); // 6-digit OTP
};

export const saveOtpS = async (identifier: string, otp: string) => {
  // Fetch the user by email
  const user = await getUserByEmailOrUsername(identifier);

  console.log("user generateOtp", user);
  if (!user) {
    throw new Error("User not found.");
  }

  // Save the OTP to the database
  await saveOtp(user.user_id, otp);

  return { message: "OTP saved successfully." };
};

export const verifyOtpS = async (
  email: string,
  otp: string
): Promise<{ isValid: boolean; token: string | undefined }> => {
  // Fetch the user by email
  const user = await getUserByEmailOrUsername(email);

  console.log("verifyOtpS", user);
  if (!user) {
    throw new Error("User not found.");
  }

  // Verify the OTP using the model function
  const isValid = await verifyOtp(user.user_id, otp);

  if (isValid) {
    await updateUserVerified(user.user_id);
  }

  // Generate and return JWT
  const token = generateToken(user);

  return { isValid, token };
};
