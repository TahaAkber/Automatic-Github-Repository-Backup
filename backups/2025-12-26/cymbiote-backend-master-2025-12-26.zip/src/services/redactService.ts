import { unsetShopRefForShopifyOrders } from "../models/orders/dbOrders";
import { getShopByDomain, ShopRepo } from "../models/shops/shopModel";

type CustomersRedactPayload = {
  shop_domain: string;
  orders_to_redact?: Array<number | string>;
};

type ShopRedactPayload = {
  shop_domain: string;
};

export const customersDataRedactService = async (
  payload: CustomersRedactPayload
) => {
  const shop = await getShopByDomain(payload.shop_domain);
  if (!shop) {
    return { found: false };
  }

  const ids = payload.orders_to_redact || [];
  if (ids.length) {
    await unsetShopRefForShopifyOrders(ids);
  }

  return { found: true };
};

export const shopRedactService = async (payload: ShopRedactPayload) => {
  const shop = await ShopRepo.getShopByDomain(payload.shop_domain);
  if (!shop) return { found: false };

  // Remove app data for this shop in one transaction
  await ShopRepo.withTransaction(async (tx) => {
    // Clear auth / tokens first
    await ShopRepo.clearShopAccessToken(tx, shop.shop_id);

    // Optional: mark uninstalled (if you have such a column)
    await ShopRepo.markShopUninstalled(tx, shop.shop_id);

    // App data tied to this shop (adjust to your schema)
    await ShopRepo.deleteProductImages(tx, shop.shop_id);
    await ShopRepo.deleteProductVariants(tx, shop.shop_id);
    await ShopRepo.deleteProducts(tx, shop.shop_id);

    await ShopRepo.deleteSubscriptions(tx, shop.shop_id);
    await ShopRepo.deletePublishingRequests(tx, shop.shop_id);
    await ShopRepo.deleteSessions(tx, shop.shop_id);

    // Add/remove more deletes here as you need (webhooks, jobs, etc.)
  });

  return { found: true };
};
