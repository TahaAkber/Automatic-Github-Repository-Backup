import { deleteWebhookSubscription } from "../graphql/subscription/mutations";
import { getAllWebhookSubscriptions } from "../graphql/subscription/subscriptionQueries";
import { getShopByDomain } from "../models/shops/shopModel";
import { sendErrorEmail } from "./emailService";

export const removeAllSubscription = async (
  domain: string
): Promise<{
  success: boolean;
  message: string;
  removed_webhook_ids?: string[];
}> => {
  try {
    let allWebhookIds: string[] = [];
    const shop = await getShopByDomain(domain);
    if (!shop) {
      return { success: false, message: "shop not found" };
    }

    const subscriptions = await getAllWebhookSubscriptions(
      shop.shop_access_token,
      shop.shop_domain
    );

    if (
      subscriptions?.data &&
      subscriptions.data.webhookSubscriptions.edges.length > 0
    ) {
      console.log(
        "subscriptions.data.webhookSubscriptions.edges",
        subscriptions.data.webhookSubscriptions.edges
      );
      allWebhookIds = subscriptions.data.webhookSubscriptions.edges.map(
        (edge: any) => edge.node.id
      );
    }

    console.log("allWebhookIds", allWebhookIds);

    if (allWebhookIds.length > 0) {
      for (const id of allWebhookIds) {
        await deleteWebhookSubscription(
          id,
          shop.shop_access_token,
          shop.shop_domain
        );
      }
    }

    return {
      success: true,
      message: "All subscriptions removed",
      removed_webhook_ids: allWebhookIds,
    };
  } catch (e: any) {
    sendErrorEmail("shop not found", e);

    return { success: false, message: "shop not found" };
  }
};
