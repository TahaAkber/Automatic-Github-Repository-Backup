import axios from "axios";
import dotenv from "dotenv";
import { Request } from "express";
import { ShopifyOrderResponse } from "../types/shopify_orders/Order";
import { Shop } from "../types/Shop";

import {
  getActiveOrdersByUserId,
  getLatestOrder,
  getNonFulfilledOrders,
  getOrderByOrderId,
  getOrderByOrderIdMob,
  getOrderByUserId,
  getOrderItemByOrderId,
  getPendingOrders,
  getTrackingOrderItemById,
  UpdatePaymentStatus,
  UpdateUsageCharged,
} from "../models/orders/dbOrders";
import { fetchShopifyOrderStatus } from "../graphql/orders/orderQueries";
import {
  createTransaction,
  isTransactionExist,
} from "../models/transactions/dbTransactions";
import {
  checkShopActiveSubscription,
  createUsageCharge,
} from "../graphql/subscription/subscriptionQueries";
import { getShopWithRatingUsingShopId } from "../models/shops/shopModel";
import { createStorefrontToken } from "../graphql/storefront/mutation";
import {
  attachDeliveryAddressesMutation,
  createCartMutation,
} from "../graphql/cart/mutation";
import {
  fetchAvailableCart,
  insertCartInformation,
} from "../models/cart/cartModel";
import { getCurrentCurrencyRate } from "./currencyService";
import { getTrackingByOrderId, getTrackingItemsById } from "./trackingService";
import { getVariantById } from "../models/products/productModel";
import { getOrderItemReviewById } from "../models/reviews/reviewsModel";
import { createDiscountForLineItems } from "./discount";
import { insertDiscountCode } from "../models/discount/discountModel";
import { sendfulfillmentEmail } from "./sendFulfillmentEmail";
import { poolPromise } from "../config/db";
import { sendDuplicateTransactionEmail, sendErrorEmail } from "./emailService";
import {
  getActiveManualTrackingsForOrderList,
  getManualTrackingsForOrderList,
} from "../models/tracking/dbTracking";

dotenv.config();

const API_VERSION = process.env.API_VERSION;
const CURRENCY_RATES_API =
  "https://cdn.jsdelivr.net/npm/@fawazahmed0/currency-api@latest/v1/currencies/usd.json";

export const createShopifyOrder = async (
  req: Request,
  session: Shop[]
): Promise<ShopifyOrderResponse> => {
  const { shop, lineItems, billing_address, shipping_address, discount_codes } =
    req.body;
  // additional condition of below if || !accessTokens[shop]

  const accessToken = session[0].shop_access_token;
  const shopId = session[0].shop_id;
  const packageRate = session[0].package_rate;

  const createOrderUrl = `https://${shop}/admin/api/${API_VERSION}/orders.json`;

  try {
    const orderData = {
      order: {
        line_items: lineItems,
        financial_status: "pending", // authorized, partially_paid, paid, partially_refunded, refunded, voided
        billing_address,
        shipping_address,
        discount_codes,
      },
    };

    const response = await axios.post<ShopifyOrderResponse>(
      createOrderUrl,
      orderData,
      {
        headers: {
          "X-Shopify-Access-Token": accessToken,
          "Content-Type": "application/json",
        },
      }
    );

    const { data } = response;

    // const saveDate = saveOrderDetails(data, shopId, packageRate);

    return data;
  } catch (error: any) {
    sendErrorEmail("Error creating order:", error);

    console.error("Error creating order:", error);
    return {};
  }
};

export const fetchFulfilledOrders = async (shop: string, session: Shop[]) => {
  const url = `https://${shop}/admin/api/${API_VERSION}/orders.json`;

  const accessToken = session[0].shop_access_token;
  const response = await axios.get(url, {
    headers: {
      "X-Shopify-Access-Token": accessToken,
      "Content-Type": "application/json",
    },
    params: {
      // Filter for orders that are either fulfilled or partially fulfilled
      status: "any", // Can also use 'open', 'closed', 'cancelled', etc.
      fields: "id,fulfillment_status", // Specify fields you want to return
    },
  });
};

export const checkAndSendFulfillmentEmail = async () => {
  const nonFulfilledOrders = await getNonFulfilledOrders();
  if (nonFulfilledOrders && nonFulfilledOrders.length > 0) {
    for (const order of nonFulfilledOrders) {
      await sendfulfillmentEmail(order.shop_email, order.order_title);
    }
  }
};

export const checkAndUpdateFulfillment = async () => {
  const pendingOrders = await getPendingOrders();
  // console.log("Current timestamp: ", new Date().toISOString());
  console.log("pendingOrders", pendingOrders);

  for (const order of pendingOrders) {
    const currentUSDRate = await getCurrentCurrencyRate("USD", "PKR");
    console.log("current usd rate", currentUSDRate);
    if (currentUSDRate === 0) {
      throw new Error("Currency API not working correctly");
    }
    const shopifyOrderStatus = await fetchShopifyOrderStatus(
      order.order_shopify_id,
      order.shop_domain,
      order.shop_access_token
    );
    const activeSubscription = await checkShopActiveSubscription(
      order.shop_access_token,
      order.shop_domain
    );

    if (activeSubscription && activeSubscription === "ACTIVE") {
      // console.log("activeSubscription", activeSubscription);
      if (
        shopifyOrderStatus &&
        (shopifyOrderStatus.displayFulfillmentStatus ===
          "PARTIALLY_FULFILLED" ||
          shopifyOrderStatus.displayFulfillmentStatus === "FULFILLED")
      ) {
        console.log("updating order_payment_status");
        const result = await UpdatePaymentStatus(
          (order.order_id as number).toString(),
          order.order_shop_id.toString(),
          shopifyOrderStatus?.displayFinancialStatus?.toLowerCase() || "unknown"
        );
        console.log("result", result);
        const updatedOrder = await UpdateUsageCharged(
          (order.order_id as number).toString(),
          order.order_shop_id.toString(),
          true //order is charged
        );
        console.log("updatedOrder", updatedOrder);

        const transactionAmount =
          shopifyOrderStatus.totalPriceSet.shopMoney.amount *
          (order.order_charge_rate / 100);

        const convertedAmt = transactionAmount / currentUSDRate; // current USD to PKR rate

        const transactionDetail =
          "Transaction for order " + order.order_title?.toString();

        const transactionExist = await isTransactionExist(
          order.order_shop_id,
          transactionDetail
        );

        if (transactionExist) {
          await sendDuplicateTransactionEmail(
            order.order_shop_id,
            transactionDetail
          );
        } else {
          console.log(
            "convertedAmt",
            convertedAmt,
            "transactionAmount",
            transactionAmount
          );
          const transactionCreated = await createTransaction(
            order.order_shop_id,
            transactionAmount,
            convertedAmt,
            "usage",
            order.order_id ? transactionDetail : "",
            order.order_id ? order.order_id : 0,
            order.subscription_id,
            order.shop_currency
          );

          await createUsageCharge(
            order.subscription_appUsagePricingDetails_id,
            `Transaction fee for Order ${order.order_title} on Charge rate ${order.order_charge_rate}%`,
            {
              amount: convertedAmt,
              currencyCode: "USD",
            },
            order.shop_domain,
            order.shop_access_token
          );
        }
      }
    }
  }
};

export const createStorefrontOrderS = async (session: any) => {
  if (!session.length) {
    throw new Error("Shop not found with the provided shop domain.");
  }

  console.log("session got", session);

  const storefrontToken = await createStorefrontToken(session);
  return storefrontToken;
};

export const createCart = async (
  session: any,
  storefrontAccessToken: string,
  shopDomain: string,
  customCartId: string,
  { lineItems, addresses, email, phone, voucherCode, cercleUserId }: any
) => {
  const accessToken = session[0].shop_access_token;
  if (!accessToken) {
    return [];
  }

  const userDiscountCode = voucherCode ? [voucherCode] : [];

  // 🟢 1) Line-item level discounts ban rahe hain (pura as-is)
  const discountCodes = await createDiscountForLineItems(
    lineItems,
    accessToken,
    shopDomain
  );

  // 🟢 2) Cart attributes banayenge – yahan cercle_user_id inject hoga
  const attributes: { key: string; value: string }[] = [];

  if (
    cercleUserId !== undefined &&
    cercleUserId !== null &&
    !Number.isNaN(Number(cercleUserId)) &&
    Number(cercleUserId) > 0
  ) {
    attributes.push({
      key: "cercle_user_id",
      value: String(cercleUserId),
    });
  }

  // 🟢 3) Cart create input (Shopify Storefront cartCreate)
  const input: any = {
    lines: lineItems.map((item: any) => ({
      merchandiseId: item.variant_id,
      quantity: item.quantity,
    })),
    buyerIdentity: {
      email,
      phone,
    },
    discountCodes: [
      ...discountCodes.map((discountNode) => discountNode?.code),
      ...userDiscountCode,
    ],
  };

  // sirf tab attributes bhejo jab kuch actual attribute ho
  if (attributes.length > 0) {
    input.attributes = attributes;
  }

  try {
    const totalQuantity = input.lines.reduce(
      (acc: number, item: any) => acc + item.quantity,
      0
    );

    console.log("totalQuantity", totalQuantity);
    console.log("createCart cercleUserId:", cercleUserId);
    console.log("createCart attributes:", attributes);

    const availableCart = await fetchAvailableCart(customCartId);

    if (availableCart && availableCart.cart_items_quantity === totalQuantity) {
      console.log("Cart already exists:", availableCart);
      return {
        success: true,
        cartId: availableCart.cart_shopify_id,
        checkoutUrl: availableCart.cart_url,
      };
    }

    // 1️⃣ Cart create karo (ab attributes bhi jaa rahe hain)
    const createCartResponse = await createCartMutation(
      storefrontAccessToken,
      shopDomain,
      input
    );

    // 2️⃣ Cart ID nikaalo
    const cartId = createCartResponse?.id;
    if (!cartId) {
      throw new Error("Cart ID not found in the response");
    }

    console.log("New Cart ID:", cartId);

    // 3️⃣ Delivery addresses attach karo
    const addressInput = {
      cartId,
      addresses,
    };

    await attachDeliveryAddressesMutation(
      storefrontAccessToken,
      shopDomain,
      addressInput
    );

    // 4️⃣ Cart info DB mein save karo
    await insertCartInformation(
      customCartId,
      cartId,
      createCartResponse.checkoutUrl,
      email,
      totalQuantity
    );

    // 5️⃣ Discount codes DB mein save karo
    if (discountCodes.length > 0) {
      discountCodes.forEach((discount) => {
        insertDiscountCode(
          discount?.code as string,
          customCartId,
          discount?.id as string,
          discount?.codeDiscount.endsAt as Date,
          discount?.codeDiscount.startsAt as Date
        );
      });
    }

    return {
      success: true,
      cartId,
      checkoutUrl: createCartResponse?.checkoutUrl,
    };
  } catch (error: any) {
    sendErrorEmail("Error in createCart:", error);
    console.error("Error in createCart:", error.message);
    return {
      success: false,
      message: "Failed to create cart",
      error: error.message || "Unknown error",
    };
  }
};

export const fetchOrders = async (
  userId: number,
  page: number,
  pageSize: number,
  status?: any
) => {
  // Fetch regular orders
  const fetchUserOrders = await getOrderByUserId(
    userId,
    page,
    pageSize,
    status
  );

  // Fetch manual trackings
  const manualTrackings = await getManualTrackingsForOrderList(userId);

  // Process orders
  const processedOrders = await Promise.all(
    fetchUserOrders.map(async (item: any) => {
      const orderVaraints = await getVariantById(item.order_item_variant_id);
      if (item.id) {
        const trackingItems = await getTrackingItemsById(item.id);
        let modifiedItems: any = trackingItems;
        if (item.tracking_status === "DELIVERED") {
          modifiedItems = await Promise.all(
            trackingItems.map(async (trackingItem: any) => {
              const [orderVariants, review_item] = await Promise.all([
                getVariantById(trackingItem.order_item_variant_id),
                getOrderItemReviewById(trackingItem.tracking_order_item_id),
              ]);

              return {
                ...trackingItem,
                ...orderVariants,
                review_item,
                review_completed: Boolean(review_item),
              };
            })
          );
        }
        item.order_item = modifiedItems;
      } else {
        const orderItem = await getOrderItemByOrderId(item.order_id, true);
        item.order_item = orderItem;
      }
      return {
        ...item,
        type: "order", // Add type field
        product_detail: orderVaraints,
      };
    })
  );

  // Format manual trackings to match order structure
  const formattedTrackings = manualTrackings.map((tracking: any) => ({
    type: "tracking",
    manual_tracking_id: tracking.manual_tracking_id,
    manual_tracking_user_id: tracking.manual_tracking_user_id,
    manual_tracking_name: tracking.manual_tracking_name,
    manual_tracking_number: tracking.manual_tracking_number,
    manual_tracking_status: tracking.manual_tracking_status,
    manual_courier_id: tracking.courier_id,
    manual_courier_name: tracking.courier_name,
    manual_courier_url: tracking.courier_url,
    manual_courier_image_url: tracking.courier_image_url,
    manual_tracking_payload: tracking.manual_tracking_payload
      ? JSON.parse(tracking.manual_tracking_payload)
      : null,
    created_at: tracking.created_at,
    updated_at: tracking.updated_at,
  }));

  // Merge orders and trackings
  const combinedData = [...processedOrders, ...formattedTrackings];

  // Sort by created_at DESC
  combinedData.sort((a, b) => {
    const dateA = new Date(a.created_at).getTime();
    const dateB = new Date(b.created_at).getTime();
    return dateB - dateA;
  });

  // Apply pagination to combined result
  const startIndex = (page - 1) * pageSize;
  const endIndex = startIndex + pageSize;
  const paginatedData = combinedData.slice(startIndex, endIndex);

  return paginatedData;
};

export const getOrderDate = async (userId: number) => {
  const pool = await poolPromise;
  try {
    const query = `SELECT created_at
        FROM Orders
        WHERE order_user_id = @userId`;
    const result = await pool.request().input("userId", userId).query(query);
    return result.recordset.map((row: any) => row.created_at);
  } catch (error: any) {
    sendErrorEmail("Error fetching order dates:", error);

    console.error("Error fetching order dates:", error);
    throw new Error("Failed to fetch order dates");
  }
};

export const fetchActiveOrders = async (
  userId: number,
  page?: number,
  pageSize?: number
) => {
  // Fetch active orders
  const fetchUserOrders = await getActiveOrdersByUserId(userId, page, pageSize);

  // Group orders by tracking number
  const ordersByTrackingNumber = new Map();

  fetchUserOrders.forEach((order: any) => {
    const trackingNumber = order.tracking_number;
    if (!ordersByTrackingNumber.has(trackingNumber)) {
      ordersByTrackingNumber.set(trackingNumber, []);
    }
    ordersByTrackingNumber.get(trackingNumber).push(order);
  });

  const processedOrders = await Promise.all(
    Array.from(ordersByTrackingNumber.entries()).map(
      async ([trackingNumber, orders]: [string, any[]]) => {
        const baseOrder = orders[0];

        const orderVariants = await getVariantById(
          baseOrder.order_item_variant_id
        );

        let allOrderItems: any[] = [];

        if (baseOrder.id) {
          const trackingItems = await getTrackingItemsById(baseOrder.id);

          if (
            baseOrder.tracking_status === "IN_TRANSIT" ||
            baseOrder.tracking_status === "IN_PROGRESS" ||
            baseOrder.tracking_status === "OUT_FOR_DELIVERY"
          ) {
            allOrderItems = await Promise.all(
              trackingItems.map(async (trackingItem: any) => {
                const [orderVariants, review_item] = await Promise.all([
                  getVariantById(trackingItem.order_item_variant_id),
                  getOrderItemReviewById(trackingItem.tracking_order_item_id),
                ]);

                return {
                  ...trackingItem,
                  ...orderVariants,
                  review_item,
                  review_completed: Boolean(review_item),
                };
              })
            );
          } else {
            allOrderItems = trackingItems;
          }
        } else {
          const orderItemsPromises = orders.map((order) =>
            getOrderItemByOrderId(order.order_id, true)
          );
          const orderItemsArrays = await Promise.all(orderItemsPromises);
          allOrderItems = orderItemsArrays.flat();
        }

        const uniqueOrderItems = allOrderItems.filter((item, index, array) => {
          const orderItemId = item.order_item_id || item.tracking_order_item_id;
          return (
            array.findIndex(
              (i) =>
                (i.order_item_id || i.tracking_order_item_id) === orderItemId
            ) === index
          );
        });

        return {
          ...baseOrder,
          type: "order", // Add type field
          product_detail: orderVariants,
          order_item: uniqueOrderItems,
        };
      }
    )
  );

  // Fetch active manual trackings
  const manualTrackings = await getActiveManualTrackingsForOrderList(userId);

  // Format manual trackings
  const formattedTrackings = manualTrackings.map((tracking: any) => ({
    type: "tracking",
    manual_tracking_id: tracking.manual_tracking_id,
    manual_tracking_user_id: tracking.manual_tracking_user_id,
    manual_tracking_name: tracking.manual_tracking_name,
    manual_tracking_number: tracking.manual_tracking_number,
    manual_tracking_status: tracking.manual_tracking_status,
    manual_courier_id: tracking.courier_id,
    manual_courier_name: tracking.courier_name,
    manual_courier_url: tracking.courier_url,
    manual_courier_image_url: tracking.courier_image_url,
    manual_tracking_payload: tracking.manual_tracking_payload
      ? JSON.parse(tracking.manual_tracking_payload)
      : null,
    created_at: tracking.created_at,
    updated_at: tracking.updated_at,
  }));

  // Merge orders and trackings
  const combinedData = [...processedOrders, ...formattedTrackings];

  // Sort by created_at DESC
  combinedData.sort((a, b) => {
    const dateA = new Date(a.created_at).getTime();
    const dateB = new Date(b.created_at).getTime();
    return dateB - dateA;
  });

  return combinedData;
};

export const fetchOrderDetailsUsingOrderId = async (
  order_id: number,
  tracking_id?: number,
  mobile_app?: boolean
) => {
  let order;
  if (mobile_app) {
    order = await getOrderByOrderIdMob(order_id, tracking_id);
  } else {
    order = await getOrderByOrderId(order_id);
  }
  return order;
};

export const fetchServiceLatestOrder = async (
  user_id: number,
  shop_id: number
) => {
  let order = await getLatestOrder(user_id, shop_id);
  return order;
};
