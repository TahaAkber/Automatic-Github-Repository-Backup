import dotenv from "dotenv";
import {
  getUserIntrest,
  insertUserIntrest,
  shopCategoryList,
  shopSubCategoryList,
} from "../models/intrest/intrest";
import { sendErrorEmail } from "./emailService";

dotenv.config();

export const intrestList = async (): Promise<any> => {
  try {
    const response = await shopCategoryList();
    return { status: 200, message: "Success", data: response };
  } catch (error: any) {
    sendErrorEmail("Error fetching intrest list: ", error);

    throw new Error("Error fetching intrest list: " + error.message);
  }
};

export const subCategoryList = async (
  store_category_id: number
): Promise<any> => {
  try {
    const response = await shopSubCategoryList(store_category_id);
    return { status: 200, message: "Success", data: response };
  } catch (error: any) {
    sendErrorEmail("Error fetching intrest list: ", error);

    throw new Error("Error fetching intrest list: " + error.message);
  }
};

export const createUserIntrest = async (user_intrest: any): Promise<any> => {
  try {
    const response = await insertUserIntrest(user_intrest);
    return response;
  } catch (error: any) {
    sendErrorEmail("Error creating user intrest: ", error);

    throw new Error("Error creating user intrest: " + error.message);
  }
};

export const userIntrestList = async (user_id: number): Promise<any> => {
  try {
    const response = await getUserIntrest(user_id);
    return response;
  } catch (error: any) {
    sendErrorEmail("Error creating user intrest: ", error);

    throw new Error("Error creating user intrest: " + error.message);
  }
};
