import { getShopFollowingStatus } from "../functions/shop";
import { getProductTaxonomyForCategoryList } from "../graphql/product/productQueries";
import { getShopReviews } from "../models/reviews/reviewsModel";
import {
  checkIfAllShopsAreShown,
  fetchCollectionDataById,
  fetchCollectionProductCategories,
  fetchCollections,
  fetchFilterCollectionProductCategories,
  fetchFilteredCollectionDataById,
  fetchTrendingCollectionById,
  fetchTrendingCollections,
  getAllActiveShopsWithPagination,
  getRandomShopCreds,
  getShopFilter,
  getShopsCount,
  searchShopsCount,
  searchShopsFromDB,
} from "../models/shops/shopModel";
import { sendErrorEmail } from "./emailService";
import { fetchTileProducts } from "./productService";

// Fetch all active shops from the database
export const fetchAllShops = async (
  pageSize = 10,
  userId?: number,
  categories?: string,
  shownShopIds = ""
) => {
  try {
    // Fetch shops based on pagination and the onlyShops flag
    const { finalResult: shops, shownShopIds: updatedShopIds } =
      await getAllActiveShopsWithPagination(pageSize, categories, shownShopIds);

    // Fetch total number of shops to calculate total pages
    const totalShops = await getShopsCount();

    const totalPages = totalShops > 0 ? Math.ceil(totalShops / pageSize) : 0;

    if (totalShops === undefined) {
      console.log("Total shops count is 0 or undefined. Check the query.");
    }

    // Split the comma-separated `updatedShopIds` string into an array
    const updatedShopIdsArray = updatedShopIds
      .split(",")
      .map((id) => Number(id));

    const unmatchedCount = await checkIfAllShopsAreShown(updatedShopIdsArray);

    const allShopsShown = unmatchedCount === 0; // If unmatchedCount is 0, it means all items are already shown

    const modifiedShopResponse = await Promise.all(
      shops.map(async (item) => {
        const filters = await getShopFilter(item.shop_id);
        const { rating, total_reviews } = await getShopReviews(item.shop_id);

        item.filters = filters;
        item.total_reviews = total_reviews;
        item.rating = rating;
        try {
          // Fetch products for the current shop
          const products = await fetchTileProducts(
            item.shop_id,
            item.shop_tile_type == 2 ? 4 : 5
          );
          const followStatus = await getShopFollowingStatus(
            item.shop_id,
            userId
          );
          // Map through the products and process the variants with images
          const productVariantsWithImages = await Promise.all(
            products.map(async (product) => {
              const variants = await Promise.all(
                product.product_variant.map(async (variant: any) => {
                  return {
                    ...variant,
                  };
                })
              );
              return { ...product, product_variant: variants };
            })
          );

          // Flatten the nested arrays and return the modified shop object
          return {
            ...item,
            shop_following: followStatus,
            products: productVariantsWithImages.flat(2), // Flatten up to two levels
          };
        } catch (error: any) {
          console.error(
            `Error processing shop with ID ${item.shop_id}:`,
            error
          );
          return {
            ...item,
            shop_following: false,
            products: [], // Return an empty products array in case of error
          };
        }
      })
    );

    return {
      shops: modifiedShopResponse,
      updatedShopIds,
      totalShops,
      totalPages,
      pageSize,
      repeatCheck: allShopsShown,
    };
  } catch (error: any) {
    sendErrorEmail("Error with shops pagination", error);

    console.log("Error with shops pagination", error.message);
    throw new Error("Error fetching active shops with pagination");
  }
};

export const searchShopsS = async (
  searchTerm: string,
  page: number,
  pageSize: number
) => {
  try {
    const shops = await searchShopsFromDB(searchTerm, page || 1, pageSize || 3);

    const shopsCount = await searchShopsCount(searchTerm);

    const totalPages = Math.ceil(shopsCount / pageSize);

    return { shops, shopsCount, page, pageSize, totalPages };
  } catch (error: any) {
    sendErrorEmail("error in search shop", error);

    throw new Error(error.message);
  }
};

export const fetchTaxonomyCategories = async (id: string) => {
  const randomShop = await getRandomShopCreds();

  if (!randomShop) {
    throw new Error("no shop found");
  }

  const taxonomies = await getProductTaxonomyForCategoryList(
    randomShop.shop_domain,
    randomShop.shop_access_token,
    id as string
  );

  return taxonomies;
};

export const fetchCollectionsbyId = async (id: any, collectionType: string) => {
  try {
    const collections = await fetchCollections(id, collectionType);
    const collectionProductCategories = await fetchCollectionProductCategories(
      id,
      collectionType
    );
    console.log(
      "collections service",
      collections,
      collectionProductCategories
    );
    return { data: collections, collectionProductCategories };
  } catch (error: any) {
    sendErrorEmail("Error with  collections", error);

    console.log("Error with  collections", error.message);
    throw new Error("Error fetching collections");
  }
};

export const fetchAllTrendingCollections = async () => {
  try {
    const collections = await fetchTrendingCollections();
    // console.log("trending collections service", collections);
    return collections;
  } catch (error: any) {
    sendErrorEmail("Error with  collections", error);

    console.log("Error with  collections", error.message);
    throw new Error("Error fetching collections");
  }
};

export const getPaginatedActiveShops = async (
  categoryIds: string,
  page: number,
  pageSize: number
) => {
  try {
    const shops = await getAllActiveShopsWithPagination(
      pageSize,
      categoryIds,
      ""
    );

    return shops;
  } catch (error: any) {
    sendErrorEmail("active shop service ", error);

    throw new Error("active shop service " + error.message);
  }
};

export const getTrendingCollectionByIdService = async (
  collectionId: string,
  sortBy?: string[], // Accepting an array for multiple sorting fields
  sortOrder?: string[], // Accepting an array for multiple sorting orders
  minPrice?: number,
  maxPrice?: number,
  colors?: string[],
  minRating?: number,
  onSale?: boolean,
  sizes?: string[], // Accept an array of size values (e.g., ['S', 'M', 'L'])
  sortPrice?: "ASC" | "DESC",
  page: number = 1,
  pageSize: number = 10
) => {
  try {
    // Call the actual service function that fetches the data
    const collectionData = await fetchTrendingCollectionById(
      collectionId,
      sortBy,
      sortOrder,
      minPrice,
      maxPrice,
      colors,
      minRating,
      onSale,
      sizes,
      sortPrice,
      page,
      pageSize
    );

    const productCategories = await fetchCollectionProductCategories(
      collectionId
    );

    return { collectionData: collectionData, productCategories };
  } catch (error: any) {
    sendErrorEmail("Error in service: ", error);

    throw new Error("Error in service: " + error.message);
  }
};
export const getCollectionByIdService = async (
  collectionId: string,
  collection_shop_id?: string,
  collection_type_id?: string,
  sortBy?: string[],
  sortOrder?: string[],
  minPrice?: number,
  maxPrice?: number,
  colors?: string[],
  minRating?: number,
  onSale?: boolean,
  sizes?: string[], // Accept an array of size values (e.g., ['S', 'M', 'L'])
  sortPrice?: "ASC" | "DESC", // Accept a string for sorting price
  page: number = 1,
  pageSize: number = 10
) => {
  try {
    // Call the actual service function that fetches the data
    const collectionData = await fetchCollectionDataById(
      collectionId,
      sortBy,
      sortOrder,
      minPrice,
      maxPrice,
      colors,
      minRating,
      onSale,
      sizes,
      sortPrice,
      page,
      pageSize
    );

    const collectionProductCategories = await fetchCollectionProductCategories(
      collection_shop_id,
      collection_type_id
    );

    return { collectionData, collectionProductCategories };
  } catch (error: any) {
    sendErrorEmail("Error in service: ", error);

    throw new Error("Error in service: " + error.message);
  }
};

export const getFilteredCollectionByIdService = async (
  collectionId: string,

  page: number = 1,
  pageSize: number = 10
) => {
  try {
    // Call the actual service function that fetches the data
    const collectionData = await fetchFilteredCollectionDataById(
      collectionId,
      page,
      pageSize
    );
    const productCategories = await fetchFilterCollectionProductCategories(
      collectionId
    );

    return { collectionData: collectionData, productCategories };
  } catch (error: any) {
    sendErrorEmail("Error in service: ", error);

    throw new Error("Error in service: " + error.message);
  }
};
