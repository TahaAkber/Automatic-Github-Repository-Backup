import {
  createNotification,
  getAppNotificationsByUserIdModel,
  getAppNotificationsModel,
  getFcmTokens,
  getNotifications,
  getShopByCollectionShopifyId,
  getuserNotificationdb,
  readNotificationByIdModel,
  removeNotification,
  saveNotification,
  updateNotificationSetting,
} from "../models/notifications/notificationModel";
import admin from "../firebase/firebase";
import { getShopFollowers } from "../models/shops/shopModel";
import { checkShopPreferenceForEvent } from "../functions/notificationSettings";
import {
  MessageData,
  NewProductVariant,
  Product,
} from "../types/notification/Notification";
import { sendErrorEmail } from "./emailService";

export const getNotificationService = async () => {
  try {
    const notifications = await getNotifications();
    return notifications;
  } catch (error: any) {
    sendErrorEmail("Error getting notification:", error);

    console.error("Error getting notification:", error.message);
    throw new Error("Failed to fetch notification");
  }
};
export const createNotificationService = async (userId: string) => {
  try {
    await createNotification(userId);
  } catch (error: any) {
    sendErrorEmail("Error creating notification:", error);

    console.error("Error creating notification:", error.message);
    throw new Error("Failed to create notification");
  }
};

export const createAppNotificationsService = async (
  userId: string | null | number,
  data: any
) => {
  try {
    await saveNotification(userId, data);
  } catch (error: any) {
    sendErrorEmail("Error creating notification:", error);

    console.error("Error creating notification:", error.message);
    throw new Error("Failed to create notification");
  }
};

export const getUserNotification = async (userId: string) => {
  try {
    const notifications = await getuserNotificationdb(userId);
    return notifications;
  } catch (error: any) {
    sendErrorEmail("Error getting notification:", error);

    console.error("Error getting notification:", error.message);
    throw new Error("Failed to fetch notification");
  }
};
export const updateNotificationSettingService = async (
  userId: string,
  notificationSettings: Record<string, boolean>
) => {
  try {
    const { success, message } = await updateNotificationSetting(
      userId,
      notificationSettings
    );
    return { success, message };
  } catch (error: any) {
    sendErrorEmail("Error updating notification settings:", error);

    console.error("Error updating notification settings:", error.message);
    throw new Error("Failed to update notification settings");
  }
};

export const getAppNotificationsService = async (
  page: number,
  pageSize: number
) => {
  try {
    const notifications = await getAppNotificationsModel(page, pageSize);
    return notifications;
  } catch (error: any) {
    sendErrorEmail("Error getting notification:", error);

    console.error("Error getting notification:", error.message);
    throw new Error("Failed to fetch notification");
  }
};

export const getAppNotificationByUserIdService = async (
  page: number,
  pageSize: number,
  userId: string
) => {
  try {
    const notifications = await getAppNotificationsByUserIdModel(
      page,
      pageSize,
      userId
    );
    return notifications;
  } catch (error: any) {
    sendErrorEmail("Error getting notification:", error);

    console.error("Error getting notification:", error.message);
    throw new Error("Failed to fetch notification");
  }
};

export const readNotification = async (notification_id: number) => {
  try {
    await readNotificationByIdModel(notification_id);
    return 1;
  } catch (error: any) {
    sendErrorEmail("Error getting notification:", error);

    console.error("Error getting notification:", error.message);
    throw new Error("Failed to fetch notification");
  }
};

export const sendFCMNotification = async (
  deviceTokens: string[] | string | null,
  MessageData: any
) => {
  const notification = {
    title: MessageData.title,
    body: MessageData.body,
    image: MessageData?.image || null,
  };

  const dataPayload = {
    screenName: MessageData.screenName || "",
    orderId: MessageData.orderId || "",
    productId: MessageData.productId || "",
    variantId: MessageData.variantId || "",
    notificationImageUrl: MessageData.notificationImageUrl || "",
    payload: JSON.stringify(MessageData.payload || {}),
  };

  try {
    if (MessageData.type === "all") {
      const topicMessage = {
        topic: "all",
        notification,
        data: dataPayload,
      };

      const response = await admin.messaging().send(topicMessage);

      return {
        successCount: 1,
        failureCount: 0,
        responses: [{ status: "fulfilled", value: response }],
      };
    }

    if (Array.isArray(deviceTokens)) {
      const responses = await Promise.allSettled(
        deviceTokens.map((token) =>
          admin.messaging().send({
            token,
            notification,
            data: dataPayload,
          })
        )
      );

      const success = responses.filter((r) => r.status === "fulfilled");
      const failed = responses.filter((r) => r.status === "rejected");

      return {
        successCount: success.length,
        failureCount: failed.length,
        responses,
      };
    }
  } catch (err: any) {
    sendErrorEmail("FCM send error:", err);

    console.error("FCM send error:", err);
    throw err;
  }
};

type ShopifyCollectionPayload = {
  title: string;
  body_html?: string;
  image?: { src?: string };
  admin_graphql_api_id: string;
  __dbCollectionRow?: any;
};
const COLLECTION_RULES = ["NEW_COLLECTION_ADDED"];

export const sendCollectionNotificationService = async (
  payload: ShopifyCollectionPayload
) => {
  try {
    const { title, body_html, image, admin_graphql_api_id, __dbCollectionRow } =
      payload;

    const Collection =
      __dbCollectionRow ??
      (await getShopByCollectionShopifyId(admin_graphql_api_id));

    if (!Collection) {
      throw new Error(`Collection not found for ${admin_graphql_api_id}`);
    }

    const niceTitle = `Introducing a New Collection: ${title} — Tap to Explore`;
    const bodyPlain =
      (body_html ?? "")
        .replace(/<[^>]*>/g, " ")
        .replace(/\s+/g, " ")
        .trim() || "Check out what’s new.";
    const imageUrl = image?.src || "";

    const screenByType =
      Collection.collection_type_name === "Simple Collection"
        ? "SimpleCollection"
        : Collection.collection_type_name === "Trending Collection"
        ? "TrendingCollection"
        : Collection.collection_type_name === "Filter Collection"
        ? "FilterCollection"
        : "SimpleCollection";

    const typedPayload =
      screenByType === "SimpleCollection"
        ? {
            status: "Collection Created",
            simpleId: Collection.collection_id,
            simpleName: Collection.collection_name,
            simpleBannerUrl: Collection.collection_banner_url,
          }
        : screenByType === "TrendingCollection"
        ? {
            status: "Collection Created",
            trendingId: Collection.collection_id,
            trendingName: Collection.collection_name,
            trendingBannerUrl: Collection.collection_banner_url,
          }
        : {
            status: "Collection Created",
            filterId: Collection.collection_id,
            filterName: Collection.collection_name,
            filterBannerUrl: Collection.collection_banner_url,
          };

    // === Trending Collection → broadcast to ALL ===
    if (Collection.collection_type_name === "Trending Collection") {
      const MessageData = {
        title: niceTitle,
        body: bodyPlain,
        image: imageUrl,
        screenName: "TrendingCollection",
        notificationImageUrl: Collection.shop_logo_url || "",
        type: "all",
        payload: JSON.stringify(typedPayload),
      };

      await sendFCMNotification(null, MessageData);
      await createAppNotificationsService(null, MessageData);
      return;
    }

    const followers = (await getShopFollowers(Collection.shop_id)) ?? [];
    if (!followers.length) return;

    for (const userId of followers) {
      try {
        const pref = await checkShopPreferenceForEvent(
          Collection.shop_id,
          userId,
          [...COLLECTION_RULES]
        );
        if (!pref.allowed) continue;

        const fcmTokens = await getFcmTokens(String(userId));
        if (!fcmTokens?.length) continue;

        const MessageData = {
          title: niceTitle,
          body: bodyPlain,
          DeviceToken: JSON.stringify(fcmTokens),
          screenName: screenByType,
          productId: "",
          variantId: "",
          notificationImageUrl: Collection.shop_logo_url || "",
          image: imageUrl,
          type: "token",
          payload: JSON.stringify(typedPayload),
        };

        await createAppNotificationsService(userId, MessageData);
        await sendFCMNotification(fcmTokens, MessageData);
      } catch (innerErr) {
        console.error(`Collection notify error for user ${userId}:`, innerErr);
      }
    }
  } catch (error: any) {
    sendErrorEmail("Error sending collection notification:", error);

    console.error(
      "Error sending collection notification:",
      error?.message ?? error
    );
    throw new Error("Failed to send collection notification");
  }
};

export const checkAndRemoveNotifications = async () => {
  try {
    const now = new Date();
    const oneMonthAgo = new Date(now.setMonth(now.getMonth() - 1));
    const result = await removeNotification(oneMonthAgo);
    return result;
  } catch (error: any) {
    sendErrorEmail("Error checking and removing notifications:", error);

    console.error("Error checking and removing notifications:", error);
  }
};

function extractPrimaryVariantId(
  product_variant?: NewProductVariant | NewProductVariant[] | null
): string {
  if (!product_variant) return "";
  const first =
    Array.isArray(product_variant) && product_variant.length
      ? product_variant[0]
      : !Array.isArray(product_variant)
      ? product_variant
      : undefined;

  if (!first) return "";
  const raw =
    (first as any)._id ??
    (first as any).admin_graphql_api_id ??
    (first as any).id;
  return raw != null ? String(raw) : "";
}

const PRODUCT_RULES = ["NEW_ARRIVAL_ALERT"];
export const sendProductNotificationService = async (
  payload: Product
): Promise<void> => {
  try {
    const {
      product_id,
      product_name,
      product_variant,
      product_shop_id,
      product_shopify_id,
      product_custom_category,
      product_description,
      product_image_url,
    } = payload;

    if (!product_id || !product_shopify_id) {
      throw new Error(`Invalid product payload: missing IDs`);
    }

    const niceTitle = `New Product: ${product_name} — Tap to View`;
    const bodyPlain = product_description || "Check out what's new.";

    const imageUrl = product_image_url ?? "";
    const screenName = "ProductDetail";

    const primaryVariantId = extractPrimaryVariantId(product_variant);

    const typedPayload = {
      status: "Product Created",
      productId: product_id,
      productSlug: product_custom_category ?? "",
      variantId: primaryVariantId,
    };

    const followers = (await getShopFollowers(product_shop_id)) ?? [];
    if (!followers.length) return;

    for (const userId of followers) {
      try {
        const pref = await checkShopPreferenceForEvent(
          product_shop_id,
          userId,
          [...PRODUCT_RULES]
        );
        if (!pref?.allowed) continue;

        const fcmTokens = await getFcmTokens(String(userId));
        if (!fcmTokens?.length) continue;

        const messageData: MessageData = {
          title: niceTitle,
          body: bodyPlain,
          DeviceToken: JSON.stringify(fcmTokens),
          screenName,
          productId: String(product_id),
          variantId: primaryVariantId,
          notificationImageUrl: imageUrl,
          image: imageUrl,
          type: "token",
          payload: JSON.stringify(typedPayload),
        };

        await createAppNotificationsService(userId, messageData);
        await sendFCMNotification(fcmTokens, messageData);
      } catch (innerErr) {
        console.error(
          `Product notify error for user ${String(userId)}:`,
          innerErr
        );
      }
    }
  } catch (error: unknown) {
    const errMsg =
      error instanceof Error
        ? error.message
        : typeof error === "string"
        ? error
        : "Unknown error";
    console.error("Error sending product notification:", errMsg);
    throw new Error("Failed to send product notification");
  }
};
