import {
  getBarqRaftarTracking,
  getDhlTracking,
  getTcsTracking,
  normalizeTCSStatus,
  parseBarqRaftarResponse,
  parseDHLResponse,
  parseTCSResponse,
  getBlueExTracking,
  parseBlueExResponse,
  normalizeBlueExStatus,
  getFlyCourierTracking,
  parseFlyCourierResponse,
  normalizeFlyCourierStatus,
} from "../functions/courierTrackings";
import {
  getActiveCouriersFromDB,
  getTrackingCouriers,
  insertManualTracking,
} from "../models/tracking/dbTracking";

export const courierDHLTrackings = async (
  userId: number,
  trackingName: string,
  trackingNumber: string
): Promise<any> => {
  try {
    const result = await getDhlTracking(trackingNumber);

    if (result.status === 200) {
      const parsed = parseDHLResponse(result.data);

      // Check if parsing was successful and we got valid tracking data
      if (!parsed || !parsed.number) {
        return {
          message: `No tracking found on DHL with tracking number: ${trackingNumber}`,
          custom_tracking_id: null,
          status: 404,
        };
      }

      const courier = await getTrackingCouriers(1);

      if (courier.length === 0) {
        return {
          message: "No courier found in the system.",
          custom_tracking_id: null,
          status: 500,
        };
      }

      const tracking_id = await insertManualTracking(
        userId,
        trackingName,
        parsed?.number as string,
        parsed?.track_info.latest_event?.description,
        courier?.courier_url || "",
        (parsed as object) || {},
        courier?.courier_id
      );

      return {
        message: "Tracking data fetched successfully.",
        custom_tracking_id: tracking_id,
        status: 200,
      };
    }

    if (result.status === 404 && result.message) {
      return {
        message: result.message,
        custom_tracking_id: null,
        status: 404,
      };
    }

    return {
      message: "No tracking information found.",
      custom_tracking_id: null,
      status: 404,
    };
  } catch (error: any) {
    if (error.response && error.response.data) {
      return {
        message:
          error.response.data.detail ||
          error.response.data.title ||
          error.message ||
          "Courier DHL tracking failed.",
        custom_tracking_id: null,
        status: error.response.status || 500,
      };
    }

    throw new Error(error.message || "Courier tracking failed.");
  }
};

// Barq Raftar → service
export const courierBarqRaftarTrackings = async (
  userId: number,
  trackingName: string,
  trackingNumber: string
): Promise<any> => {
  console.log(
    "courierBarqRaftarTrackings",
    userId,
    trackingName,
    trackingNumber
  );

  try {
    const result = await getBarqRaftarTracking(trackingNumber);

    if (result.status === 200) {
      const parsed = parseBarqRaftarResponse(result.data);

      // Check if parsing was successful and we got valid tracking data
      if (!parsed || !parsed.number) {
        return {
          message: `No tracking found on Barq Raftar with tracking number: ${trackingNumber}`,
          custom_tracking_id: null,
          status: 404,
        };
      }

      // Get Barq Raftar courier row (adjust the lookup as per your system)
      // If you index by ID, replace `getTrackingCouriers( /* barq_id */ )`
      // Otherwise prefer a "by name" helper if you have it:
      // const courier = await getTrackingCouriersByName("Barq Raftar");
      const courier = await getTrackingCouriers(3);

      if (!courier || courier.length === 0) {
        return {
          message: "No courier found in the system.",
          custom_tracking_id: null,
          status: 500,
        };
      }

      const tracking_id = await insertManualTracking(
        userId,
        trackingName,
        parsed?.number as string,
        parsed?.track_info?.latest_event?.description ||
          parsed?.track_info?.status ||
          "",
        courier?.courier_url || "",
        (parsed as object) || {},
        courier?.courier_id
      );

      return {
        message: "Tracking data fetched successfully.",
        custom_tracking_id: tracking_id,
        status: 200,
      };
    }

    if (result.status === 404 && result.message) {
      return {
        message: result.message,
        custom_tracking_id: null,
        status: 404,
      };
    }

    return {
      message: "No tracking information found.",
      custom_tracking_id: null,
      status: 404,
    };
  } catch (error: any) {
    if (error.response && error.response.data) {
      return {
        message:
          error.response.data.detail ||
          error.response.data.title ||
          error.message ||
          "Courier Barq Raftar tracking failed.",
        custom_tracking_id: null,
        status: error.response.status || 500,
      };
    }
    throw new Error(error.message || "Courier tracking failed.");
  }
};

export const courierTCSTrackings = async (
  userId: number,
  trackingName: string,
  trackingNumber: string
): Promise<any> => {
  try {
    const result = await getTcsTracking(trackingNumber);

    if (result.status === 200) {
      const parsed = parseTCSResponse(result.data);

      // Check if parsing was successful and we got valid tracking data
      if (!parsed || !parsed.number) {
        return {
          message: `No tracking found on TCS with tracking number: ${trackingNumber}`,
          custom_tracking_id: null,
          status: 404,
        };
      }

      const courier = await getTrackingCouriers(2);

      if (!courier || courier.length === 0) {
        return {
          message: "No courier found in the system.",
          custom_tracking_id: null,
          status: 500,
        };
      }

      const tracking_id = await insertManualTracking(
        userId,
        trackingName,
        parsed?.number as string,
        normalizeTCSStatus(
          parsed?.track_info?.latest_event?.description ||
            parsed?.track_info?.latest_status?.status
        ),
        courier?.courier_url || "",
        (parsed as object) || {},
        courier?.courier_id
      );

      return {
        message: "Tracking data fetched successfully.",
        custom_tracking_id: tracking_id,
        status: 200,
      };
    }

    if (result.status === 404 && result.message) {
      return {
        message: result.message,
        custom_tracking_id: null,
        status: 404,
      };
    }

    return {
      message: `No tracking found on TCS with tracking number: ${trackingNumber}`,
      custom_tracking_id: null,
      status: 404,
    };
  } catch (error: any) {
    if (error.response && error.response.data) {
      return {
        message:
          error.response.data.detail ||
          error.response.data.title ||
          error.message ||
          "Courier TCS tracking failed.",
        custom_tracking_id: null,
        status: error.response.status || 500,
      };
    }
    throw new Error(error.message || "Courier tracking failed.");
  }
};

export const getActiveCouriers = async () => {
  try {
    const couriers = await getActiveCouriersFromDB();

    if (couriers.length === 0) {
      return { status: 404, message: "No active couriers found.", data: [] };
    }

    return { status: 200, message: "success", data: couriers };
  } catch (error: any) {
    console.error("Error fetching active couriers:", error);
    return {
      status: 500,
      message: "Internal Server Error",
      data: [],
      error: error.message,
    };
  }
};

export const courierBlueExTrackings = async (
  userId: number,
  trackingName: string,
  trackingNumber: string
): Promise<any> => {
  try {
    const result = await getBlueExTracking(trackingNumber);

    if (result.status === 200) {
      const parsed = parseBlueExResponse(result.data);

      // Check if parsing was successful and we got valid tracking data
      if (!parsed || !parsed.number) {
        return {
          message: `No tracking found on BlueEX with tracking number: ${trackingNumber}`,
          custom_tracking_id: null,
          status: 404,
        };
      }

      const courier = await getTrackingCouriers(4);

      if (!courier || courier.length === 0) {
        return {
          message: "No courier found in the system.",
          custom_tracking_id: null,
          status: 500,
        };
      }

      const tracking_id = await insertManualTracking(
        userId,
        trackingName,
        parsed.number as string,
        normalizeBlueExStatus(
          parsed?.track_info?.latest_event?.description ||
            parsed?.track_info?.latest_status?.status
        ),
        courier?.courier_tracking_url || "",
        (parsed as object) || {},
        courier?.courier_id
      );

      return {
        message: "Tracking data fetched successfully.",
        custom_tracking_id: tracking_id,
        status: 200,
      };
    }

    if (result.status === 404 && result.message) {
      return {
        message: result.message,
        custom_tracking_id: null,
        status: 404,
      };
    }

    return {
      message: `No tracking found on BlueEX with tracking number: ${trackingNumber}`,
      custom_tracking_id: null,
      status: 404,
    };
  } catch (error: any) {
    if (error.response && error.response.data) {
      return {
        message:
          error.response.data.detail ||
          error.response.data.title ||
          error.message ||
          "Courier BlueEX tracking failed.",
        custom_tracking_id: null,
        status: error.response.status || 500,
      };
    }
    throw new Error(error.message || "Courier tracking failed.");
  }
};

export const courierFlyCourierTrackings = async (
  userId: number,
  trackingName: string,
  trackingNumber: string
): Promise<any> => {
  try {
    const result = await getFlyCourierTracking(trackingNumber);

    if (result.status === 200) {
      const parsed = parseFlyCourierResponse(result.data);

      if (!parsed || !parsed.number) {
        return {
          message: `No tracking found on FlyCourier with tracking number: ${trackingNumber}`,
          custom_tracking_id: null,
          status: 404,
        };
      }

      const courier = await getTrackingCouriers(5);

      if (!courier || courier.length === 0) {
        return {
          message: "No courier found in the system.",
          custom_tracking_id: null,
          status: 500,
        };
      }

      const tracking_id = await insertManualTracking(
        userId,
        trackingName,
        parsed.number as string,
        normalizeFlyCourierStatus(
          parsed?.track_info?.latest_event?.description ||
            parsed?.track_info?.latest_status?.sub_status_descr
        ),
        courier?.courier_tracking_url || "",
        (parsed as object) || {},
        courier?.courier_id
      );

      return {
        message: "Tracking data fetched successfully.",
        custom_tracking_id: tracking_id,
        status: 200,
      };
    }

    if (result.status === 404 && result.message) {
      return {
        message: result.message,
        custom_tracking_id: null,
        status: 404,
      };
    }

    return {
      message: `No tracking found on FlyCourier with tracking number: ${trackingNumber}`,
      custom_tracking_id: null,
      status: 404,
    };
  } catch (error: any) {
    if (error.response && error.response.data) {
      return {
        message:
          error.response.data.detail ||
          error.response.data.title ||
          error.message ||
          "Courier FlyCourier tracking failed.",
        custom_tracking_id: null,
        status: error.response.status || 500,
      };
    }
    throw new Error(error.message || "Courier tracking failed.");
  }
};
