import axios from "axios";
import dotenv from "dotenv";
import { sendErrorEmail } from "./emailService";

dotenv.config();

const jsonUrl = process.env.JSON_URL;
export const searchFromJson = async (identifier: string) => {
  try {
    const response = await axios.get(jsonUrl ? jsonUrl : "");
    const data = response.data;

    // Search in the fetched JSON
    const result = data.find((item: any) => {
      return Object.values(item).some((value) =>
        String(value).toLowerCase().includes(identifier.toLowerCase())
      );
    });

    return result || null;
  } catch (error: any) {
    sendErrorEmail("Error fetching or processing JSON:", error);

    console.error("Error fetching or processing JSON:", error);
    throw new Error("Failed to fetch JSON data.");
  }
};
