import { wait } from "../functions/common";
import { createMetaobjectEntryMutation } from "../graphql/metafields/metafieldsMutation";
import { fetchGoogleTaxonomy } from "../graphql/metafields/metafieldsQuery";
import { getShopByDomain } from "../models/shops/shopModel";
import { sendErrorEmail } from "./emailService";

export const createMetaObject = async (
  shopDomain: string,
  metaobjectKey: string
) => {
  try {
    const categories = await fetchGoogleTaxonomy();

    const shop = await getShopByDomain(shopDomain);
    // Step 3: Create Metaobject Entries
    console.log("shop", shop);
    let addedEntries = 0;
    let failedCategories: { categoryName: string; categoryPath: string }[] = []; // Array to store failed categories

    for (const category of categories) {
      const categoryPath = category.trim();
      const categoryName = categoryPath.split(">").pop()?.trim();

      try {
        await createMetaobjectEntryMutation(
          shop.shop_access_token,
          shopDomain,
          categoryName as string,
          categoryPath,
          metaobjectKey
        );
        addedEntries++;
      } catch (error) {
        // If error occurs, store the failed category for later retry
        console.error(`Failed to insert category: ${categoryName}`);
        failedCategories.push({
          categoryName: categoryName as string,
          categoryPath,
        });
      }

      // Retry every 20 categories processed
      if (addedEntries % 20 === 0) {
        console.log("Processed 20 categories, waiting for 30 seconds...");
        await wait(30000); // Wait 10 seconds before continuing
      }
    }

    // After all attempts, retry failed categories
    if (failedCategories.length > 0) {
      console.log(`Retrying failed categories: ${failedCategories.length}`);
      for (const failedCategory of failedCategories) {
        try {
          await createMetaobjectEntryMutation(
            shop.shop_access_token,
            shopDomain,
            failedCategory.categoryName,
            failedCategory.categoryPath,
            metaobjectKey
          );
          console.log(
            `Successfully retried category: ${failedCategory.categoryName}`
          );
        } catch (error) {
          console.error(
            `Failed to retry category: ${failedCategory.categoryName}`
          );
        }
      }
    }
    return categories;
  } catch (error: any) {
    sendErrorEmail("Error fetching categories:", error);

    console.error("Error fetching categories:", error.message);
    throw new Error("Failed to fetch categories");
  }
};
