import {
  createAddress,
  fetchAddress,
  fetchAddressDetail,
  getUserAddressCount,
  updateUserAddress
} from "../models/address/addressModel";
import { Address } from "../types/address";

export const addNewAddress = async (address: Address): Promise<void> => {
  // Additional business logic can be added here
  await createAddress(address);
};

export const updateAddress = async (address: Address): Promise<void> => {
  // Additional business logic can be added here
  await updateUserAddress(address);
};

export const getAddress = async (
  user_id: number,
  page: number,
  pageSize: number
): Promise<any> => {
  // Additional business logic can be added here
  const totalAddress = await getUserAddressCount(user_id);
  const address = await fetchAddress(user_id, page, pageSize);
  const totalPages = Math.ceil(totalAddress / pageSize);

  return {
    address,
    totalAddressCount: totalAddress,
    totalPages
  };
};

export const getAddressDetail = async (address_id: number): Promise<any> => {
  const address = await fetchAddressDetail(address_id);
  return {
    address
  };
};
