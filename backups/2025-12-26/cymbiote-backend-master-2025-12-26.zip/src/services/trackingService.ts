import axios from "axios";
import {
  checkTrackingUsingOrderShopifyId,
  deleteManualTrackingById,
  getManualTrackingByTrackingNumber,
  getManualTrackingsById,
  getTrackingByNumber,
  getTrackingByOrderIdModel,
  getTrackingItemByModel,
  getUserManualTrackingsByUserId,
  updateDelieveryStatus,
  updateTrackingEvents,
} from "../models/tracking/dbTracking";
import { getShopDetailsByShopId } from "../models/shops/shopModel";
import { updateMerchantsFulfillmentDetails } from "../graphql/tracking/mutation";
import {
  getOrderById,
  getShopTrackingIsEnabled,
} from "../models/orders/dbOrders";
import {
  getUserConnectPoints,
  UpdatePointStatus,
  UpdateUserPoints,
} from "../models/points/userPoints";
import { fetchProductVariantID } from "../models/productVariants/variantModel";
import { getFcmTokens } from "../models/notifications/notificationModel";
import {
  createAppNotificationsService,
  sendFCMNotification,
} from "./notificationService";
import { checkNotification } from "../functions/notificationSettings";
import { sendErrorEmail } from "./emailService";
import {
  courierBarqRaftarTrackings,
  courierDHLTrackings,
  courierTCSTrackings,
  courierBlueExTrackings,
  courierFlyCourierTrackings,
} from "./courierService";
import { getUserById } from "../models/users/user";
import { getNotificationTitle } from "../functions/notificationHelper";

export const getTrackingByNumberS = async (trackingNumber: string) => {
  const tracking = await getTrackingByNumber(trackingNumber);

  return tracking;
};

export const updateShopifyTracking = async (
  orderShopId: number,
  trackingData: any
) => {
  const shopDetails = await getShopDetailsByShopId(orderShopId);

  const accessToken = shopDetails?.shop_access_token;
  const shopDomain = shopDetails?.shop_domain;

  try {
    const updateFulfillment = await updateMerchantsFulfillmentDetails(
      trackingData.shopifyFulfillmentId,
      trackingData.status,
      shopDomain as string,
      accessToken as string
    );

    return updateFulfillment.data;
  } catch (error: any) {
    sendErrorEmail("Error updating Shopify tracking:", error);

    console.error("Error updating Shopify tracking:", error);
    throw new Error("Unable to update Shopify tracking");
  }
};

export const captureTrackingService = async (
  trackingNumber: string,
  trackInfo: any,
  carrier: string
) => {
  console.log("trackInfo", trackInfo);
  try {
    // Step 1: Get tracking by number
    const tracking = await getTrackingByNumberS(trackingNumber);
    console.log("trackingNumber", trackingNumber);
    if (!tracking) {
      return { status: 404, message: "Tracking not found" };
    }

    // Step 2: Get order by tracking's order ID
    const order = await getOrderById(tracking.tracking_order_id);
    if (!order) {
      return { status: 404, message: "Order not found" };
    }

    const trackingData = {
      number: trackingNumber,
      url: trackInfo?.shipping_info?.recipient_address || null,
      carrier: carrier,
      shopifyFulfillmentId: tracking.tracking_shopify_id,
      status: trackInfo?.latest_status?.status || null,
    };

    const normalizedStatus = (trackingData.status || "")
      .toString()
      .toUpperCase()
      .replace(/\s+/g, "_");
    console.log("tracking Data", trackingData.status);
    await updateDelieveryStatus(
      order.order_id,
      order.order_shop_id,
      trackingData.status
    );

    const isTrackingEnabled = await checkTrackingUsingOrderShopifyId(
      order.order_shopify_id
    );

    let updatedTracking: any = {};
    if (isTrackingEnabled) {
      updatedTracking = await updateShopifyTracking(
        order.order_shop_id,
        trackingData
      );
    }

    if (normalizedStatus === "DELIVERED") {
      const Result = await getUserConnectPoints(order?.order_id);
      console.log("response OrderId 1st", Result.connect_point_log_id);
      await UpdatePointStatus(Result.connect_point_log_id, "completed");
      await UpdateUserPoints(Result.connect_point_log_id, order?.order_user_id);
    }

    const providerEvents = trackInfo?.tracking?.providers?.[0]?.events || [];

    console.log("trackInfo events length", providerEvents.length);

    if (providerEvents.length > 0) {
      console.log(
        "came inside if",
        trackingData.status,
        tracking.id,
        providerEvents
      );
      await updateTrackingEvents(providerEvents, tracking.id, normalizedStatus);
    }

    let trackingMessage = "";
    switch (normalizedStatus) {
      case "IN_PROGRESS":
      case "INPROGRESS":
        trackingMessage = `Your order ${order.order_title} is being prepared. We'll notify you when it's on the way.`;
        break;

      case "IN_TRANSIT":
      case "INTRANSIT":
        trackingMessage = `Your order ${order.order_title} is on the way! You can track it live now.`;
        break;

      case "OUT_FOR_DELIVERY":
      case "OUTFORDELIVERY":
        trackingMessage = `Heads up! Your order ${order.order_title} is out for delivery. Be ready to receive it.`;
        break;

      case "DELIVERYFAILURE":
        trackingMessage = `Oops! Your order ${order.order_title} delivery has failed. Contact Support for assistance.`;
        break;

      case "NOTFOUND":
        trackingMessage = `Oops! Your order ${order.order_title} is not found. Contact Support for assistance.`;
        break;

      case "DELIVERED":
        trackingMessage = `Great news! Your order ${order.order_title} has been delivered successfully.`;
        break;

      default:
        trackingMessage = `Your order ${order.order_title} tracking has been updated.`;
        break;
    }

    let notifKey:
      | "notification_setting_order_intransit"
      | "notification_setting_order_dispatched"
      | "notification_setting_order_delivered"
      | "notification_setting_order_update"
      | "notification_setting_tracking" = "notification_setting_tracking";

    if (normalizedStatus === "IN_TRANSIT" || normalizedStatus === "INTRANSIT") {
      notifKey = "notification_setting_order_intransit";
    } else if (
      normalizedStatus === "OUT_FOR_DELIVERY" ||
      normalizedStatus === "OUTFORDELIVERY"
    ) {
      notifKey = "notification_setting_order_dispatched";
    } else if (normalizedStatus === "DELIVERED") {
      notifKey = "notification_setting_order_delivered";
    } else if (
      normalizedStatus === "DELIVERYFAILURE" ||
      normalizedStatus === "IN_PROGRESS" ||
      normalizedStatus === "INPROGRESS" ||
      normalizedStatus === "NOTFOUND"
    ) {
      notifKey = "notification_setting_order_update";
    }

    if (order.order_user_id) {
      const canNotify = await checkNotification(order.order_user_id, notifKey);

      if (!canNotify) {
        console.log(
          `User ${order.order_user_id} disabled ${notifKey} notifications.`
        );
      } else {
        // Only do heavier lookups if we are going to notify
        const VariantImageUrl = await fetchProductVariantID(order.order_id);
        const fcmTokens = await getFcmTokens(order.order_user_id);
        const shop = await getShopDetailsByShopId(order.order_shop_id);

        if (!fcmTokens?.length) {
          console.log(
            `No FCM tokens for user ${order.order_user_id}. Skipping push.`
          );
        } else {
          const MessageData = {
            title: getNotificationTitle(normalizedStatus),
            body: trackingMessage,
            DeviceToken: JSON.stringify(fcmTokens),
            screenName: "Orders",
            orderId: order.order_id.toString(),
            notificationImageUrl: `${shop?.shop_logo_url ?? ""}`,
            type: "token",
            payload: JSON.stringify({
              orderId: order.order_id,
              status: "Tracking Updated",
              ProductVariant: VariantImageUrl,
              trackingId: tracking.id,
              carrier,
              trackingNumber,
              normalizedStatus,
            }),
          };

          await createAppNotificationsService(order.order_user_id, MessageData);
          const notificationResult = await sendFCMNotification(
            fcmTokens,
            MessageData
          );
          console.log("notification Result", notificationResult);
          console.log("Order details processed and saved successfully.");
        }
      }
    }

    return {
      status: 200,
      message: "Tracking updated successfully",
      updatedTracking,
    };
  } catch (error: any) {
    sendErrorEmail("Error in captureTrackingService:", error);

    console.error("Error in captureTrackingService:", error);
    return {
      status: 500,
      message: "Internal Server Error",
      error: error.message,
    };
  }
};

export const getTrackingByOrderId = async (
  orderId: number,
  allTracking?: Boolean
) => {
  return await getTrackingByOrderIdModel(orderId, allTracking);
};

export const getTrackingItemsById = async (trackingId: number) => {
  return await getTrackingItemByModel(trackingId);
};

export const pushCourierTracking = async (
  userId: number,
  trackingName: string,
  trackingNumber: string,
  courier: string
) => {
  try {
    // check tracking number into our tracking db
    let trackingResponse: object | null = null;

    const user = await getUserById(userId);

    if (!user) {
      return {
        message: "user not found",
        status: 404,
      };
    }

    const tracking = await getTrackingByNumber(trackingNumber, userId);

    if (tracking) {
      return {
        message: "tracking already exists",
        order_tracking: tracking,
        status: 201,
      };
    }

    const custom_tracking = await getManualTrackingByTrackingNumber(
      trackingNumber,
      userId
    );

    console.log("custom_tracking", custom_tracking);

    if (custom_tracking) {
      return {
        message: "custom tracking already exists",
        custom_tracking_id: custom_tracking.manual_tracking_id,
        status: 201,
      };
    }

    switch (courier.toString()) {
      case "1":
        trackingResponse = await courierDHLTrackings(
          userId,
          trackingName,
          trackingNumber
        );
        break;
      case "2":
        trackingResponse = await courierTCSTrackings(
          userId,
          trackingName,
          trackingNumber
        );
        break;
      case "3":
        trackingResponse = await courierBarqRaftarTrackings(
          userId,
          trackingName,
          trackingNumber
        );
        break;
      case "4":
        trackingResponse = await courierBlueExTrackings(
          userId,
          trackingName,
          trackingNumber
        );
        break;
      case "5":
        trackingResponse = await courierFlyCourierTrackings(
          userId,
          trackingName,
          trackingNumber
        );
        break;
      default:
        return {
          message: "tracking service not available for this carrier",
          status: 404,
        };
        break;
    }

    if (!trackingResponse) {
      return {
        message: courier + " tracking information not found.",
        status: 404,
      };
    }

    return {
      ...trackingResponse,
    };
  } catch (error: any) {
    throw new Error("Error while getting courier tracking: " + error.message);
  }
};

export const getManualTrackingsByUserId = async (
  user_id: number,
  page: number = 1,
  pageSize: number = 10
) => {
  try {
    const { trackings, total } = await getUserManualTrackingsByUserId(
      user_id,
      page,
      pageSize
    );

    if (trackings.length < 1) {
      return {
        status: 404,
        message: "No trackings found.",
        data: [],
        total: 0,
      };
    }

    return {
      status: 200,
      message: "Trackings fetched.",
      data: trackings,
      total,
    };
  } catch (error: any) {
    console.error("Error fetching manual trackings:", error);
    return {
      status: 500,
      message: "Internal Server Error",
      data: [],
      total: 0,
      error: error.message,
    };
  }
};

export const getManaulTrackingById = async (manual_tracking_id: number) => {
  try {
    const tracking = await getManualTrackingsById(manual_tracking_id);

    console.log("tracking", tracking);
    if (!tracking) {
      return {
        message: "tracking not found",
        status: 404,
      };
    } else {
      return {
        message: "success",
        status: 200,
        custom_tracking: tracking,
      };
    }
  } catch (error: any) {
    return {
      status: 500,
      message: "Unable to search inside Manual_Trackings",
      data: [],
      error: error.message,
    };
  }
};

export const removeManualTracking = async (trackingId: number) => {
  if (!trackingId) {
    return {
      message: "tracking_id not available",
      status: 400,
    };
  }

  const deleted = await deleteManualTrackingById(trackingId);

  if (!deleted) {
    return {
      message: `Custom tracking with ID ${trackingId} not found.`,
      status: 404,
    };
  }

  return {
    message: "Custom tracking deleted successfully.",
    status: 200,
  };
};
