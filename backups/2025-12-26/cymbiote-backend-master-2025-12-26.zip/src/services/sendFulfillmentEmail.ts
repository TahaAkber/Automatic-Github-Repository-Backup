import nodemailer from "nodemailer";
import dotenv from "dotenv";

dotenv.config();

export const sendfulfillmentEmail = async (email: string, order_id: string) => {
  const auth = {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  };

  console.log("auth", auth);

  const transporter = nodemailer.createTransport({
    service: "Gmail",
    auth,
  });

  const mailOptions = {
    from: `"Cercle Support" <${process.env.EMAIL_USER}>`,
    to: email,
    subject: `Pending Order Alert - Order ${order_id}`,
    html: `
      <div style="font-family: Arial, sans-serif; color: #333; max-width: 600px; margin: auto; padding: 20px; border: 1px solid #eee; border-radius: 8px;">
        <h2 style="color: #d93025;">Pending Order Alert</h2>
        <p style="font-size: 14px;">
          <strong>Order ID:</strong> ${order_id}
        </p>
        <p style="font-size: 14px;">
          This order has been <strong>unfulfilled for 7 days</strong>. Immediate fulfillment is required to avoid penalties and ensure timely delivery.
        </p>
        <a href="#" style="display: inline-block; margin-top: 20px; padding: 10px 20px; background-color: #1a73e8; color: #fff; text-decoration: none; border-radius: 5px;">View Order</a>
        <p style="margin-top: 30px; font-size: 12px; color: #888;">
          This is an automated message from Cercle. Please do not reply to this email.
        </p>
      </div>
    `,
  };

  await transporter.sendMail(mailOptions);
};
