import { deleteShopifyCollectionByShopifyId } from "../graphql/collections/collectionMutation";
import {
  shopifyCollectionProductCounts,
  syncCollectionProductsToDB,
} from "../graphql/collections/collectionProductQueries";
import { fetchShopifyCollectionProducts } from "../graphql/product/productQueries";
import {
  deleteCollectionModel,
  deleteTrendingCollection,
  expiredCollections,
  getTrendingCollectionWithName,
  updateCollection,
} from "../models/collections/collectionModel";
import { getProductsByShopifyIds } from "../models/products/productModel";
import {
  fetchShopByCollectionShopId,
  getShopWithRatingUsingShopId,
} from "../models/shops/shopModel";
import { sendErrorEmail } from "./emailService";

export const getCollectionProductsS = async (
  shopId: number,
  collectionId: string,
  pageSize?: number,
  endCursor?: string
) => {
  const shop = await getShopWithRatingUsingShopId(shopId);

  const collectionResponse = await fetchShopifyCollectionProducts(
    collectionId,
    shop.shop_domain,
    shop.shop_access_token,
    pageSize as number,
    endCursor
  );

  const {
    productCount,
    products,
    hasNextPage,
    endCursor: newEndCursor,
  } = collectionResponse;

  const product_shopify_ids = products.map((e: any) => e.id);

  const dbProducts = await getProductsByShopifyIds(product_shopify_ids);

  const data = {
    shop,
    products: dbProducts,
  };

  return {
    data,
    pagination: {
      totalProductCount: productCount,
      hasNextPage,
      endCursor: newEndCursor,
      pageSize: pageSize,
    },
  };
};

export const deleteCollectionService = async (id: string) => {
  try {
    const deletedCollection = await deleteCollectionModel(id);
    return deletedCollection;
  } catch (error: any) {
    sendErrorEmail("Error deleting collection:", error);

    console.error("Error deleting collection:", error);
    throw error;
  }
};

export const updateCollectionService = async (
  id: number,
  title: string,
  body_html: string,
  image: string
) => {
  try {
    const shops = await fetchShopByCollectionShopId(id);

    if (!shops.length) {
      console.log(`No shop/collection found for Collection ID: ${id}`);
      return [];
    }

    const results = [];

    for (const shop of shops) {
      const CollectionProductCount = await shopifyCollectionProductCounts(
        id,
        shop.shop_access_token,
        shop.shop_domain
      );

      const updatedCollection = await updateCollection(
        id,
        title,
        body_html,
        image,
        shop.collection_id,
        CollectionProductCount
      );

      const updatedCollectionProducts = await syncCollectionProductsToDB(
        id,
        shop.shop_access_token,
        shop.shop_domain,
        shop.collection_id,
        CollectionProductCount
      );

      results.push({
        shop_id: shop.collection_shop_id,
        collection_id: shop.collection_id,
        updatedCollection,
        updatedCollectionProducts,
      });
    }

    return results;
  } catch (error: any) {
    sendErrorEmail("Error updating collection:", error);

    console.error("Error updating collection:", error);
    throw error;
  }
};

export const checkAndRemoveTrendingCollection = async () => {
  try {
    const { trendingCollections, collectionShopifyIds } =
      await expiredCollections();

    if (trendingCollections.length > 0) {
      for (const collection of trendingCollections) {
        const deleteShopifyCollection =
          await deleteShopifyCollectionByShopifyId(
            collection.shop_access_token,
            collection.shop_domain,
            collection.collection_shopify_id,
            collection.collection_id
          );
        await deleteTrendingCollection(collection.collection_name);
      }
    } else {
      console.log("There is no expired collection");
    }
    console.log("trendingCollections", trendingCollections);
  } catch (error: any) {
    sendErrorEmail("Error updating collection:", error);

    console.error("Error updating collection:", error);
    throw error;
  }
};
