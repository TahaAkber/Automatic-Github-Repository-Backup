import jwt from "jsonwebtoken";
import dotenv from "dotenv";
import { addSocialAccount } from "../models/socialAccount/socialAccount";
import { exchangeGoogleAuthCodeForTokens } from "../functions/firebase";
import { sendErrorEmail } from "./emailService";

dotenv.config();

export const createChildSocialAccount = async (
  userId: number,
  socialId: string,
  socialEmail: string,
  socialType: string,
  serverAuthToken?: string
): Promise<any> => {
  try {
    const getRefreshToken = await exchangeGoogleAuthCodeForTokens(
      serverAuthToken
    );

    const response = await addSocialAccount(
      userId,
      socialId,
      socialEmail,
      socialType,
      getRefreshToken?.data?.refresh_token
    );

    return { status: 200, message: "Account attached successfully" };
  } catch (error: any) {
    sendErrorEmail("Error creating following logs: ", error);

    throw new Error("Error creating following logs: " + error.message);
  }
};

// export const updateChildSocialAccount = async (
//   userId: number,
//   socialId: number,
//   socialEmail: string,
//   socialType: string,
//   serverAuthToken: string
// ): Promise<any> => {
//   try {
//     const getRefreshToken = await exchangeGoogleAuthCodeForTokens(
//       serverAuthToken
//     );

//     if (!getRefreshToken?.data?.refresh_token) {
//       const response = await addSocialAccount(
//         userId,
//         socialId,
//         socialEmail,
//         socialType,
//         getRefreshToken?.data?.refresh_token
//       );
//       return response;
//     }
//   } catch (error: any) {
//     throw new Error("Error creating following logs: " + error.message);
//   }
// };
