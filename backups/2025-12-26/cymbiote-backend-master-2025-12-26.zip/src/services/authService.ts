import jwt from "jsonwebtoken";
import {
  createSocialUser,
  createUser,
  getUserByEmailOrUsername,
  removeNotificationToken,
  storeNotificationToken,
  updatePassword,
} from "../models/users/user";
import { sendErrorEmail, sendOtpEmail } from "./emailService";
import dotenv from "dotenv";
import { generateOtp, saveOtpS } from "./otpService";

dotenv.config();

// Generate JWT
export const generateToken = (user: any) => {
  return jwt.sign(
    {
      id: user.user_id,
      email: user.user_email,
      profile: user.user_image_url,
      username: user.user_name,
      user_phone: user.user_phone,
      firstname: user.user_first_name,
      lastname: user.user_last_name,
    },
    process.env.JWT_SECRET || "",
    { expiresIn: "360d" }
  );
};

// Login user and send OTP
export const loginUser = async (
  identifier: string,
  password: string,
  isRegisteredDevice: boolean
) => {
  const user = await getUserByEmailOrUsername(identifier);

  if (!user || user.user_password !== password) {
    return { message: "Invalid email or password", token: "" };
  }

  if (isRegisteredDevice && user.user_is_verified) {
    const token = generateToken(user);
    return { token, message: "login successfull" };
  } else {
    // Generate OTP
    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    await saveOtpS(identifier, otp);
    console.log("got hit");

    // Send OTP via email
    await sendOtpEmail(user.user_email, `Your OTP is: ${otp}`);

    return { token: "", message: "otp sent to your email" };
  }
};

export const loginUserNoticationSave = async (
  device_id: string,
  notification_token: string,
  user_id?: number
) => {
  await storeNotificationToken(device_id, notification_token, user_id);
  return true;
};

export const logoutUser = async (device_id: string) => {
  return await removeNotificationToken(device_id);
};

// Login user and send OTP
export const sendOtpS = async (identifier: string) => {
  const user = await getUserByEmailOrUsername(identifier);

  if (!user) {
    throw new Error("Not found email/username.");
  }
  // Generate OTP
  const otp = Math.floor(100000 + Math.random() * 900000).toString();
  await saveOtpS(identifier, otp);
  console.log("got hit");

  // Send OTP via email
  await sendOtpEmail(user.user_email, `Your OTP is: ${otp}`);

  return { token: "", message: "otp sent to your email" };
};

export const updateUserPassword = async (
  identifier: string,
  password: string
): Promise<any> => {
  try {
    // Call model function to create a new user
    const user = await updatePassword(identifier, password);

    return { message: "Update password successfully.", user };
  } catch (error: any) {
    sendErrorEmail("Error update password user: ", error);

    throw new Error("Error update password user: " + error.message);
  }
};

export const loginSocialUser = async (identifier: string) => {
  const user = await getUserByEmailOrUsername(identifier);
  console.log(user);
  if (!user || !identifier) {
    throw new Error("Invalid identifier");
  } else if (!user.user_is_verified) {
    // Generate OTP and send email
    const otp = generateOtp();
    await saveOtpS(user.user_email, otp);
    await sendOtpEmail(user.user_email, otp);
    return { message: "OTP sent to your phone number." };
  } else {
    const token = generateToken(user);
    return { token, message: "login successfull" };
  }
};

export const signUpUser = async (
  email: string,
  phone: string,
  password: string,
  username: string,
  firstname: string,
  lastname: string,
   gender: string,
  dateOfBirth: string 
): Promise<any> => {
  try {
    // Call model function to create a new user
    const userId = await createUser(
      email,
      phone,
      password,
      username,
      firstname,
      lastname,
         gender,
      dateOfBirth
    );

    return { message: "User registered successfully.", userId };
  } catch (error: any) {
    sendErrorEmail("Error creating user: ", error);

    throw new Error("Error creating user: " + error.message);
  }
};

export const signUpSocialUser = async (
  email: string,
  phone: string,
  imageUrl: string,
  password: string,
  firstName: string,
  lastName: string,
  userLoginType: string
): Promise<any> => {
  try {
    // Call model function to create a new user
    const user = await createSocialUser(
      email,
      phone,
      imageUrl,
      password,
      firstName,
      lastName,
      userLoginType
    );

    return { message: "User registered successfully.", user };
  } catch (error: any) {
    sendErrorEmail("Error creating user: ", error);

    throw new Error("Error creating user: " + error.message);
  }
};

export const userVerifier = async (identifier: string): Promise<any> => {
  try {
    // Fetch user by email or username
    const user = await getUserByEmailOrUsername(identifier);

    // If the user already exists, return conflict error
    if (user) {
      return { status: 409, message: "Email or Phone already exists." };
    }

    return {
      status: 200,
      message: "This identifier does not have an existing user.",
    };
  } catch (error: any) {
    sendErrorEmail("Error creating user: ", error);

    throw new Error("Error creating user: " + error.message);
  }
};
