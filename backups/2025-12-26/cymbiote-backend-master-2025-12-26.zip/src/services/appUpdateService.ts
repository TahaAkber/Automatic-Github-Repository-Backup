import {
  getAppUpdateConfig,
  updateAppUpdateConfig,
} from "../models/appUpdate/appUpdateModel";

export const fetchAppUpdateConfig = async (): Promise<any> => {
  return await getAppUpdateConfig();
};

export const updateAppUpdateConfigService = async (
  id: number,
  updateData: any
): Promise<any> => {
  return await updateAppUpdateConfig(id, updateData);
};
