import {
  getOrderByShopifyId,
  getOrderItemUsingOrderIdNShopifyVarientId,
  getPointLogIdByOrderId,
  updateOrderFulfillmentStatus,
} from "../models/orders/dbOrders";
import {
  cancelTracking,
  checkTrackingUsingOrderShopifyId,
  getTrackingByNumber,
  saveTrackingInfo,
  saveTrackingOrderItems,
  updateOrderItemStatus,
  updateTrackingEventsWithCustomTracking,
  updateTrackingNumber,
  updateTrackingUrl,
  getCourierByTrackingUrl,
  updateTrackingCarrier,
} from "../models/tracking/dbTracking";
import axios from "axios";
import dotenv from "dotenv";
import {
  getDhlTracking,
  parseDHLResponse,
  getTcsTracking,
  parseTCSResponse,
  getBarqRaftarTracking,
  parseBarqRaftarResponse,
  getBlueExTracking,
  parseBlueExResponse,
  getFlyCourierTracking,
  parseFlyCourierResponse,
} from "../functions/courierTrackings";
import * as pointsModel from "../models/points/userPoints";
import { getShop, getShopDetailsByShopId } from "../models/shops/shopModel";
import { fetchShopifyOrderSource } from "../graphql/orders/orderQueries";
import { getFcmTokens } from "../models/notifications/notificationModel";
import {
  createAppNotificationsService,
  sendFCMNotification,
} from "./notificationService";
import { fetchProductVariantID } from "../models/productVariants/variantModel";
import { checkNotification } from "../functions/notificationSettings";
import { sendErrorEmail } from "./emailService";

dotenv.config();

const BASE_URL = process.env.BASE_URL;
const URL_REGISTER_17Track = "https://api.17track.net/track/v2/register";
const TOKEN_17TRACK = process.env.TOKEN_17TRACK;

const searchCarrier = async (trackingUrl: string) => {
  try {
    const url = `${BASE_URL}/api/search/carrier?identifier=${trackingUrl}`;
    console.log("url", url);
    const response = await axios.get(url);
    return response.data.key; // Returns the carrier key
  } catch (error: any) {
    sendErrorEmail("Error fetching carrier information:", error);

    console.error("Error fetching carrier information:", error);
    throw new Error("Unable to detect carrier. Please try again later.");
  }
};

const registerTracking = async (
  trackingNumber: string,
  carrierCode: number
) => {
  const payload = [
    {
      number: trackingNumber,
      carrier: carrierCode,
    },
  ];

  const headers = {
    "Content-Type": "application/json",
    "17token": TOKEN_17TRACK,
  };

  const response = await axios.post(URL_REGISTER_17Track, payload, { headers });
  return response.data;
};

export const handleFulfillment = async (
  trackingShopifyId: number, //fulfillment_id
  order_shopify_id: number,
  trackingNumber: string,
  trackingUrl: string,
  line_items: any[]
) => {
  try {
    let message = `No tracking has been added for this order.`;
    let tracking = null;
    // Step 1: Fetch order details
    const order = await getOrderByShopifyId(order_shopify_id);
    if (!order) throw new Error("Order not found.");

    const shop = await getShopDetailsByShopId(order.order_shop_id);

    if (!shop?.shop_domain || !shop?.shop_access_token) {
      throw new Error("Shop domain or access token is missing.");
    }

    if (trackingNumber && trackingUrl) {
      console.log("Inside tracking", trackingNumber, trackingUrl);
      // check if tracking service is purchased by merchant
      const trackingEnabled = await checkTrackingUsingOrderShopifyId(
        order_shopify_id
      );

      console.log("trackingEnabled", trackingEnabled);

      //first check if tracking is already available in db
      const trackingInformation = await getTrackingByNumber(trackingNumber);

      console.log("existing trackingInformation", trackingInformation);

      if (trackingInformation) {
        console.log("tracking already exists");
        return true;
      }

      const carrierCode = await searchCarrier(trackingUrl);

      console.log("carrierCode found", carrierCode);

      console.log(
        "InsertTracking",
        order.order_id,
        trackingNumber,
        carrierCode,
        order_shopify_id,
        trackingUrl
      );

      // Determine tracking source: 17track or manual APIs
      const use17track = carrierCode != undefined;
      let shouldUseManual = !use17track;

      // save tracking information in db
      tracking = await saveTrackingInfo(
        order.order_id,
        trackingNumber,
        carrierCode,
        trackingShopifyId.toString(),
        trackingUrl,
        !shouldUseManual // true if 17track succeeded, false if using manual
      );

      console.log("tracking saved to db", tracking);

      if (tracking) {
        const trackingOrderItems = await Promise.all(
          line_items.map(async (item) => {
            console.log(
              "line_item",
              order.order_id,
              item.variant_id,
              item.fulfillment_status
            );
            const data = await getOrderItemUsingOrderIdNShopifyVarientId(
              order.order_id,
              item.variant_id
            );

            return {
              orderItemId: data.order_item_id,
              quantity: item.quantity,
            };
          })
        );

        await saveTrackingOrderItems(tracking.id, trackingOrderItems);
        message = `Tracking has been added for this order.`;
      }

      if (use17track) {
        // Try 17track first
        try {
          await registerTracking(trackingNumber, carrierCode);
          console.log(`✓ Registered ${trackingNumber} with 17track`);
        } catch (error: any) {
          console.log(
            `✗ 17track failed, using manual APIs for ${trackingNumber}`
          );
          shouldUseManual = true;
        }
      }

      // Use manual tracking if needed (no carrier OR 17track failed)
      if (shouldUseManual) {
        await populateManualTrackingData(
          tracking.id,
          trackingNumber,
          trackingUrl
        );
      }
    } else {
      tracking = await saveTrackingInfo(
        order.order_id,
        trackingNumber,
        null,
        trackingShopifyId.toString(),
        trackingUrl,
        false // No carrier code means manual tracking
      );

      if (tracking) {
        const trackingOrderItems = await Promise.all(
          line_items.map(async (item) => {
            console.log(
              "line_item",
              order.order_id,
              item.variant_id,
              item.fulfillment_status
            );
            const data = await getOrderItemUsingOrderIdNShopifyVarientId(
              order.order_id,
              item.variant_id
            );

            return {
              orderItemId: data.order_item_id,
              quantity: item.quantity,
            };
          })
        );

        await saveTrackingOrderItems(tracking.id, trackingOrderItems);
        message = `Tracking has been added for this order.`;
      }
    }

    await Promise.all(
      line_items.map(async (item) => {
        const orderItem = await getOrderItemUsingOrderIdNShopifyVarientId(
          order.order_id,
          item.variant_id
        );

        await updateOrderItemStatus(
          item.fulfillment_status,
          order.order_id,
          orderItem.order_item_variant_id
        );
      })
    );

    const updateOrderStatus = await updateOrderFulfillmentStatus(
      order.order_id
    );
    console.log("updateOrderStatus", updateOrderStatus);

    // Give order points to user
    if (order.order_user_id) {
      const response = await getPointLogIdByOrderId(order?.order_id);
      console.log("response", response.connect_point_log_id);
      const result = await pointsModel.UpdatePointStatus(
        response.connect_point_log_id,
        "completed"
      );
      console.log("Response point status", result);
    }

    // send notification to user
    if (order.order_user_id) {
      const canNotify = await checkNotification(
        order.order_user_id,
        "notification_setting_order_shipped"
      );

      if (!canNotify) {
        console.log(
          `User ${order.order_user_id} disabled order_shipped notifications.`
        );
      } else {
        const VariantImageUrl = await fetchProductVariantID(order.order_id);
        const fcmTokens = await getFcmTokens(order.order_user_id);

        if (!fcmTokens?.length) {
          console.log(
            `No FCM tokens for user ${order.order_user_id}. Skipping push.`
          );
        } else {
          const MessageData = {
            title: `Great news! Your Order No: ${order.order_title} is Shipped Successfully`,
            body: message,
            image: VariantImageUrl || null,
            DeviceToken: JSON.stringify(fcmTokens),
            screenName: "Orders",
            orderId: order.order_id.toString(),
            notificationImageUrl: `${shop?.shop_logo_url ?? ""}`,
            type: "token",
            payload: JSON.stringify({
              status: "Order Shipped",
              orderId: order.order_id,
              productVariant: VariantImageUrl,
              trackingNumber: trackingNumber,
              trackingId: tracking?.id,
            }),
          };

          const notificationResult = await sendFCMNotification(
            fcmTokens,
            MessageData
          );
          await createAppNotificationsService(order.order_user_id, MessageData);
          console.log("notification Result", notificationResult);
        }
      }
    }

    return true;
  } catch (error: any) {
    sendErrorEmail("Error handling fulfillment:", error);

    console.error("Error handling fulfillment:", error);
    throw error;
  }
};

export const cancelTrackingService = async (
  status: string,
  order_id: number,
  tracking_number: number
) => {
  try {
    const order = await getOrderByShopifyId(order_id);
    const cancelledData = await cancelTracking(
      status,
      order.order_id,
      tracking_number
    );
    return cancelledData;
  } catch (error: any) {
    sendErrorEmail("Error cancelling tracking:", error);

    console.error("Error cancelling tracking:", error);
    throw error;
  }
};

export const updateFulfillmentTrackingService = async (
  fulfillment_id: number,
  status: string,
  order_id: number,
  tracking_number: string,
  tracking_url: string
) => {
  try {
    const order = await getOrderByShopifyId(order_id);

    // Handle cancellation - delete tracking
    if (status === "cancelled") {
      const cancelledData = await cancelTracking(
        status,
        order.order_id,
        tracking_number as any
      );
      return {
        action: "cancelled",
        result: cancelledData,
      };
    }

    // Handle tracking number update
    if (tracking_number) {
      await updateTrackingNumber(fulfillment_id, tracking_number);
      console.log(
        `Updated tracking number for fulfillment ${fulfillment_id} to ${tracking_number}`
      );

      // Register the new tracking number with 17track
      if (tracking_url) {
        try {
          const carrierCode = await searchCarrier(tracking_url);
          console.log(
            `Registering new tracking ${tracking_number} with carrier ${carrierCode} to 17track`
          );
          await registerTracking(tracking_number, carrierCode);
          console.log(
            `Successfully registered tracking ${tracking_number} to 17track`
          );
        } catch (error) {
          console.error(
            `Failed to register tracking ${tracking_number} to 17track:`,
            error
          );
          // Don't throw - we still want to update the DB even if 17track registration fails
        }
      }
    }

    // Handle tracking URL update
    if (tracking_url) {
      await updateTrackingUrl(fulfillment_id, tracking_url);
      console.log(`Updated tracking URL for fulfillment ${fulfillment_id}`);
    }

    return {
      action: "updated",
      fulfillment_id,
      tracking_number,
      tracking_url,
    };
  } catch (error: any) {
    sendErrorEmail("Error updating fulfillment tracking:", error);
    console.error("Error updating fulfillment tracking:", error);
    throw error;
  }
};

// Helper function to fetch manual tracking data based on carrier
async function fetchManualTrackingDataForOrder(
  trackingNumber: string,
  specificCourierId?: number
) {
  console.log("specific courier id", specificCourierId);
  try {
    let result: any = null;
    let parsed: any = null;

    // Map courier IDs to their respective functions
    // IDs based on Cron Tracking Service
    // 1: DHL, 2: TCS, 3: BarqRaftar, 4: BlueEX, 5: FlyCourier
    const courierFunctions: Record<number, () => Promise<any>> = {
      1: async () => {
        // DHL
        const r = await getDhlTracking(trackingNumber);
        return r?.status === 200 && r.data ? parseDHLResponse(r.data) : null;
      },
      2: async () => {
        // TCS
        const r = await getTcsTracking(trackingNumber);
        return r?.status === 200 && r.data ? parseTCSResponse(r.data) : null;
      },
      3: async () => {
        // BarqRaftar
        const r = await getBarqRaftarTracking(trackingNumber);
        return r?.status === 200 && r.data
          ? parseBarqRaftarResponse(r.data)
          : null;
      },
      4: async () => {
        // BlueEX
        const r = await getBlueExTracking(trackingNumber);
        return r?.status === 200 && r.data ? parseBlueExResponse(r.data) : null;
      },
      5: async () => {
        // FlyCourier
        const r = await getFlyCourierTracking(trackingNumber);
        console.log("running fly courier function", r);
        return r?.status === 200 && r.data
          ? parseFlyCourierResponse(r.data)
          : null;
      },
    };

    // If specific courier is known, try only that
    if (specificCourierId && courierFunctions[specificCourierId]) {
      console.log(
        `Using specific courier ID ${specificCourierId} for ${trackingNumber}`
      );
      return await courierFunctions[specificCourierId]();
    }

    // Otherwise try all in sequence (Priority: TCS -> DHL -> BarqRaftar -> BlueEX -> FlyCourier)
    // Note: This order is arbitrary, better to have specific courier
    const executionOrder = [1, 2, 3, 4, 5];

    for (const courierId of executionOrder) {
      try {
        if (courierFunctions[courierId]) {
          parsed = await courierFunctions[courierId]();
          if (parsed) return parsed;
        }
      } catch (e) {
        // Continue to next courier
      }
    }

    return null;
  } catch (error: any) {
    console.error("Error fetching manual tracking data:", error.message);
    return null;
  }
}

// Helper function to update Tracking table with manual data
async function updateTrackingWithManualData(
  trackingId: number,
  manualData: any,
  courierId: number
) {
  try {
    // Extract milestone array and convert to tracking_events format
    const milestone = manualData?.track_info?.milestone || [];

    // Update tracking with events
    await updateTrackingEventsWithCustomTracking(
      trackingId,
      milestone,
      courierId
    );

    console.log(
      `Updated tracking ${trackingId} with ${milestone.length} events from manual API`
    );
  } catch (error: any) {
    console.error("Error updating tracking with manual data:", error.message);
    throw error;
  }
}

// Helper to populate manual tracking data (extracted to avoid duplication)
async function populateManualTrackingData(
  trackingId: number,
  trackingNumber: string,
  trackingUrl: string
) {
  try {
    let specificCourierId: number | undefined;

    // Try to find courier from URL
    if (trackingUrl) {
      const courier = await getCourierByTrackingUrl(trackingUrl);
      if (courier) {
        specificCourierId = courier.courier_id;
      }
    }

    const manualData = await fetchManualTrackingDataForOrder(
      trackingNumber,
      specificCourierId
    );

    console.log("manual data", manualData);

    if (manualData && specificCourierId) {
      await updateTrackingWithManualData(
        trackingId,
        manualData,
        specificCourierId as number
      );
      console.log(
        `✓ Populated tracking ${trackingNumber} with manual data (${
          manualData.track_info?.milestone?.length || 0
        } events)`
      );
    } else {
      console.warn(`✗ No manual tracking data found for ${trackingNumber}`);
    }
  } catch (error: any) {
    console.error(
      `✗ Manual tracking failed for ${trackingNumber}:`,
      error.message
    );
  }
}
