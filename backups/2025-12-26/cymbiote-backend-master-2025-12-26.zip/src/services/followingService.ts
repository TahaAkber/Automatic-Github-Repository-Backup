import jwt from "jsonwebtoken";
import {
  DBResult,
  FollowingLocalItem,
  manageUserFollowing,
  userFollowingLogs,
} from "../models/following/following";
import dotenv from "dotenv";
import { getProducts } from "../models/products/productModel";
import { getShopWithRatingUsingShopId } from "../models/shops/shopModel";
import { sendErrorEmail } from "./emailService";

dotenv.config();

export const createFollowingLogs = async (
  userId: number,
  shopId: number,
  isFollowing: boolean,
  createdAt: string
): Promise<any> => {
  try {
    // Call model function to create a new user
    const response = await manageUserFollowing(
      userId,
      shopId,
      isFollowing,
      createdAt
    );

    return { status: 200, message: response };
  } catch (error: any) {
    sendErrorEmail("Error creating following logs: ", error);

    throw new Error("Error creating following logs: " + error.message);
  }
};

export const FollowingLogs = async (
  userId: number,
  product: boolean = false,
  following_local?: FollowingLocalItem[],
  search: string = "", // optional: empty means "no filter"
  page: number = 1,
  pageSize: number = 10
): Promise<any> => {
  try {
    const isLocal =
      Array.isArray(following_local) && following_local.length > 0;

    if (isLocal) {
      // Local path → repo returns array; we enrich, then optionally filter & paginate
      const baseRows = (await userFollowingLogs(
        userId,
        following_local,
        search,
        page,
        pageSize
      )) as any[];

      const enriched = await Promise.all(
        baseRows.map(async (item: any) => {
          const shop_detail = await getShopWithRatingUsingShopId(
            item.following_shop_id
          );
          return { ...item, shop_detail };
        })
      );

      const filtered = search
        ? enriched.filter((x: any) =>
            (x.shop_detail?.shop_name || "")
              .toLowerCase()
              .includes(search.toLowerCase())
          )
        : enriched;

      const total = filtered.length;
      const start = (page - 1) * pageSize;
      const end = start + pageSize;
      const pageSlice = filtered.slice(start, end);

      const data = await Promise.all(
        pageSlice.map(async (item: any) => {
          const productsArr = product
            ? await getProducts(item.following_shop_id, 6, 1)
            : [];
          return {
            ...item,
            products: productsArr,
            shop_detail: { ...item.shop_detail, shop_following: true },
          };
        })
      );

      const totalPages = Math.max(1, Math.ceil(total / pageSize));
      return {
        status: 200,
        message: "Success",
        data,
        pagination: {
          page,
          pageSize,
          total,
          totalPages,
          hasNextPage: page < totalPages,
          hasPrevPage: page > 1,
        },
        filters: { search },
      };
    }

    // DB path → repo already handles optional search + pagination
    const { rows, total, totalPages } = (await userFollowingLogs(
      userId,
      undefined,
      search,
      page,
      pageSize
    )) as DBResult;

    const data = await Promise.all(
      rows.map(async (item: any) => {
        const shop_detail = await getShopWithRatingUsingShopId(
          item.following_shop_id
        );
        const productsArr = product
          ? await getProducts(item.following_shop_id, 6, 1)
          : [];
        return {
          ...item,
          shop_detail: { ...shop_detail, shop_following: true },
          products: productsArr,
        };
      })
    );

    return {
      status: 200,
      message: "Success",
      data,
      pagination: {
        page,
        pageSize,
        total,
        totalPages,
        hasNextPage: page < totalPages,
        hasPrevPage: page > 1,
      },
      filters: { search },
    };
  } catch (error: any) {
    sendErrorEmail("Error fetching following logs: ", error);

    throw new Error("Error fetching following logs: " + error.message);
  }
};
