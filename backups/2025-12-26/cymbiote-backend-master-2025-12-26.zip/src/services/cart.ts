import {
  assignUserToCarts,
  deleteCartItemsByCartId,
  deletePreCartItems,
  getCartFromDatabase,
  syncCartToDatabase,
} from "../models/cart/cartModel";
import { getVariantById } from "../models/products/productModel";
import { getShopWithRatingUsingShopId } from "../models/shops/shopModel";
import {
  CartShop,
  FetchCartParams,
  RawCartItem,
  SyncCartPayload,
} from "../types/cart/cart";
import { sendErrorEmail } from "./emailService";

export const fetchCart = async (cart_items: any[]) => {
  try {
    console.log("Fetching cart items:", cart_items);

    const fetchItems = await Promise.all(
      cart_items.map(async (item) => {
        const cartId = item.pre_cart_id;
        const userId = item.user_id;

        console.log(`Processing cartId: ${cartId || "N/A"}`);
        const shop = await getShopWithRatingUsingShopId(item.shop_id);

        const productVariants = Array.isArray(item.product_variant)
          ? item.product_variant
          : [];

        console.log("Product Variant Raw:", productVariants);

        const variants = await Promise.all(
          productVariants
            .filter((variant: any) => {
              if (!variant || typeof variant.variant_id === "undefined") {
                console.warn("Skipping invalid variant:", variant);
                return false;
              }
              return true;
            })
            .map(async (variant: any) => {
              const productVariant = await getVariantById(variant.variant_id);
              return {
                product_variant: productVariant,
                quantity: variant.qty,
                cart_item_id: variant.cart_item_id,
              };
            })
        );

        return { cartId, userId, shop, products: variants };
      })
    );

    return { status: 200, data: fetchItems, message: "Success" };
  } catch (error: any) {
    sendErrorEmail("Error fetching cart items:", error);

    console.error("Error fetching cart items:", error.message);
    return {
      status: 500,
      message: "Error fetching cart items.",
      error: error.message,
    };
  }
};

export const syncCartService = async (payload: SyncCartPayload) => {
  try {
    const { cart_id, deviceIdentifier, user_id, shop_id, pre_cart_items } =
      payload;

    const result = await syncCartToDatabase(
      cart_id,
      deviceIdentifier,
      user_id,
      shop_id,
      pre_cart_items
    );

    return result; // e.g. { success: true, message: "Cart synced successfully" }
  } catch (error: any) {
    sendErrorEmail("Error in syncCartService:", error);

    console.error("Error in syncCartService:", error);
    throw new Error("sync cart failed " + error.message);
  }
};

export const fetchCartService = async (params: {
  user_id?: number;
  device_identifier?: string;
}) => {
  try {
    const { user_id, device_identifier } = params;

    if (!user_id && !device_identifier) {
      throw new Error("Either user_id or deviceIdentifier must be provided");
    }

    let carts: any = [];

    if (user_id) {
      carts = await getCartFromDatabase(user_id, undefined);
      console.log("user carts", carts);
    } else if (device_identifier) {
      carts = await getCartFromDatabase(undefined, device_identifier);
      console.log("device carts", carts);
    }

    const cart_items = carts.map((shopEntry: any) => ({
      pre_cart_id: shopEntry.pre_cart_id,
      shop_id: shopEntry.shop_id,
      user_id: shopEntry.pre_cart_user_id,
      product_variant: shopEntry.product_variant.map((variant: any) => ({
        variant_id: variant.variant_id,
        qty: variant.qty,
        cart_item_id: variant.pre_cart_item_id,
      })),
    }));

    console.log("Fetched carts:", cart_items);

    const enrichedCart = await fetchCart(cart_items);

    return {
      status: 200,
      data: enrichedCart.data,
      message: enrichedCart.message,
    };
  } catch (error: any) {
    sendErrorEmail("fetchCartService Error:", error);

    console.error("fetchCartService Error:", error);
    throw new Error("Failed to fetch cart");
  }
};
export const deleteCart = async (cartId: string) => {
  try {
    if (!cartId) {
      throw new Error("CartId is required");
    }

    const result = await deleteCartItemsByCartId(cartId);
    return result;
  } catch (error: any) {
    sendErrorEmail("Error in deleteCart service:", error);

    console.error("Error in deleteCart service:", error);
    throw new Error("Failed to delete cart");
  }
};
export const deleteCartItems = async (preCartItemId: string) => {
  try {
    if (!preCartItemId) {
      throw new Error("preCartItemId is required");
    }

    const result = await deletePreCartItems(preCartItemId);
    return result;
  } catch (error: any) {
    sendErrorEmail("Error in deleteCart service:", error);

    console.error("Error in deleteCart service:", error);
    throw new Error("Failed to delete cart");
  }
};

export const assignUserToCartsService = async (
  cartIds: string[],
  userId: number
): Promise<{ updatedCount: number }> => {
  if (!cartIds || !cartIds.length) {
    throw new Error("cartIds array is required");
  }
  if (!userId) {
    throw new Error("userId is required");
  }
  try {
    const result = await assignUserToCarts(cartIds, userId);
    return result;
  } catch (error: any) {
    sendErrorEmail("Error in assignUserToCartsService:", error);

    console.error("Error in assignUserToCartsService:", error);
    throw error;
  }
};
