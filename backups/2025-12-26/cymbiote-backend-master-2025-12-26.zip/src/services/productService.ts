import { areImagesSame } from "../functions/imagePosition";
import {
  detectVariantPriceDrops,
  queuePriceDropNotifications,
  queueRestockNotifications,
} from "../functions/notificationTrigger";
import { getShopFollowingStatus } from "../functions/shop";
import {
  fetchMetaObjectById,
  fetchMetaobjectDetails,
  fetchProductMetafield,
  fetchProductMetafields,
  fetchProductsWithShopifyId,
  fetchShopifyProductVariant,
  getProductTaxonomyUsingName,
  updateProductMetafieldsinDb,
} from "../graphql/product/productQueries";
import {
  createProduct,
  deleteProductImages,
  fetchCustomProductCategories,
  getDefaultTitleVariantsForMultiVariantProducts,
  getFilterProducts,
  getproductbyshopifyId,
  getProductDetail,
  getProductFiltersUsingShopId,
  getProducts,
  getShopProductCount,
  getTileProducts,
  getUsingShopId,
  getUsingShopifyVariantInventoryId,
  insertProductImage,
  markDefaultTitleVariantsInactive,
  updateProductActiveStatus,
  updateProductCustomCategory,
  updateProductDescription,
  updateProductImageUrl,
  updateProductName,
  updateProductVariantInventory,
} from "../models/products/productModel";
import {
  getVariantsUsingShopifyPVId, // Added import
  updateVariantPriceUsingVariantId,
  insertVariantsInDB,
  updateProductsVariantsMetafields,
  updateVariantImage,
  getVariantsByProductId,
  markVariantsInactive,
} from "../models/productVariants/variantModel";
import {
  getShopByProductShopifyId,
  getShopFilter,
  getShopWithRatingUsingShopId,
} from "../models/shops/shopModel";
import { Product } from "../types/Product";
import { sendErrorEmail } from "./emailService";

export const addNewProduct = async (product: Product): Promise<void> => {
  // Additional business logic can be added here
  await createProduct(product);
};

export const fetchAllProducts = async (
  shop_id?: number,
  product_length?: number
): Promise<Product[]> => {
  return await getProducts(shop_id, product_length);
};

export const fetchTileProducts = async (
  shop_id?: number,
  product_length?: number
): Promise<Product[]> => {
  return await getTileProducts(shop_id, product_length);
};

export const fetchProductsWithCategories = async (
  page: number,
  pageSize: number,
  category_name?: string,
  shop_id?: number,
  collectionType_id?: number,
  collection_id?: number
) => {
  const Products = await getFilterProducts(
    page,
    pageSize,
    category_name,
    shop_id,
    collectionType_id,
    collection_id
  );

  const productCategories = await fetchCustomProductCategories(
    shop_id,
    collection_id,
    collectionType_id
  );

  const data = {
    Products,
    productCategories,
  };

  return data;
};

export const fetchProductDetail = async (
  product_id?: number,
  user_id?: number
): Promise<Record<string, any>> => {
  return await getProductDetail(product_id, user_id);
};

export const updateProductInventoryInfo = async (
  variant_inventory_id: string,
  newInventory: number
) => {
  try {
    const inventoryGid = "gid://shopify/InventoryItem/" + variant_inventory_id;

    const productAvail = await getUsingShopifyVariantInventoryId(inventoryGid);
    if (productAvail.length < 1) {
      return null; // Product not found or inactive
    }

    const beforeRow = productAvail[0];
    const prevQty = Number(beforeRow.variant_quantity) || 0;
    const nextQty = Number(newInventory) || 0;
    const stockIncreased = nextQty > prevQty;
    console.log(beforeRow, "beforeRow<><");
    const updatedProduct = await updateProductVariantInventory(
      newInventory,
      inventoryGid
    );
    console.log(stockIncreased && nextQty > 0, "check 1");
    if (stockIncreased && nextQty > 0) {
      setImmediate(() => {
        queueRestockNotifications(beforeRow).catch((e) =>
          console.error("async restock notify error:", e)
        );
      });
    }

    return updatedProduct;
  } catch (error: any) {
    sendErrorEmail("Error updating product inventory:", error);

    console.error("Error updating product inventory:", error);
    throw error;
  }
};

export const fetchShopProduct = async (
  shop_id: number,
  page = 1,
  pageSize = 10,
  searchKeyword?: string,
  minRating?: number,
  minPrice?: number,
  maxPrice?: number,
  sortPrice?: "asc" | "desc" | undefined,
  createdAt?: "asc" | "desc" | undefined,
  product_id?: number,
  user_id?: number
) => {
  try {
    console.log("fetchShopProduct");
    const totalProduct = await getShopProductCount(
      shop_id,
      searchKeyword,
      minRating,
      minPrice,
      maxPrice,
      product_id
    );

    const products = await getProducts(
      shop_id,
      pageSize,
      page,
      false,
      searchKeyword,
      minRating,
      minPrice,
      maxPrice,
      sortPrice,
      createdAt,
      product_id
    );

    const shop = await getShopWithRatingUsingShopId(shop_id, user_id);
    const totalPages = Math.ceil(totalProduct / pageSize);
    const productCategories = await getProductFiltersUsingShopId(
      shop_id,
      searchKeyword,
      minRating
    );
    return {
      products,
      shop,
      productCategories,
      totalProductCount: totalProduct,
      totalPages,
      currentPage: page,
    };
  } catch (error: any) {
    sendErrorEmail("Error fetching active shops with pagination", error);

    throw new Error("Error fetching active shops with pagination");
  }
};

export const fetchShopReel = async (
  shop_id: number,
  page = 1,
  pageSize = 10
) => {
  try {
    // Fetch shops based on pagination
    const totalProduct = await getShopProductCount(shop_id);
    const products = await getProducts(shop_id, pageSize, page, true);
    const shop = await getShopWithRatingUsingShopId(shop_id);
    const totalPages = Math.ceil(totalProduct / pageSize);

    return {
      products,
      shop,
      totalReelCount: totalProduct,
      totalPages,
      currentPage: page,
    };
  } catch (error: any) {
    sendErrorEmail("Error fetching active shops with pagination", error);

    throw new Error("Error fetching active shops with pagination");
  }
};

export const fetchRelatedShops = async (shop_id: number) => {
  try {
    // Fetch shops based on pagination
    const totalProduct = await getShopProductCount(shop_id);
    const shop = await getUsingShopId(shop_id);

    return {
      shop,
      totalReelCount: totalProduct,
    };
  } catch (error: any) {
    sendErrorEmail("Error fetching active shops with pagination", error);

    throw new Error("Error fetching active shops with pagination");
  }
};

export const updateProductVariantsPrices = async (
  variants: any[],
  updatedVariants: any[],
  variantProductId: number
) => {
  try {
    const Specificproduct = await getproductbyshopifyId(variantProductId);
    // console.log("specific product", Specificproduct);
    // Extract Shopify variant IDs from the webhook payload
    const shopifyVariantIds = variants.map((v) => v.id);
    // console.log("checking variant id ", shopifyVariantIds);
    const dbvariants = await getVariantsUsingShopifyPVId(shopifyVariantIds);
    const Updatedvariants = [];
    // console.log("testing variants", dbvariants);
    let product_id = Specificproduct.product_id;

    for (const i of updatedVariants) {
      const dbVariant = dbvariants.find(
        (v) => v.variant_shopify_id === "gid://shopify/ProductVariant/" + i.id
      );

      if (!dbVariant) {
        Updatedvariants.push({
          ...i,
          variant_product_id: product_id,
        });
      }
    }

    await insertVariantsInDB(Updatedvariants);
    const dbVariants = await getVariantsUsingShopifyPVId(shopifyVariantIds);

    // // Prepare updates for variants where prices differ
    const updateRequiredItems = [];
    for (const variant of variants) {
      const dbVariant = dbVariants.find(
        (v) =>
          v.variant_shopify_id === "gid://shopify/ProductVariant/" + variant.id
      );

      if (dbVariant && dbVariant.variant_price !== parseInt(variant.price)) {
        updateRequiredItems.push({
          id: dbVariant.variant_id,
          newPrice: parseInt(variant.price),
        });
      }
    }

    console.log("updateRequiredItems", updateRequiredItems);

    // // Update only the variants that have price differences
    if (updateRequiredItems.length > 0) {
      const updatedItems = await updateVariantPriceUsingVariantId(
        updateRequiredItems
      );
    }

    return { updated: updateRequiredItems.length };
    // return { updated: 0 };
  } catch (error: any) {
    sendErrorEmail("Error updating product variant prices:", error);

    console.error("Error updating product variant prices:", error);
    throw error;
  }
};

export const detectAndHandleProductUpdate = async (payload: any) => {
  const productId = payload.id;
  const updatedProduct = payload;

  const changes: string[] = [];

  try {
    const currentProduct = await getproductbyshopifyId(productId);
    console.log("currentProduct", currentProduct, productId);

    if (!currentProduct) {
      console.log("Product not found in the database.");
      return changes;
    }

    if (updatedProduct.title) {
      const currentProductName = currentProduct.product_name;
      if (currentProductName !== updatedProduct.title) {
        changes.push("product_name");
        await updateProductName(productId, updatedProduct.title);
      }
    }

    if (updatedProduct.body_html) {
      const currentProductDescription = currentProduct.product_description;

      if (currentProductDescription !== updatedProduct.body_html) {
        changes.push("product_description");
        await updateProductDescription(
          productId,
          updatedProduct.body_html,
          updatedProduct.body_html
        );
      }
    }
    // usage:
    const imagesChanged = areImagesSame(
      updatedProduct.images,
      currentProduct.product_images
    );

    if (updatedProduct.image && updatedProduct.image.src) {
      const currentImageUrl = currentProduct.product_image_url;
      if (currentImageUrl !== updatedProduct.image.src) {
        changes.push("product_image_url");
        await updateProductImageUrl(productId, updatedProduct.image.src);
      }
    }

    console.log(
      "images matching",
      updatedProduct.images,
      currentProduct.product_images,
      imagesChanged
    );

    if (updatedProduct.images.length && imagesChanged === false) {
      await deleteProductImages(currentProduct.product_id);
      changes.push("product_images");

      for (const image of updatedProduct.images) {
        await insertProductImage(
          currentProduct?.product_id,
          image.src,
          image.position
        );
      }
    } else if (
      currentProduct.product_images.filter((img: any, i: number) => {
        return img.product_image_url !== updatedProduct.images[i].src;
      }).length > 0
    ) {
      await deleteProductImages(currentProduct.product_id);
      changes.push("product_images");

      // Sequentially insert images
      for (const image of updatedProduct.images) {
        await insertProductImage(
          currentProduct?.product_id,
          image.src,
          image.position
        );
      }
    }

    if (updatedProduct.status) {
      const currentActiveStatus = currentProduct.product_is_active;
      const newStatus = updatedProduct.status === "active";
      if (currentActiveStatus !== newStatus) {
        changes.push("product_is_active");
        await updateProductActiveStatus(productId, newStatus);
      }
    }

    const shopInfoByProduct = await getShopByProductShopifyId(productId);

    console.log("shopinfobyproduct", shopInfoByProduct, productId);

    const metafield = await fetchProductMetafields(
      productId,
      shopInfoByProduct.shop_domain,
      shopInfoByProduct.shop_access_token
    );

    await updateMetafieldsAndVariantMetafields(
      shopInfoByProduct,
      currentProduct
    );
    console.log("metafield", metafield);

    if (metafield) {
      const metaobject = await fetchMetaObjectById(
        metafield.value,
        shopInfoByProduct.shop_domain,
        shopInfoByProduct.shop_access_token
      );
      console.log("metaobject", metaobject);

      if (metaobject) {
        const currentCategoryValue = currentProduct.product_custom_category;
        console.log(
          "currentCategoryValue",
          currentCategoryValue,
          "metaobject.displayName",
          metaobject.displayName
        );
        if (currentCategoryValue !== metaobject.displayName) {
          changes.push("product_custom_category");
          const productTaxonomy = await getProductTaxonomyUsingName(
            metaobject.displayName,
            shopInfoByProduct.shop_domain,
            shopInfoByProduct.shop_access_token
          );

          await updateProductCustomCategory(
            productId,
            metaobject.displayName,
            productTaxonomy?.id ? productTaxonomy?.id : null
          );
        }
      }
    }

    const variants = payload.variants.map((variant: any) => ({
      id: variant.id,
      price: variant.price,
    }));
    const updatedVariants = payload.variants;
    const variantProductId = payload.id;
    console.log(updatedVariants, "<updatedVariants>");
    if (Array.isArray(updatedVariants) && updatedVariants.length) {
      try {
        const drops = await detectVariantPriceDrops(productId, updatedVariants);
        console.log(drops, "<drops>");
        if (drops.length) {
          console.log("Price drops detected:", drops);
          await queuePriceDropNotifications({
            currentProduct,
            drops,
          });
        }
      } catch (notifyErr) {
        console.error("Price drop notification error:", notifyErr);
      }
    }

    const result = await updateProductVariantsPrices(
      variants,
      updatedVariants,
      variantProductId
    );

    console.log(`Updated ${result.updated} variants with new prices.`);

    // Update Variant Images
    if (
      updatedProduct.images &&
      updatedProduct.images.length > 0 &&
      updatedProduct.variants
    ) {
      // Map image_id to src
      const imageMap = new Map<number, string>();
      updatedProduct.images.forEach((img: any) => {
        imageMap.set(img.id, img.src);
      });

      // Also get the DB variants to check existing images
      // We already called updateProductVariantsPrices above which fetches DB variants internally
      // but lets recall getVariantsUsingShopifyPVId using the IDs from payload to be sure we have the latest or just reuse logic.
      // Actually `updateProductVariantsPrices` returns `updated` count, not the variants.
      // But inside `updateProductVariantsPrices`, it fetches `dbvariants`.
      // We can refactor `updateProductVariantsPrices` to return them, OR just fetch them here again.
      // Fetching again is safer/cleaner without refactoring the other function signature.

      const variantShopifyIds = updatedProduct.variants.map((v: any) => v.id);
      const dbVariants = await getVariantsUsingShopifyPVId(variantShopifyIds);

      // Iterate variants and update image if image_id is present and changed
      for (const variant of updatedProduct.variants) {
        if (variant.image_id) {
          const newImageSrc = imageMap.get(variant.image_id);
          if (newImageSrc) {
            const gid = "gid://shopify/ProductVariant/" + variant.id;

            // Find existing variant in DB result
            const existingVariant = dbVariants.find(
              (v: any) => v.variant_shopify_id === gid
            );

            // Check if image URL is different
            if (
              existingVariant &&
              existingVariant.variant_image_url !== newImageSrc
            ) {
              console.log(
                `Updating image for variant ${gid} from ${existingVariant.variant_image_url} to ${newImageSrc}`
              );
              changes.push("variant_image_url");
              await updateVariantImage(gid, newImageSrc);
            }
          }
        }
      }
    }

    // Deactivate missing variants
    try {
      const dbVariantsForDeactivation = await getVariantsByProductId(
        currentProduct.product_id
      );
      const payloadVariantGids = updatedProduct.variants.map(
        (v: any) => "gid://shopify/ProductVariant/" + v.id
      );

      const variantsToDeactivate = dbVariantsForDeactivation.filter(
        (v: any) => !payloadVariantGids.includes(v.variant_shopify_id)
      );

      if (variantsToDeactivate.length > 0) {
        const idsToDeactivate = variantsToDeactivate.map(
          (v: any) => v.variant_id
        );
        console.log(
          `Marking ${idsToDeactivate.length} variants as inactive:`,
          idsToDeactivate
        );
        await markVariantsInactive(idsToDeactivate);
        changes.push("variants_deactivated");
      }
    } catch (err) {
      console.error("Error deactivating missing variants:", err);
    }

    console.log("checking for any default title useless variants");
    cleanDefaultTitleVariantsService();

    return changes;
  } catch (error: any) {
    sendErrorEmail("Error handling product update:", error);

    console.error("Error handling product update:", error);
    throw new Error("Failed to detect and handle product update.");
  }
};

export const getUsingShopCategoryIdProducts = async (
  data: any,
  userId: number
) => {
  const modifiedShopResponse = await Promise.all(
    (data?.finalResult || []).map(async (item: any) => {
      const filters = await getShopFilter(item.shop_id);
      item.filters = filters;
      try {
        // Fetch products for the current shop
        const products = await fetchAllProducts(item.shop_id, 5);
        const followStatus = await getShopFollowingStatus(item.shop_id, userId);
        // Map through the products and process the variants with images
        const productVariantsWithImages = await Promise.all(
          products.map(async (product) => {
            const variants = await Promise.all(
              product.product_variant.map(async (variant: any) => {
                // Fetch Shopify variant data
                const shopifyVariantData = await fetchShopifyProductVariant(
                  variant.variant_shopify_id, // Fixed incorrect variable name
                  item.shop_domain,
                  item.shop_access_token
                );

                // Return the variant with images
                return {
                  ...variant,
                  images: shopifyVariantData?.media?.nodes || [],
                  selected_options: shopifyVariantData?.selectedOptions || [],
                };
              })
            );
            return { ...product, product_variant: variants };
          })
        );

        // Flatten the nested arrays and return the modified shop object
        return {
          ...item,
          shop_following: followStatus,
          products: productVariantsWithImages.flat(2), // Flatten up to two levels
        };
      } catch (error: any) {
        sendErrorEmail(`Error processing shop with ID ${item.shop_id}:`, error);

        console.error(`Error processing shop with ID ${item.shop_id}:`, error);
        return {
          ...item,
          shop_following: false,
          products: [], // Return an empty products array in case of error
        };
      }
    })
  );

  return modifiedShopResponse;
};

export const updateMetafieldsAndVariantMetafields = async (
  shopinfobyproduct: any,
  currentProduct: any
) => {
  const shopifyVariantData = await fetchProductsWithShopifyId(
    shopinfobyproduct.shop_domain,
    shopinfobyproduct.shop_access_token,
    currentProduct.product_shopify_id
  );

  const variantData = shopifyVariantData?.data.node.variants;

  if (variantData && Array.isArray(variantData.nodes)) {
    for (const variant of variantData.nodes) {
      const options = variant.selectedOptions || [];
      try {
        await updateProductsVariantsMetafields(variant.id, options);
      } catch (error: any) {
        sendErrorEmail(
          `Error updating metafields for variant ${variant.id}:`,
          error
        );

        console.error(
          `Error updating metafields for variant ${variant.id}:`,
          error
        );
      }
    }
  }

  try {
    const metafieldsResult = await fetchProductMetafield(
      shopinfobyproduct.shop_domain,
      shopinfobyproduct.shop_access_token,
      currentProduct.product_shopify_id
    );
    const Producttitle = currentProduct.product_name;

    if (metafieldsResult) {
      const { metafields, metaobjectGids } = metafieldsResult;

      const metaobjects = await fetchMetaobjectDetails(
        shopinfobyproduct.shop_domain,
        shopinfobyproduct.shop_access_token,
        metaobjectGids
      );

      const resolved = metafields
        .filter((field: any) => field.type.includes("metaobject_reference"))
        .map((field: any) => {
          const key = field.definition?.name;

          let gids: string[] = [];
          try {
            const parsed = JSON.parse(field.value);
            gids = Array.isArray(parsed) ? parsed : [parsed];
          } catch {
            if (field.value.startsWith("gid://")) {
              gids = [field.value];
            }
          }

          const matchedValues = metaobjects
            .filter((meta: any) => gids.includes(meta.id))
            .flatMap((meta: any) =>
              meta.fields
                .map((f: any) => f.value)
                .flatMap((val: any) => {
                  try {
                    const parsed = JSON.parse(val);
                    return Array.isArray(parsed) ? parsed : [parsed];
                  } catch {
                    return [val];
                  }
                })
                .filter((v: string) => {
                  if (typeof v !== "string") return false;
                  return v && !v.startsWith("gid://shopify/TaxonomyValue");
                })
            );

          return {
            key,
            values: matchedValues,
          };
        })
        .filter((item: any) => item.values.length > 0);

      console.log("🧩 Final structured values per key:", resolved);
      if (resolved.length > 0) {
        await updateProductMetafieldsinDb(
          currentProduct.product_shopify_id,
          shopinfobyproduct.shop_id,
          resolved
        );
      }
    }
  } catch (error: any) {
    sendErrorEmail(
      "Error fetching or updating product-level metafields:",
      error
    );

    console.error(
      "Error fetching or updating product-level metafields:",
      error
    );
  }
};

export const cleanDefaultTitleVariantsService = async () => {
  try {
    // Step 1: Get variant IDs
    const variantIds = await getDefaultTitleVariantsForMultiVariantProducts();

    // Step 2: If nothing to update
    if (!variantIds || variantIds.length === 0) {
      return {
        success: true,
        updated: 0,
        message: "No Default Title variants found to mark inactive.",
      };
    }

    // Step 3: Soft delete (mark inactive)
    const updateResult = await markDefaultTitleVariantsInactive(variantIds);

    return {
      success: true,
      updated: updateResult.updated,
      message: updateResult.message,
    };
  } catch (error: any) {
    sendErrorEmail(`Error in cleanDefaultTitleVariantsService`, error.message);
    console.error("Error in cleanDefaultTitleVariantsService:", error);
    throw new Error("Failed to process Default Title variants.");
  }
};
