import { BigQuery } from "@google-cloud/bigquery";

const bigquery = new BigQuery({
  projectId: "cercle-marketplace",
  keyFilename: "./src/firebase/cercle-adminsdk.json",
  // location: "EU", // Or the actual region where dataset exists
});

export default bigquery;
