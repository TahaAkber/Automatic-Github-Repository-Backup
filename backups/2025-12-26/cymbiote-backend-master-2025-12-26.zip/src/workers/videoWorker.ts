import { Worker, isMainThread } from "worker_threads";
import sql from "mssql";
import axios from "axios";
import fs from "fs";
import path from "path";
import { spawn } from "child_process";
import os from "os";
import { v4 as uuidv4 } from "uuid";
import dotenv from "dotenv";
import { pipeline } from "stream";
import { promisify } from "util";

dotenv.config();

const DB_HOST = process.env.DB_SERVER || "localhost";

const isWSL = (): boolean => {
  if (os.platform() !== "linux") return false;
  try {
    const procVersion = fs.readFileSync("/proc/version", "utf8").toLowerCase();
    return procVersion.includes("microsoft") || procVersion.includes("wsl");
  } catch {
    return false;
  }
};

const IS_WSL = isWSL();

const getTempDir = (): string => {
  if (IS_WSL) {
    return "/tmp";
  }
  return os.tmpdir();
};

const TEMP_DIR = getTempDir();

const DB_CONFIG: sql.config = {
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  server: DB_HOST,
  database: process.env.DB_NAME,
  port: parseInt(process.env.DB_PORT || "1433"),
  options: {
    encrypt: false, // Matches "Encrypt=yes"
    trustServerCertificate: true, // Matches "TrustServerCertificate=yes"
    enableArithAbort: true,
  },
  requestTimeout: 60000, // 60s
};

const BUNNY_LIBRARY_ID = process.env.BUNNY_STREAM_LIBRARY_ID;
const BUNNY_API_KEY = process.env.BUNNY_STREAM_API_KEY;
const BUNNY_CDN_HOST =
  process.env.BUNNY_STREAM_CDN_HOSTNAME || "vz-c0741eed-905.b-cdn.net";

const PREVIEW_SECONDS = parseInt(process.env.PREVIEW_SECONDS || "3");
const TARGET_RES = process.env.TARGET_RES || "R1080";
const VIDEO_BITRATE_K = parseInt(
  process.env.COMPRESSION_VIDEO_BITRATE_K || "4500"
);
const AUDIO_BITRATE_K = parseInt(
  process.env.COMPRESSION_AUDIO_BITRATE_K || "128"
);
const DELETE_LOCAL = process.env.DELETE_LOCAL !== "0";
const USE_GPU = process.env.USE_GPU !== "0";
const GPU_PRESET = process.env.GPU_PRESET || "p4";
const GPU_TUNE = process.env.GPU_TUNE || "hq";

const getDefaultFfmpegPath = (): string => {
  // Use ffmpeg from PATH - works in Docker containers and most environments
  return "ffmpeg";
};
const FFMPEG_PATH = process.env.FFMPEG_PATH || getDefaultFfmpegPath();

const NUM_PROCESSES = parseInt(process.env.NUM_PROCESSES || "4");

const log = (level: "INFO" | "ERROR" | "WARN", message: string) => {
  const timestamp = new Date().toISOString().replace("T", " ").split(".")[0];
  const envInfo = IS_WSL ? "[WSL]" : "[Windows]";
  console.log(`${timestamp} ${envInfo} [${level}] ${message}`);
};

const streamPipeline = promisify(pipeline);

async function getDbConnection(): Promise<sql.ConnectionPool> {
  try {
    const pool = await new sql.ConnectionPool(DB_CONFIG).connect();
    return pool;
  } catch (err) {
    log("ERROR", `Database connection failed: ${err}`);
    throw err;
  }
}

async function getNextVideoRow(pool: sql.ConnectionPool): Promise<{
  video_id: number;
  video_url: string;
  video_url_preview: string | null;
} | null> {
  const transaction = new sql.Transaction(pool);

  try {
    await transaction.begin();
    const request = new sql.Request(transaction);

    const querySelect = `
            SELECT TOP 1
                video_id,
                video_url,
                video_url_preview
            FROM Videos WITH (UPDLOCK, READPAST, ROWLOCK)
            WHERE
                video_url LIKE '%cdn.shopify.com%'
                AND (video_url LIKE '%.mp4%' OR video_url NOT LIKE '%.m3u8%')
                AND video_url NOT LIKE '%#processing'
            ORDER BY video_id ASC
        `;

    const result = await request.query(querySelect);
    const row = result.recordset[0];

    if (!row) {
      await transaction.commit();
      return null;
    }

    const videoId = row.video_id;
    const originalUrl = row.video_url;

    // "Check out" the row
    const processingUrl = `${originalUrl}#processing`;
    const queryUpdate = `UPDATE Videos SET video_url = @processingUrl, updated_at = GETDATE() WHERE video_id = @videoId`;

    await request
      .input("processingUrl", sql.NVarChar, processingUrl)
      .input("videoId", sql.Int, videoId)
      .query(queryUpdate);

    await transaction.commit();

    log("INFO", `Checked out video_id=${videoId}`);
    return {
      video_id: videoId,
      video_url: originalUrl,
      video_url_preview: row.video_url_preview,
    };
  } catch (err) {
    log("ERROR", `Error in getNextVideoRow: ${err}`);
    if (transaction) {
      try {
        await transaction.rollback();
      } catch (rollbackErr) {
        /* ignore */
      }
    }
    return null;
  }
}

async function updateVideoMainHls(
  pool: sql.ConnectionPool,
  videoId: number,
  hlsUrl: string
) {
  try {
    const request = new sql.Request(pool);
    await request
      .input("hlsUrl", sql.NVarChar, hlsUrl)
      .input("videoId", sql.Int, videoId)
      .query(
        "UPDATE Videos SET video_url = @hlsUrl, updated_at = GETDATE() WHERE video_id = @videoId"
      );
  } catch (err) {
    log("ERROR", `Failed to update main HLS for video_id=${videoId}: ${err}`);
    throw err;
  }
}

async function updateVideoPreviewUrl(
  pool: sql.ConnectionPool,
  videoId: number,
  previewUrl: string
) {
  try {
    const request = new sql.Request(pool);
    await request
      .input("previewUrl", sql.NVarChar, previewUrl)
      .input("videoId", sql.Int, videoId)
      .query(
        "UPDATE Videos SET video_url_preview = @previewUrl, updated_at = GETDATE() WHERE video_id = @videoId"
      );
  } catch (err) {
    log(
      "ERROR",
      `Failed to update preview URL for video_id=${videoId}: ${err}`
    );
    throw err;
  }
}

async function rollbackVideoStatus(
  pool: sql.ConnectionPool,
  videoId: number,
  originalUrl: string
) {
  try {
    log(
      "WARN",
      `Rolling back video_id=${videoId} to original URL: ${originalUrl}`
    );
    const request = new sql.Request(pool);
    await request
      .input("originalUrl", sql.NVarChar, originalUrl)
      .input("videoId", sql.Int, videoId)
      .query(
        "UPDATE Videos SET video_url = @originalUrl, updated_at = GETDATE() WHERE video_id = @videoId"
      );
  } catch (err) {
    log(
      "ERROR",
      `FATAL: Failed to rollback video_id=${videoId}. DB Error: ${err}`
    );
  }
}

const bunnyHeadersJson = () => ({
  AccessKey: BUNNY_API_KEY,
  "Content-Type": "application/json",
});
const bunnyHeadersOctet = () => ({
  AccessKey: BUNNY_API_KEY,
  "Content-Type": "application/octet-stream",
});

async function bunnyCreateVideo(title: string): Promise<string | null> {
  const endpoint = `https://video.bunnycdn.com/library/${BUNNY_LIBRARY_ID}/videos`;
  try {
    const response = await axios.post(
      endpoint,
      { title },
      { headers: bunnyHeadersJson(), timeout: 60000 }
    );
    const data = response.data;
    const guid = data.guid || data.videoGuid || data.id;
    if (guid) return guid;
    log(
      "ERROR",
      `Bunny create video failed: ${response.status} ${JSON.stringify(data)}`
    );
  } catch (err: any) {
    log("ERROR", `Error in bunnyCreateVideo: ${err.message}`);
  }
  return null;
}

async function bunnyUploadFileToVideo(
  guid: string,
  filePath: string
): Promise<boolean> {
  const endpoint = `https://video.bunnycdn.com/library/${BUNNY_LIBRARY_ID}/videos/${guid}`;
  try {
    const fileStream = fs.createReadStream(filePath);
    await axios.put(endpoint, fileStream, {
      headers: bunnyHeadersOctet(),
      timeout: 600000, // 10 mins
      maxBodyLength: Infinity,
      maxContentLength: Infinity,
    });
    return true;
  } catch (err: any) {
    log("ERROR", `Bunny upload file failed: ${err.message}`);
  }
  return false;
}

function buildHlsUrl(guid: string): string {
  return `https://${BUNNY_CDN_HOST}/${guid}/playlist.m3u8`;
}

async function bunnyGetVideoStatus(guid: string): Promise<string | null> {
  const endpoint = `https://video.bunnycdn.com/library/${BUNNY_LIBRARY_ID}/videos/${guid}`;
  try {
    const response = await axios.get(endpoint, {
      headers: bunnyHeadersJson(),
      timeout: 30000,
    });
    const status = response.data.status;
    const statusMap: { [key: number]: string } = {
      0: "Queued",
      1: "Processing",
      2: "Finished",
      3: "Failed",
    };
    return statusMap[status] || "Unknown";
  } catch (err: any) {
    log("WARN", `Failed to get Bunny video status ${guid}: ${err.message}`);
    return null;
  }
}

async function waitForBunnyTranscode(
  guid: string,
  timeoutSeconds = 300,
  pollInterval = 10
): Promise<boolean> {
  const startTime = Date.now();
  log(
    "INFO",
    `Waiting for transcode to finish for guid=${guid} (max ${timeoutSeconds}s)...`
  );

  while (true) {
    const elapsed = (Date.now() - startTime) / 1000;
    if (elapsed > timeoutSeconds) {
      log("ERROR", `Timeout waiting for transcode on guid=${guid}.`);
      return false;
    }

    const status = await bunnyGetVideoStatus(guid);
    if (status === "Finished") {
      log("INFO", `Transcode finished for guid=${guid}.`);
      return true;
    } else if (status === "Failed") {
      log("ERROR", `Transcode failed for guid=${guid}.`);
      return false;
    } else if (status === "Queued" || status === "Processing") {
      log(
        "INFO",
        `Transcode status for ${guid}: ${status}. Waiting ${pollInterval}s...`
      );
    } else {
      log(
        "WARN",
        `Unknown transcode status for ${guid}: ${status}. Retrying...`
      );
    }

    await new Promise((resolve) => setTimeout(resolve, pollInterval * 1000));
  }
}

async function ensureFfmpeg() {
  return new Promise<void>((resolve, reject) => {
    const p = spawn(FFMPEG_PATH, ["-version"]);
    p.on("close", (code) => {
      if (code === 0) resolve();
      else reject(new Error("FFmpeg not found"));
    });
    p.on("error", reject);
  });
}

async function nvencAvailable(): Promise<boolean> {
  return new Promise<boolean>((resolve) => {
    const p = spawn(FFMPEG_PATH, ["-hide_banner", "-encoders"]);
    let output = "";
    p.stdout.on("data", (data) => (output += data.toString()));
    p.on("close", () => {
      resolve(output.toLowerCase().includes("h264_nvenc"));
    });
    p.on("error", () => resolve(false));
  });
}

async function downloadToTemp(url: string): Promise<string> {
  const tmpPath = path.join(TEMP_DIR, `vid_${uuidv4()}.mp4`);
  const response = await axios.get(url, {
    responseType: "stream",
    timeout: 300000,
  });
  await streamPipeline(response.data, fs.createWriteStream(tmpPath));
  return tmpPath;
}

function getScaleFilter(): string {
  if (TARGET_RES === "R720") return "scale=1280:-2:flags=lanczos";
  return "scale=1920:-2:flags=lanczos"; // Default R1080
}

function getFfmpegCompressCmdGpu(inPath: string, outPath: string): string[] {
  return [
    "-y",
    "-i",
    inPath,
    "-vf",
    getScaleFilter(),
    "-c:v",
    "h264_nvenc",
    "-preset",
    GPU_PRESET,
    "-tune",
    GPU_TUNE,
    "-rc:v",
    "vbr",
    "-b:v",
    `${VIDEO_BITRATE_K}k`,
    "-maxrate",
    `${Math.floor(VIDEO_BITRATE_K * 1.23)}k`,
    "-bufsize",
    `${Math.floor(VIDEO_BITRATE_K * 2.5)}k`,
    "-pix_fmt",
    "yuv420p",
    "-profile:v",
    "high",
    "-movflags",
    "+faststart",
    "-c:a",
    "aac",
    "-b:a",
    `${AUDIO_BITRATE_K}k`,
    outPath,
  ];
}

function getFfmpegCompressCmdCpu(inPath: string, outPath: string): string[] {
  return [
    "-y",
    "-i",
    inPath,
    "-vf",
    getScaleFilter(),
    "-c:v",
    "libx264",
    "-b:v",
    `${VIDEO_BITRATE_K}k`,
    "-maxrate",
    `${Math.floor(VIDEO_BITRATE_K * 1.2)}k`,
    "-bufsize",
    `${Math.floor(VIDEO_BITRATE_K * 2)}k`,
    "-pix_fmt",
    "yuv420p",
    "-preset",
    "slow",
    "-profile:v",
    "high",
    "-movflags",
    "+faststart",
    "-c:a",
    "aac",
    "-b:a",
    `${AUDIO_BITRATE_K}k`,
    outPath,
  ];
}

async function compressVideo(inputPath: string): Promise<string> {
  await ensureFfmpeg();
  const outPath = path.join(TEMP_DIR, `comp_${uuidv4()}.mp4`);

  let triedGpu = false;
  if (USE_GPU && (await nvencAvailable())) {
    triedGpu = true;
    log("INFO", "Compressing with GPU (NVENC)...");
    try {
      await runSpawn(FFMPEG_PATH, getFfmpegCompressCmdGpu(inputPath, outPath));
      return outPath;
    } catch (e) {
      log("WARN", `NVENC failed, falling back to CPU. Error: ${e}`);
    }
  }

  log(
    "INFO",
    triedGpu
      ? "Compressing with CPU (fallback)..."
      : "Compressing with CPU (NVENC not available or disabled)..."
  );
  await runSpawn(FFMPEG_PATH, getFfmpegCompressCmdCpu(inputPath, outPath));
  return outPath;
}

async function createPreviewClip(
  inputPath: string,
  seconds = PREVIEW_SECONDS
): Promise<string> {
  await ensureFfmpeg();
  const outPath = path.join(TEMP_DIR, `prev_${uuidv4()}.mp4`);
  const cmd = [
    "-y",
    "-ss",
    "0",
    "-t",
    str(seconds),
    "-i",
    inputPath,
    "-c:v",
    "libx264",
    "-preset",
    "fast",
    "-profile:v",
    "baseline",
    "-level",
    "3.0",
    "-movflags",
    "+faststart",
    "-c:a",
    "aac",
    "-b:a",
    "96k",
    outPath,
  ];
  await runSpawn(FFMPEG_PATH, cmd);
  return outPath;
}

function runSpawn(command: string, args: string[]): Promise<void> {
  return new Promise((resolve, reject) => {
    const p = spawn(command, args);

    p.on("close", (code) => {
      if (code === 0) resolve();
      else reject(new Error(`Command failed with code ${code}`));
    });
    p.on("error", reject);
  });
}

function str(val: any): string {
  return String(val);
}

function safeRemove(filePath: string | null) {
  if (!filePath) return;
  fs.unlink(filePath, (err) => {
    if (err && err.code !== "ENOENT")
      log("WARN", `Failed to delete temp file ${filePath}: ${err}`);
  });
}

async function processOne(pool: sql.ConnectionPool): Promise<boolean> {
  const row = await getNextVideoRow(pool);
  if (!row) {
    log("INFO", "No more Shopify videos to process.");
    return false;
  }

  const {
    video_id: videoId,
    video_url: sourceUrl,
    video_url_preview: existingPreviewUrl,
  } = row;
  log("INFO", `Processing video_id=${videoId} | source=${sourceUrl}`);

  let localSrc: string | null = null;
  let compressedLocal: string | null = null;
  let previewLocal: string | null = null;

  try {
    localSrc = await downloadToTemp(sourceUrl);
    log("INFO", `Downloaded source to temp: ${localSrc}`);

    compressedLocal = await compressVideo(localSrc);
    log("INFO", `Compressed video at: ${compressedLocal}`);

    const title = `com_${videoId}_${uuidv4().substring(0, 8)}`;
    const guidMain = await bunnyCreateVideo(title);
    if (!guidMain) {
      log(
        "ERROR",
        `Failed to create Bunny video container for video_id=${videoId}`
      );
      return true;
    }

    if (!(await bunnyUploadFileToVideo(guidMain, compressedLocal))) {
      log("ERROR", `Upload to Bunny failed for video_id=${videoId}`);
      return true;
    }

    const hlsUrl = buildHlsUrl(guidMain);
    await updateVideoMainHls(pool, videoId, hlsUrl);
    log("INFO", `Updated video_id=${videoId} main HLS URL: ${hlsUrl}`);

    if (existingPreviewUrl && existingPreviewUrl.includes("bunnycdn")) {
      log(
        "INFO",
        `Skipping preview generation for video_id=${videoId}, valid preview already exists.`
      );
    } else {
      log("INFO", `Generating new preview for video_id=${videoId}...`);
      previewLocal = await createPreviewClip(compressedLocal, PREVIEW_SECONDS);
      const previewTitle = `preview_${videoId}_${uuidv4().substring(0, 8)}`;
      const guidPreview = await bunnyCreateVideo(previewTitle);

      if (guidPreview) {
        if (await bunnyUploadFileToVideo(guidPreview, previewLocal)) {
          const transcodeSuccess = await waitForBunnyTranscode(guidPreview);
          if (transcodeSuccess) {
            const previewUrl = buildHlsUrl(guidPreview);
            await updateVideoPreviewUrl(pool, videoId, previewUrl);
            log(
              "INFO",
              `Updated video_id=${videoId} preview URL (m3u8): ${previewUrl}`
            );
          } else {
            log("ERROR", `Preview transcode failed for video_id=${videoId}`);
          }
        } else {
          log("ERROR", `Failed to upload preview for video_id=${videoId}`);
        }
      } else {
        log(
          "ERROR",
          `Failed to create preview container for video_id=${videoId}`
        );
      }
    }
  } catch (err: any) {
    log("ERROR", `Processing failed for video_id=${videoId}: ${err}`);
    await rollbackVideoStatus(pool, videoId, sourceUrl);
  } finally {
    if (DELETE_LOCAL) {
      safeRemove(localSrc);
      safeRemove(compressedLocal);
      safeRemove(previewLocal);
    }
  }

  return true;
}

async function workerMain() {
  if (!BUNNY_LIBRARY_ID || !BUNNY_API_KEY || !BUNNY_CDN_HOST) {
    log("ERROR", "Missing Bunny Environment Variables");
    return;
  }

  let pool: sql.ConnectionPool | null = null;
  try {
    pool = await getDbConnection();
    while (true) {
      const progressed = await processOne(pool);
      if (!progressed) break;
    }
  } catch (err) {
    log("ERROR", `Worker process hit a fatal error: ${err}`);
  } finally {
    if (pool) await pool.close();
    log("INFO", "Worker process shutting down.");
  }
}
export const startVideoProcessing = (): boolean => {
  if (isMainThread) {
    const runningTs = __filename.endsWith(".ts");
    // When running directly from TypeScript (ts-node/nodemon), Node can warn about
    // "MODULE_TYPELESS_PACKAGE_JSON". In that case, spin workers from an inline
    // CommonJS bootstrap that registers ts-node before requiring this file. When
    // running compiled JavaScript the workers will just load the JS file directly.
    const workerBootstrap = runningTs
      ? `require('ts-node/register'); require(${JSON.stringify(__filename)});`
      : null;

    const workers: Worker[] = [];
    let remaining = NUM_PROCESSES;
    let hadError = false;

    for (let i = 0; i < NUM_PROCESSES; i++) {
      const worker = runningTs
        ? new Worker(workerBootstrap as string, { eval: true })
        : new Worker(__filename);
      workers.push(worker);

      worker.on("exit", (code) => {
        if (code !== 0) hadError = true;
        remaining -= 1;
        if (remaining === 0) {
          if (hadError) {
            log("WARN", "All video workers finished; some exited with errors.");
          } else {
            log("INFO", "All video workers finished successfully.");
          }
        }
      });
    }
    return true;
  }
  return false;
};

if (isMainThread) {
  startVideoProcessing();
} else {
  workerMain();
}
