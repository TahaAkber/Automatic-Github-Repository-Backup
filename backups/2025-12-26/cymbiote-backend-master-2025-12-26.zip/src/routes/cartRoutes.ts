import express from "express";

import {
  assignUserToCartsController,
  deleteCartController,
  deleteCartItemsController,
  fetchCartController,
  getCartItems,
  syncCartController,
} from "../controllers/cartController";

const router = express.Router();

// Route to get all active Shopify stores
router.post("/cart-items", getCartItems);
router.post("/add-to-cart", syncCartController);
router.get("/cart", fetchCartController);
router.delete("/cart/:cartId", deleteCartController);
router.delete("/cart-item/:preCartItemId", deleteCartItemsController);
router.post("/assign-user", assignUserToCartsController);

export default router;
