import express from "express";
import {
  createFollowingLog,
  followingLog,
} from "../controllers/followingController";

const router = express.Router();

router.post("/create-following-log", createFollowingLog);
router.post("/user-following-log", followingLog);

export default router;
