import express from "express";
import {
  createOrderItemReview,
  reviewDetail,
  getReviewsByProductId,
  userReviews,
  deleteReview,
  postReviewComment,
  reactToReviewComment,
  reactToReview,
} from "../controllers/reviewController";

const router = express.Router();

router.post("/send-order-review", createOrderItemReview);
router.post("/user-reviews", userReviews);
router.post("/review-detail", reviewDetail);
router.post("/delete-review-detail", deleteReview);
router.get("/product/:productId", getReviewsByProductId);
router.post("/comment", postReviewComment);
router.post("/reaction", reactToReview);
router.post("/comment/reaction", reactToReviewComment);

export default router;
``