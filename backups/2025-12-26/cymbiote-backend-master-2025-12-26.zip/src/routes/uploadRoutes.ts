import { Router } from "express";
import { uploadFile } from "../controllers/uploadController";
import { upload } from "../middlewares/uploadMiddleware";

const router = Router();

// Endpoint to upload file
router.post("/", upload.single("file"), uploadFile);

export default router;
