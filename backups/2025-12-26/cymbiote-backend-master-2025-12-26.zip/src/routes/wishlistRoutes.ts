import express from "express";
import { createWishlistLog, wishlistLog } from "../controllers/whishlistController";

const router = express.Router();

router.post("/create-wishlist-log", createWishlistLog);
router.post("/user-wishlist-log", wishlistLog);

export default router;
