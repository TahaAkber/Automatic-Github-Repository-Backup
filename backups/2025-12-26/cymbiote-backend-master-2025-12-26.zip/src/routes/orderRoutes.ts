import express from "express";
import {
  createOrder,
  createStoreFrontOrder,
  fetchCancellationReasons,
  fetchLatestOrder,
  fetchOrderDetails,
  fetchOrderReceipt,
  fetchUserActiveOrders,
  fetchUserOrders,
  getDiscountOrdersRules,
  orderCancellation,
} from "../controllers/orderController";

const router = express.Router();

router.post("/create-order", createOrder);
router.get("/get-orders", fetchUserOrders);
router.get("/latest-order", fetchLatestOrder);
router.get("/order-details", fetchOrderDetails);
router.get("/order-receipt", fetchOrderReceipt);
router.get("/order-active", fetchUserActiveOrders);
router.get("/discount-rules", getDiscountOrdersRules);
router.post("/order-cancellation", orderCancellation);
router.post("/create-storefront-order", createStoreFrontOrder);
router.post("/get-cancellation-enums", fetchCancellationReasons);

export default router;
