import express from "express";
import {
  createProductHandler,
  getProductWithCategories,
  getProductDetailHandler,
  getProductsHandler,
} from "../controllers/productController";

const router = express.Router();

router.post("/", createProductHandler);
router.get("/all", getProductsHandler);
router.post("/product-detail", getProductDetailHandler);
router.get("/product-detail", getProductDetailHandler);
router.get("/filter/product-categories", getProductWithCategories);

export default router;