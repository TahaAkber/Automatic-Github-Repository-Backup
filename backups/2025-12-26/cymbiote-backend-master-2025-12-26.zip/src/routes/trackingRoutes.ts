import express from "express";
import {
  addCourierTracking,
  deleteManualTracking,
  getActiveCouriersController,
  getAllCourierTracking,
  getCourierTracking,
  getTrackingByOrder,
} from "../controllers/trackingController";

const router = express.Router();

// Route to get all active Shopify stores
router.get("/orderTracking", getTrackingByOrder);
router.get("/get-courier-trackings", getAllCourierTracking);
router.post("/add-custom-tracking", addCourierTracking);
router.get("/custom-trackings", getAllCourierTracking);
router.get("/custom-tracking", getCourierTracking);
router.delete("/custom-tracking", deleteManualTracking);
router.get("/couriers", getActiveCouriersController);

export default router;
