import express from "express";
import {
  getAppUpdateConfig,
  updateAppUpdateConfig,
} from "../controllers/appUpdateController";

const router = express.Router();

router.get("/config", getAppUpdateConfig);
router.put("/config/:id", updateAppUpdateConfig);

export default router;
