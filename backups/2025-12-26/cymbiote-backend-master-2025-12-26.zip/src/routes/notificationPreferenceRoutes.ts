import { Router } from "express";
import { upsertMerchantNotifPrefController } from "../controllers/notificationPreferenceController";

const router = Router();
router.post("/create", upsertMerchantNotifPrefController);
export default router;
