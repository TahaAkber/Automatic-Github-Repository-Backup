import express from "express";

// Recent Viewed Controllers
import {
  fetchRecentViewed,
  recentViewed,
} from "../controllers/recentController";

// Address Controllers
import {
  createAddressHandler,
  createDefaultAddress,
  deleteAddressHandler,
  deleteUserHandler,
  getAddressDetailHandler,
  getAddressHandler,
  updateAddressHandler,
} from "../controllers/addressController";
import { creatingUserIntrest, userIntrest } from "../controllers/userIntrest";

const router = express.Router();

// Recent Viewed Routes
router.post("/recent-viewed", recentViewed);
router.post("/recent-viewed-list", fetchRecentViewed);

// Address Routes
router.post("/create-address", createAddressHandler);
router.post("/update-address", updateAddressHandler);
router.post("/set-default-address", createDefaultAddress);
router.post("/get-address", getAddressHandler);
router.post("/get-address-detail", getAddressDetailHandler);
router.post("/delete-address", deleteAddressHandler);
router.post("/delete-user", deleteUserHandler);
// Intrest
router.post("/create-user-intrest", creatingUserIntrest);
router.post("/user-intrest", userIntrest);

export default router;
