import express from "express";
import { connectedAccountLog, createSocialAccountLog, getOrderFromOtherSources, removeConnectedAccount } from "../controllers/socialAccountController";

const router = express.Router();

router.post("/create-social-account-log", createSocialAccountLog);
router.post("/user-social-account-log", connectedAccountLog);
router.post("/remove-social-account-log", removeConnectedAccount);
router.post("/user-social-orders", getOrderFromOtherSources);

export default router;
