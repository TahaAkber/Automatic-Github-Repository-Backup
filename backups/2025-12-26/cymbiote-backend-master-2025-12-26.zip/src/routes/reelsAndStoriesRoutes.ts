import express from "express";
import {
  getLatestReelByOffsetController,
  getReelsByShopController,
  getReelsByShopIdController,
  getReelsByVideoIdController,
  GetSavedReelsController,
  likeReelController,
  SavedReelController,
  StoryController,
  updateReelViewCountController,
} from "../controllers/reelAndStoriesController";

const router = express.Router();

router.get("/shop/:shopId", getReelsByShopIdController);
router.get("/video/:videoId", getReelsByVideoIdController);
router.get("/latest-reel", getLatestReelByOffsetController);
router.get("/shop/:shopId/saved-reels", getReelsByShopController);
router.post("/save-reel", SavedReelController);
router.patch("/view/:videoId", updateReelViewCountController);
router.post("/like-reel", likeReelController);
router.get("/stories/:shopId", StoryController);
router.get("/saved-reels/:userId", GetSavedReelsController);

export default router;
