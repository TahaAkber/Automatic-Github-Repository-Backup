// src/routes/shopify.ts
import { Router, Request, Response } from "express";
import axios from "axios";
import dotenv from "dotenv";
import {
  chargeAMerchant,
  receiveAppMonitoring,
} from "../controllers/shopifyController";

dotenv.config();
const router = Router();

router.post("/charge-merchant", chargeAMerchant); // not currently being modified
router.get("/web-vitals-metrics", receiveAppMonitoring);

export default router;
