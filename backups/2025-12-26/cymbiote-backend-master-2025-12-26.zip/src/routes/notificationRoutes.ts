import express from "express";
import {
  createNotification,
  updateNotificationSetting,
  getNotifications,
  getuserNotification,
  sendNotification,
  getAppNotifications,
  getAppNotificationByUserId,
  readNotificationById,
} from "../controllers/notificationContoller";

const router = express.Router();

router.get("/all", getNotifications);
router.get("/app-notifications/all", getAppNotifications);
router.get("/app-notifications", getAppNotificationByUserId);
router.get("/read-notification", readNotificationById);
router.get("/user-notification", getuserNotification);
router.post("/create-notification", createNotification);
router.post("/update-notification", updateNotificationSetting);
router.post("/notify-user", sendNotification);

export default router;
