import express from "express";
import {
  userVerifierAccount,
  socialAccountLink,
  resetPassword,
  verifyOtp,
  sendOtp,
  signup,
  login,
  notificationTokenStore,
  logout,
} from "../controllers/authController";

const router = express.Router();

router.post("/store-notification-token", notificationTokenStore);
router.post("/user-verifier", userVerifierAccount);
router.post("/social-link", socialAccountLink);
router.post("/reset-password", resetPassword);
router.post("/verify-otp", verifyOtp);
router.post("/send-otp", sendOtp);
router.post("/signup", signup);
router.post("/logout", logout);
router.post("/login", login);

export default router;
