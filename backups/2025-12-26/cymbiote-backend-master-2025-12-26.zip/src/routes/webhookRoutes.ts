import { raw, Router } from "express";
import {
  captureFulfillmentsCreate,
  captureOrderDetails,
  captureTracking,
  handleInventoryWebhook,
  handleOrderCancelWebhook,
  handleProductUpdateWebhook,
  customersDataRedact,
  customersDataRequest,
  shopRedact,
  webvitalsMetrics,
  handleCollectionCreate,
  handleCollectionUpdate,
  handleCollectionDelete,
  captureFulfillmentsUpdate,
  removeAllWebhookSubscriptions,
} from "../controllers/webhookController";
import { verifyShopifyWebhook } from "../middlewares/verifyShopifyWebhook";

const router = Router();

router.get("/remove-webhook-subscriptions", removeAllWebhookSubscriptions);
router.post("/inventory-update", handleInventoryWebhook);
router.post("/products-update", handleProductUpdateWebhook);
router.post("/cancel-order", handleOrderCancelWebhook);
router.post("/collection-create", handleCollectionCreate);
router.post("/collection-update", handleCollectionUpdate);
router.post("/collection-delete", handleCollectionDelete);
router.post("/capture-tracking", captureTracking);
router.post("/capture-fulfillment", captureFulfillmentsCreate);
router.post("/capture-order", captureOrderDetails);
router.post("/update-fulfillment", captureFulfillmentsUpdate);
router.post(
  "/shop/redact",
  raw({ type: "application/json" }),
  verifyShopifyWebhook,
  shopRedact
);
router.post(
  "/customers/redact",
  raw({ type: "application/json" }),
  verifyShopifyWebhook,
  customersDataRedact
);
router.post(
  "/customers/data-request",
  raw({ type: "application/json" }),
  verifyShopifyWebhook,
  customersDataRequest
);
router.post("/web-vitals-metrics", webvitalsMetrics);

export default router;
