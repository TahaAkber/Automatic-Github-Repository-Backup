import express from "express";
import { getAnalyticsController } from "../controllers/analyticsController";

const router = express.Router();
router.get("/get-details", getAnalyticsController);
export default router;
