import express from "express";
import { startVideoWorker } from "../controllers/videoWorkerController";

const router = express.Router();

router.post("/start", startVideoWorker);

export default router;
