import express from "express";
import { createMetaObjectEntry } from "../controllers/metafieldController";
const router = express.Router();

router.post("/createMetaObject", createMetaObjectEntry);

export default router;
