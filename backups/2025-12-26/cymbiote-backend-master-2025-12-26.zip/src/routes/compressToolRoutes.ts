import express from "express";
import {
  compressTileVideos,
  compressRNSVideos,
  compressProductImages,
} from "../controllers/compressToolController";

const router = express.Router();

router.get("/tile-videos", compressTileVideos);
router.get("/rns-videos", compressRNSVideos);
router.get("/product-images", compressProductImages);

export default router;
