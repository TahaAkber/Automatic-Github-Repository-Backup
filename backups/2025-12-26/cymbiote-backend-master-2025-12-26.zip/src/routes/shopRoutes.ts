import express from "express";
import {
  searchShops,
  getShopReels,
  shopCategories,
  getRelatedShops,
  getProductByShop,
  shopSubCategories,
  getShopTaxonomies,
  getAllShopifyStores,
  getcollectionbyShopid,
  getRelatedShopProducts,
  getShopCollectionProducts,
  getAllTrendingCollections,
  getTrendingCollectionByIdController,
  getCollectionByIdController,
  getFilteredCollectionByIdController,
} from "../controllers/shopController";

const router = express.Router();

// Route to get all active Shopify stores
router.get("/all", getAllShopifyStores);
router.get("/search", searchShops);
router.get("/filter-products", getShopCollectionProducts);
router.get("/collection", getcollectionbyShopid);
router.get("/trending-collections", getAllTrendingCollections);
router.get("/trending-collection/:id", getTrendingCollectionByIdController);
router.get("/filtered-collection/:id", getFilteredCollectionByIdController);
router.get("/collection/:id", getCollectionByIdController);
router.post("/shop-products", getProductByShop);
router.post("/shop-reel", getShopReels);
router.post("/shop-related", getRelatedShops);
router.post("/category-related-product", getRelatedShopProducts);
router.post("/shop-categories", shopCategories);
router.post("/shop-sub-categories", shopSubCategories);
router.get("/taxonomies-categories", getShopTaxonomies);

export default router;
