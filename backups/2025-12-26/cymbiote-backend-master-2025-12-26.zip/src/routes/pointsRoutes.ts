import express from "express";
import {
  addPoints,
  generatePointsVoucher,
  getActiveCriteria,
  getUserVouchers,
  getUserPoints,
  spendPoints,
} from "../controllers/pointsController";

const router = express.Router();

router.get("/criteria", getActiveCriteria);
router.post("/add", addPoints);
router.get("/user/:userId", getUserPoints);
router.get("/user/voucher/:userId", getUserVouchers);
router.post("/points/spend", spendPoints);
router.post("/voucher", generatePointsVoucher);

export default router;
