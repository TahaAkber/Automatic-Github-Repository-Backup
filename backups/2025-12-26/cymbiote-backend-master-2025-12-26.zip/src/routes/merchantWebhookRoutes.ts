import { Router } from "express";
import { handleProductCreate } from "../controllers/merchantWebhookController";

const router = Router();

router.post("/product-create", handleProductCreate);

export default router;
