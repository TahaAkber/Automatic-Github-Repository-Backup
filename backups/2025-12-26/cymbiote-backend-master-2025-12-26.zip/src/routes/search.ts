import { Router } from "express";
import { searchCarrierJson } from "../controllers/searchController";

const router = Router();

router.get("/carrier", searchCarrierJson);

export default router;
