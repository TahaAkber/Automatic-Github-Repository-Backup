// Define the User creation payload type
export interface RecentView {
  user_id: number;
  recent_view_type: string;
  recent_view_product_id: number;
  recent_view_shop_id: number;
}
