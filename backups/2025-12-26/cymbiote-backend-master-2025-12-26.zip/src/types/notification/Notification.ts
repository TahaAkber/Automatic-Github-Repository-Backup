export type NotificationKey =
  | "notification_setting_pricedrop"
  | "notification_setting_stock_available"
  | "notification_setting_abandone_cart"
  | "notification_setting_abandoned_cart"
  | "notification_setting_remind_review"
  | "notification_setting_order_create"
  | "notification_setting_order_update"
  | "notification_setting_order_shipped"
  | "notification_setting_order_intransit"
  | "notification_setting_order_dispatched"
  | "notification_setting_order_delivered"
  | "notification_setting_order_picked_up"
  | "notification_setting_order_refunded"
  | "notification_setting_offers_n_updates"
  | "notification_setting_messages"
  | "notification_setting_tracking"
  | "notification_setting_shopping";

export type BaseMessage = {
  title: string;
  body: string;
  screenName?: string;
  type?: string;
  productId?: string;

  payload?: Record<string, any>;
};

export const EVENT_RULES = {
  RESTOCK: ["RESTOCK_ALERT"],
  NEW_ARRIVAL: ["NEW_ARRIVAL_ALERT"],
  SPECIAL_OFFERS: ["SPECIAL_OFFERS"],
  NEW_COLLECTION: ["NEW_COLLECTION_ADDED"],
  // MOST_POPULAR: ["MOST_POPULAR_PRODUCTS"],
} as const;

export const PRICE_DROP_NOTIF_KEY = "SPECIAL_OFFERS";

export type VariantPriceDrop = {
  variantId: string | number;
  oldPrice: number;
  newPrice: number;
  variantTitle?: string;
};

export interface MessageData {
  title: string;
  body: string;
  DeviceToken?: string;
  screenName: string;
  productId: string;
  variantId: string;
  notificationImageUrl: string;
  image: string;
  type: "token";
  payload: string;
}

export interface NewProductVariant {
  _id?: string;
  admin_graphql_api_id?: string | number;
  id?: string | number;
}
export interface Product {
  product_id?: number;
  product_name: string;
  product_quantity: number;
  product_variant?: NewProductVariant;
  product_shopify_category: string;
  product_shop_id: number;
  product_custom_category?: string;
  product_shopify_id?: string;
  product_price?: number;
  product_description?: string;
  product_image_url?: string;
}
