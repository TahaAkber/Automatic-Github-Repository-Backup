export interface AnalyticsParams {
  // Date filters
  start_date?: string;
  end_date?: string;

  // Event filters
  event_name?: string;
  event_type?: string; // product_detail, shop_view, home_view, search_query, etc.

  // User filters
  user_name?: string;
  user_id?: string;
  device_id?: string;

  // Merchant/Shop filters
  merchant_id?: string;
  merchant_name?: string;
  shop_id?: string;
  shop_name?: string;
  shop_tile_type?: string; // featured, trending, etc.
  merchant_shopify_id?: string;

  // Product filters
  product_id?: string;
  product_name?: string;

  // Search filters
  search_query?: string;
  result_type?: string; // product, shop
  is_from_search?: boolean;

  // Screen/View filters
  screen_name?: string;

  // Deal filters
  deal_id?: string;

  // Position filters
  position_in_results?: number;
  position_in_list?: number;
  tile_position?: number;
  product_position_in_tile?: number;

  // Time/Duration filters
  min_screen_time_seconds?: number;
  max_screen_time_seconds?: number;

  // View count filters
  min_product_view?: number;
  max_product_view?: number;
  min_merchant_view?: number;
  max_merchant_view?: number;

  // Count filters for search results
  min_total_results?: number;
  max_total_results?: number;
  min_products_count?: number;
  max_products_count?: number;
  min_shops_count?: number;
  max_shops_count?: number;

  // Platform filter
  platform?: string;

  // Geo filters
  country?: string;
  city?: string;

  // Reel/Video filters
  video_url_id?: string;
  video_id?: number;
  is_liked?: boolean;
  min_watch_duration_seconds?: number;
  max_watch_duration_seconds?: number;
  min_completion_rate?: number;
  max_completion_rate?: number;

  // Product Detail filters
  current_product_id?: number;
  clicked_product_id?: number;
  variant_id?: number;
  action_type?: string; // 'add_to_cart', 'buy_now', 'quantity_change'
  quantity?: number;
  shop_currency?: string;

  // Collection filters
  collection_id?: number;
  collection_name?: string;
  from_collection_id?: number;
  to_collection_id?: number;

  // Navigation filters
  from_tab?: string;
  to_tab?: string;
  from_screen?: string;
  to_screen?: string;

  // Filter change tracking
  filter_type?: string;
  filter_value?: string;

  // Item tracking
  item_id?: string;
  item_type?: string; // 'product', 'shop'

  // Brand page filters
  is_from_brand_page?: boolean;
  click_order?: number;

  // View duration filters
  min_view_duration_seconds?: number;
  max_view_duration_seconds?: number;

  // Pagination
  limit?: number;
  offset?: number;
}
