export interface ParsedDHLResponse {
  number: string;
  carrier: number;
  param: any;
  tag: string;
  track_info: any;
}
