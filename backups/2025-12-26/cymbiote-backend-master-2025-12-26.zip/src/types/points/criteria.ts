export interface Criteria {
  applyType: string;
  criteriaId: number;
  orderItemPrice?: number;
}
