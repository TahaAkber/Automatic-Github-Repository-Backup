interface CartItem {
  pre_cart_item_id?: number;
  pre_cart_item_variant_id: number;
  pre_cart_item_quantity: number;
}
export interface SyncCartPayload {
  cart_id: string;
  deviceIdentifier: string;
  user_id: number;
  shop_id: number;
  pre_cart_items: CartItem[];
}

export type ProductVariantItem = {
  product_variant: {
    product: {
      product_id: number;
      product_title: string;
      product_image_url: string;
      product_is_active: boolean;
    };
    variant: {
      variant_id: number;
      variant_price: number;
      variant_quantity: number;
      pre_cart_item_quantity: number;
      selected_options: string[];
      images: {
        preview: {
          image: {
            url: string;
          };
        };
      }[];
    };
  };
};

export type CartShop = {
  shop: {
    shop_id: number;
    shop_name: string;
    shop_logo: string;
    shop_currency: string;
    shop_is_active: boolean;
    shop_delisted: boolean;
  };
  products: ProductVariantItem[];
};

export interface FetchCartParams {
  user_id?: number;
  deviceIdentifier?: string;
}

export interface ProductVariant {
  variant_id: number;
  qty: number;
}
export interface RawCartItem {
  shop_id: number;
  pre_cart_id: string;
  product_variant: ProductVariant[];
}
