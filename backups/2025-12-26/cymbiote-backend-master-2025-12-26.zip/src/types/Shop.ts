export interface Shop {
  shop_name: string;
  shop_description: string;
  shop_shopify_id: string;
  shop_id: number;
  shop_access_token: string;
  shop_domain: string;
  shop_selected_order_view: string;
  shop_selectedOrder: string;
  shop_banner_url: string;
  shop_logo_url: string;
  shop_tile_type: string;
  shop_banner_type: string;
  shop_header_type: string;
  shop_delisted: boolean;
  shop_is_active: boolean;
  shop_inventory_update_webhook_id: string;
  shop_order_create_webhook_id: string;
  shop_fulfillment_create_webhook_id: string;
  shop_order_cancellation_webhook_id: string;
  shop_product_update_webhook_id: string;
  shop_currency?: string;
  shop_color: string;
  shop_category: string;
  package_rate: number;
  subscription_id?: number;
  created_at: Date;
  updated_at: Date;
}

export type SortBy = "product_rating" | "product_name" | "price" | "created_at";
export type SortOrder = "ASC" | "DESC";
export interface Collection {
  collection_id: number;
  collection_name: string;
  // add other fields as needed
}

export interface CollectProduct {
  collection_local_product_id: number;
  // add other fields as needed
}

export interface Variant {
  variant_id: number;
  variant_shopify_id: string | null;
  variant_price: number;
  variant_discounted_price: number;
  variant_quantity: number;
  variant_color: string | null;
  variant_image_url: string | null;
  variant_product_id: number;
  variant_name: string;
  variant_inventory_id: string | null;
  created_at: string;
  updated_at: string;
  images: any[];
  selected_options: {
    name: string;
    value: string;
  }[];
}

export interface Product {
  product_id: number;
  product_name: string;
  product_shopify_category: string;
  product_custom_category_id: string;
  product_custom_category: string;
  product_shopify_id: string;
  product_shop_id: number;
  product_description: string;
  product_image_url: string;
  product_is_active: boolean;
  created_date: string;
  created_at: string;
  updated_at: string;
  product_rating: number;
  rn: string | null;
  product_review: number;
  product_variant: Variant[];
}
