export interface PendingOrders {
  order_id?: number;
  order_date: Date;
  order_total_amount: number;
  order_delivery_address: string;
  order_customer_id: number;
  order_shop_id: number;
  order_title: string;
  order_fulfillment_status: string;
  order_shopify_id: string;
  order_charge_rate: number;
  shop_currency: string;
  shop_access_token: string;
  shop_domain: string;
  subscription_id: number;
  subscription_appRecurringPricingDetails_id: string;
  subscription_appUsagePricingDetails_id: string;
}
