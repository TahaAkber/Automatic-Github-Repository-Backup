export interface DBOrder {
  order_id?: number;
  order_date: Date;
  order_total_amount: number;
  order_delivery_address: string;
  order_user_id: number;
  order_shop_id: number;
  order_fulfillment_status: string;
  order_shopify_id: string;
  order_charge_rate: number;
  order_title: string;
  order_shipping: number;
  order_payment_status: string;
  order_tax: number;
  order_tax_rate: number;
  order_channel: string;
  order_total_discount_amount: number;
}
