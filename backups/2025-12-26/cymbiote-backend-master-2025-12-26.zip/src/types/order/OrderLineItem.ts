export interface OrderLineItem {
  variant_id: string;
  quantity: number;
}
