export interface LineItem {
  variant_id: number;
  quantity: number;
}
