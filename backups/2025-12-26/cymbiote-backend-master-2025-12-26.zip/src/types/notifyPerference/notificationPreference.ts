// types/notifyPerference/notificationPreference.ts
export type Preference = "none" | "all" | "personalized";

export const PREF_MAP: Record<Preference, number> = {
  all: 0,
  personalized: 1,
  none: 2,
};

// Allowed codes (the ONLY ones we store)
export const ALLOWED_CODES = [
  "NEW_ARRIVAL_ALERT",
  "NEW_COLLECTION_ADDED",
  "SPECIAL_OFFERS",
  "RESTOCK_ALERT",
] as const;

export type NotificationCode = (typeof ALLOWED_CODES)[number];

export const isAllowedCode = (v: unknown): v is NotificationCode =>
  typeof v === "string" && (ALLOWED_CODES as readonly string[]).includes(v);

export function sanitizeRules(input?: any[]): NotificationCode[] {
  if (!Array.isArray(input)) return [];
  const codes = input.map((x) => (typeof x === "string" ? x : x?.code));
  const seen = new Set<string>();
  return codes
    .filter(isAllowedCode)
    .filter((c) => (seen.has(c) ? false : (seen.add(c), true)));
}
