export interface ReviewReactionPayload {
    reviewId: number;
    reactorType: 'user' | 'shop';
    reactorId: number;
    reactionType: 'like' | 'dislike';
    reactionRemove?: boolean;
  }