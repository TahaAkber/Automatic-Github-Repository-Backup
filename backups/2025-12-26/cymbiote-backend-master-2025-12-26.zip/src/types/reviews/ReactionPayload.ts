export interface ReactionPayload {
  commentId: number;
  reactorType: "user" | "shop";
  reactorId: number;
  reactionType: "like" | "dislike";
}
