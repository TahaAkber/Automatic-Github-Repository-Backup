export interface CreateCommentParams {
  reviewId: number;
  parentCommentId?: number;
  commenterType: "user" | "shop";
  commenterId: number;
  commentText: string;
}
