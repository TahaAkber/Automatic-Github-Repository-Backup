export interface VerifyOtpRequest {
  email: string;
  otp: string;
  rememberDevice: boolean;
}
