export interface Address {
  address_id?: number;
  address_user_id: number;
  address_first_name: string;
  address_last_name: string;
  address_country: string;
  address_one: string;
  address_two: string;
  address_city: string;
  address_postal_code?: number;
  address_number?: number;
  address_default_select?: boolean;
}
