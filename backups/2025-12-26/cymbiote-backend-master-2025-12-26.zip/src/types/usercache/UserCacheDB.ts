export interface UserCacheDB {
  cache_id: string;
  cache_user_id: string;
  cache_json: string;
}
