export interface DiscountNode {
    id: string;
    codeDiscount: {
      title: string;
      summary?: string;
      codesCount?: {
        count: number;
      };
    };
  }