export interface CreateDiscountCodeReturn {
  id: string;
  codeDiscount: codeDiscount;
  code: string;
}

interface codeDiscount {
  title: string;
  startsAt: Date;
  endsAt: Date;
}
