export interface VariantsWithDiscount {
    variant_shopify_id: string
    variant_price: number;
    variant_discounted_price: number;
    variant_price_off: number;
}