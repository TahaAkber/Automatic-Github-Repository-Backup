import { LineItem } from "./LineItem";

export interface CreateOrderRequest {
  shop: string;
  lineItems: LineItem[];
}
