export interface TrackingEvent {
  time: string;
  status: string;
  description: string;
}
