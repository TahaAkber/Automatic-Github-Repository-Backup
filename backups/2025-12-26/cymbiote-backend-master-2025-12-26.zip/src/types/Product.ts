export interface Product {
  product_id?: number;
  product_name: string;
  product_quantity: number;
  product_variant?: any;
  product_shopify_category: string;
  product_custom_category?: string;
  product_shopify_id?: string;
  product_price?: number;
  product_description?: string;
  product_image_url?: string;
}
