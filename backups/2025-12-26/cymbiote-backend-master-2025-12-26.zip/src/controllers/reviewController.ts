import { Request, Response } from "express";

import {
  addOrderItemReview,
  createReviewCommentService,
  fetchReviewDetail,
  fetchUserReviews,
  getProductReviewS,
  handleReactionService,
  handleReviewReactionService,
} from "../services/reviews";
import { deleteOrderItemReviewById } from "../models/reviews/reviewsModel";
import { sendErrorEmail } from "../services/emailService";

export const createOrderItemReview = async (req: Request, res: Response) => {
  const {
    order_item_review_rating,
    order_item_review_comment,
    order_item_id,
    images,
  } = req.body;
  try {
    const response = await addOrderItemReview(
      order_item_id,
      order_item_review_rating,
      order_item_review_comment,
      images
    );

    return res.status(200).json({ ...response, status: 200 });
  } catch (error: any) {
    sendErrorEmail("createOrderItemReview error.", error, req.body);
    return res.status(200).json({
      status: 500,
      message: error?.message || "Internal server error.",
    });
  }
};

export const userReviews = async (req: Request, res: Response) => {
  const user_id = parseInt(req.query.user_id as string);
  const page = parseInt(req.query.page as string) || 1;
  const pageSize = parseInt(req.query.pageSize as string) || 10;
  const status = parseInt(req.query.status as string) || 0;
  try {
    if (!user_id) {
      return res.status(200).json({
        status: 400,
        message: "user_id is required.",
      });
    }
    const result = await fetchUserReviews(user_id, page, pageSize, status);
    return res.status(200).json({
      status: 200,
      message: "fetch reviews successfully.",
      data: result,
    });
  } catch (error: any) {
    sendErrorEmail("userReviews error.", error, req.query);
    return res
      .status(200)
      .json({ status: 500, message: "Internal server error." });
  }
};

export const reviewDetail = async (req: Request, res: Response) => {
  const { order_item_review_id, user_id } = req.body;
  try {
    if (!order_item_review_id) {
      return res.status(200).json({
        status: 400,
        message: "order_item_review_id is required.",
      });
    }
    const result = await fetchReviewDetail(order_item_review_id, user_id);
    return res.status(200).json(result);
  } catch (error: any) {
    sendErrorEmail("reviewDetail error.", error, req.body);
    return res
      .status(200)
      .json({ status: 500, message: "Internal server error." });
  }
};

export const getReviewsByProductId = async (req: Request, res: Response) => {
  try {
    const productId = parseInt(req.params.productId);
    const userId = parseInt(req.query.userId as string);

    if (isNaN(productId) || productId <= 0) {
      return res
        .status(400)
        .json({ status: 400, error: "Invalid or missing product ID" });
    }

    if (isNaN(userId) || userId <= 0) {
      return res
        .status(400)
        .json({ status: 400, error: "Invalid or missing user ID" });
    }

    const reviews = await getProductReviewS(productId, userId);

    return res.status(200).json({
      status: 200,
      message: "Product reviews fetched successfully.",
      productReviews: reviews,
    });
  } catch (error: any) {
    sendErrorEmail("Error in getReviewsByProductId:", error, {
      ...req.query,
      ...req.params,
    });
    console.error("Error in getReviewsByProductId:", error);
    return res
      .status(500)
      .json({ status: 500, error: error.message || "Internal server error" });
  }
};

export const deleteReview = async (req: Request, res: Response) => {
  try {
    const order_item_review_id = parseInt(req.body.order_item_review_id);
    await deleteOrderItemReviewById(order_item_review_id);
    return res.status(200).json({
      status: 200,
      message: "Review deleted successfully.",
    });
  } catch (error: any) {
    sendErrorEmail("deleteReview error", error, req.body);
    return res
      .status(200)
      .json({ status: 500, error: error.message || "Internal server error" });
  }
};

export const postReviewComment = async (req: Request, res: Response) => {
  try {
    const {
      reviewId,
      parentCommentId,
      commenterType,
      commenterId,
      commentText,
    } = req.body;

    if (!reviewId || !commenterType || !commenterId || !commentText) {
      return res
        .status(200)
        .json({ status: 400, error: "Missing required fields" });
    }

    const validTypes = ["shop", "user"];
    if (!validTypes.includes(commenterType)) {
      return res
        .status(200)
        .json({ status: 400, error: "Invalid commenter type" });
    }

    const result = await createReviewCommentService({
      reviewId,
      parentCommentId,
      commenterType,
      commenterId,
      commentText,
    });

    return res.status(201).json({
      status: 201,
      message: "Comment added successfully",
      data: result,
    });
  } catch (error: any) {
    sendErrorEmail("Error in postReviewComment:", error, req.body);
    console.error("Error in postReviewComment:", error);
    return res
      .status(200)
      .json({ status: 500, error: error.message || "Internal server error" });
  }
};

export const reactToReviewComment = async (req: Request, res: Response) => {
  try {
    const { commentId, reactorType, reactorId, reactionType } = req.body;

    if (!commentId || !reactorType || !reactorId || !reactionType) {
      return res
        .status(200)
        .json({ status: 400, error: "Missing required fields" });
    }

    const validTypes = ["user", "shop"];
    if (!validTypes.includes(reactorType)) {
      return res
        .status(200)
        .json({ status: 400, error: "Invalid reactor type" });
    }

    const validReactions = ["like", "dislike"];
    if (!validReactions.includes(reactionType)) {
      return res
        .status(200)
        .json({ status: 400, error: "Invalid reaction type" });
    }

    const result = await handleReactionService({
      commentId,
      reactorType,
      reactorId,
      reactionType,
    });

    return res
      .status(200)
      .json({ status: 200, message: "Reaction saved", data: result });
  } catch (error: any) {
    sendErrorEmail("Error in reactToReviewComment:", error, req.body);
    console.error("Error in reactToReviewComment:", error);
    return res
      .status(200)
      .json({ status: 500, error: error.message || "Internal server error" });
  }
};

export const reactToReview = async (req: Request, res: Response) => {
  try {
    const { reviewId, reactorType, reactorId, reactionType, reactionRemove } =
      req.body;

    if (!reviewId || !reactorType || !reactorId || !reactionType) {
      return res
        .status(200)
        .json({ status: 400, error: "Missing required fields" });
    }

    const validTypes = ["user", "shop"];
    if (!validTypes.includes(reactorType)) {
      return res
        .status(200)
        .json({ status: 400, error: "Invalid reactor type" });
    }

    const validReactions = ["like", "dislike"];
    if (!validReactions.includes(reactionType)) {
      return res
        .status(200)
        .json({ status: 400, error: "Invalid reaction type" });
    }

    const result = await handleReviewReactionService({
      reviewId,
      reactorType,
      reactorId,
      reactionType,
      reactionRemove,
    });

    return res.status(200).json({
      status: 200,
      message: reactionRemove ? "Reaction deleted" : "Reaction recorded",
    });
  } catch (error: any) {
    sendErrorEmail("Error in reactToReview:", error, req.body);
    console.error("Error in reactToReview:", error);
    return res
      .status(200)
      .json({ status: 500, message: error.message || "Internal server error" });
  }
};
