import { Request, Response } from "express";
import { fetchFulfilledOrders } from "../services/orders";
import { getShop } from "../models/shops/shopModel";
import { sendErrorEmail } from "../services/emailService";

export const chargeAMerchant = async (req: Request, res: Response) => {
  const { shop, lineItems } = req.body;

  try {
    const session = await getShop(shop);
    if (session.length < 1) {
      return res.status(404).json({
        orders: [],
        message: "no session for this shop found",
      });
    }
    const orders = await fetchFulfilledOrders(shop, session);
  } catch (error: any) {
    sendErrorEmail("Error in charging a merchant:", error, req.body);
    console.error("Error in charging a merchant:", error);
  }
};

export const receiveAppMonitoring = async (req: Request, res: Response) => {
  try {
    console.log("monitoring received", req.body);

    res.status(200).json({
      status: 200,
      message: "success",
    });
  } catch (error: any) {
    sendErrorEmail("Error receiving app monitoring data", error, req.body);
    return res.status(200).json({
      status: 500,
      message: "Error receiving app monitoring data",
      error: error.message || "Unknown error",
    });
  }
};
