// controllers/analyticsController.ts
import { Request, Response } from "express";
import { fetchAnalyticsFromFirebase } from "../services/analyticsService";
import { AnalyticsParams } from "../types/analytics/Analytics";
import { sendErrorEmail } from "../services/emailService";

export const getAnalyticsController = async (req: Request, res: Response) => {
  try {
    const {
      // Date filters
      start_date,
      end_date,

      // Event filters
      event_name,
      event_type,

      // User filters
      user_name,
      user_id,
      device_id,

      // Merchant/Shop filters
      merchant_id,
      merchant_name,
      shop_id,
      shop_name,
      shop_tile_type,
      merchant_shopify_id,

      // Product filters
      product_id,
      product_name,

      // Search filters
      search_query,
      result_type,
      is_from_search,

      // Screen/View filters
      screen_name,

      // Deal filters
      deal_id,

      // Position filters
      position_in_results,
      position_in_list,
      tile_position,
      product_position_in_tile,

      // Time/Duration filters
      min_screen_time_seconds,
      max_screen_time_seconds,

      // View count filters
      min_product_view,
      max_product_view,
      min_merchant_view,
      max_merchant_view,

      // Count filters for search results
      min_total_results,
      max_total_results,
      min_products_count,
      max_products_count,
      min_shops_count,
      max_shops_count,

      // Platform filter
      platform,

      // Geo filters
      country,
      city,

      // Pagination
      limit,
      offset,
    } = req.query;

    const searchParams: AnalyticsParams = {
      // Date filters
      start_date: start_date ? start_date.toString() : undefined,
      end_date: end_date ? end_date.toString() : undefined,

      // Event filters
      event_name: event_name ? event_name.toString() : undefined,
      event_type: event_type ? event_type.toString() : undefined,

      // User filters
      user_name: user_name ? user_name.toString() : undefined,
      user_id: user_id ? user_id.toString() : undefined,
      device_id: device_id ? device_id.toString() : undefined,

      // Merchant/Shop filters
      merchant_id: merchant_id ? merchant_id.toString() : undefined,
      merchant_name: merchant_name ? merchant_name.toString() : undefined,
      shop_id: shop_id ? shop_id.toString() : undefined,
      shop_name: shop_name ? shop_name.toString() : undefined,
      shop_tile_type: shop_tile_type ? shop_tile_type.toString() : undefined,
      merchant_shopify_id: merchant_shopify_id ? merchant_shopify_id.toString() : undefined,

      // Product filters
      product_id: product_id ? product_id.toString() : undefined,
      product_name: product_name ? product_name.toString() : undefined,

      // Search filters
      search_query: search_query ? search_query.toString() : undefined,
      result_type: result_type ? result_type.toString() : undefined,
      is_from_search: is_from_search ? is_from_search === 'true' : undefined,

      // Screen/View filters
      screen_name: screen_name ? screen_name.toString() : undefined,

      // Deal filters
      deal_id: deal_id ? deal_id.toString() : undefined,

      // Position filters
      position_in_results: position_in_results ? parseInt(position_in_results.toString()) : undefined,
      position_in_list: position_in_list ? parseInt(position_in_list.toString()) : undefined,
      tile_position: tile_position ? parseInt(tile_position.toString()) : undefined,
      product_position_in_tile: product_position_in_tile ? parseInt(product_position_in_tile.toString()) : undefined,

      // Time/Duration filters
      min_screen_time_seconds: min_screen_time_seconds ? parseFloat(min_screen_time_seconds.toString()) : undefined,
      max_screen_time_seconds: max_screen_time_seconds ? parseFloat(max_screen_time_seconds.toString()) : undefined,

      // View count filters
      min_product_view: min_product_view ? parseInt(min_product_view.toString()) : undefined,
      max_product_view: max_product_view ? parseInt(max_product_view.toString()) : undefined,
      min_merchant_view: min_merchant_view ? parseInt(min_merchant_view.toString()) : undefined,
      max_merchant_view: max_merchant_view ? parseInt(max_merchant_view.toString()) : undefined,

      // Count filters for search results
      min_total_results: min_total_results ? parseInt(min_total_results.toString()) : undefined,
      max_total_results: max_total_results ? parseInt(max_total_results.toString()) : undefined,
      min_products_count: min_products_count ? parseInt(min_products_count.toString()) : undefined,
      max_products_count: max_products_count ? parseInt(max_products_count.toString()) : undefined,
      min_shops_count: min_shops_count ? parseInt(min_shops_count.toString()) : undefined,
      max_shops_count: max_shops_count ? parseInt(max_shops_count.toString()) : undefined,

      // Platform filter
      platform: platform ? platform.toString() : undefined,

      // Geo filters
      country: country ? country.toString() : undefined,
      city: city ? city.toString() : undefined,

      // Pagination
      limit: limit ? parseInt(limit.toString()) : undefined,
      offset: offset ? parseInt(offset.toString()) : undefined,
    };

    const result = await fetchAnalyticsFromFirebase(searchParams);

    return res.status(result.status).json(result);
  } catch (error: any) {
    sendErrorEmail("Failed to fetch analytics data", error, req.body);
    console.error("Error in getAnalyticsController:", error);
    return res.status(500).json({
      status: 500,
      message: "Failed to fetch analytics data",
    });
  }
};
