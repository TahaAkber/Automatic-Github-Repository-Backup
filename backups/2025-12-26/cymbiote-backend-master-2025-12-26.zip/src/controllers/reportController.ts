import { Request, Response } from "express";
import { submitReportService } from "../services/reportService";
import { CreateReportParams } from "../models/reports/reportModel";

export const submitReport = async (req: Request, res: Response) => {
  try {
    const {
      reported_type,
      reported_reference_id,
      reported_by_user_id,
      reported_reason_main,
      reported_reason_sub,
      reported_reason_other_text,
      reported_has_order,
      reported_order_id,
    } = req.body;

    if (!reported_type) {
      return res.status(400).json({
        success: false,
        message: "reported_type is required",
      });
    }

    if (!reported_reference_id) {
      return res.status(400).json({
        success: false,
        message: "reported_reference_id is required",
      });
    }

    if (!reported_by_user_id) {
      return res.status(400).json({
        success: false,
        message: "reported_by_user_id is required",
      });
    }

    if (!reported_reason_main) {
      return res.status(400).json({
        success: false,
        message: "reported_reason_main is required",
      });
    }

    const validTypes = ["shop", "product", "reel", "story"];
    if (!validTypes.includes(reported_type)) {
      return res.status(400).json({
        success: false,
        message: `reported_type must be one of: ${validTypes.join(", ")}`,
      });
    }

    const reportData: CreateReportParams = {
      reported_type,
      reported_reference_id: Number(reported_reference_id),
      reported_by_user_id: Number(reported_by_user_id),
      reported_reason_main,
      reported_reason_sub,
      reported_reason_other_text,
      reported_has_order,
      reported_order_id,
    };

     await submitReportService(reportData);

    return res.status(201).json({
      status: 201,
      message: "Report submitted successfully",
    });
  } catch (error: any) {
    console.error("Error in submitReport controller:", error);
    return res.status(500).json({
      success: false,
      message: "Failed to submit report",
      error: error.message,
    });
  }
};
