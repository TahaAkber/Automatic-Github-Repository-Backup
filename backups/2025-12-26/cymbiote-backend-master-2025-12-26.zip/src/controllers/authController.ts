import { sendErrorEmail, sendOtpEmail } from "../services/emailService";
import { generateOtp, saveOtpS, verifyOtpS } from "../services/otpService";
import {
  checkDeviceDetails,
  createSocialLink,
  getUserByEmail,
  getUserByEmailOrUsername,
  getUserBySocialIdAndType,
  saveDeviceDetails,
} from "../models/users/user";
import { Request, Response } from "express";
import {
  generateToken,
  loginSocialUser,
  loginUser,
  loginUserNoticationSave,
  logoutUser,
  sendOtpS,
  signUpSocialUser,
  signUpUser,
  updateUserPassword,
  userVerifier,
} from "../services/authService";
import { createNotificationService } from "../services/notificationService";

export const signup = async (req: Request, res: Response) => {
  const { email, password, phone, username, firstname, lastname,gender,
dateofbirth } = req.body;

  if (!email || !password) {
    return res
      .status(200)
      .json({ status: 400, error: "Email and password are required." });
  }

  if (!username || !firstname || !lastname || !phone) {
    return res.status(200).json({
      status: 400,
      message: "Username, Phone, Firstname and Lastname are required.",
    });
  }

  try {
    // Fetch user by email or username
    const user = await getUserByEmailOrUsername(email || username);

    // If the user already exists, return conflict error
    if (user) {
      return res
        .status(200)
        .json({ status: 409, message: "Email already exists." });
    }

    // Sign up the new user (insert into database)
    const userDetails = await signUpUser(
      email,
      phone,
      password,
      username,
      firstname,
      lastname,gender,
dateofbirth
    );
    await createNotificationService(userDetails.userId);
    // Generate OTP and send email
    const otp = generateOtp();
    await saveOtpS(email, otp);
    await sendOtpEmail(email, otp);
    return res
      .status(200)
      .json({ status: 200, message: "OTP sent to your email." });
  } catch (error: any) {
    sendErrorEmail("Sign-in error:", error, req.body);
    console.error("Sign-in error:", error);
    return res
      .status(200)
      .json({ status: 500, message: "Internal server error." });
  }
};

export const login = async (req: Request, res: Response) => {
  try {
    const { identifier, password, device_id, login_type } = req.body;

    // in future for saving device information
    // const device = await checkDeviceDetails(device_id);

    const result = await loginUser(identifier, password, true);
    console.log("result", result);
    if (result.message === "Invalid email or password") {
      return res.status(200).json({
        status: 401,
        message: "Invalid email or password",
      });
    }
    return res.status(200).json({
      ...result,
      status: 200,
    });
  } catch (error: any) {
    sendErrorEmail(error.message, error, req.body);
    return res.status(200).json({ status: 400, message: error.message });
  }
};

export const notificationTokenStore = async (req: Request, res: Response) => {
  try {
    const { user_id, notification_token, device_id } = req.body;

    if (!notification_token) {
      return res.status(200).json({
        status: 400,
        message: "notification_token are required.",
      });
    }

    const result = await loginUserNoticationSave(
      device_id,
      notification_token,
      user_id
    );
    return res.status(200).json({
      status: 200,
      message: "Notification token saved successfully.",
    });
  } catch (error: any) {
    sendErrorEmail(error.message, error, req.body);
    return res.status(200).json({ status: 400, message: error.message });
  }
};

export const logout = async (req: Request, res: Response) => {
  try {
    const { user_id, device_id } = req.body;

    if (!device_id && !user_id) {
      return res.status(200).json({
        status: 400,
        message: "notification_token and user_id are required.",
      });
    }

    const result = await logoutUser(device_id);
    return res.status(200).json({
      status: 200,
      message: "Logged out successfully.",
    });
  } catch (error: any) {
    sendErrorEmail(error.message, error, req.body);
    return res.status(200).json({ status: 400, message: error.message });
  }
};

export const verifyOtp = async (req: Request, res: Response) => {
  const { identifier, otp, remember_device, device_id, device_name } = req.body;

  if (!identifier || !otp) {
    return res
      .status(200)
      .json({ status: 400, error: "identifier and OTP are required." });
  }

  try {
    const { isValid, token } = await verifyOtpS(identifier, otp);

    if (!isValid) {
      return res.status(200).json({ status: 401, message: "Invalid OTP." });
    }

    if (remember_device && device_id) {
      // Save device information if needed
      console.log(`Remembering device for user: ${identifier}`);
      // Save device details
      await saveDeviceDetails(device_name, device_id);
    } else if (remember_device) {
      return res
        .status(200)
        .json({ status: 401, message: "Device id not found." });
    }

    return res
      .status(200)
      .json({ token, status: 200, message: "OTP verified successfully." });
  } catch (error: any) {
    console.error("OTP verification error:", error);
    sendErrorEmail("OTP verification error:", error, req.body);
    return res
      .status(200)
      .json({ status: 500, message: "Internal server error." });
  }
};

export const sendOtp = async (req: Request, res: Response) => {
  try {
    const { identifier } = req.body;

    const result = await sendOtpS(identifier);
    return res.status(200).json({
      ...result,
      status: 200,
    });
  } catch (error: any) {
    sendErrorEmail(error.message, error, req.body);
    return res.status(200).json({ status: 400, message: error.message });
  }
};

export const resetPassword = async (req: Request, res: Response) => {
  try {
    const { identifier, password } = req.body;

    const result = await updateUserPassword(identifier, password);
    return res.status(200).json({
      ...result,
      status: 200,
    });
  } catch (error: any) {
    sendErrorEmail(error.message, error, req.body);
    return res.status(200).json({ status: 400, message: error.message });
  }
};

export const socialAccountLink = async (req: Request, res: Response) => {
  const {
    email,
    phone,
    imageUrl,
    password,
    firstname,
    lastname,
    socialid,
    socialtype,
    isLogin,
  } = req.body;
  try {
    // const user = await getUserBySocialIdAndType(socialid, socialtype);
    const user = await getUserByEmail(email);
    // If the user already exists, return conflict error
    if (user) {
      const result = await loginSocialUser(user.user_email || user.user_name);
      return res.status(200).json({
        ...result,
        status: 200,
      });
    } else {
      if (isLogin) {
        return res.status(200).json({
          status: 401,
          message: "No account is associated with this.",
        });
      } else {
        const userDetails = await signUpSocialUser(
          email,
          phone,
          imageUrl,
          password,
          firstname,
          lastname,
          "social"
        );

        // Generate OTP and send email
        const otp = generateOtp();
        await saveOtpS(email, otp);
        await sendOtpEmail(email, otp);
        await createNotificationService(userDetails.user.user_id);
        await createSocialLink(socialtype, socialid, userDetails.user.user_id);

        // const result = await loginSocialUser(email);
        // return res.status(200).json({
        //   ...result,
        //   status: 200
        // });

        return res
          .status(200)
          .json({ status: 200, message: "OTP sent to your phone number." });
      }
    }
  } catch (error: any) {
    sendErrorEmail(error.message, error, req.body);
    return res.status(200).json({ status: 400, message: error.message });
  }
};

export const userVerifierAccount = async (req: Request, res: Response) => {
  const { identifier } = req.body;

  if (!identifier) {
    return res
      .status(200)
      .json({ status: 400, error: "Identifier are required." });
  }

  try {
    // Fetch user by email or username
    const result = await userVerifier(identifier);

    return res.status(200).json({ ...result });
  } catch (error: any) {
    sendErrorEmail("userVerifierAccount error.", error, req.body);
    return res
      .status(200)
      .json({ status: 500, message: "Internal server error." });
  }
};
