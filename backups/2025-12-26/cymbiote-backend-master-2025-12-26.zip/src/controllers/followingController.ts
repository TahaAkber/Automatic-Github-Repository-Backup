import { Request, Response } from "express";
import {
  createFollowingLogs,
  FollowingLogs,
} from "../services/followingService";
import { FollowingLocalItem } from "../models/following/following";
import { sendErrorEmail } from "../services/emailService";

export const createFollowingLog = async (req: Request, res: Response) => {
  const { user_id, shop_id, is_following, created_at } = req.body;

  if (!user_id || !shop_id) {
    return res.status(200).json({
      status: 400,
      error: "user_id and shop_id are required.",
    });
  }

  try {
    // Fetch user by email or username
    const result = await createFollowingLogs(
      user_id,
      shop_id,
      is_following,
      created_at
    );

    return res.status(200).json({ ...result });
  } catch (error: any) {
    sendErrorEmail("createFollowingLog error.", error, req.body);
    return res
      .status(200)
      .json({ status: 500, message: "Internal server error." });
  }
};

export const followingLog = async (req: Request, res: Response) => {
  const {
    user_id,
    product = false,
    following_local,
    search = "",
    page = 1,
    pageSize = 10,
  } = req.body;

  try {
    const result = await FollowingLogs(
      Number(user_id),
      Boolean(product),
      (following_local ?? []) as FollowingLocalItem[], // ensure array type
      String(search || ""),
      Math.max(1, Number(page) || 1),
      Math.max(1, Number(pageSize) || 10)
    );

    return res.status(200).json(result);
  } catch (error: any) {
    sendErrorEmail("Error in followingLog:", error, req.body);
    console.error("Error in followingLog:", error);
    return res
      .status(200)
      .json({ status: 500, message: "Internal server error." });
  }
};
