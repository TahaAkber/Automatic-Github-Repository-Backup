import { Request, Response } from "express";
import {
  createAppNotificationsService,
  createNotificationService,
  getAppNotificationByUserIdService,
  getAppNotificationsService,
  getNotificationService,
  getUserNotification,
  readNotification,
  sendFCMNotification,
  updateNotificationSettingService,
} from "../services/notificationService";
import { sendErrorEmail } from "../services/emailService";

export const getNotifications = async (req: Request, res: Response) => {
  try {
    const result = await getNotificationService();
    return res.status(200).json({
      data: result,
      status: 200,
      message: "Successfully retrieved all the notifications",
    });
  } catch (error: any) {
    sendErrorEmail("Failed to get notifications", error, req.body);
    return res.status(200).json({
      status: 400,
      message: "Failed to get notifications",
    });
  }
};
export const getuserNotification = async (req: Request, res: Response) => {
  try {
    const { user_id } = req.query;
    if (!user_id) {
      return res.status(200).json({
        status: 400,
        message: "User ID is required.",
      });
    }
    const result = await getUserNotification(user_id as string);
    return res.status(200).json({
      data: result,
      status: 200,
    });
  } catch (error: any) {
    sendErrorEmail("Failed to get notifications", error, req.query);
    return res.status(200).json({
      status: 400,
      message: "Failed to get user notifications",
    });
  }
};
export const createNotification = async (req: Request, res: Response) => {
  try {
    const { userId } = req.query;
    await createNotificationService(userId as string);
    return res.status(200).json({
      status: 200,
      message: "Notification settings created successfully",
    });
  } catch (error: any) {
    sendErrorEmail("Failed to create notification", error, req.query);
    return res.status(200).json({
      status: 400,
      message: "Failed to create notification",
    });
  }
};

export const updateNotificationSetting = async (
  req: Request,
  res: Response
) => {
  try {
    const { userId, notificationSettings } = req.body;

    if (!userId || !notificationSettings) {
      return res.status(200).json({
        status: 400,
        message: "User ID and notification settings are required.",
      });
    }

    const { success, message } = await updateNotificationSettingService(
      userId as string,
      notificationSettings
    );
    return res.status(200).json({
      status: 200,
      message: message,
    });
  } catch (error: any) {
    sendErrorEmail("Failed to update notification settings", error, req.body);
    return res.status(200).json({
      status: 400,
      message: "Failed to update notification settings",
    });
  }
};

export const createAppNotifications = async (req: Request, res: Response) => {
  try {
    const data = req.body;
    if (!data.userId) {
      return res.status(200).json({
        status: 400,
        message: "User ID is required.",
      });
    }
    await createAppNotificationsService(data.userId, data);
    return res.status(200).json({
      status: 200,
      message: "Notification settings created successfully",
    });
  } catch (error: any) {
    sendErrorEmail("Failed to create notification", error, req.body);
    return res.status(200).json({
      status: 400,
      message: "Failed to create notification",
    });
  }
};

export const sendNotification = async (req: Request, res: Response) => {
  const {
    title,
    body,
    screenName,
    orderId,
    image,
    notificationImageUrl,
    type,
    deviceToken,
    payload,
  } = req.body;

  if (!type) {
    return res.status(400).json({
      status: 400,
      message: "Type is required.",
    });
  }

  if (type !== "all" && !deviceToken) {
    return res.status(400).json({
      status: 400,
      message: "Device token is required for individual messages.",
    });
  }

  try {
    const MessageData = {
      title,
      body,
      image,
      screenName,
      orderId,
      notificationImageUrl,
      type,
      payload,
    };

    const response = await sendFCMNotification(deviceToken, MessageData);

    return res.status(200).json({
      success: true,
      message: "Notification sent successfully",
      response,
    });
  } catch (error: any) {
    sendErrorEmail("Failed to send notification", error, req.body);
    console.error("Notification error:", error);
    return res.status(500).json({
      status: 500,
      message: "Failed to send notification",
      error: error?.message || error,
    });
  }
};

export const getAppNotifications = async (req: Request, res: Response) => {
  try {
    const page = parseInt(req.query.page as string) || 1;
    const pageSize = parseInt(req.query.pageSize as string) || 10;

    const { result, totalNotificationCount, totalPages } =
      await getAppNotificationsService(page, pageSize);
    return res.status(200).json({
      data: result,
      status: 200,
      pagination: {
        totalNotificationCount,
        totalPages,
        currentPage: page,
        pageSize: pageSize,
      },
      message: "Successfully retrieved all the notifications",
    });
  } catch (error: any) {
    sendErrorEmail("Failed to get App notifications", error, {
      ...req.body,
      ...req.query,
    });
    console.error("Notification error:", error);
    return res.status(500).json({
      status: 500,

      message: "Failed to get App notifications",
      error: error?.message || error,
    });
  }
};

export const getAppNotificationByUserId = async (
  req: Request,
  res: Response
) => {
  try {
    const page = parseInt(req.query.page as string) || 1;
    const pageSize = parseInt(req.query.pageSize as string) || 10;
    const userId = req.query.userId as string;
    // if (!userId) {
    //   return res.status(200).json({
    //     status: 400,
    //     message: "User ID is required.",
    //   });
    // }
    const { result, totalNotificationCount, totalPages } =
      await getAppNotificationByUserIdService(page, pageSize, userId);
    return res.status(200).json({
      data: result,
      status: 200,
      pagination: {
        totalNotificationCount,
        totalPages,
        currentPage: page,
        pageSize: pageSize,
      },
      message: "Successfully retrieved all the notifications",
    });
  } catch (error: any) {
    sendErrorEmail("Failed to get App notifications", error, {
      ...req.body,
      ...req.query,
    });
    console.error("Notification error:", error);
    return res.status(500).json({
      status: 500,

      message: "Failed to get App notifications",
      error: error?.message || error,
    });
  }
};

export const readNotificationById = async (req: Request, res: Response) => {
  try {
    const notification_id =
      parseInt(req.query.app_notification_id as string) || 0;
    if (!notification_id) {
      return res.status(200).json({
        status: 400,
        message: "Notification id is required.",
      });
    }
    const response = await readNotification(notification_id);
    return res.status(200).json({
      status: 200,
      message: "Successfully read notification",
    });
  } catch (error: any) {
    sendErrorEmail("Failed to read notifications", error, {
      ...req.body,
      ...req.query,
    });
    return res.status(500).json({
      status: 500,
      message: "Failed to read notifications",
      error: error?.message || error,
    });
  }
};
