import { Request, Response } from "express";
import {
  createCart,
  createShopifyOrder,
  createStorefrontOrderS,
  fetchActiveOrders,
  fetchOrderDetailsUsingOrderId,
  fetchOrders,
  fetchServiceLatestOrder,
  getOrderDate,
} from "../services/orders";

import {
  getShop,
  getShopWithRatingUsingShopId,
} from "../models/shops/shopModel";
import { DiscountRulesQuery } from "../types/PriceRules";
import { deleteStorefrontToken } from "../graphql/storefront/mutation";
import { getOrderReceipt, getUserOrdersCount } from "../models/orders/dbOrders";
import { fetchOrderCancellationReasons } from "../graphql/orders/orderQueries";
import { cancelOrder } from "../graphql/orders/orderMutation";
import { applyOrderStatus } from "../functions/common";
import { getDiscounts } from "../graphql/discount/query";
import { sendErrorEmail } from "../services/emailService";
import { getManualTrackingsForOrderList } from "../models/tracking/dbTracking";

export const createOrder = async (req: Request, res: Response) => {
  const { shop, lineItems } = req.body;
  if (!shop || !lineItems) {
    return res.status(200).json({
      status: 400,
      message: "Missing shop, lineItems, or access token.",
    });
  }
  try {
    const session = await getShop(shop);

    if (session.length < 1) {
      return res.status(200).json({
        status: 404,
        orders: [],
        message: "no session for this shop found",
      });
    }
    const order = await createShopifyOrder(req, session);

    // Return the Shopify order response in case of success
    return res.status(200).json({
      status: 201,
      orders: order,
      message: "success",
    });
  } catch (error: any) {
    sendErrorEmail("Error creating order", error, req.body);
    return res
      .status(200)
      .json({ status: 500, message: "Error creating order", error });
  }
};

export const createStoreFrontOrder = async (req: Request, res: Response) => {
  const {
    shop,
    customCartId,
    lineItems,
    addresses,
    email,
    phone,
    voucherCode,
    cercle_user_id,
  } = req.body;
  console.log("createStoreFrontOrder RAN", JSON.stringify(req.body));

  if (!shop || !lineItems || !email || !customCartId) {
    return res.status(400).json({
      status: 400,
      message:
        "Missing required parameters: shop or lineItems or email or cartId.",
    });
  }

  let storefrontToken: any | null = null;

  try {
    const session = await getShop(shop);
    // Generate a storefront token
    storefrontToken = await createStorefrontOrderS(session);

    // Create the cart using the token
    const cartResponse = await createCart(
      session,
      storefrontToken.accessToken,
      shop,
      customCartId,
      {
        lineItems,
        addresses,
        email,
        phone,
        voucherCode,
        cercleUserId: cercle_user_id,
      }
    );

    // Clean up: delete the storefront token
    await deleteStorefrontToken(shop, storefrontToken.id);

    return res.status(200).json({
      status: 201,
      data: cartResponse,
    });
  } catch (error: any) {
    sendErrorEmail("Error creating storefront order:", error, req.body);
    console.error("Error creating storefront order:", error);

    // Cleanup token in case of an error
    if (storefrontToken) {
      await deleteStorefrontToken(shop, storefrontToken.id).catch(
        (tokenError) => {
          console.error("Error deleting storefront token:", tokenError.message);
        }
      );
    }

    // Return a proper JSON response instead of just throwing an error
    return res.status(200).json({
      status: 500,
      message: "Error creating storefront order",
      error: error.message || "Unknown error",
    });
  }
};

export const getDiscountOrdersRules = async (
  req: Request<{}, {}, {}, DiscountRulesQuery>,
  res: Response
) => {
  const { shop } = req.query;
  try {
    if (!shop) {
      return res.status(200).json({
        status: 404,
        discounts: [],
        message: "kindly provide shop domain",
      });
    }

    const session = await getShop(shop);
    if (session.length < 1) {
      return res.status(404).json({
        discounts: [],
        message: "no session for this shop found",
      });
    }

    const discounts = await getDiscounts(shop, session);
    // console.log("shop discounts", discounts);

    return res.status(201).json({
      discounts,
      message: "success",
    });
  } catch (error: any) {
    sendErrorEmail("Error fetching discounts", error, req.query);
    console.log("Error fetching discounts", error.response.data);

    return res.status(500).json({ message: error.response.data, error });
  }
};

export const fetchUserOrders = async (req: Request, res: Response) => {
  const page = parseInt(req.query.page as string) || 1;
  const pageSize = parseInt(req.query.pageSize as string) || 10;
  const user_id = Number(req.query.user_id);
  const status = await applyOrderStatus(req.query.status);

  try {
    if (!user_id) {
      return res.status(200).json({
        status: 200,
        message: "user_id is required.",
      });
    }

    // Fetch total orders count
    const totalOrders = await getUserOrdersCount(user_id, status);

    // Fetch total manual trackings count
    const manualTrackings = await getManualTrackingsForOrderList(user_id);
    const totalManualTrackings = manualTrackings.length;

    // Combined total for pagination
    const combinedTotal = totalOrders + totalManualTrackings;
    const totalPages = Math.ceil(combinedTotal / pageSize);

    const fetchOrder = await fetchOrders(user_id, page, pageSize, status);
    const orderCreatedDate = await getOrderDate(user_id);

    return res.status(200).json({
      status: 200,
      message: "Orders fetch successfully.",
      data: fetchOrder,
      orderCreatedDate: orderCreatedDate,
      pagination: {
        totalOrders: combinedTotal,
        totalPages,
        currentPage: page,
        pageSize: pageSize,
      },
    });
  } catch (error: any) {
    sendErrorEmail("Order fetch error:", error, req.query);
    console.error("Order fetch error:", error.message);
    return res.status(200).json({
      status: 500,
      message: "Internal server error.",
    });
  }
};

export const fetchCancellationReasons = async (req: Request, res: Response) => {
  const { shop_id } = req.body;

  try {
    // Fetch total number of shops to calculate total pages
    const shop_detail = await getShopWithRatingUsingShopId(shop_id);
    const enums = await fetchOrderCancellationReasons(
      shop_detail?.shop_domain,
      shop_detail?.shop_access_token
    );
    return res.status(200).json({
      status: 200,
      message: "fetch pre enums successfully.",
      data: enums,
    });
  } catch (error: any) {
    sendErrorEmail("fetchCancellationReasons error.", error, req.body);
    return res.status(200).json({
      status: 500,
      message: "Internal server error.",
    });
  }
};

export const fetchLatestOrder = async (req: Request, res: Response) => {
  const { user_id, shop_id } = req.query;

  if (!user_id || !shop_id) {
    return res.status(200).json({
      status: 400,
      message: "user_id and shop_id is required.",
    });
  }

  try {
    const numericUserId = Number(user_id);
    const numericShopId = Number(shop_id);
    const result = await fetchServiceLatestOrder(numericUserId, numericShopId);
    if (result) {
      return res.status(200).json({
        status: 200,
        message: "fetch latest order successfully.",
        data: result,
      });
    }
    return res.status(200).json({
      status: 400,
      message: "Your order not found!",
    });
  } catch (error: any) {
    sendErrorEmail("fetchLatestOrder error.", error, req.query);
    return res.status(200).json({
      status: 500,
      message: "Internal server error.",
    });
  }
};

export const fetchOrderDetails = async (req: Request, res: Response) => {
  try {
    const { order_id, tracking_id, mobile_app } = req.query;
    const numericOrderId = Number(order_id);
    const numericTrackingId = Number(tracking_id);
    const booleanMobileApp = Boolean(mobile_app);
    if (!order_id) {
      return res.status(400).json({
        status: 400,
        message: "Invalid or missing order_id.",
      });
    }
    const order = await fetchOrderDetailsUsingOrderId(
      numericOrderId,
      numericTrackingId,
      booleanMobileApp
    );
    return res.status(200).json({
      status: 200,
      message: "fetch order details successfully.",
      data: order,
    });
  } catch (error: any) {
    sendErrorEmail("Error fetching order details:", error, req.query);
    console.log("Error fetching order details:", error.message);
    return res.status(200).json({
      status: 500,
      message: "Internal server error.",
    });
  }
};

export const fetchOrderReceipt = async (req: Request, res: Response) => {
  try {
    const { order_id } = req.query;
    const numericOrderId = Number(order_id);
    if (!order_id || isNaN(numericOrderId)) {
      return res.status(400).json({
        status: 400,
        message: "Invalid or missing order_id.",
      });
    }
    const order = await getOrderReceipt(numericOrderId);
    return res.status(200).json({
      status: 200,
      message: "fetch order receipt successfully.",
      data: order,
    });
  } catch (error: any) {
    sendErrorEmail("fetchOrderReceipt error.", error, req.query);
    return res.status(200).json({
      status: 500,
      message: "Internal server error.",
    });
  }
};

export const orderCancellation = async (req: Request, res: Response) => {
  try {
    const { shop_id, shopify_order_id, reason, staff_note } = req.body;

    console.log("orderCancellation from app", JSON.stringify(req.body || {}));

    if (!shop_id || !shopify_order_id || !reason) {
      return res.status(200).json({
        status: 400,
        message:
          "Missing required parameters (shop_id, shopify_order_id, reason).",
      });
    }

    const shop_detail = await getShopWithRatingUsingShopId(shop_id);

    if (!shop_detail?.shop_domain || !shop_detail?.shop_access_token) {
      return res.status(200).json({
        status: 400,
        message: "Invalid shop details or missing Shopify credentials.",
      });
    }

    const response = await cancelOrder(
      shop_detail.shop_domain,
      shop_detail.shop_access_token,
      shopify_order_id,
      reason,
      staff_note,
      shop_id
    );
    console.log("order cancel", response);

    return res.status(200).json(response);
  } catch (error: any) {
    sendErrorEmail("Order Cancel Issue", error, req.body);
    console.error("Order Cancel Issue:", error);
    return res.status(400).json({
      status: 500,
      message: "Internal Server Error.",
    });
  }
};

export const fetchUserActiveOrders = async (req: Request, res: Response) => {
  const user_id = Number(req.query.user_id);
  const page = Number(req.query.page || "1");
  const pageSize = Number(req.query.pageSize || "10");

  try {
    if (!user_id) {
      return res.status(400).json({
        status: 400,
        message: "user_id is required.",
      });
    }

    const orders = await fetchActiveOrders(user_id, page, pageSize);

    return res.status(200).json({
      status: 200,
      message: "Orders fetched successfully.",
      data: orders,
    });
  } catch (error: any) {
    sendErrorEmail("fetchUserActiveOrders error.", error, req.query);
    console.error(error);
    return res.status(500).json({
      status: 500,
      message: "Internal server error.",
    });
  }
};
