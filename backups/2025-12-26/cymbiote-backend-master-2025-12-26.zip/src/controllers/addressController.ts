import { Request, Response } from "express";
import {
  addNewAddress,
  getAddress,
  getAddressDetail,
  updateAddress,
} from "../services/addressService";
import {
  deleteAddress,
  deleteUserandmarkedAsDisabled,
  fetchAddress,
  setDefaultAddress,
} from "../models/address/addressModel";
import { sendErrorEmail } from "../services/emailService";
export const createAddressHandler = async (req: Request, res: Response) => {
  try {
    const {
      address_user_id,
      address_first_name,
      address_last_name,
      address_country,
      address_one,
      address_two,
      address_city,
      address_postal_code,
      address_number,
      address_default_select,
    } = req.body ?? {};

    const required: Record<string, any> = {
      address_user_id,
      address_first_name,
      address_last_name,
      address_country,
      address_one,
      address_city,
      address_number,
    };

    const missing = Object.entries(required)
      .filter(
        ([, v]) => v === undefined || v === null || String(v).trim() === ""
      )
      .map(([k]) => k);

    if (missing.length) {
      return res.status(400).json({
        status: 400,
        message: `Missing required field(s): ${missing.join(", ")}.`,
      });
    }

    await addNewAddress({
      address_user_id,
      address_first_name,
      address_last_name,
      address_country,
      address_one,
      address_two: address_two ?? "",
      address_city,
      address_postal_code: address_postal_code ?? "",
      address_number,
      address_default_select:
        typeof address_default_select === "boolean"
          ? address_default_select
          : false,
    });

    return res
      .status(201)
      .json({ status: 201, message: "Address created successfully" });
  } catch (error: any) {
    sendErrorEmail("Failed to create address", error, req.body);
    return res.status(500).json({
      status: 500,
      message: "Failed to create address",
    });
  }
};

export const updateAddressHandler = async (req: Request, res: Response) => {
  try {
    const { address_id } = req.body;

    if (!address_id) {
      res.status(200).json({
        status: 400,
        message: "Address Id are required.",
      });
    }

    await updateAddress(req.body);
    res.status(200).json({
      status: 201,
      message: "Address update successfully",
    });
  } catch (error: any) {
    sendErrorEmail("Failed to create address", error, req.body);
    res.status(200).json({
      status: 500,
      message: "Failed to update address",
      error,
    });
  }
};

export const getAddressHandler = async (req: Request, res: Response) => {
  try {
    // Extract pagination parameters from query string
    const page = parseInt(req.query.page as string) || 1; // Default to page 0 if not provided
    const pageSize = parseInt(req.query.pageSize as string) || 10; // Default to 10 items per page

    const { address, totalAddressCount, totalPages } = await getAddress(
      req.body.user_id,
      page,
      pageSize
    );

    return res.status(200).json({
      status: 200,
      data: address,
      pagination: {
        totalAddressCount,
        totalPages,
        currentPage: page,
        pageSize: pageSize,
      },
      message: "Success",
    });
  } catch (error: any) {
    sendErrorEmail("Unable to fetch Address", error, {
      ...req.body,
      ...req.query,
    });
    res.status(200).json({
      status: 500,
      message: "Unable to fetch Address",
      error,
    });
  }
};

export const getAddressDetailHandler = async (req: Request, res: Response) => {
  try {
    const { address } = await getAddressDetail(req.body.address_id);

    return res.status(200).json({
      status: 200,
      data: address,
      message: "Success",
    });
  } catch (error: any) {
    sendErrorEmail("failed to fetch address detail", error, req.body);
    res.status(200).json({
      status: 500,
      message: "failed to fetch address detail",
      error,
    });
  }
};

export const createDefaultAddress = async (req: Request, res: Response) => {
  const { user_id, address_id } = req.body;
  try {
    const response = await setDefaultAddress(user_id, address_id);

    if (response) {
      return res.status(200).json({
        status: 200,
        message: "Success",
      });
    } else {
      return res.status(200).json({
        status: 500,
        message: "failed to set default address",
      });
    }
  } catch (error: any) {
    sendErrorEmail("failed to fetch address detail", error, req.body);
    res.status(200).json({
      status: 500,
      message: "failed to fetch address detail",
      error,
    });
  }
};

export const deleteAddressHandler = async (req: Request, res: Response) => {
  try {
    await deleteAddress(req.body.address_id);
    return res.status(200).json({
      status: 200,
      message: "Success",
    });
  } catch (error: any) {
    sendErrorEmail("failed delete address", error, req.body);
    res.status(200).json({
      status: 500,
      message: "failed delete address",
      error,
    });
  }
};

export const deleteUserHandler = async (req: Request, res: Response) => {
  try {
    const { userId } = req.body;
    if (!userId) {
      return res.status(200).json({
        status: 400,
        message: "User ID is required.",
      });
    }
    const result = await deleteUserandmarkedAsDisabled(userId);
    return res.status(200).json({
      status: 200,
      message: "User Deleted Successfully",
      result,
    });
  } catch (error: any) {
    sendErrorEmail("failed to delete user", error, req.body);
    res.status(200).json({
      status: 400,
      message: "failed to delete user",
    });
  }
};
