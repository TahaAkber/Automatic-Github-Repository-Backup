import { Request, Response } from "express";
import {
  assignUserToCartsService,
  deleteCart,
  deleteCartItems,
  fetchCart,
  fetchCartService,
  syncCartService,
} from "../services/cart";
import { sendErrorEmail } from "../services/emailService";

export const getCartItems = async (
  req: Request,
  res: Response
): Promise<Response> => {
  try {
    const { cart_items } = req.body;

    // Fetch cart items
    const result = await fetchCart(cart_items);

    return res.status(200).json({ ...result });
  } catch (error: any) {
    console.error("Error fetching cart items:", error.message);
    sendErrorEmail("Error fetching cart items:", error, req.body);
    return res.status(200).json({
      status: 500,
      message: "Error fetching cart items",
      error: error.message,
    });
  }
};
export const addItemsInCart = async (
  req: Request,
  res: Response
): Promise<Response> => {
  try {
    const { cart_items } = req.body;

    // Fetch cart items
    const result = await fetchCart(cart_items);

    return res.status(200).json({ ...result });
  } catch (error: any) {
    sendErrorEmail("Error fetching cart items:", error, req.body);
    console.error("Error fetching cart items:", error.message);

    return res.status(200).json({
      status: 500,
      message: "Error fetching cart items",
      error: error.message,
    });
  }
};

export const syncCartController = async (req: Request, res: Response) => {
  try {
    const { cart_id, deviceIdentifier, user_id, shop_id, pre_cart_items } =
      req.body;

    if (
      !cart_id ||
      !deviceIdentifier ||
      !shop_id ||
      !Array.isArray(pre_cart_items)
    ) {
      return res
        .status(400) // <=== Set HTTP 400 Bad Request here
        .json({ message: "Invalid cart payload" });
    }

    const result = await syncCartService({
      cart_id,
      deviceIdentifier,
      user_id,
      shop_id,
      pre_cart_items,
    });

    // Assuming result has success boolean

    return res.status(200).json(result);
  } catch (error: any) {
    sendErrorEmail("syncCartController error:", error, req.body);
    console.error("syncCartController error:", error);
    return res.status(500).json({ message: error.message });
  }
};

export const fetchCartController = async (req: Request, res: Response) => {
  try {
    const user_id = req.query.user_id ? Number(req.query.user_id) : undefined;
    const device_identifier = req.query.device_identifier as string | undefined;

    // if (!user_id && !deviceIdentifier) {
    //   return res.status(200).json({
    //     status: 400,
    //     success: false,
    //     message: "user_id or deviceIdentifier is required",
    //   });
    // }

    const result = await fetchCartService({ user_id, device_identifier });
    return res.status(200).json(result);
  } catch (error: any) {
    sendErrorEmail("❌ fetchCartController error:", error, req.query);
    console.error("❌ fetchCartController error:", error.message);
    return res.status(200).json({
      status: 500,
      success: false,
      message: "Internal server error",
    });
  }
};

export const deleteCartController = async (req: Request, res: Response) => {
  try {
    const { cartId } = req.params;
    const result = await deleteCart(cartId);

    res.status(200).json({ status: 200, message: result.message });
  } catch (error: any) {
    sendErrorEmail("Failed to delete cart", error, req.params);
    res.status(200).json({
      status: 500,
      message: error || "Failed to delete cart",
    });
  }
};
export const deleteCartItemsController = async (
  req: Request,
  res: Response
) => {
  try {
    const { preCartItemId } = req.params;
    console.log("[Controller] Received preCartItemId:", preCartItemId);

    const result = await deleteCartItems(preCartItemId);

    res.status(result.status).json({ status: 200, message: result.message });
  } catch (error: any) {
    sendErrorEmail("Failed to delete cart item", error, req.params);
    console.error("[Controller] Error deleting cart item:", error);
    res.status(200).json({
      status: 500,
      message: error.message || "Failed to delete cart item",
    });
  }
};

export const assignUserToCartsController = async (
  req: Request,
  res: Response
) => {
  try {
    const { cartIds, userId } = req.body;

    if (!Array.isArray(cartIds) || !cartIds.length) {
      return res.status(200).json({
        status: 400,
        message: "cartIds array is required",
      });
    }
    if (!userId) {
      return res.status(200).json({
        status: 400,
        message: "userId is required",
      });
    }

    const result = await assignUserToCartsService(cartIds, userId);

    res.status(200).json({
      status: 200,
      message: `Updated ${result.updatedCount} carts with userId ${userId}`,
      updatedCount: result.updatedCount,
    });
  } catch (error: any) {
    sendErrorEmail("Error in assignUserToCartsController:", error, req.body);
    console.error("Error in assignUserToCartsController:", error);
    res.status(200).json({
      status: 500,
      message: "Internal Server Error",
    });
  }
};
