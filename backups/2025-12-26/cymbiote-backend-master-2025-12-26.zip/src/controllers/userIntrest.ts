import { Request, Response } from "express";
import {
  createUserIntrest,
  intrestList,
  subCategoryList,
  userIntrestList,
} from "../services/intrestService";
import { sendErrorEmail } from "../services/emailService";

export const creatingUserIntrest = async (req: Request, res: Response) => {
  try {
    const { user_intrest } = req.body;
    const result = await createUserIntrest(user_intrest);
    if (!result) {
      return res.status(200).json({
        status: 400,
        message: "something went wrong!",
      });
    }
    return res.status(200).json({ status: 200, message: "Success" });
  } catch (error: any) {
    sendErrorEmail("creatingUserIntrest error.", error, req.body);

    return res
      .status(200)
      .json({ status: 500, message: "Internal server error." });
  }
};

export const userIntrest = async (req: Request, res: Response) => {
  try {
    const { user_id } = req.body;

    if (!user_id) {
      return res.status(200).json({
        status: 400,
        message: "user_id is required.",
      });
    }

    const result = await userIntrestList(user_id);
    if (!result) {
      return res.status(200).json({
        status: 400,
        message: "something went wrong!",
      });
    }
    const modifiedData = result.map(
      (item: any) => item.user_intrest_category_id
    );
    return res.status(200).json({
      status: 200,
      data: modifiedData,
      message: "fetch user intrest successfully",
    });
  } catch (error: any) {
    sendErrorEmail("userIntrest error.", error, req.body);
    return res
      .status(200)
      .json({ status: 500, message: "Internal server error." });
  }
};
