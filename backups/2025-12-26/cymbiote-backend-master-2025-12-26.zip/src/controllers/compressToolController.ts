import { Request, Response } from "express";
import {
  compressShopProductImages,
  compressShopRNSVideos,
  compressShopTileVideos,
} from "../services/compressToolService";
import { sendErrorEmail } from "../services/emailService";

export const compressTileVideos = async (req: Request, res: Response) => {
  try {
    // Call the service function to compress the tile videos
    const result = await compressShopTileVideos();

    // Check the result and return an appropriate response
    if (result) {
      res.status(200).json({
        status: 200,
        message: "Tile videos compression completed successfully.",
      });
    } else {
      res.status(200).json({
        status: 500,
        message: "An error occurred while processing tile videos.",
      });
    }
  } catch (error: any) {
    // Handle any unexpected errors
    console.error("Error compressing tile videos:", error.message);
    sendErrorEmail("compressTileVideos error.", error);
    res.status(200).json({
      status: 500,
      message: "Internal server error.",
    });
  }
};

export const compressRNSVideos = async (req: Request, res: Response) => {
  try {
    // Call the service function to compress the RNS videos
    const result = await compressShopRNSVideos();

    // Check if the result indicates success
    if (result) {
      res.status(200).json({
        status: 200,
        message: "Shop RNS videos compression completed successfully.",
      });
    } else {
      res.status(500).json({
        status: 500,
        message: "An error occurred while processing the RNS videos.",
      });
    }
  } catch (error: any) {
    // Handle unexpected errors
    sendErrorEmail(
      "Internal server error while compressing RNS videos.",
      error
    );
    console.error("Error compressing RNS videos:", error.message);
    res.status(500).json({
      status: 500,
      message: "Internal server error while compressing RNS videos.",
    });
  }
};

export const compressProductImages = async (req: Request, res: Response) => {
  try {
    // Call the service function to compress the Product Images
    compressShopProductImages();

    // Check if the result indicates success
    res.status(200).json({
      status: 200,
      message: "Product Images compression completed successfully.",
    });
  } catch (error: any) {
    sendErrorEmail("Error compressing Product Images:", error);
    // Handle unexpected errors
    console.error("Error compressing Product Images:", error.message);
    res.status(500).json({
      status: 500,
      message: "Internal server error while compressing Product Images.",
    });
  }
};
