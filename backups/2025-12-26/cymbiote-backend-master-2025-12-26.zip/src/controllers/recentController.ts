import { getUserRecentViewedCount } from "../models/recentView/recentView";
import { sendErrorEmail } from "../services/emailService";
import { fetchRecentView, recentView } from "../services/recentView";
import { Request, Response } from "express";

export const recentViewed = async (req: Request, res: Response) => {
  const {
    user_id,
    recent_view_type,
    recent_view_product_id,
    recent_view_shop_id,
  } = req.body;

  // Validate required fields
  if (!user_id || !recent_view_type) {
    return res.status(200).json({
      status: 400,
      message: "user_id and recent_view_type are required.",
    });
  }

  try {
    // Call the service to create a recent view record
    const result = await recentView({
      user_id,
      recent_view_type,
      recent_view_product_id,
      recent_view_shop_id,
    });

    if (result) {
      return res.status(200).json({
        status: 200,
        message: "Recent view record added successfully.",
      });
    }
  } catch (error: any) {
    sendErrorEmail("Error in recentViewed:", error, req.body);
    console.error("Error in recentViewed:", error.message);
    return res.status(200).json({
      status: 500,
      message: "Internal server error. Please try again later.",
    });
  }
};

export const fetchRecentViewed = async (req: Request, res: Response) => {
  const { user_id, local_recent_view } = req.body;

  // Validate required fields
  if (!user_id && !local_recent_view) {
    return res.status(200).json({
      status: 400,
      message: "user_id is required.",
    });
  }

  const page = parseInt(req.query.page as string) || 1; // Default to page 1 if not provided
  const pageSize = parseInt(req.query.pageSize as string) || 10; // Default to 10 items per page
  const totalRecentViews = local_recent_view
    ? local_recent_view?.length
    : await getUserRecentViewedCount(user_id);
  const totalPages = Math.ceil(totalRecentViews / pageSize);

  try {
    // Call the service to fetch recent view records
    const result = await fetchRecentView(
      user_id,
      local_recent_view,
      page,
      pageSize
    );

    if (result?.length > 0) {
      // If records are found
      return res.status(200).json({
        status: 200,
        message: "Recent viewed items fetched successfully.",
        data: result,
        pagination: {
          totalRecentViews,
          totalPages,
          currentPage: page,
          pageSize: pageSize,
        },
      });
    } else {
      // If no records are found
      return res.status(200).json({
        status: 200,
        message: "No recent viewed items found for the given user.",
        data: [],
      });
    }
  } catch (error: any) {
    sendErrorEmail("Error in fetchRecentViewed:", error, {
      ...req.body,
      ...req.query,
    });
    console.error("Error in fetchRecentViewed:", error.message);
    return res.status(200).json({
      status: 500,
      message: "Internal server error. Please try again later.",
    });
  }
};
