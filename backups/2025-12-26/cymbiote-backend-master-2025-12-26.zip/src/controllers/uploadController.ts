import { Request, Response } from "express";
import path from "path";
import { sendErrorEmail } from "../services/emailService";

export const uploadFile = (req: Request, res: Response) => {
  try {
    if (!req.file) {
      return res.status(200).json({ status: 400, error: "No file uploaded." });
    }

    // Extract uploaded file details
    const filePath = req.file.path; // Full local file path
    const fileName = req.file.filename; // Unique file name

    // Base relative path
    let baseUploadPath = "uploads"; // Folder where uploads are stored
    let relativePath = `${baseUploadPath}/${fileName}`; // Default path

    // Determine folder structure from request params
    if (req.query.userId) {
      relativePath = `${baseUploadPath}/users/${req.query.userId}/profile/${fileName}`;
    } else if (req.query.reviewId) {
      relativePath = `${baseUploadPath}/users/reviews/${req.query.reviewId}/${fileName}`;
    }

    // Construct full URL (dynamically based on request origin)
    const fileUrl = `${req.protocol}://${req.get("host")}/${relativePath}`;

    res.status(200).json({
      status: 201,
      message: "File uploaded successfully.",
      filePath, // Local server path
      url: fileUrl, // Accessible URL
    });
  } catch (error: any) {
    sendErrorEmail(error.message, error, req.file);
    res.status(500).json({ error: error.message });
  }
};
