import { Request, Response } from "express";
import { createMetaObject } from "../services/metafieldService";
import { sendErrorEmail } from "../services/emailService";

export const createMetaObjectEntry = async (req: Request, res: Response) => {
  const { shopDomain, metaobjectKey } = req.body;
  try {
    const data = await createMetaObject(shopDomain, metaobjectKey);
    return res.status(200).json({
      status: 200,
      message: "MetaObject successfully created.",
      data: data,
    });
  } catch (error: any) {
    sendErrorEmail("Error creating MetaObject:", error, req.body);
    console.error("Error creating MetaObject:", error);
    return res.status(200).json({
      status: 500,
      message: "Failed to create MetaObject.",
      error: error.message,
    });
  }
};
