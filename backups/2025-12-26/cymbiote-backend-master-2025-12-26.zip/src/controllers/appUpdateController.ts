import { Request, Response } from "express";
import {
  fetchAppUpdateConfig,
  updateAppUpdateConfigService,
} from "../services/appUpdateService";
import { sendErrorEmail } from "../services/emailService";

export const getAppUpdateConfig = async (req: Request, res: Response) => {
  try {
    const config = await fetchAppUpdateConfig();

    if (!config) {
      return res.status(404).json({
        status: 404,
        message: "App update configuration not found",
      });
    }

    res.status(200).json({
      status: 200,
      data: config,
      message: "Success",
    });
  } catch (error: any) {
    sendErrorEmail("Failed to fetch app update config", error);
    console.error(error);
    res.status(500).json({
      status: 500,
      error: "Failed to fetch app update configuration",
    });
  }
};

export const updateAppUpdateConfig = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const updateData = req.body;

    if (!id) {
      return res.status(400).json({
        status: 400,
        message: "Config ID is required",
      });
    }

    const updatedConfig = await updateAppUpdateConfigService(
      Number(id),
      updateData
    );

    if (!updatedConfig) {
      return res.status(404).json({
        status: 404,
        message: "App update configuration not found",
      });
    }

    res.status(200).json({
      status: 200,
      data: updatedConfig,
      message: "App update configuration updated successfully",
    });
  } catch (error: any) {
    sendErrorEmail("Failed to update app update config", error, req.body);
    console.error(error);
    res.status(500).json({
      status: 500,
      error: error.message || "Failed to update app update configuration",
    });
  }
};
