import { Request, Response } from "express";
import { createChildSocialAccount } from "../services/socialAccountService";
import {
  addSocialLinkConnect,
  getExistChildSocialLink,
  getSocialAccountRefreshToken,
  getUserConnectedAccounts,
  removeAccount,
  updateSocialRefreshToken,
} from "../models/socialAccount/socialAccount";
import { exchangeGoogleAuthCodeForTokens } from "../functions/firebase";
import { sendErrorEmail } from "../services/emailService";

export const createSocialAccountLog = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const { user_id, social_id, social_email, social_type, server_auth_token } =
    req.body;

  if (!user_id || !social_id || !social_email || !social_type) {
    return res.status(200).json({
      status: 400,
      error: "Invalid request. Please provide all required fields.",
    });
  }

  try {
    const existingAccount = await getExistChildSocialLink(social_email);
    if (existingAccount) {
      const getRefreshToken = await exchangeGoogleAuthCodeForTokens(
        server_auth_token
      );
      if (getRefreshToken?.data?.refresh_token) {
        await updateSocialRefreshToken(
          existingAccount.child_id,
          getRefreshToken?.data?.refresh_token
        );
        const response = await addSocialLinkConnect(
          user_id,
          existingAccount.child_id
        );
        if (response) {
          return res.status(200).json({
            status: 200,
            message: "Account attached successfully",
          });
        } else {
          return res.status(200).json({
            status: 400,
            message: response?.message,
          });
        }
      } else {
        const response = await addSocialLinkConnect(
          user_id,
          existingAccount.child_id
        );
        if (response) {
          return res.status(200).json({
            status: 200,
            message: "Account attached successfully",
          });
        } else {
          return res.status(200).json({
            status: 400,
            message: response?.message,
          });
        }
      }
    }

    // Create new social account record
    const result = await createChildSocialAccount(
      user_id,
      social_id,
      social_email,
      social_type,
      server_auth_token
    );

    return res.status(200).json(result);
  } catch (error: any) {
    console.error("Error in createSocialAccountLog:", error.message);
    sendErrorEmail("Error in createSocialAccountLog:", error, req.body);

    return res.status(500).json({
      status: 500,
      message: "Internal server error.",
    });
  }
};

export const connectedAccountLog = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const { user_id } = req.body;

  if (!user_id) {
    return res.status(200).json({
      status: 400,
      error: "user_id is required.",
    });
  }

  try {
    const response = await getUserConnectedAccounts(user_id);
    return res.status(200).json({
      status: 200,
      message: "fetch linked accounts",
      data: response,
    });
  } catch (error: any) {
    sendErrorEmail("Error in createSocialAccountLog:", error, req.body);

    console.error("Error in createSocialAccountLog:", error.message);
    return res.status(500).json({
      status: 500,
      message: "Internal server error.",
    });
  }
};

export const removeConnectedAccount = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const { link_connect_id } = req.body;

  if (!link_connect_id) {
    return res.status(200).json({
      status: 400,
      error: "link_connect_id is required.",
    });
  }

  try {
    const response = await removeAccount(link_connect_id);
    return res.status(200).json({
      status: 200,
      message: "Remove linked accounts",
      data: response,
    });
  } catch (error: any) {
    sendErrorEmail("removeConnectedAccount error.", error, req.body);

    return res.status(200).json({
      status: 500,
      message: "Internal server error.",
    });
  }
};

export const getOrderFromOtherSources = async (
  req: Request,
  res: Response
): Promise<Response> => {
  const { user_id } = req.body;

  if (!user_id) {
    return res.status(200).json({
      status: 400,
      error: "user_id is required.",
    });
  }

  try {
    const response = await getSocialAccountRefreshToken(user_id);
    return res.status(200).json({
      status: 200,
      message: "fetch order successfully.",
      data: response,
    });
  } catch (error: any) {
    sendErrorEmail("getOrderFromOtherSources error.", error, req.body);

    return res.status(500).json({
      status: 500,
      message: "Internal server error.",
    });
  }
};
