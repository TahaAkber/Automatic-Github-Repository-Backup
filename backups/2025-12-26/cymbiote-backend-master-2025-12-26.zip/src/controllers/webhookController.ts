import { Request, Response } from "express";
import {
  detectAndHandleProductUpdate,
  updateProductInventoryInfo,
} from "../services/productService";
import {
  cancelOrderStatusService,
  processAndSaveOrderDetails,
} from "../services/orderService";
import {
  handleFulfillment,
  updateFulfillmentTrackingService,
} from "../services/fulfillmentService";
import { captureTrackingService } from "../services/trackingService";
import getBaseUrl from "../functions/getBaseUrl";
import { sendCollectionNotificationService } from "../services/notificationService";
import {
  deleteCollectionService,
  updateCollectionService,
} from "../services/collectionService";
import {
  customersDataRedactService,
  shopRedactService,
} from "../services/redactService";
import { removeAllSubscription } from "../services/subscriptionService";
import { sendErrorEmail } from "../services/emailService";

export const handleInventoryWebhook = async (req: Request, res: Response) => {
  try {
    const { inventory_item_id, available } = req.body; // Shopify sends product data
    console.log("handleInventoryWebhook", req.body);
    if (!inventory_item_id || available === undefined) {
      return res
        .status(200)
        .json({ status: 400, message: "Invalid webhook payload" });
    }
    console.log("Inventory update triggered", req.body);

    // Check and update the product in the DB
    const result = await updateProductInventoryInfo(
      inventory_item_id,
      available
    );
    if (result) {
      return res.json({
        success: true,
        message: "Product updated",
        status: 200,
      });
    } else {
      return res.json({
        success: false,
        message: "Product not found",
        status: 404,
      });
    }
  } catch (error: any) {
    sendErrorEmail("Error handling webhook:", error, req.body);

    console.error("Error handling webhook:", error);
    return res
      .status(200)
      .json({ status: 500, message: "Internal Server Error" });
  }
};

export const handleCollectionCreate = async (req: Request, res: Response) => {
  const payload = req.body;

  console.log("collection create payload", payload);
  try {
    const result = await sendCollectionNotificationService(payload);

    res.status(200).json({
      status: 200,
      result,
      message: "Collection create webhook received successfully.",
    });
  } catch (error: any) {
    sendErrorEmail(
      "Error handling collection create webhook:",
      error,
      req.body
    );

    console.error("Error handling collection create webhook:", error);
    res.status(200).json({
      status: 500,
      message: "Internal Server Error",
    });
  }
};

export const handleCollectionUpdate = async (req: Request, res: Response) => {
  const payload = req.body;
  console.log("Collection update webhook payload:", payload);
  const { id, title, body_html, image } = payload;
  try {
    const result = await updateCollectionService(id, title, body_html, image);
    res.status(200).json({
      status: 200,
      message: "Collection update webhook received successfully.",
    });
  } catch (error: any) {
    sendErrorEmail(
      "Error handling collection update webhook:",
      error,
      req.body
    );
    console.log("Error handling collection update webhook:", error);
    res.status(200).json({
      status: 500,
      message: "Internal Server Error",
    });
  }
};

export const handleCollectionDelete = async (req: Request, res: Response) => {
  const payload = req.body;
  console.log("Collection delete webhook payload:", payload);
  const { id } = payload;
  try {
    const result = await deleteCollectionService(id);

    res.status(200).json({
      status: 200,
      result,
      message: "Collection delete webhook received successfully.",
    });
  } catch (error: any) {
    sendErrorEmail(
      "Error handling collection delete webhook:",
      error,
      req.body
    );

    console.log("Error handling collection delete webhook:", error);
    res.status(200).json({
      status: 500,
      message: "Internal Server Error",
    });
  }
};

export const handleProductUpdateWebhook = async (
  req: Request,
  res: Response
) => {
  const payload = req.body;
  console.log("handleProductUpdateWebhook:", JSON.stringify(payload));
  try {
    const updatedFields = await detectAndHandleProductUpdate(payload);

    console.log("updated product", updatedFields);

    return res.status(200).json({
      success: true,
      message: "Product updated",
      status: 200,
    });
  } catch (error: any) {
    sendErrorEmail("Error handling webhook:", error, req.body);

    console.error("Error handling webhook:", error);
    return res
      .status(500)
      .json({ status: 500, message: "Internal Server Error" });
  }
};

export const handleOrderCancelWebhook = async (req: Request, res: Response) => {
  try {
    const { id, cancel_reason, cancelled_at, fulfillment_status } = req.body;
    console.log("Cancel webhook payload:", req.body);
    // Ensure the 'id' is provided
    if (!id) {
      return res
        .status(200)
        .json({ status: 400, message: "Order ID is required." });
    }
    console.log("order id", id);
    // Find the order by ID and update its status to "cancelled"
    const order = await cancelOrderStatusService(
      id,
      cancel_reason,
      fulfillment_status,
      cancelled_at
    );

    // If no order is found with that ID, return an error
    if (!order) {
      return res.status(200).json({ status: 404, message: "Order not found." });
    }

    console.log(`Order with ID ${id} marked as cancelled.`);

    // Respond with success message
    res.json({
      status: 200,
      message: "Order status updated to cancelled successfully.",
    });
  } catch (error: any) {
    sendErrorEmail("Error in order cancel webhook:", error, req.body);

    console.log("Error in order cancel webhook:", error);
    return res
      .status(200)
      .json({ status: 500, message: "Internal Server Error" });
  }
};

export const captureTracking = async (req: Request, res: Response) => {
  console.log("Tracking came from 17track");
  const { number: trackingNumber, track_info, carrier } = req.body.data;

  console.log("captureTracking body", JSON.stringify(req.body));
  try {
    // Delegate business logic to the service function
    const result = await captureTrackingService(
      trackingNumber,
      track_info,
      carrier
    );

    console.log("captureTrackingService", result);

    // Send the response based on service result
    return res
      .status(200)
      .json({ status: 200, message: "Tracking updated succesfull." });
  } catch (error: any) {
    sendErrorEmail("Error in captureTracking controller:", error, req.body);

    console.error("Error in captureTracking controller:", error);
    return res
      .status(200)
      .json({ status: 500, message: "Internal Server Error" });
  }
};

export const captureFulfillmentsCreate = async (
  req: Request,
  res: Response
) => {
  try {
    const { id, order_id, tracking_number, tracking_url, line_items } =
      req.body;
    // Regex to extract the base URL from the tracking URL
    const baseUrl = tracking_url ? getBaseUrl(tracking_url) : "";
    console.log(
      "Received fulfillment webhook data:",
      JSON.stringify(req.body),
      baseUrl
    );

    // Step 1: Call the service to handle the fulfillment
    const result = await handleFulfillment(
      id,
      order_id,
      tracking_number,
      baseUrl,
      line_items
    );

    console.log("Tracking registering response", result);

    if (result) {
      return res.json({
        status: 200,
        message: "Fulfillment updated successfully.",
      });
    } else {
      console.log("Failed to process fulfillment.");
      return res
        .status(200)
        .json({ status: 500, message: "Failed to process fulfillment." });
    }
  } catch (error: any) {
    sendErrorEmail("Error in fulfillment webhook:", error, req.body);

    console.error("Error in fulfillment webhook:", error, req.body);
    return res
      .status(200)
      .json({ status: 500, message: "Internal Server Error" });
  }
};

export const captureFulfillmentsUpdate = async (
  req: Request,
  res: Response
) => {
  try {
    console.log("Received Update fulfillment webhook data:", req.body);
    const { id, status, order_id, tracking_number, tracking_url } = req.body;

    const result = await updateFulfillmentTrackingService(
      id,
      status,
      order_id,
      tracking_number,
      tracking_url
    );

    return res.status(200).json({
      status: 200,
      result,
      message: "Fulfillment updated successfully.",
    });
  } catch (error: any) {
    sendErrorEmail("Error in fulfillment webhook:", error, req.body);

    console.error("Error in fulfillment webhook:", error);
    return res
      .status(200)
      .json({ status: 500, message: "Internal Server Error" });
  }
};

export const captureOrderDetails = async (req: Request, res: Response) => {
  console.log("captureOrderDetails", req.body);

  try {
    await processAndSaveOrderDetails({ order: req.body });
    return res
      .status(200)
      .json({ status: 200, message: "Order fetched successfully." });
  } catch (error: any) {
    sendErrorEmail("Error in order capture webhook:", error, req.body);

    console.error("Error in order capture webhook:", error);
    return res
      .status(200)
      .json({ status: 500, message: "Internal Server Error" });
  }
};

export const customersDataRequest = async (req: Request, res: Response) => {
  console.log("customersDataRequest", req.body);
  return res.status(404).json({
    status: 200,
    message: `We do not store customer data. 
      Our app processes it temporarily via Shopify APIs during runtime, 
      but we do not have permanent records of customer data.`,
  });
};

export const customersDataRedact = async (req: Request, res: Response) => {
  console.log("customersDataRedact", req.body);
  try {
    const { found } = await customersDataRedactService(req.body);

    if (!found) {
      return res.status(404).json({
        status: 404,
        message: "Shop not found.",
      });
    }

    return res.status(200).json({
      status: 200,
      message: "Customer data redacted successfully.",
    });
  } catch (error: any) {
    sendErrorEmail("customersDataRedact error:", error, req.body);

    console.error("customersDataRedact error:", error.message);
    return res.status(500).json({
      status: 500,
      message: "Internal Server Error",
    });
  }
};

export const shopRedact = async (req: Request, res: Response) => {
  console.log("shopRedact", req.body);
  try {
    sendErrorEmail("ShopRedact Ran Today:", "Working", req.body);
    const { found } = await shopRedactService(req.body); // expects { shop_domain: string }

    if (!found) {
      return res.status(404).json({ status: 404, message: "Shop not found." });
    }

    return res.status(200).json({
      status: 200,
      message: "Merchant data removed.",
    });
  } catch (e: any) {
    sendErrorEmail("shopRedact error:", e, req.body);

    console.error("shopRedact error:", e.message);
    return res
      .status(500)
      .json({ status: 500, message: "Internal Server Error" });
  }
};

export const webvitalsMetrics = async (req: Request, res: Response) => {
  console.log("Web Vitals Metrics:", req.body);
  return res.status(200).json({
    status: 200,
    message: `Merchant data is being removed.`,
  });
};

export const removeAllWebhookSubscriptions = async (
  req: Request,
  res: Response
) => {
  try {
    const shopDomain = req.query.shop_domain;

    if (!shopDomain) {
      res.status(200).json({ status: 400, message: "Shop domain is required" });
      return;
    }

    const removeSubs = await removeAllSubscription(shopDomain as string);

    res.json({
      status: 200,
      ...removeSubs,
    });
  } catch (error: any) {
    sendErrorEmail("Error removing subscriptions:", error, req.body);

    console.error("Error removing subscriptions:", error.message);
    res.status(200).json({ status: 500, message: "Internal Server Error" });
  }
};
