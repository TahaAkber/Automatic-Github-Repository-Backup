import { Request, Response } from "express";
import { sendProductNotificationService } from "../services/notificationService";
import { sendErrorEmail } from "../services/emailService";

export const handleProductCreate = async (req: Request, res: Response) => {
  const payload = req.body;

  console.log("product create payload", payload);
  try {
    const result = await sendProductNotificationService(payload);

    res.status(200).json({
      status: 200,
      result,
      message: "Product create webhook received successfully.",
    });
  } catch (error: any) {
    sendErrorEmail("Error handling Product create webhook:", error, req.body);
    console.error("Error handling Product create webhook:", error);
    res.status(200).json({
      status: 500,
      message: "Internal Server Error",
    });
  }
};
