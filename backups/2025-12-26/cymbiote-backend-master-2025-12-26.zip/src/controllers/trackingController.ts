import { Request, Response } from "express";
import {
  getManaulTrackingById,
  getManualTrackingsByUserId,
  getTrackingByOrderId,
  pushCourierTracking,
  removeManualTracking,
} from "../services/trackingService";
import { sendErrorEmail } from "../services/emailService";
import {
  courierDHLTrackings,
  getActiveCouriers,
} from "../services/courierService";

// Tracking Controller
export const getTrackingByOrder = async (req: Request, res: Response) => {
  const { orderId } = req.query;

  if (!orderId) {
    return res
      .status(200)
      .json({ status: 500, message: "No orderId provided" });
  }
  try {
    const trackingInfo = await getTrackingByOrderId(
      parseInt(orderId.toString())
    );

    if (!trackingInfo) {
      return res
        .status(200)
        .json({ status: 404, message: "No tracking found for this order" });
    }

    return res
      .status(200)
      .json({ status: 200, events: JSON.parse(trackingInfo.tracking_events) });
  } catch (error: any) {
    console.error("Error fetching tracking information:", error);
    sendErrorEmail("Error fetching tracking information:", error, req.query);

    return res
      .status(200)
      .json({ status: 500, message: "Internal Server Error" });
  }
};

export const addCourierTracking = async (req: Request, res: Response) => {
  console.log("addCourierTracking", req.body);
  const trackingNumberRaw = req.body.tracking_number as string;
  const courier = req.body.courier as string;
  const tracking_name = req.body.tracking_name as string;
  const user_id = req.body.user_id as number;
  if (!trackingNumberRaw || !courier || !tracking_name || !user_id) {
    if (!trackingNumberRaw) {
      return res
        .status(200)
        .json({ status: 400, message: "tracking_number is required." });
    }
    if (!user_id) {
      return res
        .status(200)
        .json({ status: 400, message: "user_id is required." });
    } else if (!courier) {
      return res
        .status(200)
        .json({ status: 400, message: "courier is required." });
    } else if (!tracking_name) {
      return res
        .status(200)
        .json({ status: 400, message: "tracking_name is required." });
    } else
      return res
        .status(200)
        .json({ status: 400, message: "tracking_number is required." });
  }
  try {
    const result = await pushCourierTracking(
      user_id,
      tracking_name,
      trackingNumberRaw,
      courier
    );
    return res.status(200).json({
      ...result,
    });
  } catch (error: any) {
    console.log("error on add courier", error.message);
    return res.status(200).json({
      status: 500,
      message: error?.message || "Internal server error.",
    });
  }
};

export const deleteCourierTracking = async (req: Request, res: Response) => {
  const trackingNumberRaw = req.query.trackingNumber as string;
  if (!trackingNumberRaw) {
    return res
      .status(400)
      .json({ status: 400, message: "TrackingNumber is required." });
  }
  try {
    const result = await courierDHLTrackings(0, "", trackingNumberRaw);
    return res
      .status(result.status === 200 ? 200 : result.status)
      .json({ ...result });
  } catch (error: any) {
    return res.status(200).json({
      status: 500,
      message: error?.message || "Internal server error.",
    });
  }
};

export const getCourierTracking = async (req: Request, res: Response) => {
  try {
    const custom_tracking_id = req.query.custom_tracking_id as string;
    if (!custom_tracking_id) {
      return res
        .status(200)
        .json({ status: 400, message: "param tracking_number is required." });
    }

    if (isNaN(Number(custom_tracking_id))) {
      return res.status(200).json({
        status: 400,
        message: "param custom_tracking_id must be a valid number.",
      });
    }

    const result = await getManaulTrackingById(parseInt(custom_tracking_id));

    res.status(200).json({ ...result });
  } catch (error: any) {
    res.status(200).json({
      message: "failed to get courier tracking",
      status: 500,
      error: error.message,
    });
  }
};

export const getAllCourierTracking = async (req: Request, res: Response) => {
  const userId = req.query.user_id as string;
  const page = parseInt((req.query.page as string) || "1", 10);
  const pageSize = parseInt((req.query.page_size as string) || "10", 10);

  if (!userId) {
    return res
      .status(200)
      .json({ status: 400, message: "user_id is required." });
  }

  try {
    const result = await getManualTrackingsByUserId(
      parseInt(userId),
      page,
      pageSize
    );

    return res.status(result.status === 200 ? 200 : result.status).json({
      ...result,
      page,
      page_size: pageSize,
      total_pages: Math.ceil((result.total || 0) / pageSize),
    });
  } catch (error: any) {
    return res.status(200).json({
      status: 500,
      message: error?.message || "Internal server error.",
    });
  }
};

export const deleteManualTracking = async (req: Request, res: Response) => {
  try {
    const trackingId = parseInt(req?.query.tracking_id as string, 10);

    if (!trackingId) {
      res.status(200).json({
        status: 400,
        message: "tracking_id query param is required.",
      });
    }

    const result = await removeManualTracking(trackingId);

    return res.status(200).json(result);
  } catch (error: any) {
    console.error("Error deleting manual tracking:", error.message);
    return res.status(400).json({ success: false, message: error.message });
  }
};

export const getActiveCouriersController = async (
  req: Request,
  res: Response
) => {
  try {
    const result = await getActiveCouriers();
    return res.status(result.status === 200 ? 200 : result.status).json(result);
  } catch (error: any) {
    console.error("Error in getActiveCouriersController:", error);
    return res.status(500).json({
      status: 500,
      message: "Internal server error",
      error: error.message,
      data: [],
    });
  }
};
