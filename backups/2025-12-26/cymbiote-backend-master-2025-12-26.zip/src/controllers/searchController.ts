import { Request, Response } from "express";
import { searchFromJson } from "../services/searchService";
import { sendErrorEmail } from "../services/emailService";

export const searchCarrierJson = async (req: Request, res: Response) => {
  const { identifier } = req.query;

  if (!identifier) {
    return res
      .status(200)
      .json({ status: 400, message: "Identifier is required." });
  }

  try {
    const result = await searchFromJson(identifier as string);
    if (!result) {
      return res.status(200).json({ status: 404, message: "No match found." });
    }

    return res.status(200).json(result);
  } catch (error: any) {
    sendErrorEmail("Error in searchJson:", error, req.query);
    console.error("Error in searchJson:", error);
    return res
      .status(200)
      .json({ status: 500, message: "Internal Server Error." });
  }
};
