import { Request, Response } from "express";
import {
  calculateAndAddPoints,
  createVoucher,
  creatingPointsLog,
  fetchActiveCriteria,
  fetchUserPointsLog,
  fetchUserTotalPoints,
  fetchUserVouchers,
} from "../services/pointsService";
import {
  getTotalPointCount,
  getTotalVoucherCount,
  userTotalPoint,
} from "../models/points/userPoints";
import { sendErrorEmail } from "../services/emailService";

export const getActiveCriteria = async (req: Request, res: Response) => {
  try {
    const criteria = await fetchActiveCriteria();
    res.status(200).json({ criteria });
  } catch (error: any) {
    sendErrorEmail("Failed to fetch active criteria", error);
    console.error(error);
    res.status(500).json({ error: "Failed to fetch active criteria" });
  }
};

export const addPoints = async (req: Request, res: Response) => {
  const { userId, shopId, criteriaId, transactionValue } = req.body;

  try {
    await calculateAndAddPoints(userId, shopId, criteriaId, transactionValue);
    res
      .status(200)
      .json({ status: 200, message: "Points added successfully." });
  } catch (error: any) {
    sendErrorEmail(error.message, error, req.body);
    console.error(error);
    res.status(500).json({ error: error.message });
  }
};

export const getUserPoints = async (req: Request, res: Response) => {
  const userId = parseInt(req.params.userId as string) || 1; // Default to page 1 if not provided
  const page = parseInt(req.query.page as string) || 1; // Default to page 1 if not provided
  const pageSize = parseInt(req.query.pageSize as string) || 10; // Default to 10 items per page
  const status = req.query.status as string;
  try {
    // const totalPoints = await fetchUserTotalPoints(Number(userId));
    const logs = await fetchUserPointsLog(
      Number(userId),
      page,
      pageSize,
      status
    );

    const totalPointLogs = await getTotalPointCount(Number(userId));
    const totalPages = Math.ceil(totalPointLogs / pageSize);
    const confirmPoint = await userTotalPoint(userId, "completed");
    const pendingPoint = await userTotalPoint(userId, "pending");
    const processingPoint = await userTotalPoint(userId, "redeemed");

    const totalPoints = Math.abs(confirmPoint - processingPoint);

    return res.status(200).json({
      status: 200,
      totalPoints,
      confirmPoint,
      pendingPoint,
      processingPoint,
      logs,
      pagination: {
        totalLogs: totalPointLogs,
        totalPages,
        currentPage: page,
        pageSize: pageSize,
      },
      message: "Success",
    });
  } catch (error: any) {
    sendErrorEmail("Error while getting user data", error, req.query);
    console.log("Error while getting user data", error?.message);
    res.status(500).json({ error: "Failed to fetch user points." });
  }
};

export const getUserVouchers = async (req: Request, res: Response) => {
  const { userId } = req.params;

  const page = parseInt(req.query.page as string) || 1; // Default to page 1 if not provided
  const pageSize = parseInt(req.query.pageSize as string) || 10; // Default to 10 items per page
  const shopId = parseInt(req.query.shop_id as string) || 0; // Default to 10 items per page

  try {
    const logs = await fetchUserVouchers(
      Number(userId),
      page,
      pageSize,
      shopId
    );
    const totalVoucherLogs = await getTotalVoucherCount(Number(userId));
    const totalPages = Math.ceil(totalVoucherLogs / pageSize);

    return res.status(200).json({
      status: 200,
      logs,
      pagination: {
        totalLogs: totalVoucherLogs,
        totalPages,
        currentPage: page,
        pageSize: pageSize,
      },
      message: "Success",
    });
  } catch (error: any) {
    sendErrorEmail("Failed to fetch user points.", error, req.query);
    console.log("Error while processing", error?.message);
    res
      .status(500)
      .json({ status: 400, message: "Failed to fetch user points." });
  }
};

export const spendPoints = async (req: Request, res: Response) => {
  const { userId, shopId, pointsToDeduct, description } = req.body;

  try {
    await creatingPointsLog(userId, shopId, pointsToDeduct, description);
    res
      .status(200)
      .json({ status: 200, message: "Points deducted successfully." });
  } catch (error: any) {
    sendErrorEmail(error.message, error, req.body);
    console.error(error);
    res.status(200).json({ status: 500, error: error.message });
  }
};

export const generatePointsVoucher = async (req: Request, res: Response) => {
  const { userId, pointsToDeduct, shopId } = req.body;

  console.log("generate points", req.body);
  if (!userId || !pointsToDeduct || !shopId) {
    return res.status(200).json({
      status: 400,
      message:
        "Missing required fields named userId, pointsToDeduct, description, shopId",
    });
  }
  try {
    const voucherCode = await createVoucher(userId, pointsToDeduct, shopId);
    res.status(200).json(voucherCode);
  } catch (error: any) {
    sendErrorEmail(error.message, error, req.body);
    console.error(error);
    res.status(200).json({ status: 400, message: error.message });
  }
};
