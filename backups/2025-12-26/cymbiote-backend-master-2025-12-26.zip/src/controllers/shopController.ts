import { Request, Response } from "express";
import {
  fetchAllShops,
  fetchAllTrendingCollections,
  fetchCollectionsbyId,
  fetchTaxonomyCategories,
  getCollectionByIdService,
  getFilteredCollectionByIdService,
  getPaginatedActiveShops,
  getTrendingCollectionByIdService,
  searchShopsS,
} from "../services/shopService";
import {
  fetchShopProduct,
  fetchShopReel,
  getUsingShopCategoryIdProducts,
} from "../services/productService";
import { getShopByIdSortingCategories } from "../models/products/productModel";
import { getCollectionProductsS } from "../services/collectionService";
import { mergeShopsWithReels } from "../functions/shop";
import { intrestList, subCategoryList } from "../services/intrestService";
import { SortBy } from "../types/Shop";
import { sendErrorEmail } from "../services/emailService";

export const searchShops = async (req: Request, res: Response) => {
  try {
    const search_term = req.query.search_term as string;
    const page = (req.query.page as string) || "1";
    const pageSize = (req.query.page_size as string) || "3";

    // if (!search_term) {
    //   res.status(200).json({
    //     status: 500,
    //     message: "Required field search_term required",
    //   });
    // }

    const { shops, shopsCount, totalPages } = await searchShopsS(
      search_term,
      parseInt(page),
      parseInt(pageSize)
    );

    res.status(200).json({
      data: {
        shops,
        shopsCount,
        totalPages,
        page: parseInt(page),
        pageSize: parseInt(pageSize),
      },
      message: "success",
      status: 200,
    });
  } catch (error: any) {
    sendErrorEmail("Error in search ", error, req.query);
    res.status(200).json({
      status: 500,
      message: "Error in search " + error.message,
    });
  }
};

export const getAllShopifyStores = async (req: Request, res: Response) => {
  try {
    const page = parseInt(req.query.page as string) || 1;
    const pageSize = parseInt(req.query.page_size as string) || 3;
    const userId = req.query.user_id ? Number(req.query.user_id) : 0;
    const categories = req.query.categories as string;
    const shownShopIds = (req.query.shown_shop_ids as string) || "";

    console.log("getAllShopifyStores", req.query);

    if (!categories) {
      // sendErrorEmail("categories can not null", "getAllShopifyStores", req.query);
      return res.status(200).json({
        status: 400,
        message: "categories can not null",
      });
    }

    // if (userId) {
    //   const checkingCache = await checkForUserCache(userId);

    //   if (checkingCache != null && page == 1) {
    //     return res.status(200).json({
    //       ...checkingCache,
    //       status: 200,
    //       message: "Success",
    //     });
    //   } else {
    //     console.log("No cache found");
    //   }
    // }

    const {
      shops,
      totalShops,
      totalPages,
      pageSize: pageSizeUsed,
      updatedShopIds,
      repeatCheck,
    } = await fetchAllShops(pageSize, userId, categories, shownShopIds);

    if (shops.length === 0) {
      sendErrorEmail("No active shops found", "getAllShopifyStores", req.query);
      return res.status(200).json({
        status: 404,
        message: "No active shops found",
      });
    }

    const mergedList = await mergeShopsWithReels(shops, page, pageSize);

    const apiResponse = {
      shops: mergedList,
      pagination: {
        updatedShopIds,
        repeatCheck,
        totalShops,
        totalPages,
        currentPage: page,
        pageSize: pageSizeUsed,
      },
    };

    // const shopResponseJson = JSON.stringify(apiResponse);

    // if (userId && page == 1) {
    //   insertCacheInformation(userId, shopResponseJson);
    // }

    return res.status(200).json({
      status: 200,
      ...apiResponse,
      message: "Success",
    });
  } catch (error: any) {
    sendErrorEmail("Error fetching shops:", error, req.query);
    console.error("Error fetching shops:", error.message);
    return res.status(200).json({
      status: 500,
      message: "Error fetching shops",
      error: error.message,
    });
  }
};

export const getProductByShop = async (req: Request, res: Response) => {
  console.log("/shop/shop-products", req.body, req.query);
  try {
    if (!req.body.shop_id) {
      throw new Error("shop_id is required");
    }
    const page = parseInt(req.query.page as string) || 1;
    const pageSize = parseInt(req.query.pageSize as string) || 10;
    const searchKeyword = (req.query.searchKeyword as string) || "";
    const minRating = req.query.minRating
      ? parseFloat(req.query.minRating as string)
      : undefined;
    const minPrice = req.query.minPrice
      ? parseFloat(req.query.minPrice as string)
      : undefined;
    const maxPrice = req.query.maxPrice
      ? parseFloat(req.query.maxPrice as string)
      : undefined;
    const sortPrice = req.query.sortPrice as "asc" | "desc" | undefined;
    const createdAt = req.query.createdAt as "asc" | "desc" | undefined;
    const product_id = req.query.product_id as number | undefined;
    const user_id = req.body.user_id ? req.body.user_id : undefined;

    console.log("user_idincontroller", user_id);

    const {
      products,
      shop,
      productCategories,
      totalProductCount,
      totalPages,
      currentPage,
    } = await fetchShopProduct(
      req.body.shop_id,
      page,
      pageSize,
      searchKeyword,
      minRating,
      minPrice,
      maxPrice,
      sortPrice,
      createdAt,
      product_id,
      user_id
    );

    const data = {
      shop,
      products,
      productCategories,
    };

    return res.status(200).json({
      status: 200,
      data,
      pagination: {
        totalProductCount,
        totalPages,
        currentPage: page,
        pageSize: pageSize,
      },
      message: "Success",
    });
  } catch (error: any) {
    sendErrorEmail("Error fetching shop products:", error, {
      ...req.query,
      ...req.body,
    });

    console.error("Error fetching shop products:", error.message);
    return res.status(200).json({
      status: 500,
      message: "Error fetching shop products",
      error: error.message,
    });
  }
};

export const getShopReels = async (req: Request, res: Response) => {
  try {
    // Extract pagination parameters from query string
    const page = parseInt(req.query.page as string) || 1; // Default to page 1 if not provided
    const pageSize = parseInt(req.query.pageSize as string) || 10; // Default to 10 items per page

    // Fetch paginated shops from the service
    const { products, shop, totalReelCount, totalPages } = await fetchShopReel(
      req.body.shop_id,
      page,
      pageSize
    );

    const data = {
      shop,
      products,
    };

    // Return the paginated list of shops with pagination info
    return res.status(200).json({
      status: 200,
      data,
      pagination: {
        totalReelCount,
        totalPages,
        currentPage: page,
        pageSize: pageSize,
      },
      message: "Success",
    });
  } catch (error: any) {
    sendErrorEmail("Error fetching shop products:", error, {
      ...req.query,
      ...req.body,
    });
    console.error("Error fetching shop products:", error.message);
    return res.status(200).json({
      status: 500,
      message: "Error fetching shop products",
      error: error.message,
    });
  }
};

export const getRelatedShops = async (req: Request, res: Response) => {
  try {
    const { shop_id, user_id } = req.body;

    if (!shop_id) {
      return res.status(200).json({
        status: 400,
        message: "shop_id is required.",
      });
    }

    const related_shops = await getShopByIdSortingCategories(shop_id, user_id);

    res.status(200).json({
      status: 200,
      data: related_shops,
      message: "success",
    });
  } catch (error: any) {
    sendErrorEmail("Related shops not found", error, req.body);

    res.status(200).json({
      status: 500,
      message: "Related shops not found",
      error,
    });
  }
};

export const getRelatedShopProducts = async (req: Request, res: Response) => {
  try {
    const { category_id, user_id } = req.body;

    if (!category_id) {
      return res.status(200).json({
        status: 400,
        message: "category_id and user_id is required.",
      });
    }

    const shops = await getPaginatedActiveShops(category_id, 1, 3);

    const related_shops = await getUsingShopCategoryIdProducts(shops, user_id);

    res.status(200).json({
      status: 200,
      data: related_shops,
      message: "success",
    });
  } catch (error: any) {
    sendErrorEmail("Failed to fetch related shop products", error, req.body);

    res.status(200).json({
      status: 500,
      message: "Failed to fetch related shop products",
      error: error.message,
    });
  }
};

export const getShopCollectionProducts = async (
  req: Request,
  res: Response
) => {
  const { shopId, filterId, pageSize, endCursor } = req.query;

  try {
    if (!filterId || !shopId) {
      return res.status(200).json({
        status: 500,
        message: "failled",
        error: "missing required fields filterId or shopId",
      });
    }

    const collectionProduct = await getCollectionProductsS(
      parseInt(shopId.toString()),
      filterId as string,
      pageSize as any,
      endCursor as string
    );

    return res.status(200).json({
      status: 200,
      ...collectionProduct,
    });
  } catch (error) {
    sendErrorEmail(
      "failed to fetch collection products",
      error as string,
      req.query
    );
    return res.status(200).json({
      status: 500,
      message: "failed to fetch collection products",
      error: error,
    });
  }
};

export const shopCategories = async (req: Request, res: Response) => {
  try {
    const result = await intrestList();
    return res.status(200).json({ ...result });
  } catch (error: any) {
    sendErrorEmail("shopCategories error.", error);

    return res
      .status(200)
      .json({ status: 500, message: "Internal server error." });
  }
};

export const shopSubCategories = async (req: Request, res: Response) => {
  try {
    const { store_category_id } = req.body;
    const result = await subCategoryList(store_category_id);
    return res.status(200).json({ ...result });
  } catch (error: any) {
    sendErrorEmail("shopSubCategories error.", error, req.body);

    return res
      .status(200)
      .json({ status: 500, message: "Internal server error." });
  }
};

export const getShopTaxonomies = async (req: Request, res: Response) => {
  try {
    const { id } = req.query;

    const taxonomies = await fetchTaxonomyCategories(id as string);

    res.status(200).json({
      status: 200,
      taxonomies,
    });
  } catch (error: any) {
    sendErrorEmail(error.message, error, req.query);

    res.status(200).json({
      status: 400,
      message: error.message,
    });
  }
};

export const getcollectionbyShopid = async (req: Request, res: Response) => {
  try {
    const shopId = req.query.shopId;
    if (!shopId) {
      return res.status(200).json({
        status: 500,
        message: "shopId required",
      });
    }
    const collectionType = req.query.collectionTypeId || 1;
    console.log("query items", req.query);
    const { data, collectionProductCategories } = await fetchCollectionsbyId(
      shopId,
      collectionType as string
    );
    res.status(200).json({
      status: 200,
      data,
      collectionProductCategories,
      message: "Success",
    });
  } catch (error: any) {
    sendErrorEmail(error.message, error, req.query);

    res.status(200).json({
      status: 400,
      message: error.message,
    });
  }
};

export const getAllTrendingCollections = async (
  req: Request,
  res: Response
) => {
  try {
    console.log("query items", req.query);
    const data = await fetchAllTrendingCollections();
    res.status(200).json({
      status: 200,
      data,
      message: "Success",
    });
  } catch (error: any) {
    sendErrorEmail(error.message, error, req.query);

    res.status(200).json({
      status: 400,
      message: error.message,
    });
  }
};

export const getTrendingCollectionByIdController = async (
  req: Request,
  res: Response
) => {
  const { id } = req.params;
  const sortBy = req.query.sortBy
    ? (req.query.sortBy as string).split(",")
    : undefined;

  const sortOrder = req.query.sortOrder
    ? (req.query.sortOrder as string).split(",")
    : undefined;

  const minPrice = req.query.minPrice
    ? parseFloat(req.query.minPrice as string)
    : undefined;

  const maxPrice = req.query.maxPrice
    ? parseFloat(req.query.maxPrice as string)
    : undefined;

  const colors = req.query.colors
    ? (req.query.colors as string).split(",")
    : undefined;

  const minRating = req.query.minRating
    ? parseFloat(req.query.minRating as string)
    : undefined;

  const onSale =
    req.query.onSale === "true"
      ? true
      : req.query.onSale === "false"
      ? false
      : undefined;

  const sizes = req.query.sizes
    ? (req.query.sizes as string).split(",")
    : undefined;

  const sortPrice = req.query.sortPrice as "ASC" | "DESC" | undefined;

  const page = req.query.page ? parseInt(req.query.page as string, 10) : 1;

  const pageSize = req.query.pageSize
    ? parseInt(req.query.pageSize as string, 10)
    : 10;

  console.log(sortBy, "sortByCont");
  console.log(sortOrder, "sortOrderCont");
  console.log(minPrice, "minPriceCont");
  console.log(maxPrice, "maxPriceCont");
  console.log(colors, "colors");
  console.log(minRating, "minRatingCont");
  console.log(onSale, "onSaleCont");
  console.log(sizes, "sizesCont");
  console.log(page, "pageCont");
  console.log(pageSize, "pageSizeCont");

  try {
    const { collectionData, productCategories } =
      await getTrendingCollectionByIdService(
        id,
        sortBy,
        sortOrder,
        minPrice,
        maxPrice,
        colors,
        minRating,
        onSale,
        sizes,
        sortPrice,
        page,
        pageSize
      );

    const result = {
      ...collectionData,
      productCategories,
    };

    return res.status(200).json({
      status: 200,
      data: result,
    });
  } catch (error: any) {
    sendErrorEmail("getTrendingCollectionByIdController Error", error, {
      ...req.query,
      ...req.params,
    });

    return res
      .status(200)
      .json({ status: 500, message: error.message || "Internal Server Error" });
  }
};

export const getCollectionByIdController = async (
  req: Request,
  res: Response
) => {
  const { id } = req.params;
  const sortBy = req.query.sortBy
    ? (req.query.sortBy as string).split(",")
    : undefined;

  const sortOrder = req.query.sortOrder
    ? (req.query.sortOrder as string).split(",")
    : undefined;

  const minPrice = req.query.minPrice
    ? parseFloat(req.query.minPrice as string)
    : undefined;

  const maxPrice = req.query.maxPrice
    ? parseFloat(req.query.maxPrice as string)
    : undefined;

  const colors = req.query.colors
    ? (req.query.colors as string).split(",")
    : undefined;

  const minRating = req.query.minRating
    ? parseFloat(req.query.minRating as string)
    : undefined;

  const onSale =
    req.query.onSale === "true"
      ? true
      : req.query.onSale === "false"
      ? false
      : undefined;

  const sizes = req.query.sizes
    ? (req.query.sizes as string).split(",")
    : undefined;
  const sortPrice = req.query.sortPrice as "ASC" | "DESC" | undefined;

  const page = req.query.page ? parseInt(req.query.page as string, 10) : 1;
  const pageSize = req.query.pageSize
    ? parseInt(req.query.pageSize as string, 10)
    : 10;
  const collection_shop_id = req.query.collection_shop_id
    ? (req.query.collection_shop_id as string)
    : undefined;
  const collection_type_id = req.query.collection_type_id
    ? (req.query.collection_type_id as string)
    : undefined;
  console.log(sortBy, "sortByCont");
  console.log(sortOrder, "sortOrderCont");
  console.log(minPrice, "minPriceCont");
  console.log(maxPrice, "maxPriceCont");
  console.log(colors, "colors");
  console.log(minRating, "minRatingCont");
  console.log(onSale, "onSaleCont");
  console.log(sizes, "sizesCont");
  console.log(sortPrice, "sortPriceCont");
  console.log(page, "pageCont");
  console.log(pageSize, "pageSizeCont");

  try {
    const { collectionData, collectionProductCategories } =
      await getCollectionByIdService(
        id,
        collection_shop_id,
        collection_type_id,
        sortBy,
        sortOrder,
        minPrice,
        maxPrice,
        colors,
        minRating,
        onSale,
        sizes,
        sortPrice,
        page,
        pageSize
      );
    const result = {
      ...collectionData,
      collectionProductCategories,
    };
    return res.status(200).json({
      status: 200,
      data: result,
    });
  } catch (error: any) {
    sendErrorEmail("getCollectionByIdController Error", error, req.query);

    return res
      .status(500)
      .json({ message: error.message || "Internal Server Error" });
  }
};

export const getFilteredCollectionByIdController = async (
  req: Request,
  res: Response
) => {
  const { id } = req.params;

  const page = req.query.page ? parseInt(req.query.page as string, 10) : 1;

  const pageSize = req.query.pageSize
    ? parseInt(req.query.pageSize as string, 10)
    : 10;

  try {
    const { collectionData, productCategories } =
      await getFilteredCollectionByIdService(
        id,

        page,
        pageSize
      );

    const result = {
      ...collectionData,
      productCategories,
    };
    return res.status(200).json({
      status: 200,
      data: result,
    });
  } catch (error: any) {
    sendErrorEmail("getFilteredCollectionByIdController Error", error, req.params);

    return res
      .status(500)
      .json({ message: error.message || "Internal Server Error" });
  }
};
