import { Request, Response } from "express";
import {
  addNewProduct,
  fetchAllProducts,
  fetchProductDetail,
  fetchProductsWithCategories,
} from "../services/productService";
import { getCategoryProductsCount } from "../models/products/productModel";
import { sendErrorEmail } from "../services/emailService";

export const createProductHandler = async (req: Request, res: Response) => {
  try {
    await addNewProduct(req.body);
    res.status(200).json({
      status: 201,
      message: "Product created successfully",
    });
  } catch (error: any) {
    sendErrorEmail("Failed to create product", error, req.body);
    res.status(200).json({
      status: 500,
      message: "Failed to create product",
      error,
    });
  }
};

// This call is no longer being used
export const getProductsHandler = async (req: Request, res: Response) => {
  try {
    const products = await fetchAllProducts();
    res.status(200).json({
      status: 200,
      products,
      total: products.length,
      message: "success",
    });
  } catch (error: any) {
    res.status(200).json({
      status: 500,
      message: "All products fetch failed",
      error,
    });
  }
};

export const getProductWithCategories = async (req: Request, res: Response) => {
  try {
    const { category_name, shop_id, collectionType_id, collection_id } =
      req.query;
    const page = parseInt(req.query.page as string) || 1; // Default to page 1 if not provided
    const pageSize = parseInt(req.query.pageSize as string) || 10; // Default to 10 items per page

    const totalProducts = await getCategoryProductsCount(
      !isNaN(Number(shop_id)) ? Number(shop_id) : undefined,
      typeof category_name === "string" ? category_name : undefined,
      !isNaN(Number(collectionType_id)) ? Number(collectionType_id) : undefined,

      !isNaN(Number(collection_id)) ? Number(collection_id) : undefined
    );

    const totalPages = Math.ceil(totalProducts / pageSize);

    const Products = await fetchProductsWithCategories(
      page,
      pageSize,
      typeof category_name === "string" ? category_name : undefined,
      !isNaN(Number(shop_id)) ? Number(shop_id) : undefined,
      !isNaN(Number(collectionType_id)) ? Number(collectionType_id) : undefined,
      !isNaN(Number(collection_id)) ? Number(collection_id) : undefined
    );

    res.status(200).json({
      status: 200,
      data: Products,
      pagination: {
        totalProducts,
        totalPages,
        currentPage: page,
        pageSize: pageSize,
      },
      message: "success",
    });
  } catch (error: any) {
    sendErrorEmail("Failed to fetch category products", error, req.query);
    res.status(200).json({
      status: 500,
      message: "Failed to fetch category products",
      error: error.message,
    });
  }
};

export const getProductDetailHandler = async (req: Request, res: Response) => {
  try {
    console.log("getProductDetailHandler", JSON.stringify(req.body));
    const product_detail = await fetchProductDetail(
       Number(req.query.product_id),
      Number( req.query.user_id)
    );
    res.status(200).json({
      status: 200,
      data: product_detail,
      message: "success",
    });
  } catch (error: any) {
    sendErrorEmail("Failed to fetch product details", error, req.body);
    res.status(200).json({
      status: 500,
      message: "Failed to fetch product details",
      error,
    });
  }
};
