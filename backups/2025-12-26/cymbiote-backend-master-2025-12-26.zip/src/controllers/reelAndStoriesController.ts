import { Request, Response } from "express";
import { LikeReel } from "../models/reelsAndStories/reelsAndStories";
import {
  fetchLatestReelByOffset,
  fetchReelsByShop,
  fetchReelsByShopId,
  fetchReelsByVideoId,
  GetSavedReelsService,
  incrementReelViewCountService,
  SavedReelService,
  StoryService,
} from "../services/reelsAndStories";
import { sendErrorEmail } from "../services/emailService";

export const getReelsByShopIdController = async (
  req: Request,
  res: Response
) => {
  try {
    const shopId = parseInt(req.params.shopId, 10);
    const userId = req.query.userId ? Number(req.query.userId) : undefined;

    if (isNaN(shopId)) {
      return res.status(400).json({
        status: 400,
        message: "Invalid shop ID",
      });
    }

    const result = await fetchReelsByShopId(shopId, userId);
    res.status(result.status).json(result);
  } catch (error: any) {
    sendErrorEmail("Error in getReelsByShopIdController:", error, {
      ...req.params,
      ...req.query,
    });
    console.error("Error in getReelsByShopIdController:", error);
    res.status(500).json({
      status: 500,
      message: "Internal Server Error",
    });
  }
};

export const getReelsByVideoIdController = async (
  req: Request,
  res: Response
) => {
  try {
    const videoId = parseInt(req.params.videoId, 10);
    const userId = req.query.userId ? Number(req.query.userId) : undefined;
    const page = req.query.page ? Number(req.query.page) : 1;
    const pageSize = req.query.pageSize ? Number(req.query.pageSize) : 2;
    const shopId = req.query.shopId ? Number(req.query.shopId) : undefined;

    if (isNaN(videoId)) {
      return res.status(400).json({
        status: 400,
        message: "Invalid video ID",
      });
    }

    const result = await fetchReelsByVideoId(
      videoId,
      userId,
      page,
      pageSize,
      shopId
    );
    res.status(result.status).json(result);
  } catch (error: any) {
    sendErrorEmail("Error in getReelsByVideoIdController:", error, req.body);
    console.error("Error in getReelsByVideoIdController:", error);
    res.status(500).json({
      status: 500,
      message: "Internal Server Error",
    });
  }
};
export const getLatestReelByOffsetController = async (
  req: Request,
  res: Response
) => {
  try {
    const offset = parseInt(req.query.offset as string, 10) || 0;

    if (isNaN(offset)) {
      return res.status(400).json({
        status: 400,
        message: "Invalid offset value",
      });
    }

    const result = await fetchLatestReelByOffset(offset);
    res.status(result.status).json(result);
  } catch (error: any) {
    sendErrorEmail("Error in getReelsByVideoIdController:", error, req.query);
    console.error("Error in getLatestReelByOffsetController:", error);
    res.status(500).json({
      status: 500,
      message: "Internal Server Error",
    });
  }
};

export const getReelsByShopController = async (req: Request, res: Response) => {
  try {
    const shopId = parseInt(req.params.shopId, 10);

    if (isNaN(shopId)) {
      return res.status(400).json({
        status: 400,
        message: "Invalid shop ID",
      });
    }
    const userId = req.query.userId ? Number(req.query.userId) : undefined;

    const result = await fetchReelsByShop(shopId, userId);
    res.status(result.status).json(result);
  } catch (error: any) {
    sendErrorEmail("Error in getReelsByShopIdController:", error, {
      ...req.params,
      ...req.query,
    });
    console.error("Error in getReelsByShopIdController:", error);
    res.status(500).json({
      status: 500,
      message: "Internal Server Error",
    });
  }
};

export const SavedReelController = async (req: Request, res: Response) => {
  try {
    const { user_id, video_id, status } = req.body;

    if (
      typeof user_id !== "number" ||
      typeof video_id !== "number" ||
      typeof status !== "boolean"
    ) {
      return res.status(400).json({
        success: false,
        message: "user_id, video_id, and status (boolean) are required",
      });
    }

    const result = await SavedReelService(user_id, video_id, status);

    return res.status(result.status).json({
      success: result.status === 200,
      ...(result.data || { message: result.message }),
    });
  } catch (error: any) {
    sendErrorEmail("SavedReelController error", error, req.body);
    return res.status(500).json({
      success: false,
      message: error.message || "Internal server error",
    });
  }
};

export const updateReelViewCountController = async (
  req: Request,
  res: Response
) => {
  try {
    const videoId = parseInt(req.params.videoId, 10);

    if (isNaN(videoId)) {
      return res.status(400).json({
        status: 400,
        message: "Invalid video URL ID",
      });
    }

    const result = await incrementReelViewCountService(videoId);
    res.status(result.status).json(result);
  } catch (error: any) {
    sendErrorEmail(
      "Controller error updating video view count:",
      error,
      req.params
    );
    console.error("Controller error updating video view count:", error);
    res.status(500).json({
      status: 500,
      message: "Internal Server Error",
    });
  }
};

export const likeReelController = async (
  req: Request,
  res: Response
): Promise<Response> => {
  try {
    const { user_id, video_id, liked } = req.body;

    if (
      typeof user_id !== "number" ||
      typeof video_id !== "number" ||
      typeof liked !== "boolean"
    ) {
      return res.status(400).json({
        message: "user_id, video_id, and liked (boolean) are required",
      });
    }

    const result = await LikeReel(user_id, video_id, liked);
    return res.status(200).json(result);
  } catch (error: any) {
    sendErrorEmail("likeReelController error", error, req.body);
    return res.status(500).json({
      message: error.message || "Internal server error",
    });
  }
};

export const StoryController = async (req: Request, res: Response) => {
  try {
    const { shopId } = req.params;
    const userId = req.query.userId ? Number(req.query.userId) : undefined;

    if (!shopId) {
      return res.status(400).json({
        status: "error",
        message: "Missing shopId parameter",
      });
    }

    const numericShopId = parseInt(shopId as string, 10);

    if (isNaN(numericShopId)) {
      return res.status(400).json({
        status: "error",
        message: "Invalid shopId parameter",
      });
    }

    const stories = await StoryService(numericShopId, userId);

    return res.status(200).json({
      status: 200,
      data: stories,
    });
  } catch (error: any) {
    sendErrorEmail("Error in StoryController:", error, req.params);
    console.error("Error in StoryController:", error);
    return res.status(500).json({
      status: "error",
      message: "Failed to fetch stories",
    });
  }
};

export const GetSavedReelsController = async (req: Request, res: Response) => {
  try {
    const user_id = Number(req.params.userId);
    const page = Number(req.query.page) || 1;
    const pageSize = Number(req.query.pageSize) || 12;

    if (!user_id || isNaN(user_id)) {
      return res.status(400).json({
        success: false,
        message: "Valid user_id param is required.",
      });
    }

    const result = await GetSavedReelsService(user_id, page, pageSize);
    const totalCount = result.totalCount || 0;

    const totalPages = Math.ceil(totalCount / pageSize);

    return res.status(result.status).json({
      success: result.status === 200,
      status: 200,
      ...(result.data
        ? {
            data: result.data,
            pagination: {
              totalPages,
              totalCount: result.totalCount,
              currentPage: page,
              pageSize,
            },
          }
        : { message: result.message }),
    });
  } catch (error: any) {
    sendErrorEmail("GetSavedReelsController error", error, {
      ...req.params,
      ...req.query,
    });
    return res.status(500).json({
      success: false,
      message: error.message || "Internal server error",
    });
  }
};
