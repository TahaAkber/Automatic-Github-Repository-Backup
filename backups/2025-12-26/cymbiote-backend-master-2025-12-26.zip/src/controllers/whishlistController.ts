import { Request, Response } from "express";
import { createWishlistLogs, wishlistLogs } from "../services/wishlistService";
import { sendErrorEmail } from "../services/emailService";

export const createWishlistLog = async (req: Request, res: Response) => {
  const { user_id, product_id, is_added, created_at } = req.body;

  if (!user_id || !product_id) {
    return res.status(200).json({
      status: 400,
      error: "user_id and product_id are required.",
    });
  }

  try {
    const result = await createWishlistLogs(
      user_id,
      product_id,
      is_added,
      created_at
    );

    return res.status(200).json({ ...result });
  } catch (error: any) {
    sendErrorEmail("createWishlistLog error.", error, req.body);

    return res
      .status(200)
      .json({ status: 500, message: "Internal server error." });
  }
};

export const wishlistLog = async (req: Request, res: Response) => {
  const { user_id, wishlist_local } = req.body;
  try {
    const result = await wishlistLogs(user_id, wishlist_local);
    return res.status(200).json({ ...result });
  } catch (error: any) {
    sendErrorEmail("wishlistLog error.", error, req.body);

    return res
      .status(200)
      .json({ status: 500, message: "Internal server error." });
  }
};
