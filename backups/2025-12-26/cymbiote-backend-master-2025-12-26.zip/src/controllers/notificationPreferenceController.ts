// controllers/merchantNotificationPreference.controller.ts
import { Request, Response } from "express";
import {
  Preference,
  sanitizeRules, // ✅ use your helper
  ALLOWED_CODES, // (optional) for error messages
} from "../types/notifyPerference/notificationPreference";
import { upsertMerchantNotifPrefService } from "../services/notificationPreferenceService";
import { sendErrorEmail } from "../services/emailService";

// Parse a single row's rules (DB returns NVARCHAR string)
const parseRulesFromRow = (row: any) => {
  const raw = row?.notification_preference_rules;
  let arr: unknown = [];

  if (Array.isArray(raw)) {
    arr = raw;
  } else if (typeof raw === "string") {
    try {
      arr = JSON.parse(raw);
    } catch {
      arr = [];
    }
  }

  row.notification_preference_rules = sanitizeRules(arr as any[]);
  return row;
};

export const upsertMerchantNotifPrefController = async (
  req: Request,
  res: Response
) => {
  try {
    const { userId, merchantId, preference, rules } = req.body as {
      userId?: number | string;
      merchantId?: number | string;
      preference?: Preference;
      rules?: any[];
    };

    // Basic validation
    if (userId == null || merchantId == null || !preference) {
      return res.status(400).json({
        status: 400,
        message:
          "userId, merchantId, and preference ('all'|'none'|'personalized') are required",
      });
    }

    // Coerce to numbers
    const uid = Number(userId);
    const mid = Number(merchantId);
    if (Number.isNaN(uid) || Number.isNaN(mid)) {
      return res.status(400).json({
        status: 400,
        message: "userId and merchantId must be valid numbers",
      });
    }

    if (!["all", "none", "personalized"].includes(preference)) {
      return res.status(400).json({
        status: 400,
        message: "preference must be 'all' | 'none' | 'personalized'",
      });
    }

    // ✅ Sanitize rules up front (only for personalized)
    const cleanCodes =
      preference === "personalized" ? sanitizeRules(rules) : [];
    if (preference === "personalized" && cleanCodes.length === 0) {
      return res.status(400).json({
        status: 400,
        message:
          "At least one valid rule is required for 'personalized'. Allowed: " +
          Array.from(ALLOWED_CODES).join(", "),
      });
    }

    // Call service (pass sanitized codes only)
    const dbRow = await upsertMerchantNotifPrefService(
      uid,
      mid,
      preference,
      cleanCodes
    );

    // ✅ Normalize/parse before sending (string -> array)
    const normalized = Array.isArray(dbRow)
      ? dbRow.map(parseRulesFromRow)
      : parseRulesFromRow(dbRow);

    return res.status(200).json({
      status: 200,
      message: "Merchant notification preference saved",
      data: normalized,
    });
  } catch (error: any) {
    sendErrorEmail("upsertMerchantNotifPrefController error:", error, req.body);
    console.error("upsertMerchantNotifPrefController error:", error);
    return res.status(500).json({
      status: 500,
      message: "Failed to save merchant notification preference",
    });
  }
};
