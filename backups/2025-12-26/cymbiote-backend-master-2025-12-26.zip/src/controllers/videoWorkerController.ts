import { Request, Response } from "express";
import { sendErrorEmail } from "../services/emailService";
import { startVideoProcessing } from "../workers/videoWorker";

export const startVideoWorker = async (req: Request, res: Response) => {
     try {
       const result = startVideoProcessing();
       if (!result) {
         return res.status(200).json({
           status: 400,
           message: "Worker failed to start (are you calling from a worker thread?)",
         });
       }
       return res.status(200).json({ status: 200, message: "Video Worker Started Successfully" });
     } catch (error: any) {
       sendErrorEmail("Video Worker error.", error, req.body);
   
       return res
         .status(200) // Keep 200 as per user pattern, though 500 is better
         .json({ status: 500, message: "Error starting video worker." });
     }
};
