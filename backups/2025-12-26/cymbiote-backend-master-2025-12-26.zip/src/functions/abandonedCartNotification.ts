// Abandoned-cart notification job (24h cadence with smart timing)
// -----------------------------------------------------------------
import { poolPromise } from "../config/db";
import { getFcmTokens } from "../models/notifications/notificationModel";
import { sendErrorEmail } from "../services/emailService";
import { sendFCMNotification } from "../services/notificationService";
import { checkNotification } from "./notificationSettings";
import {
  isOptimalNotificationTime,
  getNextOptimalNotificationTime,
} from "./smartNotificationTiming";

const ABANDONED_CART_NOTIF_KEY = "notification_setting_abandone_cart";

/**
 * Smart abandoned cart notifications with personalized timing
 *
 * How it works:
 * 1. Finds carts that are 24h+ old and haven't been notified in last 24h
 * 2. For each user, checks their Firebase Analytics app_open patterns
 * 3. Sends notification 30 min before user typically opens the app
 * 4. If no pattern exists (new user/insufficient data), allows notification anytime
 * 5. Continues daily at user's optimal time until cart is cleared
 */
export const sendAbandonedCartNotifications = async () => {
  try {
    const abandonedCarts = await getCartsEligibleFor24hCadence();

    if (!abandonedCarts || abandonedCarts.length === 0) {
      console.log(
        "❌ No eligible abandoned carts (>=24h) or all throttled <24h."
      );
      console.log(
        "\n   💡 Debug endpoint: GET /api/notification/debug-abandoned-carts"
      );
      return;
    }

    console.log(
      `🛒 Found ${abandonedCarts.length} cart(s) from ${getUniqueUserCount(
        abandonedCarts
      )} user(s). Checking optimal notification times...`
    );

    const cartsByUser = groupCartsByUser(abandonedCarts);

    let successCount = 0;
    let failureCount = 0;
    let skippedCount = 0;

    for (const [userId, userCarts] of cartsByUser.entries()) {
      try {
        const result = await sendGenericCartReminderToUser(userId, userCarts);
        // If result is undefined, notification was skipped (not optimal time)
        if (result === false) {
          skippedCount++;
        } else {
          successCount++;
        }
      } catch (error: any) {
        failureCount++;
        console.error(
          `Failed to send notification to user ${userId}:`,
          error?.message || error
        );
      }
    }

    console.log(
      `📊 Smart notification process completed. Sent: ${successCount}, Skipped (waiting for optimal time): ${skippedCount}, Failed: ${failureCount}`
    );
  } catch (error: any) {
    sendErrorEmail("Error in sendAbandonedCartNotifications:", error);
    console.error("Error in sendAbandonedCartNotifications:", error);
  }
};

export const getCartsEligibleFor24hCadence = async (): Promise<
  {
    cart_id: string;
    user_id: number;
    shop_id: number;
    item_count: number;
    created_at: Date;
  }[]
> => {
  try {
    const pool = await poolPromise;

    const query = `
      SELECT
        pc.pre_cart_id         AS cart_id,
        pc.pre_cart_user_id    AS user_id,
        pc.pre_cart_shop_id    AS shop_id,
        COUNT(pci.pre_cart_item_id) AS item_count,
        pc.created_at
      FROM Pre_Cart pc
      INNER JOIN Pre_Cart_Items pci
        ON pc.pre_cart_id = pci.pre_cart_id
      INNER JOIN Shop s
        ON pc.pre_cart_shop_id = s.shop_id
      INNER JOIN Product p
        ON pci.pre_cart_item_product_id = p.product_id
      INNER JOIN Product_Variants pv
        ON pci.pre_cart_item_variant_id = pv.variant_id
      WHERE pc.pre_cart_user_id IS NOT NULL
        AND pc.created_at <= DATEADD(HOUR, -24, GETDATE())  -- >= 24h old
        AND s.shop_is_active = 1  -- Only active shops
        AND (s.shop_delisted = 0 OR s.shop_delisted IS NULL)  -- Exclude delisted shops
        AND p.product_is_active = 1  -- Only active products
        AND pv.variant_is_active = 1  -- Only active variants
        AND NOT EXISTS (
          SELECT 1
          FROM App_Notifications an
          WHERE an.app_notification_user_id = pc.pre_cart_user_id
            AND an.app_notification_last_sent_at >= DATEADD(HOUR, -24, GETDATE()) -- sent within last 24h
            AND (
              (ISJSON(an.app_notification_payload) = 1
                AND JSON_VALUE(an.app_notification_payload, '$.notificationEvent') = @key)
              OR
              (ISJSON(an.app_notification_payload) = 0
                AND an.app_notification_payload LIKE @likeKey)
            )
        )
      GROUP BY pc.pre_cart_id, pc.pre_cart_user_id, pc.pre_cart_shop_id, pc.created_at
      HAVING COUNT(pci.pre_cart_item_id) > 0
    `;

    const result = await pool
      .request()
      .input("key", ABANDONED_CART_NOTIF_KEY)
      .input("likeKey", `%"notificationEvent":"${ABANDONED_CART_NOTIF_KEY}"%`)
      .query(query);

    return result.recordset.map((row: any) => ({
      cart_id: row.cart_id,
      user_id: row.user_id,
      shop_id: row.shop_id,
      item_count: Number(row.item_count) || 0,
      created_at: row.created_at,
    }));
  } catch (error: any) {
    sendErrorEmail("Error in getCartsEligibleFor24hCadence:", error);
    console.error("Error in getCartsEligibleFor24hCadence:", error);
    throw new Error("Error fetching eligible 24h carts");
  }
};

const sendGenericCartReminderToUser = async (
  userId: number,
  userCarts: {
    cart_id: string;
    user_id: number;
    shop_id: number;
    item_count: number;
    created_at: Date;
  }[]
) => {
  // 3b) Re-validate carts & item counts live to avoid stale data
  const validCarts = await filterCartsWithItems(
    userCarts.map((c) => c.cart_id)
  );
  if (validCarts.length === 0) {
    console.log(`User ${userId} now has 0 items across carts. Skipping.`);
    return;
  }

  const totalItems = validCarts.reduce(
    (acc, c) => acc + (c.item_count ?? 0),
    0
  );

  // 3a) Check user preferences
  const canNotify = await checkNotification(userId, ABANDONED_CART_NOTIF_KEY);
  if (!canNotify) {
    console.log(
      `User ${userId} opted out of abandoned cart notifications. Skipping notification but updating timestamp.`
    );
    // Still update timestamp to prevent this cart from appearing again for 24h
    const { title, body } = buildGenericNotificationMessage(
      validCarts.length,
      totalItems
    );
    const payload = {
      notificationEvent: ABANDONED_CART_NOTIF_KEY,
      cartCount: validCarts.length,
      totalItems,
      cartIds: validCarts.map((c) => c.cart_id),
      isOpenBottomSheet: true,
    };
    try {
      await upsertAbandonedCartLastSent(userId, title, body, payload);
    } catch (error: any) {
      console.error(
        `Failed to update timestamp for opted-out user ${userId}:`,
        error?.message || error
      );
    }
    return;
  }

  // 3b) SMART TIMING: Check if it's the optimal time to send notification
  const isOptimalTime = await isOptimalNotificationTime(String(userId));
  if (!isOptimalTime) {
    const nextTime = await getNextOptimalNotificationTime(String(userId));
    console.log(
      `⏰ Not optimal time for user ${userId}. Cart is ready, will send at next optimal window: ${nextTime?.toISOString() || "when user typically opens app"}`
    );
    return false;
  }

  console.log(`✅ Optimal time detected for user ${userId}. Sending notification now...`);

  // 3c) Send push & upsert last_sent_at on success
  await sendGenericNotification(userId, {
    cartCount: validCarts.length,
    totalItems,
    cartIds: validCarts.map((c) => c.cart_id),
  });

  console.log(
    `✅ Sent smart-timed cart reminder to user ${userId} (${validCarts.length} cart(s), ${totalItems} item(s))`
  );
  console.log(
    `⏱️ Next eligible send after 24h at user's optimal time.`
  );
};

// ==============================
// 4) PUSH SENDER (FCM + UPSERT last_sent_at)
// ==============================
const sendGenericNotification = async (
  userId: number,
  cartData: {
    cartCount: number;
    totalItems: number;
    cartIds: string[];
  }
) => {
  try {
    const { title, body } = buildGenericNotificationMessage(
      cartData.cartCount,
      cartData.totalItems
    );

    const payload = {
      notificationEvent: ABANDONED_CART_NOTIF_KEY,
      cartCount: cartData.cartCount,
      totalItems: cartData.totalItems,
      cartIds: cartData.cartIds,
      isOpenBottomSheet: true,
    };

    const fcmTokens = await getFcmTokens(String(userId));

    // If user has FCM tokens, send the notification
    if (fcmTokens && fcmTokens.length > 0) {
      const MessageData = {
        title,
        body,
        DeviceToken: JSON.stringify(Array.from(new Set(fcmTokens))), // de-dupe tokens
        screenName: "Cart",
        type: "token",
        payload: JSON.stringify(payload),
      };

      const notificationResult = await sendFCMNotification(
        fcmTokens,
        MessageData
      );

      console.log(
        `Generic notification sent to user ${userId}. Result:`,
        notificationResult
      );
    } else {
      console.log(
        `No FCM tokens for user ${userId}. Skipping notification send.`
      );
    }

    // ALWAYS update timestamp regardless of FCM token availability
    // This ensures 24-hour cadence is respected even if user has no tokens
    try {
      await upsertAbandonedCartLastSent(userId, title, body, payload);
    } catch (dbError: any) {
      console.error(
        `WARNING: Failed to update notification timestamp for user ${userId}:`,
        dbError?.message || dbError
      );
      // Don't throw - we attempted notification, log the DB error
    }
  } catch (error: any) {
    console.error(
      `Error sending generic notification to user ${userId}:`,
      error?.message || error
    );
    throw error;
  }
};

// ==============================
// 5) UTIL: UPSERT last_sent_at (STRICT 24h CADENCE)
// ==============================
const upsertAbandonedCartLastSent = async (
  userId: number,
  title: string,
  body: string,
  payload: any
): Promise<void> => {
  const pool = await poolPromise;

  // Match only ABANDONED_CART notifications for this user
  const sql = `
    MERGE App_Notifications AS target
    USING (SELECT @userId AS user_id, @key AS notif_key) AS src
      ON target.app_notification_user_id = src.user_id
      AND (
        (ISJSON(target.app_notification_payload) = 1
          AND JSON_VALUE(target.app_notification_payload, '$.notificationEvent') = src.notif_key)
        OR
        (ISJSON(target.app_notification_payload) = 0
          AND target.app_notification_payload LIKE @likeKey)
      )

    WHEN MATCHED THEN
      UPDATE SET
        target.app_notification_title = @title,
        target.app_notification_body = @body,
        target.app_notification_payload = @payload,
        target.app_notification_last_sent_at = GETDATE()
    WHEN NOT MATCHED THEN
      INSERT (app_notification_user_id, app_notification_title, app_notification_body, app_notification_payload, app_notification_last_sent_at)
      VALUES (@userId, @title, @body, @payload, GETDATE());
  `;

  await pool
    .request()
    .input("userId", userId)
    .input("title", title)
    .input("body", body)
    .input("key", ABANDONED_CART_NOTIF_KEY)
    .input("likeKey", `%"notificationEvent":"${ABANDONED_CART_NOTIF_KEY}"%`)
    .input("payload", JSON.stringify(payload))
    .query(sql);
};

// ==============================
// 6) UTIL: GROUP & HELPERS
// ==============================
const groupCartsByUser = (
  carts: {
    cart_id: string;
    user_id: number;
    shop_id: number;
    item_count: number;
    created_at: Date;
  }[]
): Map<
  number,
  {
    cart_id: string;
    user_id: number;
    shop_id: number;
    item_count: number;
    created_at: Date;
  }[]
> => {
  const map = new Map<number, any[]>();
  for (const c of carts) {
    const arr = map.get(c.user_id) || [];
    arr.push(c);
    map.set(c.user_id, arr);
  }
  return map;
};

const getUniqueUserCount = (carts: { user_id: number }[]): number =>
  new Set(carts.map((c) => c.user_id)).size;

// Re-fetch live item counts for a set of cart_ids; return only carts with count > 0
const filterCartsWithItems = async (
  cartIds: string[]
): Promise<{ cart_id: string; item_count: number }[]> => {
  if (cartIds.length === 0) return [];

  const pool = await poolPromise;

  // Use a temp table approach for safety & scale
  const tmpTableName = "#CartIds";
  const createTmp = `CREATE TABLE ${tmpTableName} (cart_id NVARCHAR(100) NOT NULL);`;
  const insertRows = cartIds.map((_, i) => `(@c${i})`).join(", ");

  const query = `
    ${createTmp}
    INSERT INTO ${tmpTableName} (cart_id) VALUES ${insertRows};

    SELECT
      pc.pre_cart_id AS cart_id,
      COUNT(pci.pre_cart_item_id) AS item_count
    FROM Pre_Cart pc
    INNER JOIN Pre_Cart_Items pci ON pc.pre_cart_id = pci.pre_cart_id
    INNER JOIN ${tmpTableName} t ON t.cart_id = pc.pre_cart_id
    GROUP BY pc.pre_cart_id
    HAVING COUNT(pci.pre_cart_item_id) > 0;

    DROP TABLE ${tmpTableName};
  `;

  const req = pool.request();
  cartIds.forEach((id, i) => req.input(`c${i}`, id));

  const result = await req.query(query);
  return result.recordset.map((r: any) => ({
    cart_id: r.cart_id,
    item_count: Number(r.item_count) || 0,
  }));
};

const buildGenericNotificationMessage = (
  cartCount: number,
  totalItems: number
) => {
  const title =
    cartCount > 1
      ? `You have ${cartCount} carts waiting`
      : `Your cart is waiting`;

  const body =
    totalItems > 1
      ? `You left ${totalItems} items in your cart. Tap to review.`
      : `You left an item in your cart. Tap to review.`;

  return { title, body };
};
