import dotenv from "dotenv";
import axios from "axios";
import { sendErrorEmail } from "../services/emailService";
dotenv.config();

export const exchangeGoogleAuthCodeForTokens = async (authCode = "") => {
  try {
    const response = await axios.post("https://oauth2.googleapis.com/token", {
      client_id: process.env.GOOGLE_CLIENT_ID,
      client_secret: process.env.GOOGLE_CLIENT_SECRET,
      redirect_uri: "http://localhost:3000/auth/callback",
      code: authCode,
      grant_type: "authorization_code",
    });
    return response;
  } catch (error: any) {
    sendErrorEmail(error?.message, error);

    console.log("error", error?.message);
    return null;
  }
};

export const getGoogleAccessToken = async (
  refresh_token: string,
  show_messages?: boolean
): Promise<any> => {
  try {
    const response = await axios.post("https://oauth2.googleapis.com/token", {
      client_id: process.env.GOOGLE_CLIENT_ID, // Your Google OAuth Client ID
      client_secret: process.env.GOOGLE_CLIENT_SECRET, // Your Client Secret
      refresh_token: refresh_token,
      grant_type: "refresh_token",
    });
    if (show_messages) {
      try {
        const getMessages = await getGoogleMessages(response.data.access_token);
        return getMessages;
      } catch (error: any) {
        sendErrorEmail("error inner =>", error);

        console.log("error inner =>", error?.message);
        return [];
      }
      // Assuming getGoogleMessages returns a value of type GoogleAccessTokenResponse
    } else {
      return { status: true, message: "active" };
    }
  } catch (error: any) {
    console.log("error =>", error?.message);
    return { status: false, message: "disconnected" };
  }
};

export const getGoogleMessages = async (access_token: string) => {
  try {
    const response = await axios.get(
      "https://gmail.googleapis.com/gmail/v1/users/me/messages?q=subject:order",
      {
        headers: {
          Authorization: `Bearer ${access_token}`,
        },
      }
    );

    const data = response?.data?.messages || [];

    const modifiedData = Promise.all(
      data.map(async (message: any) => {
        const messageDetail = await getGoogleMessageDetail(
          message.id,
          access_token
        );
        return messageDetail;
      })
    );

    return modifiedData;
  } catch (error: any) {
    sendErrorEmail("error", error);

    console.log("error", error?.message);
    return null;
  }
};

const getGoogleMessageDetail = async (
  message_id: string,
  access_token: string
): Promise<any> => {
  try {
    const response = await axios.get(
      `https://gmail.googleapis.com/gmail/v1/users/me/messages/${message_id}`,
      {
        headers: { Authorization: `Bearer ${access_token}` },
      }
    );

    return extractOrderDetails(response.data);
  } catch (error: any) {
    sendErrorEmail("error", error);

    console.log("error", error?.message);
    return null;
  }
};

// ✅ Function to Extract Order Details
const extractOrderDetails = (emailData: any) => {
  const emailBody = getEmailBody(emailData);
  return { email_body: emailBody };
};

const getEmailBody = (emailData: any): string => {
  let emailBody = "";

  if (emailData.payload.parts) {
    emailData.payload.parts.forEach((part: any) => {
      if (part.mimeType === "text/plain" || part.mimeType === "text/html") {
        const decodedData = Buffer.from(part.body.data, "base64").toString(
          "utf-8"
        );
        emailBody += decodedData + "\n";
      }
    });
  } else if (emailData.payload.body && emailData.payload.body.data) {
    emailBody = Buffer.from(emailData.payload.body.data, "base64").toString(
      "utf-8"
    );
  }

  return emailBody || "No email body available";
};
