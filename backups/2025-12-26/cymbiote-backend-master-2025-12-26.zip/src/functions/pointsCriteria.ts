import { Criteria } from "../types/points/criteria";
import * as pointsModel from "../models/points/userPoints";

export const applyAllOrderCriteria = async (
  dbCriteria: any,
  points: number,
  transactionValue: number,
  userId: number,
  shopId: number
): Promise<{ currentPoints: number; pointsLogId: number }> => {
  let currentPoints = points;

  // Calculate points based on criteria value
  const givingPoints = transactionValue * dbCriteria.criteria_value;
  currentPoints = currentPoints + givingPoints;

  // Log points for the user
  const description = `Earned ${givingPoints.toFixed(3)} points for ${
    dbCriteria.criteria_name
  }`;
  const pointsLogId = await pointsModel.logUserPoints(
    userId,
    shopId,
    dbCriteria.criteria_id,
    givingPoints,
    description,
    "pending"
  );
  console.log("Points iD", pointsLogId);

  return { currentPoints, pointsLogId };
};

export const applyProductOrderCriteria = async (
  dbCriteria: any,
  itemPrice: number,
  points: number,
  userId: number,
  shopId: number
): Promise<{ currentPoints: number; pointsLogId: number }> => {
  let currentPoints = points;
  const givingPoints = itemPrice * dbCriteria.criteria_value;
  currentPoints = currentPoints + givingPoints;
  const description = `Earned ${givingPoints.toFixed(3)} points for ${
    dbCriteria.criteria_name
  }`;
  const pointsLogId = await pointsModel.logUserPoints(
    userId,
    shopId,
    dbCriteria.criteria_id,
    givingPoints,
    description,
    "pending"
  );
  console.log("Points iD", pointsLogId);

  return { currentPoints, pointsLogId };
};
