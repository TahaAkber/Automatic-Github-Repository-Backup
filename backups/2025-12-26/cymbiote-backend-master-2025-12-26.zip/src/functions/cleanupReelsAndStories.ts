import { poolPromise } from "../config/db";
import { sendErrorEmail } from "../services/emailService";
import axios from "axios";

const BUNNY_LIBRARY_ID = process.env.BUNNY_STREAM_LIBRARY_ID;
const BUNNY_API_KEY = process.env.BUNNY_STREAM_API_KEY;


const extractBunnyGuid = (url: string): string | null => {
  if (!url || !url.includes("b-cdn.net")) return null;

  const match = url.match(/b-cdn\.net\/([^\/]+)/);
  return match ? match[1] : null;
};


const deleteBunnyVideo = async (guid: string): Promise<boolean> => {
  if (!BUNNY_LIBRARY_ID || !BUNNY_API_KEY) {
    console.warn("[BUNNY] Missing Bunny credentials, skipping video deletion");
    return false;
  }

  const endpoint = `https://video.bunnycdn.com/library/${BUNNY_LIBRARY_ID}/videos/${guid}`;

  try {
    await axios.delete(endpoint, {
      headers: {
        AccessKey: BUNNY_API_KEY,
      },
      timeout: 30000,
    });
    console.log(`[BUNNY] Successfully deleted video ${guid}`);
    return true;
  } catch (error: any) {
    console.error(
      `[BUNNY] Failed to delete video ${guid}: ${error.message}`
    );
    return false;
  }
};

export const deleteOldReelsAndStories = async (): Promise<{
  deletedCount: number;
  message: string;
}> => {
  const pool = await poolPromise;
  const startTime = Date.now();

  console.log(
    `[CRON] Starting cleanup of old reels and stories at ${new Date().toISOString()}`
  );

  try {
    // Get video URLs for old reels/stories so we can delete from Bunny
    const oldReelsWithVideosQuery = `
      SELECT
        rs.id,
        v.video_url,
        v.video_url_preview
      FROM ReelsNStories rs
      JOIN Videos v ON rs.video_url_id = v.video_id
      WHERE rs.created_at < DATEADD(DAY, -60, GETDATE());
    `;

    const oldReels = await pool.request().query(oldReelsWithVideosQuery);
    const oldReelRecords = oldReels.recordset;

    if (oldReelRecords.length === 0) {
      console.log("[CRON] No old reels/stories found to delete");
      return {
        deletedCount: 0,
        message: "No reels/stories older than 60 days found",
      };
    }

    console.log(
      `[CRON] Found ${oldReelRecords.length} reels/stories older than 60 days`
    );

    // Delete videos from Bunny CDN
    let bunnyDeletedCount = 0;
    let bunnyFailedCount = 0;
    const uniqueGuids = new Set<string>();

    for (const record of oldReelRecords) {
      // Extract and delete main video
      const mainGuid = extractBunnyGuid(record.video_url);
      if (mainGuid && !uniqueGuids.has(mainGuid)) {
        uniqueGuids.add(mainGuid);
        const deleted = await deleteBunnyVideo(mainGuid);
        if (deleted) {
          bunnyDeletedCount++;
        } else {
          bunnyFailedCount++;
        }
      }

      // Extract and delete preview video
      const previewGuid = extractBunnyGuid(record.video_url_preview);
      if (previewGuid && !uniqueGuids.has(previewGuid)) {
        uniqueGuids.add(previewGuid);
        const deleted = await deleteBunnyVideo(previewGuid);
        if (deleted) {
          bunnyDeletedCount++;
        } else {
          bunnyFailedCount++;
        }
      }
    }

    console.log(
      `[CRON] Bunny deletion complete: ${bunnyDeletedCount} succeeded, ${bunnyFailedCount} failed`
    );

    // Delete from Saved_ReelsNStories
    const deleteSavedQuery = `
      DELETE FROM Saved_ReelsNStories
      WHERE saved_video_id IN (
        SELECT id FROM ReelsNStories
        WHERE created_at < DATEADD(DAY, -60, GETDATE())
      );
    `;
    const savedResult = await pool.request().query(deleteSavedQuery);
    console.log(
      `[CRON] Deleted ${savedResult.rowsAffected[0]} records from Saved_ReelsNStories`
    );

    const deleteLikedQuery = `
      DELETE FROM Liked_ReelsNStories
      WHERE liked_video_id IN (
        SELECT id FROM ReelsNStories
        WHERE created_at < DATEADD(DAY, -60, GETDATE())
      );
    `;
    const likedResult = await pool.request().query(deleteLikedQuery);
    console.log(
      `[CRON] Deleted ${likedResult.rowsAffected[0]} records from Liked_ReelsNStories`
    );

    const deleteReelsProductsQuery = `
      DELETE FROM Reels_Products
      WHERE reel_video_id IN (
        SELECT video_url_id FROM ReelsNStories
        WHERE created_at < DATEADD(DAY, -60, GETDATE())
      );
    `;
    const reelsProductsResult = await pool
      .request()
      .query(deleteReelsProductsQuery);
    console.log(
      `[CRON] Deleted ${reelsProductsResult.rowsAffected[0]} records from Reels_Products`
    );

    const deleteReelsQuery = `
      DELETE FROM ReelsNStories
      WHERE created_at < DATEADD(DAY, -60, GETDATE());
    `;
    const reelsResult = await pool.request().query(deleteReelsQuery);
    const deletedCount = reelsResult.rowsAffected[0];

    const duration = ((Date.now() - startTime) / 1000).toFixed(2);
    const message = `Successfully deleted ${deletedCount} reels/stories older than 60 days in ${duration}s`;

    console.log(`[CRON] ${message}`);

    return {
      deletedCount,
      message,
    };
  } catch (error: any) {
    const errorMessage = `Error deleting old reels and stories: ${error.message}`;
    sendErrorEmail(errorMessage, error);
    console.error(`[CRON] ${errorMessage}`, error);
    throw new Error("Failed to delete old reels and stories");
  }
};

