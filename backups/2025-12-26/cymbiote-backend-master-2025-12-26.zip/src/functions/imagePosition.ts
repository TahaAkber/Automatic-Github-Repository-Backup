export const areImagesSame = (
  shopifyImages: any[] = [],
  dbImages: any[] = []
) => {
  // 1) Normalize both arrays to the same shape: { src, position }
  const normalize = (img: any) => ({
    src: img.src ?? img.product_image_url,
    position: img.position ?? img.product_image_position,
  });

  const a = shopifyImages.map(normalize);
  const b = dbImages.map(normalize);

  // 2) Length must match
  if (a.length !== b.length) return false;

  // 3) Sort by position (and fallback by src just in case)
  const sortByPosition = (arr: any[]) =>
    [...arr].sort((x, y) => {
      if (x.position === y.position) {
        return (x.src || "").localeCompare(y.src || "");
      }
      return (x.position ?? 0) - (y.position ?? 0);
    });

  const sortedA = sortByPosition(a);
  const sortedB = sortByPosition(b);

  // 4) Compare src + position one by one
  const isSame = sortedA.every(
    (img, i) =>
      img.src === sortedB[i].src && img.position === sortedB[i].position
  );

  // Optional: debug
  console.log("A norm:", sortedA);
  console.log("B norm:", sortedB);
  console.log("imagesSame:", isSame);

  return isSame;
};
