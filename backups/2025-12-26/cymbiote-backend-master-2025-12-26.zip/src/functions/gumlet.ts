import axios from "axios";
import dotenv from "dotenv";

dotenv.config();

export const uploadToGumlet = async (
  videoType: string,
  videoUrl: string,
  format = "ABR"
): Promise<string> => {
  try {
    const response = await axios.post(
      "https://api.gumlet.com/v1/video/assets",
      {
        input: videoUrl,
        collection_id: process.env.GUMLET_COLLECTION_ID,
        format,
        title: videoType + "_compress_upload",
      },
      {
        headers: {
          Authorization: `Bearer ${process.env.GUMLET_API_KEY}`,
          "Content-Type": "application/json",
        },
      }
    );

    console.log("uploadedToGumlet", response.data.output?.playback_url);

    return response.data?.output?.playback_url;
  } catch (error: any) {
    throw new Error("Error while uploadaing to Gumlet" + error.message);
  }
};
