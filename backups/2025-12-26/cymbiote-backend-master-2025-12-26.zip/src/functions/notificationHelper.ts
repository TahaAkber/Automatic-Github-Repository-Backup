export const getNotificationTitle = (normalizedStatus: string) => {
  switch (normalizedStatus) {
    case "IN_PROGRESS":
    case "INPROGRESS":
      return "Your Order is Being Prepared";

    case "IN_TRANSIT":
    case "INTRANSIT":
      return "Your Order is On the Way";

    case "OUT_FOR_DELIVERY":
    case "OUTFORDELIVERY":
      return "Your Order is Out for Delivery";

    case "DELIVERYFAILURE":
      return "Delivery Attempt Failed";

    case "NOTFOUND":
      return "Tracking Not Found";

    case "DELIVERED":
      return "Your Order Has Been Delivered";

    default:
      return "Your Tracking Has Been Updated";
  }
};
