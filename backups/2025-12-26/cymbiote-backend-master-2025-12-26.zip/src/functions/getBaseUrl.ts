export default function getBaseUrl(url: string): string {
  const match = url.match(/^https?:\/\/[^\/]+\/?/);
  return match ? match[0] : url; // fallback: return original if no match
}
