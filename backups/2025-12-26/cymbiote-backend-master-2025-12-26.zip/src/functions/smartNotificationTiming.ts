// Smart notification timing based on user's app open patterns
import bigquery from "../firebase/bqClient";
import { sendErrorEmail } from "../services/emailService";

const { GA_PROJECT, GA_DATASET, GA_LOCATION, GA_STREAM_ID, GA_PACKAGE_NAME } =
  process.env;

interface AppOpenEvent {
  event_timestamp: number;
  hour: number;
  user_id: string;
}

/**
 * Fetch user's app_open events from the last 30 days
 * @param userId - The user ID to fetch events for
 * @returns Array of app_open events with timestamps
 */
export const getUserAppOpenEvents = async (
  userId: string
): Promise<AppOpenEvent[]> => {
  try {
    const table = `\`${GA_PROJECT}.${GA_DATASET}.events_*\``;

    // Get last 30 days of data for better pattern analysis
    const endDate = new Date();
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - 30);

    const startSuffix = formatDateToSuffix(startDate);
    const endSuffix = formatDateToSuffix(endDate);

    const query = `
      SELECT
        event_timestamp,
        EXTRACT(HOUR FROM TIMESTAMP_MICROS(event_timestamp) AT TIME ZONE 'UTC') AS hour,
        (SELECT ep.value.string_value FROM UNNEST(event_params) ep WHERE ep.key = "user_id" LIMIT 1) AS user_id
      FROM ${table}
      WHERE _TABLE_SUFFIX BETWEEN @startSuffix AND @endSuffix
        AND event_name = 'app_open'
        AND EXISTS (
          SELECT 1 FROM UNNEST(event_params) ep
          WHERE ep.key = "user_id" AND ep.value.string_value = @userId
        )
        ${GA_STREAM_ID ? "AND stream_id = @streamId" : ""}
        ${GA_PACKAGE_NAME ? "AND app_info.id = @packageName" : ""}
      ORDER BY event_timestamp DESC
      LIMIT 1000
    `;

    const params: Record<string, any> = {
      startSuffix,
      endSuffix,
      userId,
    };

    if (GA_STREAM_ID) params.streamId = GA_STREAM_ID;
    if (GA_PACKAGE_NAME) params.packageName = GA_PACKAGE_NAME;

    const [rows] = await bigquery.query({
      query,
      params,
      location: GA_LOCATION,
    });

    return rows.map((row: any) => ({
      event_timestamp: row.event_timestamp,
      hour: row.hour,
      user_id: row.user_id,
    }));
  } catch (error: any) {
    sendErrorEmail("Error fetching user app open events:", error);
    console.error("Error fetching user app open events:", error);
    throw error;
  }
};

/**
 * Analyze user's app open patterns and find the most common hour they open the app
 * @param userId - The user ID to analyze
 * @returns The most common hour (0-23) when user opens the app, or null if insufficient data
 */
export const getMostCommonAppOpenHour = async (
  userId: string
): Promise<number | null> => {
  try {
    const events = await getUserAppOpenEvents(userId);

    // Need at least 5 events to establish a pattern
    if (events.length < 5) {
      console.log(
        `User ${userId} has insufficient app_open events (${events.length}). Need at least 5.`
      );
      return null;
    }

    // Count occurrences of each hour
    const hourCounts = new Map<number, number>();

    events.forEach((event) => {
      const hour = event.hour;
      hourCounts.set(hour, (hourCounts.get(hour) || 0) + 1);
    });

    // Find the hour with maximum occurrences
    let maxCount = 0;
    let mostCommonHour = null;

    hourCounts.forEach((count, hour) => {
      if (count > maxCount) {
        maxCount = count;
        mostCommonHour = hour;
      }
    });

    console.log(
      `User ${userId} most commonly opens app at hour ${mostCommonHour} (${maxCount} times out of ${events.length} events)`
    );

    return mostCommonHour;
  } catch (error: any) {
    sendErrorEmail("Error analyzing app open patterns:", error);
    console.error("Error analyzing app open patterns:", error);
    return null;
  }
};

/**
 * Calculate optimal notification time based on user's typical app open hour
 * @param userId - The user ID
 * @returns Object with optimal hour and minute to send notification, or null if no pattern found
 */
export const calculateOptimalNotificationTime = async (
  userId: string
): Promise<{ hour: number; minute: number } | null> => {
  try {
    const mostCommonHour = await getMostCommonAppOpenHour(userId);

    if (mostCommonHour === null) {
      console.log(
        `No optimal time found for user ${userId}. Will use default timing.`
      );
      return null;
    }

    // Send notification 30 minutes before their typical open time
    const notificationMinute = 30; // Fixed at 30 minutes before the hour
    let notificationHour = mostCommonHour - 1;

    // Handle wrap around midnight
    if (notificationHour < 0) {
      notificationHour = 23;
    }

    console.log(
      `Optimal notification time for user ${userId}: ${String(
        notificationHour
      ).padStart(2, "0")}:${String(notificationMinute).padStart(2, "0")} (30 min before typical open at ${String(mostCommonHour).padStart(2, "0")}:00)`
    );

    return {
      hour: notificationHour,
      minute: notificationMinute,
    };
  } catch (error: any) {
    sendErrorEmail("Error calculating optimal notification time:", error);
    console.error("Error calculating optimal notification time:", error);
    return null;
  }
};

/**
 * Check if current time matches the optimal notification time for a user
 * @param userId - The user ID
 * @param currentTime - Current date/time (defaults to now)
 * @returns true if it's the optimal time to send notification, false otherwise
 */
export const isOptimalNotificationTime = async (
  userId: string,
  currentTime: Date = new Date()
): Promise<boolean> => {
  try {
    const optimalTime = await calculateOptimalNotificationTime(userId);

    // If no pattern found, allow notification at any time (fall back to default behavior)
    if (!optimalTime) {
      return true;
    }

    const currentHour = currentTime.getUTCHours();
    const currentMinute = currentTime.getMinutes();

    // Check if current time matches optimal time (within a 10-minute window)
    const isOptimalHour = currentHour === optimalTime.hour;
    const isWithinMinuteWindow =
      currentMinute >= optimalTime.minute &&
      currentMinute < optimalTime.minute + 10;

    return isOptimalHour && isWithinMinuteWindow;
  } catch (error: any) {
    sendErrorEmail("Error checking optimal notification time:", error);
    console.error("Error checking optimal notification time:", error);
    // On error, default to allowing notification
    return true;
  }
};

/**
 * Get the next optimal notification time for a user
 * @param userId - The user ID
 * @param afterTime - Calculate next time after this date (defaults to now)
 * @returns Next optimal notification datetime, or null if no pattern
 */
export const getNextOptimalNotificationTime = async (
  userId: string,
  afterTime: Date = new Date()
): Promise<Date | null> => {
  try {
    const optimalTime = await calculateOptimalNotificationTime(userId);

    if (!optimalTime) {
      return null;
    }

    const nextTime = new Date(afterTime);
    nextTime.setUTCHours(optimalTime.hour, optimalTime.minute, 0, 0);

    // If the optimal time has already passed today, schedule for tomorrow
    if (nextTime <= afterTime) {
      nextTime.setDate(nextTime.getDate() + 1);
    }

    return nextTime;
  } catch (error: any) {
    sendErrorEmail("Error getting next optimal notification time:", error);
    console.error("Error getting next optimal notification time:", error);
    return null;
  }
};

// Helper function to format date to BigQuery table suffix format (YYYYMMDD)
const formatDateToSuffix = (date: Date): string => {
  const year = date.getUTCFullYear();
  const month = String(date.getUTCMonth() + 1).padStart(2, "0");
  const day = String(date.getUTCDate()).padStart(2, "0");
  return `${year}${month}${day}`;
};
