import axios from "axios";
import dotenv from "dotenv";
import * as cheerio from "cheerio";
import { ParsedDHLResponse } from "../types/courier/ParsedDHLResponse";
import { capsFirstLetter } from "./common";

dotenv.config();

const DHL_API_KEY = process.env.DHL_API_KEY || "";
const BARQ_BASE = process.env.BARQ_BASE || "";
const TCS_BEARER = process.env.TCS_BEARER || "";

export const getDhlTracking = async (trackingNumber: string): Promise<any> => {
  try {
    const response = await axios.get("https://api-eu.dhl.com/track/shipments", {
      params: { trackingNumber },
      headers: {
        "DHL-API-Key": DHL_API_KEY,
      },
    });

    return {
      status: 200,
      data: response.data,
    };
  } catch (error: any) {
    // sendErrorEmail("DHL API Error: ", error);
    throw new Error(
      "DHL API Error: " + (error.response?.data?.detail || error.message)
    );
  }
};

export const getBarqRaftarTracking = async (
  trackingNumber: string
): Promise<any> => {
  try {
    const response = await axios.get(BARQ_BASE, {
      params: { tracking_number: trackingNumber },
    });

    // Barq returns { status: boolean, order: {...}, logs: [...] }
    if (!response?.data?.status) {
      return {
        status: 404,
        message: "Barq Raftar: tracking not found",
      };
    }

    return {
      status: 200,
      data: response.data,
    };
  } catch (error: any) {
    throw new Error(
      "Barq Raftar API Error: " +
        (error.response?.data?.detail || error.message)
    );
  }
};

export const getTcsTracking = async (trackingNumber: string): Promise<any> => {
  try {
    // try {
    const tcsUrl = `https://ociconnect.tcscourier.com/tracking/api/Tracking/GetDynamicTrackDetail`; // production
    // const tcsUrl = `https://devconnect.tcscourier.com/tracking/api/Tracking/GetDynamicTrackDetail`; // testing
    const response = await axios.get(tcsUrl, {
      params: { consignee: trackingNumber },
      headers: {
        Authorization: `Bearer ${TCS_BEARER}`,
      },
    });

    if (!response?.data) {
      return {
        status: 404,
        message: "TCS: tracking not found",
      };
    }

    return {
      status: 200,
      data: response.data,
    };
  } catch (error: any) {
    throw new Error(
      "TCS API Error: " + (error.response?.data?.detail || error.message)
    );
  }
};

export function parseBarqRaftarResponse(
  barqResponse: any
): ParsedDHLResponse | null {
  try {
    // console.log("barqResponse", barqResponse);
    // Barq response shape:
    // { status: boolean, order: {...}, logs: [{status, status_id, created_at}, ...] }
    if (!barqResponse?.status || !barqResponse?.order) return null;

    const order = barqResponse.order;
    const logs: Array<{
      status_id?: string;
      status?: string;
      created_at?: string;
    }> = Array.isArray(barqResponse.logs) ? barqResponse.logs : [];

    // Sort logs by time ascending to mirror “latest = first” convention if needed
    const sortedLogs = [...logs].sort((a, b) => {
      const ta = new Date(a.created_at ?? 0).getTime();
      const tb = new Date(b.created_at ?? 0).getTime();
      return tb - ta; // latest first (desc)
    });

    const latestEvent = sortedLogs[0] || null;

    const latestTimes = normalizeBarqTime(latestEvent?.created_at);
    const createdTimes = normalizeBarqTime(order?.created_at);

    const trackInfo = {
      shipping_info: {
        shipper_address: {
          country: null,
          state: null,
          city: order?.from_city || null,
          street: null,
          postal_code: null,
          coordinates: [] as any[],
        },
        recipient_address: {
          country: null,
          state: null,
          city: order?.to_city || null,
          street: null,
          postal_code: null,
          coordinates: [] as any[],
        },
      },
      latest_status: {
        status: latestEvent?.status || order?.status || null,
        sub_status: latestEvent?.status_id || order?.status_id || null,
        sub_status_descr:
          capsFirstLetter((latestEvent?.status as string) || "") ||
          capsFirstLetter(order?.status || "") ||
          null,
      },
      latest_event: {
        time_iso: latestTimes.time_iso,
        time_utc: latestTimes.time_utc,
        time_raw: latestTimes.time_raw,
        description:
          capsFirstLetter(latestEvent.status as string) ||
          capsFirstLetter((order.status as string) || "") ||
          null,
        location: null,
        stage: null,
        sub_status: latestEvent?.status_id || null,
        address: {
          country: null,
          state: null,
          city: null,
          street: null,
          postal_code: null,
          coordinates: [] as any[],
        },
      },
      time_metrics: {
        days_after_order: null,
        days_of_transit: null,
        days_of_transit_done: null,
        days_after_last_update: null,
        estimated_delivery_date: {
          source: null,
          from: null,
          to: null,
        },
      },
      milestone:
        sortedLogs.map((e) => {
          const t = normalizeBarqTime(e?.created_at);
          return {
            description: capsFirstLetter((e?.status as string) || "") || null,
            sub_status: e?.status_id || null,
            time_iso: t.time_iso,
            time_utc: t.time_utc,
            time_raw: t.time_raw,
          };
        }) || [],
      misc_info: {
        risk_factor: 0,
        service_type: null, // Barq response doesn’t provide
        weight_raw: null,
        weight_kg: null,
        pieces: null,
        dimensions: null,
        customer_number: null,
        reference_number: null,
        local_number: null,
        local_provider: null,
        local_key: 0,
      },
      tracking: {
        providers_hash: 0,
        providers: [] as any[],
      },
    };

    return {
      number: order?.number || "",
      carrier: 100010, // choose/assign your Barq Raftar carrier code in your system
      param: null,
      tag: "",
      track_info: trackInfo,
    };
  } catch (err) {
    console.error("Error parsing Barq Raftar response:", err);
    return null;
  }
}

export function parseDHLResponse(dhlResponse: any): ParsedDHLResponse | null {
  // console.log("DHL Response:", JSON.stringify(dhlResponse, null, 2));
  try {
    const shipment = dhlResponse?.shipments?.[0];
    if (!shipment) return null;

    // Map the latest event
    const latestEvent = shipment.events?.[0] || null;

    const trackInfo = {
      shipping_info: {
        shipper_address: {
          country: shipment.origin?.address?.countryCode || null,
          state: null,
          city: shipment.origin?.address?.addressLocality || null,
          street: null,
          postal_code: null,
          coordinates: [],
        },
        recipient_address: {
          country: shipment.destination?.address?.countryCode || null,
          state: null,
          city: shipment.destination?.address?.addressLocality || null,
          street: null,
          postal_code: null,
          coordinates: [],
        },
      },
      latest_status: {
        status: latestEvent?.status || null,
        sub_status: latestEvent?.statusCode || null,
        sub_status_descr: latestEvent?.description || null,
      },
      latest_event: {
        time_iso: latestEvent?.timestamp || null,
        time_utc: latestEvent
          ? new Date(latestEvent.timestamp).toISOString()
          : null,
        time_raw: {
          date: latestEvent ? latestEvent.timestamp.split("T")[0] : null,
          time: latestEvent
            ? latestEvent.timestamp.split("T")[1]?.split("+")[0]
            : null,
          timezone: null,
        },
        description: capsFirstLetter(latestEvent?.statusCode || "") || null,
        location: null,
        stage: null,
        sub_status: latestEvent?.statusCode || null,
        address: {
          country: null,
          state: null,
          city: null,
          street: null,
          postal_code: null,
          coordinates: [],
        },
      },
      time_metrics: {
        days_after_order: null,
        days_of_transit: null,
        days_of_transit_done: null,
        days_after_last_update: null,
        estimated_delivery_date: {
          source: null,
          from: null,
          to: null,
        },
      },
      milestone:
        shipment.events?.map((e: any) => ({
          description: e.description || null,
          sub_status: e.statusCode || null,
          time_iso: e.timestamp || null,
          time_utc: e.timestamp ? new Date(e.timestamp).toISOString() : null,
          time_raw: {
            date: e.timestamp ? e.timestamp.split("T")[0] : null,
            time: e.timestamp ? e.timestamp.split("T")[1]?.split("+")[0] : null,
            timezone: null,
          },
        })) || [],
      misc_info: {
        risk_factor: 0,
        service_type: shipment.service || null,
        weight_raw: null,
        weight_kg: null,
        pieces: shipment.details?.totalNumberOfPieces || null,
        dimensions: null,
        customer_number: null,
        reference_number: null,
        local_number: null,
        local_provider: null,
        local_key: 0,
      },
      tracking: {
        providers_hash: 0,
        providers: [],
      },
    };

    return {
      number: shipment.id,
      carrier: 100001,
      param: null,
      tag: "",
      track_info: trackInfo,
    };
  } catch (err) {
    console.error("Error parsing DHL response:", err);
    return null;
  }
}

function normalizeBarqTime(ts?: string | null) {
  if (!ts) {
    return {
      time_iso: null as string | null,
      time_utc: null as string | null,
      time_raw: {
        date: null as string | null,
        time: null as string | null,
        timezone: null as string | null,
      },
    };
  }

  let iso: string | null = null;
  let datePart: string | null = null;
  let timePart: string | null = null;

  // If it already includes 'T' (ISO-like), keep the DHL-style split.
  if (ts.includes("T")) {
    iso = ts;
    try {
      const d = new Date(ts);
      datePart = ts.split("T")[0] || null;
      timePart = ts.split("T")[1]?.split("+")[0]?.split("Z")[0] || null;
      return {
        time_iso: iso,
        time_utc: isNaN(d.getTime()) ? null : d.toISOString(),
        time_raw: { date: datePart, time: timePart, timezone: null },
      };
    } catch {
      /* fallthrough to try parse as raw */
    }
  }

  // Barq logs format: "YYYY-MM-DD HH:mm:ss"
  // Treat as local/naive and convert to ISO UTC for time_utc.
  const m = ts.match(/^(\d{4}-\d{2}-\d{2})[ T](\d{2}:\d{2}:\d{2})$/);
  if (m) {
    datePart = m[1];
    timePart = m[2];
    const local = new Date(`${datePart}T${timePart}`);
    return {
      time_iso: `${datePart}T${timePart}`, // mimic DHL style (no TZ suffix)
      time_utc: isNaN(local.getTime()) ? null : local.toISOString(),
      time_raw: { date: datePart, time: timePart, timezone: null },
    };
  }

  // Fallback: try Date parse
  const d = new Date(ts);
  if (!isNaN(d.getTime())) {
    const isoStr = d.toISOString();
    datePart = isoStr.split("T")[0] || null;
    timePart = isoStr.split("T")[1]?.split("Z")[0] || null;
    return {
      time_iso: ts,
      time_utc: isoStr,
      time_raw: { date: datePart, time: timePart, timezone: null },
    };
  }

  // Couldn’t parse
  return {
    time_iso: null,
    time_utc: null,
    time_raw: { date: null, time: null, timezone: null },
  };
}

export function parseTCSResponse(tcsResponse: any): ParsedDHLResponse | null {
  try {
    if (!tcsResponse) return null;

    // TCS actual response structure
    const shipmentInfo = tcsResponse.shipmentinfo?.[0] || {};
    const deliveryInfo = tcsResponse.deliveryinfo || [];
    const checkpoints = tcsResponse.checkpoints || [];

    // Sort checkpoints by datetime (most recent first)
    const sortedCheckpoints = [...checkpoints].sort((a: any, b: any) => {
      const dateA = new Date(a.datetime || 0).getTime();
      const dateB = new Date(b.datetime || 0).getTime();
      return dateB - dateA;
    });

    const latestCheckpoint = sortedCheckpoints[0] || null;
    const latestDelivery = deliveryInfo[0] || null;

    const latestTimes = normalizeTCSTime(latestCheckpoint?.datetime);

    const trackInfo = {
      shipping_info: {
        shipper_address: {
          country: shipmentInfo.origincountry || null,
          state: null,
          city: shipmentInfo.origin || null,
          street: null,
          postal_code: null,
          coordinates: [] as any[],
        },
        recipient_address: {
          country: shipmentInfo.destinationcountry || null,
          state: null,
          city: shipmentInfo.destination || null,
          street: null,
          postal_code: null,
          coordinates: [] as any[],
        },
      },
      latest_status: {
        status: latestDelivery?.status || latestCheckpoint?.status || null,
        sub_status: latestDelivery?.code || null,
        sub_status_descr:
          latestDelivery?.status || latestCheckpoint?.status || null,
      },
      latest_event: {
        time_iso: latestTimes.time_iso,
        time_utc: latestTimes.time_utc,
        time_raw: latestTimes.time_raw,
        description: latestCheckpoint?.status || null,
        location:
          latestCheckpoint?.recievedby || latestDelivery?.station || null,
        stage: null,
        sub_status: latestDelivery?.code || null,
        address: {
          country: null,
          state: null,
          city: latestCheckpoint?.recievedby || latestDelivery?.station || null,
          street: null,
          postal_code: null,
          coordinates: [] as any[],
        },
      },
      time_metrics: {
        days_after_order: null,
        days_of_transit: null,
        days_of_transit_done: null,
        days_after_last_update: null,
        estimated_delivery_date: {
          source: null,
          from: null,
          to: null,
        },
      },
      milestone: sortedCheckpoints.map((checkpoint: any) => {
        const t = normalizeTCSTime(checkpoint.datetime);
        return {
          description: checkpoint.status || null,
          sub_status: checkpoint.code || null,
          time_iso: t.time_iso,
          time_utc: t.time_utc,
          time_raw: t.time_raw,
        };
      }),
      misc_info: {
        risk_factor: 0,
        service_type: null,
        weight_raw: null,
        weight_kg: null,
        pieces: 1,
        dimensions: null,
        customer_number: null,
        reference_number: shipmentInfo.referenceno || null,
        local_number: null,
        local_provider: null,
        local_key: 0,
      },
      tracking: {
        providers_hash: 0,
        providers: [] as any[],
      },
    };

    return {
      number: shipmentInfo.consignmentno || "",
      carrier: 100260,
      param: null,
      tag: "",
      track_info: trackInfo,
    };
  } catch (err) {
    console.error("Error parsing TCS response:", err);
    return null;
  }
}

function normalizeTCSTime(ts?: string | null) {
  if (!ts) {
    return {
      time_iso: null as string | null,
      time_utc: null as string | null,
      time_raw: {
        date: null as string | null,
        time: null as string | null,
        timezone: null as string | null,
      },
    };
  }

  try {
    const d = new Date(ts);
    if (!isNaN(d.getTime())) {
      const isoStr = d.toISOString();
      const datePart = isoStr.split("T")[0] || null;
      const timePart = isoStr.split("T")[1]?.split("Z")[0] || null;

      return {
        time_iso: isoStr, // Changed: Always return ISO format
        time_utc: isoStr,
        time_raw: { date: datePart, time: timePart, timezone: null },
      };
    }
  } catch (error) {
    console.error("Error parsing TCS time:", error);
  }

  return {
    time_iso: null,
    time_utc: null,
    time_raw: { date: null, time: null, timezone: null },
  };
}

// Helper function to normalize TCS status to simplified values
export function normalizeTCSStatus(status?: string | null): string {
  if (!status) return "Unknown";

  const statusLower = status.toLowerCase();

  // Delivered statuses
  if (
    statusLower.includes("delivered") ||
    statusLower.includes("shipment delivered")
  ) {
    return "Delivered";
  }

  // Returned statuses
  if (
    statusLower.includes("returned") ||
    statusLower.includes("return") ||
    statusLower.includes("refused")
  ) {
    return "Returned";
  }

  // Failed / Problem statuses
  if (
    statusLower.includes("address information needed") ||
    statusLower.includes("contact local tcs office") ||
    statusLower.includes("contact office") ||
    statusLower.includes("additional info") ||
    statusLower.includes("unable to deliver") ||
    statusLower.includes("delivery failed")
  ) {
    return "Failed";
  }

  // Out for delivery / Transit statuses
  if (
    statusLower.includes("out for delivery") ||
    statusLower.includes("departed") ||
    statusLower.includes("in transit")
  ) {
    return "Transit";
  }

  // Arrived / On Hold statuses
  if (
    statusLower.includes("arrived") ||
    statusLower.includes("on hold") ||
    statusLower.includes("facility")
  ) {
    return "In Transit";
  }

  // Picked up / Shipped statuses
  if (
    statusLower.includes("picked up") ||
    statusLower.includes("shipment picked")
  ) {
    return "Shipped";
  }

  // Cancelled statuses
  if (statusLower.includes("cancelled") || statusLower.includes("canceled")) {
    return "Cancelled";
  }

  // Default: return first 50 chars of original status
  return status.substring(0, 50);
}

// ====================
// BlueEX Integration
// ====================

export const getBlueExTracking = async (
  trackingNumber: string
): Promise<any> => {
  try {
    const blueExUrl = `https://apis.blue-ex.com/api/V4/GetTracking_V1`;
    const auth = Buffer.from("demo:demo123456").toString("base64");
    const response = await axios.post(
      blueExUrl,
      {
        ShipmentNumbers: [trackingNumber],
      },
      {
        headers: {
          Authorization: `Basic ${auth}`,
          "Content-Type": "application/json",
        },
      }
    );

    if (!response?.data || response.data.status !== 1) {
      return {
        status: 404,
        message: "BlueEX: tracking not found",
      };
    }

    return {
      status: 200,
      data: response.data,
    };
  } catch (error: any) {
    throw new Error(
      "BlueEX API Error: " + (error.response?.data?.detail || error.message)
    );
  }
};

export function parseBlueExResponse(response: any): ParsedDHLResponse | null {
  if (
    !response?.processed_shipments ||
    response.processed_shipments.length === 0
  )
    return null;

  const shipment = response.processed_shipments[0];
  const details = shipment.Details || {};

  // Build milestone array from cnDetail
  const milestone =
    shipment.cnDetail?.map((event: any) => {
      const timeObj = parseBlueExTimeDetailed(
        event.statusdate,
        event.statustime
      );
      return {
        description: event.statusmessage,
        sub_status: mapBlueExSubStatus(event.statusmessage),
        time_iso: timeObj.time_iso,
        time_utc: timeObj.time_utc,
        time_raw: timeObj.time_raw,
      };
    }) || [];

  const latestTimeObj = parseBlueExTimeDetailed(
    details.statusdate,
    details.statustime
  );

  return {
    number: shipment.shipmentnumber,
    carrier: 100261, // BlueEX carrier code
    param: response,
    tag: "BlueEX",
    track_info: {
      shipping_info: {
        shipper_address: {
          country: "Pakistan",
          state: null,
          city: shipment.org_city || null,
          street: null,
          postal_code: null,
          coordinates: [],
        },
        recipient_address: {
          country: "Pakistan",
          state: null,
          city: shipment.dest_city || null,
          street: shipment.cust_add || null,
          postal_code: null,
          coordinates: [],
        },
      },
      latest_status: {
        status: "OK",
        sub_status: mapBlueExSubStatus(details.desc),
        sub_status_descr: details.desc || "",
      },
      latest_event: {
        time_iso: latestTimeObj.time_iso,
        time_utc: latestTimeObj.time_utc,
        time_raw: latestTimeObj.time_raw,
        description: details.desc,
        location: shipment.dest_city || null,
        stage: null,
        sub_status: mapBlueExSubStatus(details.desc),
        address: {
          country: "Pakistan",
          state: null,
          city: shipment.dest_city || null,
          street: null,
          postal_code: null,
          coordinates: [],
        },
      },
      time_metrics: {
        days_after_order: null,
        days_of_transit: null,
        days_of_transit_done: null,
        days_after_last_update: null,
        estimated_delivery_date: { source: null, from: null, to: null },
      },
      milestone: milestone,
      misc_info: {
        risk_factor: 0,
        service_type: "standard",
        weight_raw: null,
        weight_kg: null,
        pieces: 1,
        dimensions: null,
        customer_number: shipment.cust_con || null,
        reference_number: shipment.cust_ref || null,
        local_number: null,
        local_provider: "BlueEX",
        local_key: 0,
      },
      tracking: { providers_hash: 0, providers: [] },
    },
  };
}

function normalizeBlueExTime(dateStr: string, timeStr: string): string {
  try {
    if (!dateStr || !timeStr) return new Date().toISOString();
    // Remove st, nd, rd, th from day (e.g. "Oct 15th, 2025")
    const cleanDate = dateStr.replace(/(\d+)(st|nd|rd|th)/, "$1");
    const fullStr = `${cleanDate} ${timeStr}`;
    const date = new Date(fullStr);
    if (isNaN(date.getTime())) return new Date().toISOString();
    return date.toISOString();
  } catch (e) {
    return new Date().toISOString();
  }
}

export function normalizeBlueExStatus(status: string): string {
  const statusLower = status.toLowerCase();
  if (statusLower.includes("delivered")) return "Delivered";
  if (statusLower.includes("returned")) return "Returned";
  if (statusLower.includes("out for delivery")) return "Out For Delivery";
  if (statusLower.includes("booked") || statusLower.includes("received"))
    return "Booked";
  if (statusLower.includes("route") || statusLower.includes("reached"))
    return "In Transit";

  // Default mapping
  return "In Transit";
}

function parseBlueExTimeDetailed(dateStr: string, timeStr: string) {
  try {
    if (!dateStr || !timeStr) {
      const now = new Date();
      return {
        time_iso: now.toISOString(),
        time_utc: now.toISOString(),
        time_raw: {
          date: now.toISOString().split("T")[0],
          time: now.toTimeString().split(" ")[0],
          timezone: null,
        },
      };
    }

    const cleanDate = dateStr.replace(/(\d+)(st|nd|rd|th)/, "$1");
    const fullStr = `${cleanDate} ${timeStr}`;
    const date = new Date(fullStr);

    if (isNaN(date.getTime())) {
      const now = new Date();
      return {
        time_iso: now.toISOString(),
        time_utc: now.toISOString(),
        time_raw: {
          date: now.toISOString().split("T")[0],
          time: now.toTimeString().split(" ")[0],
          timezone: null,
        },
      };
    }

    return {
      time_iso: date.toISOString(),
      time_utc: date.toISOString(),
      time_raw: {
        date: date.toISOString().split("T")[0],
        time: date.toTimeString().split(" ")[0],
        timezone: null,
      },
    };
  } catch (e) {
    const now = new Date();
    return {
      time_iso: now.toISOString(),
      time_utc: now.toISOString(),
      time_raw: {
        date: now.toISOString().split("T")[0],
        time: now.toTimeString().split(" ")[0],
        timezone: null,
      },
    };
  }
}

function mapBlueExSubStatus(description: string): string {
  const descLower = (description || "").toLowerCase();

  if (descLower.includes("delivered")) return "delivered";
  if (descLower.includes("out for delivery")) return "transit";
  if (descLower.includes("returned") || descLower.includes("return"))
    return "returned";
  if (descLower.includes("failed") || descLower.includes("hold"))
    return "failure";
  if (descLower.includes("cancelled") || descLower.includes("canceled"))
    return "cancelled";
  if (
    descLower.includes("booked") ||
    descLower.includes("received") ||
    descLower.includes("pending")
  )
    return "info_received";

  return "transit";
}

// ====================
// FlyCourier Integration (HTML Scraping)
// ====================

export const getFlyCourierTracking = async (
  trackingNumber: string
): Promise<any> => {
  try {
    const flyCourierUrl = `https://app.flycourier.com.pk/includes/track.php?cs=4&cn=${trackingNumber}`;
    const response = await axios.get(flyCourierUrl);

    if (!response?.data || response.data.includes("No record found")) {
      return {
        status: 404,
        message: "FlyCourier: tracking not found",
      };
    }

    return {
      status: 200,
      data: response.data,
    };
  } catch (error: any) {
    throw new Error(
      "FlyCourier API Error: " + (error.response?.data?.detail || error.message)
    );
  }
};

export function parseFlyCourierResponse(
  html: string
): ParsedDHLResponse | null {
  try {
    const $ = cheerio.load(html);

    const shipmentText = $("span.shipment b").text() || "";
    const shipmentMatch = shipmentText.match(/Shipment # (\d+)/);
    if (!shipmentMatch) return null;
    const shipmentNumber = shipmentMatch[1];

    const cityText = $('div[style*="text-align: right"] span b')
      .map((i, el) => $(el).text())
      .get();
    const originCity = cityText[0] || "";
    const destCity = cityText[1] || "";

    const events: any[] = [];
    $("table tbody tr").each((i, row) => {
      const cells = $(row).find("td");
      if (cells.length >= 3) {
        const date = $(cells[0]).text().trim();
        const time = $(cells[1]).text().trim();
        const status = $(cells[2]).text().trim();
        const remarks = $(cells[3]).text().trim();

        if (date && time && status) {
          const timeObj = parseFlyCourierTime(date, time);
          events.push({
            description: status + (remarks ? ` - ${remarks}` : ""),
            sub_status: mapFlyCourierSubStatus(status),
            time_iso: timeObj.time_iso,
            time_utc: timeObj.time_utc,
            time_raw: timeObj.time_raw,
          });
        }
      }
    });

    if (events.length === 0) return null;

    const getDetailValue = (label: string) => {
      let value = "";
      $("table tr").each((i, row) => {
        const cells = $(row).find("td");
        if (cells.length === 2 && $(cells[0]).text().includes(label)) {
          value = $(cells[1]).text().trim();
        }
      });
      return value;
    };

    const bookingDate = getDetailValue("Booking Date");
    const reference = getDetailValue("Shipment Reference");
    const pieces = getDetailValue("Booked / Received Peices");
    const weight = getDetailValue("Booked / Charged Weight");
    const consigneeInfo = getDetailValue("Consignee Information");
    const pickupInfo = getDetailValue("Pickup Information");

    const latestEvent = events[events.length - 1] || events[0];

    return {
      number: shipmentNumber,
      carrier: 100262,
      param: html,
      tag: "FlyCourier",
      track_info: {
        shipping_info: {
          shipper_address: {
            country: "Pakistan",
            state: null,
            city: originCity || null,
            street: pickupInfo || null,
            postal_code: null,
            coordinates: [],
          },
          recipient_address: {
            country: "Pakistan",
            state: null,
            city: destCity || null,
            street: consigneeInfo || null,
            postal_code: null,
            coordinates: [],
          },
        },
        latest_status: {
          status: latestEvent.sub_status,
          sub_status: latestEvent.sub_status,
          sub_status_descr: latestEvent.description,
        },
        latest_event: {
          time_iso: latestEvent.time_iso,
          time_utc: latestEvent.time_utc,
          time_raw: latestEvent.time_raw,
          description: latestEvent.description,
          location: destCity || null,
          stage: null,
          sub_status: latestEvent.sub_status,
          address: {
            country: "Pakistan",
            state: null,
            city: destCity || null,
            street: null,
            postal_code: null,
            coordinates: [],
          },
        },
        time_metrics: {
          days_after_order: null,
          days_of_transit: null,
          days_of_transit_done: null,
          days_after_last_update: null,
          estimated_delivery_date: { source: null, from: null, to: null },
        },
        milestone: events,
        misc_info: {
          risk_factor: 0,
          service_type: "standard",
          weight_raw: weight || null,
          weight_kg: weight ? parseFloat(weight.split("/")[0].trim()) : null,
          pieces: pieces ? parseInt(pieces.split("/")[0].trim()) : 1,
          dimensions: null,
          customer_number: null,
          reference_number: reference || null,
          local_number: null,
          local_provider: "FlyCourier",
          local_key: 0,
        },
        tracking: { providers_hash: 0, providers: [] },
      },
    };
  } catch (error) {
    console.error("Error parsing FlyCourier HTML:", error);
    return null;
  }
}

function parseFlyCourierTime(dateStr: string, timeStr: string) {
  try {
    const [day, month, year] = dateStr.split("-");
    const fullStr = `${month}/${day}/${year} ${timeStr}`;
    const date = new Date(fullStr);

    if (isNaN(date.getTime())) {
      const now = new Date();
      return {
        time_iso: now.toISOString(),
        time_utc: now.toISOString(),
        time_raw: {
          date: now.toISOString().split("T")[0],
          time: now.toTimeString().split(" ")[0],
          timezone: null,
        },
      };
    }

    return {
      time_iso: date.toISOString(),
      time_utc: date.toISOString(),
      time_raw: {
        date: date.toISOString().split("T")[0],
        time: date.toTimeString().split(" ")[0],
        timezone: null,
      },
    };
  } catch (e) {
    const now = new Date();
    return {
      time_iso: now.toISOString(),
      time_utc: now.toISOString(),
      time_raw: {
        date: now.toISOString().split("T")[0],
        time: now.toTimeString().split(" ")[0],
        timezone: null,
      },
    };
  }
}

function mapFlyCourierSubStatus(status: string): string {
  const statusLower = status.toLowerCase();

  if (statusLower.includes("delivered")) return "delivered";
  if (
    statusLower.includes("shipment received") ||
    statusLower.includes("loadsheet created")
  )
    return "info_received";
  if (statusLower.includes("out for delivery")) return "transit";
  if (statusLower.includes("returned") || statusLower.includes("return"))
    return "returned";
  if (statusLower.includes("failed") || statusLower.includes("hold"))
    return "failure";
  if (statusLower.includes("cancelled") || statusLower.includes("canceled"))
    return "cancelled";

  return "transit";
}

export function normalizeFlyCourierStatus(status: string): string {
  const statusLower = status.toLowerCase();
  if (statusLower.includes("delivered")) return "Delivered";
  if (statusLower.includes("returned")) return "Returned";
  if (statusLower.includes("out for delivery")) return "Out For Delivery";
  if (statusLower.includes("shipment received")) return "In Transit";
  if (statusLower.includes("loadsheet created")) return "In Transit";

  return "In Transit";
}
