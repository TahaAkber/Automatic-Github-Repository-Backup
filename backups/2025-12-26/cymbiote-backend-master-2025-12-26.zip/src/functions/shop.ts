import { poolPromise } from "../config/db";
import { Request } from "mssql"; // Ensure mssql is correctly installed and imported
import { getLatestReelByOffset } from "../models/reelsAndStories/reelsAndStories";
import {
  NotificationCode,
  Preference,
  sanitizeRules,
} from "../types/notifyPerference/notificationPreference";
import sql from "mssql";
import { sendErrorEmail } from "../services/emailService";

export const getShopFollowingStatus = async (
  shop_id?: number,
  user_id?: number
): Promise<boolean> => {
  if (!shop_id || !user_id) {
    return false; // Return false if either value is missing
  }

  const pool = await poolPromise;

  const query = `
      SELECT following_id FROM User_Following 
      WHERE following_shop_id = @shop_id 
      AND following_user_id = @user_id
    `;

  const request = pool.request();
  request.input("shop_id", shop_id);
  request.input("user_id", user_id);

  const result = await request.query(query);

  return result.recordset.length > 0; // Returns true if a record exists
};

export const getShopReviewsStats = async (shopId: number) => {
  if (!shopId || typeof shopId !== "number") {
    throw new Error("Invalid shop ID for stats");
  }

  const pool = await poolPromise;
  const request = pool.request();
  request.input("shopId", shopId);

  const result = await request.query(`
SELECT
  COUNT(*) AS total_reviews,
  COALESCE(AVG(R.order_item_review_rating), 0) AS average_rating,  -- Ensure average is 0 if no reviews
  COALESCE(SUM(CASE WHEN R.order_item_review_rating >= 4.5 THEN 1 ELSE 0 END), 0) AS excellent,
  COALESCE(SUM(CASE WHEN R.order_item_review_rating >= 3.5 AND R.order_item_review_rating < 4.5 THEN 1 ELSE 0 END), 0) AS good,
  COALESCE(SUM(CASE WHEN R.order_item_review_rating >= 2.5 AND R.order_item_review_rating < 3.5 THEN 1 ELSE 0 END), 0) AS average,
  COALESCE(SUM(CASE WHEN R.order_item_review_rating >= 1.5 AND R.order_item_review_rating < 2.5 THEN 1 ELSE 0 END), 0) AS poor,
  COALESCE(SUM(CASE WHEN R.order_item_review_rating < 1.5 THEN 1 ELSE 0 END), 0) AS verypoor
FROM Order_Item_Review R
JOIN Order_Items OI ON R.order_item_id = OI.order_item_id
JOIN Product_Variants PV ON OI.order_item_variant_id = PV.variant_id
JOIN Products P ON PV.variant_product_id = P.product_id
JOIN Shops S ON P.product_shop_id = S.shop_id
WHERE S.shop_id = @shopId;
  `);

  return (
    result.recordset[0] || {
      total_reviews: 0,
      average_rating: 0,
      excellent: 0,
      good: 0,
      average: 0,
      poor: 0,
      verypoor: 0,
    }
  );
};

export const mergeShopsWithReels = async (
  shops: any[],
  page: number,
  pageSize: number
): Promise<any[]> => {
  const globalStartIndex = (page - 1) * pageSize + 1;
  const mergedList: any[] = [];

  let reelOffset = Math.floor((globalStartIndex - 1) / 6);

  for (let i = 0; i < shops.length; i++) {
    const globalIndex = globalStartIndex + i;
    mergedList.push(shops[i]);

    if (globalIndex % 6 === 0) {
      const reel = await getLatestReelByOffset(reelOffset);
      const modifiedData = reel.map((item, index) => {
        return {
          ...item,
          shop_tile_type: 10,
          type: "REEL",
        };
      });
      if (reel) {
        mergedList.push({
          reels: modifiedData,
          shop_tile_type: 10,
          type: "REEL",
        });
      }
      reelOffset++;
    }
  }

  return mergedList;
};
export const shopRatingUpdate = async (shop_id: number) => {
  const pool = await poolPromise;
  const request = pool.request();

  const shopRating = await getShopReviewsStats(shop_id);

  console.log("shopRating", shopRating);

  request.input("shop_id", shop_id);
  request.input(
    "newRating",
    shopRating?.average_rating ? shopRating?.average_rating.toFixed(1) : 0
  ); // Input for the new rating

  try {
    // Step 1: Update the shop rating for the given shop_id
    await request.query(
      `UPDATE Shops SET shop_rating = @newRating WHERE shop_id = @shop_id`
    );

    console.log("Shop rating updated successfully!");
    return true;
  } catch (error: any) {
    sendErrorEmail("Error updating shop rating:", error);

    console.error("Error updating shop rating:", error);
    return false;
  }
};

const NUM_TO_PREF: Record<number, Preference> = {
  0: "all",
  1: "personalized",
  2: "none",
};

export type MerchantNotificationPref =
  | { preference: "personalized"; rules: NotificationCode[] }
  | { preference: "all" | "none" };

export const getMerchantNotificationPreference = async (
  shop_id?: number,
  user_id?: number
): Promise<MerchantNotificationPref | null> => {
  if (!shop_id || !user_id) return null;

  const pool = await poolPromise;
  const sql = `
    SELECT TOP (1)
      notification_preference_type,
      notification_preference_rules
    FROM [cymbiote].[dbo].[Shop_Notification_Preferences]
    WHERE notification_shop_id = @shop_id
      AND notification_user_id  = @user_id
  `;

  const result = await pool
    .request()
    .input("shop_id", shop_id)
    .input("user_id", user_id)
    .query(sql);

  if (result.recordset.length === 0) return null;

  const row = result.recordset[0];
  const prefNum = Number(row.notification_preference_type);
  const preference: Preference = NUM_TO_PREF[prefNum] ?? "all";

  if (preference !== "personalized") {
    return { preference };
  }

  let parsed: any[] = [];
  const raw = row.notification_preference_rules;
  if (Array.isArray(raw)) parsed = raw;
  else if (typeof raw === "string") {
    try {
      parsed = JSON.parse(raw);
    } catch {
      parsed = [];
    }
  }

  const rules = sanitizeRules(parsed);
  return { preference: "personalized", rules };
};

function toVariantGid(id: string | number) {
  const s = String(id);
  if (s.startsWith("gid://")) return s;
  const num = s.match(/(\d+)$/)?.[1] ?? s;
  return `gid://shopify/ProductVariant/${num}`;
}

export async function getVariantsByShopifyVariantIds(
  shopifyVariantIds: Array<string | number>
) {
  if (!shopifyVariantIds?.length) return [];

  const gidIds = [...new Set(shopifyVariantIds.map(toVariantGid))];

  const pool = await poolPromise;
  const request = pool.request();

  const placeholders: string[] = [];
  gidIds.forEach((id, i) => {
    const pname = `id${i}`;
    request.input(pname, sql.NVarChar(200), id);
    placeholders.push(`@${pname}`);
  });

  const query = `
    SELECT
      pv.[variant_shopify_id]  AS shopify_variant_id,
      pv.[variant_price]       AS variant_price,
      pv.[variant_name]        AS variant_title
    FROM [cymbiote].[dbo].[Product_Variants] pv
    WHERE pv.[variant_shopify_id] IN (${placeholders.join(",")})
  `;

  const result = await request.query(query);
  return result.recordset.map((r: any) => ({
    shopify_variant_id: String(r.shopify_variant_id),
    variant_price: Number(r.variant_price),
    variant_title: r.variant_title ?? null,
  }));
}
