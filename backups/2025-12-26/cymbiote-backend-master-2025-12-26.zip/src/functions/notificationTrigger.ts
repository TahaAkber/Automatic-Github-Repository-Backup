import { getFcmTokens } from "../models/notifications/notificationModel";
import {
  getShopDetailsByShopId,
  getShopFollowers,
  getWishlistUserIds,
} from "../models/shops/shopModel";
import { sendErrorEmail } from "../services/emailService";
import {
  createAppNotificationsService,
  sendFCMNotification,
} from "../services/notificationService";
import {
  BaseMessage,
  EVENT_RULES,
  NotificationKey,
  PRICE_DROP_NOTIF_KEY,
  VariantPriceDrop,
} from "../types/notification/Notification";
import {
  checkNotification,
  checkShopPreferenceForEvent,
} from "./notificationSettings";
import { getVariantsByShopifyVariantIds } from "./shop";

export const notifyIfEnabled = async (
  userId: number,
  key: NotificationKey,
  baseMessage: BaseMessage
): Promise<{ sent: boolean; reason?: string; result?: any }> => {
  const canNotify = await checkNotification(userId, key);
  if (!canNotify) {
    console.log(`User ${userId} disabled ${key} notifications.`);
    console.log(
      "Order details processed and saved successfully (no notification sent)."
    );
    return { sent: false, reason: "disabled" };
  }
  const uidNum = typeof userId === "string" ? Number(userId) : userId; // for funcs that want number
  const uidStr = String(userId);
  const fcmTokens = await getFcmTokens(uidStr);
  if (!fcmTokens?.length) {
    console.log("Order details processed and saved successfully.");
    return { sent: false, reason: "no_tokens" };
  }

  const MessageData = {
    title: baseMessage.title,
    body: baseMessage.body,
    DeviceToken: JSON.stringify(fcmTokens),
    screenName: baseMessage.screenName ?? "Orders",
    type: baseMessage.type ?? "token",
    payload: JSON.stringify(baseMessage.payload ?? {}),
  };

  // await createAppNotificationsService(uidStr, MessageData);
  const notificationResult = await sendFCMNotification(fcmTokens, MessageData);
  console.log("notification Result", notificationResult);
  console.log("Order details processed and saved successfully.");
  return { sent: true, result: notificationResult };
};

export const queueRestockNotifications = async (beforeRow: any) => {
  try {
    const shop = await getShopDetailsByShopId(beforeRow.product_shop_id);

    const wishlistUserIds: number[] = await getWishlistUserIds(
      beforeRow.product_id
    );
    const followerUserIds: number[] = await getShopFollowers(
      beforeRow.product_shop_id
    );

    const NOTIF_KEY = "notification_setting_stock_available";
    const RESTOCK_RULES = ["RESTOCK_ALERT", "BACK_IN_STOCK_REMINDER"]; // for personalized pref
    const title = "Back in Stock!";
    const body = `${beforeRow.product_name}${
      beforeRow.variant_title ? ` (${beforeRow.variant_title})` : ""
    } is available again. Tap to grab yours.`;
    const screenName = "ProductDetail";
    const notificationImageUrl =
      beforeRow.image_url || shop?.shop_logo_url || "";

    const payload = {
      productId: beforeRow.product_id,
      variantId: beforeRow.variant_id,
      shopId: beforeRow.product_shop_id,
      shopName: shop?.shop_name || "",
      notificationEvent: "RESTOCK",
      productImage: beforeRow.product_image_url || "",
      status: "Back In Stock",
    };

    const wishlistSet = new Set<number>(wishlistUserIds ?? []);
    for (const userId of wishlistSet) {
      try {
        const canNotify = await checkNotification(userId, NOTIF_KEY);
        if (!canNotify) continue;

        const fcmTokens = await getFcmTokens(String(userId));
        if (!fcmTokens?.length) continue;

        const MessageData = {
          title,
          body,
          DeviceToken: JSON.stringify(fcmTokens),
          screenName,
          productId: String(beforeRow.product_id),
          variantId: String(beforeRow.variant_id),
          notificationImageUrl,
          type: "token",
          payload: JSON.stringify(payload),
        };

        await createAppNotificationsService(userId, MessageData);
        await sendFCMNotification(fcmTokens, MessageData);
      } catch (innerErr: any) {
        console.error(
          `Inventory notify (wishlist) error for user ${userId}:`,
          innerErr
        );
      }
    }

    // 2) Notify followers who are NOT already wishlisted (apply shop preference here)
    const followersToNotify = (followerUserIds ?? []).filter(
      (id) => !wishlistSet.has(id)
    );
    if (!followersToNotify.length) return;

    for (const userId of followersToNotify) {
      try {
        const pref = await checkShopPreferenceForEvent(
          beforeRow.product_shop_id,
          userId,
          [...RESTOCK_RULES] // spread in case it's readonly
        );
        if (!pref.allowed) continue;

        const canNotify = await checkNotification(userId, NOTIF_KEY);
        if (!canNotify) continue;

        const fcmTokens = await getFcmTokens(String(userId));
        if (!fcmTokens?.length) continue;
        console.log(beforeRow.product_id, "<<<<<<beforeRow.product_id");
        const MessageData = {
          title,
          body,
          DeviceToken: JSON.stringify(fcmTokens),
          screenName,
          productId: String(beforeRow.product_id),
          variantId: String(beforeRow.variant_id),
          notificationImageUrl,
          type: "token",
          payload: JSON.stringify(payload),
        };

        await createAppNotificationsService(userId, MessageData);
        await sendFCMNotification(fcmTokens, MessageData);
      } catch (innerErr) {
        console.error(
          `Inventory notify (followers) error for user ${userId}:`,
          innerErr
        );
      }
    }
  } catch (err: any) {
    sendErrorEmail("queueRestockNotifications error:", err);

    console.error("queueRestockNotifications error:", err);
  }
};

function formatPKR(val: number) {
  return new Intl.NumberFormat("en-PK", {
    style: "currency",
    currency: "PKR",
    maximumFractionDigits: 0,
  }).format(val);
}
function extractNumericId(id: string | number): string {
  const m = String(id).match(/(\d+)$/);
  return m ? m[1] : String(id);
}

function toVariantGid(id: string | number): string {
  const num = extractNumericId(id);
  return `gid://shopify/ProductVariant/${num}`;
}

export async function detectVariantPriceDrops(
  shopifyProductId: string | number,
  payloadVariants: any[]
): Promise<VariantPriceDrop[]> {
  const variants = Array.isArray(payloadVariants) ? payloadVariants : [];
  const variantIds = variants.map((v: any) => v?.id).filter(Boolean);

  const dbRows = await getVariantsByShopifyVariantIds(variantIds);
  const dbById = new Map<string, any>();
  for (const row of dbRows) {
    const gid = String(row.shopify_variant_id);
    const num = extractNumericId(gid);
    dbById.set(gid, row);
    dbById.set(num, row);
  }

  const drops: VariantPriceDrop[] = [];
  for (const v of variants) {
    const keyGid = toVariantGid(v.id);
    const keyNum = extractNumericId(v.id);
    const dbv = dbById.get(keyGid) || dbById.get(keyNum);
    if (!dbv) continue;

    const oldPrice = Number(dbv.variant_price);
    const newPrice = Number(v.price);
    if (!isFinite(oldPrice) || !isFinite(newPrice)) continue;

    if (newPrice < oldPrice) {
      drops.push({
        variantId: v.id,
        oldPrice,
        newPrice,
        variantTitle: v.title ?? dbv.variant_title ?? undefined,
      });
    }
  }

  return drops;
}

export async function enqueueNotification(args: {
  userId: number;
  shopId: number;
  productId: number;
  variantId?: string;
  notifKey: string;
  title: string;
  body: string;
  imageUrl?: string;
  screenName: string;
  screenParams?: any;
  payloadExtra?: Record<string, any>;
}) {
  const {
    userId,
    shopId,
    productId,
    variantId,
    notifKey,
    title,
    body,
    imageUrl,
    screenName,
    screenParams,
    payloadExtra,
  } = args;

  const fcmTokens = await getFcmTokens(String(userId));
  if (!fcmTokens?.length) {
    return { sent: false, reason: "no_tokens" };
  }

  const payload = {
    productId,
    variantId,
    shopId,
    notificationEvent: notifKey,
    productImage: imageUrl ?? "",
    ...screenParams,
    ...(payloadExtra || {}),
  };

  const MessageData = {
    title,
    body,
    DeviceToken: JSON.stringify(fcmTokens),
    screenName,
    productId: String(productId),
    variantId: variantId ? String(variantId) : undefined,
    notificationImageUrl: imageUrl,
    type: "token",
    payload: JSON.stringify(payload),
  };

  await createAppNotificationsService(userId, MessageData);
  const result = await sendFCMNotification(fcmTokens, MessageData);
  return { sent: true, result };
}

export async function queuePriceDropNotifications(args: {
  currentProduct: any;
  drops: VariantPriceDrop[];
}) {
  const { currentProduct, drops } = args;
  if (!drops.length) return;

  const shop = await getShopDetailsByShopId(currentProduct.product_shop_id);

  const wishlistUserIds: number[] = await getWishlistUserIds(
    currentProduct.product_id
  );
  const followerUserIds: number[] = await getShopFollowers(
    currentProduct.product_shop_id
  );

  const userIds = Array.from(new Set([...wishlistUserIds, ...followerUserIds]));
  if (!userIds.length) return;

  const productName = currentProduct.product_name;
  const notificationImageUrl =
    currentProduct.image_url ||
    currentProduct.product_image_url ||
    currentProduct.product_images?.[0]?.product_image_url ||
    shop?.shop_logo_url ||
    "";

  for (const drop of drops) {
    const title = "Price dropped!";
    const wasNow = `was ${formatPKR(drop.oldPrice)}, now ${formatPKR(
      drop.newPrice
    )}`;
    const variantTag = drop.variantTitle ? ` (${drop.variantTitle})` : "";

    const body = `${productName}${variantTag} ${wasNow}. Tap to view.`;

    for (const userId of userIds) {
      await enqueueNotification({
        userId,
        shopId: currentProduct.product_shop_id,
        productId: currentProduct.product_id,
        variantId: String(drop.variantId),
        notifKey: PRICE_DROP_NOTIF_KEY,
        title,
        body,
        imageUrl: notificationImageUrl,
        screenName: "ProductDetail",
        screenParams: {
          product_id: currentProduct.product_id,
          variant_id: String(drop.variantId),
        },
      });
    }
  }
}
