import { NextFunction, Request, Response } from "express";
import { sendErrorEmail } from "../services/emailService";

export const wait = (ms: number) => new Promise((res) => setTimeout(res, ms));

export const capsFirstLetter = (str: string) =>
  str.charAt(0).toUpperCase() + str.slice(1);

export const applyOrderStatus = async (statusId: any): Promise<any> => {
  switch (statusId) {
    case "1":
      return "IN_PROGRESS";
    case "2":
      return "OUT_FOR_DELIVERY";
    case "3":
      return "IN_TRANSIT";
    case "4":
      return "DELIVERED";
    case "5":
      return "ACTIVE_ORDERS";
    default:
      return 0;
  }
};

export const applyPointStatus = (statusId: any) => {
  switch (statusId) {
    case "1":
      return "pending";
    case "2":
      return "redeemed";
    case "3":
      return "completed";
    case "4":
      return "cancelled";
    default:
      return "0";
  }
};

export const toFixedMethod = (number: any) => {
  const num =
    number === null ||
    number === undefined ||
    number === "" ||
    number === "null" ||
    number === "undefined" ||
    isNaN(number)
      ? "0.00"
      : parseFloat(number).toFixed(2);
  return num.toString();
};

export const setDatabaseEnv = (
  req: Request,
  _: Response,
  next: NextFunction
) => {
  // Check the incoming request URL or any other criteria to determine staging or production
  if (req.path.startsWith("/staging")) {
    // DatabaseManager.setDatabaseName("staging");
  } else if (req.path.startsWith("/api")) {
    // DatabaseManager.setDatabaseName("production");
  } else {
    // DatabaseManager.setDatabaseName("production");
  }

  // Call the next middleware or route handler
  next();
};

export const retryOperation = async <T>(
  operation: () => Promise<T>,
  retries: number = 5,
  delay: number = 2000 // Delay in ms before retrying
): Promise<T | undefined> => {
  let attempt = 0;

  while (attempt < retries) {
    try {
      return await operation(); // Try the operation
    } catch (error: any) {
      attempt++;
      console.log(
        `Attempt ${attempt} Issue:${error.message} failed. Retrying...`
      );
      sendErrorEmail(
        `Operation failed after ${retries} attempts: ${error.message}`,
        error
      );

      if (attempt >= retries) {
        throw new Error(
          `Operation failed after ${retries} attempts: ${error.message}`
        );
      }

      // Wait for a delay before retrying
      await new Promise((resolve) => setTimeout(resolve, delay));
    }
  }
};

export const toSuffix = (d: Date) =>
  d.toISOString().slice(0, 10).replace(/-/g, ""); // YYYYMMDD
export const toDate = (v?: string) => (v ? new Date(v) : undefined);
