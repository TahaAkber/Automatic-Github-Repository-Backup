type AspectMatch = {
  decimal: number; // e.g., 1.777...
  simplified: string; // e.g., "16:9"
  orientation: "landscape" | "portrait" | "square";
  matchedCommon?: string; // e.g., "16:9" if within tolerance
  diffPct?: number; // % difference from matched common ratio
};

function gcd(a: number, b: number): number {
  a = Math.abs(a);
  b = Math.abs(b);
  while (b) [a, b] = [b, a % b];
  return a || 1;
}

export function getAspectRatio(
  width: number,
  height: number,
  tolerancePct = 2 // how close (in %) to consider a match
): AspectMatch {
  if (!width || !height) throw new Error("Invalid dimensions");

  const decimal = width / height;
  const d = gcd(width, height);
  const num = Math.round(width / d);
  const den = Math.round(height / d);
  const simplified = `${num}:${den}`;

  const orientation =
    width === height ? "square" : width > height ? "landscape" : "portrait";

  // Common aspect ratios you care about (add/remove as needed)
  const COMMON: Record<string, number> = {
    "1:1": 1 / 1,
    "4:3": 4 / 3,
    "3:2": 3 / 2,
    "5:4": 5 / 4,
    "16:10": 16 / 10,
    "16:9": 16 / 9,
    "21:9": 21 / 9,
    // Portrait counterparts (optional if you want explicit labels)
    "9:16": 9 / 16,
    "3:4": 3 / 4,
    "2:3": 2 / 3,
    "4:5": 4 / 5,
  };

  let matchedCommon: string | undefined;
  let bestDiffPct = Infinity;

  for (const [label, ratio] of Object.entries(COMMON)) {
    const diffPct = (Math.abs(decimal - ratio) / ratio) * 100;
    if (diffPct < bestDiffPct) {
      bestDiffPct = diffPct;
      if (diffPct <= tolerancePct) matchedCommon = label;
    }
  }

  return {
    decimal,
    simplified,
    orientation,
    matchedCommon,
    diffPct: matchedCommon ? Number(bestDiffPct.toFixed(3)) : undefined,
  };
}
