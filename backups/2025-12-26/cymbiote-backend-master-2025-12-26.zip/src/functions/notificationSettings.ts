import { poolPromise } from "../config/db";
import { NotificationKey } from "../types/notification/Notification";

const getSettings = async (userId: number) => {
  const pool = await poolPromise;
  const { recordset } = await pool
    .request()
    .input("userId", userId)
    .query(
      `SELECT TOP 1 * FROM Notification_Settings WHERE notification_setting_user_id=@userId`
    );
  return recordset[0] || null;
};

const toBool = (val: any, fallback = false) =>
  val === true ||
  val === 1 ||
  val === "1" ||
  val?.toString().toLowerCase() === "true" ||
  fallback;

export const checkNotification = async (
  userId: number,
  keys: NotificationKey | NotificationKey[],
  logic: "AND" | "OR" = "AND"
): Promise<boolean> => {
  console.log(keys, "<keys>");
  const settings = await getSettings(userId);
  if (!settings) return false;

  const arr = (Array.isArray(keys) ? keys : [keys]).map((k) =>
    toBool(settings[k])
  );
  return logic === "AND" ? arr.every(Boolean) : arr.some(Boolean);
};

type PrefType = "all" | "personalized" | "none" | "none_set" | "unknown";

export type ShopPrefDecision = {
  allowed: boolean;
  prefType: PrefType;
  reason:
    | "pref_all"
    | "pref_none"
    | "pref_personalized_match"
    | "pref_personalized_no_match"
    | "no_pref_row"
    | "unknown";
  matchedRule?: boolean;
  rules?: string[];
};

type PrefRow = {
  notification_preference_type?: number | string | null; // 0=all,1=personalized,2=none (preferred)
  notification_preference_id?: number | null; // fallback if you store code here
  notification_preference_rules?: string | null; // JSON array of rule keys
};

const getShopPrefRow = async (
  shopId: number,
  userId: number
): Promise<PrefRow | null> => {
  const pool = await poolPromise;
  const { recordset } = await pool
    .request()
    .input("shopId", shopId)
    .input("userId", userId).query<PrefRow>(`
      SELECT TOP 1
        notification_preference_type,
        notification_preference_id,
        notification_preference_rules
      FROM [cymbiote].[dbo].[Shop_Notification_Preferences]
      WHERE notification_shop_id = @shopId
        AND notification_user_id = @userId
    `);

  console.log(recordset, "<recordset>");
  return recordset?.[0] ?? null;
};

const getTypeCode = (row: PrefRow): 0 | 1 | 2 | -1 => {
  // Prefer notification_preference_type if numeric; else fallback to id
  const t = row.notification_preference_type;
  const asNum =
    typeof t === "number"
      ? t
      : typeof t === "string" && t.trim() !== ""
      ? Number(t)
      : row.notification_preference_id ?? -1;
  if (asNum === 0 || asNum === 1 || asNum === 2) return asNum;
  return -1;
};

const parseRules = (rulesStr?: string | null): string[] => {
  if (!rulesStr) return [];
  try {
    const v = JSON.parse(rulesStr);
    if (Array.isArray(v)) return v.map((x) => String(x).toUpperCase());
    return [];
  } catch {
    return [];
  }
};

export const checkShopPreferenceForEvent = async (
  shopId: number,
  userId: number,
  eventRuleKeys: string | string[]
): Promise<ShopPrefDecision> => {
  const keys = (
    Array.isArray(eventRuleKeys) ? eventRuleKeys : [eventRuleKeys]
  ).map((k) => String(k).toUpperCase());

  const row = await getShopPrefRow(shopId, userId);
  if (!row) {
    return { allowed: true, prefType: "none_set", reason: "no_pref_row" };
  }

  const code = getTypeCode(row);
  if (code === 0) {
    return { allowed: true, prefType: "all", reason: "pref_all" };
  }
  if (code === 2) {
    return { allowed: false, prefType: "none", reason: "pref_none" };
  }
  if (code === 1) {
    const savedRules = parseRules(row.notification_preference_rules);
    const matched = keys.some((k) => savedRules.includes(k));
    return {
      allowed: matched,
      prefType: "personalized",
      reason: matched
        ? "pref_personalized_match"
        : "pref_personalized_no_match",
      matchedRule: matched,
      rules: savedRules,
    };
  }

  return { allowed: false, prefType: "unknown", reason: "unknown" };
};
  