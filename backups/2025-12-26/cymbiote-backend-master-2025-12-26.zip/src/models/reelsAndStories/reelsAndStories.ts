import { poolPromise } from "../../config/db";
import { sendErrorEmail } from "../../services/emailService";
import { getUsingShopId } from "../products/productModel";
import { getShopReviews } from "../reviews/reviewsModel";

export const getReelsByShopId = async (shopId: number, userId?: number) => {
  const pool = await poolPromise;

  try {
    const query = `
      SELECT 
        rs.id,
        rs.video_url_id,
        rs.video_title,
        rs.video_likes_count,
        rs.video_view_count,
        rs.video_type,
        v.video_url,
        v.video_thumbnail_url,  
        rp.reel_video_id AS product_reel_video_id,
        rp.reel_product_id AS product_id,
        p.product_name,
        p.product_image_url,
        p.product_is_active,
        pv.variant_price,
        s.shop_id,
        s.shop_name,
        s.shop_logo_url,

        -- 🧮 Saved count
        (
          SELECT COUNT(*) 
          FROM Saved_ReelsNStories srs 
          WHERE srs.saved_video_id = rs.id
        ) AS savedCount,

        -- ✅ Is video saved by this user
        ${
          userId
            ? `
          CASE 
            WHEN EXISTS (
              SELECT 1 FROM Saved_ReelsNStories srs 
              WHERE srs.saved_video_id = rs.id 
              AND srs.saved_user_id = @userId
            ) THEN 1
            ELSE 0
          END
        `
            : `CAST(NULL AS BIT)`
        } AS isSaved,

        ${
          userId
            ? `
          CASE 
            WHEN EXISTS (
              SELECT 1 FROM Liked_ReelsNStories lrs 
              WHERE lrs.liked_video_id = rs.id 
              AND lrs.liked_user_id = @userId
            ) THEN 1
            ELSE 0
          END
        `
            : `CAST(NULL AS BIT)`
        } AS isLiked

      FROM ReelsNStories rs
      JOIN Videos v ON rs.video_url_id = v.video_id
      LEFT JOIN Reels_Products rp ON rs.video_url_id = rp.reel_video_id
      LEFT JOIN Products p ON rp.reel_product_id = p.product_id
      OUTER APPLY (
        SELECT TOP 1 variant_price
        FROM Product_Variants
        WHERE variant_product_id = p.product_id
        ORDER BY variant_price ASC
      ) pv
      LEFT JOIN Shops s ON v.video_shop_id = s.shop_id
      WHERE v.video_shop_id = @shopId 
        AND rs.video_type = 'REEL' 
        AND p.product_is_active = 'true'
      ORDER BY v.created_at DESC;
    `;

    const request = pool.request().input("shopId", shopId);
    if (userId) {
      request.input("userId", userId);
    }

    const result = await request.query(query);
    const records = result.recordset;

    if (records.length === 0) {
      const { rating = 0, total_reviews = 0 } =
        (await getShopReviews(shopId)) || {};
      return {
        shop: { shop_id: shopId, rating, total_reviews },
        reels: [],
      };
    }

    // grab shop info from first row
    const { shop_id, shop_name, shop_logo_url } = records[0];
    const { rating = 0, total_reviews = 0 } =
      (await getShopReviews(shop_id)) || {};

    const shop = {
      shop_id,
      shop_name,
      shop_logo_url,
      rating,
      total_reviews,
    };

    // everything else is reels
    const reels = records.map((row) => ({
      id: row.id,
      video_url_id: row.video_url_id,
      video_title: row.video_title,
      video_likes_count: row.video_likes_count,
      video_view_count: row.video_view_count,
      video_type: row.video_type,
      video_url: row.video_url,
      video_thumbnail_url: row.video_thumbnail_url,
      product: row.product_id
        ? {
            product_id: row.product_id,
            product_name: row.product_name,
            product_image_url: row.product_image_url,
            product_is_active: row.product_is_active,
            variant_price: row.variant_price,
          }
        : null,
      savedCount: row.savedCount,
      isSaved: row.isSaved,
      isLiked: row.isLiked,
    }));

    return { shop, reels };
  } catch (error: any) {
    sendErrorEmail("Error fetching reels by shop ID:", error);

    console.error("Error fetching reels by shop ID:", error);
    throw new Error("Failed to fetch reels for the shop");
  }
};

export const getReelsByVideoId = async (
  videoId: number,
  userId?: number,
  page = 1,
  pageSize = 2,
  shopId?: number
) => {
  const pool = await poolPromise;
  const offset = (page - 1) * pageSize;

  try {
    const query = `
      WITH ReelsBase AS (
  SELECT
    rs.id,
    rs.video_url_id,
    rs.video_title,
    rs.video_likes_count,
    rs.video_view_count,
    rs.video_type,
    v.video_url,
    v.video_thumbnail_url,
    v.video_url_480p,
    v.video_url_720p,
    v.video_url_1080p,
    rp.reel_video_id AS product_reel_video_id,
    rp.reel_product_id AS product_id,
    p.product_name,
    p.product_image_url,
    p.product_is_active,
    pv.variant_price,
    pv.variant_discounted_price,
    s.shop_id,
    s.shop_name,
    s.shop_logo_url,
    s.shop_rating,
    v.created_at,

    -- existing saved count
    (
      SELECT COUNT(*)
      FROM Saved_ReelsNStories srs
      WHERE srs.saved_video_id = rs.id
    ) AS savedCount,

    -- ✅ NEW: total_reviews per shop
    (
      SELECT COUNT(R2.order_item_review_id)
      FROM Order_Item_Review R2
      JOIN Order_Items OI2      ON R2.order_item_id = OI2.order_item_id
      JOIN Product_Variants PV2 ON OI2.order_item_variant_id = PV2.variant_id
      JOIN Products P2          ON PV2.variant_product_id = P2.product_id
      WHERE P2.product_shop_id = s.shop_id
    ) AS total_reviews,

    ${
      userId
        ? `CASE
            WHEN EXISTS (
              SELECT 1 FROM Saved_ReelsNStories srs
              WHERE srs.saved_video_id = rs.id AND srs.saved_user_id = @userId
            ) THEN 1 ELSE 0
          END`
        : `CAST(NULL AS BIT)`
    } AS isSaved,
    ${
      userId
        ? `CASE
            WHEN EXISTS (
              SELECT 1 FROM Liked_ReelsNStories lrs
              WHERE lrs.liked_video_id = rs.id AND lrs.liked_user_id = @userId
            ) THEN 1 ELSE 0
          END`
        : `CAST(NULL AS BIT)`
    } AS isLiked

  FROM ReelsNStories rs
  JOIN Videos v ON rs.video_url_id = v.video_id
  LEFT JOIN Reels_Products rp ON rs.video_url_id = rp.reel_video_id
  LEFT JOIN Products p ON rp.reel_product_id = p.product_id
  OUTER APPLY (
    SELECT TOP 1 variant_price, variant_discounted_price
    FROM Product_Variants
    WHERE variant_product_id = p.product_id
    ORDER BY variant_price ASC
  ) pv
  LEFT JOIN Shops s ON v.video_shop_id = s.shop_id
  WHERE rs.video_type = 'REEL' AND p.product_is_active = 'true'
)

SELECT *
FROM (
  SELECT *,
    CASE
      WHEN video_url_id = @videoId THEN 0
      ${
        shopId
          ? `WHEN shop_id = @shopId AND video_url_id != @videoId THEN 1`
          : ""
      }
      ELSE 2
    END AS sort_order
  FROM ReelsBase
) AS Combined
ORDER BY sort_order ASC, NEWID()
OFFSET @offset ROWS FETCH NEXT @pageSize ROWS ONLY;

    `;

    const request = pool
      .request()
      .input("videoId", videoId)
      .input("offset", offset)
      .input("pageSize", pageSize);

    if (userId) request.input("userId", userId);
    if (shopId) request.input("shopId", shopId);

    const result = await request.query(query);
    return result.recordset;
  } catch (error: any) {
    sendErrorEmail("Error fetching reels by video ID:", error);

    console.error("Error fetching reels by video ID:", error);
    throw new Error("Failed to fetch reels by video ID");
  }
};

export const getLatestReelByOffset = async (offset: number) => {
  const pool = await poolPromise;

  try {
    const query = `
      SELECT 
        rs.video_url_id,
        rs.video_title,
        rs.video_likes_count,
        rs.video_view_count,
        rs.video_type,
        v.video_url_preview, -- add this field in SELECT
        v.video_url,
        v.video_thumbnail_url,
        rp.reel_video_id AS product_reel_video_id,
        rp.reel_product_id AS product_id,
        p.product_name,
        p.product_image_url,
        s.shop_id,
        s.shop_name,
        s.shop_logo_url
      FROM ReelsNStories rs
      JOIN Videos v ON rs.video_url_id = v.video_id
      LEFT JOIN Reels_Products rp ON rs.video_url_id = rp.reel_video_id
      LEFT JOIN Products p ON rp.reel_product_id = p.product_id
      LEFT JOIN Shops s ON v.video_shop_id = s.shop_id
      WHERE 
        rs.video_type = 'REEL'
        AND p.product_is_active = 'true'
        AND v.video_url_preview IS NOT NULL -- ✅ only with preview
      ORDER BY NEWID() 
      OFFSET @offset ROWS FETCH NEXT 5 ROWS ONLY;
    `;

    const result = await pool.request().input("offset", offset).query(query);
    const records = result.recordset;

    const shopIds = [...new Set(records.map((r) => r.shop_id))];

    const shopStoryMap: Record<number, boolean> = {};
    await Promise.all(
      shopIds.map(async (shopId) => {
        shopStoryMap[shopId] = await isHaveStories(shopId);
      })
    );

    const reelsWithStories = records.map((r) => ({
      ...r,
      shopHaveStory: shopStoryMap[r.shop_id] || false,
    }));

    return reelsWithStories;
  } catch (error: any) {
    sendErrorEmail("Error fetching latest reel by offset:", error);

    console.error("Error fetching latest reel by offset:", error);
    throw new Error("Failed to fetch the latest reel");
  }
};

export const getReelsByShop = async (shopId: number, userId?: number) => {
  const pool = await poolPromise;

  try {
    const query = `
      SELECT 
          rs.video_url_id,
          rs.video_title,
          rs.video_likes_count,
          rs.video_view_count,
          rs.video_type,
          v.video_url,
          v.video_thumbnail_url,
          rp.reel_video_id AS product_reel_video_id,
          rp.reel_product_id AS product_id,
          p.product_name,
          p.product_image_url,
          s.shop_id,
          s.shop_name,
          s.shop_logo_url
      FROM ReelsNStories rs
      JOIN Videos v ON rs.video_url_id = v.video_id
      LEFT JOIN Reels_Products rp ON rs.video_url_id = rp.reel_video_id
      LEFT JOIN Products p ON rp.reel_product_id = p.product_id
      LEFT JOIN Shops s ON v.video_shop_id = s.shop_id
      WHERE v.video_shop_id = @shopId AND rs.video_type = 'REEL' AND p.product_is_active = 'true'
      ORDER BY v.created_at DESC;
    `;

    const request = pool.request().input("shopId", shopId);
    const result = await request.query(query);
    const records = result.recordset;

    if (records.length === 0) {
      return {
        shop: null,
        reels: [],
        savedReels: [],
      };
    }

    const { shop_id } = records[0];
    const shop = await getUsingShopId(shop_id);
    const { rating, total_reviews } = await getShopReviews(shop_id);
    shop.rating = rating || 0;
    shop.total_reviews = total_reviews || 0;
    const reels = records.map((row) => ({
      video_url_id: row.video_url_id,
      video_title: row.video_title,
      video_likes_count: row.video_likes_count,
      video_view_count: row.video_view_count,
      video_type: row.video_type,
      video_url: row.video_url,
      video_thumbnail_url: row.video_thumbnail_url,
      rating: rating || 0,
      total_reviews: total_reviews || 0,
      product: row.product_id
        ? {
            product_id: row.product_id,
            product_name: row.product_name,
            product_image_url: row.product_image_url,
          }
        : null,
    }));

    let savedReels: Array<{
      saved_video_id: number;
      video_url: string;
      video_thumbnail_url: string;
    }> = [];

    if (userId) {
      const savedQuery = `
        SELECT srs.saved_video_id, v.video_url, v.video_thumbnail_url , rns.video_view_count
        FROM Saved_ReelsNStories srs
        JOIN ReelsNStories rns ON srs.saved_video_id = rns.id
        JOIN Videos v ON rns.video_url_id = v.video_id
        WHERE srs.saved_user_id = @userId AND v.video_shop_id = @shopId;
      `;

      const savedResult = await pool
        .request()
        .input("userId", userId)
        .input("shopId", shopId)
        .query(savedQuery);

      // Map the saved videos to include URL and thumbnail
      savedReels = savedResult.recordset.map((row) => ({
        saved_video_id: row.saved_video_id,
        video_url: row.video_url,
        video_thumbnail_url: row.video_thumbnail_url,
        video_view_count: row.video_view_count,
      }));
    }

    return { shop, reels, savedReels };
  } catch (error: any) {
    sendErrorEmail("Error fetching reels by shop ID:", error);

    console.error("Error fetching reels by shop ID:", error);
    throw new Error("Failed to fetch reels for the shop");
  }
};

export const SavedReel = async (
  user_id: number,
  video_id: number,
  status: boolean
): Promise<{
  message: string;
  status: boolean;
  action: "created" | "deleted";
}> => {
  const pool = await poolPromise;

  // Check if user exists
  const userResult = await pool
    .request()
    .input("user_id", user_id)
    .query("SELECT 1 FROM Users WHERE user_id = @user_id");

  if (userResult.recordset.length === 0) {
    throw new Error(`User with ID ${user_id} does not exist.`);
  }

  // Check if video exists
  const videoResult = await pool
    .request()
    .input("video_id", video_id)
    .query("SELECT 1 FROM ReelsNStories WHERE id = @video_id");

  if (videoResult.recordset.length === 0) {
    throw new Error(`Video with ID ${video_id} does not exist.`);
  }

  if (status) {
    // Save
    await pool
      .request()
      .input("user_id", user_id)
      .input("video_id", video_id)
      .input("status", true).query(`
        INSERT INTO Saved_ReelsNStories 
        (saved_user_id, saved_video_id, saved_status) 
        VALUES (@user_id, @video_id, @status)
      `);
    return {
      message: "Video saved successfully",
      status: true,
      action: "created",
    };
  } else {
    // Unsave
    await pool.request().input("user_id", user_id).input("video_id", video_id)
      .query(`
        DELETE FROM Saved_ReelsNStories 
        WHERE saved_user_id = @user_id AND saved_video_id = @video_id
      `);
    return {
      message: "Video unsaved successfully",
      status: false,
      action: "deleted",
    };
  }
};

// models/reelsModel.ts

export const updateReelViewCount = async (videoId: number): Promise<void> => {
  const pool = await poolPromise;

  const query = `
    UPDATE ReelsNStories
    SET video_view_count = video_view_count + 1
    WHERE video_url_id = @videoId
  `;

  await pool.request().input("videoId", videoId).query(query);
};

export const LikeReel = async (
  user_id: number,
  video_id: number,
  liked: boolean
): Promise<{ message: string; status: boolean }> => {
  const pool = await poolPromise;

  const userResult = await pool
    .request()
    .input("user_id", user_id)
    .query("SELECT 1 FROM Users WHERE user_id = @user_id");

  if (userResult.recordset.length === 0) {
    throw new Error(`User with ID ${user_id} does not exist.`);
  }

  const videoResult = await pool
    .request()
    .input("video_id", video_id)
    .query("SELECT 1 FROM ReelsNStories WHERE id = @video_id");

  if (videoResult.recordset.length === 0) {
    throw new Error(`Video with ID ${video_id} does not exist.`);
  }

  const likeCheck = await pool
    .request()
    .input("user_id", user_id)
    .input("video_id", video_id).query(`
      SELECT liked_id FROM Liked_ReelsNStories
      WHERE liked_user_id = @user_id AND liked_video_id = @video_id
    `);

  const alreadyLiked = likeCheck.recordset.length > 0;

  if (liked) {
    if (!alreadyLiked) {
      await pool.request().input("user_id", user_id).input("video_id", video_id)
        .query(`
          INSERT INTO Liked_ReelsNStories (liked_user_id, liked_video_id)
          VALUES (@user_id, @video_id)
        `);

      await pool.request().input("video_id", video_id).query(`
          UPDATE ReelsNStories
          SET video_likes_count = video_likes_count + 1
          WHERE id = @video_id
        `);

      return { message: "Video liked successfully", status: true };
    } else {
      return { message: "Video already liked", status: true };
    }
  } else {
    if (alreadyLiked) {
      await pool.request().input("user_id", user_id).input("video_id", video_id)
        .query(`
          DELETE FROM Liked_ReelsNStories
          WHERE liked_user_id = @user_id AND liked_video_id = @video_id
        `);

      await pool.request().input("video_id", video_id).query(`
          UPDATE ReelsNStories
          SET video_likes_count = video_likes_count - 1
          WHERE id = @video_id
        `);

      return { message: "Video unliked successfully", status: false };
    } else {
      return { message: "Video already unliked", status: false };
    }
  }
};

export const getStories = async (shopId: number, userId?: number) => {
  console.log(shopId, "shopId");
  const pool = await poolPromise;

  try {
    const query = `
      SELECT
        rs.id,
        rs.video_url_id,
        rs.video_title,
        rs.video_type,
        rs.video_likes_count,
        rs.created_at AS story_created_at,
        rs.updated_at AS story_updated_at,

        v.video_url,
        v.updated_at AS video_updated_at,
        v.video_thumbnail_url,

        s.shop_id,
        s.shop_name,
        s.shop_logo_url,

        rp.reel_video_id AS product_reel_video_id,
        rp.reel_product_id AS product_id,
        p.product_name,
        p.product_image_url,
        p.product_is_active,

        pv.variant_price,
        pv.variant_discounted_price,

        ${
          userId
            ? `CASE
                WHEN EXISTS (
                  SELECT 1 FROM Liked_ReelsNStories lrs
                  WHERE lrs.liked_video_id = rs.id
                  AND lrs.liked_user_id = @userId
                ) THEN 1 ELSE 0 END`
            : `CAST(NULL AS BIT)`
        } AS isLiked

      FROM ReelsNStories rs
      JOIN Videos v ON rs.video_url_id = v.video_id
      LEFT JOIN Shops s ON v.video_shop_id = s.shop_id
      LEFT JOIN Reels_Products rp ON rs.video_url_id = rp.reel_video_id
      LEFT JOIN Products p ON rp.reel_product_id = p.product_id

      OUTER APPLY (
        SELECT TOP 1 variant_price, variant_discounted_price
        FROM Product_Variants
        WHERE variant_product_id = p.product_id
        ORDER BY variant_price ASC
      ) pv

      WHERE
        UPPER(rs.video_type) = 'STORY'
        AND v.video_shop_id = @shopId
        AND (p.product_is_active = 'true' OR p.product_is_active IS NULL)
        AND v.updated_at >= DATEADD(HOUR, -24, GETDATE())

      ORDER BY v.updated_at DESC;
    `;

    const request = pool.request().input("shopId", shopId);
    if (userId) request.input("userId", userId);

    const result = await request.query(query);

    const groupedStories: { [shopId: number]: any } = {};

    for (const row of result.recordset) {
      const shop_Id = row.shop_id;

      // Group by shop
      if (!groupedStories[shop_Id]) {
        const shopDetail = await getUsingShopId(shop_Id);
        groupedStories[shop_Id] = {
          shop: { ...shopDetail },
          stories: [],
        };
      }

      // Check if story exists
      let story = groupedStories[shop_Id].stories.find(
        (s: any) => s.id === row.id
      );

      // Create new story entry if not exists
      if (!story) {
        story = {
          id: row.id,
          video_url_id: row.video_url_id,
          video_title: row.video_title,
          video_type: row.video_type,
          video_likes_count: row.video_likes_count,

          // NEW FIELDS
          story_created_at: row.story_created_at,
          story_updated_at: row.story_updated_at,

          video_url: row.video_url,
          video_thumbnail_url: row.video_thumbnail_url,
          video_updatedAt: row.video_updated_at,

          isLiked: row.isLiked,

          products: [],
        };

        groupedStories[shop_Id].stories.push(story);
      }

      // Push product
      if (row.product_id) {
        story.products.push({
          product_id: row.product_id,
          product_name: row.product_name,
          product_image_url: row.product_image_url,
          variant_price: row.variant_price,
          variant_discounted_price: row.variant_discounted_price,
        });
      }
    }

    return Object.values(groupedStories);
  } catch (error: any) {
    sendErrorEmail("Error fetching stories:", error);
    console.error("Error fetching stories:", error);
    throw new Error("Failed to fetch stories");
  }
};


export const isHaveStories = async (shopId: number) => {
  const pool = await poolPromise;
  try {
    const query = `
      SELECT COUNT(*) AS story_count
      FROM ReelsNStories rs
      JOIN Videos v ON rs.video_url_id = v.video_id
      WHERE 
        UPPER(rs.video_type) = 'STORY' AND 
        v.video_shop_id = @shopId AND 
        v.updated_at >= DATEADD(HOUR, -24, GETDATE());
    `;

    const request = pool.request().input("shopId", shopId);
    const result = await request.query(query);

    // If count is greater than 0, shop has recent stories
    return result.recordset[0].story_count > 0;
  } catch (error: any) {
    sendErrorEmail("Error checking if shop has stories:", error);

    console.error("Error checking if shop has stories:", error);
    throw new Error("Failed to check if shop has stories");
  }
};

export const GetSavedReels = async (
  user_id: number,
  page: number,
  pageSize: number
): Promise<{ data: any[]; total: number }> => {
  const pool = await poolPromise;
  const offset = (page - 1) * pageSize;

  const totalResult = await pool.request().input("user_id", user_id).query(`
    SELECT COUNT(*) as total 
    FROM Saved_ReelsNStories 
    WHERE saved_user_id = @user_id
  `);

  const total = totalResult.recordset[0].total;

  const result = await pool
    .request()
    .input("user_id", user_id)
    .input("offset", offset)
    .input("pageSize", pageSize).query(`
    WITH SavedBase AS (
      SELECT 
        s.saved_video_id,
        s.saved_status,
        s.created_at AS saved_created_at,
        r.id AS reel_id,
        r.video_url_id,
        r.video_title,
        r.video_likes_count,
        r.video_view_count,
        r.video_type,
        r.created_at AS reel_created_at,
        v.video_url,
        v.video_thumbnail_url,
        v.video_url_1080p,
        v.created_at AS video_created_at,
        rp.reel_product_id AS product_id,
        p.product_name,
        p.product_image_url,
        p.product_is_active,
        p.created_at AS product_created_at,
        pv.variant_price,
        pv.variant_discounted_price,
        shops.shop_id,
        shops.shop_name,
        shops.shop_logo_url,
        (
          SELECT ISNULL(AVG(R2.order_item_review_rating),0)
          FROM Order_Item_Review R2
          JOIN Order_Items OI2 ON R2.order_item_id = OI2.order_item_id
          JOIN Product_Variants PV2 ON OI2.order_item_variant_id = PV2.variant_id
          JOIN Products P2 ON PV2.variant_product_id = P2.product_id
          WHERE P2.product_shop_id = shops.shop_id
        ) AS rating,
        (
          SELECT COUNT(R2.order_item_review_id)
          FROM Order_Item_Review R2
          JOIN Order_Items OI2 ON R2.order_item_id = OI2.order_item_id
          JOIN Product_Variants PV2 ON OI2.order_item_variant_id = PV2.variant_id
          JOIN Products P2 ON PV2.variant_product_id = P2.product_id
          WHERE P2.product_shop_id = shops.shop_id
        ) AS total_reviews
      FROM Saved_ReelsNStories s
      JOIN ReelsNStories r ON s.saved_video_id = r.id
      JOIN Videos v ON r.video_url_id = v.video_id
      LEFT JOIN Reels_Products rp ON r.video_url_id = rp.reel_video_id
      LEFT JOIN Products p ON rp.reel_product_id = p.product_id
      OUTER APPLY (
        SELECT TOP 1 variant_price, variant_discounted_price 
        FROM Product_Variants
        WHERE variant_product_id = p.product_id
        ORDER BY variant_price ASC
      ) pv
      LEFT JOIN Shops shops ON v.video_shop_id = shops.shop_id
      WHERE s.saved_user_id = @user_id
    )
    SELECT * 
    FROM SavedBase
    ORDER BY 
      saved_created_at DESC, 
      saved_video_id DESC
    OFFSET @offset ROWS FETCH NEXT @pageSize ROWS ONLY;
  `);

  return {
    data: result.recordset,
    total,
  };
};
