// src/analytics/getAnalyticsFromFirebase.ts
import bigquery from "../../firebase/bqClient";
import { toDate, toSuffix } from "../../functions/common";
import { AnalyticsParams } from "../../types/analytics/Analytics";

const { GA_PROJECT, GA_DATASET, GA_LOCATION, GA_STREAM_ID, GA_PACKAGE_NAME } =
  process.env;

export const getAnalyticsFromFirebase = async (
  searchParams?: AnalyticsParams
): Promise<any[]> => {
  const p = searchParams ?? {};
  const params: Record<string, any> = {};
  const table = `\`${GA_PROJECT}.${GA_DATASET}.events_*\``;

  let where = "";

  const start =
    toDate(p.start_date) ?? new Date(Date.now() - 6 * 24 * 3600 * 1000); // last 7d
  const endRaw = toDate(p.end_date) ?? new Date();
  const end = new Date(endRaw.getTime() + 24 * 3600 * 1000);

  params.startSuffix = toSuffix(start);
  params.endSuffix = toSuffix(end);
  where = `WHERE _TABLE_SUFFIX BETWEEN @startSuffix AND @endSuffix`;

  params.startTs = start;
  params.endTs = end;
  where += `
    AND TIMESTAMP_MICROS(event_timestamp) >= @startTs
    AND TIMESTAMP_MICROS(event_timestamp) <  @endTs
  `;

  if (GA_STREAM_ID) {
    where += ` AND stream_id = @envStreamId`;
    params.envStreamId = GA_STREAM_ID;
  }
  if (GA_PACKAGE_NAME) {
    where += ` AND app_info.id = @envPackageName`;
    params.envPackageName = GA_PACKAGE_NAME;
  }
  if (p.event_name) {
    where += ` AND event_name = @eventName`;
    params.eventName = p.event_name;
  }

  if (p.user_name) {
    where += `
      AND EXISTS (
        SELECT 1 FROM UNNEST(event_params) ep
        WHERE ep.key = "user_name" AND ep.value.string_value LIKE @userName
      )`;
    params.userName = `%${p.user_name}%`;
  }

  if (p.user_id) {
    where += `
      AND EXISTS (
        SELECT 1 FROM UNNEST(event_params) ep
        WHERE ep.key = "user_id" AND ep.value.string_value = @userId
      )`;
    params.userId = p.user_id;
  }

  if (typeof p.merchant_id === "number") {
    where += `
      AND EXISTS (
        SELECT 1 FROM UNNEST(event_params) ep
        WHERE ep.key = "merchant_id" AND ep.value.double_value = @merchantId
      )`;
    params.merchantId = p.merchant_id;
  }

  if (p.merchant_name) {
    where += `
      AND EXISTS (
        SELECT 1 FROM UNNEST(event_params) ep
        WHERE ep.key = "merchant_name" AND ep.value.string_value LIKE @merchantName
      )`;
    params.merchantName = `%${p.merchant_name}%`;
  }

  if (typeof p.product_id === "number") {
    where += `
      AND EXISTS (
        SELECT 1 FROM UNNEST(event_params) ep
        WHERE ep.key = "product_id" AND ep.value.double_value = @productId
      )`;
    params.productId = p.product_id;
  }

  if (p.product_name) {
    where += `
      AND EXISTS (
        SELECT 1 FROM UNNEST(event_params) ep
        WHERE ep.key = "product_name" AND ep.value.string_value LIKE @productName
      )`;
    params.productName = `%${p.product_name}%`;
  }

  if (p.platform) {
    where += `
      AND EXISTS (
        SELECT 1 FROM UNNEST(event_params) ep
        WHERE ep.key = "platform" AND ep.value.string_value LIKE @platform
      )`;
    params.platform = `%${p.platform}%`;
  }

  // Event type filter
  if (p.event_type) {
    where += `
      AND EXISTS (
        SELECT 1 FROM UNNEST(event_params) ep
        WHERE ep.key = "event_type" AND ep.value.string_value = @eventType
      )`;
    params.eventType = p.event_type;
  }

  // Device ID filter
  if (p.device_id) {
    where += `
      AND EXISTS (
        SELECT 1 FROM UNNEST(event_params) ep
        WHERE ep.key = "device_id" AND ep.value.string_value = @deviceId
      )`;
    params.deviceId = p.device_id;
  }

  // Shop filters
  if (typeof p.shop_id === "number") {
    where += `
      AND EXISTS (
        SELECT 1 FROM UNNEST(event_params) ep
        WHERE ep.key = "shop_id" AND ep.value.double_value = @shopId
      )`;
    params.shopId = p.shop_id;
  }

  if (p.shop_name) {
    where += `
      AND EXISTS (
        SELECT 1 FROM UNNEST(event_params) ep
        WHERE ep.key = "shop_name" AND ep.value.string_value LIKE @shopName
      )`;
    params.shopName = `%${p.shop_name}%`;
  }

  if (p.shop_tile_type) {
    where += `
      AND EXISTS (
        SELECT 1 FROM UNNEST(event_params) ep
        WHERE ep.key = "shop_tile_type" AND ep.value.string_value = @shopTileType
      )`;
    params.shopTileType = p.shop_tile_type;
  }

  if (p.merchant_shopify_id) {
    where += `
      AND EXISTS (
        SELECT 1 FROM UNNEST(event_params) ep
        WHERE ep.key = "merchant_shopify_id" AND ep.value.string_value = @merchantShopifyId
      )`;
    params.merchantShopifyId = p.merchant_shopify_id;
  }

  // Search filters
  if (p.search_query) {
    where += `
      AND EXISTS (
        SELECT 1 FROM UNNEST(event_params) ep
        WHERE ep.key = "search_query" AND ep.value.string_value LIKE @searchQuery
      )`;
    params.searchQuery = `%${p.search_query}%`;
  }

  if (p.result_type) {
    where += `
      AND EXISTS (
        SELECT 1 FROM UNNEST(event_params) ep
        WHERE ep.key = "result_type" AND ep.value.string_value = @resultType
      )`;
    params.resultType = p.result_type;
  }

  if (typeof p.is_from_search === "boolean") {
    where += `
      AND EXISTS (
        SELECT 1 FROM UNNEST(event_params) ep
        WHERE ep.key = "is_from_search" AND ep.value.string_value = @isFromSearch
      )`;
    params.isFromSearch = p.is_from_search ? "true" : "false";
  }

  // Screen filter
  if (p.screen_name) {
    where += `
      AND EXISTS (
        SELECT 1 FROM UNNEST(event_params) ep
        WHERE ep.key = "screen_name" AND ep.value.string_value = @screenName
      )`;
    params.screenName = p.screen_name;
  }

  // Deal filter
  if (typeof p.deal_id === "number") {
    where += `
      AND EXISTS (
        SELECT 1 FROM UNNEST(event_params) ep
        WHERE ep.key = "deal_id" AND ep.value.double_value = @dealId
      )`;
    params.dealId = p.deal_id;
  }

  // Position filters
  if (typeof p.position_in_results === "number") {
    where += `
      AND EXISTS (
        SELECT 1 FROM UNNEST(event_params) ep
        WHERE ep.key = "position_in_results" AND ep.value.double_value = @positionInResults
      )`;
    params.positionInResults = p.position_in_results;
  }

  if (typeof p.position_in_list === "number") {
    where += `
      AND EXISTS (
        SELECT 1 FROM UNNEST(event_params) ep
        WHERE ep.key = "position_in_list" AND ep.value.double_value = @positionInList
      )`;
    params.positionInList = p.position_in_list;
  }

  if (typeof p.tile_position === "number") {
    where += `
      AND EXISTS (
        SELECT 1 FROM UNNEST(event_params) ep
        WHERE ep.key = "tile_position" AND ep.value.double_value = @tilePosition
      )`;
    params.tilePosition = p.tile_position;
  }

  if (typeof p.product_position_in_tile === "number") {
    where += `
      AND EXISTS (
        SELECT 1 FROM UNNEST(event_params) ep
        WHERE ep.key = "product_position_in_tile" AND ep.value.double_value = @productPositionInTile
      )`;
    params.productPositionInTile = p.product_position_in_tile;
  }

  // Screen time filters
  if (typeof p.min_screen_time_seconds === "number") {
    where += `
      AND EXISTS (
        SELECT 1 FROM UNNEST(event_params) ep
        WHERE ep.key = "screen_time_seconds" AND ep.value.double_value >= @minScreenTime
      )`;
    params.minScreenTime = p.min_screen_time_seconds;
  }

  if (typeof p.max_screen_time_seconds === "number") {
    where += `
      AND EXISTS (
        SELECT 1 FROM UNNEST(event_params) ep
        WHERE ep.key = "screen_time_seconds" AND ep.value.double_value <= @maxScreenTime
      )`;
    params.maxScreenTime = p.max_screen_time_seconds;
  }

  // View count filters
  if (typeof p.min_product_view === "number") {
    where += `
      AND EXISTS (
        SELECT 1 FROM UNNEST(event_params) ep
        WHERE ep.key = "product_view" AND ep.value.double_value >= @minProductView
      )`;
    params.minProductView = p.min_product_view;
  }

  if (typeof p.max_product_view === "number") {
    where += `
      AND EXISTS (
        SELECT 1 FROM UNNEST(event_params) ep
        WHERE ep.key = "product_view" AND ep.value.double_value <= @maxProductView
      )`;
    params.maxProductView = p.max_product_view;
  }

  if (typeof p.min_merchant_view === "number") {
    where += `
      AND EXISTS (
        SELECT 1 FROM UNNEST(event_params) ep
        WHERE ep.key = "merchant_view" AND ep.value.double_value >= @minMerchantView
      )`;
    params.minMerchantView = p.min_merchant_view;
  }

  if (typeof p.max_merchant_view === "number") {
    where += `
      AND EXISTS (
        SELECT 1 FROM UNNEST(event_params) ep
        WHERE ep.key = "merchant_view" AND ep.value.double_value <= @maxMerchantView
      )`;
    params.maxMerchantView = p.max_merchant_view;
  }

  // Search result count filters
  if (typeof p.min_total_results === "number") {
    where += `
      AND EXISTS (
        SELECT 1 FROM UNNEST(event_params) ep
        WHERE ep.key = "total_results" AND ep.value.double_value >= @minTotalResults
      )`;
    params.minTotalResults = p.min_total_results;
  }

  if (typeof p.max_total_results === "number") {
    where += `
      AND EXISTS (
        SELECT 1 FROM UNNEST(event_params) ep
        WHERE ep.key = "total_results" AND ep.value.double_value <= @maxTotalResults
      )`;
    params.maxTotalResults = p.max_total_results;
  }

  if (typeof p.min_products_count === "number") {
    where += `
      AND EXISTS (
        SELECT 1 FROM UNNEST(event_params) ep
        WHERE ep.key = "products_count" AND ep.value.double_value >= @minProductsCount
      )`;
    params.minProductsCount = p.min_products_count;
  }

  if (typeof p.max_products_count === "number") {
    where += `
      AND EXISTS (
        SELECT 1 FROM UNNEST(event_params) ep
        WHERE ep.key = "products_count" AND ep.value.double_value <= @maxProductsCount
      )`;
    params.maxProductsCount = p.max_products_count;
  }

  if (typeof p.min_shops_count === "number") {
    where += `
      AND EXISTS (
        SELECT 1 FROM UNNEST(event_params) ep
        WHERE ep.key = "shops_count" AND ep.value.double_value >= @minShopsCount
      )`;
    params.minShopsCount = p.min_shops_count;
  }

  if (typeof p.max_shops_count === "number") {
    where += `
      AND EXISTS (
        SELECT 1 FROM UNNEST(event_params) ep
        WHERE ep.key = "shops_count" AND ep.value.double_value <= @maxShopsCount
      )`;
    params.maxShopsCount = p.max_shops_count;
  }

  // Geo filters
  if (p.country) {
    where += ` AND LOWER(geo.country) LIKE @country`;
    params.country = `%${p.country.toLowerCase()}%`;
  }

  if (p.city) {
    where += ` AND LOWER(geo.city) LIKE @city`;
    params.city = `%${p.city.toLowerCase()}%`;
  }

  // Reel/Video filters
  if (p.video_url_id) {
    where += `
      AND EXISTS (
        SELECT 1 FROM UNNEST(event_params) ep
        WHERE ep.key = "video_url_id" AND ep.value.string_value = @videoUrlId
      )`;
    params.videoUrlId = p.video_url_id;
  }

  if (typeof p.video_id === "number") {
    where += `
      AND EXISTS (
        SELECT 1 FROM UNNEST(event_params) ep
        WHERE ep.key = "video_id" AND ep.value.double_value = @videoId
      )`;
    params.videoId = p.video_id;
  }

  if (typeof p.is_liked === "boolean") {
    where += `
      AND EXISTS (
        SELECT 1 FROM UNNEST(event_params) ep
        WHERE ep.key = "is_liked" AND ep.value.string_value = @isLiked
      )`;
    params.isLiked = p.is_liked ? "true" : "false";
  }

  if (typeof p.min_watch_duration_seconds === "number") {
    where += `
      AND EXISTS (
        SELECT 1 FROM UNNEST(event_params) ep
        WHERE ep.key = "watch_duration_seconds" AND ep.value.double_value >= @minWatchDuration
      )`;
    params.minWatchDuration = p.min_watch_duration_seconds;
  }

  if (typeof p.max_watch_duration_seconds === "number") {
    where += `
      AND EXISTS (
        SELECT 1 FROM UNNEST(event_params) ep
        WHERE ep.key = "watch_duration_seconds" AND ep.value.double_value <= @maxWatchDuration
      )`;
    params.maxWatchDuration = p.max_watch_duration_seconds;
  }

  if (typeof p.min_completion_rate === "number") {
    where += `
      AND EXISTS (
        SELECT 1 FROM UNNEST(event_params) ep
        WHERE ep.key = "completion_rate" AND ep.value.double_value >= @minCompletionRate
      )`;
    params.minCompletionRate = p.min_completion_rate;
  }

  if (typeof p.max_completion_rate === "number") {
    where += `
      AND EXISTS (
        SELECT 1 FROM UNNEST(event_params) ep
        WHERE ep.key = "completion_rate" AND ep.value.double_value <= @maxCompletionRate
      )`;
    params.maxCompletionRate = p.max_completion_rate;
  }

  // Product Detail filters
  if (typeof p.current_product_id === "number") {
    where += `
      AND EXISTS (
        SELECT 1 FROM UNNEST(event_params) ep
        WHERE ep.key = "current_product_id" AND ep.value.double_value = @currentProductId
      )`;
    params.currentProductId = p.current_product_id;
  }

  if (typeof p.clicked_product_id === "number") {
    where += `
      AND EXISTS (
        SELECT 1 FROM UNNEST(event_params) ep
        WHERE ep.key = "clicked_product_id" AND ep.value.double_value = @clickedProductId
      )`;
    params.clickedProductId = p.clicked_product_id;
  }

  if (typeof p.variant_id === "number") {
    where += `
      AND EXISTS (
        SELECT 1 FROM UNNEST(event_params) ep
        WHERE ep.key = "variant_id" AND ep.value.double_value = @variantId
      )`;
    params.variantId = p.variant_id;
  }

  if (p.action_type) {
    where += `
      AND EXISTS (
        SELECT 1 FROM UNNEST(event_params) ep
        WHERE ep.key = "action_type" AND ep.value.string_value = @actionType
      )`;
    params.actionType = p.action_type;
  }

  if (typeof p.quantity === "number") {
    where += `
      AND EXISTS (
        SELECT 1 FROM UNNEST(event_params) ep
        WHERE ep.key = "quantity" AND ep.value.double_value = @quantity
      )`;
    params.quantity = p.quantity;
  }

  if (p.shop_currency) {
    where += `
      AND EXISTS (
        SELECT 1 FROM UNNEST(event_params) ep
        WHERE ep.key = "shop_currency" AND ep.value.string_value = @shopCurrency
      )`;
    params.shopCurrency = p.shop_currency;
  }

  // Collection filters
  if (typeof p.collection_id === "number") {
    where += `
      AND EXISTS (
        SELECT 1 FROM UNNEST(event_params) ep
        WHERE ep.key = "collection_id" AND ep.value.double_value = @collectionId
      )`;
    params.collectionId = p.collection_id;
  }

  if (p.collection_name) {
    where += `
      AND EXISTS (
        SELECT 1 FROM UNNEST(event_params) ep
        WHERE ep.key = "collection_name" AND ep.value.string_value LIKE @collectionName
      )`;
    params.collectionName = `%${p.collection_name}%`;
  }

  if (typeof p.from_collection_id === "number") {
    where += `
      AND EXISTS (
        SELECT 1 FROM UNNEST(event_params) ep
        WHERE ep.key = "from_collection_id" AND ep.value.double_value = @fromCollectionId
      )`;
    params.fromCollectionId = p.from_collection_id;
  }

  if (typeof p.to_collection_id === "number") {
    where += `
      AND EXISTS (
        SELECT 1 FROM UNNEST(event_params) ep
        WHERE ep.key = "to_collection_id" AND ep.value.double_value = @toCollectionId
      )`;
    params.toCollectionId = p.to_collection_id;
  }

  // Navigation filters (tabs and screens)
  if (p.from_tab) {
    where += `
      AND EXISTS (
        SELECT 1 FROM UNNEST(event_params) ep
        WHERE ep.key = "from_tab" AND ep.value.string_value = @fromTab
      )`;
    params.fromTab = p.from_tab;
  }

  if (p.to_tab) {
    where += `
      AND EXISTS (
        SELECT 1 FROM UNNEST(event_params) ep
        WHERE ep.key = "to_tab" AND ep.value.string_value = @toTab
      )`;
    params.toTab = p.to_tab;
  }

  if (p.from_screen) {
    where += `
      AND EXISTS (
        SELECT 1 FROM UNNEST(event_params) ep
        WHERE ep.key = "from_screen" AND ep.value.string_value = @fromScreen
      )`;
    params.fromScreen = p.from_screen;
  }

  if (p.to_screen) {
    where += `
      AND EXISTS (
        SELECT 1 FROM UNNEST(event_params) ep
        WHERE ep.key = "to_screen" AND ep.value.string_value = @toScreen
      )`;
    params.toScreen = p.to_screen;
  }

  // Filter change tracking
  if (p.filter_type) {
    where += `
      AND EXISTS (
        SELECT 1 FROM UNNEST(event_params) ep
        WHERE ep.key = "filter_type" AND ep.value.string_value = @filterType
      )`;
    params.filterType = p.filter_type;
  }

  if (p.filter_value) {
    where += `
      AND EXISTS (
        SELECT 1 FROM UNNEST(event_params) ep
        WHERE ep.key = "filter_value" AND ep.value.string_value LIKE @filterValue
      )`;
    params.filterValue = `%${p.filter_value}%`;
  }

  // Item tracking
  if (p.item_id) {
    where += `
      AND EXISTS (
        SELECT 1 FROM UNNEST(event_params) ep
        WHERE ep.key = "item_id" AND ep.value.string_value = @itemId
      )`;
    params.itemId = p.item_id;
  }

  if (p.item_type) {
    where += `
      AND EXISTS (
        SELECT 1 FROM UNNEST(event_params) ep
        WHERE ep.key = "item_type" AND ep.value.string_value = @itemType
      )`;
    params.itemType = p.item_type;
  }

  // Brand page specific filters
  if (typeof p.is_from_brand_page === "boolean") {
    where += `
      AND EXISTS (
        SELECT 1 FROM UNNEST(event_params) ep
        WHERE ep.key = "is_from_brand_page" AND ep.value.string_value = @isFromBrandPage
      )`;
    params.isFromBrandPage = p.is_from_brand_page ? "true" : "false";
  }

  if (typeof p.click_order === "number") {
    where += `
      AND EXISTS (
        SELECT 1 FROM UNNEST(event_params) ep
        WHERE ep.key = "click_order" AND ep.value.double_value = @clickOrder
      )`;
    params.clickOrder = p.click_order;
  }

  // View duration filters
  if (typeof p.min_view_duration_seconds === "number") {
    where += `
      AND EXISTS (
        SELECT 1 FROM UNNEST(event_params) ep
        WHERE ep.key = "view_duration_seconds" AND ep.value.double_value >= @minViewDuration
      )`;
    params.minViewDuration = p.min_view_duration_seconds;
  }

  if (typeof p.max_view_duration_seconds === "number") {
    where += `
      AND EXISTS (
        SELECT 1 FROM UNNEST(event_params) ep
        WHERE ep.key = "view_duration_seconds" AND ep.value.double_value <= @maxViewDuration
      )`;
    params.maxViewDuration = p.max_view_duration_seconds;
  }

  const limit = Math.max(1, Math.min(p.limit ?? 1000, 10000));
  const offset = p.offset ?? 0;

  const query = `
    SELECT
      event_timestamp,
      event_date,
      event_name,
      event_params,
      geo.city,
      geo.country,
      geo.region,
      app_info.version          AS app_version,
      app_info.id               AS app_package_name,
      app_info.firebase_app_id  AS firebase_app_id,
      device.operating_system   AS device_os,
      device.mobile_brand_name  AS device_brand,
      device.mobile_model_name  AS device_model,
      stream_id,

      -- User fields
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "user_name"     LIMIT 1) AS user_name,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "user_id"       LIMIT 1) AS user_id,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "device_id"     LIMIT 1) AS device_id,

      -- Merchant/Shop fields
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "merchant_id"   LIMIT 1) AS merchant_id,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "merchant_name" LIMIT 1) AS merchant_name,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "merchant_shopify_id" LIMIT 1) AS merchant_shopify_id,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "shop_id"       LIMIT 1) AS shop_id,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "shop_name"     LIMIT 1) AS shop_name,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "shop_tile_type" LIMIT 1) AS shop_tile_type,

      -- Product fields
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "product_id"    LIMIT 1) AS product_id,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "product_name"  LIMIT 1) AS product_name,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "product_price" LIMIT 1) AS product_price,

      -- Event type and screen
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "event_type"    LIMIT 1) AS event_type,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "screen_name"   LIMIT 1) AS screen_name,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "screen_time_seconds" LIMIT 1) AS screen_time_seconds,

      -- Search fields
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "search_query"  LIMIT 1) AS search_query,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "result_type"   LIMIT 1) AS result_type,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "is_from_search" LIMIT 1) AS is_from_search,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "total_results" LIMIT 1) AS total_results,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "products_count" LIMIT 1) AS products_count,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "shops_count"   LIMIT 1) AS shops_count,

      -- Position fields
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "position_in_results" LIMIT 1) AS position_in_results,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "position_in_list" LIMIT 1) AS position_in_list,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "tile_position" LIMIT 1) AS tile_position,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "product_position_in_tile" LIMIT 1) AS product_position_in_tile,

      -- View counts
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "product_view"  LIMIT 1) AS product_view,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "merchant_view" LIMIT 1) AS merchant_view,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "view_duration_seconds" LIMIT 1) AS view_duration_seconds,

      -- Deal fields
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "deal_id"       LIMIT 1) AS deal_id,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "deal_banner_url" LIMIT 1) AS deal_banner_url,

      -- Skipped items
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "skipped_count" LIMIT 1) AS skipped_count,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "skipped_items" LIMIT 1) AS skipped_items,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "skipped_shop_ids" LIMIT 1) AS skipped_shop_ids,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "skipped_product_ids" LIMIT 1) AS skipped_product_ids,

      -- Navigation fields
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "from_screen"   LIMIT 1) AS from_screen,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "to_screen"     LIMIT 1) AS to_screen,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "from_tab"      LIMIT 1) AS from_tab,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "to_tab"        LIMIT 1) AS to_tab,

      -- Filter change fields
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "filter_type"   LIMIT 1) AS filter_type,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "filter_value"  LIMIT 1) AS filter_value,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "previous_value" LIMIT 1) AS previous_value,

      -- Item metadata
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "item_id"       LIMIT 1) AS item_id,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "item_name"     LIMIT 1) AS item_name,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "item_type"     LIMIT 1) AS item_type,

      -- Platform
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "platform"      LIMIT 1) AS platform,

      -- Timestamp
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "timestamp"     LIMIT 1) AS timestamp,

      -- Reel/Video fields
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "video_url_id"  LIMIT 1) AS video_url_id,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "video_id"      LIMIT 1) AS video_id,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "video_likes_count" LIMIT 1) AS video_likes_count,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "video_views_count" LIMIT 1) AS video_views_count,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "is_liked"      LIMIT 1) AS is_liked,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "watch_duration_seconds" LIMIT 1) AS watch_duration_seconds,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "total_duration_seconds" LIMIT 1) AS total_duration_seconds,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "completion_rate" LIMIT 1) AS completion_rate,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "click_order"   LIMIT 1) AS click_order,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "watch_duration_before_click_seconds" LIMIT 1) AS watch_duration_before_click_seconds,

      -- Product Detail fields
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "current_product_id" LIMIT 1) AS current_product_id,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "clicked_product_id" LIMIT 1) AS clicked_product_id,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "clicked_product_name" LIMIT 1) AS clicked_product_name,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "clicked_product_price" LIMIT 1) AS clicked_product_price,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "clicked_product_shop_id" LIMIT 1) AS clicked_product_shop_id,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "variant_id"    LIMIT 1) AS variant_id,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "variant_name"  LIMIT 1) AS variant_name,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "variant_price" LIMIT 1) AS variant_price,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "variant_discounted_price" LIMIT 1) AS variant_discounted_price,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "action_type"   LIMIT 1) AS action_type,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "quantity"      LIMIT 1) AS quantity,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "shop_currency" LIMIT 1) AS shop_currency,

      -- Collection fields
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "collection_id" LIMIT 1) AS collection_id,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "collection_name" LIMIT 1) AS collection_name,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "from_collection_id" LIMIT 1) AS from_collection_id,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "from_collection_name" LIMIT 1) AS from_collection_name,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "to_collection_id" LIMIT 1) AS to_collection_id,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "to_collection_name" LIMIT 1) AS to_collection_name,

      -- Brand page fields
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "is_from_brand_page" LIMIT 1) AS is_from_brand_page,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "clicked_products_count" LIMIT 1) AS clicked_products_count,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "clicked_product_ids" LIMIT 1) AS clicked_product_ids,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "reels_count"   LIMIT 1) AS reels_count,

      -- Skipped products array fields
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "skipped_shops_count" LIMIT 1) AS skipped_shops_count,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "skipped_products_count" LIMIT 1) AS skipped_products_count,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "skipped_similar_count" LIMIT 1) AS skipped_similar_count,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "skipped_related_count" LIMIT 1) AS skipped_related_count,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "skipped_similar_product_ids" LIMIT 1) AS skipped_similar_product_ids,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "skipped_related_product_ids" LIMIT 1) AS skipped_related_product_ids,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "total_displayed" LIMIT 1) AS total_displayed,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "total_viewed" LIMIT 1) AS total_viewed,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "total_clicked" LIMIT 1) AS total_clicked,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "total_displayed_similar" LIMIT 1) AS total_displayed_similar,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "total_clicked_similar" LIMIT 1) AS total_clicked_similar,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "total_displayed_related" LIMIT 1) AS total_displayed_related,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "total_clicked_related" LIMIT 1) AS total_clicked_related,

      -- Tab count fields
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "all_count"     LIMIT 1) AS all_count,

      -- Current shop fields
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "current_shop_id" LIMIT 1) AS current_shop_id,
      (SELECT AS STRUCT ep.value FROM UNNEST(event_params) ep WHERE ep.key = "current_shop_name" LIMIT 1) AS current_shop_name
    FROM ${table}
    ${where}
    ORDER BY event_timestamp DESC
    LIMIT ${limit}
    OFFSET ${offset}
  `;

  try {
    const [rows] = await bigquery.query({
      query,
      params,
      location: GA_LOCATION, // e.g., "US"
    });

    // Remove null fields from the response
    const cleanedRows = rows.map((row: any) => {
      const cleaned: Record<string, any> = {};

      Object.keys(row).forEach((key) => {
        const value = row[key];

        // Only include non-null and non-undefined values
        if (value !== null && value !== undefined) {
          cleaned[key] = value;
        }
      });

      return cleaned;
    });

    return cleanedRows;
  } catch (error) {
    console.error("BigQuery fetch failed:", error);
    throw new Error("BigQuery fetch failed. Check server logs for details.");
  }
};
