import { poolPromise } from "../../config/db";
import sql from "mssql";
import { sendErrorEmail } from "../../services/emailService";

export const getNextShopRow = async (): Promise<{
  shop_id: number;
  shop_banner_url: string;
} | null> => {
  const pool = await poolPromise;
  const result = await pool.request().query(`
    SELECT TOP 1 shop_id, shop_banner_url
    FROM Shops
    WHERE shop_banner_type = 'video' AND shop_banner_url LIKE '%cdn%'
  `);
  return result.recordset[0] || null;
};

export const updateShopUrl = async (
  shopId: number,
  newUrl: string
): Promise<void> => {
  const pool = await poolPromise;
  await pool
    .request()
    .input("shopId", sql.Int, shopId)
    .input("newUrl", sql.NVarChar, newUrl).query(`
      UPDATE Shops
      SET shop_banner_url = @newUrl
      WHERE shop_id = @shopId
    `);
};

export const updateProductImageUrls = async (
  productId: number,
  lowUrl: string,
  averageUrl: string,
  highUrl: string
): Promise<void> => {
  const pool = await poolPromise;
  try {
    await pool
      .request()
      .input("productId", productId)
      .input("lowUrl", lowUrl)
      .input("highUrl", highUrl)
      .input("averageUrl", averageUrl).query(`
        UPDATE Product_Images
        SET product_image_url_low = @lowUrl,
            product_image_url_medium = @averageUrl,
            product_image_url_high = @highUrl
        WHERE product_image_id = @productId
      `);
  } catch (error: any) {
    sendErrorEmail("Error updating product image URLs:", error);

    console.error("Error updating product image URLs:", error);
  }
};

export const getAllProductImage = async () => {
  const pool = await poolPromise;
  const result = await pool.request().query(`
    SELECT * FROM Product_Images
   WHERE product_image_url_low IS NULL 
   AND product_image_url_medium IS NULL
  `);
  return result.recordset;
};

export const getVideoNextRow = async (): Promise<{
  video_id: number;
  video_url: string;
} | null> => {
  const pool = await poolPromise;
  const result = await pool.request().query(`
    SELECT TOP 1 video_id, video_url
    FROM Videos
    WHERE video_url LIKE '%cdn%' 
  `);
  return result.recordset[0] || null;
};

export const updateVideoUrl = async (
  videoId: number,
  newUrl: string
): Promise<void> => {
  const pool = await poolPromise;
  await pool
    .request()
    .input("videoId", sql.Int, videoId)
    .input("newUrl", sql.NVarChar, newUrl).query(`
      UPDATE Videos
      SET video_url = @newUrl
      WHERE video_id = @videoId
    `);
};

export const getNextProductRow = async (
  offset: number
): Promise<{
  product_id: number;
  product_image_url: string;
} | null> => {
  const pool = await poolPromise;
  const result = await pool.request().input("offset", offset).query(`
  SELECT product_id, product_image_url
  FROM Products
  WHERE product_image_url LIKE '%cdn%'
  ORDER BY product_id
  OFFSET @offset ROWS
  FETCH NEXT 1 ROWS ONLY
  `);
  return result.recordset[0] || null;
};
