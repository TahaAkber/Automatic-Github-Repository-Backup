import { poolPromise } from "../../config/db";
import { sendErrorEmail } from "../../services/emailService";
import { RecentView } from "../../types/RecentView";
import { getProductDetail, getUsingShopId } from "../products/productModel";
import { isHaveStories } from "../reelsAndStories/reelsAndStories";
import { getShopWithRatingUsingShopId } from "../shops/shopModel";

export const createRecentView = async ({
  user_id,
  recent_view_type,
  recent_view_product_id,
  recent_view_shop_id,
}: RecentView): Promise<void> => {
  const pool = await poolPromise;

  const query = `
      MERGE INTO Recent_View AS Target
      USING (SELECT @recent_view_user_id AS recent_view_user_id, 
                    @recent_view_type AS recent_view_type, 
                    @recent_view_product_id AS recent_view_product_id, 
                    @recent_view_shop_id AS recent_view_shop_id) AS Source
      ON Target.recent_view_user_id = Source.recent_view_user_id 
         AND Target.recent_view_type = Source.recent_view_type 
         AND Target.recent_view_product_id = Source.recent_view_product_id 
         AND Target.recent_view_shop_id = Source.recent_view_shop_id
      WHEN MATCHED THEN
          UPDATE SET updated_at = GETDATE()
      WHEN NOT MATCHED THEN
          INSERT (recent_view_user_id, recent_view_type, recent_view_product_id, recent_view_shop_id, created_at, updated_at)
          VALUES (@recent_view_user_id, @recent_view_type, @recent_view_product_id, @recent_view_shop_id, GETDATE(), GETDATE());
    `;

  try {
    await pool
      .request()
      .input("recent_view_user_id", user_id)
      .input("recent_view_type", recent_view_type)
      .input("recent_view_product_id", recent_view_product_id)
      .input("recent_view_shop_id", recent_view_shop_id)
      .query(query);
  } catch (error: any) {
    sendErrorEmail("Error in createRecentView:", error);

    console.error("Error in createRecentView:", error.message);
    throw new Error("Error creating or updating recent view.");
  }
};

export const getRecentView = async (
  user_id: number,
  local_recent_view: any[],
  page: number,
  pageSize: number
): Promise<any[]> => {
  const pool = await poolPromise;
  let query = "";

  // Logged-in: fetch from Recent_View table
  if (user_id) {
    query = `
     SELECT 
  rv.*,
  p.*,
  s.*,
  pi.product_image_url_low,
  pi.product_image_url_medium
FROM Recent_View rv
LEFT JOIN Products p
  ON rv.recent_view_type = 'product'
 AND rv.recent_view_product_id = p.product_id
LEFT JOIN Shops s
  ON rv.recent_view_type = 'shop'
 AND rv.recent_view_shop_id = s.shop_id
OUTER APPLY (
  SELECT TOP 1
    i.product_image_url_low,
    i.product_image_url_medium
  FROM Product_Images i
  WHERE i.product_image_product_id = p.product_id
  ORDER BY i.product_image_id DESC   -- latest image; use ASC for first
) pi
WHERE rv.recent_view_user_id = @user_id
ORDER BY rv.updated_at DESC
OFFSET @offset ROWS FETCH NEXT @pageSize ROWS ONLY;
    `;
  }

  // Offline: simulate recent views using local_recent_view array
  else if (Array.isArray(local_recent_view) && local_recent_view.length > 0) {
    const unionRows = local_recent_view
      .map((item) => {
        const type = item.recent_view_type;
        const productId =
          type === "product" ? Number(item.recent_view_product_id) : "NULL";
        const shopId =
          type === "shop" ? Number(item.recent_view_shop_id) : "NULL";

        return `SELECT '${type}' AS recent_view_type, ${productId} AS recent_view_product_id, ${shopId} AS recent_view_shop_id, GETDATE() AS updated_at`;
      })
      .join(" UNION ALL ");

    query = `
      WITH Recent_Local_View AS (
        ${unionRows}
      )
      SELECT 
        rv.*,
        p.*,
        s.*
      FROM 
        Recent_Local_View rv
      LEFT JOIN 
        Products p ON rv.recent_view_type = 'product' AND rv.recent_view_product_id = p.product_id
      LEFT JOIN 
        Shops s ON rv.recent_view_type = 'shop' AND rv.recent_view_shop_id = s.shop_id
      ORDER BY 
        rv.updated_at DESC
      OFFSET @offset ROWS
      FETCH NEXT @pageSize ROWS ONLY;
    `;
  }

  // No user_id and no local view => return empty
  else {
    return [];
  }

  try {
    const result = await pool
      .request()
      .input("user_id", user_id || 0)
      .input("offset", (page - 1) * pageSize)
      .input("pageSize", pageSize)
      .query(query);

    const records = result.recordset;

    // Enrich results with has_stories for shop views
    const enrichedResults = await Promise.all(
      records.map(async (item) => {
        if (item.recent_view_type === "shop" && item.shop_id) {
          const hasStories = await isHaveStories(item.shop_id);
          return { ...item, shopHaveStory: !!hasStories };
        }
        return item;
      })
    );

    return enrichedResults;
  } catch (error: any) {
    sendErrorEmail("Error in getRecentView:", error);

    console.error("Error in getRecentView:", error.message);
    throw new Error("Error fetching recent views.");
  }
};

export const getUserRecentViewedCount = async (user_id: number) => {
  const pool = await poolPromise;
  const query = `
    SELECT COUNT(*) as count
    FROM Recent_View
    WHERE recent_view_user_id = ${user_id}
  `;
  const result = await pool.request().query(query);
  return result.recordset[0].count;
};
