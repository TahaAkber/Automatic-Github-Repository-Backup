import { poolPromise } from "../../config/db";

export const ManageUserWishlist = async (
  userId: number,
  productId: number,
  isAdded: boolean,
  createdAt: string
) => {
  const pool = await poolPromise;

  console.log("createdAt", createdAt);

  const result = await pool
    .request()
    .input("wishlist_user_id", userId)
    .input("wishlist_product_id", productId)
    .input("is_added", isAdded)
    .input("created_at", createdAt)
    .execute("ManageUserWishlist");

  return result.recordset[0]?.response_message;
};

export const userWishlistLogs = async (
  userId: number,
  wishlist_local?: {
    wishlist_product_id: number;
    created_at: string;
  }[]
) => {
  const pool = await poolPromise;

  if (wishlist_local && wishlist_local.length) {
    const sortedLocal = [...wishlist_local].sort(
      (a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
    );

    const localItem = sortedLocal.map((item, index) => ({
      wishlist_id: index,
      wishlist_product_id: item.wishlist_product_id,
      created_at: item.created_at
    }));

    return localItem;
  }

  const query = `
      SELECT *
      FROM User_Wishlist
      WHERE wishlist_user_id = @userId
      ORDER BY created_at DESC;   
  `;

  const result = await pool.request().input("userId", userId).query(query);

  return result.recordset;
};
