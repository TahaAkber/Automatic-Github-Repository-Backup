import { poolPromise } from "../../config/db";
import {
  fetchShopifyProductVariant,
  getProductDescriptiveHtmlByShopifyId,
} from "../../graphql/product/productQueries";
import { Product } from "../../types/Product";
import {
  getShopFollowingStatus,
  getShopReviewsStats,
} from "../../functions/shop";
import { reels, reelThumbnail } from "../../constant/constant";
import { getShopAccessCreds, getShopFilter } from "../shops/shopModel";
import { fetchAllProducts } from "../../services/productService";
import { getShopWithRatingUsingShopId } from "../shops/shopModel";
import { getShopReviews } from "../reviews/reviewsModel";
import { isShopHaveStories } from "../../services/reelsAndStories";
import { getProductReviewS } from "../../services/reviews";
import { sendErrorEmail } from "../../services/emailService";

export const createProduct = async (product: Product): Promise<void> => {
  const pool = await poolPromise;
  const { product_name, product_quantity, product_shopify_category } = product;

  const query = `
    INSERT INTO Products (product_name, product_quantity, product_shopify_category)
    VALUES (@product_name, @product_quantity, @product_shopify_category);
  `;

  pool
    .request()
    .input("product_name", product_name)
    .input("product_quantity", product_quantity)
    .input("product_shopify_category", product_shopify_category)
    .query(query);
};

export const getProductFiltersUsingShopId = async (
  shop_id: number,
  searchKeyword?: string,
  minRating?: number
) => {
  const pool = await poolPromise;
  const request = pool.request();

  let productFilterquery = `SELECT DISTINCT product_custom_category
  FROM Products  
  WHERE product_is_active = 1`;

  if (shop_id) {
    productFilterquery += ` AND product_shop_id = @shop_id`;
    request.input("shop_id", shop_id);
  } else {
    throw new Error("shop_id is required");
  }

  if (searchKeyword && searchKeyword.trim() !== "") {
    productFilterquery += ` AND (product_name LIKE @search OR product_description LIKE @search)`;
    request.input("search", `%${searchKeyword.trim()}%`);
  }

  if (minRating !== undefined) {
    productFilterquery += ` AND product_rating >= @minRating`;

    request.input("minRating", minRating);
  }

  const productfilterresult = await request.query(productFilterquery);
  const productFilter = productfilterresult.recordset || []; // ProductFilter

  const productCategories = productFilter.map(
    (item) => item.product_custom_category
  );
  return productCategories;
};

export const getProducts = async (
  shop_id?: number,
  product_length?: number,
  offset?: number,
  reel?: boolean,
  searchKeyword?: string,
  minRating?: number,
  minPrice?: number,
  maxPrice?: number,
  sortPrice?: "asc" | "desc",
  createdAt?: "asc" | "desc",
  product_id?: number
): Promise<Product[]> => {
  const pool = await poolPromise;
  const request = pool.request();

  if (!shop_id) throw new Error("shop_id is required");
  request.input("shop_id", shop_id);

  let query = `
    SELECT
      p.*,
      pi.product_image_url_low,
      pi.product_image_url_medium,
      s.shop_currency AS product_currency
    FROM Products p
    -- Join Images
    OUTER APPLY (
      SELECT TOP 1
        i.product_image_url_low,
        i.product_image_url_medium
      FROM Product_Images i
      WHERE i.product_image_product_id = p.product_id
      ORDER BY i.product_image_position ASC
    ) pi
    LEFT JOIN Shops s ON s.shop_id = p.product_shop_id
    WHERE p.product_is_active = 1
      AND p.product_shop_id = @shop_id
  `;

  if (product_id) {
    query += ` AND p.product_id <> @product_id`;
    request.input("product_id", product_id);
  }

  if (searchKeyword && searchKeyword.trim()) {
    query += ` AND (p.product_name LIKE @search OR p.product_description LIKE @search)`;
    request.input("search", `%${searchKeyword.trim()}%`);
  }

  if (minRating !== undefined) {
    query += ` AND p.product_rating >= @minRating`;
    request.input("minRating", minRating);
  }

  let orderBy = "ORDER BY p.created_at DESC"; // default

  if (sortPrice) {
    orderBy = `ORDER BY p.product_price ${sortPrice.toUpperCase()}`;
  }

  if (createdAt) {
    orderBy = `ORDER BY p.created_at ${createdAt.toUpperCase()}`;
  }

  query += ` ${orderBy}`;

  if (product_length) {
    const offsetPage = ((offset || 1) - 1) * product_length;

    query += ` OFFSET @offset ROWS FETCH NEXT @pageSize ROWS ONLY`;
    request.input("offset", offsetPage);
    request.input("pageSize", product_length);
  }

  const result = await request.query(query);
  const records = result.recordset || [];

  // 7. Post-Processing (Fetching Variants)
  // We no longer need to filter by price here, just map the data
  const productByVariant = await Promise.all(
    records.map(async (item, index) => {
      // You can remove minPrice/maxPrice args here since SQL handled it
      const productVariant = await getUsingProductVariantId(
        item.product_id
        // minPrice, maxPrice -> Optional: keep if you want to filter specific variants inside the product object
      );

      if (productVariant.length === 0) return null;

      item.product_review = await getProductReview(item.product_id);

      if (reel) {
        item.product_reel_url = reels[index] || reels[0];
        item.product_reel_thumbnail_url = reelThumbnail[index] || reelThumbnail[0];
      }

      return {
        ...item,
        product_variant: productVariant,
      };
    })
  );

  return productByVariant.filter((item) => item !== null);
};


export const getVariantById = async (variant_id?: number): Promise<any> => {
  if (!variant_id || !Number.isFinite(Number(variant_id))) {
    return null;
  }
  const pool = await poolPromise;
  let query = `
  SELECT *
    FROM Product_Variants WHERE variant_id = ${variant_id}
  `;

  try {
    const variantResult = await pool.request().query(query);

    const variantRecord = variantResult.recordset?.[0] || {};
    // console.log("variantRecord", variantRecord);
    let productQuery = `
      SELECT
          p.*,
          s.shop_currency AS product_currency
      FROM Products p
      JOIN Shops s
          ON s.shop_id = p.product_shop_id
      WHERE p.product_id = ${variantRecord?.variant_product_id}
      ORDER BY p.created_at ASC;
    `;

    const ProductResult = await pool.request().query(productQuery);

    const productRecord = ProductResult.recordset?.[0] || {};

    // const shopResult = await getShopAccessCreds(productRecord?.product_shop_id);

    // const shopifyVariantData = await fetchShopifyProductVariant(
    //   variantRecord?.variant_shopify_id,
    //   shopResult.shop_domain,
    //   shopResult.shop_access_token
    // );

    const imageNodes = [
      {
        preview: {
          image: {
            url:
              variantRecord?.variant_image_url ||
              "https://cdn.shopify.com/s/files/1/0595/2379/2944/files/img_not_found_cercle.jpg?v=1757333158",
          },
        },
      },
    ];

    const optionsArray = [
      variantRecord.variant_option_key_one &&
      variantRecord.variant_option_value_one
        ? {
            name: variantRecord.variant_option_key_one,
            value: variantRecord.variant_option_value_one,
          }
        : null,
      variantRecord.variant_option_key_two &&
      variantRecord.variant_option_value_two
        ? {
            name: variantRecord.variant_option_key_two,
            value: variantRecord.variant_option_value_two,
          }
        : null,
      variantRecord.variant_option_key_third &&
      variantRecord.variant_option_value_third
        ? {
            name: variantRecord.variant_option_key_third,
            value: variantRecord.variant_option_value_third,
          }
        : null,
    ].filter(Boolean);

    console.log("optionsArray", optionsArray);

    const data = {
      product: productRecord,
      variant: {
        ...variantRecord,
        images: imageNodes,
        selected_options: optionsArray,
      },
    };

    return data;
  } catch (error: any) {
    sendErrorEmail("Error fetching product variants", error);

    throw new Error(
      "Error fetching product variants " + error.message + " " + variant_id
    );
  }
};

// export const getCategoryProductsCount = async (
//   shop_id?: number,
//   category_name?: string,
//   collectionType_id?: number,
//   collection_id?: number
// ) => {
//   const pool = await poolPromise;

//   let query = "";
//   if (shop_id) {
//     query = `
//     SELECT COUNT(*) as count
//     FROM Products WHERE product_shop_id = @shop_id AND product_custom_category = @category_name
//   `;
//   } else if (collection_id) {
//     query = `SELECT COUNT(*) as count FROM Collection_Products c JOIN  Products p ON c.collection_local_product_id = p.product_id WHERE collection_id =  @collection_id AND p.product_custom_category = @category_name; `;
//   } else if (collectionType_id) {
//     const trendingResult = await pool
//       .request()
//       .input("trendingId", collectionType_id).query(`
//             SELECT trending_name
//             FROM Trending_Collections
//             WHERE trending_expiration_date > GETDATE()
//               AND trending_id = @trendingId
//           `);

//     if (trendingResult.recordset.length === 0)
//       return {
//         products: [],
//         totalProducts: 0,
//         totalPages: 0,
//       };

//     const trendingName = trendingResult.recordset[0].trending_name;

//     const collectionResult = await pool
//       .request()
//       .input("collectionName", trendingName).query(`
//             SELECT collection_id
//             FROM Collections
//             WHERE collection_name = @collectionName
//           `);

//     if (collectionResult.recordset.length === 0)
//       return {
//         products: [],
//         totalProducts: 0,
//         totalPages: 0,
//       };

//     const collectionIds = collectionResult.recordset.map(
//       (r) => r.collection_id
//     );

//     const productRequest = pool.request();
//     collectionIds.forEach((id, idx) => productRequest.input(`cid${idx}`, id));
//     const collectionIdParams = collectionIds
//       .map((_, idx) => `@cid${idx}`)
//       .join(",");

//     const productIdsResult = await productRequest.query(`
//           SELECT DISTINCT collection_local_product_id
//           FROM Collection_Products
//           WHERE collection_id IN (${collectionIdParams})
//         `);

//     const productIds = productIdsResult.recordset.map(
//       (r) => r.collection_local_product_id
//     );
//     const request = pool.request().input("category_name", category_name);
//     productIds.forEach((id, idx) => request.input(`id${idx}`, id));
//     const idParams = productIds.map((_, idx) => `@id${idx}`).join(",");
//     let query = `
//            SELECT COUNT(*) AS count
//     FROM Products p
//     WHERE p.product_id IN (${idParams})
//     AND p.product_is_active = 1
//     AND p.product_custom_category = @category_name
//         `;
//     console.log("category_name", category_name);
//     const productResult = await request.query(query);
//     const rawProductCategories = productResult.recordset || [];
//     return rawProductCategories;
//   }

//   const result = await pool
//     .request()
//     .input("shop_id", shop_id)
//     .input("category_name", category_name)
//     .input("collection_id", collection_id)
//     .input("bol", collectionType_id)
//     .query(query);
//   return result.recordset[0].count;
// };
export const getCategoryProductsCount = async (
  shop_id?: number,
  category_name?: string,
  collectionType_id?: number, // trending_id
  collection_id?: number
): Promise<number> => {
  if (!category_name) return 0; // required for all cases

  const pool = await poolPromise;

  // CASE 1: By shop
  if (shop_id) {
    const res = await pool
      .request()
      .input("shop_id", shop_id)
      .input("category_name", category_name).query(`
        SELECT COUNT(*) AS count
        FROM Products
        WHERE product_shop_id = @shop_id
          AND product_custom_category = @category_name
          AND product_is_active = 1
      `);
    return res.recordset[0]?.count ?? 0;
  }

  // CASE 2: By explicit collection_id
  if (collection_id) {
    const res = await pool
      .request()
      .input("collection_id", collection_id)
      .input("category_name", category_name).query(`
        SELECT COUNT(DISTINCT p.product_id) AS count
        FROM Collection_Products AS cp
        JOIN Products AS p
          ON cp.collection_local_product_id = p.product_id
        WHERE cp.collection_id = @collection_id
          AND p.product_custom_category = @category_name
          AND p.product_is_active = 1
      `);
    return res.recordset[0]?.count ?? 0;
  }

  // CASE 3: By trending (collectionType_id → trending_id)
  if (collectionType_id) {
    // validate trending and get its name
    const trending = await pool.request().input("trendingId", collectionType_id)
      .query(`
        SELECT trending_name
        FROM Trending_Collections
        WHERE trending_id = @trendingId 
        AND trending_expiration_date > GETDATE() AND trending_is_active = 1
      `);

    if (!trending.recordset.length) return 0;

    const trendingName = trending.recordset[0].trending_name as string;

    // Count products that belong to ANY collection with this trending_name
    const res = await pool
      .request()
      .input("trending_name", trendingName)
      .input("category_name", category_name).query(`
        SELECT COUNT(DISTINCT p.product_id) AS count
        FROM Collection_Products AS cp
        JOIN Products AS p
          ON cp.collection_local_product_id = p.product_id
        JOIN Collections AS c
          ON c.collection_id = cp.collection_id
        WHERE c.collection_name = @trending_name
          AND p.product_custom_category = @category_name
          AND p.product_is_active = 1
      `);

    return res.recordset[0]?.count ?? 0;
  }

  // No selector provided → nothing to count
  return 0;
};
export const getFilterProducts = async (
  page: number,
  pageSize: number,
  category_name?: string,
  shop_id?: number,
  collectionType_id?: number,
  collection_id?: number
) => {
  const pool = await poolPromise;
  const offset = (page - 1) * pageSize;
  let query = "";

  if (shop_id && category_name) {
    query = `
    SELECT 
        p.*,
        pv.*,
        pi.product_image_url_low,
        pi.product_image_url_medium,
        s.shop_currency AS product_currency
    FROM Products p
    JOIN Product_Variants pv 
        ON pv.variant_product_id = p.product_id
        AND pv.variant_id = (
            SELECT MIN(variant_id) 
            FROM Product_Variants 
            WHERE variant_product_id = p.product_id
        )
    OUTER APPLY (
        SELECT TOP 1 
            product_image_url_low,
            product_image_url_medium
        FROM Product_Images pi
        WHERE pi.product_image_product_id = p.product_id
        ORDER BY pi.product_image_position ASC

    ) pi
    LEFT JOIN Shops s ON s.shop_id = p.product_shop_id
    WHERE p.product_shop_id = @shop_id
      AND p.product_custom_category = @category_name
    ORDER BY p.created_date DESC
      OFFSET @offset ROWS FETCH NEXT @pageSize ROWS ONLY;
    `;
  } else if (collection_id && category_name) {
    query = `
      SELECT
        c.collection_id,
        p.*,
        pv.*,
        pi.product_image_url_low,
        pi.product_image_url_medium,
        s.shop_currency AS product_currency
      FROM Collection_Products c
      JOIN Products p
        ON c.collection_local_product_id = p.product_id
      JOIN Product_Variants pv
        ON pv.variant_product_id = p.product_id
        AND pv.variant_id = (
            SELECT MIN(variant_id)
            FROM Product_Variants
            WHERE variant_product_id = p.product_id
        )
      OUTER APPLY (
        SELECT TOP 1
          product_image_url_low,
          product_image_url_medium
        FROM Product_Images i
        WHERE i.product_image_product_id = p.product_id
        ORDER BY pi.product_image_position ASC
      ) pi
      LEFT JOIN Shops s ON s.shop_id = p.product_shop_id
      WHERE c.collection_id = @collection_id
        AND p.product_custom_category = @category_name
      ORDER BY p.created_date DESC
      OFFSET @offset ROWS FETCH NEXT @pageSize ROWS ONLY;
    `;
  } else if (collectionType_id) {
    console.log("collectionType_id", collectionType_id);
    const trendingResult = await pool
      .request()
      .input("trendingId", collectionType_id).query(`
            SELECT trending_name
            FROM Trending_Collections
            WHERE trending_expiration_date > GETDATE()
            AND trending_id = @trendingId AND trending_is_active = 1
          `);

    if (trendingResult.recordset.length === 0)
      return {
        products: [],
        totalProducts: 0,
        totalPages: 0,
      };

    const trendingName = trendingResult.recordset[0].trending_name;

    const collectionResult = await pool
      .request()
      .input("collectionName", trendingName).query(`
            SELECT collection_id
            FROM Collections
            WHERE collection_name = @collectionName
          `);

    if (collectionResult.recordset.length === 0)
      return {
        products: [],
        totalProducts: 0,
        totalPages: 0,
      };

    const collectionIds = collectionResult.recordset.map(
      (r) => r.collection_id
    );

    const productRequest = pool.request();
    collectionIds.forEach((id, idx) => productRequest.input(`cid${idx}`, id));
    const collectionIdParams = collectionIds
      .map((_, idx) => `@cid${idx}`)
      .join(",");

    const productIdsResult = await productRequest.query(`
          SELECT DISTINCT collection_local_product_id
          FROM Collection_Products
          WHERE collection_id IN (${collectionIdParams})
        `);

    const productIds = productIdsResult.recordset.map(
      (r) => r.collection_local_product_id
    );
    const request = pool.request().input("category_name", category_name);
    productIds.forEach((id, idx) => request.input(`id${idx}`, id));
    const idParams = productIds.map((_, idx) => `@id${idx}`).join(",");
    console.log("idparams", idParams);
    let query = `
      SELECT
        p.*,
        s.shop_currency AS product_currency,
        pv.*,
        pi.product_image_url_low,
        pi.product_image_url_medium
      FROM Products p
      JOIN Product_Variants pv
        ON pv.variant_product_id = p.product_id
        AND pv.variant_id = (
          SELECT MIN(variant_id)
          FROM Product_Variants
          WHERE variant_product_id = p.product_id
        )
      JOIN Shops s
        ON s.shop_id = p.product_shop_id
      OUTER APPLY (
        SELECT TOP 1
          product_image_url_low,
          product_image_url_medium
        FROM Product_Images i
        WHERE i.product_image_product_id = p.product_id
        ORDER BY pi.product_image_position ASC
 
      ) pi
      WHERE p.product_id IN (${idParams})
        AND p.product_is_active = 1
        AND p.product_custom_category = @category_name
      ORDER BY p.created_date DESC
      OFFSET @offset ROWS FETCH NEXT @pageSize ROWS ONLY;
    `;
    const productResult = await request
      .input("offset", offset)
      .input("pageSize", pageSize)
      .query(query);
    console.log("productresult", productResult.recordset);
    const rawProductCategories = productResult.recordset || [];
    return rawProductCategories;
  }

  const result = await pool
    .request()
    .input("shop_id", shop_id)
    .input("category_name", category_name)
    .input("collection_id", collection_id)
    .input("offset", offset)
    .input("pageSize", pageSize)
    .query(query);
  return result.recordset;
};

export const fetchCustomProductCategories = async (
  shop_id?: number,
  collection_id?: number,
  collectionType_id?: number
) => {
  let query;
  const pool = await poolPromise;
  if (shop_id) {
    query = `SELECT
    DISTINCT(p.product_custom_category)
    FROM Products p
    WHERE p.product_shop_id = @shop_id`;

    const result = await pool.request().input("shop_id", shop_id).query(query);
    return result.recordset.map((r) => r.product_custom_category);
  } else if (collection_id) {
    const query = `SELECT DISTINCT(p.product_custom_category) 
    FROM Collection_Products c
    JOIN Products p ON p.product_id = c.collection_local_product_id
    WHERE c.collection_id = @collection_id`;
    const result = await pool
      .request()
      .input("collection_id", collection_id)
      .query(query);
    return result.recordset.map((r) => r.product_custom_category);
  } else if (collectionType_id) {
    const trendingResult = await pool
      .request()
      .input("trendingId", collectionType_id).query(`
            SELECT trending_name
            FROM Trending_Collections
            WHERE trending_expiration_date > GETDATE()
            AND trending_id = @trendingId AND trending_is_active = 1
          `);

    if (trendingResult.recordset.length === 0) return;

    const trendingName = trendingResult.recordset[0].trending_name;

    const collectionResult = await pool
      .request()
      .input("collectionName", trendingName).query(`
            SELECT collection_id
            FROM Collections
            WHERE collection_name = @collectionName
          `);

    if (collectionResult.recordset.length === 0) return;
    const collectionIds = collectionResult.recordset.map(
      (r) => r.collection_id
    );

    const productRequest = pool.request();
    collectionIds.forEach((id, idx) => productRequest.input(`cid${idx}`, id));
    const collectionIdParams = collectionIds
      .map((_, idx) => `@cid${idx}`)
      .join(",");

    const productIdsResult = await productRequest.query(`
          SELECT DISTINCT collection_local_product_id
          FROM Collection_Products
          WHERE collection_id IN (${collectionIdParams})
        `);

    const productIds = productIdsResult.recordset.map(
      (r) => r.collection_local_product_id
    );
    const request = pool.request();
    productIds.forEach((id, idx) => request.input(`id${idx}`, id));
    const idParams = productIds.map((_, idx) => `@id${idx}`).join(",");
    let query = `
          SELECT DISTINCT p.product_custom_category
          FROM Products p
          WHERE p.product_id IN (${idParams}) AND product_is_active = 1
        `;
    const productResult = await request.query(query);
    const rawProductCategories = productResult.recordset || [];

    return rawProductCategories.map((item) => item.product_custom_category);
  }
};

export const getProductDetail = async (
  product_id?: number,
  user_id?: number
): Promise<Record<string, any>> => {
  const pool = await poolPromise;
  let query = `
    SELECT 
        p.*,
        s.shop_currency AS product_currency
    FROM Products p
    LEFT JOIN Shops s ON s.shop_id = p.product_shop_id
    WHERE p.product_id = ${product_id};
  `;

  try {
    const result = await pool.request().query(query);
    const productDetail = result.recordset[0];
    const productImages = await getProductImages(product_id || 0);

    if (productImages) {
      productDetail.product_images = productImages;
    }
    const productVariant = await getUsingProductVariantId(
      productDetail.product_id
    );

    const getShopById = await getShopWithRatingUsingShopId(
      productDetail?.product_shop_id,
      user_id
    );

    const productVariantsWithImages = await Promise.all(
      productVariant.map(async (item) => {
        const shopifyVariantData = await fetchShopifyProductVariant(
          item.variant_shopify_id,
          getShopById.shop_domain,
          getShopById.shop_access_token
        );
        return {
          ...item,
          images: shopifyVariantData?.media?.nodes,
          selected_options: shopifyVariantData?.selectedOptions,
        };
      })
    );

    const data = {
      product_detail: productDetail,
      product_variant: productVariantsWithImages,
      shop_detail: getShopById,
    };

    return data;
  } catch (error: any) {
    sendErrorEmail("Error fetching product details", error);

    throw new Error("Error fetching product details" + error.message);
  }
};

export const getSpecificProduct = async (product_id?: number): Promise<any> => {
  const pool = await poolPromise;

  let query = `
    SELECT
      p.*,
      s.shop_currency AS product_currency,
      pi.product_image_url_low,
      pi.product_image_url_medium
    FROM Products p
    JOIN Shops s
      ON s.shop_id = p.product_shop_id
    OUTER APPLY (
      SELECT TOP 1
        i.product_image_url_low,
        i.product_image_url_medium
      FROM Product_Images i
      WHERE i.product_image_product_id = p.product_id
      ORDER BY i.product_image_id DESC
    ) pi
    WHERE p.product_id = ${product_id}
      AND p.product_is_active = 1;
  `;

  // Execute the query
  const result = await pool.request().query(query);

  // If product exists, modify the response to include product_variant
  if (result.recordset.length > 0) {
    const variants = await getUsingProductVariantId(product_id || 0);
    return { ...result.recordset[0], product_variant: variants };
  }

  return false; // Return false if product not found
};

export const getProductVariants = async (shopifyVariantId: string) => {
  const pool = await poolPromise;
  const query = `SELECT * FROM Product_Variants WHERE variant_shopify_id = '${shopifyVariantId}'`;

  const result = await pool.request().query(query);
  return result.recordset;
};

export const getUsingShopifyVariantInventoryId = async (
  variant_inventory_id: string
) => {
  console.log("variant_inventory_id", variant_inventory_id);
  try {
    const pool = await poolPromise;
    const query = `
      SELECT pv.* ,p.*
      FROM Product_Variants pv
      JOIN Products p 
      ON pv.variant_product_id = p.product_id
      WHERE pv.variant_inventory_id = @variant_inventory_id
      AND p.product_is_active = 1;
    `;

    const dbResp = await pool
      .request()
      .input("variant_inventory_id", variant_inventory_id)
      .query(query);

    if (dbResp.recordset.length === 0) {
      return []; // No active product variants found
    }

    // console.log("getUsingShopifyVariantInventoryId dbResp", dbResp);

    return dbResp.recordset; // Return the found product variant(s)
  } catch (error: any) {
    sendErrorEmail("Error fetching product variant from database:", error);

    console.error("Error fetching product variant from database:", error);
    throw new Error("Database query failed"); // Rethrow or handle the error as necessary
  }
};

export const getUsingProductVariantId = async (
  product_id: number,
  minPrice?: number,
  maxPrice?: number
) => {
  try {
    const pool = await poolPromise;

    let query = `
      SELECT pv.* 
      FROM Product_Variants pv
      JOIN Products p 
      ON pv.variant_product_id = p.product_id
      WHERE pv.variant_product_id = @product_id
      AND p.product_is_active = 1
	    AND pv.variant_is_active = 1
    `;

    if (minPrice !== undefined && maxPrice !== undefined) {
      query += ` AND pv.variant_price BETWEEN @minPrice AND @maxPrice`;
    }

    const dbResp = await pool
      .request()
      .input("product_id", product_id)
      .input("minPrice", minPrice)
      .input("maxPrice", maxPrice)
      .query(query);

    if (dbResp.recordset.length === 0) {
      return [];
    }

    return dbResp.recordset;
  } catch (error: any) {
    sendErrorEmail("Error fetching product variant from database:", error);

    console.error("Error fetching product variant from database:", error);
    throw new Error("Database query failed");
  }
};

export const updateProductVariantInventory = async (
  newInventory: number,
  variant_inventory_id: string
) => {
  try {
    const query = `UPDATE Product_Variants
      SET variant_quantity = @new_quantity,updated_at = GETDATE()
      FROM Product_Variants pv
      JOIN Products p ON pv.variant_product_id = p.product_id WHERE pv.variant_inventory_id = @variant_inventory_id AND p.product_is_active = 1;`;

    const pool = await poolPromise;
    const updatedProduct = await pool
      .request()
      .input("new_quantity", newInventory)
      .input("variant_inventory_id", variant_inventory_id)
      .query(query);

    // Check if any rows were affected by the update
    console.log("updatedProduct", updatedProduct);
    return updatedProduct.rowsAffected[0] > 0;
  } catch (error: any) {
    sendErrorEmail("Error updating product inventory:", error);

    console.error("Error updating product inventory:", error);
    throw new Error("Failed to update product inventory");
  }
};

export const getUsingShopId = async (shop_id: number, user_id?: number) => {
  try {
    const pool = await poolPromise;
    const query = `SELECT * FROM Shops WHERE shop_id = @shop_id`;

    const dbShopResp = await pool
      .request()
      .input("shop_id", shop_id)
      .query(query);

    if (shop_id) {
      shop_id;
    }

    dbShopResp.recordset[0].rating =
      (await getShopReviews(shop_id)).rating || 0;
    dbShopResp.recordset[0].filters = await getShopFilter(shop_id);
    const totalReviewsResponse = await getShopReviews(shop_id);
    dbShopResp.recordset[0].total_reviews =
      totalReviewsResponse?.total_reviews || 0;
    dbShopResp.recordset[0].shopHaveStory = await isShopHaveStories(shop_id);

    if (user_id) {
      const followingStatus = await getShopFollowingStatus(shop_id, user_id);
      dbShopResp.recordset[0].shop_following = followingStatus;

      console.log("followingStatus", followingStatus);
    }

    return dbShopResp.recordset[0];
  } catch (error: any) {
    sendErrorEmail("Error fetching shop from database:", error);

    console.error("Error fetching shop from database:", error);
    throw new Error("Database query failed"); // Rethrow or handle the error as necessary
  }
};

export const getShopByIdSortingCategories = async (
  shop_id: number,
  user_id?: number
) => {
  try {
    const pool = await poolPromise;
    const query = `
      DECLARE @category INT;

      SELECT @category = shop_category
      FROM Shops
      WHERE shop_id = @shop_id;

      SELECT TOP 2 *
      FROM Shops s
      WHERE
          s.shop_is_active = 1
          AND s.shop_delisted = 0
          AND s.shop_category = @category
          AND s.shop_id <> @shop_id
      ORDER BY NEWID();`;

    const dbShopResp = await pool
      .request()
      .input("shop_id", shop_id)
      .query(query);

    if (dbShopResp.recordset.length === 0) {
      return []; // If no related shops are found, return an empty array
    }

    // Process all related shops
    const modifiedData = await Promise.all(
      dbShopResp.recordset.map(async (shop) => {
        try {
          if (user_id) {
            const followingStatus = await getShopFollowingStatus(
              shop.shop_id,
              user_id
            );
            shop.shop_following = followingStatus;
          }

          const filters = await getShopFilter(shop.shop_id);
          shop.filters = filters;

          const rating = await getShopReviewsStats(shop.shop_id); // Get follow status

          const products = await fetchAllProducts(shop.shop_id, 5);
          shop.rating = rating;
          shop.products = products || [];

          return shop;
        } catch (error: any) {
          sendErrorEmail("Error processing shop data:", error);

          console.error("Error processing shop data:", error);
          return shop;
        }
      })
    );

    return modifiedData;
  } catch (error: any) {
    sendErrorEmail("Error fetching related shops from database:", error);

    console.error("Error fetching related shops from database:", error);
    throw new Error("Database query failed");
  }
};

export const getShopProductCount = async (
  shop_id: number,
  searchKeyword?: string,
  minRating?: number,
  minPrice?: number,
  maxPrice?: number,
  excludeProductId?: number // To match the "product_id" exclusion in fetch
): Promise<number> => {
  const pool = await poolPromise;
  const request = pool.request();

  // 1. We need the same base table alias 'p'
  let query = `
    SELECT COUNT(*) as count
    FROM Products p
  `;

  // 2. If Price filters are used, we MUST join/apply the variants table
  // just like we did in getProducts to calculate min/max price.
  if (minPrice !== undefined || maxPrice !== undefined) {
    query += `
      OUTER APPLY (
        SELECT 
            MIN(v.variant_price) as min_variant_price,
            MAX(v.variant_price) as max_variant_price
        FROM Product_Variants v
        WHERE v.variant_product_id = p.product_id
      ) price_info
    `;
  }

  // 3. Start WHERE clause
  query += ` WHERE p.product_is_active = 1 AND p.product_shop_id = @shop_id`;
  request.input("shop_id", shop_id);

  // 4. Mirror the Exclusion Logic
  if (excludeProductId) {
    query += ` AND p.product_id <> @excludeProductId`;
    request.input("excludeProductId", excludeProductId);
  }

  // 5. Mirror the Search Logic
  if (searchKeyword && searchKeyword.trim() !== "") {
    query += ` AND (p.product_name LIKE @search OR p.product_description LIKE @search)`;
    request.input("search", `%${searchKeyword.trim()}%`);
  }

  // 6. Mirror the Rating Logic
  if (minRating !== undefined) {
    query += ` AND p.product_rating >= @minRating`;
    request.input("minRating", minRating);
  }

  // 7. Mirror the Price Logic
  if (minPrice !== undefined) {
    query += ` AND price_info.max_variant_price >= @minPrice`;
    request.input("minPrice", minPrice);
  }
  if (maxPrice !== undefined) {
    query += ` AND price_info.min_variant_price <= @maxPrice`;
    request.input("maxPrice", maxPrice);
  }

  const result = await request.query(query);
  return result.recordset[0].count;
};

export const getProductReview = async (product_id: number) => {
  // const pool = await poolPromise;
  // const query = `
  //   SELECT COUNT(*) as count
  //   FROM Products
  //   WHERE product_is_active = 1 AND product_shop_id = @shop_id
  // `;
  // const result = await pool.request().input("shop_id", shop_id).query(query);
  return 4.5;
};

export const getproductbyshopifyId = async (
  product_id?: number
): Promise<any> => {
  const pool = await poolPromise;

  // SQL query to fetch product details
  let query = `SELECT * 
    FROM Products 
    WHERE product_shopify_id = 'gid://shopify/Product/${product_id}' 
    `;

  // Fetch product variants based on product_id

  // Execute the query
  const result = await pool.request().query(query);

  // If product exists, modify the response to include product_variant
  if (result.recordset.length > 0) {
    const dbProductId = result.recordset[0].product_id;

    const product_images = await getProductImages(dbProductId);

    const variants = await getUsingProductVariantId(dbProductId || 0);
    return {
      ...result.recordset[0],
      product_images,
      product_variant: variants,
    };
  }

  return false; // Return false if product not found
};

export const getProductsByShopifyIds = async (
  product_shopify_ids: string[],
  reel?: Boolean
): Promise<Product[]> => {
  const pool = await poolPromise;

  // Build the query to fetch products with the given product_shopify_id array
  let query = `
    SELECT * 
    FROM Products
    WHERE product_is_active = 1 
    AND product_shopify_id IN (${product_shopify_ids
      .map((id) => `'${id}'`)
      .join(", ")})
  `;

  // Execute the query
  const result = await pool.request().query(query);

  const validateRecord = result.recordset || [];

  // Fetch variants and reviews for each product
  const productByVariant = await Promise.all(
    validateRecord.map(async (item, index) => {
      const productVariant = await getUsingProductVariantId(item.product_id);
      item.product_review = await getProductReview(item.product_id);

      if (reel) {
        item.product_reel_url = reels[index] || reels[0];
        item.product_reel_thumbnail_url =
          reelThumbnail[index] || reelThumbnail[0];
      }

      return {
        ...item,
        product_variant: productVariant,
      };
    })
  );

  return productByVariant;
};

// Function to update the product name
export const updateProductName = async (
  productShopifyId: number,
  newProductName: string
) => {
  const pool = await poolPromise;
  const query = `
    UPDATE Products
    SET product_name = @newProductName, updated_at = GETDATE()
    WHERE product_shopify_id = @productId
  `;

  try {
    await pool
      .request()
      .input("productId", "gid://shopify/Product/" + productShopifyId)
      .input("newProductName", newProductName)
      .query(query);
  } catch (error: any) {
    sendErrorEmail("Error updating product name:", error);

    console.error("Error updating product name:", error);
    throw new Error("Failed to update product name.");
  }
};

// Function to update the product description
export const updateProductDescription = async (
  productShopifyId: number,
  newProductDescription: string,
  newProductDescriptionhtml: string
) => {
  const pool = await poolPromise;
  const query = `
  UPDATE Products
  SET 
    product_description = @newProductDescription,
    product_description_html = @newProductDescriptionhtml,
    updated_at = GETDATE()
  WHERE product_shopify_id = @productId
`;

  try {
    const sanitizedDescription = newProductDescription.replace(/<[^>]*>/g, "");
    await pool
      .request()
      .input("productId", "gid://shopify/Product/" + productShopifyId)
      .input("newProductDescription", sanitizedDescription)
      .input("newProductDescriptionhtml", newProductDescriptionhtml)
      .query(query);
  } catch (error: any) {
    sendErrorEmail("Error updating product description:", error);

    console.error("Error updating product description:", error);
    throw new Error("Failed to update product description.");
  }
};

// Function to update the product price
export const updateProductPrice = async (
  productId: number,
  variantId: number,
  newPrice: number
) => {
  const pool = await poolPromise;
  const query = `
    UPDATE Product_Variants
    SET price = @newPrice, updated_at = GETDATE()
    WHERE product_id = @productId AND variant_id = @variantId
  `;

  try {
    await pool
      .request()
      .input("productId", productId)
      .input("variantId", variantId)
      .input("newPrice", newPrice)
      .query(query);
  } catch (error: any) {
    sendErrorEmail("Error updating product price:", error);

    console.error("Error updating product price:", error);
    throw new Error("Failed to update product price.");
  }
};

// Function to update the product image URL
export const updateProductImageUrl = async (
  productId: number,
  newImageUrl: string
) => {
  const pool = await poolPromise;
  const query = `
    UPDATE Products
    SET product_image_url = @newImageUrl, updated_at = GETDATE()
    WHERE product_shopify_id = @productId
  `;

  try {
    await pool
      .request()
      .input("productId", "gid://shopify/Product/" + productId)
      .input("newImageUrl", newImageUrl)
      .query(query);
  } catch (error: any) {
    sendErrorEmail("Error updating product image URL:", error);

    console.error("Error updating product image URL:", error);
    throw new Error("Failed to update product image URL.");
  }
};

export const updateProductCustomCategory = async (
  productId: number,
  newCategoryValue: string,
  newCategoryId?: string
) => {
  const pool = await poolPromise;
  const query = `
    UPDATE Products
    SET product_custom_category = @newCat, product_custom_category_id = @newCatId, updated_at = GETDATE()
    WHERE product_shopify_id = @productId
  `;

  try {
    const request = await pool
      .request()
      .input("productId", "gid://shopify/Product/" + productId)
      .input("newCat", newCategoryValue)
      .input("newCatId", newCategoryId);

    request.query(query);
  } catch (error: any) {
    sendErrorEmail("Error updating custom category:", error);

    console.error("Error updating custom category:", error);
    throw new Error("Failed to update product image URL.");
  }
};

// Function to update the product active status
export const updateProductActiveStatus = async (
  productShopifyId: number,
  isActive: boolean
) => {
  const pool = await poolPromise;
  console.log("changed value", isActive);
  const query = `
    UPDATE Products
    SET product_is_active = @isActive, updated_at = GETDATE()
    WHERE product_shopify_id = @productId
  `;

  try {
    await pool
      .request()
      .input("productId", "gid://shopify/Product/" + productShopifyId)
      .input("isActive", isActive) // true or false
      .query(query);

    console.log(
      `Product active status updated to ${isActive ? "active" : "inactive"}`
    );
  } catch (error: any) {
    sendErrorEmail("Error updating product active status:", error);

    console.error("Error updating product active status:", error);
    throw new Error("Failed to update product active status.");
  }
};

export const getProductImages = async (productId: number) => {
  try {
    const pool = await poolPromise;
    const query = `SELECT * FROM Product_Images WHERE product_image_product_id = @productId ORDER BY product_image_position ASC`;

    const result = await pool
      .request()
      .input("productId", productId)
      .query(query);

    return result.recordset || [];
  } catch (error: any) {
    sendErrorEmail("getProductImages", error);

    return [];
  }
};

export const deleteProductImages = async (productId: number) => {
  const pool = await poolPromise;
  const query = `
    DELETE FROM Product_Images WHERE product_image_product_id = @productId`;

  try {
    const response = await pool
      .request()
      .input("productId", productId)
      .query(query);

    return response.rowsAffected.length > 0;
  } catch (error: any) {
    sendErrorEmail("Failed to delete product images", error);

    throw new Error("Failed to delete product images" + error.message);
  }
};

export const insertProductImage = async (
  productId: number,
  imageUrl: string,
  imagePosition: number
) => {
  try {
    const pool = await poolPromise;

    const query = `INSERT INTO Product_Images (product_image_url, product_image_product_id, created_at, product_image_position)
      VALUES (@imageUrl, @productId, GETDATE(), @imagePosition)`;

    const request = await pool
      .request()
      .input("imageUrl", imageUrl)
      .input("productId", productId)
      .input("imagePosition", imagePosition)
      .query(query);

    return request.rowsAffected.length > 0;
  } catch (error: any) {
    sendErrorEmail("Error inserting product image:", error);

    console.error("Error inserting product image:", error.message);
    throw new Error("Failed to insert product image");
  }
};

export const ProductRatingUpdate = async (product_id: number) => {
  const pool = await poolPromise;
  const request = pool.request();

  const productRating = await getProductReviewS(product_id, 0);

  request.input("product_id", product_id);
  request.input(
    "newRating",
    productRating?.averageRating ? productRating?.averageRating.toFixed(1) : 0
  );

  try {
    await request.query(
      `UPDATE Products SET product_rating = @newRating WHERE product_id = @product_id`
    );
    return true;
  } catch (error: any) {
    return false;
  }
};

export const getTileProducts = async (
  shop_id?: number,
  product_length?: number,
  offset?: number,
  reel?: Boolean
) => {
  const pool = await poolPromise;

  const query = `SELECT TOP ${product_length} *
FROM (
    SELECT *,
        ROW_NUMBER() OVER (
            PARTITION BY product_category
            ORDER BY 
                CASE WHEN fulfilled_count <= 1 THEN 0 ELSE 1 END DESC,
                fulfilled_count DESC,
                product_rating DESC
        ) AS rn
    FROM (
        SELECT 
            p.product_id,
            p.product_shop_id,
            CAST(p.product_name AS NVARCHAR(255)) AS product_name,
            CAST(p.product_custom_category AS NVARCHAR(255)) AS product_category,
            CAST(p.product_description AS NVARCHAR(MAX)) AS product_description,
            CAST(p.product_description_html AS NVARCHAR(MAX)) AS product_description_html,

            (
                SELECT TOP 1 CAST(pi.product_image_url AS NVARCHAR(MAX))
                FROM Product_Images pi
                WHERE pi.product_image_product_id = p.product_id
                ORDER BY pi.product_image_position ASC
            ) AS product_image_url,
            (
                SELECT TOP 1 CAST(pi.product_image_url_low AS NVARCHAR(MAX))
                FROM Product_Images pi
                WHERE pi.product_image_product_id = p.product_id
                ORDER BY pi.product_image_position ASC
            ) AS product_image_url_low,
            (
                SELECT TOP 1 CAST(pi.product_image_url_medium AS NVARCHAR(MAX))
                FROM Product_Images pi
                WHERE pi.product_image_product_id = p.product_id
                ORDER BY pi.product_image_position ASC
            ) AS product_image_url_medium,

            p.product_rating,
            p.created_at,
            s.shop_currency AS product_currency,
            COUNT(CASE WHEN oi.order_item_fulfillment_status = 'fulfilled' THEN 1 END) AS fulfilled_count
        FROM Products p
        LEFT JOIN Product_Variants v 
            ON v.variant_product_id = p.product_id
        LEFT JOIN Order_Items oi 
            ON oi.order_item_variant_id = v.variant_id
        LEFT JOIN Shops s 
            ON s.shop_id = p.product_shop_id
        WHERE 
            p.product_is_active = 1
            AND p.product_shop_id = @shop_id
        GROUP BY 
            p.product_id,
            p.product_shop_id,
            CAST(p.product_name AS NVARCHAR(255)),
            CAST(p.product_custom_category AS NVARCHAR(255)),
            CAST(p.product_description AS NVARCHAR(MAX)),
            CAST(p.product_description_html AS NVARCHAR(MAX)),
            p.product_rating,
            p.created_at,
            s.shop_currency
    ) AS ProductWithCounts
) AS RankedProducts
WHERE rn <= 4
ORDER BY fulfilled_count DESC, product_rating DESC;
  `;

  const result = await pool.request().input("shop_id", shop_id).query(query);
  const validateRecord = result.recordset || [];
  const productByVariant = await Promise.all(
    validateRecord.map(async (item, index) => {
      const productVariant = await getUsingProductVariantId(item.product_id);

      const filteredVariants = productVariant.filter(
        (variant) => variant.variant_quantity > 0
      );

      if (filteredVariants.length === 0) {
        return null;
      }

      item.product_review = await getProductReview(item.product_id);

      if (reel) {
        item.product_reel_url = reels[index] || reels[0];
        item.product_reel_thumbnail_url =
          reelThumbnail[index] || reelThumbnail[0];
      }

      return {
        ...item,
        product_variant: [filteredVariants[0]],
      };
    })
  );

  return productByVariant.filter((p) => p !== null);
};

export const productIsActive = async () => {
  const query = `
  SELECT 
    p.product_id,
    p.product_name,
    (
        SELECT variant_id, variant_quantity, updated_at
        FROM Product_Variants v
        WHERE v.variant_product_id = p.product_id
        FOR JSON PATH
    ) AS variants
  FROM Products p
  WHERE p.product_is_active = 1
    AND NOT EXISTS (
      SELECT 1 
      FROM Product_Variants v2
      WHERE v2.variant_product_id = p.product_id
        AND v2.variant_quantity > 0
    );
  `;
  const pool = await poolPromise;
  try {
    const Result = await pool.request().query(query);

    const resultQuantity = Result.recordset;

    const twoMonthsAgo = new Date();
    twoMonthsAgo.setMonth(twoMonthsAgo.getMonth() - 2);

    const filteredProducts = resultQuantity.filter((product) => {
      if (!product.variants) return true;

      let variants;
      try {
        variants = JSON.parse(product.variants);
      } catch (e) {
        console.error(
          `Invalid JSON in variants for product_id ${product.product_id}`
        );
        return false;
      }

      if (!Array.isArray(variants) || variants.length === 0) {
        return true;
      }

      const hasPositiveStock = variants.some((v) => v.variant_quantity > 0);
      if (hasPositiveStock) return false;

      const latestUpdatedAt = variants.reduce((latest, v) => {
        if (!v.updated_at) return latest;
        const date = new Date(v.updated_at);
        return isNaN(date.getTime()) ? latest : date > latest ? date : latest;
      }, new Date(0));

      return latestUpdatedAt <= twoMonthsAgo || latestUpdatedAt.getTime() === 0;
    });

    if (filteredProducts.length > 0) {
      for (const product of filteredProducts) {
        await pool.request().input("product_id", product.product_id).query(`
        UPDATE Products 
        SET product_is_active = 0, updated_at = GETDATE()
        WHERE product_id = @product_id;
        `);
      }
    }

    return {
      message: "Product active status updated",
      success: true,
    };
  } catch (error: any) {
    console.error("Error updating product active status:", error);
    throw new Error("Failed to update product active status.");
  }
};

export const getDefaultTitleVariantsForMultiVariantProducts = async () => {
  const pool = await poolPromise;

  try {
    const query = `
      SELECT pv.variant_id
      FROM Product_Variants pv
      WHERE pv.variant_name = 'Default Title'
        AND pv.variant_product_id IN (
          SELECT variant_product_id
          FROM Product_Variants
          GROUP BY variant_product_id
          HAVING COUNT(*) > 1
        )
        AND pv.variant_is_active = 1;
    `;

    const result = await pool.request().query(query);
    return result.recordset.map((row) => row.variant_id);
  } catch (error) {
    console.error("Error fetching variants with Default Title:", error);
    throw new Error(
      "Failed to fetch Default Title variants for multi-variant products"
    );
  }
};

export const markDefaultTitleVariantsInactive = async (
  variantIds: number[]
) => {
  const pool = await poolPromise;

  try {
    if (!variantIds || variantIds.length === 0) {
      return { updated: 0, message: "No variant IDs provided" };
    }

    // Create parameterized list
    const paramNames = variantIds.map((_, index) => `@id${index}`).join(", ");

    const query = `
      UPDATE Product_Variants
      SET variant_is_active = 0, updated_at = GETDATE()
      WHERE variant_id IN (${paramNames});
    `;

    const request = pool.request();

    variantIds.forEach((id, index) => {
      request.input(`id${index}`, id);
    });

    const result = await request.query(query);

    return {
      updated: result.rowsAffected[0],
      message: `${result.rowsAffected[0]} variants marked as inactive`,
    };
  } catch (error) {
    console.error("Error marking variants inactive:", error);
    throw new Error("Failed to mark Default Title variants inactive");
  }
};
