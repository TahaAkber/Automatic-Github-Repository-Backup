import { DateTime, Float, Int } from "mssql";
import { poolPromise } from "../../config/db";
import { sendErrorEmail } from "../../services/emailService";

export const insertCreditInformation = async (
  creditAmount: number,
  currencyType: string,
  shopId: number,
  description: string
) => {
  try {
    const pool = await poolPromise;

    const result = await pool
      .request()
      .input("credit_description", description)
      .input("credit_amount", creditAmount)
      .input("credit_currency_type", currencyType)
      .input("credit_shop_id", shopId)
      .query(
        "INSERT INTO Merchant_Credits (credit_description, credit_amount, credit_currency_type, credit_shop_id) VALUES (@credit_description, @credit_amount, @credit_currency_type, @credit_shop_id)"
      );

    return result.rowsAffected;
  } catch (error: any) {
    sendErrorEmail("Error credit information to database.", error);

    console.error("Error credit information to database.", error.message);
    throw new Error("Failed to insert credit information.");
  }
};

export const checkVoucherEligibility = async (
  shopId: number,
  billingDate: string,
  voucherValue: number
) => {
  console.log("voucher value", typeof voucherValue, voucherValue);
  try {
    const pool = await poolPromise;
    const result = await pool
      .request()
      .input("shopId", Int, shopId)
      .input("billingDate", DateTime, billingDate)
      .input("voucherValue", Float, voucherValue)
      .query("EXEC CanCreateVoucher @shopId, @billingDate, @voucherValue");

    return result.recordset[0].CanCreateVoucher; // Returns 1 (true) or 0 (false)
  } catch (error: any) {
    sendErrorEmail("Error checking voucher eligibility:", error);

    console.error("Error checking voucher eligibility:", error);
    throw new Error("Failed to check voucher eligibility.");
  }
};
