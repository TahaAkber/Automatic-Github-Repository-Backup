import { poolPromise } from "../../config/db";
import { getGoogleAccessToken } from "../../functions/firebase";
import { sendErrorEmail } from "../../services/emailService";

// export const addSocialAccount = async (
//   userId: number,
//   socialId: number,
//   socialEmail: string,
//   refreshToken: string
// ) => {
//   const pool = await poolPromise;

//   const query = `
//   SELECT * FROM Child_Social_Links
//   WHERE child_social_email = @email
//   AND child_social_type = google
// `;

//   return result.recordset[0]?.response_message;
// };

export const addSocialAccount = async (
  userId: number,
  socialId: string,
  socialEmail: string,
  socialType: string,
  refreshToken: string
): Promise<any> => {
  try {
    const pool = await poolPromise;

    const query = `
    INSERT INTO Child_Social_Links 
    (child_social_id, child_social_email, child_social_refresh_token, child_social_type)
    OUTPUT inserted.child_id
    VALUES (@socialId, @socialEmail, @refreshToken, @socialType)
    `;

    console.log("logs data =>", {
      socialId,
      socialEmail,
      socialType,
      refreshToken,
    });

    const request = pool.request();
    request.input("socialId", socialId);
    request.input("socialEmail", socialEmail);
    request.input("socialType", socialType);
    request.input("refreshToken", refreshToken);
    const result = await request.query(query);
    await addSocialLinkConnect(userId, result.recordset[0].child_id);
    return 1;
  } catch (error: any) {
    sendErrorEmail("Error adding social account:", error);

    console.error("Error adding social account:", error.message);
    return 0;
  }
};

export const addSocialLinkConnect = async (
  userId: number,
  childSocialId: number
): Promise<any> => {
  try {
    const pool = await poolPromise;

    const query = `
      IF NOT EXISTS (
          SELECT 1 
          FROM Social_Links_Connect
          WHERE link_connect_user_id = @socialId
            AND link_connect_child_social_link_id = @childSocialId
      )
      BEGIN
          INSERT INTO Social_Links_Connect
            (link_connect_user_id, link_connect_child_social_link_id)
          VALUES (@socialId, @childSocialId)
      END
    `;

    const request = pool.request();
    request.input("socialId", userId);
    request.input("childSocialId", childSocialId);
    await request.query(query);

    return 1;
  } catch (error: any) {
    sendErrorEmail("Error adding social accou:", error);

    console.error("Error adding social accou:", error.message);
    return error?.message;
  }
};

export const updateSocialRefreshToken = async (
  childId: number,
  refreshToken?: string
): Promise<any> => {
  try {
    const pool = await poolPromise;

    const query = `
      UPDATE Child_Social_Links
      SET child_social_refresh_token = @refreshToken
      WHERE child_id = @child_id
    `;

    const request = pool.request();
    request.input("child_id", childId);
    request.input("refreshToken", refreshToken);
    await request.query(query);

    return 1;
  } catch (error: any) {
    sendErrorEmail("error in updateSocialRefreshToken", error);

    console.log("error", error.message);
    return 2;
  }
};

export const getExistChildSocialLink = async (
  email?: string,
  childId?: number
): Promise<any> => {
  let query;

  const pool = await poolPromise;

  if (childId) {
    query = `
    SELECT * FROM Child_Social_Links 
    WHERE child_id = @child_id 
  `;
  } else {
    query = `
    SELECT * FROM Child_Social_Links 
    WHERE child_social_email = @email 
  `;
  }

  const request = pool.request();
  request.input("email", email);
  request.input("child_id", childId);
  const result = await request.query(query);
  return result.recordset[0];
};

export const getUserConnectedAccounts = async (userId: number) => {
  const pool = await poolPromise;

  const query = `
      SELECT *
      FROM Social_Links_Connect
      WHERE link_connect_user_id = @userId
      ORDER BY created_at DESC;
    `;

  const result = await pool.request().input("userId", userId).query(query);

  const modifiedData = await Promise.all(
    result.recordset.map(async (item: any) => {
      const response = await getExistChildSocialLink(
        "",
        item.link_connect_child_social_link_id
      );
      const checkRefreshToken = await getGoogleAccessToken(
        response?.child_social_refresh_token
      );
      response.child_social_status = checkRefreshToken?.message;
      response.link_connect_id = item.link_connect_id;
      console.log("response", response);

      return response;
    })
  );

  return modifiedData;
};

export const getSocialAccountRefreshToken = async (userId: number) => {
  const pool = await poolPromise;

  const query = `
      SELECT *
      FROM Social_Links_Connect
      WHERE link_connect_user_id = @userId
      ORDER BY created_at DESC;
    `;

  const result = await pool.request().input("userId", userId).query(query);

  const modifiedData = await Promise.all(
    result.recordset.map(async (item: any) => {
      const response = await getExistChildSocialLink(
        "",
        item.link_connect_child_social_link_id
      );
      const checkRefreshToken = await getGoogleAccessToken(
        response?.child_social_refresh_token,
        true
      );
      // response.child_social_status = checkRefreshToken?.message;
      // response.link_connect_id = item.link_connect_id;

      return checkRefreshToken;
    })
  );

  return modifiedData.flat();
};

export const removeAccount = async (link_connect_id: number) => {
  const pool = await poolPromise;

  const query = `
      DELETE FROM Social_Links_Connect
      WHERE link_connect_id = @link_connect_id;
    `;

  await pool.request().input("link_connect_id", link_connect_id).query(query);

  return 1;
};
