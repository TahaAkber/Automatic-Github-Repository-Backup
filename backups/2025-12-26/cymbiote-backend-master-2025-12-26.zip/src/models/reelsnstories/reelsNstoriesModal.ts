import { poolPromise } from "../../config/db";
import { sendErrorEmail } from "../../services/emailService";

export const saveReelStoryToDB = async (
  user_id: number,
  video_id: number,
  status: boolean = true
) => {
  try {
    const pool = await poolPromise;

    const query = `
        INSERT INTO Saved_ReelsNStories (saved_user_id, saved_video_id, saved_status)
        VALUES (@user_id, @video_id, @status);
      `;

    await pool
      .request()
      .input("user_id", user_id)
      .input("video_id", video_id)
      .input("status", status)
      .query(query);
  } catch (error: any) {
    sendErrorEmail("Error saving reel/story to the database:", error);

    console.error("Error saving reel/story to the database:", error);
    throw new Error("Failed to save reel/story");
  }
};

export const removeSavedReelStoryFromDB = async (
  user_id: number,
  video_id: number
) => {
  try {
    const pool = await poolPromise;

    const query = `
        DELETE FROM Saved_ReelsNStories
        WHERE saved_user_id = @user_id AND saved_video_id = @video_id;
      `;

    await pool
      .request()
      .input("user_id", user_id)
      .input("video_id", video_id)
      .query(query);
  } catch (error: any) {
    sendErrorEmail("Error removing reel/story from the database:", error);

    console.error("Error removing reel/story from the database:", error);
    throw new Error("Failed to remove reel/story");
  }
};

export const checkIfReelStoryAlreadySaved = async (
  user_id: number,
  video_id: number
) => {
  try {
    const pool = await poolPromise;

    // Step 1: Check if user exists
    const userQuery = `
        SELECT 1 FROM Users WHERE user_id = @user_id;
      `;
    const userResult = await pool
      .request()
      .input("user_id", user_id)
      .query(userQuery);

    if (userResult.recordset.length === 0) {
      throw new Error(`User with ID ${user_id} does not exist.`);
    }

    // Step 2: Check if video exists
    const videoQuery = `
        SELECT 1 FROM ReelsNStories WHERE id = @video_id;
      `;
    const videoResult = await pool
      .request()
      .input("video_id", video_id)
      .query(videoQuery);

    if (videoResult.recordset.length === 0) {
      throw new Error(`Video with ID ${video_id} does not exist.`);
    }

    // Step 3: Check if the reel/story is already saved
    const savedQuery = `
        SELECT 1 FROM Saved_ReelsNStories
        WHERE saved_user_id = @user_id AND saved_video_id = @video_id;
      `;
    const savedResult = await pool
      .request()
      .input("user_id", user_id)
      .input("video_id", video_id)
      .query(savedQuery);

    // Return true if the combination is not saved, false if it is saved
    return savedResult.recordset.length > 0;
  } catch (error: any) {
    sendErrorEmail("Error checking saved reel/story status:", error);

    console.error("Error checking saved reel/story status:", error);
    throw new Error(error.message || "Failed to check reel/story saved status");
  }
};
