import { poolPromise } from "../../config/db";
import { sendErrorEmail } from "../../services/emailService";

export const deleteCollectionModel = async (id: string) => {
  const pool = await poolPromise;
  const shopifyGid = `gid://shopify/Collection/${id}`;

  const getIdQuery = `
    SELECT collection_id FROM Collections WHERE collection_shopify_id = @collectionId;
  `;

  const getIdResult = await pool
    .request()
    .input("collectionId", shopifyGid)
    .query(getIdQuery);

  const matchingCollections = getIdResult.recordset;

  if (matchingCollections.length === 0) {
    console.log(`❌ No collection found for Shopify GID: ${shopifyGid}`);
    return;
  }

  for (const row of matchingCollections) {
    const collectionId = row.collection_id;

    try {
      // Delete from child table
      await pool
        .request()
        .input("collectionId", collectionId)
        .query(
          `DELETE FROM Collection_Products WHERE collection_id = @collectionId`
        );
      console.log(
        `✅ Deleted Collection_Products for collection_id: ${collectionId}`
      );
    } catch (error: any) {
      sendErrorEmail("❌ Error deleting child products:", error);

      console.error("❌ Error deleting child products:", error);
    }
  }

  try {
    // Delete all matching collections
    const deleteResult = await pool
      .request()
      .input("collectionId", shopifyGid)
      .query(
        `DELETE FROM Collections WHERE collection_shopify_id = @collectionId`
      );

    if (deleteResult.rowsAffected[0] === 0) {
      console.log(`⚠️ No collections deleted for Shopify GID: ${shopifyGid}`);
    } else {
      console.log(
        `✅ Deleted ${deleteResult.rowsAffected[0]} collection(s) for: ${shopifyGid}`
      );
    }

    return deleteResult;
  } catch (error: any) {
    sendErrorEmail("❌ Error while deleting collection(s):", error);

    console.log("❌ Error while deleting collection(s):", error);
    throw error;
  }
};

export const getLocalProductIdByShopifyId = async (id: string) => {
  const pool = await poolPromise;
  const query = `
    SELECT product_id FROM Products where product_shopify_id = @id `;
  try {
    const result = await pool.request().input("id", id).query(query);
    return result.recordset[0].product_id;
  } catch (error: any) {
    sendErrorEmail("Error while getting local product id by shopify id", error);

    console.log("Error while getting local product id by shopify id", error);
    throw error;
  }
};

export const deleteCollectionProducts = async (collection_id: number) => {
  const deleteQuery = `DELETE FROM Collection_Products WHERE collection_id = @collection_id`;
  const pool = await poolPromise;
  try {
    const deleteResult = await pool
      .request()
      .input("collection_id", collection_id)
      .query(deleteQuery);
    return deleteResult;
  } catch (error: any) {
    sendErrorEmail("Error while deleting collection products", error);

    console.log("Error while deleting collection products", error);
    throw error;
  }
};

export const deleteTrendingCollection = async (collection_name: string) => {
  const deleteTrendingCollection = `DELETE FROM Trending_Collections 
  WHERE trending_name IN (@collection_name);`;
  const pool = await poolPromise;
  try {
    const deleteResult = await pool
      .request()
      .input("collection_name", collection_name)
      .query(deleteTrendingCollection);
    return deleteResult;
  } catch (error: any) {
    sendErrorEmail("Error while deleting collection", error);

    console.log("Error while deleting collection", error);
    throw error;
  }
};
export const deleteCollections = async (collection_id: number) => {
  const deleteCollection = `DELETE FROM Collections WHERE collection_id= @collection_id`;
  const pool = await poolPromise;
  try {
    const deleteResult = await pool
      .request()
      .input("collection_id", collection_id)
      .query(deleteCollection);
    return deleteResult;
  } catch (error: any) {
    sendErrorEmail("Error while deleting collection", error);

    console.log("Error while deleting collection", error);
    throw error;
  }
};

export const updateCollectionProducts = async (
  title: string,
  id: string,
  collection_id: number,
  CollectionProductCount: number
) => {
  const insertQuery = `INSERT INTO Collection_Products (collection_id, collection_local_product_id, collection_product_name) VALUES (@collection_id, @collection_local_product_id,@collection_product_name)`;
  const updateQuery = `UPDATE Collections SET collection_product_count = @CollectionProductCount WHERE collection_id = @collection_id`;

  const pool = await poolPromise;

  try {
    const updateResult = await pool
      .request()
      .input("collection_id", collection_id)
      .input("CollectionProductCount", CollectionProductCount)
      .query(updateQuery);

    const localProductId = await getLocalProductIdByShopifyId(id);

    const insertResult = await pool
      .request()
      .input("collection_id", collection_id)
      .input("collection_local_product_id", localProductId)
      .input("collection_product_name", title)
      .query(insertQuery);
    return insertResult;
  } catch (error: any) {
    sendErrorEmail("Error while updating collection products", error);

    console.log("Error while updating collection products", error);
    throw error;
  }
};

export const updateCollection = async (
  id: number,
  title: string,
  body_html: string,
  image: any,
  collection_id: number,
  CollectionProductCount: number
) => {
  const query = `
    UPDATE Collections 
    SET 
      collection_name = @collection_name, 
      collection_product_count = @productCount, 
      collection_condition = @collection_body_html, 
      collection_banner_url = @collection_banner_url 
    WHERE collection_id = @collection_id
  `;

  const pool = await poolPromise;

  console.log("updateCollection", collection_id, title);

  const imageUrl = image?.src || null;

  try {
    const result = await pool
      .request()
      .input("collection_id", collection_id)
      .input("collection_name", title)
      .input("collection_body_html", body_html.replace(/<[^>]*>/g, "").trim())
      .input("collection_banner_url", imageUrl)
      .input("productCount", CollectionProductCount)
      .query(query);

    return result;
  } catch (error: any) {
    sendErrorEmail("Error while updating collection", error);

    console.log("Error while updating collection", error);
    throw error;
  }
};
export const getTrendingCollectionWithName = async (
  trendingCollections: any[]
) => {
  const pool = await poolPromise;
  try {
    const names = trendingCollections
      .map(
        (collection: any) => `'${collection.trending_name.replace(/'/g, "''")}'`
      )
      .join(",");

    const query = `
      SELECT 
        c.*, 
        s.shop_access_token, 
        s.shop_domain 
      FROM 
        Collections c
      INNER JOIN 
        Shops s ON s.shop_id = c.collection_shop_id
      WHERE 
        c.collection_name IN (${names});
    `;

    const result = await pool.request().query(query);
    return result.recordset;
  } catch (error: any) {
    sendErrorEmail("Error while getting collections", error);

    console.log("Error while getting collections", error);
    throw error;
  }
};

export const expiredCollections = async () => {
  const pool = await poolPromise;

  const query = `
    SELECT * 
    FROM Trending_Collections 
    WHERE CAST(trending_expiration_date AS DATE) <= CAST(GETDATE() AS DATE);
  `;

  try {
    const result = await pool.request().query(query);
    const expiredTrending = result.recordset;

    if (!expiredTrending.length) {
      return { trendingCollections: [], collectionShopifyIds: [] };
    }

    const trendingCollections = await getTrendingCollectionWithName(
      expiredTrending
    );

    const collectionShopifyIds = trendingCollections.map(
      (item: any) => item.collection_shopify_id
    );

    return { trendingCollections, collectionShopifyIds };
  } catch (error: any) {
    sendErrorEmail("Error while getting Trending collection", error);

    console.error("Error while getting Trending collection", error);
    throw error;
  }
};
