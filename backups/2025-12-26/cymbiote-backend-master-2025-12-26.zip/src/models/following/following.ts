import { poolPromise } from "../../config/db";

export type FollowingLocalItem = {
  shop_id: number;
  created_at: string;
};
export type DBResult = { rows: any[]; total: number; totalPages: number };

export const manageUserFollowing = async (
  userId: number,
  shopId: number,
  isFollowing: boolean,
  createdAt: string
) => {
  const pool = await poolPromise;

  console.log("createdAt", createdAt);

  const result = await pool
    .request()
    .input("user_id", userId)
    .input("shop_id", shopId)
    .input("is_following", isFollowing)
    .input("created_at", createdAt)
    .execute("ManageUserFollowing");

  return result.recordset[0]?.response_message;
};

export const userFollowingLogs = async (
  userId: number,
  following_local?: { shop_id: number; created_at: string }[],
  search: string = "",
  page: number = 1,
  pageSize: number = 10
): Promise<any> => {
  const pool = await poolPromise;

  if (Array.isArray(following_local) && following_local.length > 0) {
    const localItem = following_local.map((item, index) => ({
      following_id: index,
      following_shop_id: Number(item.shop_id),
      created_at: item.created_at,
    }));
    return localItem;
  }

  const offset = (page - 1) * pageSize;
  const hasSearch = (search ?? "").trim().length > 0;

  const countQuery = `
    SELECT COUNT(*) AS total
    FROM User_Following f
    JOIN Shops s ON s.shop_id = f.following_shop_id
    WHERE f.following_user_id = @userId
      ${hasSearch ? "AND LOWER(s.shop_name) LIKE LOWER(@search)" : ""}
  `;
  const countReq = pool.request().input("userId", userId);
  if (hasSearch) countReq.input("search", `%${search.trim()}%`);
  const countRes = await countReq.query(countQuery);
  const total: number = countRes.recordset?.[0]?.total ?? 0;

  const dataQuery = `
    SELECT f.*, s.shop_name
    FROM User_Following f
    JOIN Shops s ON s.shop_id = f.following_shop_id
    WHERE f.following_user_id = @userId
      ${hasSearch ? "AND LOWER(s.shop_name) LIKE LOWER(@search)" : ""}
    ORDER BY f.created_at DESC
    OFFSET @offset ROWS FETCH NEXT @pageSize ROWS ONLY;
  `;
  const dataReq = pool
    .request()
    .input("userId", userId)
    .input("offset", offset)
    .input("pageSize", pageSize);
  if (hasSearch) dataReq.input("search", `%${search.trim()}%`);
  const dataRes = await dataReq.query(dataQuery);

  const totalPages = Math.max(1, Math.ceil(total / pageSize));
  return { rows: dataRes.recordset ?? [], total, totalPages };
};
