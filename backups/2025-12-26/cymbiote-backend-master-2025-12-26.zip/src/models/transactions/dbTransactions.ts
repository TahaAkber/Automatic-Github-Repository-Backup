import { poolPromise } from "../../config/db";
import { sendErrorEmail } from "../../services/emailService";
import sql from "mssql";

export const createTransaction = async (
  shop_id: number,
  total_amount: number,
  total_amount_usd: number,
  transaction_type: string,
  transaction_detail: string,
  transaction_order_id?: number,
  transaction_subscription_id?: number,
  transaction_currency?: string,
  transaction_kind: string = "sale"
) => {
  try {
    const pool = await poolPromise;

    const query = `
      INSERT INTO Transactions (
        transaction_shop_id, 
        transaction_amount,
        transaction_amount_usd, 
        transaction_type, 
        transaction_detail,
        transaction_order_id,
        transaction_subscription_id,
        transaction_kind,
        transaction_currency,
        created_date
      ) 
      VALUES (
        @shop_id, 
        @total_amount, 
        @total_amount_usd, 
        @transaction_type, 
        @transaction_detail,
        @transaction_order_id,
        @transaction_subscription_id,
        @transaction_kind,
        @transaction_currency,
        GETDATE()
      );
    `;

    const result = await pool
      .request()
      .input("shop_id", shop_id)
      .input("total_amount", total_amount)
      .input("total_amount_usd", total_amount_usd)
      .input("transaction_type", transaction_type)
      .input("transaction_detail", transaction_detail)
      .input("transaction_order_id", transaction_order_id)
      .input("transaction_subscription_id", transaction_subscription_id)
      .input("transaction_kind", transaction_kind)
      .input("transaction_currency", transaction_currency)
      .query<any>(query);

    return result.recordset;
  } catch (error: any) {
    sendErrorEmail("Error creating transaction:", error);

    console.error("Error creating transaction:", error);
    throw new Error("Failed to create transaction.");
  }
};

export const isTransactionExist = async (
  shop_id: number,
  transaction_detail: string
): Promise<boolean> => {
  try {
    const pool = await poolPromise;

    const query = `
      SELECT COUNT(1) AS count
      FROM Transactions
      WHERE transaction_shop_id = @shop_id
        AND transaction_detail = @transaction_detail;
    `;

    const result = await pool
      .request()
      .input("shop_id", sql.Int, shop_id)
      .input("transaction_detail", sql.NVarChar, transaction_detail)
      .query(query);

    const count = result.recordset[0]?.count || 0;

    return count > 0;
  } catch (error: any) {
    sendErrorEmail("Error checking transaction existence:", error);
    console.error("Error checking transaction existence:", error);
    throw new Error("Failed to check transaction existence.");
  }
};
