import { poolPromise } from "../../config/db";
import { sendErrorEmail } from "../../services/emailService";
import { UserCacheDB } from "../../types/usercache/UserCacheDB";

export const getUserByEmailOrUsername = async (identifier: string) => {
  const pool = await poolPromise;
  const query = `
    SELECT * FROM Users
    WHERE user_email = @identifier OR user_name = @identifier OR user_phone = @identifier
  `;
  const result = await pool
    .request()
    .input("identifier", identifier)
    .query(query);
  return result.recordset[0];
};

export const registerDevice = async (deviceId: string) => {
  try {
    const pool = await poolPromise;

    // Check if the device already exists
    const checkQuery = `
      SELECT device_id, id 
      FROM Registered_Devices 
      WHERE device_id = @deviceId
    `;

    const checkResult = await pool
      .request()
      .input("deviceId", deviceId)
      .query(checkQuery);

    if (checkResult.recordset.length > 0) {
      // Device already exists
      return checkResult.recordset[0].id;
    }

    // Insert new device
    const insertQuery = `
      INSERT INTO Registered_Devices (device_id)
      OUTPUT INSERTED.id
      VALUES (@deviceId)
    `;

    const insertResult = await pool
      .request()
      .input("deviceId", deviceId)
      .query(insertQuery);

    return insertResult.recordset[0].id;
  } catch (error: any) {
    sendErrorEmail("Error in registerDevice:", error);

    console.error("Error in registerDevice:", error);
    throw new Error("Failed to created device");
  }
};

export const storeNotificationToken = async (
  deviceId: string,
  notificationToken: string,
  userId?: number
) => {
  try {
    const pool = await poolPromise;
    const request = pool.request();

    const getDeviceId = await registerDevice(deviceId);
    console.log("getDeviceId", getDeviceId);
    request.input("deviceId", getDeviceId);
    request.input("notificationToken", notificationToken);
    if (userId) {
      request.input("userId", userId);
    }

    // 1. Check if token exists
    const checkTokenQuery = `
      SELECT * FROM User_Notification_Tokens
      WHERE notification_device_id = @deviceId
    `;
    const checkResult = await request.query(checkTokenQuery);

    console.log("checkResult", checkResult);
    if (checkResult.recordset.length > 0) {
      if (userId) {
        // Check if this device already has an entry
        const existingDevice = await pool
          .request()
          .input("deviceId", getDeviceId).query(`
        SELECT 1 FROM User_Notification_Tokens
        WHERE notification_device_id = @deviceId
      `);

        if (existingDevice.recordset.length > 0) {
          // Update token for this device
          await pool
            .request()
            .input("userId", userId)
            .input("deviceId", getDeviceId)
            .input("notificationToken", notificationToken).query(`
          UPDATE User_Notification_Tokens
          SET notification_user_id = @userId,
              notification_token = @notificationToken
          WHERE notification_device_id = @deviceId
        `);
        } else {
          // Insert new device token
          await pool
            .request()
            .input("userId", userId)
            .input("deviceId", getDeviceId)
            .input("notificationToken", notificationToken).query(`
          INSERT INTO User_Notification_Tokens (notification_user_id, notification_token, notification_device_id)
          VALUES (@userId, @notificationToken, @deviceId)
        `);
        }
        return true;
      } else {
        // Guest device (no userId)
        await pool
          .request()
          .input("deviceId", getDeviceId)
          .query(
            `DELETE FROM User_Notification_Tokens WHERE notification_device_id = @deviceId`
          );

        await pool
          .request()
          .input("userId", null)
          .input("deviceId", getDeviceId)
          .input("notificationToken", notificationToken).query(`
        INSERT INTO User_Notification_Tokens (notification_user_id, notification_token, notification_device_id)
        VALUES (@userId, @notificationToken, @deviceId)
      `);
      }
    } else {
      // First time install
      await pool
        .request()
        .input("notificationToken", notificationToken)
        .input("userId", userId || null)
        .input("deviceId", getDeviceId).query(`
      INSERT INTO User_Notification_Tokens (notification_user_id, notification_token, notification_device_id)
      VALUES (@userId, @notificationToken, @deviceId)
    `);
    }
    return true;
  } catch (error: any) {
    sendErrorEmail("Error storing notification token:", error);

    console.error("Error storing notification token:", error);
    throw new Error("Error storing notification token");
  }
};
export const removeNotificationToken = async (deviceId: string) => {
  try {
    const pool = await poolPromise;

    const getDeviceId = await registerDevice(deviceId);

    const checkTokenQuery = `
      SELECT * FROM User_Notification_Tokens
      WHERE notification_device_id = @deviceId
    `;

    const checkRequest = pool.request();
    checkRequest.input("deviceId", getDeviceId);
    const checkResult = await checkRequest.query(checkTokenQuery);

    console.log("checkResult", checkResult);

    if (checkResult.recordset.length > 0) {
      // Step 2: Update and null user ID
      const updateRequest = pool.request();
      updateRequest.input("deviceId", getDeviceId);
      await updateRequest.query(`
        UPDATE User_Notification_Tokens
        SET notification_user_id = NULL
        WHERE notification_device_id = @deviceId
      `);
    }

    return true;
  } catch (error: any) {
    sendErrorEmail("Error storing notification token", error);

    throw new Error("Error storing notification token");
  }
};

export const getUserById = async (userId: number) => {
  const pool = await poolPromise;
  const query = `
    SELECT * FROM Users
    WHERE user_id = @userId
  `;
  const result = await pool.request().input("userId", userId).query(query);
  return result.recordset[0];
};

export const getUserByEmail = async (email: string) => {
  const pool = await poolPromise;
  const query = `SELECT u.* 
    FROM Users u
    WHERE user_email = @email`;
  try {
    const result = await pool.request().input("email", email).query(query);
    return result.recordset[0];
  } catch (error: any) {
    sendErrorEmail("Error getting user by email:", error);
    throw new Error("Error getting user by email");
  }
};

export const getUserBySocialIdAndType = async (
  socialId: number,
  socialType: string
) => {
  const pool = await poolPromise;

  const query = `
    SELECT u.* 
    FROM Users u
    INNER JOIN Social_Links sa ON sa.social_user_id = u.user_id
    WHERE sa.social_id = @social_id AND sa.social_type = @social_type
  `;

  const result = await pool
    .request()
    .input("social_id", socialId)
    .input("social_type", socialType)
    .query(query);

  return result.recordset[0]; // Return the first matching user record
};

export const createUser = async (
  email: string,
  phone: string,
  password: string,
  username: string,
  firstname: string,
  lastname: string,
  gender: string,       
  dateofbirth: string   
): Promise<number> => {
  const pool = await poolPromise;

  const query = `
    INSERT INTO Users (
      user_email,
      user_phone,
      user_password,
      user_name,
      user_first_name,
      user_last_name,
      user_gender,
      user_dob,
      user_login_type,
      created_date
    )
    VALUES (
      @Email,
      @Phone,
      @Password,
      @Username,
      @FirstName,
      @LastName,
      @Gender,
      TRY_CONVERT(date, @DateOfBirth),
      @UserLoginType,
      GETDATE()
    );

    SELECT CAST(SCOPE_IDENTITY() AS int) AS user_id;
  `;

  const result = await pool
    .request()
    .input("Email", email)
    .input("Phone", phone)
    .input("Password", password)
    .input("Username", username)
    .input("FirstName", firstname)
    .input("LastName", lastname)
    .input("Gender", gender)
    .input("DateOfBirth", dateofbirth)
    .input("UserLoginType", "email")
    .query(query);

  const userId = result.recordset?.[0]?.user_id;
  console.log("Inserted user ID:", userId);
  return userId;
};


export const createSocialLink = async (
  socialtype: string,
  socialId: number,
  userId: number
): Promise<number> => {
  const pool = await poolPromise;

  const query = `
    INSERT INTO Social_Links (social_type, social_id, social_user_id, created_at)
    VALUES (@social_type, @social_id, @social_user_id, GETDATE());
  `;

  const result = await pool
    .request()
    .input("social_type", socialtype)
    .input("social_id", socialId)
    .input("social_user_id", userId)
    .query(query);

  // Return the user ID of the newly inserted user
  return result.rowsAffected[0];
};

export const createSocialUser = async (
  email: string,
  phone: string,
  imageUrl: string,
  password: string,
  firstName: string,
  lastName: string,
  userLoginType: string
) => {
  const pool = await poolPromise; // Get the connection pool

  try {
    const result = await pool
      .request()
      .input("Email", email)
      .input("ImageUrl", imageUrl)
      .input("Phone", phone)
      .input("Password", password)
      .input("FirstName", firstName)
      .input("LastName", lastName)
      .input("UserLoginType", userLoginType)
      .execute("InsertSocialUser"); // Execute the stored procedure

    const newUser = result.recordset[0]; // Get the first user record returned

    return newUser; // Return the created user information
  } catch (error: any) {
    sendErrorEmail("Error creating user:", error);

    console.error("Error creating user:", error);
    throw new Error("Database operation failed.");
  }
};

export const saveDeviceDetails = async (
  deviceName: string,
  deviceId: string
) => {
  const pool = await poolPromise;
  const query = `
    INSERT INTO Registered_Devices (device_name, device_id)
    VALUES (@deviceName, @device_id)
  `;
  await pool
    .request()
    .input("device_id", deviceId)
    .input("deviceName", deviceName)
    .query(query);
};

export const checkDeviceDetails = async (deviceId: string) => {
  const pool = await poolPromise;
  const query = `
    SELECT * FROM Registered_Devices
    WHERE device_id = @deviceId
  `;
  const result = await pool.request().input("deviceId", deviceId).query(query);
  return result.recordset[0];
};

export const updateUserVerified = async (user_id: number) => {
  try {
    const query = `
    UPDATE Users SET user_is_verified = @user_is_verified WHERE user_id = @user_id
`;

    const pool = await poolPromise;
    const update = await pool
      .request()
      .input("user_id", user_id)
      .input("user_is_verified", true)
      .query(query);

    // Check if any rows were affected by the update
    console.log("update", update);
    // return updatedProduct.rowsAffected[0] > 0;
  } catch (error: any) {
    sendErrorEmail("Error updating user verified:", error);

    console.error("Error updating user verified:", error);
    throw new Error("Failed to update user verified");
  }
};

export const updatePassword = async (identifier: string, password: string) => {
  try {
    const query = `
        UPDATE Users SET user_password = @user_password WHERE user_email = @identifier OR user_name = @identifier OR user_phone = @identifier
`;

    const pool = await poolPromise;
    const update = await pool
      .request()
      .input("identifier", identifier)
      .input("user_password", password)
      .query(query);

    // Check if any rows were affected by the update
    console.log("update", update);
    return update.rowsAffected[0] > 0;
  } catch (error: any) {
    sendErrorEmail("Error updating user verified:", error);

    console.error("Error updating user verified:", error);
    throw new Error("Failed to update user verified");
  }
};

export const addUserCache = async (userId: number, cacheJson: string) => {
  const pool = await poolPromise;

  console.log("adding cache to the db");

  try {
    const query = `
      INSERT INTO User_Cache (cache_user_id, cache_json) VALUES (@userId, @json);
    `;

    const request = await pool
      .request()
      .input("userId", userId)
      .input("json", cacheJson)
      .query(query);

    return request.rowsAffected.length > 0;
  } catch (error: any) {
    sendErrorEmail("Failed to add user cache ", error);

    throw new Error("Failed to add user cache " + error.message);
  }
};

export const getUserCache = async (userId: number): Promise<UserCacheDB> => {
  const pool = await poolPromise;

  const query = `
    SELECT * FROM User_Cache WHERE cache_user_id = @userId;
  `;
  try {
    const request = await pool.request().input("userId", userId).query(query);

    return request.recordset[0];
  } catch (error: any) {
    sendErrorEmail("Failed to get User Cache ", error);

    throw new Error("Failed to get User Cache " + error.message);
  }
};
