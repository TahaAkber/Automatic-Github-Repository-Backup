import { Int, NVarChar } from "mssql";
import { poolPromise } from "../../config/db";
import { getUserByEmailOrUsername } from "../users/user";
import sql from "mssql";
import { CartShop, ProductVariantItem } from "../../types/cart/cart";
import { sendErrorEmail } from "../../services/emailService";

export const insertCartInformation = async (
  cartId: string,
  cartShopifyId: string,
  cartUrl: string,
  cartUserEmail: string,
  cartItemsQuantity: number
) => {
  try {
    const pool = await poolPromise;

    // Getting user by email
    const user = await getUserByEmailOrUsername(cartUserEmail);
    if (!user || !user.user_id) {
      throw new Error("User not found for email: " + cartUserEmail);
    }

    const result = await pool
      .request()
      .input("cart_id", NVarChar(255), cartId)
      .input("cart_shopify_id", NVarChar(500), cartShopifyId)
      .input("cart_url", NVarChar(500), cartUrl)
      .input("cart_user_id", Int, user.user_id)
      .input("cart_items_quantity", Int, cartItemsQuantity)
      .execute("InsertOrUpdateCart");

    console.log("Stored Procedure Response:", result.recordset[0]);
    return result.recordset[0];
  } catch (error: any) {
    sendErrorEmail("Error in insertCartInformation:", error);

    console.error("Error in insertCartInformation:", error);
    throw new Error("Error inserting/updating cart information");
  }
};

export const fetchAvailableCart = async (cartId: string) => {
  try {
    const pool = await poolPromise;
    const query = `SELECT * FROM Carts WHERE cart_id = '${cartId}'`;
    const result = await pool.request().query(query);
    return result.recordset[0];
  } catch (error: any) {
    sendErrorEmail("Error in fetchAvailableCart:", error);

    console.error("Error in fetchAvailableCart:", error);
    throw new Error("Error fetching available cart");
  }
};

// export const syncCartToDatabase = async (
//   cart_id: string, // 👈 NEW: cart_id as first argument
//   deviceIdentifier: string,
//   user_id: number,
//   shop_id: number,
//   pre_cart_items: {
//     pre_cart_item_id?: number;
//     pre_cart_item_variant_id: number;
//     pre_cart_item_quantity: number;
//   }[]
// ) => {
//   try {
//     const pool = await poolPromise;
//     const result = await pool
//       .request()
//       .input("cart_id", cart_id)
//       .input("deviceIdentifier", deviceIdentifier)
//       .input("user_id", sql.Int, user_id)
//       .input("shop_id", sql.Int, shop_id)
//       .input(
//         "pre_cart_items_json",
//         sql.NVarChar(sql.MAX),
//         JSON.stringify(pre_cart_items)
//       )
//       .execute("UpsertPreCartFromJson");

//     return { status: 200, message: "Cart synced successfully" };
//   } catch (error) {
//     console.error("Error in syncCartToDatabase:", error);
//     throw new Error("Error syncing cart to database");
//   }
// };

export const syncCartToDatabase = async (
  cart_id: string,
  deviceIdentifier: string,
  user_id: number,
  shop_id: number,
  pre_cart_items: {
    pre_cart_item_id?: number;
    pre_cart_item_variant_id: number;
    pre_cart_item_quantity: number;
  }[]
) => {
  try {
    const pool = await poolPromise;
    const MAX_PER_ITEM = 50; // ✅ per-line cap

    const variantIds = [
      ...new Set(pre_cart_items.map((i) => i.pre_cart_item_variant_id)),
    ];

    if (variantIds.length === 0) {
      return { status: 200, message: "Cart synced successfully" };
    }

    const req = pool.request();
    const placeholders = variantIds.map((_, i) => `@id${i}`).join(",");
    variantIds.forEach((id, i) => req.input(`id${i}`, sql.Int, id));

    const stockResult = await req.query(`
      SELECT 
        variant_id, 
        variant_quantity AS quantity
      FROM Product_Variants
      WHERE variant_id IN (${placeholders})
    `);

    const stockMap: Record<number, number> = {};
    for (const row of stockResult.recordset ?? []) {
      stockMap[Number(row.variant_id)] = Number(row.quantity ?? 0);
    }

    for (const line of pre_cart_items) {
      const vid = Number(line.pre_cart_item_variant_id);
      const requested = Number(line.pre_cart_item_quantity);

      if (!Number.isInteger(requested) || requested < 1) {
        return {
          status: 400,
          message: `Quantity must be a positive integer for variant ${vid}.`,
        };
        // const err: any = new Error(
        //   `Quantity must be a positive integer for variant ${vid}.`
        // );
        // err.status = 400;
        // err.code = "INVALID_QUANTITY";
        // throw err;
      }

      // ✅ New: per-line max 50 check
      if (requested > MAX_PER_ITEM) {
        return {
          status: 400,
          message: `Sorry, quantity cannot exceed ${MAX_PER_ITEM} for variant . Add a lower quantity to continue.`,
        };
        // const err: any = new Error(
        //   `Sorry, quantity cannot exceed ${MAX_PER_ITEM} for variant . Add a lower quantity to continue.`
        // );
        // err.status = 400;
        // err.code = "QTY_LIMIT_EXCEEDED";
        // throw err;
      }

      if (stockMap[vid] === undefined) {
        return {
          status: 404,
          message: `Variant ${vid} not found.`,
        };
        // const err: any = new Error(`Variant ${vid} not found.`);
        // err.status = 404;
        // err.code = "VARIANT_NOT_FOUND";
        // throw err;
      }

      const available = stockMap[vid];
      if (requested > available) {
        return {
          status: 400,
          message: `Sorry, insufficient quantity available for this variant. Requested ${requested}, available ${available}.`,
        };
        // const err: any = new Error(
        //   `Sorry, insufficient quantity available for this variant. Requested ${requested}, available ${available}.`
        // );
        // err.status = 400;
        // err.code = "INSUFFICIENT_STOCK";
        // throw err;
      }
    }

    await pool
      .request()
      .input("cart_id", cart_id)
      .input("deviceIdentifier", deviceIdentifier)
      .input("user_id", sql.Int, user_id)
      .input("shop_id", sql.Int, shop_id)
      .input(
        "pre_cart_items_json",
        sql.NVarChar(sql.MAX),
        JSON.stringify(pre_cart_items)
      )
      .execute("UpsertPreCartFromJson");

    return { status: 200, message: "Cart synced successfully" };
  } catch (error: any) {
    sendErrorEmail("Error in syncCartToDatabase:", error);

    console.error("Error in syncCartToDatabase:", error);
    if (error?.status) {
      throw error;
    }
    const err: any = new Error("Error syncing cart to database");
    err.status = 500;
    err.code = "SYNC_FAILED";
    throw err;
  }
};

export const getCartFromDatabase = async (
  user_id?: number,
  deviceIdentifier?: string
): Promise<
  {
    pre_cart_id: string;
    pre_cart_user_id?: number;
    shop_id: number;
    product_variant: {
      variant_id: number;
      qty: number;
      pre_cart_item_id?: string;
    }[];
  }[]
> => {
  try {
    const pool = await poolPromise;

    let preCartQuery = `
      SELECT c.pre_cart_id, 
             c.pre_cart_user_id, 
             c.pre_cart_shop_id, 
             s.shop_id, 
             c.created_at
      FROM Pre_Cart c
      JOIN Shops s ON s.shop_id = c.pre_cart_shop_id
    `;

    const request = pool.request();

    if (typeof user_id === "number" && user_id > 0) {
      preCartQuery += ` WHERE c.pre_cart_user_id = @user_id`;
      request.input("user_id", sql.Int, user_id);
    } else if (deviceIdentifier) {
      // FIX: Use IN instead of =
      preCartQuery += `
        WHERE c.pre_cart_device_id IN (
          SELECT id FROM Registered_Devices WHERE device_id = @deviceIdentifier
        )
        AND (c.pre_cart_user_id IS NULL)
      `;
      request.input("deviceIdentifier", deviceIdentifier);
    } else {
      throw new Error("Either user_id or deviceIdentifier is required");
    }

    preCartQuery += ` ORDER BY c.created_at DESC`;

    const cartHeaderResult = await request.query(preCartQuery);
    const carts = cartHeaderResult.recordset;

    const finalCart = [];

    for (const cart of carts) {
      const preCartId = cart.pre_cart_id as string;

      if (!preCartId || typeof preCartId !== "string") {
        console.warn("⚠️ Skipping invalid pre_cart_id:", cart.pre_cart_id);
        continue;
      }

      const cartItemsQuery = `
        SELECT pci.pre_cart_item_variant_id AS variant_id,
               pci.pre_cart_item_quantity AS qty,
               pci.pre_cart_item_id
        FROM Pre_Cart_Items pci
        WHERE pci.pre_cart_id = @pre_cart_id
        ORDER BY pci.pre_cart_item_id DESC
      `;

      const itemRequest = pool.request();
      itemRequest.input("pre_cart_id", preCartId);
      const itemResults = await itemRequest.query(cartItemsQuery);
      const items = itemResults.recordset;

      finalCart.push({
        pre_cart_id: preCartId,
        pre_cart_user_id: cart.pre_cart_user_id,
        shop_id: cart.pre_cart_shop_id,
        product_variant: items.map((item) => ({
          variant_id: item.variant_id,
          qty: item.qty,
          pre_cart_item_id: item.pre_cart_item_id,
        })),
      });
    }

    return finalCart;
  } catch (error: any) {
    sendErrorEmail("Error in getCartFromDatabase:", error);

    console.error("❌ Error in getCartFromDatabase:", error);
    throw new Error("Error fetching cart data");
  }
};

export const deleteCartItemsByCartId = async (cartId: string) => {
  const pool = await poolPromise;

  const transaction = pool.transaction();

  try {
    await transaction.begin();

    const deleteItemsQuery = `
      DELETE FROM Pre_Cart_Items WHERE pre_cart_id = @cartId;
    `;

    const request = transaction.request();
    request.input("cartId", cartId);

    await request.query(deleteItemsQuery);

    const checkCartQuery = `
      SELECT COUNT(*) AS itemCount FROM Pre_Cart_Items WHERE pre_cart_id = @cartId;
    `;

    const itemResult = await request.query(checkCartQuery);
    const itemCount = itemResult.recordset[0].itemCount;

    if (itemCount === 0) {
      const deleteCartQuery = `
        DELETE FROM Pre_Cart WHERE pre_cart_id = @cartId;
      `;
      await request.query(deleteCartQuery);
    }

    await transaction.commit();

    return {
      status: 200,
      message: "Cart items and cart deleted successfully ",
    };
  } catch (error: any) {
    sendErrorEmail("Error deleting cart items and cart:", error);

    await transaction.rollback();
    console.error("Error deleting cart items and cart:", error);
    throw new Error("Error deleting cart items and cart");
  }
};
export const deletePreCartItems = async (preCartItemId: string) => {
  if (!preCartItemId) {
    throw new Error("preCartItemId is required");
  }

  const pool = await poolPromise;
  const transaction = pool.transaction();

  try {
    console.log(preCartItemId, "preCartItemId");
    await transaction.begin();

    const request = transaction.request();
    request.input("preCartItemId", preCartItemId);

    const getCartIdQuery = `
      SELECT pre_cart_id FROM Pre_Cart_Items WHERE pre_cart_item_id = @preCartItemId;
    `;

    const cartResult = await request.query(getCartIdQuery);

    if (cartResult.recordset.length === 0) {
      throw new Error("Cart item not found");
    }

    const cartId = cartResult.recordset[0].pre_cart_id;

    const deleteItemQuery = `
      DELETE FROM Pre_Cart_Items WHERE pre_cart_item_id = @preCartItemId;
    `;

    await request.query(deleteItemQuery);

    // Check if any items remain in this cart
    const checkItemsQuery = `
      SELECT COUNT(*) AS itemCount FROM Pre_Cart_Items WHERE pre_cart_id = @cartId;
    `;

    request.input("cartId", cartId);
    const itemCountResult = await request.query(checkItemsQuery);

    const itemCount = itemCountResult.recordset[0].itemCount;

    // If no items remain, delete the cart
    if (itemCount === 0) {
      const deleteCartQuery = `
        DELETE FROM Pre_Cart WHERE pre_cart_id = @cartId;
      `;
      await request.query(deleteCartQuery);
    }

    await transaction.commit();

    return {
      status: 200,
      message: "Cart item deleted successfully",
      cartDeleted: itemCount === 0,
    };
  } catch (error: any) {
    sendErrorEmail("Error deleting cart item:", error);

    await transaction.rollback();
    console.error("Error deleting cart item:", error);
    throw new Error("Error deleting cart item");
  }
};

export const assignUserToCarts = async (
  cartIds: string[],
  userId: number
): Promise<{ updatedCount: number }> => {
  const pool = await poolPromise;
  const transaction = pool.transaction();

  try {
    await transaction.begin();

    if (!cartIds.length) throw new Error("cartIds array is empty");

    let updatedCount = 0;

    for (const guestCartId of cartIds) {
      // 1. Get the guest cart shop ID
      const guestCart = await transaction
        .request()
        .input("guestCartId", sql.VarChar, guestCartId).query(`
          SELECT pre_cart_shop_id FROM Pre_Cart WHERE pre_cart_id = @guestCartId
        `);

      if (!guestCart.recordset.length) continue;
      const shopId = guestCart.recordset[0].pre_cart_shop_id;

      // 2. Find user's existing cart for the same shop
      const userCartResult = await transaction
        .request()
        .input("userId", sql.Int, userId)
        .input("shopId", sql.Int, shopId).query(`
          SELECT pre_cart_id FROM Pre_Cart
          WHERE pre_cart_user_id = @userId AND pre_cart_shop_id = @shopId
        `);

      let userCartId: string | null = null;
      if (userCartResult.recordset.length) {
        userCartId = userCartResult.recordset[0].pre_cart_id;
      }

      // 3. Get all items from the guest cart
      const guestItemsResult = await transaction
        .request()
        .input("guestCartId", sql.VarChar, guestCartId).query(`
          SELECT pre_cart_item_id, pre_cart_item_variant_id, pre_cart_item_quantity
          FROM Pre_Cart_Items WHERE pre_cart_id = @guestCartId
        `);
      const guestItems = guestItemsResult.recordset;

      if (userCartId) {
        // 4. Merge guest items into user's cart
        for (const guestItem of guestItems) {
          // Check if this variant already exists in user cart
          const userItemResult = await transaction
            .request()
            .input("userCartId", sql.VarChar, userCartId)
            .input("variantId", sql.Int, guestItem.pre_cart_item_variant_id)
            .query(`
              SELECT pre_cart_item_id, pre_cart_item_quantity FROM Pre_Cart_Items
              WHERE pre_cart_id = @userCartId AND pre_cart_item_variant_id = @variantId
            `);

          if (userItemResult.recordset.length) {
            // Variant exists: update quantity in user's cart, delete guest item
            const userItemId = userItemResult.recordset[0].pre_cart_item_id;
            await transaction
              .request()
              .input("qty", sql.Int, guestItem.pre_cart_item_quantity)
              .input("userItemId", sql.Int, userItemId).query(`
                UPDATE Pre_Cart_Items
                SET pre_cart_item_quantity = pre_cart_item_quantity + @qty
                WHERE pre_cart_item_id = @userItemId
              `);
            // Delete guest item
            await transaction
              .request()
              .input("guestItemId", sql.Int, guestItem.pre_cart_item_id)
              .query(
                `DELETE FROM Pre_Cart_Items WHERE pre_cart_item_id = @guestItemId`
              );
          } else {
            // Variant not in user cart: move the item over
            await transaction
              .request()
              .input("userCartId", sql.VarChar, userCartId)
              .input("guestItemId", sql.Int, guestItem.pre_cart_item_id).query(`
                UPDATE Pre_Cart_Items
                SET pre_cart_id = @userCartId
                WHERE pre_cart_item_id = @guestItemId
              `);
          }
        }
        // Delete the empty guest cart
        await transaction
          .request()
          .input("guestCartId", sql.VarChar, guestCartId)
          .query(`DELETE FROM Pre_Cart WHERE pre_cart_id = @guestCartId`);

        updatedCount++;
      } else {
        // No existing user cart for this shop: assign guest cart to user
        await transaction
          .request()
          .input("userId", sql.Int, userId)
          .input("guestCartId", sql.VarChar, guestCartId).query(`
            UPDATE Pre_Cart
            SET pre_cart_user_id = @userId
            WHERE pre_cart_id = @guestCartId
          `);

        updatedCount++;
      }
    }

    await transaction.commit();
    return { updatedCount };
  } catch (error: any) {
    sendErrorEmail("Error in assignUserToCarts:", error);

    await transaction.rollback();
    console.error("Error in assignUserToCarts:", error);
    throw error;
  }
};

