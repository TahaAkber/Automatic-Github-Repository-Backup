import { Int, pool, VarChar } from "mssql";
import { poolPromise } from "../../config/db";
import { CreateCommentParams } from "../../types/reviews/CreateCommentParams";
import { ReactionPayload } from "../../types/reviews/ReactionPayload";
import { ReviewReactionPayload } from "../../types/reviews/ReviewReactionPayload";
import { sendErrorEmail } from "../../services/emailService";

export const InsertReviewImages = async (reviewId: number, images = []) => {
  const pool = await poolPromise;

  try {
    for (const img of images) {
      await pool
        .request()
        .input("review_id", reviewId)
        .input("review_image_url", img).query(`
          INSERT INTO Review_Images (review_image_review_id, review_image_url)
          VALUES (@review_id, @review_image_url)
        `);
    }

    return { success: true };
  } catch (error: any) {
    sendErrorEmail("Failed to insert review images:", error);

    console.error("Failed to insert review images:", error);
    throw new Error("Failed to insert review images");
  }
};

export const GetReviewImages = async (reviewId: number) => {
  const pool = await poolPromise;

  try {
    // Fetch image URLs from Review_Images table for the provided reviewId
    const result = await pool.request().input("review_id", reviewId).query(`
        SELECT review_image_url
        FROM Review_Images
        WHERE review_image_review_id = @review_id
      `);

    // Return the list of image URLs
    return result.recordset.map((row) => row.review_image_url) || [];
  } catch (error: any) {
    sendErrorEmail("Failed to get review images:", error);

    console.error("Failed to get review images:", error);
    throw new Error("Failed to fetch review images");
  }
};

export const deleteReviewImages = async (reviewId: number) => {
  const pool = await poolPromise;

  try {
    // DELETE all images where review_id matches
    await pool.request().input("review_id", reviewId).query(`
        DELETE FROM Review_Images
        WHERE review_image_review_id = @review_id
      `);

    console.log(`All images for review_id ${reviewId} deleted.`);
    return true;
  } catch (error: any) {
    sendErrorEmail("Failed to delete review images:", error);

    console.error("Failed to delete review images:", error);
    throw new Error("Failed to delete review images");
  }
};

export const CreateOrderItemReview = async (
  orderItemId: number,
  reviewRating: number,
  reviewComment: string,
  images?: []
) => {
  const pool = await poolPromise;

  try {
    const query = `
      INSERT INTO Order_Item_Review (
        order_item_id,
        order_item_review_rating,
        order_item_review_comment
      )
      VALUES (
        @order_item_id,
        @order_item_review_rating,
        @order_item_review_comment
      );

      SELECT SCOPE_IDENTITY() AS insertedId;
    `;

    const result = await pool
      .request()
      .input("order_item_id", orderItemId)
      .input("order_item_review_rating", reviewRating)
      .input("order_item_review_comment", reviewComment)
      .query(query);

    const insertedId = result.recordset[0]?.insertedId;

    console.log("insertedId", insertedId);

    if (images && images.length > 0 && insertedId) {
      await InsertReviewImages(insertedId, images);
    }

    return 1;
  } catch (error: any) {
    sendErrorEmail("CreateOrderItemReview error:", error);

    console.error("CreateOrderItemReview error:", error);
    throw new Error("Failed to create review by order item ID");
  }
};

export const userReviews = async (userId: number, productDetail = true) => {
  const pool = await poolPromise;

  try {
    const query = `
      SELECT 
        r.order_item_review_id,
        r.order_item_id,
        r.order_item_review_rating,
        r.order_item_review_comment,
        r.created_at,
        o.order_id
      FROM Order_Item_Review r
      INNER JOIN Order_Items oi ON r.order_item_id = oi.order_item_id
      INNER JOIN Orders o ON oi.order_id = o.order_id
      WHERE o.order_user_id = @userId
      ORDER BY r.order_item_review_id DESC;
    `;

    const result = await pool.request().input("userId", userId).query(query);

    return result.recordset || [];
  } catch (error: any) {
    sendErrorEmail("userReviews error:", error);

    console.error("userReviews error:", error);
    throw new Error("Failed to fetch user reviews");
  }
};

export const getOrderItemReviewById = async (order_item_id: number) => {
  const pool = await poolPromise;

  try {
    const query = `
      SELECT *
      FROM Order_item_Review
      WHERE order_item_id = @order_item_id;
    `;

    const result = await pool
      .request()
      .input("order_item_id", order_item_id)
      .query(query);

    const images = await GetReviewImages(
      result.recordset?.[0]?.order_item_review_id
    );
    if (images.length > 0) {
      result.recordset[0].images = images;
    }

    return result.recordset.length > 0 ? result.recordset[0] : false;
  } catch (error: any) {
    sendErrorEmail("Failed to get order item by item id", error);

    throw new Error("Failed to get order item by item id");
  }
};

export const deleteOrderItemReviewById = async (
  order_item_review_id: number
) => {
  const pool = await poolPromise;

  try {
    await deleteReviewImages(order_item_review_id);

    const query = `
      DELETE
      FROM Order_item_Review
      WHERE order_item_review_id = @order_item_review_id;
    `;

    const result = await pool
      .request()
      .input("order_item_review_id", order_item_review_id)
      .query(query);

    return true;
  } catch (error: any) {
    sendErrorEmail("Failed to get order item by item id", error);

    throw new Error("Failed to get order item by item id");
  }
};

export const getReviewById = async (order_item_review_id: number) => {
  const pool = await poolPromise;

  try {
    const query = `
      SELECT *
      FROM Order_item_Review
      WHERE order_item_review_id = @order_item_review_id;
    `;

    const result = await pool
      .request()
      .input("order_item_review_id", order_item_review_id)
      .query(query);

    const images = await GetReviewImages(order_item_review_id);
    if (images.length > 0) {
      result.recordset[0].images = images;
    }

    return result.recordset.length > 0 ? result.recordset[0] : false;
  } catch (error: any) {
    sendErrorEmail("Failed to get order item by item id", error);

    throw new Error("Failed to get order item by item id");
  }
};

export const getProductReviews = async (productId: number) => {
  if (!productId || typeof productId !== "number") {
    throw new Error("Invalid product ID");
  }

  const pool = await poolPromise;
  const request = pool.request();
  request.input("productId", Int, productId);

  const result = await request.query(`
    SELECT 
      R.order_item_review_id,
      R.order_item_review_rating,
      R.order_item_review_comment,
      U.user_id,
      U.user_name,
      U.user_first_name,
      U.user_last_name,
      U.user_image_url,
      PV.variant_id,
      R.created_at
    FROM Order_Item_Review R
    JOIN Order_Items OI ON R.order_item_id = OI.order_item_id
    JOIN Orders O ON OI.order_id = O.order_id
    JOIN Users U ON O.order_user_id = U.user_id
    JOIN Product_Variants PV ON OI.order_item_variant_id = PV.variant_id
    WHERE PV.variant_product_id = @productId;
  `);

  return result.recordset || [];
};

export const getGroupedReviewImages = async (reviewIds: number[]) => {
  if (!Array.isArray(reviewIds) || reviewIds.length === 0) return {};

  const pool = await poolPromise;
  const request = pool.request();

  reviewIds.forEach((id, index) => {
    if (typeof id !== "number") throw new Error("Invalid review ID type");
    request.input(`id${index}`, Int, id);
  });

  const placeholders = reviewIds.map((_, index) => `@id${index}`).join(",");

  const query = `
    SELECT review_image_review_id, review_image_url
    FROM Review_Images
    WHERE review_image_review_id IN (${placeholders});
  `;

  const result = await request.query(query);
  const grouped: Record<number, string[]> = {};

  for (const row of result.recordset) {
    if (!grouped[row.review_image_review_id]) {
      grouped[row.review_image_review_id] = [];
    }
    grouped[row.review_image_review_id].push(row.review_image_url);
  }

  return grouped;
};

export const getProductReviewsStats = async (productId: number) => {
  if (!productId || typeof productId !== "number") {
    throw new Error("Invalid product ID for stats");
  }

  const pool = await poolPromise;
  const request = pool.request();
  request.input("productId", Int, productId);

  const result = await request.query(`
    SELECT
      COUNT(*) AS total_reviews,
      AVG(R.order_item_review_rating) AS average_rating,
      SUM(CASE WHEN R.order_item_review_rating >= 4.5 THEN 1 ELSE 0 END) AS excellent,
      SUM(CASE WHEN R.order_item_review_rating >= 3.5 AND R.order_item_review_rating < 4.5 THEN 1 ELSE 0 END) AS good,
      SUM(CASE WHEN R.order_item_review_rating >= 2.5 AND R.order_item_review_rating < 3.5 THEN 1 ELSE 0 END) AS average,
      SUM(CASE WHEN R.order_item_review_rating >= 1.5 AND R.order_item_review_rating < 2.5 THEN 1 ELSE 0 END) AS poor,
      SUM(CASE WHEN R.order_item_review_rating < 1.5 THEN 1 ELSE 0 END) AS verypoor
    FROM Order_Item_Review R
    JOIN Order_Items OI ON R.order_item_id = OI.order_item_id
    JOIN Product_Variants PV ON OI.order_item_variant_id = PV.variant_id
    WHERE PV.variant_product_id = @productId;
  `);

  return (
    result.recordset[0] || {
      total_reviews: 0,
      average_rating: 0,
      excellent: 0,
      good: 0,
      average: 0,
      poor: 0,
      verypoor: 0,
    }
  );
};

export const createReviewComment = async (params: CreateCommentParams) => {
  const pool = await poolPromise;
  const request = pool.request();

  request.input("reviewId", Int, params.reviewId);
  request.input("parentCommentId", Int, params.parentCommentId || null);
  request.input("commenterType", VarChar(20), params.commenterType);
  request.input("commenterId", Int, params.commenterId);
  request.input("commentText", VarChar, params.commentText);

  const query = `
    INSERT INTO Review_Comments (
      review_id,
      parent_comment_id,
      commenter_type,
      commenter_id,
      comment_text,
      created_at
    )
    OUTPUT INSERTED.*
    VALUES (
      @reviewId,
      @parentCommentId,
      @commenterType,
      @commenterId,
      @commentText,
      GETDATE()
    )
  `;

  const result = await request.query(query);
  return result.recordset[0];
};

export const createOrUpdateReaction = async (payload: ReactionPayload) => {
  const pool = await poolPromise;

  // Step 1: Validate reactor existence
  const validationQuery =
    payload.reactorType === "user"
      ? "SELECT 1 FROM Users WHERE user_id = @reactorId"
      : "SELECT 1 FROM Shops WHERE shop_id = @reactorId";

  const validationReq = pool.request();
  validationReq.input("reactorId", Int, payload.reactorId);

  const validationResult = await validationReq.query(validationQuery);
  if (validationResult.recordset.length === 0) {
    throw new Error(
      payload.reactorType === "user"
        ? `User with ID ${payload.reactorId} does not exist`
        : `Shop with ID ${payload.reactorId} does not exist`
    );
  }

  // Step 2: Prepare for upsert with updated_at
  const request = pool.request();
  request.input("commentId", Int, payload.commentId);
  request.input("reactorType", VarChar(20), payload.reactorType);
  request.input("reactorId", Int, payload.reactorId);
  request.input("reactionType", VarChar(10), payload.reactionType);

  const query = `
    MERGE Review_Comment_Reactions AS target
    USING (
      SELECT @commentId AS comment_id, @reactorType AS reactor_type, @reactorId AS reactor_id
    ) AS source
    ON target.comment_id = source.comment_id 
       AND target.reactor_type = source.reactor_type 
       AND target.reactor_id = source.reactor_id
    WHEN MATCHED THEN 
      UPDATE SET reaction_type = @reactionType, updated_at = GETDATE()
    WHEN NOT MATCHED THEN
      INSERT (comment_id, reactor_type, reactor_id, reaction_type, created_at)
      VALUES (@commentId, @reactorType, @reactorId, @reactionType, GETDATE())
    OUTPUT inserted.*;
  `;

  const result = await request.query(query);
  return result.recordset[0];
};

export const createOrUpdateReviewReaction = async (
  payload: ReviewReactionPayload
) => {
  const pool = await poolPromise;

  // Step 1: Validate existence of reactor (user/shop)
  const validationQuery =
    payload.reactorType === "user"
      ? "SELECT 1 FROM Users WHERE user_id = @reactorId"
      : "SELECT 1 FROM Shops WHERE shop_id = @reactorId";

  const validationReq = pool.request();
  validationReq.input("reactorId", Int, payload.reactorId);

  const validationResult = await validationReq.query(validationQuery);
  if (validationResult.recordset.length === 0) {
    throw new Error(
      payload.reactorType === "user"
        ? `User with ID ${payload.reactorId} does not exist`
        : `Shop with ID ${payload.reactorId} does not exist`
    );
  }

  // Step 2: Validate existence of the review
  const reviewValidationQuery = `
    SELECT 1 FROM Order_Item_Review WHERE order_item_review_id = @reviewId
  `;
  const reviewValidationReq = pool.request();
  reviewValidationReq.input("reviewId", Int, payload.reviewId);

  const reviewValidationResult = await reviewValidationReq.query(
    reviewValidationQuery
  );
  if (reviewValidationResult.recordset.length === 0) {
    throw new Error(`Review with ID ${payload.reviewId} does not exist`);
  }

  // Step 3: React to review (insert or update)
  const request = pool.request();
  request.input("reviewId", Int, payload.reviewId);
  request.input("reactorType", VarChar(20), payload.reactorType);
  request.input("reactorId", Int, payload.reactorId);
  request.input("reactionType", VarChar(10), payload.reactionType);
  request.input("reactionRemove", Int, Boolean(payload.reactionRemove) ? 1 : 0);

  const query = `
    IF @reactionRemove = 1
    BEGIN
      -- If reactionRemove is true, delete the existing reaction
      DELETE FROM Review_Reactions
      WHERE review_id = @reviewId
      AND reactor_type = @reactorType
      AND reactor_id = @reactorId;
    END
    ELSE
    BEGIN
      -- If reactionRemove is false, either insert or update the reaction
      MERGE Review_Reactions AS target
      USING (
        SELECT @reviewId AS review_id, @reactorType AS reactor_type, @reactorId AS reactor_id
      ) AS source
      ON target.review_id = source.review_id 
      AND target.reactor_type = source.reactor_type 
      AND target.reactor_id = source.reactor_id
      WHEN MATCHED THEN 
        UPDATE SET reaction_type = @reactionType, updated_at = GETDATE()
      WHEN NOT MATCHED THEN
        INSERT (review_id, reactor_type, reactor_id, reaction_type, created_at)
        VALUES (@reviewId, @reactorType, @reactorId, @reactionType, GETDATE())
      OUTPUT inserted.*;
    END
  `;

  const result = await request.query(query);
  return true;
};

export const getReviewReactionsGrouped = async (
  reviewIds: number[],
  currentUserId: number
) => {
  if (reviewIds.length === 0) return {};

  const pool = await poolPromise;
  const request = pool.request();

  reviewIds.forEach((id, index) => request.input(`reviewId${index}`, Int, id));
  request.input("currentUserId", Int, currentUserId);

  const idsSql = reviewIds.map((_, index) => `@reviewId${index}`).join(",");

  const query = `
    SELECT
      RR.review_id,
      SUM(CASE WHEN RR.reaction_type = 'like' THEN 1 ELSE 0 END) AS like_count,
      SUM(CASE WHEN RR.reaction_type = 'dislike' THEN 1 ELSE 0 END) AS dislike_count,
      (
        SELECT reaction_type FROM Review_Reactions
        WHERE review_id = RR.review_id AND reactor_type = 'user' AND reactor_id = @currentUserId
      ) AS self_reaction
    FROM Review_Reactions RR
    WHERE RR.review_id IN (${idsSql})
    GROUP BY RR.review_id;
  `;

  const result = await request.query(query);

  const map: Record<number, any> = {};
  for (const row of result.recordset) {
    map[row.review_id] = {
      likeCount: row.like_count,
      dislikeCount: row.dislike_count,
      selfReaction: row.self_reaction,
    };
  }

  return map;
};

export const getCommentReactionsGrouped = async (
  commentIds: number[],
  currentUserId: number
) => {
  if (commentIds.length === 0) return {};

  const pool = await poolPromise;
  const request = pool.request();

  commentIds.forEach((id, index) =>
    request.input(`commentId${index}`, Int, id)
  );
  request.input("currentUserId", Int, currentUserId);

  const idsSql = commentIds.map((_, index) => `@commentId${index}`).join(",");

  const query = `
    SELECT
      RC.comment_id,
      SUM(CASE WHEN RC.reaction_type = 'like' THEN 1 ELSE 0 END) AS like_count,
      SUM(CASE WHEN RC.reaction_type = 'dislike' THEN 1 ELSE 0 END) AS dislike_count,
      (
        SELECT reaction_type FROM Review_Comment_Reactions
        WHERE comment_id = RC.comment_id AND reactor_type = 'user' AND reactor_id = @currentUserId
      ) AS self_reaction
    FROM Review_Comment_Reactions RC
    WHERE RC.comment_id IN (${idsSql})
    GROUP BY RC.comment_id;
  `;

  const result = await request.query(query);

  const map: Record<number, any> = {};
  for (const row of result.recordset) {
    map[row.comment_id] = {
      likeCount: row.like_count,
      dislikeCount: row.dislike_count,
      selfReaction: row.self_reaction,
    };
  }

  return map;
};

export const getCommentsForReviewIds = async (reviewIds: number[]) => {
  if (reviewIds.length === 0) return [];

  const pool = await poolPromise;
  const request = pool.request();
  reviewIds.forEach((id, index) => request.input(`id${index}`, Int, id));
  const idsSql = reviewIds.map((_, index) => `@id${index}`).join(",");

  const query = `
    SELECT *
    FROM Review_Comments
    WHERE review_id IN (${idsSql})
    ORDER BY created_at ASC;
  `;

  const result = await request.query(query);
  return result.recordset;
};
export const getCommentReactionForReviewId = async (
  reviewId: number,
  userId?: number,
  userType?: string
) => {
  if (!reviewId) return { reactionCount: 0, selfReaction: false };

  const pool = await poolPromise;
  const request = pool.request();

  let query = `
    SELECT COUNT(*) AS reactionCount
    FROM Review_Reactions
    WHERE review_id = @reviewId;
  `;

  if (userId) {
    query = `
SELECT COUNT(*) AS reactionCount, 
       MAX(CASE 
            WHEN reactor_type = @userType AND reactor_id = @userId THEN 1 
            ELSE 0 
            END) AS selfReaction
FROM Review_Reactions
WHERE review_id = @reviewId;
    `;
  }

  const result = await request
    .input("reviewId", reviewId)
    .input("userId", userId)
    .input("userType", userType)
    .query(query);

  const { reactionCount, selfReaction } = result.recordset[0];

  return {
    reactionCount,
    selfReaction: userId ? selfReaction === 1 : false,
  };
};

export const getShopReviews = async (shop_id: number) => {
  try {
    const pool = await poolPromise;

    // Query to fetch the average rating and total reviews for the shop
    const query = `
      SELECT 
          AVG(R.order_item_review_rating) AS rating, 
          COUNT(R.order_item_review_id) AS total_reviews
      FROM Order_Item_Review R
      JOIN Order_Items OI ON R.order_item_id = OI.order_item_id
      JOIN Product_Variants PV ON OI.order_item_variant_id = PV.variant_id
      JOIN Products P ON PV.variant_product_id = P.product_id
      WHERE P.product_shop_id = @shop_id;
    `;

    // Execute the query
    const result = await pool.request().input("shop_id", shop_id).query(query);

    // Return the result in the required format
    const { rating, total_reviews } = result.recordset[0];

    return {
      rating: rating || 0, // If no rating is found, default to 0
      total_reviews: total_reviews || 0, // If no reviews are found, default to 0
    };
  } catch (error: any) {
    sendErrorEmail("Error fetching shop reviews:", error);

    console.error("Error fetching shop reviews:", error);
    throw new Error("Failed to fetch shop reviews");
  }
};
