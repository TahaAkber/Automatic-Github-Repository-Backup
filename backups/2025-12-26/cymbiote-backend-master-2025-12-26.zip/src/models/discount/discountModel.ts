import { poolPromise } from "../../config/db";
import { sendErrorEmail } from "../../services/emailService";
import { VariantsWithDiscount } from "../../types/discounts/VariantsWithDiscount";
import { OrderLineItem } from "../../types/order/OrderLineItem";

interface DiscountCode {
  discountCode: string;
  cartId: string;
  expireDate: Date;
}

export const checkVariantsForDiscount = async (
  variants: OrderLineItem[]
): Promise<VariantsWithDiscount[]> => {
  try {
    const variantShopifyIds = variants.map((v) => v.variant_id);

    const pool = await poolPromise;

    const query = `
    SELECT 
        PV.variant_shopify_id, 
        PV.variant_price, 
        PV.variant_discounted_price, 
        (PV.variant_price - PV.variant_discounted_price) AS variant_price_off
    FROM Product_Variants PV
    WHERE variant_shopify_id IN (${variantShopifyIds
      .map((id) => `'${id}'`)
      .join(",")})
    AND (PV.variant_discounted_price) > 0
`;

    const result = await pool.request().query(query);

    return result.recordset;
  } catch (error: any) {
    sendErrorEmail("Error fetching variants for discount in db:",error);

    throw new Error(
      "Error fetching variants for discount in db:" + error.message
    );
  }
};

export const getLatestDiscountId = async (): Promise<number> => {
  try {
    const pool = await poolPromise;
    const query = `SELECT MAX(cart_discount_id) as id from Cart_Discount_Codes;`;
    const result = await pool.request().query(query);

    return result.recordset[0].id;
  } catch (error: any) {
    sendErrorEmail("Error fetching last discoun id from db",error);

    throw new Error("Error fetching last discoun id from db" + error.message);
  }
};

export const getLatestVoucherId = async (): Promise<number> => {
  try {
    const pool = await poolPromise;
    const query = `SELECT MAX(voucher_id) as id from Vouchers;`;
    const result = await pool.request().query(query);

    return result.recordset[0].id;
  } catch (error: any) {
    sendErrorEmail("Error fetching last discoun id from db" ,error);

    throw new Error("Error fetching last discoun id from db" + error.message);
  }
};

export const insertDiscountCode = async (
  discountCode: string,
  cartId: string,
  cartShopifyId: string,
  expireDate: Date,
  createdAt?: Date
) => {
  const pool = await poolPromise;

  // SQL Query to insert data into the Discount_Codes table
  const query = `
      INSERT INTO Cart_Discount_Codes (cart_discount_code, cart_discount_cart_id, cart_discount_shopify_id, cart_discount_expire_date, created_at)
      VALUES (@discountCode, @cartId, @cartShopifyId, @expireDate, @createdAt)
    `;

  try {
    const result = await pool
      .request()
      .input("discountCode", discountCode)
      .input("cartId", cartId)
      .input("cartShopifyId", cartShopifyId)
      .input("expireDate", expireDate)
      .input("createdAt", createdAt ? createdAt : new Date())
      .query(query);

    console.log("Discount code inserted successfully, Code", discountCode);
    return result; // Return the result (or handle the inserted data as necessary)
  } catch (error: any) {
    sendErrorEmail("Error inserting discount code:", error);

    console.error("Error inserting discount code:", error);
    throw new Error("Failed to insert discount code");
  }
};
