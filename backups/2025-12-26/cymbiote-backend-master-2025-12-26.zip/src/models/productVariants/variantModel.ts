import { poolPromise } from "../../config/db";
import { sendErrorEmail } from "../../services/emailService";

export interface UpdateVariantPrice {
  id: number; // Variant ID in the database
  newPrice: number; // New price for the variant
}

export const getVariantsUsingShopifyPVId = async (
  shopifyVariantIds: string[]
) => {
  const pool = await poolPromise;
  const query = `
    SELECT variant_id, variant_shopify_id, variant_price, variant_quantity, variant_name, variant_product_id, variant_inventory_id, variant_image_url
    FROM Product_Variants
    WHERE variant_shopify_id IN (${shopifyVariantIds
      .map((_, i) => `@id${i}`)
      .join(",")})
    `;

  const params = shopifyVariantIds.reduce<{ [key: string]: string }>(
    (acc, id, index) => {
      acc[`id${index}`] = id;
      return acc;
    },
    {}
  );

  const variantsReq = await pool.request();

  for (const key in params) {
    variantsReq.input(
      key,
      "gid://shopify/ProductVariant/" + params[key].toString()
    );
  }

  const dbVariants = await variantsReq.query(query);
  // console.log("variant model", dbVariants);
  return dbVariants.recordset;
};

export const updateVariantPriceUsingVariantId = async (
  updatePriceVariants: UpdateVariantPrice[]
): Promise<void> => {
  try {
    // Get the connection pool
    const pool = await poolPromise;

    if (updatePriceVariants.length === 0) {
      console.log("No variants to update.");
      return;
    }

    // Dynamically construct the CASE statement for the query
    const updateCases = updatePriceVariants
      .map(
        (variant, index) => `WHEN variant_id = @id${index} THEN @price${index}`
      )
      .join(" ");

    // Construct the IN clause for the WHERE condition
    const variantIds = updatePriceVariants
      .map((_, index) => `@id${index}`)
      .join(", ");

    // Final SQL query
    const query = `
        UPDATE Product_Variants
        SET updated_at = GETDATE(),variant_price = CASE ${updateCases} END
        WHERE variant_id IN (${variantIds});
      `;

    // Create a SQL request
    const request = pool.request();

    // Add parameters for each variant
    updatePriceVariants.forEach((variant, index) => {
      request.input(`id${index}`, variant.id);
      request.input(`price${index}`, variant.newPrice);
    });
    console.log("updatePriceVariants", updatePriceVariants);

    // Execute the query
    await request.query(query);

    console.log("Bulk update completed successfully.");
  } catch (error: any) {
    sendErrorEmail("Error performing bulk update:", error);

    console.error("Error performing bulk update:", error);
    throw new Error("Failed to perform bulk update.");
  }
};

// updateVariantsInDB;

export const insertVariantsInDB = async (variants: any[]) => {
  try {
    const pool = await poolPromise;

    if (variants.length === 0) {
      console.log("⚠️ No New variants to insert.");
      return;
    }

    const transformedVariants = variants.map((variant) => ({
      variant_shopify_id: variant.admin_graphql_api_id,
      variant_price: parseFloat(variant.price),
      variant_quantity: variant.inventory_quantity,
      variant_name: variant.title,
      variant_product_id: variant.variant_product_id,
      variant_inventory_id: `gid://shopify/InventoryItem/${variant.inventory_item_id}`,
    }));

    console.log("🔄 Transformed Variants for Insert:", transformedVariants);

    // **Extract column names dynamically**
    const columns = Object.keys(transformedVariants[0]).join(", ");
    const valuesPlaceholders = transformedVariants
      .map(
        (_, index) =>
          `(${Object.keys(transformedVariants[0])
            .map((col) => `@${col}${index}`)
            .join(", ")})`
      )
      .join(", ");

    const query = `
      INSERT INTO Product_Variants (${columns})
      VALUES ${valuesPlaceholders};
    `;

    const request = pool.request();

    transformedVariants.forEach((variant, index) => {
      Object.entries(variant).forEach(([key, value]) => {
        request.input(`${key}${index}`, value);
      });
    });

    await request.query(query);

    console.log(
      `✅ Successfully inserted ${transformedVariants.length} new variants.`
    );
  } catch (error: any) {
    sendErrorEmail("❌ Error inserting new variants:", error);

    console.error("❌ Error inserting new variants:", error);
    throw new Error("Failed to insert new variants.");
  }
};

export const updateProductsVariantsMetafields = async (
  variantShopifyId: string,
  options: any[]
) => {
  try {
    const pool = await poolPromise;
    const query = `
      UPDATE Product_Variants
      SET 
        variant_option_key_one = @variant_option_key_one,
        variant_option_value_one = @variant_option_value_one,
        variant_option_key_two = @variant_option_key_two,
        variant_option_value_two = @variant_option_value_two,
        variant_option_key_third = @variant_option_key_third,
        variant_option_value_third = @variant_option_value_third,
        updated_at = GETDATE()
      WHERE variant_shopify_id = @variant_shopify_id;
    `;

    const request = pool.request();
    request.input("variant_shopify_id", variantShopifyId);
    request.input("variant_option_key_one", options[0]?.name || null);
    request.input("variant_option_value_one", options[0]?.value || null);
    request.input("variant_option_key_two", options[1]?.name || null);
    request.input("variant_option_value_two", options[1]?.value || null);
    request.input("variant_option_key_third", options[2]?.name || null);
    request.input("variant_option_value_third", options[2]?.value || null);

    const response = await request.query(query);
    console.log(
      `✅ Successfully updated Product_Variants metafields for variant ID: ${variantShopifyId}`
    );
    return response.rowsAffected;
  } catch (error: any) {
    sendErrorEmail("❌ Error updating Product_Variants metafields:", error);

    console.error("❌ Error updating Product_Variants metafields:", error);
    throw new Error("Failed to update Product_Variants metafields.");
  }
};

export const fetchProductVariantID = async (order_id: string) => {
  const pool = await poolPromise;
  const query = `
  SELECT oi.order_item_variant_id, pv.variant_image_url
  FROM Order_Items oi
  JOIN Product_Variants pv 
    ON oi.order_item_variant_id = pv.variant_id 
  WHERE oi.order_id = @order_id;
`;
  try {
    const result = await pool
      .request()
      .input("order_id", order_id)
      .query(query);
    return result.recordset[0]?.variant_image_url;
  } catch (error: any) {
    sendErrorEmail("Error fetching product variant ID:", error);

    console.error("Error fetching product variant ID:", error);
    throw new Error("Failed to fetch product variant ID.");
  }
};

export const updateVariantImage = async (
  variantShopifyId: string,
  imageUrl: string
) => {
  try {
    const pool = await poolPromise;
    console.log("updateVariantImage", variantShopifyId, imageUrl);
    const query = `
      UPDATE Product_Variants
      SET variant_image_url = @imageUrl, updated_at = GETDATE()
      WHERE variant_shopify_id = @variantShopifyId;
    `;

    const request = pool.request();
    request.input("variantShopifyId", variantShopifyId);
    request.input("imageUrl", imageUrl);

    const response = await request.query(query);
    return response.rowsAffected[0] > 0;
  } catch (error: any) {
    sendErrorEmail("Error updating variant image:", error);
    console.error("Error updating variant image:", error);
    // Don't throw, just log. Image update failure isn't critical.
    return false;
  }
};

export const getVariantsByProductId = async (productId: number) => {
  const pool = await poolPromise;
  const query = `
    SELECT variant_id, variant_shopify_id, variant_image_url
    FROM Product_Variants 
    WHERE variant_product_id = @productId AND variant_is_active = 1
  `;
  // Assuming default is active 1.

  const request = pool.request();
  request.input("productId", productId);
  const result = await request.query(query);
  return result.recordset;
};

export const markVariantsInactive = async (variantIds: number[]) => {
  const pool = await poolPromise;
  if (!variantIds || variantIds.length === 0) return 0;

  const paramNames = variantIds.map((_, index) => `@id${index}`).join(", ");
  const query = `
        UPDATE Product_Variants
        SET variant_is_active = 0, updated_at = GETDATE()
        WHERE variant_id IN (${paramNames});
    `;

  const request = pool.request();
  variantIds.forEach((id, index) => {
    request.input(`id${index}`, id);
  });

  const result = await request.query(query);
  return result.rowsAffected[0];
};
