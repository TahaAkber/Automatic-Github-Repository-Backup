import { poolPromise } from "../../config/db";
import { sendErrorEmail } from "../../services/emailService";
import { Address } from "../../types/address";

export const createAddress = async (address: Address): Promise<void> => {
  const pool = await poolPromise;
  const {
    address_user_id,
    address_first_name,
    address_last_name,
    address_country,
    address_one,
    address_two,
    address_city,
    address_postal_code,
    address_number,
    address_default_select,
  } = address;

  const query = `
      INSERT INTO User_Address (
        address_user_id, 
        address_first_name, 
        address_last_name, 
        address_one, 
        address_two,
        address_city,
        address_country,
        address_postal_code,
        address_number,
        address_default_select,
        created_at
      )
      VALUES (
        @address_user_id,
        @address_first_name, 
        @address_last_name,  
        @address_one, 
        @address_two,
        @address_city,
        @address_country,
        @address_postal_code,
        @address_number,
        @address_default_select,
        GETDATE()
      );
    `;

  await pool
    .request()
    .input("address_user_id", address_user_id)
    .input("address_first_name", address_first_name)
    .input("address_last_name", address_last_name)
    .input("address_one", address_one)
    .input("address_two", address_two)
    .input("address_city", address_city)
    .input("address_country", address_country)
    .input("address_postal_code", address_postal_code)
    .input("address_number", address_number)
    .input("address_default_select", address_default_select)
    .query(query);
};

export const updateUserAddress = async (address: Address): Promise<void> => {
  const pool = await poolPromise;
  const {
    address_id,
    address_first_name,
    address_last_name,
    address_country,
    address_one,
    address_two,
    address_city,
    address_postal_code,
    address_number,
  } = address;

  const query = `
    UPDATE User_Address
    SET 
      address_first_name = @address_first_name,
      address_last_name = @address_last_name,
      address_country = @address_country,
      address_city = @address_city,
      address_one = @address_one,
      address_two = @address_two,
      address_postal_code = @address_postal_code,
      address_number = @address_number,
      updated_at = GETDATE()
    WHERE address_id = @address_id;
  `;

  await pool
    .request()
    .input("address_first_name", address_first_name)
    .input("address_last_name", address_last_name)
    .input("address_country", address_country)
    .input("address_one", address_one)
    .input("address_two", address_two)
    .input("address_city", address_city)
    .input("address_postal_code", address_postal_code)
    .input("address_number", address_number)
    .input("address_id", address_id)
    .query(query);
};

// Get the total number of active shops (for pagination info)
export const getUserAddressCount = async (user_id: number) => {
  const pool = await poolPromise;
  const query = `
    SELECT COUNT(*) as count
    FROM User_Address
    WHERE address_user_id = @user_id
  `;
  const result = await pool.request().input("user_id", user_id).query(query);
  return result.recordset[0].count;
};

export const fetchAddress = async (
  user_id: number,
  page = 0,
  pageSize = 10
): Promise<any[]> => {
  const pool = await poolPromise;

  // Calculate the offset (for pagination) 
  const offset = (page - 1) * pageSize;

  const query = `
    SELECT * FROM User_Address
    WHERE address_user_id = ${user_id}
    ORDER BY created_at DESC
    OFFSET ${offset} ROWS
    FETCH NEXT ${pageSize} ROWS ONLY;
  `;

  const result = await pool.request().query(query);

  return result.recordset || [];
};

export const fetchAddressDetail = async (
  address_id: number
): Promise<any[]> => {
  const pool = await poolPromise;

  const query = `
    SELECT * FROM User_Address
    WHERE address_id = ${address_id}
  `;

  const result = await pool.request().query(query);

  return result.recordset?.[0] || {};
};

export const setDefaultAddress = async (
  user_id: number,
  address_id: number
): Promise<any> => {
  const pool = await poolPromise;

  const result = await pool
    .request()
    .input("UserId", user_id)
    .input("AddressId", address_id)
    .execute("SetDefaultAddress"); // Execute the stored procedure

  return result.recordset || {};
};

export const deleteAddress = async (address_id: number): Promise<void> => {
  const pool = await poolPromise;

  const query = `
    DELETE FROM User_Address
    WHERE address_id = ${address_id};
  `;

  await pool.request().query(query);
};

export const deleteUserandmarkedAsDisabled = async (userId: number) => {
  const pool = await poolPromise;

  const query = `
    UPDATE Users
    SET 
      user_is_disabled = 1,
      user_email = user_email + '-old'
    WHERE user_id = @userId;
  `;

  try {
    const result = await pool.request().input("userId", userId).query(query);
    return result.rowsAffected[0] > 0;
  } catch (error:any) {
    sendErrorEmail("Error disabling user:", error);

    console.error("Error disabling user:", error);
    throw error;
  }
};
