import sql from "mssql";
import { poolPromise } from "../../config/db";
import {
  getMerchantNotificationPreference,
  getShopFollowingStatus,
  getShopReviewsStats,
} from "../../functions/shop";
import { isShopHaveStories } from "../../services/reelsAndStories";
import {
  Collection,
  CollectProduct,
  Product,
  Shop,
  SortBy,
  SortOrder,
} from "../../types/Shop";
import { getShopReviews } from "../reviews/reviewsModel";
import {
  getProductReview,
  getUsingProductVariantId,
} from "../products/productModel";
import { sendErrorEmail } from "../../services/emailService";

export const getShop = async (shopDomain: string): Promise<Shop[]> => {
  const pool = await poolPromise;

  try {
    const query = `
      SELECT 
        s.*,
        p.package_rate
      FROM 
        Shops s
      JOIN 
        Subscriptions sub ON s.shop_id = sub.subscription_shop_id
      JOIN 
        Packages p ON sub.subscription_package_id = p.package_id
      WHERE 
        sub.subscription_confirmed = 1 AND
        sub.subscription_enabled = 1 AND
        s.shop_domain = @shopDomain;
    `;

    const result = await pool
      .request()
      .input("shopDomain", shopDomain)
      .query(query);

    console.log("shop domain: " + shopDomain);
    return result.recordset;
  } catch (error: any) {
    console.error("Error fetching shop for domain:", shopDomain, error);
    throw new Error("Failed to fetch shop: " + error.message);
  }
};

export const getShopFromOtherDomain = async (
  shopDomain: string
): Promise<Shop[]> => {
  const pool = await poolPromise;
  try {
    const query = `
      SELECT 
        s.*,
        p.package_rate
      FROM 
        Shops s
      JOIN 
        Subscriptions sub ON s.shop_id = sub.subscription_shop_id
      JOIN 
        Packages p ON sub.subscription_package_id = p.package_id
      WHERE 
        s.shop_other_domains LIKE @shopDomain
    `;

    // Use parameterized query to prevent SQL injection
    const result = await pool
      .request()
      .input("shopDomain", `%${shopDomain}%`)
      .query(query);

    console.log("shop other domain: " + shopDomain);
    return result.recordset;
  } catch (error: any) {
    console.error("Error fetching shop by other domain:", error);
    throw new Error(
      "Failed to fetch shop for domain " + shopDomain + ": " + error.message
    );
  }
};

export const getShopByDomain = async (shopDomain: string) => {
  console.log("shopDomain", shopDomain);
  const pool = await poolPromise;
  const query = `SELECT 
    s.*
  FROM
    Shops s
  WHERE 
    s.shop_domain = @shopDomain`;
  try {
    const result = await pool
      .request()
      .input("shopDomain", shopDomain)
      .query(query);
    console.log("shop domain: " + shopDomain);
    return result.recordset[0];
  } catch (error: any) {
    sendErrorEmail("Error fetching Shop By Domain", error);

    throw new Error("Error fetching Shop By Domain");
  }
};

export const updateShopCreds = async (shopId: number, billingDate: string) => {
  const pool = await poolPromise;

  try {
    const query = `SELECT * FROM Merchant_Credits WHERE credit_shop_id = @shopId`;
    const result = await pool.request().input("shopId", shopId).query(query);
    const response = result.recordset;

    const billingDateObj = new Date("2025-08-17T08:02:02Z");
    if (isNaN(billingDateObj.getTime())) {
      throw new Error("Invalid billingDate provided");
    }

    const dateNow = new Date();
    const billingDay = billingDateObj.getUTCDate();
    const dayNow = dateNow.getUTCDate();

    let startDate = new Date(billingDateObj);
    let endDate = new Date(billingDateObj);

    if (dayNow <= billingDay) {
      endDate.setMonth(billingDateObj.getMonth() - 1);
    } else {
      startDate.setMonth(billingDateObj.getMonth() + 1);
    }

    const filteredCredits = response.filter((t) => {
      const createdAt = new Date(t.created_at);
      return createdAt >= startDate && createdAt < endDate;
    });

    const totalCredit = filteredCredits.reduce(
      (sum, t) => sum + (t.credit_amount || 0),
      0
    );

    console.log("credits", totalCredit);

    if (response.length > 0) {
      const updateQuery = `UPDATE Shops SET shop_credits = @totalCredit WHERE shop_id = @shopId`;
      await pool
        .request()
        .input("shopId", shopId)
        .input("totalCredit", totalCredit)
        .query(updateQuery);
    }

    return { filteredCredits, totalCredit };
  } catch (error: any) {
    sendErrorEmail("Error updating Shop Creds", error);
    throw new Error("Error updating Shop Creds: " + error.message);
  }
};

export const checkIfAllShopsAreShown = async (
  updatedShopIdsArray: number[]
) => {
  try {
    // Check if all the `updatedShopIds` are present in the database
    const pool = await poolPromise;
    const checkQuery = `
        SELECT COUNT(*) AS unmatchedCount
        FROM Shops S
        WHERE shop_id NOT IN (${updatedShopIdsArray.join(",")})
        AND shop_is_active = 1 
        AND shop_delisted = 0
        AND EXISTS (
            SELECT 1 
            FROM Products P 
            WHERE P.product_shop_id = S.shop_id
        );
      `;

    const result = await pool.request().query(checkQuery);
    return result.recordset[0].unmatchedCount;
  } catch (error: any) {
    sendErrorEmail("Fetching all active shop count ", error);

    throw new Error("Fetching all active shop count " + error.message);
  }
};

export const searchShopsFromDB = async (
  searchTerm: string,
  page = 0,
  pageSize = 3
) => {
  const offset = (page - 1) * pageSize;

  try {
    let query = ``;

    // Common filter to ensure shop has at least one published product
    const publishedProductCheck = `
      AND EXISTS (
        SELECT 1 
        FROM Products p 
        WHERE p.product_shop_id = s.shop_id 
        AND p.product_is_active = 1
      )
    `;

    if (searchTerm) {
      query = `
        SELECT
          s.*,
        CASE 
            WHEN s.shop_name LIKE '%${searchTerm}%' THEN 1
            ELSE 2
        END AS priority
        FROM Shops s
        WHERE
        s.shop_is_active = 1
        AND s.shop_delisted = 0
        AND s.shop_name LIKE '%${searchTerm}%'
        ${publishedProductCheck} -- <-- Added Check Here
        ORDER BY priority, s.created_at DESC
        OFFSET ${offset} ROWS
        FETCH NEXT ${pageSize} ROWS ONLY;
      `;
    } else {
      query = `
        SELECT
        s.*,
        CASE 
            WHEN s.shop_rating > 3.8 THEN 1
            ELSE 2
        END AS priority
        FROM Shops s 
        WHERE
        s.shop_is_active = 1
        AND s.shop_delisted = 0
        ${publishedProductCheck} -- <-- Added Check Here
        ORDER BY priority, s.created_at DESC
        OFFSET ${offset} ROWS
        FETCH NEXT ${pageSize} ROWS ONLY;
      `;
    }

    const pool = await poolPromise;
    const result = await pool.request().query(query);

    return result.recordset;
  } catch (error: any) {
    sendErrorEmail("Fetching shops from db ", error);
    throw new Error("Fetching shops from db " + error.message);
  }
};

export const searchShopsCount = async (searchTerm?: string) => {
  const pool = await poolPromise;
  try {
    let query = ``;

    // Same check for the count query to keep pagination in sync
    const publishedProductCheck = `
      AND EXISTS (
        SELECT 1 
        FROM Products p 
        WHERE p.product_shop_id = s.shop_id 
        AND p.product_is_active = 1
      )
    `;

    if (searchTerm) {
      query = `
        SELECT COUNT(shop_id) as count
        FROM Shops s
        WHERE 
        s.shop_is_active = 1 AND s.shop_delisted = 0
        AND s.shop_name LIKE '%${searchTerm}%'
        ${publishedProductCheck}          
      `;
    } else {
      query = `
        SELECT COUNT(shop_id) as count
        FROM Shops s 
        WHERE
        s.shop_is_active = 1
        AND s.shop_delisted = 0
        ${publishedProductCheck}
      `;
    }

    const result = await pool.request().query(query);
    return result.recordset[0].count;
  } catch (error: any) {
    sendErrorEmail("Count Fetch ", error);
    throw new Error("Count Fetch " + error.message);
  }
};

export const getAllActiveShopsWithPagination = async (
  pageSize: number,
  categories = "",
  shownShopIds = ""
) => {
  const pool = await poolPromise;
  let query;

  // Calculate offset for pagination

  query = `
    SELECT TOP ${pageSize}
        S.*,
        CASE 
            WHEN EXISTS (
                SELECT 1
                FROM Store_Selected_Categories SC
                WHERE SC.store_selected_shop_id = S.shop_id
                  AND SC.store_selected_category_id IN (${categories})
            ) THEN 1
            ELSE 2
        END AS priority
    FROM Shops S
    WHERE S.shop_is_active = 1
      AND S.shop_delisted   = 0
      ${shownShopIds ? `AND S.shop_id NOT IN (${shownShopIds})` : ``}
      AND EXISTS (
            SELECT 1
            FROM Products P
            WHERE P.product_shop_id = S.shop_id
      )
    ORDER BY
        priority,
        S.shop_rating DESC;
  `;

  const result = await pool.request().query(query);

  // if (onlyShops) {
  //   return result.recordset;
  // }

  const oldShopIds: number[] = shownShopIds
    ? shownShopIds.split(",").map((id) => Number(id))
    : [];

  const newShopIds: number[] = result.recordset.map((shop: any) => {
    return shop.shop_id;
  });

  const combinedShopIds = [...oldShopIds, ...newShopIds];

  console.log("combinedShopIds", combinedShopIds);

  const finalResult = await Promise.all(
    result.recordset.map(async (item) => {
      try {
        const rating = await getShopRating(item.shop_id);
        const shopHaveStory = await isShopHaveStories(item.shop_id);

        return {
          ...item,
          rating: rating,
          shopHaveStory: shopHaveStory,
        };
      } catch (error: any) {
        sendErrorEmail("error in final result", error);

        return item;
      }
    })
  );

  return { finalResult, shownShopIds: combinedShopIds.join(",") };
};
export const getShopRating = async (shop_id: number) => {
  const pool = await poolPromise;
  const query = `
    SELECT shop_rating as rating
    FROM Shops
    WHERE shop_id = @shop_id;
  `;
  try {
    const result = await pool.request().input("shop_id", shop_id).query(query);
    return result.recordset[0].rating;
  } catch (error: any) {
    sendErrorEmail("Error fetching rating:", error);

    console.log("Error fetching rating:", error);
  }
};
// Get the total number of active shops (for pagination info)
export const getShopsCount = async () => {
  const pool = await poolPromise;
  let query = `
    SELECT COUNT(shop_id) AS count FROM Shops S where shop_is_active = 1 AND shop_delisted = 0 AND EXISTS (
      SELECT 1
      FROM Products P
      WHERE P.product_shop_id = S.shop_id
    );
  `;

  const result = await pool.request().query(query);
  return result.recordset[0].count;
};

export const getShopFilter = async (shop_id: number) => {
  const pool = await poolPromise;

  // Step 1: Get collections associated with the shop
  const query = `
    SELECT *
    FROM Collections
    WHERE collection_type_id = 3 AND collection_shop_id = ${shop_id}
  `;
  const result = await pool.request().query(query);

  // Step 2: Map the collections data to match the previous structure
  const collections = result.recordset.map((collection: any) => ({
    filter_option_id: collection.collection_id,
    filter_option_value: collection.collection_name,
    filter_option_shop_filter_id: collection.collection_type_id,
    filter_option_shopify_id: collection.collection_shopify_id,
    created_at: collection.created_at,
    updated_at: collection.created_at,
  }));

  return collections;
};

export const getShopDetailsByShopId = async (
  shopId: number
): Promise<Shop | null> => {
  const pool = await poolPromise;
  console.log("getShopDetailsByShopId", shopId);

  try {
    const query = `
      SELECT shop_id, shop_access_token, shop_domain, shop_name, shop_shopify_id, shop_logo_url
      FROM Shops
      WHERE shop_id = @shopId;
    `;

    const result = await pool
      .request()
      .input("shopId", shopId)
      .query<Shop>(query);

    console.log("getShopDetails result:", result);

    // Return the shop details if found, else return null
    return result.recordset.length > 0 ? result.recordset[0] : null;
  } catch (error: any) {
    sendErrorEmail("Error fetching shop details:", error);

    console.error("Error fetching shop details:", error);
    throw new Error("Failed to get shop details");
  }
};

export const getShopWithActiveSubByShopId = async (
  shopId: number
): Promise<Shop | null> => {
  const pool = await poolPromise;
  console.log("getShopWithActiveSubByShopId", shopId);

  try {
    const query = `
      SELECT shop_id, shop_access_token, shop_domain, shop_name, shop_shopify_id, shop_logo_url, shop_currency, sub.subscription_id
      FROM Shops s JOIN Subscriptions sub ON s.shop_id = sub.subscription_shop_id
      WHERE sub.subscription_confirmed = 1 AND sub.subscription_enabled = 1 AND shop_id = @shopId;
    `;

    const result = await pool
      .request()
      .input("shopId", shopId)
      .query<Shop>(query);

    console.log("getShopDetails result:", result);

    // Return the shop details if found, else return null
    return result.recordset.length > 0 ? result.recordset[0] : null;
  } catch (error: any) {
    sendErrorEmail("Error fetching shop details with subscription:", error);

    console.error("Error fetching shop details with subscription:", error);
    throw new Error("Failed to get shop details with subscription");
  }
};

export const fetchShopByCollectionShopId = async (collection_id: number) => {
  const pool = await poolPromise;
  const query = `
    SELECT 
      c.collection_shop_id,
      c.collection_id,
      s.shop_access_token,
      s.shop_domain 
    FROM Collections c
    JOIN Shops s ON c.collection_shop_id = s.shop_id
    WHERE c.collection_shopify_id = @collectionID;
  `;

  const collectionID = `gid://shopify/Collection/${collection_id}`;
  try {
    const response = await pool
      .request()
      .input("collectionID", collectionID)
      .query(query);
    return response.recordset;
  } catch (error: any) {
    sendErrorEmail("Error fetching shop details:", error);

    console.error("Error fetching shop details:", error);
    throw new Error("Failed to get shop details");
  }
};

export const getShopAccessCreds = async (
  shopIdentity: string | number
): Promise<{ shop_domain: string; shop_access_token: string }> => {
  const pool = await poolPromise;
  if (!shopIdentity) {
    throw new Error("Identifier is required");
  }
  try {
    let query = ``;

    if (typeof shopIdentity === "string") {
      // If it's a string, search by shop_domain
      query = `SELECT shop_domain, shop_access_token
                FROM Shops 
                WHERE shop_domain = @identifier`;
    } else if (typeof shopIdentity === "number") {
      // If it's a number, search by shop_id
      query = `SELECT shop_domain, shop_access_token
                FROM Shops 
                WHERE shop_id = @identifier`;
    }

    const response = await pool
      .request()
      .input("identifier", shopIdentity)
      .query(query);

    return response.recordset[0];
  } catch (error: any) {
    sendErrorEmail("Failed to fetch shop creds", error);

    throw new Error("Failed to fetch shop creds");
  }
};

export const getShopWithRatingUsingShopId = async (
  shop_identity: number | string,
  user_id?: number
) => {
  if (!shop_identity) {
    throw new Error("Identifier is required");
  }

  // Validate if identifier is either a number (shop_id) or string (shop_domain)
  if (typeof shop_identity !== "string" && typeof shop_identity !== "number") {
    throw new Error("Invalid identifier type");
  }
  try {
    const pool = await poolPromise;
    let query = "";
    if (typeof shop_identity === "string") {
      // If it's a string, search by shop_domain
      query = `SELECT * 
                FROM Shops 
                WHERE shop_domain = @identifier`;
    } else if (typeof shop_identity === "number") {
      // If it's a number, search by shop_id
      query = `SELECT * 
                FROM Shops 
                WHERE shop_id = @identifier`;
    }

    const dbShopResp = await pool
      .request()
      .input("identifier", shop_identity)
      .query(query);

    const shopData = dbShopResp.recordset[0];

    const shopReviews = await getShopReviews(shopData?.shop_id || 2);
    shopData.filters = await getShopFilter(shopData?.shop_id || 2);
    shopData.rating = shopReviews?.rating || 0;
    shopData.total_reviews = shopReviews?.total_reviews || 0;
    shopData.shopHaveStory = await isShopHaveStories(shopData?.shop_id); // ✅ Added this line
    if (user_id) {
      const followingStatus = await getShopFollowingStatus(
        shopData?.shop_id || 2,
        user_id
      );
      shopData.shop_following = followingStatus;

      console.log("followingStatus", followingStatus);
    }
    if (user_id) {
      const notificationPreference = await getMerchantNotificationPreference(
        shopData?.shop_id ?? 2,
        user_id
      );
      shopData.notification = notificationPreference;

      console.log("notificationPreference", notificationPreference);
    }

    return dbShopResp.recordset[0];
  } catch (error: any) {
    sendErrorEmail("Error fetching shop from database:", error);

    console.error("Error fetching shop from database:", error);
    throw new Error("Database query failed"); // Rethrow or handle the error as necessary
  }
};

export const getShopByProductShopifyId = async (shopifyProductId: string) => {
  const pool = await poolPromise;
  const query = `
    SELECT S.shop_id, S.shop_domain, S.shop_access_token FROM Products P
     JOIN Shops S ON P.product_shop_id = S.shop_id 
     where P.product_shopify_id = 'gid://shopify/Product/${shopifyProductId}'
  `;

  const result = await pool.request().query(query);
  return result.recordset[0];
};

export const getRandomShopCreds = async () => {
  try {
    const pool = await poolPromise;

    const query = `EXEC GetRandomShopAccessTokenAndDomain`;

    const request = await pool.request().query(query);

    return request.recordset[0];
  } catch (error: any) {
    sendErrorEmail("Failed to fetch random shop creds ", error);

    throw new Error("Failed to fetch random shop creds " + error.message);
  }
};

export const fetchCollections = async (id: any, type: string) => {
  try {
    const pool = await poolPromise;

    const query = `SELECT * FROM Collections where 
    collection_shop_id = @id AND collection_type_id = @typeId`;

    const response = await pool
      .request()
      .input("id", id)
      .input("typeId", type)
      .query(query);
    console.log("response", response);
    return response.recordset;
  } catch (error: any) {
    sendErrorEmail("Failed to fetch collections ", error);

    throw new Error("Failed to fetch collections " + error.message);
  }
};

export const fetchCollectionProductCategories = async (
  id?: any,
  type?: string
) => {
  const query = `
  SELECT DISTINCT p.product_custom_category
FROM Collections c 
JOIN Collection_Products cp ON c.collection_id = cp.collection_id 
JOIN products p ON cp.collection_local_product_id = p.product_id 
WHERE collection_shop_id = @id 
    AND collection_type_id = @type
    AND p.product_custom_category IS NOT NULL
    AND p.product_custom_category != ''
ORDER BY p.product_custom_category;
`;

  try {
    const pool = await poolPromise;
    if (id && type) {
      const response = await pool
        .request()
        .input("id", id)
        .input("type", type)
        .query(query);
      const mappedData = response.recordset.map(
        (item) => item.product_custom_category
      );
      return mappedData;
    } else if (id && !type) {
      const trendingResult = await pool.request().input("trendingId", id)
        .query(`
        SELECT trending_name
        FROM Trending_Collections
        WHERE trending_expiration_date > GETDATE()
          AND trending_id = @trendingId AND trending_is_active = 1
      `);

      if (trendingResult.recordset.length === 0)
        return {
          products: [],
          totalProducts: 0,
          totalPages: 0,
        };

      const trendingName = trendingResult.recordset[0].trending_name;

      const collectionResult = await pool
        .request()
        .input("collectionName", trendingName).query(`
        SELECT collection_id
        FROM Collections
        WHERE collection_name = @collectionName
      `);

      if (collectionResult.recordset.length === 0)
        return {
          products: [],
          totalProducts: 0,
          totalPages: 0,
        };

      const collectionIds = collectionResult.recordset.map(
        (r) => r.collection_id
      );

      const productRequest = pool.request();
      collectionIds.forEach((id, idx) =>
        productRequest.input(`cid${idx}`, sql.Int, id)
      );
      const collectionIdParams = collectionIds
        .map((_, idx) => `@cid${idx}`)
        .join(",");

      const productIdsResult = await productRequest.query(`
      SELECT DISTINCT collection_local_product_id
      FROM Collection_Products
      WHERE collection_id IN (${collectionIdParams})
    `);

      const productIds = productIdsResult.recordset.map(
        (r) => r.collection_local_product_id
      );
      const request = pool.request();
      productIds.forEach((id, idx) => request.input(`id${idx}`, sql.Int, id));
      const idParams = productIds.map((_, idx) => `@id${idx}`).join(",");
      let query = `
      SELECT DISTINCT p.product_custom_category
      FROM Products p
      WHERE p.product_id IN (${idParams}) AND product_is_active = 1
    `;
      const productResult = await request.query(query);
      const rawProductCategories = productResult.recordset || [];

      return rawProductCategories.map((item) => item.product_custom_category);
    }
  } catch (error: any) {
    sendErrorEmail("Failed to fetch product categories", error);

    throw new Error("Failed to fetch product categories" + error.message);
  }
};

export const fetchFilterCollectionProductCategories = async (
  collectionId: string
) => {
  const pool = await poolPromise;
  const query = `SELECT DISTINCT p.product_custom_category
    FROM Collection_Products
   JOIN Products p ON p.product_id=collection_local_product_id
    WHERE collection_id = @collectionId
    AND p.product_custom_category IS NOT NULL`;
  try {
    const response = await pool
      .request()
      .input("collectionId", collectionId)
      .query(query);
    const mappedData = response.recordset.map(
      (item) => item.product_custom_category
    );
    return mappedData;
  } catch (error: any) {
    sendErrorEmail("Failed to fetch product categories ", error);

    throw new Error("Failed to fetch product categories " + error.message);
  }
};

export const fetchTrendingCollections = async () => {
  try {
    const pool = await poolPromise;

    const query = `SELECT * FROM Trending_Collections TC
    WHERE TC.trending_expiration_date > GETDATE() AND trending_is_active = 1;`;

    const response = await pool.request().query(query);
    return response.recordset;
  } catch (error: any) {
    sendErrorEmail("Failed to fetch collections  ", error);

    throw new Error("Failed to fetch collections " + error.message);
  }
};
export const fetchTrendingCollectionById = async (
  trendingId: string,
  sortBy?: string[],
  sortOrder?: string[],
  minPrice?: number,
  maxPrice?: number,
  colors?: string[],
  minRating?: number,
  onSale?: boolean,
  sizes?: string[],
  sortPrice?: "ASC" | "DESC",
  page: number = 1,
  pageSize: number = 10
): Promise<{
  products: Product[];
  totalProducts: number;
  totalPages: number;
  currentPage: number;
  pageSize: number;
}> => {
  try {
    const pool = await poolPromise;
    const normalizedSizes = sizes?.map((s) => s.toUpperCase()) || [];

    const validSortFields = ["product_rating", "created_at"];
    const validSortOrders = ["ASC", "DESC"];

    const finalSortBy = sortBy?.every((f) => validSortFields.includes(f))
      ? sortBy
      : ["created_at"];
    const finalSortOrder = sortOrder?.every((o) => validSortOrders.includes(o))
      ? sortOrder
      : ["ASC"];

    const trendingResult = await pool.request().input("trendingId", trendingId)
      .query(`
        SELECT trending_name
        FROM Trending_Collections
        WHERE trending_expiration_date > GETDATE()
        AND trending_id = @trendingId AND trending_is_active = 1
      `);

    if (trendingResult.recordset.length === 0)
      return {
        products: [],
        totalProducts: 0,
        totalPages: 0,
        currentPage: page,
        pageSize,
      };

    const trendingName = trendingResult.recordset[0].trending_name;

    const collectionResult = await pool
      .request()
      .input("collectionName", trendingName).query(`
        SELECT collection_id
        FROM Collections
        WHERE collection_name = @collectionName
      `);

    if (collectionResult.recordset.length === 0)
      return {
        products: [],
        totalProducts: 0,
        totalPages: 0,
        currentPage: page,
        pageSize,
      };

    const collectionIds = collectionResult.recordset.map(
      (r) => r.collection_id
    );

    const productRequest = pool.request();
    collectionIds.forEach((id, idx) =>
      productRequest.input(`cid${idx}`, sql.Int, id)
    );
    const collectionIdParams = collectionIds
      .map((_, idx) => `@cid${idx}`)
      .join(",");

    const productIdsResult = await productRequest.query(`
      SELECT DISTINCT collection_local_product_id
      FROM Collection_Products
      WHERE collection_id IN (${collectionIdParams})
    `);

    const productIds = productIdsResult.recordset.map(
      (r) => r.collection_local_product_id
    );

    if (productIds.length === 0)
      return {
        products: [],
        totalProducts: 0,
        totalPages: 0,
        currentPage: page,
        pageSize,
      };

    const request = pool.request();
    productIds.forEach((id, idx) => request.input(`id${idx}`, sql.Int, id));
    const idParams = productIds.map((_, idx) => `@id${idx}`).join(",");

    let query = `
      SELECT 
          p.*,
          s.shop_currency AS product_currency,
          pi.product_image_url_low,
          pi.product_image_url_medium
      FROM Products p
      LEFT JOIN Shops s ON s.shop_id = p.product_shop_id
      OUTER APPLY (
          SELECT TOP 1 *
          FROM Product_Images pi
          ORDER BY pi.product_image_position ASC
          WHERE pi.product_image_product_id = p.product_id
      ) pi
      WHERE p.product_id IN (${idParams})
        AND p.product_is_active = 1
    `;

    if (minRating !== undefined) {
      query += ` AND product_rating >= @minRating`;
      request.input("minRating", sql.Float, minRating);
    }

    const sortClause = finalSortBy
      .map((field, idx) => {
        const order = finalSortOrder[idx] || "ASC";
        return `${field} ${order}`;
      })
      .join(", ");
    query += ` ORDER BY ${sortClause}`;

    const productResult = await request.query(query);
    const rawProducts = productResult.recordset || [];

    const filteredProducts = await Promise.all(
      rawProducts.map(async (product) => {
        const variants = await getUsingProductVariantId(product.product_id);

        const matchingVariants = variants.filter((v) => {
          let valid = true;

          if (minPrice !== undefined && maxPrice !== undefined) {
            valid =
              valid &&
              v.variant_price >= minPrice &&
              v.variant_price <= maxPrice;
          }

          if (onSale === true) {
            valid =
              valid &&
              v.variant_discounted_price > 0 &&
              v.variant_discounted_price < v.variant_price;
          }

          if (colors?.length) {
            valid =
              valid &&
              colors.some((color) =>
                (v.variant_name || "")
                  .toLowerCase()
                  .includes(color.toLowerCase())
              );
          }

          if (normalizedSizes.length) {
            valid =
              valid &&
              normalizedSizes.some((size) =>
                (v.variant_name || "").toUpperCase().includes(size)
              );
          }

          return valid;
        });

        if (matchingVariants.length === 0) return null;

        return {
          ...product,
          product_review: await getProductReview(product.product_id),
          product_variant: matchingVariants,
        };
      })
    );

    const allValidProducts = filteredProducts.filter(
      (p) => p !== null
    ) as Product[];

    // ✅ Sort by variant price (if requested)
    let sortedProducts = [...allValidProducts];
    if (sortPrice) {
      sortedProducts.sort((a, b) => {
        const aPrice = a.product_variant[0]?.variant_price ?? 0;
        const bPrice = b.product_variant[0]?.variant_price ?? 0;
        return sortPrice === "ASC" ? aPrice - bPrice : bPrice - aPrice;
      });
    }

    const totalProducts = sortedProducts.length;
    const totalPages = Math.ceil(totalProducts / pageSize);
    const paginatedProducts = sortedProducts.slice(
      (page - 1) * pageSize,
      page * pageSize
    );

    return {
      products: paginatedProducts,
      totalProducts,
      totalPages,
      currentPage: page,
      pageSize,
    };
  } catch (error: any) {
    sendErrorEmail("Error in service: Failed to fetch product details:", error);

    console.error("Error in service: Failed to fetch product details:", error);
    throw new Error("Failed to fetch product details: " + error.message);
  }
};

export const fetchCollectionDataById = async (
  collectionId: string,
  sortBy?: string[],
  sortOrder?: string[],
  minPrice?: number,
  maxPrice?: number,
  colors?: string[],
  minRating?: number,
  onSale?: boolean,
  sizes?: string[],
  sortPrice?: "ASC" | "DESC",
  page: number = 1,
  pageSize: number = 10
): Promise<{
  products: Product[];
  totalProducts: number;
  totalPages: number;
  currentPage: number;
  pageSize: number;
}> => {
  try {
    const pool = await poolPromise;
    const normalizedSizes = sizes?.map((s) => s.toUpperCase()) || [];

    const validSortFields = ["product_rating", "created_at"];
    const validSortOrders = ["ASC", "DESC"];

    const finalSortBy = sortBy?.every((f) => validSortFields.includes(f))
      ? sortBy
      : ["created_at"];
    const finalSortOrder = sortOrder?.every((o) => validSortOrders.includes(o))
      ? sortOrder
      : ["ASC"];

    const productRequest = pool.request().input("collectionId", collectionId);
    const productIdsResult = await productRequest.query(`
      SELECT DISTINCT collection_local_product_id
      FROM Collection_Products
      WHERE collection_id = @collectionId
    `);

    const productIds = productIdsResult.recordset.map(
      (r) => r.collection_local_product_id
    );

    if (productIds.length === 0)
      return {
        products: [],
        totalProducts: 0,
        totalPages: 0,
        currentPage: page,
        pageSize,
      };

    const request = pool.request();
    productIds.forEach((id, idx) => request.input(`id${idx}`, sql.Int, id));
    const idParams = productIds.map((_, idx) => `@id${idx}`).join(",");

    let query = `
      SELECT *
      FROM Products
      WHERE product_id IN (${idParams}) AND product_is_active = 1
    `;

    if (minRating !== undefined) {
      query += ` AND product_rating >= @minRating`;
      request.input("minRating", sql.Float, minRating);
    }

    const sortClause = finalSortBy
      .map((field, idx) => {
        const order = finalSortOrder[idx] || "ASC";
        return `${field} ${order}`;
      })
      .join(", ");
    query += ` ORDER BY ${sortClause}`;

    const productResult = await request.query(query);
    const rawProducts = productResult.recordset || [];

    const filteredProducts = await Promise.all(
      rawProducts.map(async (product) => {
        const variants = await getUsingProductVariantId(product.product_id);

        const matchingVariants = variants.filter((v) => {
          let valid = true;

          if (minPrice !== undefined && maxPrice !== undefined) {
            valid =
              valid &&
              v.variant_price >= minPrice &&
              v.variant_price <= maxPrice;
          }

          if (onSale === true) {
            valid =
              valid &&
              v.variant_discounted_price > 0 &&
              v.variant_discounted_price < v.variant_price;
          }

          if (colors?.length) {
            valid =
              valid &&
              colors.some((color) =>
                (v.variant_name || "")
                  .toLowerCase()
                  .includes(color.toLowerCase())
              );
          }

          if (normalizedSizes.length) {
            valid =
              valid &&
              normalizedSizes.some((size) =>
                (v.variant_name || "").toUpperCase().includes(size)
              );
          }

          return valid;
        });

        if (matchingVariants.length === 0) return null;

        return {
          ...product,
          product_review: await getProductReview(product.product_id),
          product_variant: matchingVariants,
        };
      })
    );

    const allValidProducts = filteredProducts.filter(
      (p) => p !== null
    ) as Product[];

    // ✅ Sort by variant price (if requested)
    let sortedProducts = [...allValidProducts];
    if (sortPrice) {
      sortedProducts.sort((a, b) => {
        const aPrice = a.product_variant[0]?.variant_price ?? 0;
        const bPrice = b.product_variant[0]?.variant_price ?? 0;
        return sortPrice === "ASC" ? aPrice - bPrice : bPrice - aPrice;
      });
    }

    const totalProducts = sortedProducts.length;
    const totalPages = Math.ceil(totalProducts / pageSize);
    const paginatedProducts = sortedProducts.slice(
      (page - 1) * pageSize,
      page * pageSize
    );

    return {
      products: paginatedProducts,
      totalProducts,
      totalPages,
      currentPage: page,
      pageSize,
    };
  } catch (error: any) {
    sendErrorEmail(
      "Error in service: Failed to fetch collection details:",
      error
    );

    console.error(
      "Error in service: Failed to fetch collection details:",
      error
    );
    throw new Error("Failed to fetch collection details: " + error.message);
  }
};

export const fetchFilteredCollectionDataById = async (
  collectionId: string,
  page: number = 1,
  pageSize: number = 10
): Promise<{
  products: Product[];
  totalProducts: number;
  totalPages: number;
  currentPage: number;
  pageSize: number;
}> => {
  try {
    const pool = await poolPromise;

    const productRequest = pool.request().input("collectionId", collectionId);
    const productIdsResult = await productRequest.query(`
      SELECT DISTINCT collection_local_product_id
      FROM Collection_Products
      WHERE collection_id = @collectionId
    `);

    const productIds = productIdsResult.recordset.map(
      (r) => r.collection_local_product_id
    );
    if (productIds.length === 0)
      return {
        products: [],
        totalProducts: 0,
        totalPages: 0,
        currentPage: page,
        pageSize,
      };

    const request = pool.request();
    productIds.forEach((id, idx) => request.input(`id${idx}`, sql.Int, id));
    const idParams = productIds.map((_, idx) => `@id${idx}`).join(",");

    let query = `
      SELECT 
          p.*,
          s.shop_currency AS product_currency
      FROM Products p
      LEFT JOIN Shops s ON s.shop_id = p.product_shop_id
      WHERE p.product_id IN (${idParams}) 
        AND p.product_is_active = 1
      ORDER BY p.created_at DESC;
    `;

    const productResult = await request.query(query);
    const rawProducts = productResult.recordset || [];

    const enrichedProducts = await Promise.all(
      rawProducts.map(async (product) => {
        return {
          ...product,
          product_review: await getProductReview(product.product_id),
          product_variant: await getUsingProductVariantId(product.product_id),
        };
      })
    );

    const totalProducts = enrichedProducts.length;
    const totalPages = Math.ceil(totalProducts / pageSize);
    const paginatedProducts = enrichedProducts.slice(
      (page - 1) * pageSize,
      page * pageSize
    );

    return {
      products: paginatedProducts,
      totalProducts,
      totalPages,
      currentPage: page,
      pageSize,
    };
  } catch (error: any) {
    sendErrorEmail(
      "Error in service: Failed to fetch collection details:",
      error
    );

    console.error(
      "Error in service: Failed to fetch collection details:",
      error
    );
    throw new Error("Failed to fetch collection details: " + error.message);
  }
};

export const ShopRepo = {
  async withTransaction<T>(fn: (tx: sql.Transaction) => Promise<T>) {
    const pool = await poolPromise;
    const tx = new sql.Transaction(pool);
    await tx.begin();
    try {
      const result = await fn(tx);
      await tx.commit();
      return result;
    } catch (e) {
      await tx.rollback();
      throw e;
    }
  },

  async getShopByDomain(shopDomain: string) {
    const pool = await poolPromise;
    const q = `SELECT TOP 1 shop_id, shop_domain FROM Shops WHERE shop_domain = @sd;`;
    const r = await pool
      .request()
      .input("sd", sql.NVarChar(255), shopDomain)
      .query(q);
    return r.recordset[0] || null;
  },

  // --- Core actions ---

  // If your Shops table has a token/secret column, clear it
  clearShopAccessToken(tx: sql.Transaction, shopId: number) {
    const req = new sql.Request(tx);
    return req.input("sid", sql.Int, shopId).query(`
        UPDATE Shops
        SET shop_access_token = NULL
        WHERE shop_id = @sid;
      `);
  },

  // Optional: if you have an "uninstalled" / "deleted_at" style column
  markShopUninstalled(tx: sql.Transaction, shopId: number) {
    const req = new sql.Request(tx);
    // adjust the column name if you keep uninstalled timestamp/flag
    return req
      .input("sid", sql.Int, shopId)
      .query(
        `
        UPDATE Shops
        SET shop_uninstalled_at = SYSUTCDATETIME()
        WHERE shop_id = @sid;
      `
      )
      .catch(() => Promise.resolve()); // ignore if column doesn't exist
  },

  // Delete app data tied to this shop (adjust table/column names to your DB)

  // Product_Images joined via product_id -> Products
  deleteProductImages(tx: sql.Transaction, shopId: number) {
    const req = new sql.Request(tx);
    return req
      .input("sid", sql.Int, shopId)
      .query(
        `
        DELETE pi
        FROM Product_Images pi
        INNER JOIN Products p ON p.product_id = pi.product_image_product_id
        WHERE p.product_shop_id = @sid;
      `
      )
      .catch(() => Promise.resolve()); // if table not present
  },

  // Product_Variants joined via product_id -> Products
  deleteProductVariants(tx: sql.Transaction, shopId: number) {
    const req = new sql.Request(tx);
    return req
      .input("sid", sql.Int, shopId)
      .query(
        `
        DELETE pv
        FROM Product_Variants pv
        INNER JOIN Products p ON p.product_id = pv.variant_product_id
        WHERE p.product_shop_id = @sid;
      `
      )
      .catch(() => Promise.resolve());
  },

  // Products owned by this shop
  deleteProducts(tx: sql.Transaction, shopId: number) {
    const req = new sql.Request(tx);
    return req
      .input("sid", sql.Int, shopId)
      .query(
        `
        DELETE FROM Products
        WHERE product_shop_id = @sid;
      `
      )
      .catch(() => Promise.resolve());
  },

  // Subscriptions for this shop
  deleteSubscriptions(tx: sql.Transaction, shopId: number) {
    const req = new sql.Request(tx);
    return req
      .input("sid", sql.Int, shopId)
      .query(
        `
        DELETE FROM Subscriptions
        WHERE subscription_shop_id = @sid;
      `
      )
      .catch(() => Promise.resolve());
  },

  // Product_Publishing_Request for this shop
  deletePublishingRequests(tx: sql.Transaction, shopId: number) {
    const req = new sql.Request(tx);
    return req
      .input("sid", sql.Int, shopId)
      .query(
        `
        DELETE FROM Product_Publishing_Request
        WHERE publishing_request_shop_id = @sid;
      `
      )
      .catch(() => Promise.resolve());
  },

  // Sessions tied to this shop (if you store them)
  deleteSessions(tx: sql.Transaction, shopId: number) {
    const req = new sql.Request(tx);
    return req
      .input("sid", sql.Int, shopId)
      .query(
        `
        DELETE FROM Sessions
        WHERE session_shop_id = @sid;
      `
      )
      .catch(() => Promise.resolve());
  },
};

export const getShopFollowers = async (shopId: number): Promise<number[]> => {
  const pool = await poolPromise;
  console.log(shopId, "shopId ><><");
  const result = await pool.request().input("shopId", sql.Int, shopId).query(`
      SELECT DISTINCT following_user_id
      FROM [cymbiote].[dbo].[User_Following]
      WHERE following_shop_id = @shopId
    `);
  console.log(result, "<result><");
  // Normalize to numbers & filter nulls
  return (result.recordset || [])
    .map((r: any) => Number(r.following_user_id))
    .filter((v: any) => Number.isFinite(v));
};

export const getWishlistUserIds = async (
  productId: number
): Promise<number[]> => {
  const pool = await poolPromise;
  const { recordset } = await pool
    .request()
    .input("productId", sql.Int, productId).query(`
      SELECT DISTINCT wishlist_user_id
      FROM [cymbiote].[dbo].[User_Wishlist]
      WHERE wishlist_product_id = @productId
    `);

  return (recordset ?? [])
    .map((r) => Number(r.wishlist_user_id))
    .filter((n) => Number.isFinite(n));
};
