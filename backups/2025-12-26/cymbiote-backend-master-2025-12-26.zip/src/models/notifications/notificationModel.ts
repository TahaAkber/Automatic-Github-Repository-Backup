import { poolPromise } from "../../config/db";
import { sendErrorEmail } from "../../services/emailService";

interface NotificationData {
  title: string;
  body: string;
  DeviceToken: any;
  type: string;
  screenName: string;
  notificationImageUrl: string;
  payload: any;
}

export const getNotifications = async () => {
  try {
    const pool = await poolPromise;
    const query = `SELECT * FROM Notification_Settings`;
    const result = await pool.request().query(query);
    return result.recordset;
  } catch (error: any) {
    sendErrorEmail("error while fetching notifications from database", error);

    console.log("error while fetching notifications from database", error);
    throw error;
  }
};
export const getuserNotificationdb = async (userId: string) => {
  try {
    const pool = await poolPromise;
    const query = `SELECT * FROM Notification_Settings WHERE notification_setting_user_id = @userId`;
    const result = await pool.request().input("userId", userId).query(query);

    if (result.recordset.length === 0) {
      throw new Error(
        `User ID ${userId} does not exist or has no notifications.`
      );
    }

    return result.recordset[0];
  } catch (error: any) {
    sendErrorEmail("error while fetching notifications from database", error);

    console.log("error while fetching notifications from database", error);
    throw error;
  }
};

export const createNotification = async (userId: string) => {
  const pool = await poolPromise;
  const query = `INSERT INTO Notification_Settings (
  notification_setting_user_id,
  notification_setting_pricedrop,
  notification_setting_stock_available,
  notification_setting_abandone_cart,
  notification_setting_remind_review,
  notification_setting_order_create,
  notification_setting_order_update,
  notification_setting_order_shipped,
  notification_setting_order_intransit,
  notification_setting_order_dispatched,
  notification_setting_order_delivered,
  notification_setting_order_picked_up,
  notification_setting_order_refunded,
  notification_setting_offers_n_updates,
  notification_setting_messages,
  notification_setting_tracking,
  notification_setting_shopping
)
VALUES (
  @userId, 
  1,  
  1,  
  1,  
  1,  
  1, 
  1,  
  1,  
  1,  
  1,  
  1,  
  1,  
  1,  
  1,  
  1,  
  1,  
  1   
);
 `;
  try {
    const result = await pool.request().input("userId", userId).query(query);
    return result;
  } catch (error: any) {
    sendErrorEmail("error while creating notification in database", error);

    console.log("error while creating notification in database", error);
    throw error;
  }
};

export const updateNotificationSetting = async (
  userId: string,
  notificationSettings: Record<string, boolean>
) => {
  const pool = await poolPromise;

  if (!notificationSettings || Object.keys(notificationSettings).length === 0) {
    throw new Error("No settings provided for update.");
  }

  const allowedColumns = new Set([
    "notification_setting_pricedrop",
    "notification_setting_stock_available",
    "notification_setting_abandone_cart",
    "notification_setting_remind_review",
    "notification_setting_order_create",
    "notification_setting_order_update",
    "notification_setting_order_shipped",
    "notification_setting_order_intransit",
    "notification_setting_order_dispatched",
    "notification_setting_order_delivered",
    "notification_setting_order_picked_up",
    "notification_setting_order_refunded",
    "notification_setting_offers_n_updates",
    "notification_setting_messages",
    "notification_setting_tracking",
    "notification_setting_shopping",
  ]);

  const setClauses: string[] = [];
  const request = pool.request();
  request.input("userId", userId);

  let paramIndex = 0;
  for (const [column, value] of Object.entries(notificationSettings)) {
    if (!allowedColumns.has(column)) {
      throw new Error(`Invalid column name: ${column}`);
    }

    const paramName = `val${paramIndex}`;
    setClauses.push(`[${column}] = @${paramName}`);
    request.input(paramName, value ? 1 : 0);
    paramIndex++;
  }

  const query = `
      UPDATE Notification_Settings
      SET ${setClauses.join(", ")}
      WHERE notification_setting_user_id = @userId;
    `;

  try {
    const result = await request.query(query);

    // Check if any rows were updated
    if (result.rowsAffected[0] === 0) {
      return {
        success: false,
        message: "User notification settings not found.",
      };
    }

    return {
      success: true,
      message: "Notification settings updated successfully.",
    };
  } catch (error: any) {
    sendErrorEmail("Error updating notification settings:", error);

    console.error("Error updating notification settings:", error);
    throw error;
  }
};

export const getShopByCollectionShopifyId = async (shopifyId: string) => {
  const pool = await poolPromise;
  const query = `
  SELECT 
    c.collection_id,c.collection_name,c.collection_banner_url,
    s.shop_logo_url,
    t.collection_type_name
  FROM 
    Collections c
  JOIN 
    Shops s ON s.shop_id = c.collection_shop_id
  JOIN
    Collection_Types t ON t.collection_type_id = c.collection_type_id
  WHERE 
      c.collection_shopify_id = @shopifyId;
`;
  try {
    const result = await pool
      .request()
      .input("shopifyId", shopifyId)
      .query(query);
    return result.recordset[0];
  } catch (error: any) {
    sendErrorEmail("error while fetching notifications from database", error);

    console.log("error while fetching notifications from database", error);
    throw error;
  }
};

export const saveNotification = async (
  UserId: string | null | number,
  data: NotificationData
) => {
  const pool = await poolPromise;
  const query = `
  INSERT INTO App_Notifications (
  app_notification_user_id,
  app_notification_title,
  app_notification_body,
  app_notification_device_token,
  app_notification_type,
  app_notification_screen_name,
  app_notification_image_url,
  app_notification_payload
  )
  VALUES (
      @UserId,
      @Title,
      @Body,
      @DeviceToken,
      @Type,
      @ScreenName,
      @notificationImageUrl,
      @Payload
    );
  `;
  try {
    const request = pool
      .request()
      .input("UserId", UserId)
      .input("Title", data.title)
      .input("Body", data.body)
      .input("DeviceToken", data.DeviceToken)
      .input("Type", data.type)
      .input("ScreenName", data.screenName)
      .input("notificationImageUrl", data.notificationImageUrl)
      .input("Payload", data.payload);

    return await request.query(query);
  } catch (error: any) {
    sendErrorEmail("Error saving notification:", error);

    console.error("Error saving notification:", error);
    throw error;
  }
};

export const getFcmTokens = async (user_id: string | number) => {
  const pool = await poolPromise;
  let query;
  if (user_id) {
    query = `
    SELECT * FROM User_Notification_Tokens WHERE notification_user_id = @userId
    `;
  } else {
    query = `
    SELECT * FROM User_Notification_Tokens
    `;
  }
  try {
    const response = await pool.request().input("userId", user_id).query(query);

    return response.recordset.map((item: any) => item.notification_token);
  } catch (error: any) {
    sendErrorEmail("error while fetching fcm tokens from database", error);

    console.log("error while fetching fcm tokens from database", error);
    throw error;
  }
};

export const getAppNotificationsModel = async (
  page: number,
  pageSize: number
) => {
  const pool = await poolPromise;

  const offset = (page - 1) * pageSize;

  const notificationQuery = `
    SELECT * 
    FROM App_Notifications
    ORDER BY created_at DESC
    OFFSET @Offset ROWS
    FETCH NEXT @PageSize ROWS ONLY;

    SELECT COUNT(*) AS TotalCount FROM App_Notifications;
  `;

  try {
    const response = await pool
      .request()
      .input("Offset", offset)
      .input("PageSize", pageSize)
      .query(notificationQuery);

    const notifications = response.recordset;
    const totalCount = (response as any).recordsets[1][0].TotalCount;
    const totalPages = Math.ceil(totalCount / pageSize);

    return {
      result: notifications,
      totalNotificationCount: totalCount,
      totalPages,
    };
  } catch (error: any) {
    sendErrorEmail("Error while getting Notifications", error);

    console.log("Error while getting Notifications");
    throw error;
  }
};

export const getAppNotificationsByUserIdModel = async (
  page: number,
  pageSize: number,
  userId: string
) => {
  const pool = await poolPromise;

  const offset = (page - 1) * pageSize;

  const notificationQuery = `
SELECT n.*
FROM App_Notifications n
JOIN Users u ON u.user_id = @userId
WHERE (n.app_notification_user_id = @userId OR n.app_notification_user_id IS NULL)
  AND n.created_at >= u.created_date
  AND n.app_notification_last_sent_at IS NULL
ORDER BY n.created_at DESC
OFFSET @Offset ROWS
FETCH NEXT @PageSize ROWS ONLY;

SELECT COUNT(*) AS TotalCount
FROM App_Notifications n
JOIN Users u ON u.user_id = @userId
WHERE (n.app_notification_user_id = @userId OR n.app_notification_user_id IS NULL)
  AND n.created_at >= u.created_date
  AND n.app_notification_last_sent_at IS NULL;
`;

  try {
    const response = await pool
      .request()
      .input("Offset", offset)
      .input("userId", userId)
      .input("PageSize", pageSize)
      .query(notificationQuery);

    const notifications = response.recordset;
    const totalCount = (response as any).recordsets[1][0].TotalCount;
    const totalPages = Math.ceil(totalCount / pageSize);

    return {
      result: notifications,
      totalNotificationCount: totalCount,
      totalPages,
    };
  } catch (error: any) {
    sendErrorEmail("Error while getting Notifications", error);
    console.log("Error while getting Notifications");
    throw error;
  }
};

export const readNotificationByIdModel = async (notification_id: number) => {
  const pool = await poolPromise;

  const notificationQuery = `
    UPDATE App_Notifications
    SET app_notification_read = 'true'
    WHERE app_notification_id = @notification_id;
  `;

  try {
    const response = await pool
      .request()
      .input("notification_id", notification_id)
      .query(notificationQuery);

    return 1;
  } catch (error: any) {
    sendErrorEmail("Error while read Notification", error);

    console.log("Error while read Notification");
    throw error;
  }
};

export const removeNotification = async (date: Date) => {
  const query = `DELETE FROM App_Notifications WHERE created_at = @date`;

  try {
    const pool = await poolPromise;
    const response = await pool.request().input("date", date).query(query);

    if (response.rowsAffected[0] === 0) {
      return {
        success: false,
        message: "No notifications found for the given date",
      };
    }

    return {
      success: true,
      message: "Notifications for the given date has been removed successfully",
      affectedRows: response.rowsAffected[0],
    };
  } catch (error: any) {
    sendErrorEmail("Error removing notification:", error);

    console.error("Error removing notification:", error);
    return {
      success: false,
      message: "Error removing notification",
      error: error.message,
    };
  }
};
