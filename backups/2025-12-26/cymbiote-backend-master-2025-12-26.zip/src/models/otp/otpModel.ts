import { poolPromise } from "../../config/db";

export const saveOtp = async (userId: number, otp: string) => {
  console.log("saveOtp", userId, otp);
  const pool = await poolPromise;
  const query = `
    INSERT INTO Otp_Table (otp_user_id, otp_number, created_at)
VALUES (@userId, @otp, GETDATE());
  `;
  // UPDATE Otp_Table
  // SET otp_number = @otp, otp_expiry = DATEADD(MINUTE, 10, GETDATE())
  // WHERE otp_user_id = @userId
  await pool.request().input("otp", otp).input("userId", userId).query(query);
};

export const verifyOtp = async (userId: string, otp: string) => {
  const pool = await poolPromise;
  const query = `
    SELECT * FROM Otp_Table 
    WHERE otp_user_id = @userId AND otp_number = @Otp 
    AND created_at > DATEADD(MINUTE, -15, GETDATE())
  `;
  const result = await pool
    .request()
    .input("userId", userId)
    .input("Otp", otp)
    .query(query);

  return result.recordset.length > 0;
};
