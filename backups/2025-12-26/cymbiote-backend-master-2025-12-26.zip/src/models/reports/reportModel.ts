import sql from "mssql";
import { poolPromise } from "../../config/db";
import { sendErrorEmail } from "../../services/emailService";

export interface CreateReportParams {
  reported_type: "shop" | "product" | "reel" | "story";
  reported_reference_id: number;
  reported_by_user_id: number;
  reported_reason_main: string;
  reported_reason_sub?: string;
  reported_reason_other_text?: string;
  reported_has_order?: boolean;
  reported_order_id?: string;
}

export interface Report {
  report_id: number;
  reported_type: string;
  reported_reference_id: number;
  reported_by_user_id: number;
  reported_decision_id?: number;
  reported_status: string;
  created_at: Date;
  updated_at: Date;
  reported_reason_main: string;
  reported_reason_sub?: string;
  reported_reason_other_text?: string;
  reported_has_order?: boolean;
  reported_order_id?: string;
}

export const createReport = async (
  params: CreateReportParams
): Promise<Report> => {
  const pool = await poolPromise;

  try {
    // Validate reported_type
    const validTypes = ["shop", "product", "reel","story"];
    if (!validTypes.includes(params.reported_type)) {
      throw new Error(
        `Invalid reported_type. Must be one of: ${validTypes.join(", ")}`
      );
    }

    // Validate required fields
    if (!params.reported_reference_id) {
      throw new Error("reported_reference_id is required");
    }

    if (!params.reported_by_user_id) {
      throw new Error("reported_by_user_id is required");
    }

    if (!params.reported_reason_main) {
      throw new Error("reported_reason_main is required");
    }

    // Check if user has ordered this product
    let reported_has_order = params.reported_has_order || false;
    let reported_order_id = params.reported_order_id || null;

    if (params.reported_type === "product") {
      const orderCheckQuery = `
        SELECT TOP 1 O.order_id, O.order_shopify_id
        FROM Orders O
        JOIN Order_Items OI ON O.order_id = OI.order_id
        JOIN Product_Variants PV ON OI.order_item_variant_id = PV.variant_id
        WHERE PV.variant_product_id = @productId
          AND O.order_user_id = @userId
        ORDER BY O.order_date DESC;
      `;

      const orderCheckResult = await pool
        .request()
        .input("productId", sql.Int, params.reported_reference_id)
        .input("userId", sql.Int, params.reported_by_user_id)
        .query(orderCheckQuery);

      if (orderCheckResult.recordset.length > 0) {
        reported_has_order = true;
        reported_order_id = orderCheckResult.recordset[0].order_shopify_id || String(orderCheckResult.recordset[0].order_id);
      }
    }

    const query = `
      INSERT INTO Reports (
        reported_type,
        reported_reference_id,
        reported_by_user_id,
        reported_reason_main,
        reported_reason_sub,
        reported_reason_other_text,
        reported_has_order,
        reported_order_id
      )
      OUTPUT INSERTED.*
      VALUES (
        @reported_type,
        @reported_reference_id,
        @reported_by_user_id,
        @reported_reason_main,
        @reported_reason_sub,
        @reported_reason_other_text,
        @reported_has_order,
        @reported_order_id
      );
    `;

    const result = await pool
      .request()
      .input("reported_type", sql.VarChar(20), params.reported_type)
      .input("reported_reference_id", sql.Int, params.reported_reference_id)
      .input("reported_by_user_id", sql.Int, params.reported_by_user_id)
      .input("reported_reason_main", sql.NVarChar(100), params.reported_reason_main)
      .input("reported_reason_sub", sql.NVarChar(100), params.reported_reason_sub || null)
      .input(
        "reported_reason_other_text",
        sql.NVarChar(500),
        params.reported_reason_other_text || null
      )
      .input("reported_has_order", sql.Bit, reported_has_order)
      .input("reported_order_id", sql.NVarChar(50), reported_order_id)
      .query(query);

    return result.recordset[0];
  } catch (error: any) {
    sendErrorEmail("Error creating report", error);
    console.error("Error creating report:", error);
    throw new Error("Failed to create report: " + error.message);
  }
};
