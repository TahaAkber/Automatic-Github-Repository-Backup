import { Float, Int, NVarChar, pool } from "mssql";
import { poolPromise } from "../../config/db";
import { getOrderDetailById } from "../orders/dbOrders";
import { applyPointStatus } from "../../functions/common";
import { getShopWithRatingUsingShopId } from "../shops/shopModel";
import { sendErrorEmail } from "../../services/emailService";

export const getActiveCriteria = async (): Promise<any> => {
  const pool = await poolPromise;
  const query = `
    SELECT criteria_id, criteria_name, criteria_details, criteria_value
    FROM Points_Criteria
    WHERE criteria_is_active = 1
  `;
  const result = await pool.request().query(query);
  return result.recordset;
};

export const getUserTotalPoints = async (userId: number): Promise<number> => {
  const pool = await poolPromise;
  const query = `
    SELECT user_points AS total_points
    FROM Users
    WHERE user_id = @userId
  `;
  const request = pool.request();
  request.input("userId", userId);
  const result = await request.query(query);
  return result.recordset[0]?.total_points || 0;
};

// Function to group points logs by month
const groupPointsLogsByMonth = (logs: any[]): any[] => {
  const grouped: Record<string, any[]> = logs.reduce(
    (acc: Record<string, any[]>, log: any) => {
      // Ensure created_at is a valid date
      const dateObj = log?.created_at ? new Date(log.created_at) : null;

      if (!dateObj || isNaN(dateObj.getTime())) {
        return acc; // Skip invalid dates
      }

      // Format month-year (e.g., "January 2025")
      const monthYear = dateObj.toLocaleString("en-US", {
        month: "long",
        year: "numeric",
      });

      if (!acc[monthYear]) {
        acc[monthYear] = [];
      }
      acc[monthYear].push(log);
      return acc;
    },
    {} as Record<string, any[]>
  );

  return Object.entries(grouped).map(([month, data]) => ({
    month,
    data,
  }));
};

export const logUserPoints = async (
  userId: number,
  shopId: number,
  criteriaId: number,
  points: number,
  description: string,
  pointStatus: string
): Promise<number> => {
  const pool = await poolPromise;
  const query = `
    INSERT INTO User_Points_Logs (
      points_log_user_id,
      points_log_shop_id,
      points_log_criteria_id,
      points_log_transaction_count,
      points_log_description,
      points_status,
      created_at
    )
    VALUES (@userId, @shopId, @criteriaId, @points, @description, @points_status, GETDATE());
    SELECT SCOPE_IDENTITY() AS points_log_id
  `;
  const request = pool.request();
  request.input("userId", userId);
  request.input("shopId", shopId);
  request.input("criteriaId", criteriaId);
  request.input("points", points.toFixed(3));
  request.input("description", description);
  request.input("points_status", pointStatus);

  const result = await request.query(query);
  return result.recordset[0].points_log_id;
};

export const addPointsToUser = async (user_id: number, points: number) => {
  const pool = await poolPromise;

  try {
    // Execute the stored procedure to insert tracking details
    const result = await pool
      .request()
      .input("userId", user_id)
      .input("pointsToAdd", points)
      .execute("AddPointsToUser"); // Call the stored procedure

    console.log("addPointsToUser");

    // Return the inserted tracking details
    // const totalPoints = result.recordset[0];
    // return totalPoints;
  } catch (error: any) {
    sendErrorEmail("Error updating user points:", error);

    console.error("Error updating user points:", error);
    throw new Error("Database operation failed.");
  }
};

export const logPointsToUser = async (
  userId: number,
  page = 1,
  pageSize = 10,
  status?: string
) => {
  const pool = await poolPromise;
  const offset = (page - 1) * pageSize;
  let query;

  const request = pool.request().input("userId", userId);

  if (status !== "0" && status !== "" && status) {
    query = `
      SELECT *
      FROM User_Points_Logs
      WHERE points_log_user_id = @userId
        AND TRIM(points_status) = @status
      ORDER BY created_at DESC
      OFFSET ${offset} ROWS
      FETCH NEXT ${pageSize} ROWS ONLY;
    `;

    const cleanStatus = applyPointStatus(status);
    if (!cleanStatus || typeof cleanStatus !== "string") {
      throw new Error("Invalid status value");
    }

    request.input("status", cleanStatus);
  } else {
    query = `
      SELECT *
      FROM User_Points_Logs
      WHERE points_log_user_id = @userId
      ORDER BY created_at DESC
      OFFSET ${offset} ROWS
      FETCH NEXT ${pageSize} ROWS ONLY;
    `;
  }

  const result = await request.query(query);

  const finalResult = await Promise.all(
    result.recordset.map(async (item) => {
      const shop = item.points_log_shop_id
        ? await getShopWithRatingUsingShopId(item.points_log_shop_id)
        : null;

      const getConnectPointLog = await userPointConnectUsingPointLogId(
        item.points_log_id
      );

      if (getConnectPointLog) {
        const orderDetail = await getOrderDetailById(
          getConnectPointLog?.connect_order_id
        );
        item.order_title = orderDetail?.order_title;
      }

      return {
        ...item,
        shop,
      };
    })
  );

  return groupPointsLogsByMonth(finalResult);
};

export const userVouchers = async (
  userId: number,
  page = 1,
  pageSize = 10,
  shopId?: number
) => {
  const pool = await poolPromise;
  const offset = (page - 1) * pageSize;
  let query;

  if (shopId) {
    query = `
    SELECT 
    *
    FROM Vouchers
    WHERE 
    voucher_user_id = @userId
    AND voucher_shop_id = @shopId
    AND (voucher_is_redeemed IS NULL OR voucher_is_redeemed = 0)
    AND voucher_expiration_date >= GETUTCDATE()
    ORDER BY created_at DESC;
  `;
  } else {
    query = `
    SELECT
    *
    FROM Vouchers
    WHERE voucher_user_id = @userId
    ORDER BY created_at DESC
    OFFSET ${offset} ROWS
    FETCH NEXT ${pageSize} ROWS ONLY;
  `;
  }

  const result = await pool
    .request()
    .input("userId", userId)
    .input("shopId", shopId)
    .query(query);

  const finalResult = await Promise.all(
    result.recordset.map(async (item) => {
      const shop = item.voucher_shop_id
        ? await getShopWithRatingUsingShopId(item.voucher_shop_id)
        : null;
      return {
        ...item,
        shop,
      };
    })
  );

  return shopId ? finalResult : groupPointsLogsByMonth(finalResult);
};

export const getTotalPointCount = async (userId: number) => {
  const pool = await poolPromise;
  const query = `
    SELECT COUNT(*) as count
    FROM User_Points_Logs
    WHERE points_log_user_id = ${userId}
  `;
  const result = await pool.request().query(query);
  return result.recordset[0].count;
};

export const getTotalVoucherCount = async (userId: number) => {
  const pool = await poolPromise;
  const query = `
    SELECT COUNT(*) as count
    FROM Vouchers
    WHERE voucher_user_id = ${userId}
  `;
  const result = await pool.request().query(query);
  return result.recordset[0].count;
};

export const getVoucherByCode = async (voucher_code: string) => {
  const pool = await poolPromise;
  const result = await pool.request().input("voucher_code", voucher_code)
    .query(`
      SELECT *
      FROM Vouchers
      WHERE voucher_code = @voucher_code
    `);

  return result.recordset[0];
};

export const insertVoucher = async (
  userId: number,
  pointsToDeduct: number,
  shop_id: number,
  voucher_shopify_id: string,
  voucher_code: string,
  expiration_date: string
) => {
  const pool = await poolPromise;

  try {
    // Creating the new voucher
    const result = await pool
      .request()
      .input("voucher_user_id", Int, userId)
      .input("voucher_value", Float, pointsToDeduct)
      .input("voucher_shopify_id", NVarChar(50), voucher_shopify_id)
      .input("voucher_shop_id", Int, shop_id)
      .input("voucher_code", NVarChar(50), voucher_code)
      .input("voucher_expiration_date", NVarChar(50), expiration_date)
      .execute("InsertVoucher");

    // Return the inserted tracking details returned from the stored procedure
    const totalPoints = result.recordset[0];
    console.log("totalpoints", totalPoints);
    return totalPoints;
  } catch (error: any) {
    sendErrorEmail("Error updating user points:", error);

    console.error("Error updating user points:", error);
    throw new Error("Database operation failed.");
  }
};

export const userPointConnectUsingPointLogId = async (point_log_id: number) => {
  const pool = await poolPromise;
  const query = `
    SELECT *
    FROM Order_Points_Connect
    WHERE connect_point_log_id = ${point_log_id}
  `;
  const result = await pool.request().query(query);
  return result.recordset.length > 0 ? result.recordset?.[0] : null;
};

export const userTotalPoint = async (userId: number, status: string) => {
  const pool = await poolPromise;
  const result = await pool
    .request()
    .input("userId", userId)
    .input("status", status).query(`
      SELECT
        SUM(ABS(points_log_transaction_count)) AS total_points
      FROM User_Points_Logs
      WHERE points_log_user_id = @userId
      AND TRIM(points_status) = @status
    `);

  return result.recordset[0]?.total_points
    ? result.recordset[0]?.total_points.toFixed(2)
    : 0;
};

export const UpdatePointStatus = async (
  points_log_id: number,
  points_status: string
) => {
  const pool = await poolPromise;
  // console.log("testing ids", points_log_id, points_status);
  try {
    const updateQuery = `
      UPDATE User_Points_Logs
      SET points_status = @points_status
      WHERE points_log_id = @points_log_id
    `;

    const result = await pool
      .request()
      .input("points_log_id", points_log_id) // Corrected
      .input("points_status", points_status)
      .query(updateQuery);

    return { success: true, message: "Points status updated successfully" };
  } catch (err: any) {
    sendErrorEmail("Error Updating Status", err);

    console.error("Error Updating Status", err);
    return { success: false, error: err };
  }
};

export const getUserConnectPoints = async (orderId: string) => {
  try {
    const pool = await poolPromise;
    const query = `SELECT * FROM Order_Points_Connect 
                   WHERE connect_order_id = @orderId`;

    const result = await pool
      .request()
      .input("orderId", orderId) // Fixed: Parameter name now matches the query
      .query(query);

    console.log("Get User Connect Points Query Result:", result.recordset[0]);
    return result.recordset[0]; // Return result if needed
  } catch (error: any) {
    sendErrorEmail("Error fetching user connect points:", error);

    console.error("Error fetching user connect points:", error);
    throw error;
  }
};

export const UpdateUserPoints = async (
  point_log_id: string,
  user_id: string
): Promise<number | null> => {
  try {
    const pool = await poolPromise;

    console.log("UpdateUserPoints called with:", point_log_id, user_id);

    // Fetch points from User_Points_Logs
    const getPointsQuery = `
      SELECT points_log_transaction_count 
      FROM User_Points_Logs 
      WHERE points_log_id = @point_log_id
    `;

    const getPointsResult = await pool
      .request()
      .input("point_log_id", point_log_id)
      .query(getPointsQuery);

    const points = getPointsResult.recordset[0]?.points_log_transaction_count;

    if (points === null || points === undefined) {
      console.warn("No points found for points_log_id:", point_log_id);
      return null; // or 0 if you want
    }

    if (points === 0) {
      console.log("Points is zero, no update required.");
      return 0;
    }

    // Update user's points by adding new points
    const updatePointsQuery = `
      UPDATE Users
      SET user_points = ISNULL(user_points, 0) + @points
      WHERE user_id = @user_id;

      SELECT user_points FROM Users WHERE user_id = @user_id;
    `;

    const updatedPointsResult = await pool
      .request()
      .input("user_id", user_id)
      .input("points", points)
      .query(updatePointsQuery);

    const updatedPoints = updatedPointsResult.recordset[0]?.user_points;

    console.log("Updated user points:", updatedPoints);

    return updatedPoints ?? null;
  } catch (error: any) {
    sendErrorEmail("Error in UpdateUserPoints:", error);

    console.error("Error in UpdateUserPoints:", error);
    throw error;
  }
};
