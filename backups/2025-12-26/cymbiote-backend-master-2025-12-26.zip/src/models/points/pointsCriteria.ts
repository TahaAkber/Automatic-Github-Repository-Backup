import { poolPromise } from "../../config/db";

export const getAllPointsCriteria = async (): Promise<
  {
    criteria_id: number;
    criteria_name: string;
    criteria_details: string;
    criteria_identifier: string;
  }[]
> => {
  const pool = await poolPromise;

  const query = `
    SELECT 
    pc.criteria_id, 
    pc.criteria_name, 
    pc.criteria_details,
      pci.identifier_value as criteria_identifier
    FROM Points_Criteria pc 
    INNER JOIN Points_Criteria_Identifiers pci 
    ON pc.criteria_id = pci.identifier_criteria_id;
  `;

  const result = await pool.request().query(query);

  return result.recordset;
};
