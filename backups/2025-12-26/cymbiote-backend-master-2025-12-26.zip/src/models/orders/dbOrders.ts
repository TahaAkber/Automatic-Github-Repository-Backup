import { Int, NVarChar } from "mssql";
import { poolPromise } from "../../config/db";
import { DBOrder } from "../../types/order/DBOrder";
import { PendingOrders } from "../../types/order/PendingOrders";
import { LineItem } from "../../types/shopify_orders/Order";
import {
  getProductVariants,
  getUsingShopId,
  getVariantById,
} from "../products/productModel";
import { applyOrderStatus } from "../../functions/common";
import {
  getShopByDomain,
  getShopWithRatingUsingShopId,
} from "../shops/shopModel";
import {
  getTrackingByOrderId,
  getTrackingItemsById,
} from "../../services/trackingService";
import { getOrderItemReviewById } from "../reviews/reviewsModel";
import { sendErrorEmail } from "../../services/emailService";
import dotenv from "dotenv";

dotenv.config();

const DB_NAME = process.env.DB_NAME || "cymbiote";

export const createOrder = async (
  discountCodes: any[],
  order: DBOrder,
  line_items: LineItem[]
): Promise<any> => {
  const {
    order_user_id,
    order_date,
    order_delivery_address,
    order_total_amount,
    order_fulfillment_status,
    order_shop_id,
    order_shopify_id,
    order_charge_rate,
    order_title,
    order_channel,
    order_shipping,
    order_payment_status,
    order_tax,
    order_tax_rate,
    order_total_discount_amount,
  } = order;

  console.log("recieved order", order);

  const pool = await poolPromise;

  const result = await pool
    .request()
    .input("order_user_id", order_user_id ? order_user_id : null) // change in later when customers are added
    .input("order_date", order_date)
    .input("order_delivery_address", order_delivery_address)
    .input("order_total_amount", order_total_amount)
    .input("order_fulfillment_status", "pending")
    .input("order_shop_id", order_shop_id)
    .input("order_shopify_id", order_shopify_id)
    .input("order_charge_rate", order_charge_rate)
    .input("order_delivery_status", "Unavailable")
    .input("order_title", order_title)
    .input("order_payment_status", order_payment_status)
    .input("order_channel", order_channel)
    .input("order_shipping", order_shipping)
    .input("order_tax", order_tax)
    .input("order_tax_rate", order_tax_rate)
    .input("order_total_discount_amount", order_total_discount_amount)
    .execute("InsertOrderAndGetId");

  console.log("query complete", result);

  const newOrderId = result.recordset[0].order_id;

  console.log("query complete", newOrderId);
  console.log("lineitems query", line_items);

  const lineitems = line_items.map((e) => {
    createLineItem(e, newOrderId);
  });
  console.log("discountCodes", discountCodes);
  if (discountCodes.length > 0) {
    const pool = await poolPromise;

    // Start a transaction
    const transaction = await pool.transaction();

    try {
      // Begin the transaction
      await transaction.begin();

      console.log("lineitems", lineitems);

      const codes = discountCodes.map((e) => e.code);
      console.log("codes", codes);

      const codeParams = codes.map((_, i) => `@code${i}`).join(",");
      console.log("codeParams", codeParams);

      // Prepare the query for the Vouchers table update
      const voucherQuery = `
        UPDATE Vouchers
        SET voucher_is_redeemed = 1,
            updated_at = GETDATE(),
            voucher_order_id = @newOrderId
        WHERE voucher_user_id = @user_id
        AND voucher_code IN (${codeParams});
      `;

      // Create a request tied to the transaction
      const request = transaction
        .request()
        .input("user_id", Int, order_user_id)
        .input("newOrderId", newOrderId);

      // Add the codes as parameters for the voucher query
      codes.forEach((code, i) => {
        request.input(`code${i}`, code);
      });

      // Execute the Vouchers update query
      const voucherOutput = await request.query(voucherQuery);
      console.log("Updated vouchers count:", voucherOutput.rowsAffected);

      // Prepare the query for the Cart_Discount table update
      const cartDiscountQuery = `
        UPDATE Cart_Discount_Codes
        SET cart_discount_is_applied = 1,
            cart_discount_order_id = @newOrderId
        WHERE cart_discount_code IN (${codeParams});
      `;

      // Execute the Cart_Discount update query
      const cartDiscountOutput = await request.query(cartDiscountQuery);
      console.log(
        "Updated cart discounts count:",
        cartDiscountOutput.rowsAffected
      );

      // Commit the transaction if both updates are successful
      await transaction.commit();
      console.log("Transaction committed successfully.");
    } catch (error: any) {
      // Rollback the transaction if an error occurs
      sendErrorEmail("Transaction failed and rolled back:", error);

      await transaction.rollback();
      console.error("Transaction failed and rolled back:", error);
    }
  }

  return result.recordset;
};

export const createLineItem = async (lineItem: LineItem, orderId: number) => {
  let { discount_allocations, price, product_id, quantity, variant_id } =
    lineItem;

  const query = `
  INSERT INTO Order_Items (order_id, order_item_quantity, order_item_variant_id, order_item_price, order_item_disc_amount)
  VALUES (@order_id, @order_item_quantity, @order_item_variant_id, @order_item_price, @order_item_disc_amount);
  `;

  let totalDiscount = 0;
  if (discount_allocations?.length === 1 && discount_allocations[0] === null) {
    discount_allocations = [];
  }
  if (discount_allocations && discount_allocations.length > 0) {
    totalDiscount = discount_allocations.reduce((total, discount) => {
      return total + parseFloat(discount.amount);
    }, 0);
  }

  const prodVariant = await getProductVariants(
    variant_id ? `gid://shopify/ProductVariant/${variant_id}` : ""
  );

  const db_variant_id = prodVariant[0]?.variant_id;

  // const valuesPassed = {
  //   orderId,
  //   product_id,
  //   quantity,
  //   db_variant_id,
  //   price: parseFloat(price),
  //   totalDiscount,
  // };

  // console.log("recieved lineItem", valuesPassed);

  const pool = await poolPromise;
  console.log(
    "testing all",
    orderId,
    quantity,
    db_variant_id,
    price,
    totalDiscount
  );
  const result = await pool
    .request()
    .input("order_id", orderId)
    .input("order_item_quantity", quantity)
    .input("order_item_variant_id", db_variant_id)
    .input("order_item_price", parseFloat(price))
    .input("order_item_disc_amount", totalDiscount)
    .query<any>(query);

  console.log("LineItem added successfully", result);

  return result.recordset;
};

export const getPendingOrders = async () => {
  const pool = await poolPromise;

  const query = `
    SELECT 
      o.order_id, 
      o.order_shopify_id, 
      o.order_total_amount, 
      o.order_charge_rate,
      o.order_shop_id,
      o.order_title,
	    s.shop_currency,
      s.shop_access_token,
      s.shop_domain,
      sub.subscription_id,
      sub.subscription_appRecurringPricingDetails_id,
      sub.subscription_appUsagePricingDetails_id
    FROM 
      Orders o
    JOIN 
      Shops s ON o.order_shop_id = s.shop_id
    JOIN 
      Subscriptions sub ON o.order_shop_id = sub.subscription_shop_id
    WHERE 
		o.order_usage_charged = 0
		AND o.order_fulfillment_status = 'fulfilled'
		AND o.order_date >= DATEADD(MONTH, -1, GETDATE())
		AND s.shop_is_active = 1         
		AND sub.subscription_confirmed = 1
		AND sub.subscription_enabled = 1  
		AND (o.order_channel = '${DB_NAME}'
		OR o.order_channel = 'cercledev');
  `;

  const result = await pool.request().query<PendingOrders>(query);

  return result.recordset;
};

export const getNonFulfilledOrders = async () => {
  const pool = await poolPromise;
  const query = `
  SELECT 
    o.order_id, 
    o.order_shopify_id, 
    o.order_total_amount, 
    o.order_charge_rate,
    o.order_shop_id,
    o.order_title,
    s.shop_access_token,
    s.shop_domain,
    s.shop_email
FROM 
    Orders o
JOIN 
    Shops s ON o.order_shop_id = s.shop_id
WHERE 
    o.order_fulfillment_status = 'pending'
    AND CAST(o.order_date AS DATE) = CAST(DATEADD(DAY, -7, GETDATE()) AS DATE);
  `;
  try {
    const result = await pool.request().query(query);
    return result.recordset;
  } catch (error: any) {
    sendErrorEmail(error.message, error);

    console.log(error.message);
  }
};

export const updateOrderCancelStatus = async (
  shopifyOrderId: string,
  cancel_reason: string,
  cancelled_at: Date,
  fulfillment_status: string
) => {
  try {
    const pool = await poolPromise;
    const cancelDate = new Date(cancelled_at);
    const order_cancelled_by =
      cancel_reason.toLowerCase() === "customer" ? "customer" : "merchant";

    // Call the stored procedure with input parameters
    const result = await pool
      .request()
      .input("shopifyOrderId", shopifyOrderId)
      .input("cancel_reason", cancel_reason)
      .input("cancelled_at", cancelDate)
      .input("fulfillment_status", fulfillment_status)
      .input("order_cancelled_by", order_cancelled_by)
      .execute("UpdateOrderCancelStatusAndGetShopDetails");

    // Retrieve the rows affected and shop details
    const rowsAffected = result.returnValue;
    const shopDetails = result.recordset; // assuming shop details are returned as a recordset

    // console.log("Rows Affected:", rowsAffected);
    // console.log("Shop Details:", shopDetails);

    return { rowsAffected, shopDetails };
  } catch (error: any) {
    sendErrorEmail("Error updating order cancel status:", error);

    console.error("Error updating order cancel status:", error);
    throw new Error("Failed to update order status.");
  }
};

export const updateOrderStaffNote = async (
  shopify_order_id: string,
  staff_note: string
) => {
  try {
    const pool = await poolPromise;
    const query = `
    UPDATE Orders SET order_cancelled_staff_notes = @staff_note WHERE order_shopify_id = @shopify_order_id;`;
    const result = await pool
      .request()
      .input("staff_note", staff_note)
      .input("shopify_order_id", shopify_order_id)
      .query(query);
    return true;
  } catch (error: any) {
    console.log("Error updating Staff Notes");
  }
};

export const checkCancellationRate = async (shop_domain: string) => {
  try {
    const pool = await poolPromise;
    const result = await pool
      .request()
      .input("ShopDomain", shop_domain)
      .execute("GetShopCancellationRateByDomain");

    if (result && result.recordset && result.recordset.length > 0) {
      // Return just the data, leaving response formatting for the service/controller layer
      return result.recordset[0];
    } else {
      // Return null if no data found, which can be handled by the service
      return null;
    }
  } catch (error: any) {
    sendErrorEmail(
      "Database error occurred while retrieving cancellation rate.",
      error
    );

    // Throw the error to be handled by the service layer
    throw new Error(
      "Database error occurred while retrieving cancellation rate."
    );
  }
};

export const updateShopDelistedStatus = async (shop_domain: string) => {
  try {
    const pool = await poolPromise;
    const result = await pool
      .request()
      .input("ShopDomain", shop_domain)
      .query(
        "UPDATE Shops SET shop_delisted = 1 WHERE shop_domain = @ShopDomain"
      );

    if (result && result.rowsAffected[0] > 0) {
      // Return success confirmation and number of rows affected
      return { success: true, rowsAffected: result.rowsAffected[0] };
    } else {
      // Return information if no rows were updated
      return {
        success: false,
        message: "No shop found with the specified domain.",
      };
    }
  } catch (error: any) {
    sendErrorEmail(
      "Database error occurred while updating shop delisted status.",
      error
    );

    // Handle the error by throwing it to be managed in the service layer
    throw new Error(
      "Database error occurred while updating shop delisted status."
    );
  }
};

export const getOrderByShopifyId = async (orderShopifyId: number) => {
  const pool = await poolPromise;

  // console.log("orderShopifyId for getOrderById", orderShopifyId);

  try {
    const query = `
      SELECT *
      FROM Orders
      WHERE order_shopify_id = @orderShopifyId;
    `;

    const result = await pool
      .request()
      .input("orderShopifyId", orderShopifyId)
      .query(query);

    // Return the order_shop_id if the order exists, else return null
    return result.recordset[0] || null;
  } catch (error: any) {
    sendErrorEmail("Error fetching order by id:", error);

    console.error("Error fetching order by id:", error);
    throw new Error("Failed to get order by ID");
  }
};

// export const getOrderByUserId = async (
//   orderUserId: number,
//   page: number,
//   pageSize: number,
//   orderStatus?: any
// ) => {
//   const pool = await poolPromise;

//   const offset = (page - 1) * pageSize;

//   let query;

//   console.log("orderStatus", orderStatus);

//   try {
//     const result = await pool
//       .request()
//       .input("orderUserId", orderUserId)
//       .input("page", page)
//       .input("pageSize", pageSize)
//       .input("status", orderStatus)
//       .execute("GetOrdersByUserId");

//     return result.recordset || [];
//   } catch(error:any){
//     console.error("Error fetching order by user ID:", error);
//     throw new Error("Failed to get order by user ID");
//   }
// };

export const getOrderByUserId = async (
  orderUserId: number,
  page: number,
  pageSize: number,
  orderStatus?: any
) => {
  const pool = await poolPromise;

  const offset = (page - 1) * pageSize;

  let query;

  console.log("orderStatus", orderStatus);

  try {
    if (orderStatus == 0) {
      query = `
        WITH OrderWithPin AS (
            SELECT 
                o.order_id,
                o.order_title,
                o.order_shop_id,
                o.order_user_id,
                o.order_cancelled_by,
                o.order_total_amount,
                o.order_fulfillment_status,
                o.order_shopify_id,
                o.created_at,
                o.updated_at,
                u.user_id,
                u.user_name,
                s.shop_name,
                s.shop_currency,
                t.tracking_status,
                t.id,
                oi.order_item_id,
                oi.order_item_variant_id,
                CASE
                    WHEN t.tracking_status = 'DELIVERED'
                        AND DATEDIFF(SECOND, o.updated_at, GETDATE()) BETWEEN 0 AND 604800
                        AND NOT EXISTS (
                            SELECT 1
                            FROM Order_Items oi2
                            JOIN Order_Item_Review oir 
                              ON oi2.order_item_id = oir.order_item_id
                            WHERE oi2.order_id = o.order_id
                        )
                    THEN 1
                    ELSE 0
                END AS pin_delivered_recent
            FROM Orders AS o
            JOIN Users  AS u ON o.order_user_id = u.user_id
            JOIN Shops  AS s ON o.order_shop_id = s.shop_id
            LEFT JOIN Order_Items          AS oi  ON oi.order_id = o.order_id
            LEFT JOIN Tracking_Order_Items AS toi ON toi.tracking_order_item_id = oi.order_item_id
            LEFT JOIN Tracking             AS t   ON t.id = toi.tracking_id
            WHERE o.order_user_id = @orderUserId
        )
        SELECT 
            order_id,
            order_title,
            order_shop_id,
            order_user_id,
            order_cancelled_by,
            order_total_amount,
            order_fulfillment_status,
            order_shopify_id,
            created_at,
            updated_at,
            user_id,
            user_name,
            shop_name,
            shop_currency,
            tracking_status,
            id,
            order_item_id,
            order_item_variant_id,
            pin_delivered_recent
        FROM OrderWithPin
        GROUP BY
            order_id,
            order_title,
            order_shop_id,
            order_user_id,
            order_cancelled_by,
            order_total_amount,
            order_fulfillment_status,
            order_shopify_id,
            order_item_id,
            order_item_variant_id,
            created_at,
            updated_at,
            user_id,
            user_name,
            shop_name,
            shop_currency,
            tracking_status,
            id,
            pin_delivered_recent
        HAVING 
            COUNT(DISTINCT id) <= 1
            OR COUNT(DISTINCT id) > 1
        ORDER BY 
            pin_delivered_recent DESC,
            created_at DESC
        OFFSET @offset ROWS
        FETCH NEXT @pageSize ROWS ONLY;
      `;
    } else if (orderStatus) {
      query = `
        WITH OrderWithPin AS (
            SELECT 
                o.order_id,
                o.order_title,
                o.order_shop_id,
                o.order_user_id,
                o.order_cancelled_by,
                o.order_total_amount,
                o.order_fulfillment_status,
                o.order_shopify_id,
                o.created_at,
                o.updated_at,
                u.user_id,
                u.user_name,
                s.shop_name,
                s.shop_currency,
                t.tracking_status,
                t.id,
                oi.order_item_id,
                oi.order_item_variant_id
            FROM Orders o
            JOIN Users u ON o.order_user_id = u.user_id
            JOIN Shops s ON o.order_shop_id = s.shop_id
            LEFT JOIN Order_Items oi ON oi.order_id = o.order_id
            LEFT JOIN Tracking_Order_Items toi ON toi.tracking_order_item_id = oi.order_item_id
            LEFT JOIN Tracking t ON t.id = toi.tracking_id
            WHERE o.order_user_id = @orderUserId
              AND t.tracking_status = @status
        )
        SELECT 
            order_id,
            order_title,
            order_shop_id,
            order_user_id,
            order_cancelled_by,
            order_total_amount,
            order_fulfillment_status,
            order_shopify_id,
            created_at,
            updated_at,
            user_id,
            user_name,
            shop_name,
            shop_currency,
            tracking_status,
            id,
            order_item_id,
            order_item_variant_id
        FROM OrderWithPin
        GROUP BY
            order_id, order_title, order_shop_id, order_user_id, order_cancelled_by, 
            order_total_amount, order_fulfillment_status, order_shopify_id, 
            order_item_id, order_item_variant_id, created_at, updated_at, 
            user_id, user_name, shop_name, shop_currency, 
            tracking_status, id
        HAVING 
            COUNT(DISTINCT id) <= 1
            OR COUNT(DISTINCT id) > 1
        ORDER BY 
            created_at DESC
        OFFSET @offset ROWS
        FETCH NEXT @pageSize ROWS ONLY;
      `;
    } else {
      query = `
        SELECT * 
        FROM Orders 
        WHERE order_user_id = @orderUserId
        ORDER BY created_at DESC
        OFFSET @offset ROWS
        FETCH NEXT @pageSize ROWS ONLY;
      `;
    }

    const result = await pool
      .request()
      .input("orderUserId", orderUserId)
      .input("offset", offset)
      .input("pageSize", pageSize)
      .input("status", orderStatus)
      .query(query);
    console.log("result", result.recordset);
    return result.recordset || [];
  } catch (error: any) {
    sendErrorEmail("Error fetching order by user ID:", error);

    console.error("Error fetching order by user ID:", error);
    throw new Error("Failed to get order by user ID");
  }
};

export const getReviewByUserId = async (
  orderUserId: number,
  page: number,
  pageSize: number,
  reviewStatus?: number
) => {
  const pool = await poolPromise;
  const deliveredStatus = await applyOrderStatus("4");
  const offset = (page - 1) * pageSize;

  console.log("reviewStatus", reviewStatus);

  let query;

  try {
    if (reviewStatus === 1) {
      query = `
    SELECT o.*
FROM Orders o
JOIN Tracking t ON o.order_id = t.tracking_order_id
WHERE o.order_user_id = @orderUserId
  AND t.tracking_status = @status
  AND EXISTS (
    SELECT 1
    FROM Order_Items oi
    WHERE oi.order_id = o.order_id
      AND NOT EXISTS (
        SELECT 1
        FROM Order_Item_Review oir
        WHERE oir.order_item_id = oi.order_item_id
      )
  )
ORDER BY o.created_at DESC
      `;
    } else if (reviewStatus === 2) {
      // ✅ Only Fully Reviewed Orders (All items reviewed)
      // ✅ Default fallback (same as Delivered)
      query = `
        WITH TrackingDelivered AS (
  SELECT 
    tracking_order_id
  FROM Tracking
  WHERE tracking_status = @status
  GROUP BY tracking_order_id
),
OrdersWithPendingReviews AS (
  SELECT 
    o.*,
    1 AS pending_review
  FROM Orders o
  JOIN TrackingDelivered t ON o.order_id = t.tracking_order_id
  WHERE o.order_user_id = @orderUserId
    AND EXISTS (
      SELECT 1
      FROM Order_Items oi
      LEFT JOIN Order_Item_Review oir ON oi.order_item_id = oir.order_item_id
      WHERE oi.order_id = o.order_id
        AND oir.order_item_id IS NULL
    )
    AND DATEDIFF(SECOND, o.created_at, GETDATE()) <= 604800
),
OrdersWithCompletedReviews AS (
  SELECT 
    o.*,
    0 AS pending_review
  FROM Orders o
  JOIN TrackingDelivered t ON o.order_id = t.tracking_order_id
  WHERE o.order_user_id = @orderUserId
    AND NOT EXISTS (
      SELECT 1
      FROM Order_Items oi
      LEFT JOIN Order_Item_Review oir ON oi.order_item_id = oir.order_item_id
      WHERE oi.order_id = o.order_id
        AND oir.order_item_id IS NULL
    )
)
SELECT *
FROM (
  SELECT * FROM OrdersWithPendingReviews
  UNION
  SELECT * FROM OrdersWithCompletedReviews
) AS FinalOrders
ORDER BY pending_review DESC, created_at DESC`;
    } else {
      // ✅ Default fallback (same as Delivered)
      query = `
      WITH TrackingLatest AS (
  SELECT 
      tracking_order_id, 
      tracking_status
  FROM Tracking
  WHERE tracking_status = @status
  GROUP BY tracking_order_id, tracking_status
),
OrderWithPendingReview AS (
  SELECT 
      o.*,
      t.tracking_status,
      CASE 
          WHEN NOT EXISTS (
              SELECT 1 
              FROM Order_Items oi
              JOIN Order_Item_Review oir ON oi.order_item_id = oir.order_item_id
              WHERE oi.order_id = o.order_id
          )
          AND DATEDIFF(SECOND, o.created_at, GETDATE()) BETWEEN 0 AND 604800
          THEN 1
          ELSE 0
      END AS pending_review
  FROM Orders o
  LEFT JOIN TrackingLatest t ON o.order_id = t.tracking_order_id
  WHERE o.order_user_id = @orderUserId 
  AND t.tracking_status = @status
)
SELECT * 
FROM OrderWithPendingReview
ORDER BY 
  pending_review DESC,
  created_at DESC`;
    }

    const result = await pool
      .request()
      .input("orderUserId", orderUserId)
      .input("offset", offset)
      .input("pageSize", pageSize)
      .input("status", deliveredStatus)
      .query(query);

    return result.recordset || [];
  } catch (error: any) {
    sendErrorEmail("Error fetching order by user ID:", error);

    console.error("Error fetching order by user ID:", error);
    throw new Error("Failed to get order by user ID");
  }
};

export const getOrderItemByOrderId = async (
  order_id: number,
  isUnFulFilled = false
) => {
  const pool = await poolPromise;

  try {
    const unFulfilledCondition = isUnFulFilled
      ? "AND (order_item_fulfillment_status IS NULL OR order_item_fulfillment_status = 'partial' OR order_item_fulfillment_status = 'fulfilled')"
      : "";

    const query = `
    SELECT *
    FROM Order_items
    WHERE order_id = @order_id
    ${unFulfilledCondition}
`;

    const result = await pool
      .request()
      .input("order_id", order_id)
      .query(query);
    return result.recordset || [];
  } catch (error: any) {
    sendErrorEmail("Error fetching order by order id:", error);

    console.error("Error fetching order by order id:", error);
    throw new Error("Failed to get order by order ID");
  }
};

export const getOrderItemById = async (order_item_id: number) => {
  const pool = await poolPromise;

  try {
    const query = `
      SELECT *
      FROM Order_items
      WHERE order_item_id = @order_item_id;
    `;

    const result = await pool
      .request()
      .input("order_item_id", order_item_id)
      .query(query);

    return result.recordset.length > 0 ? result.recordset[0] : false;
  } catch (error: any) {
    sendErrorEmail("Failed to get order item by item id", error);

    throw new Error("Failed to get order item by item id");
  }
};

export const getTrackingOrderById = async (order_id: number) => {
  const pool = await poolPromise;

  try {
    const query = `
      SELECT *
      FROM Tracking
      WHERE order_id = @order_id;
    `;

    const result = await pool
      .request()
      .input("order_id", order_id)
      .query(query);

    // Return the order_shop_id if the order exists, else return null
    return result.recordset || [];
  } catch (error: any) {
    sendErrorEmail("Error fetching order by tracking:", error);

    console.error("Error fetching order by tracking:", error);
    throw new Error("Failed to get order by tracking");
  }
};

export const getTrackingOrderItemById = async (
  tracking_order_item_id: number
) => {
  const pool = await poolPromise;

  try {
    const query = `
      SELECT *
      FROM Tracking_Order_Items
      WHERE tracking_order_item_id = @tracking_order_item_id;
    `;

    const result = await pool
      .request()
      .input("tracking_order_item_id", tracking_order_item_id)
      .query(query);

    // console.log("result", result.recordset);
    if (result.recordset.length > 0) {
      return result.recordset;
    } else {
      return false;
    }
  } catch (error: any) {
    sendErrorEmail("Error fetching order by tracking:", error);

    console.error("Error fetching order by tracking:", error);
    throw new Error("Failed to get order by tracking");
  }
};

export const getOrderById = async (orderId: number) => {
  const pool = await poolPromise;

  try {
    const query = `
      SELECT *
      FROM Orders
      WHERE order_id = @orderId;
    `;

    const result = await pool.request().input("orderId", orderId).query(query);

    // Return the order_shop_id if the order exists, else return null
    return result.recordset[0] || null;
  } catch (error: any) {
    sendErrorEmail("Error fetching order by id:", error);

    console.error("Error fetching order by id:", error);
    throw new Error("Failed to get order by ID");
  }
};

export const getShopTrackingIsEnabled = async (shopId: number) => {
  const pool = await poolPromise;
  const query = `SELECT shop_active_tracking FROM Shops where shop_id = @shopId`;
  try {
    const result = await pool.request().input("shopId", shopId).query(query);
    return result.recordset[0];
  } catch (error: any) {
    sendErrorEmail("Error fetching shop tracking status:", error);

    console.error("Error fetching shop tracking status:", error);
    throw new Error("Failed to get shop tracking status");
  }
};

export const getOrderItemUsingOrderIdNShopifyVarientId = async (
  shopifyOrderId: string,
  shopifyVarientId: string
): Promise<any> => {
  const pool = await poolPromise;

  const query = `
  SELECT oi.order_item_id, oi.order_item_variant_id
    FROM Order_Items oi
    JOIN Product_Variants pv ON oi.order_item_variant_id = pv.variant_id
    WHERE pv.variant_shopify_id = 'gid://shopify/ProductVariant/${shopifyVarientId}'
  AND oi.order_id = ${shopifyOrderId};
  `;

  const result = await pool.request().query(query);

  return result.recordset[0];
};

export const getOrderItemsWithCategory = async (
  orderId: number
): Promise<any> => {
  try {
    const pool = await poolPromise;

    const query = `
      SELECT oi.*, 
          p.product_custom_category_id AS order_item_category
      FROM Order_Items oi
      INNER JOIN Product_Variants pv ON oi.order_item_variant_id = pv.variant_id
      INNER JOIN Products p ON pv.variant_product_id = p.product_id
      WHERE oi.order_id = @orderId;
    `;

    const result = await pool
      .request()
      .input("orderId", Int, orderId)
      .query(query);

    return result.recordset;
  } catch (error: any) {
    sendErrorEmail("Error fetching product variants:", error);

    console.error("Error fetching product variants:", error);
    throw new Error("Failed to fetch product variants for order.");
  }
};

export const getUserOrdersCount = async (user_id: number, status?: string) => {
  const pool = await poolPromise;
  const request = pool.request();

  let query = "";

  request.input("user_id", user_id);

  if (status) {
    query = `
      SELECT COUNT(o.order_id) AS count
      FROM Orders o
      LEFT JOIN Tracking t ON o.order_id = t.tracking_order_id
      WHERE o.order_user_id = @user_id AND t.tracking_status = @status
    `;
    request.input("status", status);
  } else {
    query = `
      SELECT COUNT(*) AS count
      FROM Orders
      WHERE order_user_id = @user_id
    `;
  }

  const result = await request.query(query);
  // console.log("result", result.recordset);
  return result.recordset[0].count || 0;
};

export const OrderPointConnect = async (
  connect_order_id: Number,
  connect_point_log_id: Number
) => {
  const pool = await poolPromise;
  try {
    const query = `
      INSERT INTO Order_Points_Connect(connect_order_id, connect_point_log_id)
      VALUES (@connect_order_id, @connect_point_log_id)
    `;

    const request = pool.request();
    request.input("connect_order_id", connect_order_id);
    request.input("connect_point_log_id", connect_point_log_id);

    const result = await request.query(query);
    return result;
  } catch (error: any) {
    sendErrorEmail("Error in Connect Order Point: ", error);

    console.log("Error in Connect Order Point: ", error);
  }
};
export const getPointLogIdByOrderId = async (order_id: number) => {
  const pool = await poolPromise;
  try {
    console.log("🔍 Fetching Order ID:", order_id); // Debugging

    const query = `
      SELECT * FROM Order_Points_Connect
      WHERE connect_order_id = @order_id;
    `;

    const request = await pool.request(); // ✅ Ensure request is awaited
    request.input("order_id", order_id);

    const result = await request.query(query);

    console.log("✅ Query Result:", result.recordset); // Debugging

    if (result.recordset.length > 0) {
      return result.recordset[0]; // ✅ Return all records
    } else {
      console.log("⚠️ No matching records found");
      return null; // ✅ Return null if no record found
    }
  } catch (error: any) {
    sendErrorEmail("❌ Error in Fetching Data:", error);

    console.error("❌ Error in Fetching Data:", error);
    throw error;
  }
};

export const getOrderDetailById = async (order_id: number) => {
  const pool = await poolPromise;
  const query = `
    SELECT *
    FROM Orders
    WHERE order_id = ${order_id}
  `;
  const result = await pool.request().query(query);
  return result.recordset.length > 0 ? result.recordset[0] : null;
};

export const UpdatePaymentStatus = async (
  order_id: string,
  order_shop_id: string,
  order_payment_status: string
) => {
  try {
    const pool = await poolPromise;
    const query = `
      UPDATE Orders
      SET order_payment_status = @order_payment_status
      WHERE order_id = @order_id AND order_shop_id = @order_shop_id;
    `;

    const dbResponse = await pool
      .request()
      .input("order_id", order_id)
      .input("order_shop_id", order_shop_id)
      .input("order_payment_status", order_payment_status)
      .query(query);
    console.log("Payment status updated successfully", dbResponse);
    return { success: true, message: "Payment status updated successfully" };
  } catch (error: any) {
    sendErrorEmail("Error in updating payment status:", error);

    console.error("Error in updating payment status:", error);
    throw new Error("Failed to update payment status.");
  }
};

export const UpdateUsageCharged = async (
  order_id: string,
  order_shop_id: string,
  order_usage_charged: boolean
) => {
  try {
    const pool = await poolPromise;
    const query = `
      UPDATE Orders
      SET order_usage_charged = @order_usage_charged
      WHERE order_id = @order_id AND order_shop_id = @order_shop_id;
    `;

    const dbResponse = await pool
      .request()
      .input("order_id", order_id)
      .input("order_shop_id", order_shop_id)
      .input("order_usage_charged", order_usage_charged)
      .query(query);
    console.log("Order charged updated successfully", dbResponse);
    return { success: true, message: "Order charged updated successfully" };
  } catch (error: any) {
    sendErrorEmail("Error in updating Order charged:", error);

    console.error("Error in updating Order charged:", error);
    throw new Error("Failed to update Order charged.");
  }
};

export const updateCancellationByOrderShopifyId = async (
  order_shopify_id: string,
  order_cancel_by?: string
) => {
  try {
    const pool = await poolPromise;

    const query = `
      UPDATE Orders
      SET order_cancelled_by = @order_cancel_by
      WHERE order_shopify_id = @order_shopify_id
    `;

    await pool
      .request()
      .input("order_shopify_id", order_shopify_id)
      .input("order_cancel_by", order_cancel_by || null) // Use `null` if no value is provided
      .query(query);

    console.log(
      `Order ${order_shopify_id} updated successfully with cancelled by: ${order_cancel_by}`
    );
  } catch (error: any) {
    sendErrorEmail("updateCancellationByOrderShopifyId", error);

    throw error;
  }
};

export const getLatestOrder = async (user_id: number, shop_id: number) => {
  try {
    const pool = await poolPromise;

    const query = `
      SELECT TOP 1 *
      FROM Orders
      WHERE order_user_id = @user_id
        AND order_shop_id = @shop_id
        AND created_at >= DATEADD(MINUTE, -5, GETDATE())
      ORDER BY created_at DESC;
    `;

    const result = await pool
      .request()
      .input("user_id", user_id)
      .input("shop_id", shop_id)
      .query(query);

    return result.recordset?.[0] || null;
  } catch (error: any) {
    sendErrorEmail("Error fetching latest order:", error);

    console.error("Error fetching latest order:", error);
    throw error;
  }
};
export const getActiveOrdersByUserId = async (
  userId: number,
  page = 1,
  pageSize = 10
) => {
  const pool = await poolPromise;
  const offset = (page - 1) * pageSize;

  const query = `
    -- One row per order, no DISTINCT needed
SELECT
  o.*,
  oi_ca.order_item_variant_id,
  t_ca.id               AS id,             -- tracking_id
  t_ca.tracking_order_id,
  t_ca.tracking_status,
  t_ca.tracking_number,
  s.shop_name,
  s.shop_currency
FROM Orders o
-- pick one variant for the order (stable order by primary key)
OUTER APPLY (
  SELECT TOP (1) oi.order_item_variant_id
  FROM Order_Items oi
  WHERE oi.order_id = o.order_id
  ORDER BY oi.order_item_id
) AS oi_ca
-- pick the latest tracking row in the active statuses
OUTER APPLY (
  SELECT TOP (1)
         t.id, t.tracking_order_id, t.tracking_status, t.tracking_number
  FROM Tracking t
  WHERE t.tracking_order_id = o.order_id
    AND t.tracking_status IN ('IN_PROGRESS','OUT_FOR_DELIVERY','IN_TRANSIT')
  ORDER BY t.updated_at DESC, t.id DESC
) AS t_ca
JOIN Shops s
  ON o.order_shop_id = s.shop_id
WHERE o.order_user_id = @userId
  AND t_ca.id IS NOT NULL                    -- ensure it has an active tracking row
ORDER BY o.created_at DESC
OFFSET @offset ROWS
FETCH NEXT @pageSize ROWS ONLY;

  `;

  const result = await pool
    .request()
    .input("userId", userId)
    .input("offset", offset)
    .input("pageSize", pageSize)
    .query(query);

  return result.recordset || [];
};

export const getOrderByOrderId = async (order_id: number) => {
  const pool = await poolPromise;

  const orderResult = await pool.request().input("order_id", order_id).query(`
      SELECT * 
      FROM Orders 
      LEFT JOIN Cart_Discount_Codes c ON c.cart_discount_order_id = Orders.order_id
      LEFT JOIN Vouchers v ON v.voucher_order_id = Orders.order_id
      WHERE Orders.order_id = @order_id;
    `);

  const order = orderResult.recordset[0];

  const orderItemsResult = await pool
    .request()
    .input("order_id", order_id)
    .query(`SELECT * FROM Order_Items WHERE order_id = @order_id`);

  const orderItems = orderItemsResult.recordset;

  const trackingResult = await pool
    .request()
    .input("order_id", order_id)
    .query(`SELECT * FROM Tracking WHERE tracking_order_id = @order_id`);

  const tracking = trackingResult.recordset;

  let trackingOrderItems: any[] = [];

  if (tracking.length > 0) {
    const trackingIds = tracking.map((row) => row.id);
    const inClause = trackingIds.join(",");

    const trackingOrderItemsResult = await pool
      .request()
      .query(
        `SELECT * FROM Tracking_Order_Items WHERE tracking_id IN (${inClause})`
      );

    trackingOrderItems = trackingOrderItemsResult.recordset;
  }
  const finalResult = {
    order,
    orderItems,
    tracking,
    trackingOrderItems,
  };
  console.log("Result", finalResult);

  return {
    order,
    orderItems,
    tracking,
    trackingOrderItems,
  };
};

export const getOrderByOrderIdMob = async (
  order_id: number,
  tracking_id?: number
) => {
  const pool = await poolPromise;

  const query = `
    WITH OrderWithPin AS (
        SELECT 
            o.order_id,
            o.order_title,
            o.order_shop_id,
            o.order_user_id,
            o.order_cancelled_by,
            o.order_total_amount,
            o.created_at,
            o.updated_at,
            o.order_date,
            u.user_id,
            u.user_name,
            s.shop_name,
            t.tracking_status,
            t.tracking_number,
            t.tracking_events,
            t.id AS tracking_id,
            oi.order_item_id,
            oi.order_item_variant_id,
            CASE
                WHEN t.tracking_status = 'DELIVERED'
                    AND DATEDIFF(SECOND, o.updated_at, GETDATE()) BETWEEN 0 AND 604800
                    AND NOT EXISTS (
                        SELECT 1
                        FROM Order_Items oi2
                        JOIN Order_Item_Review oir 
                            ON oi2.order_item_id = oir.order_item_id
                        WHERE oi2.order_id = o.order_id
                    )
                THEN 1 ELSE 0 END AS pin_delivered_recent
        FROM Orders o
        JOIN Users u ON o.order_user_id = u.user_id
        JOIN Shops s ON o.order_shop_id = s.shop_id
        LEFT JOIN Order_Items oi ON oi.order_id = o.order_id
        LEFT JOIN Tracking_Order_Items toi ON toi.tracking_order_item_id = oi.order_item_id
        LEFT JOIN Tracking t ON t.id = toi.tracking_id
        WHERE o.order_id = @order_id
    )
    SELECT * 
    FROM OrderWithPin
    ORDER BY pin_delivered_recent DESC, created_at DESC;
  `;

  const orderResult = await pool
    .request()
    .input("order_id", order_id)
    .query(query);

  console.log("tracking_id", tracking_id);

  let item = tracking_id
    ? orderResult.recordset.find((i) => i.tracking_id == tracking_id)
    : orderResult.recordset.find((i) => !i.tracking_id);

  console.log("item123", item);

  if (!item) return null;

  const shopDetail = await getUsingShopId(item.order_shop_id);

  if (item.tracking_id) {
    const trackingItems = await getTrackingItemsById(item.tracking_id);
    const modifiedItems = await Promise.all(
      trackingItems.map(async (trackingItem: any) => {
        const [variant, review_item] = await Promise.all([
          getVariantById(trackingItem.order_item_variant_id),
          getOrderItemReviewById(trackingItem.tracking_order_item_id),
        ]);
        return {
          ...trackingItem,
          ...variant,
          review_item,
          review_completed: Boolean(review_item),
        };
      })
    );
    item.order_item = modifiedItems;
  } else {
    const orderItems = await getOrderItemByOrderId(item.order_id, true);
    const modifiedItems = await Promise.all(
      orderItems.map(async (orderItem: any) => {
        const [variant, review_item] = await Promise.all([
          getVariantById(orderItem.order_item_variant_id),
          getOrderItemReviewById(orderItem.order_item_id),
        ]);
        return {
          ...orderItem,
          ...variant,
          review_item,
          review_completed: Boolean(review_item),
        };
      })
    );
    item.order_item = modifiedItems;
    console.log("orderItems", orderItems);
  }
  return {
    ...item,
    shop_detail: shopDetail,
  };
};

export const getOrderReceipt = async (
  order_id: number,
  tracking_id?: number,
  no_tracking?: boolean
) => {
  const pool = await poolPromise;

  const orderResult = await pool.request().input("order_id", order_id).query(`
      SELECT * 
      FROM Orders 
      LEFT JOIN Cart_Discount_Codes c ON c.cart_discount_order_id = Orders.order_id
      LEFT JOIN Vouchers v ON v.voucher_order_id = Orders.order_id
      LEFT JOIN Users u ON u.user_id = Orders.order_user_id
      WHERE Orders.order_id = @order_id;
    `);

  const item = orderResult.recordset[0];

  const shop_detail = await getShopWithRatingUsingShopId(item.order_shop_id);
  const orderItem = await getOrderItemByOrderId(item.order_id);
  const orderTracking = await getTrackingByOrderId(item.order_id, true);

  // Modify order variants
  const modifiedOrderVaraints = await Promise.all(
    orderItem.map(async (item: any) => {
      const orderVaraints = await getVariantById(item.order_item_variant_id);
      const review_item = await getOrderItemReviewById(item.order_item_id);
      return {
        ...item,
        ...orderVaraints,
        review_item,
        review_completed: Boolean(review_item),
      };
    })
  );

  // Modify order items and filter out empty ones
  const modifiedOrderItem = (
    await Promise.all(
      orderItem.map(async (item: any) => {
        const trackingOrderItems = await getTrackingOrderItemById(
          item.order_item_id
        );
        return trackingOrderItems ? trackingOrderItems : [];
      })
    )
  ).filter(Boolean); // Remove null values
  // console.log("object1234", modifiedOrderItem.flat());

  const modifiedData = {
    ...item,
    shop_detail,
    order_item: modifiedOrderVaraints,
    order_tracking: orderTracking,
    order_tracking_item: modifiedOrderItem.flat(),
  };

  const data = modifiedData.order_tracking.map((tracking: any) => {
    const orderItem = modifiedData.order_tracking_item.filter(
      (orderItem: any) => orderItem.tracking_id === tracking.id
    );
    const orderItemIds =
      orderItem.map((item: any) => item.tracking_order_item_id) || [];
    console.log("orderItemIds", orderItemIds);
    const orderItemFilter = modifiedData?.order_item.filter((item: any) =>
      orderItemIds.includes(item?.order_item_id)
    );
    return {
      ...modifiedData,
      order_item: orderItemFilter,
      order_tracking: tracking,
      order_tracking_item: orderItem,
    };
  });

  const unFullFilled = data.find(
    (item: any) => item.order_tracking_item?.length === 0
  );
  const trackingItem = data.find(
    (item: any) => item.order_tracking?.id === tracking_id
  );
  const initialItem = {
    ...item,
    shop_detail,
    order_item: modifiedOrderVaraints,
    order_tracking: orderTracking,
    order_tracking_item: modifiedOrderItem.flat(),
  };

  console.log("unFullFilled", unFullFilled);

  if (tracking_id) {
    return trackingItem;
  } else if (no_tracking) {
    return modifiedData;
  } else {
    return initialItem;
  }
};

export const getUserOrdersCountByShopDomain = async (shopDomain: string) => {
  try {
    const pool = await poolPromise;
    const query = `
    SELECT 
        s.shop_domain,
    COUNT(o.order_id) AS order_count
    FROM Shops s
    LEFT JOIN Orders o ON s.shop_id = o.order_shop_id
    WHERE s.shop_domain = @shopDomain
    GROUP BY s.shop_domain
`;
    const response = await pool
      .request()
      .input("shopDomain", shopDomain)
      .query(query);
    const result = response.recordset[0];
    return result;
  } catch (error: any) {
    sendErrorEmail("Error Counting Products", error);

    console.log("Error Counting Products", error.message);
  }
};

export const updateOrderFulfillmentStatus = async (order_id: number) => {
  const pool = await poolPromise;
  const getOrderItemStatus = `
    SELECT order_item_fulfillment_status 
    FROM Order_Items 
    WHERE order_id = @order_id
  `;
  const updateQuery = `
    UPDATE Orders 
    SET order_fulfillment_status = @order_fulfillment_status 
    WHERE order_id = @order_id
  `;

  try {
    const result = await pool
      .request()
      .input("order_id", order_id)
      .query(getOrderItemStatus);

    if (!result.recordset.length) {
      return {
        success: false,
        message: "No items found for the given order_id",
      };
    }

    const statuses = result.recordset.map(
      (item: any) => item.order_item_fulfillment_status
    );
    const allFulfilled = statuses.every((status) => status === "fulfilled");
    const orderStatus = allFulfilled ? "fulfilled" : "partial";

    await pool
      .request()
      .input("order_id", order_id)
      .input("order_fulfillment_status", orderStatus)
      .query(updateQuery);

    return {
      success: true,
      message: `Order fulfillment status updated to '${orderStatus}'`,
      orderStatus,
    };
  } catch (error: any) {
    sendErrorEmail("Error Updating Order Status:", error);

    console.error("Error Updating Order Status:", error.message);
    return {
      success: false,
      message: "Error updating order fulfillment status",
      error: error.message,
    };
  }
};

export const unsetShopRefForShopifyOrders = async (
  shopifyOrderIds: Array<string | number>
) => {
  const pool = await poolPromise;

  for (const rawId of shopifyOrderIds) {
    const oid = String(rawId);
    await pool.request().input("oid", NVarChar(50), oid).query(`
        UPDATE Orders
        SET order_shop_id = NULL
        WHERE order_shopify_id = @oid
          AND order_channel = 'online_store';
      `);
  }
};

export const saveErrorOrderData = async (
  orderPayload: object,
  shopDomain: string | null
) => {
  const pool = await poolPromise;
  let query = ``;
  try {
    if (shopDomain) {
      const shop = await getShopByDomain(shopDomain);

      query = `
        INSERT INTO Error_Orders (error_order_shop_id, error_order_payload)
        VALUES (@shopId, @orderPayload)
      `;
      await pool
        .request()
        .input("shopId", Int, shop?.shop_id || null)
        .input("orderPayload", NVarChar, JSON.stringify(orderPayload))
        .query(query);
      console.log("Error order data saved successfully");
    } else {
      query = `
        INSERT INTO Error_Orders (error_order_payload)
        VALUES (@orderPayload)
      `;
      await pool
        .request()
        .input("orderPayload", NVarChar, JSON.stringify(orderPayload))
        .query(query);
      console.log("Error order data saved successfully without shop id");
    }
  } catch (error: any) {
    console.log("unable to save error order payload", error.message);
    throw new Error("unable to save error order payload");
  }
};
