import { poolPromise } from "../../config/db";
import {
  PREF_MAP,
  Preference,
  sanitizeRules,
} from "../../types/notifyPerference/notificationPreference";

export const upsertMerchantNotifPref = async (
  userId: number,
  merchantId: number,
  preference: Preference, // 'none' | 'all' | 'personalized'
  rules?: any[] // strings or { code: string, ... }
) => {
  const prefValue = PREF_MAP[preference]; // 0/1/2
  const cleanCodes = prefValue === 1 ? sanitizeRules(rules) : [];
  const rulesJson = JSON.stringify(cleanCodes);

  const sql = `
    MERGE [cymbiote].[dbo].[Shop_Notification_Preferences] AS tgt
    USING (
      SELECT 
        CAST(@userId AS INT)           AS notification_user_id,
        CAST(@merchantId AS INT)       AS notification_shop_id,
        CAST(@prefValue AS TINYINT)    AS notification_preference_type,
        CAST(@rulesJson AS NVARCHAR(MAX)) AS notification_preference_rules
    ) AS src
      ON (tgt.notification_user_id = src.notification_user_id
          AND tgt.notification_shop_id = src.notification_shop_id)
    WHEN MATCHED THEN
      UPDATE SET 
        notification_preference_type  = src.notification_preference_type,
        notification_preference_rules = src.notification_preference_rules
    WHEN NOT MATCHED THEN
      INSERT (notification_user_id, notification_shop_id, notification_preference_type, notification_preference_rules)
      VALUES (src.notification_user_id, src.notification_shop_id, src.notification_preference_type, src.notification_preference_rules)
    OUTPUT inserted.*;
  `;

  const pool = await poolPromise;
  const res = await pool
    .request()
    .input("userId", userId)
    .input("merchantId", merchantId)
    .input("prefValue", prefValue)
    .input("rulesJson", rulesJson)
    .query(sql);

  const row = res.recordset?.[0];
  if (!row) throw new Error("Upsert returned no row");
  return row;
};
