import { poolPromise } from "../../config/db";
import sql from "mssql";
import { TrackingEvent } from "../../types/tracking/TrackingEvent";
import { sendErrorEmail } from "../../services/emailService";
import getBaseUrl from "../../functions/getBaseUrl";

export const saveTrackingInfo = async (
  orderId: number,
  trackingNumber: string | null,
  carrierCode: string | null,
  trackingShopifyId: string,
  trackingUrl: string | null,
  trackingIsAutomated: boolean = true
) => {
  const pool = await poolPromise;

  try {
    const normalizedTrackingNumber =
      trackingNumber && trackingNumber.trim() !== "" ? trackingNumber : null;

    const normalizedCarrierCode =
      carrierCode && carrierCode !== "" ? carrierCode : null;

    const normalizedTrackingUrl =
      trackingUrl && trackingUrl.trim() !== "" ? trackingUrl : null;

    // Execute updated stored procedure
    const result = await pool
      .request()
      .input("OrderId", orderId)
      .input("TrackingNumber", normalizedTrackingNumber)
      .input("CarrierCode", normalizedCarrierCode)
      .input("TrackingShopifyId", trackingShopifyId)
      .input("TrackingUrl", normalizedTrackingUrl)
      .input("TrackingIsAutomated", trackingIsAutomated)
      .execute("InsertTracking");

    return result.recordset[0];
  } catch (error: any) {
    sendErrorEmail("Error saving tracking information:", error);
    console.error("Error saving tracking information:", error);
    throw new Error("Database operation failed.");
  }
};

export const saveTrackingOrderItems = async (
  trackingOrderId: number,
  orderItems: { orderItemId: number; quantity: number }[]
) => {
  try {
    const pool = await poolPromise;
    const table = new sql.Table("Tracking_Order_Items");
    table.columns.add("tracking_order_item_id", sql.Int, { nullable: false });
    table.columns.add("tracking_order_item_quantity", sql.Int, {
      nullable: true,
    });
    table.columns.add("tracking_id", sql.Int, {
      nullable: false,
    });

    // Add rows to the table
    orderItems.forEach((item) => {
      table.rows.add(item.orderItemId, item.quantity, trackingOrderId);
    });

    const result = await pool.request().bulk(table);
    console.log("result New", result);
    return true; // Successfully inserted
  } catch (error: any) {
    sendErrorEmail("Error saving tracking order items:", error);

    console.error("Error saving tracking order items:", error);
    throw error;
  }
};

export const updateOrderItemStatus = async (
  fulfillment_status: string,
  order_id: number,
  variant_id: number
) => {
  const pool = await poolPromise;
  try {
    const query = `UPDATE Order_Items SET order_item_fulfillment_status = @fulfillment_status WHERE order_id = @order_id AND order_item_variant_id = @variant_id;`;
    const result = await pool
      .request()
      .input("fulfillment_status", fulfillment_status)
      .input("order_id", order_id)
      .input("variant_id", variant_id)
      .query(query);
    return result.recordset;
  } catch (error: any) {
    sendErrorEmail("Error updating order item status:", error);

    console.error("Error updating order item status:", error);
    throw new Error("Failed to update order item status");
  }
};

export const getTrackingByNumber = async (
  trackingNumber: string,
  userId?: number // Made optional
) => {
  const pool = await poolPromise;

  try {
    // 1. Initialize the request
    const request = pool
      .request()
      .input("trackingNum", sql.NVarChar, trackingNumber);

    // 2. Start the query
    let query = `
      SELECT T.*, U.user_id 
      FROM Tracking T 
      INNER JOIN Orders O ON O.order_id = T.tracking_order_id
      INNER JOIN Users U ON U.user_id = O.order_user_id
      WHERE tracking_number = @trackingNum`;

    // 3. Dynamically append condition if userId exists
    if (userId) {
      query += ` AND U.user_id = @userId`;
      request.input("userId", sql.Int, userId);
    }

    // 4. Execute query
    const result = await request.query(query);

    console.log("getTrackingByNumber result", trackingNumber, result);

    return result.recordset[0] || null;
  } catch (error: any) {
    sendErrorEmail("Error while fetching tracking info:", error);
    console.error("Error while fetching tracking info:", error);
    throw new Error("Failed to get tracking by number");
  }
};

export const updateTrackingEvents = async (
  events: TrackingEvent[],
  trackingId: number,
  status: string
) => {
  console.log("updateTrackingEvents", events.length, trackingId, status);

  switch (status) {
    case "DELIVERED":
      status = "DELIVERED";
      break;
    case "INTRANSIT":
      status = "IN_TRANSIT";
      break;
    case "OUTFORDELIVERY":
      status = "OUT_FOR_DELIVERY";
      break;
    case "INPROGRESS":
      status = "IN_PROGRESS";
      break;
    case "FAILED":
      status = "FAILED";
      break;
  }

  try {
    const pool = await poolPromise;
    console.log("status", status);

    // Convert the events array to a JSON string
    const eventsJson = JSON.stringify(events);

    const query = `
      UPDATE Tracking
      SET tracking_events = @trackingEvents, tracking_status = @status, updated_at = GETDATE()
      WHERE id = @id;
    `;

    // Execute the SQL query
    const result = await pool
      .request()
      .input("trackingEvents", eventsJson)
      .input("id", trackingId)
      .input("status", status)
      .query(query);

    return { success: true, rowsAffected: result.rowsAffected };
  } catch (error: any) {
    sendErrorEmail("Error updating tracking events:", error);

    console.error("Error updating tracking events:", error);
    return { success: false, error: error.message };
  }
};

export const getTrackingByOrderIdModel = async (
  orderId: number,
  allTracking?: Boolean
) => {
  const pool = await poolPromise;

  const query = `
    SELECT * FROM Tracking
    WHERE tracking_order_id = @orderId
  `;

  const result = await pool.request().input("orderId", orderId).query(query);

  return allTracking ? result.recordset : result.recordset[0];
};

export const getTrackingItemByModel = async (trackingId: number) => {
  const pool = await poolPromise;

  const query = `
    SELECT 
        toi.*, 
        oi.order_item_variant_id,
        oi.order_item_price,
        oi.order_item_quantity
    FROM Tracking_Order_Items AS toi
    INNER JOIN Order_Items AS oi 
        ON toi.tracking_order_item_id = oi.order_item_id
    WHERE toi.tracking_id = @trackingId;
  `;

  const result = await pool
    .request()
    .input("trackingId", trackingId)
    .query(query);

  return result.recordset;
};

export const updateDelieveryStatus = async (
  order_id: string,
  order_shop_id: string,
  order_delivery_status: string
) => {
  try {
    const pool = await poolPromise;
    const query = `
      UPDATE Orders SET order_delivery_status = @order_delivery_status, updated_at = GETDATE()  WHERE order_id = @order_id AND order_shop_id = @order_shop_id;`;
    const result = await pool
      .request()
      .input("order_id", order_id)
      .input("order_shop_id", order_shop_id)
      .input("order_delivery_status", order_delivery_status)
      .query(query);
    return result;
  } catch (error: any) {
    sendErrorEmail("Error updating delivery status:", error);

    console.error("Error updating delivery status:", error);
    throw new Error("Failed to update delivery status");
  }
};

export const checkTrackingUsingOrderShopifyId = async (
  orderShopifyId: number
) => {
  const pool = await poolPromise;
  const getdatequery = `
    SELECT TOP 1
      s.subscription_charge_date,
      p.package_trial_days
    FROM subscriptions s
    INNER JOIN Packages p ON s.subscription_package_id = p.package_id
    WHERE s.subscription_shop_id = @shop_id;
  `;
  const gettrackingquery = `
    SELECT 
      S.shop_id, S.shop_active_tracking
    FROM Orders O
    INNER JOIN Shops S ON O.order_shop_id = S.shop_id
    WHERE O.order_shopify_id = @orderShopifyId
  `;
  try {
    const request = await pool
      .request()
      .input("orderShopifyId", orderShopifyId)
      .query(gettrackingquery);

    // console.log("gettrackingquery", request.recordset[0]);

    const tracking = request.recordset?.[0]?.shop_active_tracking;
    if (tracking === true) {
      // console.log("tracking", tracking);
      return tracking;
    } else {
      const requestdate = await pool
        .request()
        .input("shop_id", request.recordset[0]?.shop_id)
        .query(getdatequery);
      // console.log("requestdate", requestdate.recordset[0]);
      if (requestdate.recordset.length > 0) {
        const chargeDate = new Date(
          requestdate.recordset[0].subscription_charge_date
        );
        const trialDays = requestdate.recordset[0].package_trial_days;

        const now = new Date();
        const trialEndDate = new Date(chargeDate);
        trialEndDate.setDate(trialEndDate.getDate() + trialDays);

        const diffMs = trialEndDate.getTime() - now.getTime();
        const remainingTrialDays = Math.max(
          Math.floor(diffMs / (1000 * 60 * 60 * 24)),
          0
        );

        console.log("Remaining trial days:", remainingTrialDays);
        return remainingTrialDays > 0;
      }
    }
  } catch (error: any) {
    sendErrorEmail("Error fetching tracking ", error);

    throw new Error("Error fetching tracking " + error.message);
  }
};

export const cancelTracking = async (
  status: string,
  order_id: number,
  tracking_number: number
) => {
  try {
    if (status === "cancelled") {
      const pool = await poolPromise;

      const query = `
  BEGIN TRAN;

  DELETE toi
  FROM Tracking_Order_Items toi
  JOIN Tracking t ON toi.tracking_id = t.id
  WHERE t.tracking_order_id = @order_id
  AND t.tracking_number = @tracking_number ;

  DELETE t
  FROM Tracking t
  WHERE t.tracking_order_id = @order_id
  AND t.tracking_number = @tracking_number;

  COMMIT TRAN;
    `;

      const result = await pool
        .request()
        .input("order_id", order_id)
        .input("tracking_number", tracking_number)
        .query(query);

      return result;
    }
  } catch (error: any) {
    sendErrorEmail("Error cancelling tracking:", error);

    console.error("Error cancelling tracking:", error);
  }
};

export const updateTrackingNumber = async (
  fulfillment_id: number,
  new_tracking_number: string
) => {
  try {
    const pool = await poolPromise;

    const query = `
      UPDATE Tracking 
      SET tracking_number = @new_tracking_number, updated_at = GETDATE()
      WHERE tracking_shopify_id = @fulfillment_id
    `;

    const result = await pool
      .request()
      .input("new_tracking_number", new_tracking_number)
      .input("fulfillment_id", fulfillment_id)
      .query(query);

    return result;
  } catch (error: any) {
    sendErrorEmail("Error updating tracking number:", error);
    console.error("Error updating tracking number:", error);
    throw error;
  }
};

export const updateTrackingUrl = async (
  fulfillment_id: number,
  new_tracking_url: string
) => {
  try {
    const pool = await poolPromise;

    const query = `
      UPDATE Tracking 
      SET tracking_url = @new_tracking_url, updated_at = GETDATE()
      WHERE tracking_shopify_id = @fulfillment_id
    `;

    const result = await pool
      .request()
      .input("new_tracking_url", new_tracking_url)
      .input("fulfillment_id", fulfillment_id)
      .query(query);

    return result;
  } catch (error: any) {
    sendErrorEmail("Error updating tracking URL:", error);
    console.error("Error updating tracking URL:", error);
    throw error;
  }
};

export const updateTrackingEventsWithCustomTracking = async (
  trackingId: number,
  events: any[],
  courierId: number
) => {
  try {
    const pool = await poolPromise;

    const query = `
      UPDATE Tracking 
      SET tracking_carrier_code = @tracking_courier_id, tracking_events = @tracking_events, updated_at = GETDATE()
      WHERE id = @trackingId
    `;

    const result = await pool
      .request()
      .input("tracking_events", JSON.stringify(events))
      .input("trackingId", trackingId)
      .input("tracking_courier_id", courierId)
      .query(query);

    return result;
  } catch (error: any) {
    sendErrorEmail("Error updating tracking events:", error);
    console.error("Error updating tracking events:", error);
    throw error;
  }
};

export const updateTrackingCarrier = async (
  trackingId: number,
  carrierCode: string
) => {
  try {
    const pool = await poolPromise;

    const query = `
      UPDATE Tracking 
      SET tracking_carrier_code = @carrierCode, updated_at = GETDATE()
      WHERE id = @trackingId
    `;

    const result = await pool
      .request()
      .input("carrierCode", carrierCode)
      .input("trackingId", trackingId)
      .query(query);

    return result;
  } catch (error: any) {
    console.error("Error updating tracking carrier:", error);
    throw error;
  }
};

export const getManualTrackingByTrackingNumber = async (
  trackingNumber: string,
  userId: number
) => {
  const pool = await poolPromise;

  console.log("tracking number", trackingNumber);

  try {
    const query = `SELECT * FROM Manual_Trackings WHERE manual_tracking_number = @trackingNumber 
    AND manual_tracking_user_id = @userId;`;

    const result = await pool
      .request()
      .input("trackingNumber", sql.NVarChar(50), trackingNumber.toString())
      .input("userId", sql.Int, userId)
      .query(query);

    return result.recordset[0] || null;
  } catch (error: any) {
    throw new Error("Error to query from Manual_Trackings " + error.message);
  }
};

export const insertManualTracking = async (
  tracking_user_id: number,
  tracking_name: string,
  tracking_number: string,
  tracking_status: string,
  tracking_url: string,
  tracking_payload: object,
  tracking_courier: number
) => {
  const pool = await poolPromise;
  try {
    const query = `INSERT INTO Manual_Trackings(manual_tracking_user_id, manual_tracking_name, manual_tracking_number, manual_tracking_status, manual_tracking_payload, manual_tracking_courier) 
    VALUES (@trackingUserId, @trackingName, @trackingNumber, @trackingStatus, @trackingPayload, @trackingCarrierCode); 
    SELECT SCOPE_IDENTITY() AS insertedId;`;

    const result = await pool
      .request()
      .input("trackingUserId", tracking_user_id)
      .input("trackingName", tracking_name)
      .input("trackingNumber", tracking_number)
      .input("trackingStatus", tracking_status)
      .input("trackingPayload", JSON.stringify(tracking_payload))
      .input("trackingCarrierCode", tracking_courier)
      .query(query);

    // console.log("insertManualTracking result", result);

    return result.recordset[0]?.insertedId || null;
  } catch (error: any) {
    // sendErrorEmail("Error inserting manual tracking:", error.message);
    console.error("Error inserting manual tracking:", error.message);

    throw new Error("Failed to insert manual tracking in db" + error.message);
  }
};

export const getTrackingCouriers = async (courier_id: number) => {
  try {
    const pool = await poolPromise;
    const query = `SELECT * FROM Couriers WHERE courier_id = @courierId AND courier_active = 1;`;

    const result = await pool
      .request()
      .input("courierId", courier_id)
      .query(query);
    return result.recordset[0] || null;
  } catch (error: any) {
    throw new Error("Failed to fetch tracking couriers:" + error.message);
  }
};

export const getActiveCouriersFromDB = async () => {
  const pool = await poolPromise;

  try {
    const query = `
      SELECT 
        courier_id,
        courier_name,
        courier_active,
        courier_url,
        courier_image_url
      FROM Couriers
      WHERE courier_active = 1
      ORDER BY courier_name ASC;
    `;

    const result = await pool.request().query(query);
    return result.recordset || [];
  } catch (error: any) {
    throw new Error("Failed to fetch active couriers: " + error.message);
  }
};

export const getUserManualTrackingsByUserId = async (
  user_id: number,
  page: number = 1,
  pageSize: number = 10
) => {
  const pool = await poolPromise;
  const offset = (page - 1) * pageSize;

  try {
    // Fetch paginated results
    const result = await pool
      .request()
      .input("user_id", user_id)
      .input("offset", offset)
      .input("pageSize", pageSize).query(`
        SELECT 
          mt.manual_tracking_id, 
          mt.manual_tracking_name, 
          mt.manual_tracking_number, 
          mt.manual_tracking_status,
          mt.manual_tracking_courier AS manual_tracking_courier_id,
          c.courier_name AS manual_tracking_courier,
          mt.manual_tracking_user_id, 
          mt.manual_tracking_payload, 
          mt.created_at, 
          mt.updated_at
        FROM Manual_Trackings mt
        INNER JOIN Couriers c 
          ON c.courier_id = mt.manual_tracking_courier
        WHERE mt.manual_tracking_user_id = @user_id
        ORDER BY mt.created_at DESC
        OFFSET @offset ROWS
        FETCH NEXT @pageSize ROWS ONLY;
      `);

    // Fetch total count for pagination
    const countResult = await pool.request().input("user_id", user_id).query(`
        SELECT COUNT(*) AS total
        FROM Manual_Trackings
        WHERE manual_tracking_user_id = @user_id;
      `);

    const total = countResult.recordset[0]?.total || 0;

    return { trackings: result.recordset || [], total };
  } catch (error: any) {
    throw new Error("Failed to fetch manual trackings: " + error.message);
  }
};

export const getManualTrackingsById = async (trackingId: number) => {
  const pool = await poolPromise;

  try {
    const query = `
      SELECT 
        mt.manual_tracking_id, 
        mt.manual_tracking_name, 
        mt.manual_tracking_number, 
        mt.manual_tracking_status,
        mt.manual_tracking_courier AS manual_tracking_courier_id,
        c.courier_name AS manual_tracking_courier,
        mt.manual_tracking_user_id, 
        mt.manual_tracking_payload, 
        mt.created_at, 
        mt.updated_at
      FROM Manual_Trackings mt
      INNER JOIN Couriers c ON c.courier_id = mt.manual_tracking_courier
      WHERE mt.manual_tracking_id = @tracking_id;
    `;

    const result = await pool
      .request()
      .input("tracking_id", sql.Int, trackingId)
      .query(query);

    return result.recordset[0] || null;
  } catch (error: any) {
    throw new Error("Failed to fetch manual trackings: " + error.message);
  }
};

export const deleteManualTrackingById = async (trackingId: number) => {
  const pool = await poolPromise;

  try {
    const query = `
      DELETE FROM Manual_Trackings
      WHERE manual_tracking_id = @tracking_id;
    `;

    const result = await pool
      .request()
      .input("tracking_id", sql.Int, trackingId)
      .query(query);

    // rowsAffected[0] gives the number of rows deleted
    return result.rowsAffected[0] > 0;
  } catch (error: any) {
    throw new Error("Failed to delete manual tracking: " + error.message);
  }
};

export const getCourierByTrackingUrl = async (trackingUrl: string) => {
  try {
    const couriers = await getActiveCouriersFromDB();

    // Normalize tracking URL for comparison
    const normalizedTrackingUrl = trackingUrl.toLowerCase();

    console.log("normalizedTrackingUrl", normalizedTrackingUrl);

    // Find courier where tracking URL contains courier URL (or vice versa pattern)
    // Assuming courier_url in DB is something like "tcsexpress.com" or "leopardscourier.com"
    const matchedCourier = couriers.find((courier: any) => {
      if (!courier.courier_url) return false;
      const normalizedCourierUrl = getBaseUrl(
        courier.courier_url.toLowerCase()
      );
      return normalizedTrackingUrl.includes(normalizedCourierUrl);
    });

    return matchedCourier || null;
  } catch (error: any) {
    console.error("Error finding courier by URL:", error);
    return null;
  }
};

// Cron Job Functions
export const getActiveManualTrackingsForUpdate = async (
  batchSize: number = 50,
  minMinutesSinceUpdate: number = 10
) => {
  const pool = await poolPromise;

  try {
    const query = `
      SELECT TOP (@batchSize)
        mt.manual_tracking_id,
        mt.manual_tracking_number,
        mt.manual_tracking_status,
        mt.manual_tracking_user_id,
        mt.manual_tracking_name,
        c.courier_id,
        mt.updated_at
      FROM Manual_Trackings mt
      INNER JOIN Couriers c ON mt.manual_tracking_courier = c.courier_id
      WHERE 
        mt.manual_tracking_status NOT IN ('Delivered', 'Failed', 'Returned', 'Cancelled')
        AND DATEDIFF(MINUTE, mt.updated_at, GETDATE()) >= @minMinutes
      ORDER BY 
        CASE 
          WHEN mt.manual_tracking_status IN ('Transit', 'In Transit') THEN 1
          WHEN mt.manual_tracking_status = 'Shipped' THEN 2
          ELSE 3
        END,
        mt.updated_at ASC;
    `;

    const result = await pool
      .request()
      .input("batchSize", sql.Int, batchSize)
      .input("minMinutes", sql.Int, minMinutesSinceUpdate)
      .query(query);

    return result.recordset || [];
  } catch (error: any) {
    console.error("Error fetching active manual trackings for update:", error);
    throw new Error(
      "Failed to fetch active manual trackings: " + error.message
    );
  }
};

export const getActiveNonAutomatedTrackings = async (
  batchSize: number = 50,
  minMinutesSinceUpdate: number = 10
) => {
  const pool = await poolPromise;

  try {
    const query = `
      SELECT TOP (@batchSize)
        id,
        tracking_number,
        tracking_carrier_code,
        tracking_status,
        updated_at
      FROM Tracking
      WHERE 
        tracking_is_automated = 0
        AND tracking_status NOT IN ('DELIVERED', 'Delivered', 'Failed', 'Returned', 'Cancelled')
        AND tracking_carrier_code IS NOT NULL
        AND tracking_carrier_code IN ('1', '2', '3', '4', '5')
        AND DATEDIFF(MINUTE, updated_at, GETDATE()) >= @minMinutes
      ORDER BY updated_at ASC;
    `;

    const result = await pool
      .request()
      .input("batchSize", sql.Int, batchSize)
      .input("minMinutes", sql.Int, minMinutesSinceUpdate)
      .query(query);

    return result.recordset || [];
  } catch (error: any) {
    console.error("Error fetching active non-automated trackings:", error);
    throw new Error(
      "Failed to fetch active non-automated trackings: " + error.message
    );
  }
};

export const updateManualTrackingFromCron = async (
  manualTrackingId: number,
  newStatus: string,
  newPayload: object
) => {
  const pool = await poolPromise;

  try {
    const query = `
      UPDATE Manual_Trackings
      SET 
        manual_tracking_status = @newStatus,
        manual_tracking_payload = @newPayload,
        updated_at = GETDATE()
      WHERE manual_tracking_id = @manualTrackingId;
    `;

    const result = await pool
      .request()
      .input("manualTrackingId", sql.Int, manualTrackingId)
      .input("newStatus", sql.NVarChar(100), newStatus)
      .input("newPayload", sql.NVarChar(sql.MAX), JSON.stringify(newPayload))
      .query(query);

    return result.rowsAffected[0] > 0;
  } catch (error: any) {
    console.error("Error updating manual tracking from cron:", error);
    throw new Error(
      "Failed to update manual tracking from cron: " + error.message
    );
  }
};

// Functions for Order List Integration
export const getManualTrackingsForOrderList = async (userId: number) => {
  const pool = await poolPromise;

  try {
    const query = `
      SELECT 
        mt.manual_tracking_id,
        mt.manual_tracking_user_id,
        mt.manual_tracking_name,
        mt.manual_tracking_number,
        mt.manual_tracking_status,
        mt.manual_tracking_payload,
        mt.manual_tracking_courier,
        mt.created_at,
        mt.updated_at,
        c.courier_id,
        c.courier_name,
        c.courier_url,
        c.courier_image_url
      FROM Manual_Trackings mt
      INNER JOIN Couriers c ON mt.manual_tracking_courier = c.courier_id
      WHERE mt.manual_tracking_user_id = @userId
      ORDER BY mt.created_at DESC;
    `;

    const result = await pool
      .request()
      .input("userId", sql.Int, userId)
      .query(query);

    return result.recordset || [];
  } catch (error: any) {
    console.error("Error fetching manual trackings for order list:", error);
    throw new Error("Failed to fetch manual trackings: " + error.message);
  }
};

export const getActiveManualTrackingsForOrderList = async (userId: number) => {
  const pool = await poolPromise;

  try {
    const query = `
      SELECT 
        mt.manual_tracking_id,
        mt.manual_tracking_user_id,
        mt.manual_tracking_name,
        mt.manual_tracking_number,
        mt.manual_tracking_status,
        mt.manual_tracking_payload,
        mt.manual_tracking_courier,
        mt.created_at,
        mt.updated_at,
        c.courier_id,
        c.courier_name,
        c.courier_url,
        c.courier_image_url
      FROM Manual_Trackings mt
      INNER JOIN Couriers c ON mt.manual_tracking_courier = c.courier_id
      WHERE 
        mt.manual_tracking_user_id = @userId
        AND mt.manual_tracking_status NOT IN ('Delivered', 'Failed', 'Returned', 'Cancelled')
      ORDER BY mt.created_at DESC;
    `;

    const result = await pool
      .request()
      .input("userId", sql.Int, userId)
      .query(query);

    return result.recordset || [];
  } catch (error: any) {
    console.error(
      "Error fetching active manual trackings for order list:",
      error
    );
    throw new Error(
      "Failed to fetch active manual trackings: " + error.message
    );
  }
};
