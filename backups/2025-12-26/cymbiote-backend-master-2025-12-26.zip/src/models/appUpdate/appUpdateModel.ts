import { poolPromise } from "../../config/db";
import { sendErrorEmail } from "../../services/emailService";

export const getAppUpdateConfig = async (): Promise<any> => {
  try {
    const pool = await poolPromise;
    const query = `
      SELECT TOP 1
        id,
        update_required,
        internal_android_dev_version,
        internal_android_dev_url,
        internal_android_stage_version,
        internal_android_stage_url,
        internal_android_prod_version,
        internal_android_prod_url,
        internal_ios_dev_version,
        internal_ios_dev_url,
        internal_ios_stage_version,
        internal_ios_stage_url,
        internal_ios_prod_version,
        internal_ios_prod_url,
        android_prod_version,
        android_prod_url,
        ios_prod_version,
        ios_prod_url,
        created_at,
        updated_at
      FROM App_Update_Config
      ORDER BY id DESC
    `;
    const result = await pool.request().query(query);
    return result.recordset[0] || null;
  } catch (error: any) {
    sendErrorEmail("Error fetching app update config:", error);
    console.error("Error fetching app update config:", error);
    throw new Error("Failed to fetch app update config.");
  }
};

export const updateAppUpdateConfig = async (
  id: number,
  updateData: {
    update_required?: boolean;
    internal_android_dev_version?: string;
    internal_android_dev_url?: string;
    internal_android_stage_version?: string;
    internal_android_stage_url?: string;
    internal_android_prod_version?: string;
    internal_android_prod_url?: string;
    internal_ios_dev_version?: string;
    internal_ios_dev_url?: string;
    internal_ios_stage_version?: string;
    internal_ios_stage_url?: string;
    internal_ios_prod_version?: string;
    internal_ios_prod_url?: string;
    android_prod_version?: string;
    android_prod_url?: string;
    ios_prod_version?: string;
    ios_prod_url?: string;
  }
): Promise<any> => {
  try {
    const pool = await poolPromise;

    const updateFields: string[] = [];
    const request = pool.request();

    if (updateData.update_required !== undefined) {
      updateFields.push("update_required = @update_required");
      request.input("update_required", updateData.update_required);
    }
    if (updateData.internal_android_dev_version !== undefined) {
      updateFields.push("internal_android_dev_version = @internal_android_dev_version");
      request.input("internal_android_dev_version", updateData.internal_android_dev_version);
    }
    if (updateData.internal_android_dev_url !== undefined) {
      updateFields.push("internal_android_dev_url = @internal_android_dev_url");
      request.input("internal_android_dev_url", updateData.internal_android_dev_url);
    }
    if (updateData.internal_android_stage_version !== undefined) {
      updateFields.push("internal_android_stage_version = @internal_android_stage_version");
      request.input("internal_android_stage_version", updateData.internal_android_stage_version);
    }
    if (updateData.internal_android_stage_url !== undefined) {
      updateFields.push("internal_android_stage_url = @internal_android_stage_url");
      request.input("internal_android_stage_url", updateData.internal_android_stage_url);
    }
    if (updateData.internal_android_prod_version !== undefined) {
      updateFields.push("internal_android_prod_version = @internal_android_prod_version");
      request.input("internal_android_prod_version", updateData.internal_android_prod_version);
    }
    if (updateData.internal_android_prod_url !== undefined) {
      updateFields.push("internal_android_prod_url = @internal_android_prod_url");
      request.input("internal_android_prod_url", updateData.internal_android_prod_url);
    }
    if (updateData.internal_ios_dev_version !== undefined) {
      updateFields.push("internal_ios_dev_version = @internal_ios_dev_version");
      request.input("internal_ios_dev_version", updateData.internal_ios_dev_version);
    }
    if (updateData.internal_ios_dev_url !== undefined) {
      updateFields.push("internal_ios_dev_url = @internal_ios_dev_url");
      request.input("internal_ios_dev_url", updateData.internal_ios_dev_url);
    }
    if (updateData.internal_ios_stage_version !== undefined) {
      updateFields.push("internal_ios_stage_version = @internal_ios_stage_version");
      request.input("internal_ios_stage_version", updateData.internal_ios_stage_version);
    }
    if (updateData.internal_ios_stage_url !== undefined) {
      updateFields.push("internal_ios_stage_url = @internal_ios_stage_url");
      request.input("internal_ios_stage_url", updateData.internal_ios_stage_url);
    }
    if (updateData.internal_ios_prod_version !== undefined) {
      updateFields.push("internal_ios_prod_version = @internal_ios_prod_version");
      request.input("internal_ios_prod_version", updateData.internal_ios_prod_version);
    }
    if (updateData.internal_ios_prod_url !== undefined) {
      updateFields.push("internal_ios_prod_url = @internal_ios_prod_url");
      request.input("internal_ios_prod_url", updateData.internal_ios_prod_url);
    }
    if (updateData.android_prod_version !== undefined) {
      updateFields.push("android_prod_version = @android_prod_version");
      request.input("android_prod_version", updateData.android_prod_version);
    }
    if (updateData.android_prod_url !== undefined) {
      updateFields.push("android_prod_url = @android_prod_url");
      request.input("android_prod_url", updateData.android_prod_url);
    }
    if (updateData.ios_prod_version !== undefined) {
      updateFields.push("ios_prod_version = @ios_prod_version");
      request.input("ios_prod_version", updateData.ios_prod_version);
    }
    if (updateData.ios_prod_url !== undefined) {
      updateFields.push("ios_prod_url = @ios_prod_url");
      request.input("ios_prod_url", updateData.ios_prod_url);
    }

    if (updateFields.length === 0) {
      throw new Error("No fields to update");
    }

    updateFields.push("updated_at = SYSUTCDATETIME()");

    const query = `
      UPDATE App_Update_Config
      SET ${updateFields.join(", ")}
      WHERE id = @id;

      SELECT
        id,
        update_required,
        internal_android_dev_version,
        internal_android_dev_url,
        internal_android_stage_version,
        internal_android_stage_url,
        internal_android_prod_version,
        internal_android_prod_url,
        internal_ios_dev_version,
        internal_ios_dev_url,
        internal_ios_stage_version,
        internal_ios_stage_url,
        internal_ios_prod_version,
        internal_ios_prod_url,
        android_prod_version,
        android_prod_url,
        ios_prod_version,
        ios_prod_url,
        created_at,
        updated_at
      FROM App_Update_Config
      WHERE id = @id
    `;

    request.input("id", id);
    const result = await request.query(query);

    return result.recordset[0] || null;
  } catch (error: any) {
    sendErrorEmail("Error updating app update config:", error);
    console.error("Error updating app update config:", error);
    throw new Error("Failed to update app update config.");
  }
};