import { poolPromise } from "../../config/db";
import { sendErrorEmail } from "../../services/emailService";

export const shopCategoryList = async () => {
  const pool = await poolPromise;
  const query = `
      SELECT *
      FROM Store_Categories
      ORDER BY category_id DESC;
    `;
  const result = await pool.request().query(query);
  return result.recordset;
};

export const shopSubCategoryList = async (store_category_id: number) => {
  const pool = await poolPromise;
  const query = `
      SELECT *
      FROM Store_Sub_Category
      WHERE store_category_id = @store_category_id
      ORDER BY store_sub_category_id DESC;
    `;
  const result = await pool
    .request()
    .input("store_category_id", store_category_id)
    .query(query);
  return result.recordset;
};

export const insertUserIntrest = async (user_intrest: any) => {
  const pool = await poolPromise;

  console.log("user_intrest", user_intrest);

  const insertQuery = `
    INSERT INTO User_Intrest (user_intrest_user_id, user_intrest_category_id)
    VALUES (@user_intrest_user_id, @user_intrest_category_id);
  `;

  const updateQuery = `
    UPDATE User_Intrest
    SET updated_at = GETDATE()
    WHERE user_intrest_user_id = @user_intrest_user_id
    AND user_intrest_category_id = @user_intrest_category_id;
  `;

  const checkIfExistsQuery = `
    SELECT COUNT(*) AS existingRecord
    FROM User_Intrest
    WHERE user_intrest_user_id = @user_intrest_user_id
    AND user_intrest_category_id = @user_intrest_category_id;
  `;

  try {
    // Use Promise.all to handle multiple records in parallel
    const promises = user_intrest.map(async (item: any) => {
      const { user_intrest_user_id, user_intrest_category_id } = item;

      if (!user_intrest_user_id || !user_intrest_category_id) {
        throw new Error(
          "user_intrest_user_id and user_intrest_category_id are required."
        );
      }

      // Check if the record already exists
      const checkResult = await pool
        .request()
        .input("user_intrest_user_id", user_intrest_user_id)
        .input("user_intrest_category_id", user_intrest_category_id)
        .query(checkIfExistsQuery);

      console.log("Check result:", checkResult.recordset[0].existingRecord);

      if (checkResult.recordset[0].existingRecord === 0) {
        // If the record does not exist, insert the new interest and update the updated_at field
        await pool
          .request()
          .input("user_intrest_user_id", user_intrest_user_id)
          .input("user_intrest_category_id", user_intrest_category_id)
          .query(insertQuery);
      } else {
        // If the record exists, update the updated_at field
        await pool
          .request()
          .input("user_intrest_user_id", user_intrest_user_id)
          .input("user_intrest_category_id", user_intrest_category_id)
          .query(updateQuery);
      }
    });

    // Run all promises in parallel
    await Promise.all(promises);

    return true; // Return true if all insertions or updates are successful
  } catch (error: any) {
    sendErrorEmail("Error inserting or updating user interest:", error);

    console.error("Error inserting or updating user interest:", error.message);
    return false; // Return false if any error occurs
  }
};

export const getUserIntrest = async (user_id: number) => {
  const pool = await poolPromise;
  const query = `
      SELECT *
      FROM User_Intrest
      WHERE user_intrest_user_id = @user_intrest_user_id
      ORDER BY created_at DESC;
    `;
  const result = await pool
    .request()
    .input("user_intrest_user_id", user_id)
    .query(query);
  return result.recordset;
};
