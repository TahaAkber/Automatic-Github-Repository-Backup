// middlewares/verifyShopifyWebhook.ts
import crypto from "crypto";
import type { Request, Response, NextFunction } from "express";

const SHOPIFY_WEBHOOK_SECRET = process.env.SHOPIFY_WEBHOOK_SECRET!;

export function verifyShopifyWebhook(
  req: Request,
  res: Response,
  next: NextFunction
) {
  try {
    const hmacHeader = req.get("X-Shopify-Hmac-Sha256") || "";
    const raw = (req as any).rawBody as Buffer;
    console.log("Raw", raw);
    const digest = crypto
      .createHmac("sha256", SHOPIFY_WEBHOOK_SECRET)
      .update(raw)
      .digest("base64");

    console.log("Digest", digest);

    const ok =
      hmacHeader &&
      digest.length === hmacHeader.length &&
      crypto.timingSafeEqual(Buffer.from(digest), Buffer.from(hmacHeader));

    if (!ok) return res.status(401).send("Invalid HMAC");
    next();
  } catch {
    return res.status(401).send("Invalid HMAC");
  }
}
