import axios from "axios";
import dotenv from "dotenv";
import { sendErrorEmail } from "../../services/emailService";

dotenv.config();

const SHOPIFY_CREDIT_API_KEY = process.env.SHOPIFY_CREDIT_API_KEY;
const SHOPIFY_PARTNER_ORGANIZATION_ID =
  process.env.SHOPIFY_PARTNER_ORGANIZATION_ID;

export const createCreditsOnMerchant = async (
  appId: string,
  storeId: string,
  points: number,
  description: string
) => {
  try {
    const creditQuery = `
        mutation appCreditCreate($amount: MoneyInput!, $appId: ID!, $description: String!, $shopId: ID!, $test: Boolean) {
            appCreditCreate(amount: $amount, appId: $appId, description: $description, shopId: $shopId, test: $test) {
                appCredit {
                    id
                    name
                    amount {
                        amount
                        currencyCode
                        __typename
                    }
                    __typename
                }
                userErrors {
                  field
                  message
                }
            }
        }
  `;

    const input = {
      amount: {
        amount: points,
        currencyCode: "USD",
      },
      appId: `gid://partners/App/${appId}`,
      description,
      shopId: `gid://partners/Shop/${storeId}`,
      test: true,
    };

    console.log("credit inputs", input);

    const { data: responseCreditCreate } = await axios.post(
      `https://partners.shopify.com/${SHOPIFY_PARTNER_ORGANIZATION_ID}/api/2025-01/graphql.json`,
      {
        query: creditQuery,
        variables: input,
      },
      {
        headers: {
          "X-Shopify-Access-Token": SHOPIFY_CREDIT_API_KEY,
          "Content-Type": "application/json",
        },
      }
    );

    if (responseCreditCreate.data.appCreditCreate.userErrors.length > 0) {
      console.error(
        "response error",
        responseCreditCreate.data.appCreditCreate.userErrors
      );
      throw new Error(
        "Error creating credits on merchant. " +
          responseCreditCreate.data.appCreditCreate.userErrors[0].message
      );
    }

    console.log(
      "responseCreditCreate",
      responseCreditCreate.data.appCreditCreate.appCredit
    );

    return responseCreditCreate.data.appCreditCreate.appCredit;
  } catch (error: any) {
    sendErrorEmail("Error creating credits on merchant. ",error);

    console.log("error new", error);
    throw new Error("Error creating credits on merchant. " + error.message);
  }
};
