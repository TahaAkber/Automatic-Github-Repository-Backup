import axios from "axios";
import dotenv from "dotenv";
import { Shop } from "../../types/Shop";
import { sendErrorEmail } from "../../services/emailService";

dotenv.config();

const API_VERSION = process.env.STOREFRONT_API_VERSION;

export const createCartMutation = async (
  storefrontAccessToken: string,
  shopDomain: string,
  input: any
) => {
  const query = `
    mutation cartCreate($input: CartInput) {
      cartCreate(input: $input) {
        cart {
          id
          checkoutUrl
          lines(first: 10) {
            edges {
              node {
                merchandise {
                  ... on ProductVariant {
                    id
                  }
                }
              }
            }
          }
        }
        userErrors {
          field
          message
        }
      }
    }
  `;

  try {
    const response = await axios.post(
      `https://${shopDomain}/api/${API_VERSION}/graphql.json`,
      { query, variables: { input } },
      {
        headers: {
          "X-Shopify-Storefront-Access-Token": storefrontAccessToken,
          "Content-Type": "application/json",
        },
      }
    );

    const storefrontCartCreateResponse = response.data;

    console.log("storefrontCartCreateResponse", storefrontCartCreateResponse);

    // Handle userErrors from Shopify response
    if (storefrontCartCreateResponse.data?.cartCreate?.userErrors?.length > 0) {
      console.error(
        "Cart creation error",
        storefrontCartCreateResponse.data.cartCreate.userErrors
      );

      return {
        success: false,
        message: "Error creating cart",
        errors: storefrontCartCreateResponse.data.cartCreate.userErrors,
      };
    }

    return storefrontCartCreateResponse.data.cartCreate.cart;
  } catch (error: any) {
    console.error("Axios error response:", error.response?.data || error);
    sendErrorEmail("Error creating cart", error);

    return {
      success: false,
      message: "Error creating cart",
      errorDetails: error.response?.data || error.message,
    };
  }
};

export const attachDeliveryAddressesMutation = async (
  storefrontAccessToken: string,
  shopDomain: string,
  { cartId, addresses }: any
) => {
  const mutation = `
    mutation cartDeliveryAddressesAdd($addresses: [CartSelectableAddressInput!]!, $cartId: ID!) {
      cartDeliveryAddressesAdd(addresses: $addresses, cartId: $cartId) {
        cart {
          checkoutUrl
          id
        }
        userErrors {
          field
          message
        }
        warnings {
          code
          message
          target
        }
      }
    }
  `;

  const variables = {
    cartId,
    addresses,
  };

  const headers = {
    "X-Shopify-Storefront-Access-Token": storefrontAccessToken,
    "Content-Type": "application/json",
  };

  try {
    const response = await axios.post(
      `https://${shopDomain}/api/${API_VERSION}/graphql.json`,
      { query: mutation, variables },
      {
        headers,
      }
    );

    return response.data;
  } catch (error: any) {
    sendErrorEmail("Error attaching delivery addresses:", error);

    console.error("Error attaching delivery addresses:", error.message);
    throw new Error("Error attaching delivery addresses");
  }
};
