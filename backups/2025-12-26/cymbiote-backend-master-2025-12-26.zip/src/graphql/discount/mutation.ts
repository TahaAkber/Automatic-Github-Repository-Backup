import axios from "axios";
import dotenv from "dotenv";
import { CreateDiscountCodeReturn } from "../../types/discounts/CreateDiscountCodeReturn";
import { sendErrorEmail } from "../../services/emailService";

dotenv.config();

const API_VERSION = process.env.API_VERSION;
const APP_NAME = process.env.APP_NAME;

export const createCercleOnlyDiscount = async (
  amountToOff: number,
  productVariantId: string,
  previousDiscountId: number,
  accessToken: string,
  shopDomain: string
): Promise<CreateDiscountCodeReturn | null> => {
  try {
    const query = `
    mutation CreateDiscountCode($basicCodeDiscount: DiscountCodeBasicInput!) {
      discountCodeBasicCreate(basicCodeDiscount: $basicCodeDiscount) {
        codeDiscountNode {
          id
          codeDiscount {
            ... on DiscountCodeBasic {
              title
              startsAt
              endsAt
            }
          }
        }
        userErrors {
          field
          message
        }
      }
    }
    `;
    const DISCOUNT_CODE = APP_NAME + "ONLYDISC" + previousDiscountId;
    const currentTime = new Date().toISOString();
    const tenMinAhead = new Date(Date.now() + 10 * 60 * 1000).toISOString();
    const basicCodeDiscount = {
      basicCodeDiscount: {
        title: "Merchant Only Discount",
        code: DISCOUNT_CODE,
        startsAt: currentTime,
        endsAt: tenMinAhead,
        customerSelection: {
          all: true,
        },
        customerGets: {
          value: {
            discountAmount: {
              amount: amountToOff,
              appliesOnEachItem: true,
            },
          },
          items: {
            products: {
              productVariantsToAdd: [`${productVariantId}`],
            },
          },
        },
        usageLimit: 1,
        appliesOncePerCustomer: true,
        combinesWith: {
          productDiscounts: true,
          orderDiscounts: true,
          shippingDiscounts: true,
        },
      },
    };

    const API_URL = `https://${shopDomain}/admin/api/${API_VERSION}/graphql.json`;
    const response = await axios.post(
      API_URL,
      {
        query: query,
        variables: basicCodeDiscount,
      },
      {
        headers: {
          "X-Shopify-Access-Token": accessToken,
          "Content-Type": "application/json",
        },
      }
    );

    const discountCodeBasicCreate = response.data.data.discountCodeBasicCreate;
    if (discountCodeBasicCreate.userErrors.length > 0) {
      console.error(
        "Error creating discount code:",
        discountCodeBasicCreate.userErrors
      );
      return null;
    }

    const discountNode = discountCodeBasicCreate.codeDiscountNode;

    return {
      ...discountNode,
      code: DISCOUNT_CODE,
    };
  } catch (error: any) {
    sendErrorEmail("Discount was not created on shopify ",error);

    throw new Error("Discount was not created on shopify " + error.message);
  }
};
