import axios from "axios";
import { Shop } from "../../types/Shop";
import { DiscountNode } from "../../types/discounts/DiscountNode";
import { sendErrorEmail } from "../../services/emailService";

export const getDiscounts = async (
  shop: string,
  session: Shop[]
): Promise<DiscountNode[]> => {
  const accessToken = session[0].shop_access_token;

  const graphqlUrl = `https://${shop}/admin/api/2024-10/graphql.json`;

  const query = `
      {
        codeDiscountNodes(first: 10) {
          nodes {
            id
            codeDiscount {
              ... on DiscountCodeBasic {
                title
                summary
              }
              ... on DiscountCodeBxgy {
                title
                codesCount {
                  count
                }
              }
            }
          }
        }
      }
    `;

  try {
    const response = await axios.post(
      graphqlUrl,
      {
        query,
      },
      {
        headers: {
          "X-Shopify-Access-Token": accessToken,
          "Content-Type": "application/json",
        },
      }
    );

    // The actual structure of the GraphQL response is data -> codeDiscountNodes -> nodes
    const discounts = response.data.data.codeDiscountNodes.nodes;

    console.log("Merchants Discounts", discounts);
    return discounts;
  } catch (error: any) {
    sendErrorEmail("Error fetching discounts:", error);

    console.error("Error fetching discounts:", error);
    return [];
  }
};
