import axios from "axios";
import dotenv from "dotenv";
import { sendErrorEmail } from "../../services/emailService";

dotenv.config();

const API_VERSION = process.env.API_VERSION;

export const createDraftOrderMutation = `
  mutation draftOrderCreate($input: DraftOrderInput!) {
    draftOrderCreate(input: $input) {
      draftOrder {
        id
        invoiceUrl
      }
      userErrors {
        field
        message
      }
    }
  }
`;

export const cancelOrder = async (
  shopDomain: string,
  accessToken: string,
  shopifyOrderId: string,
  reason: string,
  staffNote: string,
  shopId?: string
): Promise<any> => {
  const query = `
    mutation orderCancel {
      orderCancel(
        notifyCustomer: true, 
        orderId: "gid://shopify/Order/${shopifyOrderId}",
        reason: ${reason}, 
        refund: true, 
        restock: true, 
        staffNote: "${staffNote}"
      ) {
        job {
          id 
        }
        orderCancelUserErrors {
          message
        }
        userErrors {
          field
          message
        }
      }
    }
  `;

  try {
    const apiUrl = `https://${shopDomain}/admin/api/${API_VERSION}/graphql.json`;
    // console.log("apiUrl", apiUrl, shopDomain, accessToken);
    const response = await axios.post(
      apiUrl,
      { query },
      {
        headers: {
          "X-Shopify-Access-Token": accessToken,
          "Content-Type": "application/json",
        },
      }
    );

    const orderCancelData = response.data.data.orderCancel;

    const errors = [
      ...(orderCancelData.orderCancelUserErrors || []).map(
        (e: any) => e.message
      ),
      ...(orderCancelData.userErrors || []).map((e: any) => e.message),
    ];

    const uniqueErrors = [...new Set(errors)];

    if (uniqueErrors.length > 0) {
      return {
        status: 400,
        message: `${uniqueErrors.join(", ")}`,
      };
    } else {
      return {
        status: 200,
        message: `Order Cancelled Successfully`,
      };
    }
  } catch (error: any) {
    sendErrorEmail(`Error canceling Shopify order:`, error);

    console.error(
      `Error canceling Shopify order:`,
      error.response?.data || error.message
    );
    return {
      status: 400,
      message: `API Request Failed: ${
        error.response?.data?.errors?.[0]?.message || error.message
      }`,
    };
  }
};
