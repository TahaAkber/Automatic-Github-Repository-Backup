import axios from "axios";
import { getShop } from "../../models/shops/shopModel";
import dotenv from "dotenv";
import { updateCancellationByOrderShopifyId } from "../../models/orders/dbOrders";
import { sendErrorEmail } from "../../services/emailService";

dotenv.config();

const API_VERSION = process.env.API_VERSION;

export const fetchShopifyOrderStatus = async (
  shopifyOrderId: string,
  shopDomain: string,
  accessToken: string
): Promise<any> => {
  const query = `
    {
      order(id: "gid://shopify/Order/${shopifyOrderId}") {
        id
        displayFulfillmentStatus
        displayFinancialStatus
        totalPriceSet {
          shopMoney {
            amount
            currencyCode
          }
        }
        transactions{
          amountSet{
            shopMoney{
              amount
              currencyCode
            }
          }
        }
      }
    }`;

  try {
    const apiUrl = `https://${shopDomain}/admin/api/${API_VERSION}/graphql.json`;
    const response = await axios.post(
      apiUrl,
      {
        query,
      },
      {
        headers: {
          "X-Shopify-Access-Token": accessToken,
          "Content-Type": "application/json",
        },
      }
    );
    return response.data.data.order;
  } catch (error: any) {
    sendErrorEmail(`Error fetching Shopify order status`, error);

    console.error(`Error fetching Shopify order status: ${error}`);
    throw new Error(
      `Failed to fetch order status for order ID: ${shopifyOrderId}`
    );
  }
};

export const getStaffNote = async (
  shopDomain: string,
  accessToken: string,
  order_shopify_id: string
): Promise<any> => {
  const query = `
  query GetOrderCancellationStaffNote {
  order(id: "gid://shopify/Order/${order_shopify_id}") {
    id
    cancellation {
      staffNote
    }
  }
}
  `;
  try {
    const apiUrl = `https://${shopDomain}/admin/api/${API_VERSION}/graphql.json`;
    const response = await axios.post(
      apiUrl,
      { query },
      {
        headers: {
          "X-Shopify-Access-Token": accessToken, // ✅ Required for Shopify Admin API
          "Content-Type": "application/json",
        },
      }
    );
    return response.data.data.order.cancellation.staffNote;
  } catch (error: any) {
    sendErrorEmail("Error fetching Staff Notes:", error);

    console.error(
      "Error fetching Staff Notes:",
      error.response?.data || error.message
    );
    throw new Error("Failed to fetch order Staff Notes.");
  }
};

export const fetchOrderCancellationReasons = async (
  shopDomain: string,
  accessToken: string
): Promise<any> => {
  const query = `
    query {
      __type(name: "OrderCancelReason") {
        enumValues {
          name
          description
        }
      }
    }
  `;

  try {
    const apiUrl = `https://${shopDomain}/admin/api/${API_VERSION}/graphql.json`;
    const response = await axios.post(
      apiUrl,
      { query },
      {
        headers: {
          "X-Shopify-Access-Token": accessToken, // ✅ Required for Shopify Admin API
          "Content-Type": "application/json",
        },
      }
    );

    return response.data.data.__type.enumValues;
  } catch (error: any) {
    sendErrorEmail("Error fetching cancellation reasons:", error);

    console.error(
      "Error fetching cancellation reasons:",
      error.response?.data || error.message
    );
    throw new Error("Failed to fetch order cancellation reasons.");
  }
};

export const fetchShopifyOrderSource = async (
  shopifyOrderId: any,
  shopDomain: string,
  accessToken: string
): Promise<any> => {
  const query = `
    query GetOrderSource($orderId: ID!) {
      order(id: $orderId) {
        id
        name
        app {
          id
          name
        }
        displayFinancialStatus
      }
    }`;

  try {
    const apiUrl = `https://${shopDomain}/admin/api/${API_VERSION}/graphql.json`;
    const response = await axios.post(
      apiUrl,
      {
        query,
        variables: { orderId: `gid://shopify/Order/${shopifyOrderId}` },
      },
      {
        headers: {
          "X-Shopify-Access-Token": accessToken,
          "Content-Type": "application/json",
        },
      }
    );
    console.log("insider order queries", response.data.data);
    return response.data.data.order;
  } catch (error: any) {
    sendErrorEmail("Error fetching Shopify order source: ", error);

    console.error(`Error fetching Shopify order source: ${error}`);
    throw new Error(
      `Failed to fetch order source for order ID: ${shopifyOrderId}`
    );
  }
};
