import axios from "axios";
import dotenv from "dotenv";
import { sendErrorEmail } from "../../services/emailService";

dotenv.config();

const API_VERSION = process.env.API_VERSION;

export const deleteWebhookSubscription = async (
  webhookSubscriptionId: string,
  accessToken: string,
  shopDomain: string
) => {
  const query = `
    mutation webhookSubscriptionDelete($id: ID!) {
        webhookSubscriptionDelete(id: $id) {
            userErrors {
                field
                message
            }
            deletedWebhookSubscriptionId
        }
    }`;

  const variables = { id: webhookSubscriptionId };

  try {
    const { data } = await axios.post(
      `https://${shopDomain}/admin/api/${API_VERSION}/graphql.json`,
      { query, variables },
      {
        headers: {
          "X-Shopify-Access-Token": accessToken,
          "Content-Type": "application/json",
        },
      }
    );

    return data;
  } catch (error: any) {
    sendErrorEmail("Error deleting webhook subscription: ",error);

    throw new Error("Error deleting webhook subscription: " + error.message);
  }
};
