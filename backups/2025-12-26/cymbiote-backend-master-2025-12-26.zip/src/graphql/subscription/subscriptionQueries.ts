import axios from "axios";
import dotenv from "dotenv";
import { sendErrorEmail } from "../../services/emailService";

dotenv.config();

const API_VERSION = process.env.API_VERSION;

export const createUsageCharge = async (
  subscriptionLineItemId: string,
  description: string,
  amount: { amount: number; currencyCode: string },
  shopDomain: string,
  accessToken: string
) => {
  const query = `
    mutation appUsageRecordCreate($subscriptionLineItemId: ID!, $description: String!, $price: MoneyInput!) {
      appUsageRecordCreate(
        subscriptionLineItemId: $subscriptionLineItemId
        description: $description
        price: $price
      ) {
        appUsageRecord {
          id
          description
          price {
            amount
            currencyCode
          }
        }
        userErrors {
          field
          message
        }
      }
    }
  `;

  const variables = {
    subscriptionLineItemId,
    description,
    price: amount,
  };

  console.log("subscribing variables", variables);

  try {
    const response = await axios.post(
      `https://${shopDomain}/admin/api/${API_VERSION}/graphql.json`,
      {
        query,
        variables,
      },
      {
        headers: {
          "X-Shopify-Access-Token": accessToken,
          "Content-Type": "application/json",
        },
      }
    );

    const { data } = response;
    if (data.errors) {
      console.error("Error creating usage record:", data.errors);
    } else {
      if (data.data.appUsageRecordCreate.userErrors.length > 0) {
        console.error(
          "Error occured",
          data.data.appUsageRecordCreate.userErrors
        );
      }
      console.log("Usage record created successfully:", data.data);
    }

    return data;
  } catch (error: any) {
    sendErrorEmail("Error creating usage charge:", error.toString());

    console.error("Error creating usage charge:", error);
  }
};

export const checkShopActiveSubscription = async (
  accessToken: string,
  shopDomain: string
) => {
  const query = `query {
  currentAppInstallation {
    activeSubscriptions {
      id
      status
    }
  }
}
`;

  try {
    const response = await axios.post(
      `https://${shopDomain}/admin/api/${API_VERSION}/graphql.json`,
      {
        query,
      },
      {
        headers: {
          "X-Shopify-Access-Token": accessToken,
          "Content-Type": "application/json",
        },
      }
    );

    // console.log(
    //   "response",
    //   response.data.data.currentAppInstallation.activeSubscriptions[0]?.status
    // );
    return response.data.data.currentAppInstallation.activeSubscriptions[0]
      ?.status;
  } catch (error: any) {
    sendErrorEmail("Error creating usage charge:", error);

    console.error("Error creating usage charge:", error);
    throw new Error("Failed to get next billing date.");
  }
};

export const getNextSubscriptionBillingDate = async (
  accessToken: string,
  shopDomain: string
) => {
  const query = `
    query InstallApp_Information {
      currentAppInstallation {
        id
        activeSubscriptions{
          currentPeriodEnd
        }
      }
    }
  `;
  try {
    const response = await axios.post(
      `https://${shopDomain}/admin/api/${API_VERSION}/graphql.json`,
      {
        query,
      },
      {
        headers: {
          "X-Shopify-Access-Token": accessToken,
          "Content-Type": "application/json",
        },
      }
    );

    const { data: appInstalledData } = response;

    return appInstalledData?.data?.currentAppInstallation
      ?.activeSubscriptions[0]?.currentPeriodEnd;
  } catch (error: any) {
    sendErrorEmail("Error creating usage charge:", error);

    console.error("Error creating usage charge:", error);
    throw new Error("Failed to get next billing date.");
  }
};

export const getAllWebhookSubscriptions = async (
  accessToken: string,
  shopDomain: string
) => {
  const apiUrl = `https://${shopDomain}/admin/api/${API_VERSION}/graphql.json`;
  const query = `query allWebhookSubscriptions {
      webhookSubscriptions(first: 20) {
        edges {
          node {
            id
            topic
            endpoint {
              __typename
              ... on WebhookHttpEndpoint {
                callbackUrl
              }
              ... on WebhookEventBridgeEndpoint {
                arn
              }
              ... on WebhookPubSubEndpoint {
                pubSubProject
                pubSubTopic
              }
            }
          }
        }
      }
    }`;

  try {
    const webhookSubscriptionsResponse = await axios.post(
      apiUrl,
      {
        query: query,
      },
      {
        headers: {
          "X-Shopify-Access-Token": accessToken,
          "Content-Type": "application/json",
        },
      }
    );

    return webhookSubscriptionsResponse.data;
  } catch (error: any) {
    sendErrorEmail("Error fetching webhook subscriptions:", error);

    console.error("Error fetching webhook subscriptions:", error);
    throw new Error("Failed to fetch webhook subscriptions.");
  }
};
