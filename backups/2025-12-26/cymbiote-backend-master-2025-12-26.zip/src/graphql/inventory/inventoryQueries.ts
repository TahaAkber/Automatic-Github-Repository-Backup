import axios from "axios";
import { sendErrorEmail } from "../../services/emailService";

export const fetchInventoryInformation = async (
  inventory_item_id: string,
  shopDomain: string,
  accessToken: string
) => {
  const query = `
    query {
      inventoryItem(id: "gid://shopify/InventoryItem/${inventory_item_id}") {
        variant {
          id
        }
      }
    }
  `;

  const shopifyGraphQLEndpoint = `https://${shopDomain}/admin/api/2024-10/graphql.json`;

  try {
    const response = await axios.post(
      shopifyGraphQLEndpoint,
      {
        query,
      },
      {
        headers: {
          "X-Shopify-Access-Token": accessToken,
          "Content-Type": "application/json",
        },
      }
    );

    const productVariantId = response.data.data.inventoryItem.variant.id;
    return productVariantId;
  } catch (error: any) {
    sendErrorEmail("Error fetching product variant ID:", error);

    console.error("Error fetching product variant ID:", error);
    return null;
  }
};
