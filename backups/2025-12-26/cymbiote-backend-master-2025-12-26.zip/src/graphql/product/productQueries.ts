import axios from "axios";
import dotenv from "dotenv";
import { poolPromise } from "../../config/db";
import axiosRetry from "axios-retry";
import https from "https";
import { sendErrorEmail } from "../../services/emailService";

dotenv.config();

const API_VERSION = process.env.API_VERSION;
const APP_NAME = process.env.APP_NAME;

axiosRetry(axios, {
  retries: 3, // Retry 3 times
  retryDelay: axiosRetry.exponentialDelay, // Exponential backoff
  retryCondition: (error) => {
    // Retry only for network errors or 5xx responses
    return (
      axiosRetry.isNetworkOrIdempotentRequestError(error) ||
      error.code === "ETIMEDOUT"
    );
  },
});

export const fetchShopifyProductVariant = async (
  variantId: string,
  shopDomain: string,
  accessToken: string
): Promise<any> => {
  const query = `
    query {
      productVariant(id: "${variantId}") {
        id
        title
        selectedOptions {
          name
          value
        }
        media(first: 10) {
          nodes {
            preview {
              image {
                url
              }
            }
          }
        }
      }
    }
  `;

  try {
    const apiUrl = `https://${shopDomain}/admin/api/${process.env.API_VERSION}/graphql.json`;

    const response = await axios.post(
      apiUrl,
      { query },
      {
        headers: {
          "X-Shopify-Access-Token": accessToken,
          "Content-Type": "application/json",
        },
        timeout: 15000, // 15 seconds timeout
        httpsAgent: new https.Agent({ family: 4 }), // Force IPv4
      }
    );

    if (!response.data?.data?.productVariant) {
      throw new Error(`No product variant returned for ID: ${variantId}`);
    }

    return response.data.data.productVariant;
  } catch (error: any) {
    sendErrorEmail(
      `Error fetching Shopify product variant: ${error.message} | Variant ID: ${variantId} | Shop: ${shopDomain}`,
      error
    );

    console.error(
      `Error fetching Shopify product variant: ${error.message} | Variant ID: ${variantId} | Shop: ${shopDomain}`
    );
    throw new Error(`Failed to fetch product variant with ID: ${variantId}`);
  }
};

export const fetchShopifyCollectionProducts = async (
  collectionId: string,
  shopDomain: string,
  accessToken: string,
  perPage: number = 50,
  afterCursor: string | null = null // Start with no cursor
): Promise<any> => {
  const query = `
    query GetCollection {
      collection(id: "${collectionId}") {
        id
        title
        handle
        productsCount {
          count
        }
        products(first: ${perPage} ${
    afterCursor ? `after: "${afterCursor}"` : ""
  }) {
          pageInfo {
            hasNextPage
            endCursor
          }
          nodes {
            id
          }
        }
        updatedAt
      }
    }
  `;

  try {
    const apiUrl = `https://${shopDomain}/admin/api/${API_VERSION}/graphql.json`;
    const response = await axios.post(
      apiUrl,
      { query },
      {
        headers: {
          "X-Shopify-Access-Token": accessToken,
          "Content-Type": "application/json",
        },
      }
    );

    const data = response.data.data.collection.products;
    const collection = response.data.data.collection;

    const products = data.nodes;

    const pageInfo = data.pageInfo;
    const hasNextPage = pageInfo.hasNextPage;
    const endCursor = pageInfo.endCursor;

    return {
      productCount: collection.productsCount.count,
      products,
      hasNextPage,
      endCursor,
    };
  } catch (error: any) {
    sendErrorEmail(
      `Error fetching Shopify collection products: ${error.message}`,
      error
    );

    console.error(
      `Error fetching Shopify collection products: ${error.message}`
    );
    throw new Error(
      `Unable to fetch collection products with collection ID: ${collectionId}`
    );
  }
};

export const fetchProductMetafields = async (
  productId: number,
  shopDomain: string,
  accessToken: string
) => {
  const metafieldKey = `${APP_NAME?.toLowerCase()}_product_category`;
  try {
    const query = `
      query {
        product(id: "gid://shopify/Product/${productId}") {
          metafields(first: 10) {
            edges {
              node {
                id
                key
                namespace
                value
                type
                definition {
                  name
                  description
                }
              }
            }
          }
        }
      }
    `;

    const apiUrl = `https://${shopDomain}/admin/api/${API_VERSION}/graphql.json`;
    const response = await axios.post(
      apiUrl,
      { query },
      {
        headers: {
          "X-Shopify-Access-Token": accessToken,
          "Content-Type": "application/json",
        },
      }
    );

    // Return metafields data
    return response.data.data.product.metafields.edges.find((edge: any) => {
      // console.log(
      //   "response.edge",
      //   edge
      // );
      return edge.node.key === metafieldKey;
    })?.node;
  } catch (error: any) {
    sendErrorEmail(
      `Error fetching metafields for product ${productId}:`,
      error
    );

    console.error(`Error fetching metafields for product ${productId}:`, error);
    throw new Error(`Failed to fetch metafields for product ${productId}`);
  }
};

export const fetchVariantMetafields = async (
  variantId: number,
  shopDomain: string,
  accessToken: string
) => {
  const query = `
    query {
      productVariant(id: "gid://shopify/ProductVariant/${variantId}") {
        metafields(first: 10) {
          edges {
            node {
              id
              key
              namespace
              value
              type
            }
          }
        }
      }
    }
  `;

  const apiUrl = `https://${shopDomain}/admin/api/${API_VERSION}/graphql.json`;
  const response = await axios.post(
    apiUrl,
    { query },
    {
      headers: {
        "X-Shopify-Access-Token": accessToken,
        "Content-Type": "application/json",
      },
    }
  );

  // Return metafields for the variant
  return response.data.data.productVariant.metafields.edges.map(
    (edge: any) => edge.node
  );
};

export const fetchMetaObjectById = async (
  metaobjectId: string,
  shopDomain: string,
  accessToken: string
) => {
  try {
    const query = `
    {
      metaobject(id: "${metaobjectId}") {
        id
        displayName
      }
    }`;

    const apiUrl = `https://${shopDomain}/admin/api/${API_VERSION}/graphql.json`;
    const response = await axios.post(
      apiUrl,
      { query },
      {
        headers: {
          "X-Shopify-Access-Token": accessToken,
          "Content-Type": "application/json",
        },
      }
    );

    return response.data.data.metaobject;
  } catch (error: any) {
    sendErrorEmail("error in metaobject", error);

    console.log("error in metaobject", error.message);
    throw new Error("Failed to fetch metaobject with this ID: " + metaobjectId);
  }
};

export const getProductTaxonomyUsingName = async (
  name: string,
  shopDomain: string,
  accessToken: string,
  pageSize: number = 1
) => {
  console.log("searchTerm", name);
  try {
    const query = `
    {
      taxonomy {
        categories (first:${pageSize}, search:"${name}"){
          nodes{
            fullName
            id
            name
          }
        }
      }
    }`;

    const apiUrl = `https://${shopDomain}/admin/api/${API_VERSION}/graphql.json`;
    const response = await axios.post(
      apiUrl,
      { query },
      {
        headers: {
          "X-Shopify-Access-Token": accessToken,
          "Content-Type": "application/json",
        },
      }
    );

    console.log(
      "taxonomy response",
      response.data?.data.taxonomy.categories.nodes
    );

    return response.data?.data.taxonomy.categories.nodes[0];
  } catch (error: any) {
    sendErrorEmail("Taxonomy Error", error);

    console.log("Taxonomy Error", error.message);
    throw new Error("Failed to find product taxonomy with name " + name);
  }
};

// export const getProductTaxonomyForCategoryList = async (
//   shopDomain: string,
//   accessToken: string,
//   id?: string
// ) => {
//   console.log("shopDomain:", shopDomain);

//   const getProductCategory = `
//     SELECT product_custom_category_id FROM PRODUCTS
//   `;

//   const pool = await poolPromise;
//   const result = await pool.request().query(getProductCategory);
//   const dbcategories = result.recordset;

//   const apiUrl = `https://${shopDomain}/admin/api/${API_VERSION}/graphql.json`;

//   console.log(
//     "categories",
//     dbcategories.map((item) => item.product_custom_category_id)
//   );
//   const simplifiedGids = dbcategories
//     .map((item) => item.product_custom_category_id)
//     .filter(
//       (id) =>
//         typeof id === "string" && id.includes("gid://shopify/TaxonomyCategory/")
//     )
//     .map((id) => {
//       const raw = id.split("/").pop();
//       const prefix = raw?.split("-")[0];
//       return `gid://shopify/TaxonomyCategory/${prefix}`;
//     });

//   const uniqueCategoryGids = Array.from(new Set(simplifiedGids));

//   const query = `{
//     taxonomy {
//       categories(first: 100) {
//         nodes {
//           id
//           name
//           isLeaf
//           fullName
//           isRoot
//           level
//         }
//       }
//     }
//   }`;

//   try {
//     const response = await axios.post(
//       apiUrl,
//       { query },
//       {
//         headers: {
//           "X-Shopify-Access-Token": accessToken,
//           "Content-Type": "application/json",
//         },
//       }
//     );

//     const categories = response.data?.data?.taxonomy?.categories?.nodes || [];

//     let parentCategories = categories.filter((category: any) =>
//       uniqueCategoryGids.includes(category.id)
//     );

//     if (id) {
//       const shopifyChildrenQuery = `
//         query GetChildrenCategories($id: ID!) {
//           taxonomy {
//             categories(first: 250, childrenOf: $id) {
//               nodes {
//                 id
//                 name
//                 isLeaf
//                 fullName
//                 isRoot
//               }
//             }
//           }
//         }
//       `;

//       try {
//         const Response = await axios.post(
//           apiUrl,
//           {
//             query: shopifyChildrenQuery,
//             variables: { id },
//           },
//           {
//             headers: {
//               "X-Shopify-Access-Token": accessToken,
//               "Content-Type": "application/json",
//             },
//           }
//         );

//         parentCategories =
//           Response.data?.data?.taxonomy?.categories?.nodes || [];
//       } catch (error) {
//         console.error(`Failed to fetch Childrens for parent ID: ${id}`, error);
//       }
//     }

//     return parentCategories;
//   } catch (error: any) {
//     console.error("Taxonomy Error:", error.message);
//     throw new Error("Failed to find product taxonomy with name " + name);
//   }
// };

export const getProductTaxonomyForCategoryList = async (
  shopDomain: string,
  accessToken: string,
  id?: string
) => {
  console.log("shopDomain:", shopDomain);

  const pool = await poolPromise;
  const result = await pool.request().query(`
    SELECT product_custom_category_id FROM PRODUCTS
  `);

  const dbcategories = result.recordset;
  const apiUrl = `https://${shopDomain}/admin/api/${API_VERSION}/graphql.json`;

  const simplifiedGids = dbcategories
    .map((item) => item.product_custom_category_id)
    .filter(
      (gid) =>
        typeof gid === "string" &&
        gid.includes("gid://shopify/TaxonomyCategory/")
    )
    .map((gid) => {
      const raw = gid.split("/").pop(); // e.g., el-1-2-3
      const prefix = raw?.split("-")[0]; // e.g., el
      return `gid://shopify/TaxonomyCategory/${prefix}`;
    });

  const uniqueCategoryGids = Array.from(new Set(simplifiedGids));

  const baseQuery = `
    {
      taxonomy {
        categories(first: 100) {
          nodes {
            id
            name
            isLeaf
            fullName
            isRoot
            level
          }
        }
      }
    }
  `;

  try {
    const baseResponse = await axios.post(
      apiUrl,
      { query: baseQuery },
      {
        headers: {
          "X-Shopify-Access-Token": accessToken,
          "Content-Type": "application/json",
        },
      }
    );

    const categories =
      baseResponse.data?.data?.taxonomy?.categories?.nodes || [];

    let parentCategories = categories.filter((cat: any) =>
      uniqueCategoryGids.includes(cat.id)
    );

    // If an ID is provided, fetch children of that category
    if (id) {
      const childrenQuery = `
        query GetChildrenCategories($id: ID!) {
          taxonomy {
            categories(first: 250, childrenOf: $id) {
              nodes {
                id
                name
                isLeaf
                fullName
                isRoot
              }
            }
          }
        }
      `;

      try {
        const childResponse = await axios.post(
          apiUrl,
          {
            query: childrenQuery,
            variables: { id },
          },
          {
            headers: {
              "X-Shopify-Access-Token": accessToken,
              "Content-Type": "application/json",
            },
          }
        );
        const childNodes =
          childResponse.data?.data?.taxonomy?.categories?.nodes || [];

        parentCategories = childNodes.filter((child: any) => {
          return dbcategories.some((item) => {
            const dbId = item.product_custom_category_id;
            return (
              typeof dbId === "string" &&
              (dbId === child.id || dbId.startsWith(`${child.id}-`))
            );
          });
        });

        return parentCategories;
      } catch (childError) {
        console.error(
          `❌ Failed to fetch children for parent ID: ${id}`,
          childError
        );
      }
    }

    return parentCategories;
  } catch (error: any) {
    sendErrorEmail("❌ Taxonomy Error:", error);

    console.error("❌ Taxonomy Error:", error.message);
    throw new Error("Failed to find product taxonomy.");
  }
};

export const getProductDescriptiveHtmlByShopifyId = async (
  shopDomain: string,
  accessToken: string,
  product_shopify_id: string
) => {
  if (!shopDomain || !accessToken || !product_shopify_id) {
    throw new Error(
      "Missing required parameters: shopDomain, accessToken, or product_id"
    );
  }

  const apiUrl = `https://${shopDomain}/admin/api/${API_VERSION}/graphql.json`;
  const query = `
    query GetProduct($id: ID!) {
      product(id: $id) {
        id
        title
        description
        descriptionHtml
      }
    }
  `;

  try {
    const response = await axios.post(
      apiUrl,
      {
        query,
        variables: { id: product_shopify_id },
      },
      {
        headers: {
          "X-Shopify-Access-Token": accessToken,
          "Content-Type": "application/json",
        },
      }
    );

    return response.data?.data?.product?.descriptionHtml || "";
  } catch (error: any) {
    sendErrorEmail("Error fetching product description:", error);

    console.error("Error fetching product description:", error);
    throw error;
  }
};

export const fetchProductsWithShopifyId = async (
  shopDomain: string,
  accessToken: string,
  id: string
) => {
  try {
    const query = `
      query GetProductById($id: ID!) {
        node(id: $id) {
          ... on Product {
            id
            title
            description
            status
            productType
            totalInventory
            category {
              name
            }
            images(first: 5) {
              nodes {
                url
              }
            }
            variants(first: 10) {
              nodes {
                title
                price
                image {
                  url
                  id
                }
                id
                selectedOptions {
                  name
                  value
                }
              }
            }
            metafields(first: 3) {
              nodes {
                key
                value
              }
            }
          }
        }
      }
    `;

    const apiUrl = `https://${shopDomain}/admin/api/${API_VERSION}/graphql.json`;

    const response = await axios.post(
      apiUrl,
      {
        query,
        variables: { id },
      },
      {
        headers: {
          "X-Shopify-Access-Token": accessToken,
          "Content-Type": "application/json",
        },
      }
    );

    return response.data; // this includes `data` and possibly `errors` if present
  } catch (error: any) {
    sendErrorEmail("❌ Error while fetching product with Shopify ID:", error);

    console.error(
      "❌ Error while fetching product with Shopify ID:",
      error.message
    );
    return null;
  }
};

export const fetchProductMetafield = async (
  shopDomain: string,
  accessToken: string,
  productId: string
) => {
  try {
    const query = `
      query GetProductById($id: ID!) {
        node(id: $id) {
          ... on Product {
            id
            title
            description
            descriptionHtml
            metafields(first: 100) {
              edges {
                node {
                  id
                  key
                  namespace
                  value
                  type
                  definition {
                    name
                    description
                  }
                }
              }
            }
          }
        }
      }
    `;

    const apiUrl = `https://${shopDomain}/admin/api/${API_VERSION}/graphql.json`;

    const response = await axios.post(
      apiUrl,
      {
        query,
        variables: { id: productId },
      },
      {
        headers: {
          "X-Shopify-Access-Token": accessToken,
          "Content-Type": "application/json",
        },
      }
    );

    const product = response?.data?.data?.node;
    if (!product) return null;

    const metafields = product.metafields.edges.map((e: any) => e.node);

    const metaobjectGids: string[] = [];

    metafields.forEach((field: any) => {
      if (field.type.includes("metaobject_reference")) {
        try {
          const parsed = JSON.parse(field.value);
          if (Array.isArray(parsed)) {
            metaobjectGids.push(...parsed);
          } else if (typeof parsed === "string") {
            metaobjectGids.push(parsed);
          }
        } catch (err) {
          if (
            typeof field.value === "string" &&
            field.value.startsWith("gid://shopify/Metaobject/")
          ) {
            metaobjectGids.push(field.value);
          }
        }
      }
    });

    return {
      id: product.id,
      title: product.title,
      description: product.description,
      descriptionHtml: product.descriptionHtml,
      metafields,
      metaobjectGids: Array.from(new Set(metaobjectGids)),
    };
  } catch (error: any) {
    sendErrorEmail("❌ Error fetching product metafields:", error);

    console.error("❌ Error fetching product metafields:", error.message);
    throw new Error("Failed to fetch product metafields.");
  }
};

export const buildMetaobjectQuery = (gids: string[]) => {
  const queries = gids.map((gid, index) => {
    return `
      m${index}: metaobject(id: "${gid}") {
        id
        type
        handle
        fields {
          key
          value
          type
          definition {
            name
          }
        }
      }
    `;
  });

  return `
    query {
      ${queries.join("\n")}
    }
  `;
};

export const fetchMetaobjectDetails = async (
  shopDomain: string,
  accessToken: string,
  metaobjectGids: string[]
) => {
  if (!metaobjectGids.length) return [];

  const query = buildMetaobjectQuery(metaobjectGids);
  const apiUrl = `https://${shopDomain}/admin/api/${API_VERSION}/graphql.json`;

  const response = await axios.post(
    apiUrl,
    { query },
    {
      headers: {
        "X-Shopify-Access-Token": accessToken,
        "Content-Type": "application/json",
      },
    }
  );

  const metaobjectsRaw = response.data?.data || {};
  const metaobjects = Object.values(metaobjectsRaw).filter(Boolean);

  return metaobjects;
};

export const updateProductMetafieldsinDb = async (
  product_shopify_id: string,
  shop_id: string,
  resolved: any
) => {
  try {
    const pool = await poolPromise;
    const request = pool.request();

    request.input("product_metafields", JSON.stringify(resolved));
    request.input("product_shop_id", shop_id);
    request.input("product_shopify_id", product_shopify_id);

    const updatedData = await request.query(`
      UPDATE Products
      SET product_metafields = @product_metafields, updated_at = GETDATE()
      WHERE product_shop_id = @product_shop_id
      AND product_shopify_id = @product_shopify_id;
    `);
    console.log("✅ Successfully updated product metafields", updatedData);
  } catch (error: any) {
    sendErrorEmail("❌ Error updating product metafields:", error);

    console.error("❌ Error updating product metafields:", error);
    throw new Error("Failed to update product metafields.");
  }
};
