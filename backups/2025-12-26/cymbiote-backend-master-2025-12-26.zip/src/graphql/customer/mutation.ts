import axios from "axios";
import dotenv from "dotenv";

dotenv.config();

const API_VERSION = process.env.API_VERSION;

export const customerCreateMutation = async (
  firstName: string,
  lastName: string,
  userEmail: string,
  shopDomain: string,
  accessToken: string
) => {
  const createCustomerMutation = `
        mutation customerCreate($input: CustomerInput!) {
          customerCreate(input: $input) {
            customer {
              id
              email
            }
            userErrors {
              field
              message
            }
          }
        }
      `;

  const createCustomerResponse = await axios.post(
    `https://${shopDomain}/admin/api/${API_VERSION}/graphql.json`,
    {
      query: createCustomerMutation,
      variables: {
        input: {
          email: userEmail,
          firstName: firstName,
          lastName: lastName,
          emailMarketingConsent: {
            marketingState: "SUBSCRIBED",
            marketingOptInLevel: "CONFIRMED_OPT_IN",
          },
        },
      },
    },
    {
      headers: {
        "X-Shopify-Access-Token": accessToken,
        "Content-Type": "application/json",
      },
    }
  );

  const { data: newCustomerData } = createCustomerResponse;
  if (newCustomerData.data.customerCreate.userErrors.length > 0) {
    console.error(
      "Error creating customer:",
      newCustomerData.data.customerCreate.userErrors
    );
    return null;
  }

  return newCustomerData.data.customerCreate.customer;
};
