import axios from "axios";
import dotenv from "dotenv";
import { Shop } from "../../types/Shop";
import { getShop } from "../../models/shops/shopModel";
import { sendErrorEmail } from "../../services/emailService";

dotenv.config();

const API_VERSION = process.env.STOREFRONT_API_VERSION;

export const createStorefrontToken = async (session: Shop[]) => {
  const accessToken = session[0].shop_access_token;
  const shop = session[0].shop_domain;

  const query = `
      mutation storeFrontAccessTokenCreate($input: StorefrontAccessTokenInput!) {
        storefrontAccessTokenCreate(input: $input) {
          storefrontAccessToken {
            id
            accessToken
          }
          userErrors {
            field
            message
          }
        }
      }
    `;

  const variables = { input: { title: "Storefront Access Token" } };

  try {
    const { data: responseData } = await axios.post(
      `https://${shop}/admin/api/${API_VERSION}/graphql.json`,
      { query, variables },
      {
        headers: {
          "X-Shopify-Access-Token": accessToken,
          "Content-Type": "application/json",
        },
      }
    );

    console.log(
      "storefrontAccessToken Response",
      responseData.data.storefrontAccessTokenCreate.storefrontAccessToken
    );

    if (responseData?.data?.storefrontAccessTokenCreate?.userErrors.length) {
      throw new Error(
        "Error creating storefront token: " +
          responseData?.data?.storefrontAccessTokenCreate.userErrors[0]
      );
    }

    return responseData?.data?.storefrontAccessTokenCreate
      ?.storefrontAccessToken;
  } catch (error: any) {
    sendErrorEmail("Error creating storefront token: " ,error);

    throw new Error("Error creating storefront token: " + error.message);
  }
};

export const deleteStorefrontToken = async (
  shop: string,
  storefrontToken: string
) => {
  const session = await getShop(shop);
  const accessToken = session[0].shop_access_token;

  const query = `
    mutation storefrontAccessTokenDelete($input: StorefrontAccessTokenDeleteInput!) {
      storefrontAccessTokenDelete(input: $input) {
        deletedStorefrontAccessTokenId
        userErrors {
          field
          message
        }
      }
    }`;

  const variables = {
    input: { id: storefrontToken },
  };

  const { data: tokenDeleteResponse } = await axios.post(
    `https://${shop}/admin/api/${API_VERSION}/graphql.json`,
    { query, variables },
    {
      headers: {
        "X-Shopify-Access-Token": accessToken,
        "Content-Type": "application/json",
      },
    }
  );

  const { data } = tokenDeleteResponse;
  console.log("delete storefront token", data);
  if (data.storefrontAccessTokenDelete.userErrors.length) {
    throw new Error("Failed to delete storefront access token");
  }
};
