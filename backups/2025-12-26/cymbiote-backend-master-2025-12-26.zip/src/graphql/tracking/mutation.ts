import axios from "axios";
import dotenv from "dotenv";
import { sendErrorEmail } from "../../services/emailService";

dotenv.config();

const API_VERSION = process.env.API_VERSION;

export const updateMerchantsFulfillmentDetails = async (
  fulfillmentId: string,
  status: string = "outfordelivery",
  shopDomain: string,
  accessToken: string
) => {
  const query = `
    mutation fulfillmentEventCreate($fulfillmentEvent: FulfillmentEventInput!) {
      fulfillmentEventCreate(fulfillmentEvent: $fulfillmentEvent) {
        fulfillmentEvent {
          id
          status
          message
        }
        userErrors {
          field
          message
        }
      }
    }
  `;

  let fulfillStatus: string = "";
  let fulfillmentMessage: string = "";
  console.log("delivery status", status);
  switch (status?.toLowerCase()) {
    case "delivered":
      fulfillStatus = status.toUpperCase();
      fulfillmentMessage = "The package is successfully delivered!";
      break;
    case "inforeceived":
      fulfillStatus = "CONFIRMED";
      fulfillmentMessage = "The package information is received!";
      break;
    case "notfound":
      fulfillStatus = "FAILURE";
      fulfillmentMessage = "The package details were not found!";
      break;
    case "outfordelivery":
      fulfillStatus = "OUT_FOR_DELIVERY";
      fulfillmentMessage = "This package is now out for delivery!";
      break;
    case "intransit":
      fulfillStatus = "IN_TRANSIT";
      fulfillmentMessage = "This package is in-transit!";
      break;
    case "deliveryfailure":
      fulfillStatus = "FAILURE";
      fulfillmentMessage = "The package was not delivered!";
      break;
    default:
      fulfillStatus = "FAILURE";
      fulfillmentMessage = "The package was not delivered!";
      break;
  }

  // unused labels: DELAYED, LABEL_PRINTED, LABEL_PURCHASED, READY_FOR_PICKUP

  const variables = {
    fulfillmentEvent: {
      fulfillmentId: "gid://shopify/Fulfillment/" + fulfillmentId,
      message: fulfillmentMessage,
      status: fulfillStatus,
    },
  };

  try {
    const response = await axios.post(
      `https://${shopDomain}/admin/api/${API_VERSION}/graphql.json`,
      {
        query,
        variables,
      },
      {
        headers: {
          "X-Shopify-Access-Token": accessToken,
          "Content-Type": "application/json",
        },
      }
    );

    // console.log("fulfillment response", response);
    const { data } = response;
    if (data.errors) {
      console.error("Error updating fulfillment record:", data.errors);
    } else {
      if (data.data.appUsageRecordCreate?.userErrors.length > 0) {
        console.error(
          "Error occured",
          data.data.appUsageRecordCreate.userErrors
        );
      }
      console.log("Updated fulfillment successfully:", data.data);
    }

    return data;
  } catch (error: any) {
    sendErrorEmail("Error creating usage charge:", error);

    console.error("Error creating usage charge:", error);
  }
};
