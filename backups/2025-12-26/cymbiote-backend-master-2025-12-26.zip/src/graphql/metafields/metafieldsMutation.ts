import axios from "axios";
import dotenv from "dotenv";

dotenv.config();

const API_VERSION = process.env.API_VERSION;

export async function createMetaobjectEntryMutation(
  accessToken: any,
  shopDomain: any,
  categoryName: string,
  categoryPath: string,
  metaobjectKey: string
) {
  const mutation = `
      mutation {
        metaobjectCreate(
          metaobject: {
            type: "${metaobjectKey}",
            fields: [
              { key: "category_name", value: "${categoryName}" },
              { key: "category_path", value: "${categoryPath}" }
            ]
          }
        ) {
          metaobject {
            id
            fields {
              key
              value
            }
          }
          userErrors {
            field
            message
          }
        }
      }
    `;

  const apiUrl = `https://${shopDomain}/admin/api/${API_VERSION}/graphql.json`;
  const result = await axios.post(
    apiUrl,
    { query: mutation },
    {
      headers: {
        "X-Shopify-Access-Token": accessToken,
        "Content-Type": "application/json",
      },
    }
  );

  // Check if there are any user errors returned from the GraphQL response
  if (result.data.data.metaobjectCreate.userErrors.length) {
    console.error(
      `Error creating metaobject entry for ${categoryName}:`,
      result.data.metaobjectCreate.userErrors
    );
    return result.data.data.metaobjectCreate.userErrors;
  } else {
    console.log(`Metaobject entry created successfully for ${categoryName}`);
    return result.data.data.metaobjectCreate.metaobject;
  }
}
