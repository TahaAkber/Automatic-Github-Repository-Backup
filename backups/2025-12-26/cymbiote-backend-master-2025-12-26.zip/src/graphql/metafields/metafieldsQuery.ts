import axios from "axios";
import { sendErrorEmail } from "../../services/emailService";

export const fetchGoogleTaxonomy = async () => {
  console.log("testing=======>");
  try {
    const response = await axios.get(
      "https://www.google.com/basepages/producttype/taxonomy.en-US.txt"
    );
    const data = await response.data;
    const categories = data
      .split("\n")
      .filter((line: any) => line && !line.startsWith("#"));
    console.log("testing12=======>", categories);

    return categories;
  } catch (error: any) {
    sendErrorEmail("Error fetching Google Taxonomy:", error);

    console.error("Error fetching Google Taxonomy:", error);
    throw new Error("Failed to fetch Google Taxonomy");
  }
};
