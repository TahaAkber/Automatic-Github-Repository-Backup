import axios from "axios";
import dotenv from "dotenv";
import {
  deleteCollectionProducts,
  deleteCollections,
} from "../../models/collections/collectionModel";
import { sendErrorEmail } from "../../services/emailService";

dotenv.config();
const API_VERSION = process.env.API_VERSION;

export const deleteShopifyCollectionByShopifyId = async (
  accessToken: string,
  shopDomain: string,
  collection_shopify_id: any,
  collection_id: number
) => {
  const deleteMutation = `
    mutation collectionDelete($input: CollectionDeleteInput!) {
        collectionDelete(input: $input) {
        deletedCollectionId
    shop {
        id
        name
    }
    userErrors {
        field
        message
    }
  }
}`;

  try {
    const DeleteMutationResponse = await axios.post(
      `https://${shopDomain}/admin/api/${API_VERSION}/graphql.json`,
      {
        query: deleteMutation,
        variables: {
          input: {
            id: collection_shopify_id,
          },
        },
      },
      {
        headers: {
          "X-Shopify-Access-Token": accessToken,
          "Content-Type": "application/json",
        },
      }
    );
    console.log("DeleteMutationResponse", DeleteMutationResponse.data.data);
    await deleteCollectionProducts(collection_id);

    await deleteCollections(collection_id);

    return DeleteMutationResponse.data.data.collectionDelete.shop;
  } catch (error: any) {
    sendErrorEmail("Error while deleting Shopify Collection", error);

    console.log("Error while deleting Shopify Collection", error);
    throw error;
  }
};
