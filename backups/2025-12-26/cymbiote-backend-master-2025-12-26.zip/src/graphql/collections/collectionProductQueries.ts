import axios from "axios";
import dotenv from "dotenv";
import {
  deleteCollectionProducts,
  updateCollectionProducts,
} from "../../models/collections/collectionModel";
import { sendErrorEmail } from "../../services/emailService";

dotenv.config();

const API_VERSION = process.env.API_VERSION;

export const shopifyCollectionProductCounts = async (
  id: number,
  accessToken: string,
  shopDomain: string
) => {
  const ID = `gid://shopify/Collection/${id}`;
  const query = `
     query GetCollection {
    collection(id: "${ID}") {
    id
    title
    handle
    productsCount {
      count
    }
  }
}`;
  try {
    const apiUrl = `https://${shopDomain}/admin/api/${API_VERSION}/graphql.json`;
    const response = await axios.post(
      apiUrl,
      { query },
      {
        headers: {
          "X-Shopify-Access-Token": accessToken,
          "Content-Type": "application/json",
        },
      }
    );
    return response.data.data.collection.productsCount.count;
  } catch (error: any) {
    sendErrorEmail("Error while getting collection products count", error);

    console.log("Error while getting collection products count", error);
  }
};

export const syncCollectionProductsToDB = async (
  collectionId: number,
  accessToken: string,
  shopDomain: string,
  collection_id: number,
  CollectionProductCount: number
) => {
  const gqlQuery = `
    query GetCollectionProducts($id: ID!, $cursor: String) {
      collection(id: $id) {
        products(first: 250, after: $cursor) {
          pageInfo {
            hasNextPage
          }
          edges {
            cursor
            node {
              id
              title
              handle
            }
          }
        }
      }
    }
  `;

  const shopifyCollectionId = `gid://shopify/Collection/${collectionId}`;
  let hasNextPage = true;
  let cursor: string | null = null;

  try {
    const apiUrl = `https://${shopDomain}/admin/api/${API_VERSION}/graphql.json`;

    while (hasNextPage) {
      const response: any = await axios.post(
        apiUrl,
        {
          query: gqlQuery,
          variables: {
            id: shopifyCollectionId,
            cursor,
          },
        },
        {
          headers: {
            "X-Shopify-Access-Token": accessToken,
            "Content-Type": "application/json",
          },
        }
      );

      const products = response.data.data.collection.products.edges;

      await deleteCollectionProducts(collection_id);

      // Loop and update in DB
      for (const edge of products) {
        const product = edge.node;

        const collectionProducts = await updateCollectionProducts(
          product.title,
          product.id,
          collection_id,
          CollectionProductCount
        );

        console.log(`Updated: ${product.title}`);
      }

      // Prepare for next iteration
      hasNextPage = response.data.data.collection.products.pageInfo.hasNextPage;
      cursor =
        products.length > 0 ? products[products.length - 1].cursor : null;
    }

    console.log("✅ All products synced to DB");
  } catch (error: any) {
    sendErrorEmail("Error while getting collection products count", error);

    console.error(
      "Error while getting collection products count",
      error.response?.data || error.message
    );
  }
};

export const deleteShopifyProducts = async () => {};
