import axios from "axios";
import dotenv from "dotenv";
import { customerCreateMutation } from "../customer/mutation";
import {
  getLatestDiscountId,
  getLatestVoucherId,
} from "../../models/discount/discountModel";
import { sendErrorEmail } from "../../services/emailService";

dotenv.config();

const API_VERSION = process.env.API_VERSION;
const APP_NAME = process.env.APP_NAME;

export const createVoucherOnMerchant = async (
  shopDomain: string,
  accessToken: string,
  formattedPointstodeduct: number,
  user: any
) => {
  console.log("testing ", formattedPointstodeduct);
  try {
    // 1️⃣ Query Shopify to check if the customer exists by email
    const queryCustomer = `
      query {
        customers(first: 1, query: "email:${user.user_email}") {
          edges {
            node {
              id
              displayName
            }
          }
        }
      }
    `;

    const customerResponse = await axios.post(
      `https://${shopDomain}/admin/api/${API_VERSION}/graphql.json`,
      { query: queryCustomer },
      {
        headers: {
          "X-Shopify-Access-Token": accessToken,
          "Content-Type": "application/json",
        },
      }
    );

    const { data: customerData } = customerResponse;

    let customerId: string | null = null;

    console.log("first customerData:", customerData);

    if (customerData.data.customers.edges.length > 0) {
      // ✅ Customer exists, extract the customer ID
      customerId = customerData.data.customers.edges[0].node.id;
    } else {
      // 2️⃣ If customer does not exist, create a new one
      console.log("Customer not found, creating new customer...");
      const newCustomerData = await customerCreateMutation(
        user.user_first_name,
        user.user_last_name,
        user.user_email,
        shopDomain,
        accessToken
      );

      // ✅ New customer created, extract the customer ID
      customerId = newCustomerData.id;

      console.log("New customer created:", customerId);
    }

    // const queryGiftCard = `
    //   mutation giftCardCreate($input: GiftCardCreateInput!) {
    //     giftCardCreate(input: $input) {
    //       giftCard {
    //         id
    //         initialValue {
    //           amount
    //           currencyCode
    //         }
    //         customer {
    //           id
    //         }
    //         expiresOn
    //       }
    //       giftCardCode
    //       userErrors {
    //         message
    //         field
    //       }
    //     }
    //   }
    // `;

    const query = `
    mutation CreateDiscountCode($basicCodeDiscount: DiscountCodeBasicInput!) {
      discountCodeBasicCreate(basicCodeDiscount: $basicCodeDiscount) {
        codeDiscountNode {
          id
          codeDiscount {
            ... on DiscountCodeBasic {
              title
              startsAt
              endsAt
            }
          }
        }
        userErrors {
          field
          message
        }
      }
    }
    `;

    const currentDate = new Date();
    currentDate.setDate(currentDate.getDate() + 30);
    const currentDiscountId = await getLatestDiscountId();
    const voucherId = await getLatestVoucherId();
    console.log("currenct discount id ", currentDiscountId);
    console.log("currenct voucherId", voucherId);
    const formattedExpirationDate = currentDate.toISOString().split("T")[0];
    let newDiscount = 0;
    if (voucherId > 0) {
      newDiscount = voucherId + 1;
    } else {
      newDiscount = 1;
    }
    const DISCOUNT_CODE = "VOUCHER" + "DISC" + newDiscount;

    // const giftCardVariables = {
    //   input: {
    //     initialValue: voucherValue,
    //     customerId: customerId ? customerId : null,
    //     expiresOn: formattedExpirationDate,
    //   },
    // };

    const discountCodeVariables = {
      basicCodeDiscount: {
        title: `Cercle Voucher for ${user.user_email}`,
        code: DISCOUNT_CODE,
        startsAt: new Date(),
        endsAt: formattedExpirationDate,
        customerSelection: {
          customers: {
            add: [customerId],
          },
        },
        customerGets: {
          value: {
            discountAmount: {
              amount: formattedPointstodeduct,
              appliesOnEachItem: false,
            },
          },
          items: {
            all: true,
          },
        },
        minimumRequirement: {
          subtotal: {
            greaterThanOrEqualToSubtotal: 10.0,
          },
        },
        usageLimit: 1,
        appliesOncePerCustomer: true,
      },
    };

    const discountResponse = await axios.post(
      `https://${shopDomain}/admin/api/${API_VERSION}/graphql.json`,
      {
        query: query,
        variables: discountCodeVariables,
      },
      {
        headers: {
          "X-Shopify-Access-Token": accessToken,
          "Content-Type": "application/json",
        },
      }
    );

    console.log(
      "object discount Code response",
      discountResponse.data.data.discountCodeBasicCreate
    );

    // if (
    //   discountResponse.data.data.discountCodeBasicCreate.usersErrors.length > 0
    // ) {
    //   console.error(
    //     "Error creating gift card:",
    //     discountResponse.data.data.discountCodeBasicCreate.usersErrors
    //   );

    //   throw new Error("Error creating gift card");
    // }
    console.log(
      "object discount Code response final",
      discountResponse.data.data.discountCodeBasicCreate.codeDiscountNode
    );

    return {
      code: DISCOUNT_CODE,
      id: discountResponse.data.data.discountCodeBasicCreate.codeDiscountNode
        .id,
      discountCardCode:
        discountResponse.data.data.discountCodeBasicCreate.codeDiscountNode
          .codeDiscount,
    };
  } catch (error: any) {
    sendErrorEmail("Error in createVoucherOnMerchant:", error);

    console.error("Error in createVoucherOnMerchant:", error);
    throw new Error("Failed to create voucher");
  }
};
