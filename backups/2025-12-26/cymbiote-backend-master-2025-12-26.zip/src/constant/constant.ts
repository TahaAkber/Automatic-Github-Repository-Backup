export const reels = [
    "https://cdn.shopify.com/videos/c/vp/4b4331ade2674bbb9b0885f49d103474/4b4331ade2674bbb9b0885f49d103474.HD-1080p-2.5Mbps-42427073.mp4",
    "https://cdn.shopify.com/videos/c/vp/643bc79de87345e5b036d08fc37f1c23/643bc79de87345e5b036d08fc37f1c23.HD-1080p-4.8Mbps-41016729.mp4",
    "https://cdn.shopify.com/videos/c/vp/55da2d70f6834fd4a4f66078a1b1fe78/55da2d70f6834fd4a4f66078a1b1fe78.HD-1080p-7.2Mbps-41017611.mp4"
]

export const reelThumbnail = [
    "https://images.unsplash.com/photo-1542291026-7eec264c27ff?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8c2hvZXN8ZW58MHx8MHx8fDA%3D",
    "https://images.unsplash.com/photo-1460353581641-37baddab0fa2?fm=jpg&q=60&w=3000&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTB8fHNob2VzfGVufDB8fDB8fHww",
    "https://images.pexels.com/photos/786003/pexels-photo-786003.jpeg?cs=srgb&dl=pexels-pluyar-786003.jpg&fm=jpg"
]