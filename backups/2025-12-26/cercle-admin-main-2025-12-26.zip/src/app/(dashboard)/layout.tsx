// Type Imports
import type { ChildrenType } from "../../@core/types";

// Layout Imports
import LayoutWrapper from "@layouts/LayoutWrapper";
import { VerticalLayout } from "@layouts/VerticalLayout";

// Component Imports
// import Navigation from "../../components/layout/vertical/Navigation";
// import Navbar from "../../components/layout/vertical/Navbar";
// import VerticalFooter from "../components/layout/vertical/Footer";

const Layout = async ({ children }: ChildrenType) => {
  // Vars

  return (
      <LayoutWrapper
        verticalLayout={
          <VerticalLayout direction="ltr">{children}</VerticalLayout>
        }
      />
  );
};

export default Layout;
