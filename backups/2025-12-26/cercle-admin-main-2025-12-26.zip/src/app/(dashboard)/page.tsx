// MUI Imports
import {
  Grid,
  Container,
  Skeleton,
  Alert,
  AlertTitle,
  Button,
  Box,
} from "@mui/material";

// Components Imports
import Award from "../../views/dashboard/Award";
import Transactions from "../../views/dashboard/Transactions";
import WeeklyOverview from "../../views/dashboard/WeeklyOverview";
import TotalEarning from "../../views/dashboard/TotalEarning";
import LineChart from "../../views/dashboard/LineChart";
import DistributedColumnChart from "../../views/dashboard/DistributedColumnChart";
import DepositWithdraw from "../../views/dashboard/DepositWithdraw";
import SalesByCountries from "../../views/dashboard/SalesByCountries";
import CardStatVertical from "../../components/card-statistics/Vertical";
import { useEffect, useRef, useState, useCallback } from "react";
import { useAppDispatch } from "../../components/hooks/hooks";
import {
  fetchBestSellerShop,
  fetchDashboardShopOrderPrices,
  fetchDashboardShopProducts,
  fetchDashboardTransactions,
} from "../../../src/redux/thunks/dashboardThunks";
import { useSelector } from "react-redux";
import Cookies from "js-cookie";

const DashboardAnalytics = () => {
  const dispatch = useAppDispatch();

  const {
    transactions,
    shop_products,
    totalAmountInPKR,
    currencyDetails,
    best_seller_shop,
    trendingshops,
  } = useSelector((state: any) => state.dashboard);

  // Page-level loading & error
  const [pageLoading, setPageLoading] = useState(true);
  const [errors, setErrors] = useState<string[]>([]);
  const didRun = useRef(false);

  const fetchAll = useCallback(async () => {
    setPageLoading(true);
    setErrors([]);

    const token = Cookies.get("authToken");
    if (token) {
      const results = await Promise.allSettled([
        dispatch(fetchDashboardTransactions()),
        dispatch(fetchDashboardShopProducts()),
        dispatch(fetchDashboardShopOrderPrices()),
        dispatch(fetchBestSellerShop()),
      ]);

      // Collect any errors
      const errs: string[] = results
        .map((r, i) => {
          if (r.status === "rejected")
            return r.reason?.message || `Request ${i + 1} failed`;
          // Some RTK thunks reject with fulfilled status but an error payload; handle that too
          if (r.status === "fulfilled" && (r.value as any)?.error) {
            return (r.value as any).error?.message || `Request ${i + 1} failed`;
          }
          return null;
        })
        .filter(Boolean) as string[];

      setErrors(errs);
      setPageLoading(false);
    }
  }, [dispatch]);

  useEffect(() => {
    if (didRun.current) return;
    didRun.current = true;
    fetchAll();
  }, [fetchAll]);

  // --- Page-level loading skeleton (only show real content when ALL done) ---
  if (pageLoading) {
    return (
      <Container maxWidth="xl" sx={{ mt: 3, px: { xs: 2, sm: 1 } }}>
        <Grid container spacing={3}>
          {/* Row 1 skeletons */}
          <Grid size={{ xs: 12, md: 4 }}>
            <Skeleton
              variant="rectangular"
              height={180}
              sx={{ borderRadius: 2 }}
            />
          </Grid>
          <Grid size={{ xs: 12, md: 8 }}>
            <Skeleton
              variant="rectangular"
              height={180}
              sx={{ borderRadius: 2 }}
            />
          </Grid>

          {/* Row 2 skeletons */}
          <Grid size={{ xs: 12, md: 4 }}>
            <Skeleton
              variant="rectangular"
              height={452}
              sx={{ borderRadius: 2 }}
            />
          </Grid>
          <Grid size={{ xs: 12, md: 8 }}>
            <Skeleton
              variant="rectangular"
              height={452}
              sx={{ borderRadius: 2 }}
            />
          </Grid>

          {/* Row 3 skeletons */}
          <Grid size={{ xs: 12, md: 12 }}>
            <Grid container spacing={3}>
              <Grid size={{ xs: 6, md: 6 }}>
                <Skeleton
                  variant="rectangular"
                  height={120}
                  sx={{ borderRadius: 2 }}
                />
              </Grid>
              <Grid size={{ xs: 6, md: 6 }}>
                <Skeleton
                  variant="rectangular"
                  height={120}
                  sx={{ borderRadius: 2 }}
                />
              </Grid>
              <Grid size={{ xs: 6, md: 6 }}>
                <Skeleton
                  variant="rectangular"
                  height={300}
                  sx={{ borderRadius: 2 }}
                />
              </Grid>
              <Grid size={{ xs: 6, md: 6 }}>
                <Skeleton
                  variant="rectangular"
                  height={300}
                  sx={{ borderRadius: 2 }}
                />
              </Grid>
            </Grid>
          </Grid>

          {/* Row 4 skeletons */}
          <Grid size={{ xs: 12, md: 6, lg: 4 }}>
            <Skeleton
              variant="rectangular"
              height={380}
              sx={{ borderRadius: 2 }}
            />
          </Grid>
          <Grid size={{ xs: 12, md: 6, lg: 8 }}>
            <Skeleton
              variant="rectangular"
              height={380}
              sx={{ borderRadius: 2 }}
            />
          </Grid>
        </Grid>
      </Container>
    );
  }

  return (
    <Container maxWidth="xl" sx={{ mt: 3, px: { xs: 2, sm: 1 } }}>
      {/* Combined errors (if any) */}
      {errors.length > 0 && (
        <Box mb={2}>
          <Alert
            severity="error"
            action={
              <Button color="inherit" size="small" onClick={fetchAll}>
                Retry
              </Button>
            }
          >
            <AlertTitle>Some data failed to load</AlertTitle>
            {errors.map((e, idx) => (
              <div key={idx}>{e}</div>
            ))}
          </Alert>
        </Box>
      )}

      <Grid container spacing={3}>
        {/* Row 1: Award & Transactions */}
        <Grid size={{ xs: 12, md: 4 }}>
          <Award best_seller_shop={best_seller_shop} loading={pageLoading} />
        </Grid>
        <Grid size={{ xs: 12, md: 8 }}>
          <Transactions transactions={transactions} loading={pageLoading} />
        </Grid>

        {/* Row 2: Weekly Overview & Total Earning */}
        <Grid size={{ xs: 12, md: 4 }}>
          <WeeklyOverview
            shops={trendingshops || []}
            currencyDetails={currencyDetails}
            loading={pageLoading}
          />
        </Grid>
        <Grid size={{ xs: 12, md: 8 }}>
          <TotalEarning
            shop_products={shop_products}
            totalAmountInPKR={totalAmountInPKR}
            loading={pageLoading}
          />
        </Grid>

        {/* Row 3: Stats Cards & Charts Section */}
        <Grid size={{ xs: 12, md: 12 }}>
          <Grid container spacing={3}>
            {/* Stats Cards */}
            <Grid size={{ xs: 6, md: 6 }}>
              <CardStatVertical
                title="Total Profit"
                stats="$25.6k"
                avatarIcon="ri-pie-chart-2-line"
                avatarColor="secondary"
                subtitle="Weekly Profit"
                trendNumber="42%"
                trend="positive"
              />
            </Grid>
            <Grid size={{ xs: 6, md: 6 }}>
              <CardStatVertical
                stats="862"
                trend="negative"
                trendNumber="18%"
                title="New Project"
                subtitle="Yearly Project"
                avatarColor="primary"
                avatarIcon="ri-file-word-2-line"
              />
            </Grid>

            {/* Charts */}
            <Grid size={{ xs: 6, md: 6 }}>
              <LineChart />
            </Grid>
            <Grid size={{ xs: 6, md: 6 }}>
              <DistributedColumnChart />
            </Grid>
          </Grid>
        </Grid>

        {/* Row 4: Sales by Countries & Deposit Withdraw */}
        <Grid size={{ xs: 12, md: 6, lg: 4 }}>
          <SalesByCountries />
        </Grid>
        <Grid size={{ xs: 12, md: 6, lg: 8 }}>
          <DepositWithdraw />
        </Grid>

        {/* Row 5: Reserved for Table */}
        <Grid size={{ xs: 12 }}>{/* <Table /> */}</Grid>
      </Grid>
    </Container>
  );
};

export default DashboardAnalytics;
