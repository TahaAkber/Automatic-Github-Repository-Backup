const Error = () => {
  return <div>Error Occured</div>;
};

export default Error;
