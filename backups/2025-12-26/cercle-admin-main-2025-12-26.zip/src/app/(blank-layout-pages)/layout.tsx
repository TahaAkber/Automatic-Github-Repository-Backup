// Type Imports

// Component Imports
import BlankLayout from "@layouts/BlankLayout";

const Layout = ({ children }: any) => {
  // Vars

  return (
      <BlankLayout>{children}</BlankLayout>
  );
};

export default Layout;
