const UnderMaintenancePage = () => {
  // Vars

  return <div>We are Under Maintaintenance</div>;
};

export default UnderMaintenancePage;
