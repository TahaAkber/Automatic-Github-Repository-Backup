// Component Imports
import BlankLayout from "@layouts/BlankLayout";
// import NotFound from '@views/NotFound'

// Util Imports
// import { getServerMode } from "@core/utils/serverHelpers";

const NotFoundPage = () => {
  // Vars
  // const mode = getServerMode();

  return (
    <BlankLayout>
      {/* <NotFound mode={mode} /> */}
      <div>Not Found</div>
    </BlankLayout>
  );
};

export default NotFoundPage;
