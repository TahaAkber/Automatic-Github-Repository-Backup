// api.js (or a utility file)
import axios from "axios";
import { appUrl } from "../redux/thunks/authThunks";
import Cookies from "js-cookie";
import { decryptToken } from "../components/functions/encryption";

let decodedCryptoToken = "";

export const updateuserRoles = async (
  userId: any,
  username: string,
  status: boolean,
  roles: any[]
) => {
  decodedCryptoToken = decryptToken(Cookies.get("authToken") || "");

  try {
    const rolesData = await axios.put(
      `${appUrl}/api/role/edit?id=${userId}`,
      {
        name: username,
        isActive: status,
        roles: roles,
      },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${decodedCryptoToken}`,
        },
      }
    );
    console.log("roles data", rolesData.data);
    return rolesData.data;
  } catch (error) {
    console.error("Error updating user:", error);
    throw error;
  }
};

export const updateuserstatus = async (id: any, status: boolean) => {
  decodedCryptoToken = decryptToken(Cookies.get("authToken") || "");

  try {
    const response = await axios.put(
      `${appUrl}/api/users/updatestatus?id=${id}`,
      { status: status },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${decodedCryptoToken}`,
        },
      }
    );
    console.log("updateuserstatus", response.data);
  } catch (error: any) {
    console.error("Error details:", error.response?.data || error.message);
  }
};

export const fetchRoles = async () => {
  decodedCryptoToken = decryptToken(Cookies.get("authToken") || "");

  try {
    const rolesData = await axios.get(`${appUrl}/api/role/all`, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${decodedCryptoToken}`,
      },
    });

    console.log("roles data", rolesData.data.result);
    return rolesData.data.result;
  } catch (error) {
    console.error("Error fetching roles:", error);
    throw error;
  }
};

export const deleteUser = async (userId: any) => {
  decodedCryptoToken = decryptToken(Cookies.get("authToken") || "");

  try {
    console.log("userid", userId);
    const response = await axios.delete(
      `${appUrl}/api/users/delete?id=${userId}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${decodedCryptoToken}`,
        },
      }
    );
    console.log("User deleted successfully:", response.data);
  } catch (error) {
    console.error("Error deleting user:", error);
    throw error;
  }
};
