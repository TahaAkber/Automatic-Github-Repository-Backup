function formatDate(dateLike: any): string {
  const date = dateLike ? new Date(dateLike) : new Date();
  try {
    return new Intl.DateTimeFormat(undefined, {
      year: "numeric",
      month: "short",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
    }).format(date);
  } catch {
    return String(dateLike ?? "");
  }
}

export default formatDate;