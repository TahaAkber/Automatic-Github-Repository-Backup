const formatK = (val?: number | null): string => {
  const n = Number(val);
  if (!isFinite(n) || isNaN(n)) return "0";

  const abs = Math.abs(n);

  if (abs >= 1_000_000_000)
    return `${(n / 1_000_000_000)
      .toFixed(2)
      .replace(/\.0+$|(\.\d*[1-9])0+$/, "$1")}B`;

  if (abs >= 1_000_000)
    return `${(n / 1_000_000)
      .toFixed(2)
      .replace(/\.0+$|(\.\d*[1-9])0+$/, "$1")}M`;

  if (abs >= 1_000)
    return `${(n / 1_000).toFixed(2).replace(/\.0+$|(\.\d*[1-9])0+$/, "$1")}K`;

  return n.toLocaleString();
};

export default formatK;
