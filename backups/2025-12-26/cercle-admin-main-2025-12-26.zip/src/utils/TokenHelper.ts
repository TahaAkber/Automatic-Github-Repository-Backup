import Cookies from "js-cookie";

// helpers (top of file or a utils file)
const sleep = (ms: number) => new Promise((res) => setTimeout(res, ms));

export const waitForAuthToken = async (maxMs = 8000, stepMs = 150) => {
  const start = Date.now();
  let token = Cookies.get("authToken");
  while (!token && Date.now() - start < maxMs) {
    await sleep(stepMs);
    token = Cookies.get("authToken");
  }
  return token ?? null;
};
