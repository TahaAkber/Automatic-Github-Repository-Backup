export interface NotificationItem {
  app_notification_id: number;
  app_notification_user_id: number;
  app_notification_active?: boolean;

  // add other fields as per response...
}

export interface MerchantResponse {
  status: number | string;
  message: string;
  pagination: Pagination;
  Products?: any[];
  merchants: string[];
}
export interface brandsResponse {
  status: number | string;
  message: string;
  pagination: Pagination;
  brands: any[];
  brands_requests?: any[];
}

export interface Pagination {
  currentPage: string; // comes as string from API
  totalPages: number;
  totalCount: number;
}

export interface NotificationResponse {
  status: number;
  message: string;
  notifications: NotificationItem[];
  pagination: Pagination;
  totalCount: number;
  totalPages: number;
}

export interface NotificationState {
  status: number | null;
  message: string;
  notifications: NotificationItem[];
  totalCount: number;
  totalPages: number;
  pagination?: Pagination;
  error: string | null;
}

export interface RegisterCredentials {
  username: string;
  email: string;
  roles: any[];
}

export interface RegisterResponse {
  status: string | number | any;
  message: string;
  tempPassword: string;
  email: string;
}

export interface LoginCredentials {
  email: string;
  password: string;
}

interface User {
  id: string;
  username: string;
  email: string;
  onboarded: boolean;
  roles: any[];
  isRead: boolean;
  isWrite: boolean;
}

export interface AuthResponse {
  user: User;
  isValidToken: boolean;
  status: number | string | null;
  encodedToken: string;
}

export interface CollectionResponse {
  status: number | string;
  message: string;
  pagination?: Pagination;
  collections: string[];
}

export interface CreateCollectionPayload {
  collection_Description: string;
  collection_Title: string;
  collection_image_url: string;
  end_Date: any;
}

export interface CreateCollectionResponse {
  success: boolean;
  message: string;
  data: any; // or you can type it more specifically if known
}

export type NotificationPayload = {
  app_notification_title: string;
  app_notification_body: string;
  app_notification_type: string;
  app_notifcation_schedule_type: string;
  app_notification_time_slot: string;
  app_notification_read: boolean;
  app_notification_starts_at: string | null;
  app_notification_ends_at: string | null;
  app_notification_screen_name: string | null;
  app_notification_shop_id: number | null;
  app_notification_product_ids?: number[];
  app_notification_image_url: string | null;
};

export interface OrderResponse {
  status: number | string;
  message: string;
  pagination: Pagination;
  orders: any[];
}
export interface OrderdetailResponse {
  status: number | string;
  message: string;
  orderdetail: string;
  orderItems: any[];
}

export interface CancelOrders {
  status: number | string;
  message: string;
  cancelOrders: any[];
}
export type CreatePlansResponse = {
  package_name: string;
  package_rate: number;
  package_description: string;
  package_order_limit: number;
  package_limit_exceed_charges: number;
  package_trial_days: number;
  package_charges: number;
};
export interface Planresult {
  status: number;
  result: CreatePlansResponse;
  message: string;
}

export type CreatePlanRequest = {
  package_name: string;
  package_rate: number;
  package_description: string;
  package_order_limit: number;
  package_limit_exceed_charges: number;
  package_trial_days: number;
  package_charges: number;
  package_video_count?: number;
};

export interface PlansResponse {
  status: number | string;
  message: string;
  pagination: Pagination;
  plansResult: string[];
}

export interface ReviewsResponse {
  status: Number;
  message: string;
  reviews: any[];
  pagination: Pagination;
}

export type trackingOrderItem = {
  id: string;
  tracking_order_item_id: string;
  tracking_order_item_quantity: number;
  tracking_id: string;
};

export type TrackingEvent = {
  time_iso: string;
  time_utc: string | null;
  time_raw: {
    date: string | null;
    time: string | null;
    timezone: string | null;
  };
  description: string;
  location: string | null;
  stage: string | null;
  sub_status: string;
  address: {
    country: string | null;
    state: string | null;
    city: string | null;
    street: string | null;
    postal_code: string | null;
    coordinates: {
      longitude: number | null;
      latitude: number | null;
    };
  };
};

export type Tracking = {
  id: number;
  tracking_number: string;
  tracking_status: string;
  tracking_url: string;
  tracking_carrier_code: string;
  tracking_order_id: number;
  tracking_shopify_id: string;
  tracking_events: TrackingEvent[] | string; // Change to TrackingEvent[] if you parse it
  created_at: string;
  updated_at: string;
};

export interface TrackingResponse {
  status: string;
  message: string;
  trackingOrderItem: trackingOrderItem;
  tracking: Tracking;
  orders: any;
}

export interface UserResponse {
  status: number | string;
  message: string;
  pagination: Pagination;
  users: string[];
}

export interface Report {
  report_id: number;
  reported_type: string;
  reported_reference_id: number;
  reported_by_user_id: number;
  reported_decision_id: number | null;
  reported_status: string;
  created_at: string;
  updated_at: string;
  reported_reason_main: string;
  reported_reason_sub: string;
  reported_reason_other_text: string | null;
  reported_has_order: boolean;
  reported_order_id: number | null;
  reel_id: number | null;
  reel_video_id: number | null;
  reel_video_url: string | null;
  video_id: number | null;
  video_shop_id: number | null;
  product_id: number | null;
  product_name: string | null;
  product_description: string | null;
  product_image_url: string | null;
  shop_id: number | null;
  shop_name: string | null;
  shop_email: string | null;
  shop_address: string | null;
  shop_logo_url: string | null;
  user_first_name: string;
  user_last_name: string;
  user_email: string;
}

export interface ReportsResponse {
  status: number | string;
  message: string;
  pagination: Pagination;
  reports: Report[];
}

export interface ForgotPasswordResponse {
  status: number | string;
  message: string;
  tempPassword: string;
  email: string;
  user: User;
  encodedToken: string;
}
