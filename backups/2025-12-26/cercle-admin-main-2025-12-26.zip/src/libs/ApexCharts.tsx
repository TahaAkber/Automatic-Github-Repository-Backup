import React, { Suspense } from "react";

const Chart = React.lazy<React.ComponentType<any>>(() =>
  typeof window !== "undefined"
    ? import("react-apexcharts")
    : Promise.resolve({ default: () => null } as { default: React.ComponentType<any> })
);

const LazyChart = (props: any) => {
  return (
    <Suspense fallback={<div>Loading chart...</div>}>
      <Chart {...props} />
    </Suspense>
  );
};

export default LazyChart;
