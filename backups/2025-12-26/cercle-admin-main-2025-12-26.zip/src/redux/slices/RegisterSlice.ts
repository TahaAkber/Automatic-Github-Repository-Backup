// src/redux/slices/authSlice.ts
import { createSlice } from "@reduxjs/toolkit";
import { registerUser } from "../thunks/authThunks";

interface AuthState {
  status: string | number | any;
  message: string;
  tempPassword: string;
  email: string;
}

const initialState: AuthState = {
  status: "",
  message: "",
  tempPassword: "",
  email: "",
};

const authRegister = createSlice({
  name: "authRegister",
  initialState,
  reducers: {
    resetRegisterState: (state) => {
      state.status = null;
      state.message = "";
      state.tempPassword = "";
      state.email = "";
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(registerUser.pending, (state) => {
        state.status = null;
      })
      .addCase(registerUser.fulfilled, (state, action) => {
        state.status = action.payload.status;
        state.message = action.payload.message;
        state.tempPassword = action.payload.tempPassword;
        state.email = action.payload.email;
        console.log("FULFILLED STATUS", action.payload);
      })
      .addCase(registerUser.rejected, (state, action) => {
        state.status = "failed";
        state.message = action.payload || "Registration failed.";
      });
  },
});

export const { resetRegisterState } = authRegister.actions;
export default authRegister.reducer;
