import { createSlice } from "@reduxjs/toolkit";
import {
  fetchMerchantsDropdown,
  fetchProductsDropdown,
} from "../thunks/notificationDropdownThunks";

type Merchant = {
  shop_id: number;
  shop_name: string;
  shop_logo_url?: string | null;
};
type LiteProduct = {
  product_id: number;
  product_name: string;
  product_image_url?: string | null;
};

type Block<T> = {
  data: T[];
  loading: boolean;
  error: string | null;
  pagination?: {
    currentPage: number;
    totalPages: number;
    totalCount: number;
    limit: number;
  };
};

type NotificationDropdownState = {
  merchants: Block<Merchant>;
  products: Block<LiteProduct>;
};

const initialBlock = { data: [], loading: false, error: null } as Block<any>;

const initialState: NotificationDropdownState = {
  merchants: { ...initialBlock },
  products: { ...initialBlock },
};

const notificationDropdownSlice = createSlice({
  name: "dropdown",
  initialState,
  reducers: {
    clearDropdowns: () => initialState,
  },
  extraReducers: (builder) => {
    // Merchants
    builder
      .addCase(fetchMerchantsDropdown.pending, (state) => {
        state.merchants.loading = true;
        state.merchants.error = null;
      })
      .addCase(fetchMerchantsDropdown.fulfilled, (state, action: any) => {
        state.merchants.loading = false;
        state.merchants.data = action.payload?.merchants ?? [];
        state.merchants.pagination = action.payload?.pagination;
      })
      .addCase(fetchMerchantsDropdown.rejected, (state, action: any) => {
        state.merchants.loading = false;
        state.merchants.error = action.payload ?? "Error";
      });

    // Products
    builder
      .addCase(fetchProductsDropdown.pending, (state) => {
        state.products.loading = true;
        state.products.error = null;
      })
      .addCase(fetchProductsDropdown.fulfilled, (state, action: any) => {
        state.products.loading = false;
        state.products.data = action.payload?.products ?? [];
        state.products.pagination = action.payload?.pagination;
      })
      .addCase(fetchProductsDropdown.rejected, (state, action: any) => {
        state.products.loading = false;
        state.products.error = action.payload ?? "Error";
      });
  },
});

export const { clearDropdowns } = notificationDropdownSlice.actions;
export default notificationDropdownSlice.reducer;
