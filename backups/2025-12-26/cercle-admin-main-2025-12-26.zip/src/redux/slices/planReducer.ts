const initialState = {
  plansResult: [], 
  selectedPlan: null, 
};

const planstateReducer = (state = initialState, action: any) => {
  switch (action.type) {
    case "SET_SELECTED_PLAN":
      return {
        ...state,
        selectedPlan: action.payload, 
      };
    default:
      return state;
  }
};

export default planstateReducer;
