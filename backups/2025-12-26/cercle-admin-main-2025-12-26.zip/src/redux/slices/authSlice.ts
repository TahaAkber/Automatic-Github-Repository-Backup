import { createSlice } from "@reduxjs/toolkit";
import { forgotPassword, loginUser } from "../thunks/authThunks";
import Cookies from "js-cookie";

interface User {
  id: string;
  username: string;
  email: string;
  onboarded: boolean;
  encodedToken?: string;
  roles: any[];
}

interface AuthState {
  token: any | null;
  user: User | null;
  isValidToken: boolean;
  encodedToken: string;

  error: string;

  // Forgot password state
  forgotPasswordLoading: boolean;
  forgotPasswordError: string;
  forgotPasswordSuccess: boolean;

  // OTP verification state

}

const initialState: AuthState = {
  token: null,
  user: null,
  isValidToken: false,
  encodedToken: "",
  error: "",
  forgotPasswordLoading: false,
  forgotPasswordError: "",
  forgotPasswordSuccess: false,

};

const authSlice = createSlice({
  name: "auth",
  initialState,
  reducers: {
    logout: (state) => {
      state.token = null;
      state.isValidToken = false;
      state.user = null;
      Cookies.remove("authToken");
      state.error = "";
    },
    resetAuthStatus: (state) => {
      state.forgotPasswordLoading = false;
      state.forgotPasswordError = "";
      state.forgotPasswordSuccess = false;

    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(loginUser.pending, (state) => {
        state.token = null;
        state.user = null;
        state.isValidToken = false;
        state.error = "";
      })
      .addCase(loginUser.fulfilled, (state, action) => {
        state.token = action.payload ?? null;
        state.user = action.payload.user;
        state.isValidToken = true;
        state.encodedToken = action.payload.encodedToken;
        if (action.payload.status === 400) {
          state.error = action.payload as unknown as string;
        }
      })
      .addCase(loginUser.rejected, (state, action) => {
        state.error = action.payload as string;
      })
      .addCase(forgotPassword.pending, (state) => {
        state.forgotPasswordLoading = true;
        state.forgotPasswordError = "";
        state.forgotPasswordSuccess = false;
      })
      .addCase(forgotPassword.fulfilled, (state) => {
        state.forgotPasswordLoading = false;
        state.forgotPasswordSuccess = true;
        state.forgotPasswordError = "";
      })
      .addCase(forgotPassword.rejected, (state, action) => {
        state.forgotPasswordLoading = false;
        state.forgotPasswordSuccess = false;
        state.forgotPasswordError = action.payload as string;
      })

  },
});

export const { logout, resetAuthStatus } = authSlice.actions;
export default authSlice.reducer;
