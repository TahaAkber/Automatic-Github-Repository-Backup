import { createSlice } from "@reduxjs/toolkit";
import {
  fetchNotifications,
  deleteNotification,
  createNotification,
  fetchScheduledNotifications,
  toggleNotification, // ⬅️ add this import
} from "../thunks/notificationThunks";
import { NotificationState } from "../../types/pages/types";

const initialState: NotificationState & {
  scheduledNotifications?: any[];
  scheduledTotalCount?: number;
  scheduledTotalPages?: number;
  scheduledPagination?: {
    currentPage?: number;
    totalPages?: number;
    totalCount?: number;
  };
  scheduledError?: string | null;
} = {
  status: null,
  message: "",
  notifications: [],
  totalCount: 0,
  totalPages: 0,
  pagination: undefined,
  error: null,

  // scheduled defaults
  scheduledNotifications: [],
  scheduledTotalCount: 0,
  scheduledTotalPages: 0,
  scheduledPagination: undefined,
  scheduledError: null,
};

const notificationsSlice = createSlice({
  name: "notifications",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      // ---- Fetch Notifications (immediate / non-scheduled) ----
      .addCase(fetchNotifications.pending, (state) => {
        state.error = null;
      })
      .addCase(fetchNotifications.fulfilled, (state, action) => {
        state.status = action.payload.status ?? null;
        state.message = action.payload.message ?? "";
        state.notifications = action.payload.notifications ?? [];
        state.totalCount = action.payload.pagination?.totalCount ?? 0;
        state.totalPages = action.payload.pagination?.totalPages ?? 0;
        state.pagination = action.payload.pagination;

        if (action.payload.status === 400) {
          state.error =
            typeof action.payload === "string"
              ? action.payload
              : JSON.stringify(action.payload);
        }
      })
      .addCase(fetchNotifications.rejected, (state, action) => {
        state.error = (action.payload as string) ?? "Unknown error";
      })

      // ---- Fetch Scheduled Notifications ----
      .addCase(fetchScheduledNotifications.pending, (state) => {
        state.scheduledError = null;
      })
      .addCase(fetchScheduledNotifications.fulfilled, (state, action) => {
        state.status = action.payload.status ?? null;
        state.message = action.payload.message ?? "";
        state.scheduledNotifications = action.payload.notifications ?? [];
        state.scheduledTotalCount = action.payload.pagination?.totalCount ?? 0;
        state.scheduledTotalPages = action.payload.pagination?.totalPages ?? 0;

        if (action.payload.status === 400) {
          state.scheduledError =
            typeof action.payload === "string"
              ? action.payload
              : JSON.stringify(action.payload);
        }
      })
      .addCase(fetchScheduledNotifications.rejected, (state, action) => {
        state.scheduledError = (action.payload as string) ?? "Unknown error";
      })

      // ---- Delete Notification ----
      .addCase(deleteNotification.fulfilled, (state, action) => {
        state.notifications = state.notifications.filter(
          (notif) => notif.app_notification_id !== action.payload.id
        );
        state.scheduledNotifications = state.scheduledNotifications?.filter(
          (notif: any) => notif.app_notification_id !== action.payload.id
        );
        state.message = action.payload.message;
      })
      .addCase(deleteNotification.rejected, (state, action) => {
        state.error =
          (action.payload as string) ?? "Failed to delete notification";
      })

      // ---- Create Notification ----
      .addCase(createNotification.fulfilled, (state, action) => {
        state.notifications.unshift({
          app_notification_id: action.payload.id,
          app_notification_title: "",
          app_notification_body: "",
          app_notification_read: false,
        } as any);
        state.message = action.payload.message;
      })
      .addCase(createNotification.rejected, (state, action) => {
        state.error =
          (action.payload as string) ?? "Failed to create notification";
      })

      .addCase(toggleNotification.fulfilled, (state, action) => {
        const { id, active } = action.payload;

        const immediate = state.notifications.find(
          (n: any) => n.app_notification_id === id
        );
        if (immediate) immediate.app_notification_active = active;

        const scheduled = state.scheduledNotifications?.find(
          (n: any) => n.app_notification_id === id
        );
        if (scheduled) scheduled.app_notification_active = active;

        state.message = action.payload.message;
      })
      .addCase(toggleNotification.rejected, (state, action) => {
        state.error =
          (action.payload as string) ?? "Failed to toggle notification";
      });
  },
});

export default notificationsSlice.reducer;
