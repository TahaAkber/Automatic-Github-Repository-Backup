import { createSlice } from "@reduxjs/toolkit";
import { Pagination } from "./orderSlice";
import {
  deleteCollection,
  fetchCollectionById,
  fetchcollections,
} from "../thunks/collectionThunks";

interface CollectionState {
  status: string | number | any;
  message: string;
  pagination: Pagination | any;
  collections: string[];
  result?: any[];
  error: string;
  loading?: boolean;
}

const initialState: CollectionState = {
  status: "",
  message: "",
  pagination: null,
  collections: [],
  error: "",
  loading: false,
};

const collectionSlice = createSlice({
  name: "collections",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchcollections.pending, (state) => {
        state.status = null;
        state.message = "";
        state.pagination = null;
        state.collections = [];
      })
      .addCase(fetchcollections.fulfilled, (state, action) => {
        state.status = action.payload?.status;
        state.message = action.payload?.message;
        state.pagination = action.payload?.pagination;
        state.collections = action.payload?.collections;
        if (action.payload?.status === 400) {
          state.error =
            typeof action.payload === "string"
              ? action.payload
              : JSON.stringify(action.payload) || "";
        }
      })
      .addCase(fetchcollections.rejected, (state, action) => {
        state.error = action.payload as string;
      })

      .addCase(fetchCollectionById.pending, (state) => {
        state.status = null;
        state.message = "";
        state.pagination = null;
        state.collections = [];
      })
      .addCase(fetchCollectionById.fulfilled, (state, action) => {
        state.status = action.payload?.status;
        state.message = action.payload?.message;
        state.pagination = action.payload?.pagination;
        state.collections = action.payload?.collections;
        if (action.payload?.status === 400) {
          state.error =
            typeof action.payload === "string"
              ? action.payload
              : JSON.stringify(action.payload) || "";
        }
      })
      .addCase(fetchCollectionById.rejected, (state, action) => {
        state.error = action.payload as string;
      })
      .addCase(deleteCollection.pending, (state) => {
        state.error = "";
        state.message = "";
        state.loading = true;
      })
      .addCase(deleteCollection.fulfilled, (state, action) => {
        state.message = action.payload.message;
        state.loading = false;
      })
      .addCase(deleteCollection.rejected, (state, action) => {
        state.error =
          typeof action.payload === "string"
            ? action.payload
            : JSON.stringify(action.payload) || "Failed to delete Collection";
        state.loading = false;
      });
  },
});

export default collectionSlice.reducer;
