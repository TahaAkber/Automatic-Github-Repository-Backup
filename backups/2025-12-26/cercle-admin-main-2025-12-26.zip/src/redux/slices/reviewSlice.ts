import { createSlice } from "@reduxjs/toolkit";
import { fetchReviews } from "../thunks/reviewThunks";
import { Pagination } from "./orderSlice";
interface ReviewState {
  loading: boolean;
  reviews: any[];
  status: Number;
  pagination: Pagination | any;
  message: string;
}
const initialState: ReviewState = {
  loading: false,
  reviews: [],
  message: "",
  pagination: { page: 0, pageSize: 0, totalItems: 0 },
  status: 0,
};

const reviewSlice = createSlice({
  name: "reviews",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchReviews.pending, (state) => {
        state.loading = true;
      })
      .addCase(fetchReviews.fulfilled, (state, action) => {
        state.loading = false;
        state.reviews = action?.payload?.reviews;
        state.status = action?.payload?.status;
        state.message = action?.payload?.message;
        state.pagination = action?.payload?.pagination;
      })
      .addCase(fetchReviews.rejected, (state, action) => {
        state.loading = false;
        state.message = action.payload ?? "Failed to fetch Reviews";
      });
  },
});
export default reviewSlice.reducer;
