import { createSlice } from "@reduxjs/toolkit";
import { cancelOrders, fetchOrders, orderdetail } from "../thunks/orderThunks";

interface OrderState {
  status: string | number | any;
  message: string;
  pagination: Pagination | any;
  orders: any[] | any;
  orderitems: any[] | any;
  cancelledOrders?: any[];
  error: string;
  loading?: boolean;
}

export type Pagination = {
  page: number;
  pageSize: number;
  totalItems: number;
};

const initialState: OrderState = {
  status: "",
  message: "",
  pagination: null,
  cancelledOrders: [],
  orders: [],
  orderitems: [],
  error: "",
};

const orderSlice = createSlice({
  name: "orders",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchOrders.pending, (state) => {
        state.status = null;
        state.message = "";
        state.pagination = null;
        state.orders = [];
        state.error = "";
        state.loading = true;
      })
      .addCase(fetchOrders.fulfilled, (state, action) => {
        state.status = action.payload?.status;
        state.message = action.payload?.message;
        state.pagination = action.payload?.pagination;
        state.orders = action.payload?.orders;
        state.loading = false;
        if (action.payload?.status === 400) {
          state.error =
            typeof action.payload === "string"
              ? action.payload
              : JSON.stringify(action.payload) || "";
        }
      })
      .addCase(fetchOrders.rejected, (state, action) => {
        state.error = action.payload as string;
        state.loading = false;
      })
      .addCase(orderdetail.pending, (state) => {
        state.status = null;
        state.message = "";
        state.pagination = null;
        state.orders = [];
        state.error = "";
        state.loading = true;
      })
      .addCase(orderdetail.fulfilled, (state, action) => {
        state.status = action.payload?.status;
        state.message = action.payload?.message;
        state.orders = action.payload?.orderdetail;
        state.orderitems = action.payload?.orderItems || [];
        state.loading = false;

        if (action.payload?.status === 400) {
          state.error =
            typeof action.payload === "string"
              ? action.payload
              : JSON.stringify(action.payload) || "";
        }
      })
      .addCase(orderdetail.rejected, (state, action) => {
        state.error = action.payload || "Unknown error";
        state.loading = false;
      })
      .addCase(cancelOrders.pending, (state) => {
        state.status = null;
        state.message = "";
        state.pagination = null;
        state.error = "";
        state.loading = true;
      })
      .addCase(cancelOrders.fulfilled, (state, action) => {
        state.status = action.payload?.status;
        state.message = action.payload?.message;
        state.cancelledOrders = action.payload?.cancelOrders;
        if (action.payload && "pagination" in action.payload) {
          state.pagination = (action.payload as any).pagination;
        }
        state.loading = false;

        if (action.payload?.status === 400) {
          state.error =
            typeof action.payload === "string"
              ? action.payload
              : JSON.stringify(action.payload) || "";
        }
      })
      .addCase(cancelOrders.rejected, (state, action) => {
        state.error = action.payload || "Unknown error";
        state.loading = false;
      });
  },
});

export default orderSlice.reducer;
