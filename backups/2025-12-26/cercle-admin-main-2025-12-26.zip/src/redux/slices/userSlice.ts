import { createSlice } from "@reduxjs/toolkit";
import { Pagination } from "./orderSlice";
import { fetchadminUsers } from "../thunks/userThunks";
interface UserState {
  status: number | string | null;
  message: string;
  pagination: Pagination | any;
  users: string[];
  error: string | null;
}

const initialState: UserState = {
  status: "",
  message: "",
  pagination: null,
  users: [],
  error: "",
};

const userSlice = createSlice({
  name: "users",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchadminUsers.pending, (state) => {
        state.status = null;
        state.message = "";
        state.pagination = null;
        state.users = [];
        state.error = "";
      })
      .addCase(fetchadminUsers.fulfilled, (state, action) => {
        state.status = action.payload?.status;
        state.message = action.payload?.message;
        state.pagination = action.payload?.pagination;
        state.users = action.payload?.users;
        if (action.payload?.status === 400) {
          state.error =
            typeof action.payload === "string"
              ? action.payload
              : JSON.stringify(action.payload) || "";
        }
      })

      .addCase(fetchadminUsers.rejected, (state, action) => {
        state.error = action.payload as string;
      });
  },
});

export default userSlice.reducer;
