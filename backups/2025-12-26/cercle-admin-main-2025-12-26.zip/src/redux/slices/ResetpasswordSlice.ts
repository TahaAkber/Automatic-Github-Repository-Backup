import { createSlice } from "@reduxjs/toolkit";
import { resetpassword } from "../thunks/authThunks";

interface resetState {
  status?: string | number | any;
  message?: string;
  error?: string;
  loading?: any;
}

const initialState: resetState = {
  status: "",
  message: "",
  error: "",
  loading: null,
};

const ResetpasswordSlice = createSlice({
  name: "authReset",
  initialState,
  reducers: {
    resetResetPasswordStatus: (state) => {
      state.status = "";
      state.message = "";
      state.error = "";
      state.loading = null;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(resetpassword.pending, (state) => {
        state.loading = true;
        state.error = "";
      })
      .addCase(resetpassword.fulfilled, (state, action) => {
        state.loading = false;
        state.message = action?.payload?.message;
        state.status = action?.payload?.status;
      })
      .addCase(resetpassword.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;

        console.log("rejected", state.error);
      });
  },
});

export const { resetResetPasswordStatus } = ResetpasswordSlice.actions;
export default ResetpasswordSlice.reducer;
