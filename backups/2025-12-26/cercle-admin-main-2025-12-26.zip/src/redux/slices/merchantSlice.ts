import { createSlice } from "@reduxjs/toolkit";
import { Pagination } from "./orderSlice";
import {
  fetchmerchants,
  fetchbrands,
  fetchMerchantProducts,
  fetchBrandsRequest,
  fetchtiles,
} from "../thunks/merchantThunks";

interface ShopState {
  status: string | number | null;
  message: string;
  merchant_pagination: Pagination | any;
  merchant_product_pagination: Pagination | any;
  brand_pagination: Pagination | any;
  brands_requests_pagination: Pagination | any;
  merchants: any[]; // change to your concrete type if you have one
  brands: any[]; // change to your concrete type if needed
  Products: any[];
  error: string | null;
  loading: boolean;
  brands_requests?: any[];
  tiles?: any[];
}

const initialState: ShopState = {
  status: null,
  message: "",
  merchant_pagination: null,
  merchant_product_pagination: null,
  brand_pagination: null,
  brands_requests_pagination: null,
  merchants: [],
  brands: [],
  Products: [],
  error: null,
  loading: false,
  brands_requests: [],
  tiles: [],
};

const merchantSlice = createSlice({
  name: "merchants",
  initialState,
  reducers: {
    clearBrands(state) {
      state.brands = [];
    },
  },
  extraReducers: (builder) => {
    builder.addCase(fetchmerchants.pending, (state) => {
      state.loading = true;
      state.error = null;
    });
    builder.addCase(fetchmerchants.fulfilled, (state, action) => {
      state.loading = false;
      state.status = action.payload?.status ?? null;
      state.message = action.payload?.message ?? "";
      state.merchant_pagination = action.payload?.pagination ?? null;
      state.merchants = action.payload?.merchants ?? [];
      if (action.payload?.status === 400) {
        state.error =
          typeof action.payload === "string"
            ? action.payload
            : JSON.stringify(action.payload) || "Request failed";
      }
    });
    builder.addCase(fetchmerchants.rejected, (state, action) => {
      state.loading = false;
      state.error = (action.payload as string) || "Failed to fetch merchants";
    });

    builder.addCase(fetchbrands.pending, (state) => {
      state.loading = true;
      state.error = null;
    });
    builder.addCase(fetchbrands.fulfilled, (state, action) => {
      state.loading = false;
      state.status = action.payload?.status ?? null;
      state.message = action.payload?.message ?? "";
      state.brand_pagination = action.payload?.pagination ?? null;
      state.brands = action.payload?.brands ?? [];
      console.log("action payload of brands", action.payload);
      if (action.payload?.status === 400) {
        state.error =
          typeof action.payload === "string"
            ? action.payload
            : JSON.stringify(action.payload) || "Request failed";
      }
    });
    builder.addCase(fetchbrands.rejected, (state, action) => {
      state.loading = false;
      state.error = (action.payload as string) || "Failed to fetch brands";
    });

    builder.addCase(fetchMerchantProducts.pending, (state) => {
      state.loading = true;
      state.error = null;
    });
    builder.addCase(fetchMerchantProducts.fulfilled, (state, action) => {
      state.loading = false;
      state.status = action.payload?.status ?? null;
      state.message = action.payload?.message ?? "";
      state.merchant_product_pagination = action.payload?.pagination ?? null;
      state.Products = action.payload?.Products ?? [];
      if (action.payload?.status === 400) {
        state.error =
          typeof action.payload === "string"
            ? action.payload
            : JSON.stringify(action.payload) || "Request failed";
      }
    });
    builder.addCase(fetchMerchantProducts.rejected, (state, action) => {
      state.loading = false;
      state.error = (action.payload as string) || "Failed to fetch products";
    });
    builder.addCase(fetchBrandsRequest.pending, (state) => {
      state.loading = true;
      state.error = null;
    });
    builder.addCase(fetchBrandsRequest.fulfilled, (state, action) => {
      state.loading = false;
      state.status = action.payload?.status ?? null;
      state.message = action.payload?.message ?? "";
      state.brands_requests_pagination = action.payload?.pagination ?? null;
      state.brands_requests = action.payload?.brands_requests ?? [];
      if (action.payload?.status === 400) {
        state.error =
          typeof action.payload === "string"
            ? action.payload
            : JSON.stringify(action.payload) || "Request failed";
      }
    });
    builder.addCase(fetchBrandsRequest.rejected, (state, action) => {
      state.loading = false;
      state.error = (action.payload as string) || "Failed to fetch tiles";
    });
    builder.addCase(fetchtiles.pending, (state) => {
      state.loading = true;
      state.error = null;
    });
    builder.addCase(fetchtiles.fulfilled, (state, action) => {
      state.loading = false;
      state.status = action.payload?.status ?? null;
      state.message = action.payload?.message ?? "";
      state.tiles = action.payload?.tiles ?? [];
    });
    builder.addCase(fetchtiles.rejected, (state, action) => {
      state.loading = false;
      state.error = (action.payload as string) || "Failed to fetch tiles";
    });
  },
});
export const { clearBrands } = merchantSlice.actions;
export default merchantSlice.reducer;
