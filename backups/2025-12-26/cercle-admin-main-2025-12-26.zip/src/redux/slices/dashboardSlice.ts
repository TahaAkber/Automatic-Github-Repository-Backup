import { createSlice } from "@reduxjs/toolkit";
import {
  fetchBestSellerShop,
  fetchDashboardShopOrderPrices,
  fetchDashboardShopProducts,
  fetchDashboardTransactions,
} from "../thunks/dashboardThunks";

interface CollectionState {
  status: string | number | any;
  message: string;
  transactions?: any;
  shop_products?: any;
  totalAmountInPKR?: number;
  shops?: any[];
  currencyDetails?: any;
  trendingshops?:any[];
  best_seller_shop?: any;
  error: any;
  loading: boolean;
}

const initialState: CollectionState = {
  status: "",
  message: "",
  error: null,
  loading: false,
};

const collectionSlice = createSlice({
  name: "dashboard",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchDashboardTransactions.pending, (state) => {
        state.status = null;
        state.message = "";
        state.loading = true;
      })
      .addCase(fetchDashboardTransactions.fulfilled, (state, action) => {
        state.status = action.payload?.status;
        state.message = action.payload?.message;
        state.transactions = action.payload?.result;
        state.loading = false;
      })
      .addCase(fetchDashboardTransactions.rejected, (state, action) => {
        state.error = action.payload as string;
        state.loading = false;
      })
      .addCase(fetchDashboardShopProducts.pending, (state) => {
        state.status = null;
        state.message = "";
        state.loading = true;
      })
      .addCase(fetchDashboardShopProducts.fulfilled, (state, action) => {
        state.status = action.payload?.status;
        state.message = action.payload?.message;
        state.shop_products = action.payload?.result.rankedShops;
        state.totalAmountInPKR = action.payload?.result.totalAmountInPKR;
        state.loading = false;
      })
      .addCase(fetchDashboardShopProducts.rejected, (state, action) => {
        state.error = action.payload as string;
        state.loading = false;
      })
      .addCase(fetchDashboardShopOrderPrices.pending, (state) => {
        state.status = null;
        state.message = "";
        state.loading = true;
      })
      .addCase(fetchDashboardShopOrderPrices.fulfilled, (state, action) => {
        state.status = action.payload?.status;
        state.message = action.payload?.message;
        state.trendingshops = action.payload?.result.shops;
        state.currencyDetails = action.payload?.result.currencyDetails;
        state.loading = false;
      })
      .addCase(fetchDashboardShopOrderPrices.rejected, (state, action) => {
        state.error = action.payload as string;
        state.loading = false;
      })
      .addCase(fetchBestSellerShop.pending, (state) => {
        state.status = null;
        state.message = "";
        state.loading = true;
      })
      .addCase(fetchBestSellerShop.fulfilled, (state, action) => {
        state.status = action.payload?.status;
        state.message = action.payload?.message;
        state.shops = action.payload?.result.shops;
        state.best_seller_shop = action.payload?.result;
        state.loading = false;
      })
      .addCase(fetchBestSellerShop.rejected, (state, action) => {
        state.error = action.payload as string;
        state.loading = false;
      });
  },
});

export default collectionSlice.reducer;
