import { createSlice } from "@reduxjs/toolkit";
import { Pagination } from "./orderSlice";
import { fetchplans } from "../thunks/plansThunk";

interface PlansState {
  status: string | number | any;
  message: string;
  pagination: Pagination | any;
  plansResult: string[];
  error: string;
}

const initialState: PlansState = {
  status: "",
  message: "",
  pagination: null,
  plansResult: [],
  error: "",
};

const plansSlice = createSlice({
  name: "plans",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchplans.pending, (state) => {
        state.status = null;
        state.message = "";
        state.pagination = null;
        state.plansResult = [];
        state.error = "";
      })
      .addCase(fetchplans.fulfilled, (state, action) => {
        state.status = action.payload?.status;
        state.message = action.payload?.message;
        state.pagination = action.payload?.pagination;
        state.plansResult = action.payload?.plansResult;
        if (action.payload?.status === 400) {
          state.error =
            typeof action.payload === "string"
              ? action.payload
              : JSON.stringify(action.payload) || "";
        }
        console.log("testing data", state.plansResult);
      })
      .addCase(fetchplans.rejected, (state, action) => {
        state.error = action.payload as string;
      });
  },
});

export default plansSlice.reducer;
