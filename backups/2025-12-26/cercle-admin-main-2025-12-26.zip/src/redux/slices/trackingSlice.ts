import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { fetchtracking, fetchtrackingCredits } from "../thunks/trackingThunks";

type trackingOrderItem = {
  id: string;
  tracking_order_item_id: string;
  tracking_order_item_quantity: number;
  tracking_id: string;
};

type TrackingEvent = {
  time_iso: string;
  time_utc: string | null;
  time_raw: {
    date: string | null;
    time: string | null;
    timezone: string | null;
  };
  description: string;
  location: string | null;
  stage: string | null;
  sub_status: string;
  address: {
    country: string | null;
    state: string | null;
    city: string | null;
    street: string | null;
    postal_code: string | null;
    coordinates: {
      longitude: number | null;
      latitude: number | null;
    };
  };
};

type Tracking = {
  id: number;
  tracking_number: string;
  tracking_status: string;
  tracking_url: string;
  tracking_carrier_code: string;
  tracking_order_id: number;
  tracking_shopify_id: string;
  tracking_events: TrackingEvent[] | string;
  created_at: string;
  updated_at: string;
};

interface TrackingResponse {
  status: string;
  message: string;
  trackingOrderItem: trackingOrderItem;
  tracking: Tracking;
  orders: any;
}

interface TrackingState {
  loading: boolean;
  error: string | null;
  data: TrackingResponse | null;
  result?: any;
}

const initialState: TrackingState = {
  loading: false,
  error: null,
  data: null,
  result: null,
};

const trackingSlice = createSlice({
  name: "tracking",
  initialState,
  reducers: {
    clearTrackingData(state) {
      state.data = null;
      state.error = null;
      state.loading = false;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchtracking.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(
        fetchtracking.fulfilled,
        (state, action: PayloadAction<TrackingResponse>) => {
          state.loading = false;
          state.data = action.payload;
        }
      )
      .addCase(fetchtracking.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload ?? "Failed to fetch tracking data";
      })
      .addCase(fetchtrackingCredits.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchtrackingCredits.fulfilled, (state, action) => {
        state.loading = false;
        state.result = action.payload.result;
      })
      .addCase(fetchtrackingCredits.rejected, (state, action) => {
        state.loading = false;
        const payload = action.payload as any;
        state.error = payload?.result ?? "Failed to fetch tracking charges";
      });
  },
});

export const { clearTrackingData } = trackingSlice.actions;

export default trackingSlice.reducer;
