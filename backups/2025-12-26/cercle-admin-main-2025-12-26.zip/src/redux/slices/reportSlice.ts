import { createSlice } from "@reduxjs/toolkit";
import { Pagination } from "./orderSlice";
import { fetchReports, deleteReport, updateReportStatus, getReportsById } from "../thunks/reportThunk";
import { Report } from "../../types/pages/types";

interface ReportsState {
    status: string | number | any;
    message: string;
    pagination: Pagination | any;
    reports: Report[];
    error: string;
    detailedReports: Report[];
    detailedReportsPagination: Pagination | any;
    detailedReportsStatus: string;
}

const initialState: ReportsState = {
    status: "",
    message: "",
    pagination: null,
    reports: [],
    error: "",
    detailedReports: [],
    detailedReportsPagination: null,
    detailedReportsStatus: "idle",
};

const reportsSlice = createSlice({
    name: "reports",
    initialState,
    reducers: {},
    extraReducers: (builder) => {
        builder
            .addCase(fetchReports.pending, (state) => {
                state.status = null;
                state.message = "";
                state.pagination = null;
                state.reports = [];
                state.error = "";
            })
            .addCase(fetchReports.fulfilled, (state, action) => {
                state.status = action.payload?.status;
                state.message = action.payload?.message;
                state.pagination = action.payload?.pagination;
                state.reports = action.payload?.reports;
                if (action.payload?.status === 400) {
                    state.error =
                        typeof action.payload === "string"
                            ? action.payload
                            : JSON.stringify(action.payload) || "";
                }
                console.log("testing data", state.reports);
            })
            .addCase(fetchReports.rejected, (state, action) => {
                state.error = action.payload as string;
            })
            .addCase(updateReportStatus.pending, (state) => {
                state.status = "loading";
            })
            .addCase(updateReportStatus.fulfilled, (state, action) => {
                state.status = "succeeded";
                // Update the report status in the array
                const reportId = action.meta.arg.id;
                const newStatus = action.meta.arg.status;
                const reportIndex = state.reports.findIndex(r => r.report_id === reportId);
                if (reportIndex !== -1) {
                    state.reports[reportIndex].reported_status = newStatus;
                }
            })
            .addCase(updateReportStatus.rejected, (state, action) => {
                state.status = "failed";
                state.error = action.payload as string;
            })
            .addCase(deleteReport.pending, (state) => {
                state.status = "loading";
            })
            .addCase(deleteReport.fulfilled, (state, action) => {
                state.status = "succeeded";
                // Remove the deleted report from the array
                // The action.meta.arg contains the original arguments passed to the thunk
                const deletedId = action.meta.arg.id;
                state.reports = state.reports.filter(report => report.report_id !== deletedId);
            })
            .addCase(deleteReport.rejected, (state, action) => {
                state.status = "failed";
                state.error = action.payload as string;
            })
            .addCase(getReportsById.pending, (state) => {
                state.detailedReportsStatus = "loading";
                state.detailedReports = [];
            })
            .addCase(getReportsById.fulfilled, (state, action) => {
                state.detailedReportsStatus = "succeeded";
                state.detailedReports = action.payload?.reports || [];
                state.detailedReportsPagination = action.payload?.pagination;
            })
            .addCase(getReportsById.rejected, (state, action) => {
                state.detailedReportsStatus = "failed";
                state.error = action.payload as string;
            });
    },
});

export default reportsSlice.reducer;
