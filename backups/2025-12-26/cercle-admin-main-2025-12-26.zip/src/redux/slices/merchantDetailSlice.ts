import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { fetchmerchantdetail } from "../thunks/merchantThunks";

export interface Product {
  product_id: number;
  product_name: string;
  product_image_url: string;
  product_description: string;
}

export interface MerchantDetailResponse {
  merchantDetails: any[];
  ordersCount: any;
  totalPages: number | string;
  totalCount: number | string;
  variantPrice: number | string;
  orderTotalPrice: number | string;
  orderTotalAfterRate: number | string;
  orderTotalDeducted: number | string;
  status: number | string;
  message: string;
  error: string | null;
}

const initialState: MerchantDetailResponse = {
  merchantDetails: [],
  ordersCount: 0,
  status: "",
  totalPages: 0,
  variantPrice: 0,
  orderTotalPrice: 0,
  orderTotalAfterRate: 0,
  orderTotalDeducted: 0,
  totalCount: 0,
  message: "",
  error: null,
};

const merchantDetailSlice = createSlice({
  name: "merchantdetails",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchmerchantdetail.pending, (state) => {
        state.status = "loading";
        state.message = "";
        state.merchantDetails = [];
        state.error = null;
      })
      .addCase(
        fetchmerchantdetail.fulfilled,
        (state, action: PayloadAction<MerchantDetailResponse>) => {
          state.status = action.payload.status;
          state.merchantDetails = action.payload.merchantDetails;
          state.ordersCount = action.payload.ordersCount;
          state.orderTotalPrice = action.payload.orderTotalPrice;
          state.orderTotalAfterRate = action.payload.orderTotalAfterRate;
          state.orderTotalDeducted = action.payload.orderTotalDeducted;
          state.totalPages = action.payload.totalPages;
          state.totalCount = action.payload.totalCount;
          state.message = action.payload.message || "";
          state.error = null;
        }
      )

      .addCase(fetchmerchantdetail.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.payload as string;
      });
  },
});

export default merchantDetailSlice.reducer;
