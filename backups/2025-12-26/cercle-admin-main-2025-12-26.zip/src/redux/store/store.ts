import { configureStore } from "@reduxjs/toolkit";
import authReducer from "../slices/authSlice";
import { persistStore, persistReducer } from "redux-persist";
import storage from "redux-persist/lib/storage";
import { combineReducers } from "redux";
import authRreducer from "../slices/RegisterSlice";
import resetreducer from "../slices/ResetpasswordSlice";
import orderReducer from "../slices/orderSlice";
import merchantReducer from "../slices/merchantSlice";
import userReducer from "../slices/userSlice";
import planReducer from "../slices/plansSlice";
import planstateReducer from "../slices/planReducer";
import collectionReducer from "../slices/collectionSlice";
import merchantdetailReducer from "../slices/merchantDetailSlice";
import trackingReducer from "../slices/trackingSlice";
import notificationReducer from "../slices/notificationSlice";
import notificationDropdownReducer from "../slices/notificationDropdownSlice";
import dashboardReducer from "../slices/dashboardSlice";
import reviewReducer from "../slices/reviewSlice";
import reportReducer from "../slices/reportSlice";

const rootReducer = combineReducers({
  auth: authReducer,
  authRegister: authRreducer,
  authReset: resetreducer,
  orders: orderReducer,
  merchants: merchantReducer,
  users: userReducer,
  plans: planReducer,
  planstate: planstateReducer,
  collections: collectionReducer,
  merchantdetails: merchantdetailReducer,
  tracking: trackingReducer,
  notification: notificationReducer,
  notificationDropdown: notificationDropdownReducer,
  productReviews: reviewReducer,
  dashboard: dashboardReducer,
  reports: reportReducer,
});

const persistConfig = {
  key: "root",
  storage,
  whitelist: ["auth"],
};

const persistedReducer = persistReducer(persistConfig, rootReducer);

export const store = configureStore({
  reducer: persistedReducer,
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      serializableCheck: false,
    }),
});

export const persistor = persistStore(store);

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;

export default store;
