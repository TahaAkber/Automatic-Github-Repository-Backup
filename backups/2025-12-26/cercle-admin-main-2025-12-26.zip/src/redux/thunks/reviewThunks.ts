import { createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";
import Cookies from "js-cookie";
import { appUrl } from "./authThunks";
import { ReviewsResponse } from "src/types/pages/types";
import { decryptToken } from "../../components/functions/encryption";

let decodedCryptoToken = "";

export const fetchReviews = createAsyncThunk<
  ReviewsResponse,
  { page: number; limit: number; search: string },
  { rejectValue: string }
>("reviews/fetch", async ({ page, limit, search }, { rejectWithValue }) => {
  decodedCryptoToken = decryptToken(Cookies.get("authToken") || "");

  try {
    const response = await axios.get(
      `${appUrl}/api/products/reviews?page=${page}&limit=${limit}&search=${search}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${decodedCryptoToken}`,
        },
      }
    );
    console.log("response", response.data);
    return response.data;
  } catch (error: any) {
    return rejectWithValue("Failed to fetch brands");
  }
});
