import { createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";
import Cookies from "js-cookie";
import { appUrl } from "./authThunks";
import { decryptToken } from "../../components/functions/encryption";

let decodedCryptoToken = "";

export const fetchDashboardTransactions = createAsyncThunk(
  "transactions/Card/fetch",
  async (_, { rejectWithValue }) => {
    decodedCryptoToken = decryptToken(Cookies.get("authToken") || "");
    console.log("token", decodedCryptoToken);
    try {
      const response = await axios.get(`${appUrl}/api/dashboard/transactions`, {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${decodedCryptoToken}`,
        },
      });
      console.log("respone of admin user", response)

      return response.data;
    } catch (error: any) {
      if (error.response?.data?.message) {
        return rejectWithValue(error.response.data.message);
      }

      return rejectWithValue(
        error.message || "Failed to fetch transaction Data"
      );
    }
  }
);

export const fetchDashboardShopProducts = createAsyncThunk(
  "shops/products",
  async (_, { rejectWithValue }) => {
    decodedCryptoToken = decryptToken(Cookies.get("authToken") || "");

    try {
      const response = await axios.get(
        `${appUrl}/api/dashboard/shop-products`,
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${decodedCryptoToken}`,
          },
        }
      );
      return response.data;
    } catch (error: any) {
      if (error.response?.data?.message) {
        return rejectWithValue(error.response.data.message);
      }

      return rejectWithValue(
        error.message || "Failed to fetch transaction Data"
      );
    }
  }
);

export const fetchDashboardShopOrderPrices = createAsyncThunk(
  "shops/prices",
  async (_, { rejectWithValue }) => {
    decodedCryptoToken = decryptToken(Cookies.get("authToken") || "");

    try {
      const response = await axios.get(`${appUrl}/api/dashboard/shop-prices`, {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${decodedCryptoToken}`,
        },
      });
      return response.data;
    } catch (error: any) {
      if (error.response?.data?.message) {
        return rejectWithValue(error.response.data.message);
      }

      return rejectWithValue(
        error.message || "Failed to fetch transaction Data"
      );
    }
  }
);

export const fetchBestSellerShop = createAsyncThunk(
  "best/seller",
  async (_, { rejectWithValue }) => {
    decodedCryptoToken = decryptToken(Cookies.get("authToken") || "");

    try {
      const response = await axios.get(`${appUrl}/api/dashboard/best-seller`, {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${decodedCryptoToken}`,
        },
      });
      return response.data;
    } catch (error: any) {
      if (error.response?.data?.message) {
        return rejectWithValue(error.response.data.message);
      }

      return rejectWithValue(
        error.message || "Failed to fetch transaction Data"
      );
    }
  }
);
