import { createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";
import Cookies from "js-cookie";
import { appUrl } from "./authThunks";
import { decryptToken } from "../../components/functions/encryption";

type Params = { limit?: number; search?: string };
let decodedCryptoToken = "";

export const fetchMerchantsDropdown = createAsyncThunk(
  "dropdown/fetchMerchants",
  async ({ limit = 10, search = "" }: Params, { rejectWithValue }) => {
    decodedCryptoToken = decryptToken(Cookies.get("authToken") || "");

    try {
      const res = await axios.get(`${appUrl}/api/merchant/dropdown`, {
        params: { limit, searchKeyword: search },
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${decodedCryptoToken}`,
        },
      });
      return res.data; // { status, message, merchants, pagination }
    } catch (e) {
      return rejectWithValue("Failed to fetch merchants");
    }
  }
);

// GET /api/products/lite  -> { products, pagination }
export const fetchProductsDropdown = createAsyncThunk(
  "dropdown/fetchProducts",
  async ({ limit = 10, search = "" }: Params, { rejectWithValue }) => {
    decodedCryptoToken = decryptToken(Cookies.get("authToken") || "");

    try {
      const res = await axios.get(`${appUrl}/api/products/dropdown`, {
        params: { limit, search },
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${decodedCryptoToken}`,
        },
      });
      return res.data; // { status, message, products, pagination }
    } catch (e) {
      return rejectWithValue("Failed to fetch products");
    }
  }
);
