import { createAsyncThunk } from "@reduxjs/toolkit";
import { appUrl } from "./authThunks";
import Cookies from "js-cookie";
import axios from "axios";
import { UserResponse } from "src/types/pages/types";
import { decryptToken } from "../../components/functions/encryption";

let decodedCryptoToken = "";
export const fetchadminUsers = createAsyncThunk<
  UserResponse,
  { page: number },
  { rejectValue: string }
>("user/fetch", async ({ page }, { rejectWithValue }) => {
  decodedCryptoToken = decryptToken(Cookies.get("authToken") || "");

  try {
    const response = await axios.get(
      `${appUrl}/api/users/all?page=${page}&limit=10`,
      {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${decodedCryptoToken}`,
        },
      }
    );

    console.log("response", response.data);
    return response.data;
  } catch (error: any) {
    return rejectWithValue("Failed to fetch users");
  }
});
