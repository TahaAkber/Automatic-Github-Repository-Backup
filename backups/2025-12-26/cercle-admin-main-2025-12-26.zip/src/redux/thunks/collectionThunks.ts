import { createAsyncThunk } from "@reduxjs/toolkit";
import Cookies from "js-cookie";
import { appUrl } from "./authThunks";
import axios from "axios";
import {
  CollectionResponse,
  CreateCollectionPayload,
  CreateCollectionResponse,
} from "src/types/pages/types";
import { decryptToken } from "../../components/functions/encryption";

let decodedCryptoToken = "";

export const fetchcollections = createAsyncThunk<
  CollectionResponse,
  { page: number },
  { rejectValue: string }
>("collections/fetch", async ({ page }, { rejectWithValue }) => {
  decodedCryptoToken = decryptToken(Cookies.get("authToken") || "");

  try {
    const response = await axios.get(
      `${appUrl}/api/collections/all?page=${page}&limit=10`,
      {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${decodedCryptoToken}`,
        },
      }
    );

    return response.data;
  } catch (error: any) {
    return rejectWithValue("Failed to fetch orders");
  }
});

export const fetchCollectionById = createAsyncThunk<
  CollectionResponse,
  { collection_id: number },
  { rejectValue: string }
>("collections/fetch/id", async ({ collection_id }, { rejectWithValue }) => {
  decodedCryptoToken = decryptToken(Cookies.get("authToken") || "");

  try {
    const response = await axios.get(
      `${appUrl}/api/collections/${collection_id}`,
      {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${decodedCryptoToken}`,
        },
      }
    );

    return response.data;
  } catch (error: any) {
    return rejectWithValue("Failed to fetch orders");
  }
});

export const createCollection = createAsyncThunk<
  CreateCollectionResponse, // ✅ response type
  CreateCollectionPayload // ✅ request payload type
>("collection/create", async (data, { rejectWithValue }) => {
  decodedCryptoToken = decryptToken(Cookies.get("authToken") || "");

  try {
    const response = await axios.post(
      `${appUrl}/api/collections/createcollection`,
      data,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${decodedCryptoToken}`,
        },
      }
    );

    return response.data;
  } catch (error: any) {
    return rejectWithValue("Failed to create collection");
  }
});

export const deleteCollection = createAsyncThunk<
  { success: string; message: string },
  { collectionId: string }
>("collection/delete", async ({ collectionId }, { rejectWithValue }) => {
  decodedCryptoToken = decryptToken(Cookies.get("authToken") || "");

  try {
    const response = await axios.post(
      `${appUrl}/api/collections/deleteTrendingCollection?trending_id=${collectionId}`,
      {}, // no body
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${decodedCryptoToken}`,
        },
      }
    );
    return response.data;
  } catch (error: any) {
    return rejectWithValue("Failed to delete collection");
  }
});

export const updateTrendingCollectionStatus = createAsyncThunk<
  { success: string; message: string },
  { trending_id: number; is_active: boolean }
>(
  "collection/status/update",
  async ({ trending_id, is_active }, { rejectWithValue }) => {
    decodedCryptoToken = decryptToken(Cookies.get("authToken") || "");

    try {
      const response = await axios.post(
        `${appUrl}/api/collections/updateTrendingStatus`,
        { trending_id, is_active },
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${decodedCryptoToken}`,
          },
        }
      );
      return response.data;
    } catch (error: any) {
      return rejectWithValue("Failed to update collection");
    }
  }
);

export const updateTrendingCollection = createAsyncThunk<
  { success: string; message: string },
  {
    collection_id: number;
    collection_Description: string;
    collection_image_url: string;
  }
>(
  "collection/update",
  async (
    { collection_id, collection_Description, collection_image_url },
    { rejectWithValue }
  ) => {
    decodedCryptoToken = decryptToken(Cookies.get("authToken") || "");

    try {
      const response = await axios.post(
        `${appUrl}/api/collections/updateTrendingCollection`,
        { collection_id, collection_Description, collection_image_url },
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${decodedCryptoToken}`,
          },
        }
      );
      return response.data;
    } catch (error: any) {
      return rejectWithValue("Failed to update collection");
    }
  }
);
