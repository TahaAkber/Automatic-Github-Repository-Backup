import { createAsyncThunk } from "@reduxjs/toolkit";
import { appUrl } from "./authThunks";
import Cookies from "js-cookie";
import axios from "axios";
import { MerchantDetailResponse } from "../slices/merchantDetailSlice";
import { brandsResponse, MerchantResponse } from "src/types/pages/types";
import { decryptToken } from "../../components/functions/encryption";

let decodedCryptoToken = "";

export const fetchMerchantProducts = createAsyncThunk<
  MerchantResponse,
  {
    page: number;
    limit?: number;
    shopId: Number;
    searchKeyword?: string;
    isActive?: boolean;
  },
  { rejectValue: string }
>(
  "merchants/products/fetch",
  async (
    { page, limit, shopId, searchKeyword = "", isActive },
    { rejectWithValue }
  ) => {
    decodedCryptoToken = decryptToken(Cookies.get("authToken") || "");
    try {
      const baseUrl = `${appUrl}/api/merchant/products?page=${page}&limit=${limit}&shopId=${shopId}&searchKeyword=${searchKeyword}`;

      const params = new URLSearchParams();

      if (isActive !== undefined) {
        params.append("isActive", isActive.toString());
      }

      const url = `${baseUrl}&${params.toString()}`;
      console.log("url", url);
      const response = await axios.get(url, {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${decodedCryptoToken}`,
        },
      });

      return response.data;
    } catch (error: any) {
      return rejectWithValue("Failed to fetch merchants");
    }
  }
);

export const approveBrand = createAsyncThunk<
  any,
  {
    brand_id: number;
    brand_status_is_approved: boolean;
    brand_note?: string;
    brand_approval_is_approved?: boolean;
    user_id: any;
  }
>(
  "brand/approve",
  async (
    {
      brand_id,
      brand_status_is_approved,
      brand_note,
      brand_approval_is_approved,
      user_id,
    },
    { rejectWithValue }
  ) => {
    decodedCryptoToken = decryptToken(Cookies.get("authToken") || "");
    try {

      const authToken = Cookies.get("authToken");

      if (!authToken) {
        throw new Error("No authentication token found");
      }
      const response = await axios.post(
        `${appUrl}/api/merchant/approve-brands`,
        {
          brand_id,
          brand_status_is_approved,
          brand_note,
          brand_approval_is_approved,
          user_id,
        },
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${decodedCryptoToken}`,
          },
        }
      );

      return response.data;
    } catch (error: any) {
      console.error("Update Error:", error.message);

      if (
        error.response &&
        error.response.data &&
        error.response.data.message
      ) {
        return rejectWithValue(error.response.data.message);
      }

      return rejectWithValue("Failed to approve brand");
    }
  }
);

export const fetchmerchants = createAsyncThunk<
  MerchantResponse,
  { page: number; searchKeyword?: string; limit?: number; status?: string },
  { rejectValue: string }
>(
  "merchants/fetch",
  async (
    { page, searchKeyword = "", limit = 15, status },
    { rejectWithValue }
  ) => {
    decodedCryptoToken = decryptToken(Cookies.get("authToken") || "");
    try {
      const baseUrl = `${appUrl}/api/merchant/all?page=${page}&limit=${limit}`;
      const params = new URLSearchParams();

      if (searchKeyword) {
        params.append("searchKeyword", searchKeyword);
      }

      // Map status to filters
      if (status === "active") {
        params.append("shop_is_active", "true");
        params.append("shop_delisted", "false");
      } else if (status === "delisted") {
        params.append("shop_is_active", "true");
        params.append("shop_delisted", "true");
      } else if (status === "unactive") {
        params.append("shop_is_active", "false");
      }

      const url = `${baseUrl}&${params.toString()}`;

      const response = await axios.get(url, {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${decodedCryptoToken}`,
        },
      });
      return response.data;
    } catch (error: any) {
      return rejectWithValue("Failed to fetch merchants");
    }
  }
);

export const fetchbrands = createAsyncThunk<
  brandsResponse,
  { page: number; limit: number; searchKeyword: string },
  { rejectValue: string }
>(
  "Brands/fetch",
  async ({ page, limit, searchKeyword }, { rejectWithValue }) => {
    decodedCryptoToken = decryptToken(Cookies.get("authToken") || "");

    try {
      const response = await axios.get(
        `${appUrl}/api/merchant/brands?page=${page}&limit=${limit}&searchKeyword=${searchKeyword}`,
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${decodedCryptoToken}`,
          },
        }
      );
      console.log("Response from api for merchants:", response.data);
      return response.data;
    } catch (error: any) {
      return rejectWithValue("Failed to fetch brands");
    }
  }
);

export const fetchmerchantdetail = createAsyncThunk<
  MerchantDetailResponse,
  { id: Number; page: Number }
>("merchant/fetch", async ({ id, page }, { rejectWithValue }) => {
  decodedCryptoToken = decryptToken(Cookies.get("authToken") || "");

  try {
    const response = await axios.get(
      `${appUrl}/api/merchant/details?id=${id}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${decodedCryptoToken}`,
        },
        params: {
          page: page,
          limit: 12,
        },
      }
    );

    console.log("responce od merchant", response)
    return response.data;
  } catch (error: any) {
    console.error("Fetch Error:", error.message);

    if (error.response && error.response.data && error.response.data.message) {
      return rejectWithValue(error.response.data.message);
    }

    return rejectWithValue("Failed to fetch merchant details");
  }
});

export const updateMerchant = createAsyncThunk<
  any,
  { id: number; isEnable: boolean }
>("merchant/update", async ({ id, isEnable }, { rejectWithValue }) => {
  decodedCryptoToken = decryptToken(Cookies.get("authToken") || "");

  try {
    const response = await axios.post(
      `${appUrl}/api/merchant/enable`,
      { id, isEnable },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${decodedCryptoToken}`,
        },
      }
    );

    return response.data;
  } catch (error: any) {
    console.error("Update Error:", error.message);

    if (error.response && error.response.data && error.response.data.message) {
      return rejectWithValue(error.response.data.message);
    }

    return rejectWithValue("Failed to update merchant");
  }
});

export const fetchBrandsRequest = createAsyncThunk<
  brandsResponse,
  {
    page: Number;
    limit: Number;
    onlyCount?: Boolean;
    brandRequestSearch?: string;
  }
>(
  "merchant/fetch",
  async (
    { page, limit, onlyCount, brandRequestSearch },
    { rejectWithValue }
  ) => {
    decodedCryptoToken = decryptToken(Cookies.get("authToken") || "");
    try {
      if (!decodedCryptoToken) {
        throw new Error("No authentication token found");
      }

      const response = await axios.get(
        `${appUrl}/api/merchant/request-brands`,
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${decodedCryptoToken}`,
          },
          params: {
            page: page,
            limit: limit,
            onlyCount,
            searchKeyword: brandRequestSearch,
          },
        }
      );

      console.log("response", response.data);

      return response.data;
    } catch (error: any) {
      console.error("Fetch Error:", error.message);

      if (
        error.response &&
        error.response.data &&
        error.response.data.message
      ) {
        return rejectWithValue(error.response.data.message);
      }

      return rejectWithValue("Failed to fetch brands requests");
    }
  }
);

export const fetchtiles = createAsyncThunk(
  "tiles/fetch",
  async (_, { rejectWithValue }) => {
    decodedCryptoToken = decryptToken(Cookies.get("authToken") || "");

    try {
      const response = await axios.get(`${appUrl}/api/merchant/tiles`, {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${decodedCryptoToken}`,
        },
      });
      return response.data;
    } catch (error: any) {
      console.error("Fetch Error:", error.message);

      if (
        error.response &&
        error.response.data &&
        error.response.data.message
      ) {
        return rejectWithValue(error.response.data.message);
      }

      return rejectWithValue("Failed to fetch brands requests");
    }
  }
);

export const updateTileThunk = createAsyncThunk(
  "tiles/update",
  async (data, { rejectWithValue }) => {
    const decodedCryptoToken = decryptToken(Cookies.get("authToken") || "");
    try {
      const response = await axios.post(
        `${appUrl}/api/merchant/tile-update`,
        data,
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${decodedCryptoToken}`,
          },
        }
      );
      return response.data;
    } catch (error: any) {
      console.error("Fetch Error:", error.message);
      return rejectWithValue(
        error.response?.data?.message || "Failed to update tile"
      );
    }
  }
);


export const updateBrandThunk = createAsyncThunk<
  any, // response type
  { brand_id: number; brand_name?: string; brand_need_desc: string; brand_logo_url: string }, // argument type
  { rejectValue: string }
>(
  "brands/update",
  async (data, { rejectWithValue }) => {
    const decodedCryptoToken = decryptToken(Cookies.get("authToken") || "");
    console.log("Payload sending to api:", data);
    try {
      const response = await axios.post(
        `${appUrl}/api/merchant/update-brands`,
        data,
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${decodedCryptoToken}`,
          },
        }
      );

      console.log("Response from api:", response.data);

      return response.data;
    } catch (error: any) {
      return rejectWithValue(
        error.response?.data?.message || "Failed to update brand"
      );
    }
  }
);

