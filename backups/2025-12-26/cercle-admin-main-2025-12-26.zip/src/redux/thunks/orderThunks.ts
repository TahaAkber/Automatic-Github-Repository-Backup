import { createAsyncThunk } from "@reduxjs/toolkit";
import { appUrl } from "./authThunks";
import Cookies from "js-cookie";
import axios from "axios";
import {
  CancelOrders,
  OrderdetailResponse,
  OrderResponse,
} from "src/types/pages/types";
import { decryptToken } from "../../components/functions/encryption";

let decodedCryptoToken = "";
export const fetchOrders = createAsyncThunk<
  OrderResponse,
  {
    page: number;
    limit?: number;
    fulfilementstatus?: string;
    shopName?: string;
  },
  { rejectValue: string }
>(
  "orders/fetch",
  async (
    { page, limit = 12, fulfilementstatus = "", shopName = "" },
    { rejectWithValue }
  ) => {
    decodedCryptoToken = decryptToken(Cookies.get("authToken") || "");

    try {
      const baseUrl = `${appUrl}/api/orders/all?page=${page}&limit=${limit}`;
      const params = new URLSearchParams();

      if (fulfilementstatus) {
        params.append("fulfilementstatus", fulfilementstatus);
      }

      if (shopName) {
        params.append("shopName", shopName);
      }

      const url = `${baseUrl}&${params.toString()}`;

      const response = await axios.get(url, {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${decodedCryptoToken}`,
        },
      });

      return response.data;
    } catch (error: any) {
      return rejectWithValue("Failed to fetch orders");
    }
  }
);

export const orderdetail = createAsyncThunk<
  OrderdetailResponse,
  { id: number },
  { rejectValue: string }
>("orderdetails/fetch", async ({ id }, { rejectWithValue }) => {
  decodedCryptoToken = decryptToken(Cookies.get("authToken") || "");

  try {
    const response = await axios.get(`${appUrl}/api/orders/orderdetail/${id}`, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${decodedCryptoToken}`,
      },
    });

    return response.data;
  } catch (error: any) {
    console.error("Fetch failed:", error);
    return rejectWithValue("Failed to fetch order details");
  }
});

export const cancelOrders = createAsyncThunk<
  CancelOrders,
  { page: number; limit: number; search?: string; order_cancelled_by?: string },
  { rejectValue: string }
>(
  "cancelOrders/fetch",
  async ({ page, limit, search, order_cancelled_by }, { rejectWithValue }) => {
    decodedCryptoToken = decryptToken(Cookies.get("authToken") || "");

    try {
      const response = await axios.get(`${appUrl}/api/orders/cancel-orders`, {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${decodedCryptoToken}`,
        },
        params: {
          page,
          limit,
          search,
          order_cancelled_by,
        },
      });
      console.log("response", response.data);
      return response.data;
    } catch (error: any) {
      console.error("Fetch failed:", error);
      return rejectWithValue("Failed to fetch cancel orders");
    }
  }
);
