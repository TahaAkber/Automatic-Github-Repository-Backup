import { createAsyncThunk } from "@reduxjs/toolkit";
import { appUrl } from "./authThunks";
import Cookies from "js-cookie";
import axios from "axios";
import {
  NotificationPayload,
  NotificationResponse,
} from "../../types/pages/types";
import { decryptToken } from "../../components/functions/encryption";

let decodedCryptoToken = "";

export const fetchNotifications = createAsyncThunk<
  NotificationResponse,
  { page: number; limit?: number },
  { rejectValue: string }
>("notifications/fetch", async ({ page, limit = 10 }, { rejectWithValue }) => {
  decodedCryptoToken = decryptToken(Cookies.get("authToken") || "");

  try {
    const response = await axios.get(
      `${appUrl}/api/notifications/inApp?page=${page}&limit=${limit}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${decodedCryptoToken}`,
        },
      }
    );
    return response.data;
  } catch (error: any) {
    return rejectWithValue("Failed to fetch notifications");
  }
});

// ---- DELETE Notification Thunk ----
export const deleteNotification = createAsyncThunk<
  { id: number; message: string },
  number,
  { rejectValue: string }
>("notifications/delete", async (notificationId, { rejectWithValue }) => {
  decodedCryptoToken = decryptToken(Cookies.get("authToken") || "");

  try {
    const response = await axios.delete(
      `${appUrl}/api/notifications/inApp/${notificationId}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${decodedCryptoToken}`,
        },
      }
    );
    return { id: notificationId, message: response.data.message };
  } catch (error: any) {
    return rejectWithValue("Failed to delete notification");
  }
});



export const createNotification = createAsyncThunk<
  { message: string; id: number }, // success return type
  NotificationPayload, // payload type (JSON object instead of FormData)
  { rejectValue: string } // reject value type
>("notifications/create", async (payload, { rejectWithValue }) => {
  decodedCryptoToken = decryptToken(Cookies.get("authToken") || "");

  try {
    const response = await axios.post(
      `${appUrl}/api/notifications/inApp`,
      payload,
      {
        headers: {
          "Content-Type": "application/json", // ✅ JSON instead of multipart
          Authorization: `Bearer ${decodedCryptoToken}`,
        },
      }
    );
    return { message: response.data.message, id: response.data.id };
  } catch (error: any) {
    return rejectWithValue("Failed to create notification");
  }
});

export const fetchScheduledNotifications = createAsyncThunk<
  NotificationResponse,
  { page: number; limit?: number },
  { rejectValue: string }
>(
  "notifications/fetchScheduled",
  async ({ page, limit = 10 }, { rejectWithValue }) => {
    decodedCryptoToken = decryptToken(Cookies.get("authToken") || "");

    try {
      const url = `${appUrl}/api/notifications/scheduled?page=${page}&limit=${limit}`;

      const response = await axios.get(url, {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${decodedCryptoToken}`,
        },
      });
      return response.data;
    } catch (error: any) {
      return rejectWithValue("Failed to fetch scheduled notifications");
    }
  }
);

export const toggleNotification = createAsyncThunk<
  { id: number; active: boolean; message: string },
  { id: number; active: boolean },
  { rejectValue: string }
>("notifications/toggle", async ({ id, active }, { rejectWithValue }) => {
  decodedCryptoToken = decryptToken(Cookies.get("authToken") || "");

  try {
    const response = await axios.put(
      `${appUrl}/api/notifications/inApp/${id}/active`,
      { active },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${Cookies.get("authToken")}`,
        },
      }
    );

    return {
      id,
      active: response.data.app_notification_active ?? active, // fallback
      message: response.data.message,
    };
  } catch (error: any) {
    return rejectWithValue("Failed to toggle notification");
  }
});
