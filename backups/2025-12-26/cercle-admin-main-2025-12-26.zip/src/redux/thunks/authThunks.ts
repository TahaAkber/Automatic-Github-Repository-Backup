import { createAsyncThunk } from "@reduxjs/toolkit";
import axios, { AxiosError } from "axios";
import Cookies from "js-cookie";
import { decodeAndVerifyJWT } from "../../components/functions/JwtDecode";
import {
  AuthResponse,
  LoginCredentials,
  RegisterCredentials,
  RegisterResponse,
  ForgotPasswordResponse,
} from "../../../src/types/pages/types";
import { encryptToken } from "../../components/functions/encryption";

export const appUrl = import.meta.env.VITE_APP_URL;


interface ResetResponse {
  message: string;
  status: string | number | any;
}

function parseExpiresIn(expiresIn: string): number {
  const timeValue = parseInt(expiresIn);
  const timeUnit = expiresIn.replace(/[0-9]/g, "").toLowerCase();

  switch (timeUnit) {
    case "s":
      return timeValue;
    case "m":
      return timeValue * 60;
    case "h":
      return timeValue * 3600;
    case "d":
      return timeValue * 86400;
    default:
      return 3600;
  }
}

export const loginUser = createAsyncThunk<
  AuthResponse,
  LoginCredentials,
  { rejectValue: string }
>("auth/loginUser", async ({ email, password }, { rejectWithValue }) => {
  try {
    const response = await axios.post(`${appUrl}/api/auth/login`, {
      email,
      password,
    });

    const token = response.data.token;

    const encodedToken = encryptToken(token);

    const expiresInSeconds = parseExpiresIn(response.data.expiresIn || "1h");

    const status = response.data.status;

    if (token) {
      Cookies.set("authToken", encodedToken, {
        expires: expiresInSeconds / 86400,
      });
    }

    const decodedData = await decodeAndVerifyJWT(token);

    let isValidToken = false;

    try {
      if (expiresInSeconds / 86400) {
        isValidToken = true;
      } else {
        isValidToken = false;
      }
    } catch (error) {
      console.error("Invalid token:", error);
    }
    return { user: decodedData, isValidToken, encodedToken, status };
  } catch (error) {
    const err = error as AxiosError;
    return rejectWithValue((err.response?.data as string) || err.message);
  }
});

export const registerUser = createAsyncThunk<
  RegisterResponse,
  RegisterCredentials,
  { rejectValue: string }
>("auth/registerUser", async (formData, { rejectWithValue }) => {
  try {
    const response = await axios.post<RegisterResponse>(
      `${appUrl}/api/auth/register`,
      formData
    );


    if (response.data.status === 200) {
      return response.data;
    } else {
      return rejectWithValue(response.data.message || "Registration failed.");
    }
  } catch (error) {
    const err = error as AxiosError<{ message: string }>;
    return rejectWithValue(err.response?.data.message || err.message);
  }
});

export const resetpassword = createAsyncThunk<
  ResetResponse,
  { email: string; oldPassword: string; newPassword: string,otpToken:string },
  { rejectValue: string }
>("auth/reset-password", async (formData, { rejectWithValue }) => {
  try {
    const response = await axios.post(
      `${appUrl}/api/auth/reset-password`,
      formData
    );

    if (response.data.status === 200) {
      return response.data;
    } else {
      return rejectWithValue(
        response.data.message || "failed to reset password"
      );
    }
  } catch (error) {
    console.error("Password reset failed:", error);
    return rejectWithValue("An error occurred while resetting the password.");
  }
});

export const forgotPassword = createAsyncThunk<
  ForgotPasswordResponse,
  { email: string },
  { rejectValue: string }
>("auth/forgot-password", async (formData, { rejectWithValue }) => {
  try {
    console.log("Forgot Password Thunk - appUrl:", appUrl);
    console.log("Forgot Password Thunk - Full URL:", `${appUrl}/api/auth/forgot-password`);
    console.log("Forgot Password Thunk - formData:", formData);

    const response = await axios.post(
      `${appUrl}/api/auth/forgot-password`,
      formData
    );

    if (response.data.status === 200) {
      return response.data;
    } else {
      return rejectWithValue(response.data.message || "failed to send reset link");
    }
  } catch (error) {
    console.error("Failed to send reset link:", error);
    return rejectWithValue("An error occurred while sending the reset link.");
  }
});


