import { createAsyncThunk } from "@reduxjs/toolkit";
import Cookies from "js-cookie";
import { appUrl } from "./authThunks";
import axios from "axios";
import { TrackingResponse } from "src/types/pages/types";
import { decryptToken } from "../../components/functions/encryption";

let decodedCryptoToken = "";

export const fetchtracking = createAsyncThunk<
  TrackingResponse,
  { id: number },
  { rejectValue: string }
>("tracking/fetch", async ({ id }, { rejectWithValue }) => {
  decodedCryptoToken = decryptToken(Cookies.get("authToken") || "");

  try {
    const response = await axios.get(
      `${appUrl}/api/tracking/details?trackingId=${id}`,
      {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${decodedCryptoToken}`,
        },
      }
    );

    console.log("response", response.data);
    return response.data;
  } catch (error: any) {
    return rejectWithValue("Failed to fetch tracking");
  }
});

export const fetchtrackingCredits = createAsyncThunk<
  { message: string; result: any; status: number },
  void,
  { rejectValue: string }
>("tracking/charges", async (_, { rejectWithValue }) => {
  const decodedCryptoToken = decryptToken(Cookies.get("authToken") || "");

  try {
    const response = await axios.get(
      `${appUrl}/api/tracking/admin-charges`,
      {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${decodedCryptoToken}`,
        },
      }
    );
    console.log("reels and bundles resoince", response)

    return response.data;
  } catch (error: any) {
    return rejectWithValue("Failed to fetch tracking");
  }
});

export const updateTrackingCredits = createAsyncThunk<
  { message: string; status: number },
  { id: number; tracking_charges?: number, reelNstory_charges?: number },
  { rejectValue: string }
>("update/tracking/charges", async ({ id, tracking_charges, reelNstory_charges }, { rejectWithValue }) => {
  const decodedCryptoToken = decryptToken(Cookies.get("authToken") || "");
  try {
    console.log("update tracking charges", reelNstory_charges, id)
    const response = await axios.post(
      `${appUrl}/api/tracking/update-charges`,
      { id, tracking_charges, reelNstory_charges },
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${decodedCryptoToken}`,
        },
      }
    );
    console.log("reel and bundle update", response)
    return response.data;
  } catch (error: any) {
    return rejectWithValue("Failed to fetch tracking");
  }
});
