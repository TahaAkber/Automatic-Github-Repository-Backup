import { createAsyncThunk } from "@reduxjs/toolkit";
import { appUrl } from "./authThunks";
import Cookies from "js-cookie";
import axios from "axios";
import {

    ReportsResponse,
} from "src/types/pages/types";
import { decryptToken } from "../../components/functions/encryption";

let decodedCryptoToken = "";

export const fetchReports = createAsyncThunk<
    ReportsResponse,
    { page: number; limit: number; search: string; status: string; reported_type: string },
    { rejectValue: string }
>("reports/fetch", async ({ page, limit, search, status, reported_type }, { rejectWithValue }) => {
    decodedCryptoToken = decryptToken(Cookies.get("authToken") || "");

    try {
        const response = await axios.get(
            `${appUrl}/api/reports/all?page=${page}&limit=${limit}&search=${search}&statusFilter=${status}&typeFilter=${reported_type}`,
            {
                method: "GET",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${decodedCryptoToken}`,
                },
            }
        );

        console.log("response", response.data);
        return response.data;
    } catch (error: any) {
        return rejectWithValue("Failed to fetch reports");
    }
});

export const updateReportStatus = createAsyncThunk<
    { message: string; status: number; decisionId?: number },
    { id: number; status: string; decision_description?: string; decision_result?: string },
    { rejectValue: string }
>("reports/updateStatus", async ({ id, status, decision_description, decision_result }, { rejectWithValue }) => {
    decodedCryptoToken = decryptToken(Cookies.get("authToken") || "");

    try {
        const payload: any = { status };

        // Add decision fields if provided
        if (decision_description) payload.decision_description = decision_description;
        if (decision_result) payload.decision_result = decision_result;

        const response = await axios.put(
            `${appUrl}/api/reports/updateStatus/${id}`,
            payload,
            {
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${decodedCryptoToken}`,
                },
            }
        );

        console.log("updateReportStatus response:", response.data);
        return response.data;
    } catch (error: any) {
        return rejectWithValue(error.response?.data?.message || "Failed to update report status");
    }
});

export const deleteReport = createAsyncThunk<
    { message: string; status: number },
    { id: number },
    { rejectValue: string }
>("reports/delete", async ({ id }, { rejectWithValue }) => {
    decodedCryptoToken = decryptToken(Cookies.get("authToken") || "");

    try {
        const response = await axios.delete(
            `${appUrl}/api/reports/deleteReport/${id}`,
            {
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${decodedCryptoToken}`,
                },
            }
        );

        console.log("deleteReport response:", response.data);
        return response.data;
    } catch (error: any) {
        return rejectWithValue(error.response?.data?.message || "Failed to delete report");
    }
});

export const getReportsById = createAsyncThunk<
    ReportsResponse,
    {
        reported_reference_id?: string;
        reported_type?: string;
        reported_product_id?: string;
        reported_shop_id?: string;
        limit?: number;
        page?: number;
    },
    { rejectValue: string }
>(
    "reports/getById",
    async (
        {
            reported_reference_id = "",
            reported_type = "",
            reported_product_id = "",
            reported_shop_id = "",
            limit = 10,
            page = 1,
        },
        { rejectWithValue }
    ) => {
        decodedCryptoToken = decryptToken(Cookies.get("authToken") || "");

        try {
            const params = new URLSearchParams({
                reported_reference_id,
                reported_type,
                reported_product_id,
                reported_shop_id,
                limit: limit.toString(),
                page: page.toString(),
            });

            const response = await axios.get(
                `${appUrl}/api/reports/get-report?${params.toString()}`,
                {
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${decodedCryptoToken}`,
                    },
                }
            );

            console.log("getReportsById response:", response.data);
            return response.data;
        } catch (error: any) {
            return rejectWithValue(
                error.response?.data?.message || "Failed to fetch reports by ID"
            );
        }
    }
);
