import { createAsyncThunk } from "@reduxjs/toolkit";
import { appUrl } from "./authThunks";
import Cookies from "js-cookie";
import axios from "axios";
import {
  CreatePlanRequest,
  Planresult,
  PlansResponse,
} from "src/types/pages/types";
import { decryptToken } from "../../components/functions/encryption";

let decodedCryptoToken = "";

export const fetchplans = createAsyncThunk<
  PlansResponse,
  { page: number },
  { rejectValue: string }
>("plans/fetch", async ({ page }, { rejectWithValue }) => {
  decodedCryptoToken = decryptToken(Cookies.get("authToken") || "");

  try {
    const response = await axios.get(
      `${appUrl}/api/plans/all?page=${page}&limit=10`,
      {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${decodedCryptoToken}`,
        },
      }
    );

    console.log("response", response.data);
    return response.data;
  } catch (error: any) {
    return rejectWithValue("Failed to fetch plans");
  }
});

export const createplan = createAsyncThunk<
  Planresult,
  CreatePlanRequest,
  { rejectValue: string }
>("plans/create", async (data: CreatePlanRequest, { rejectWithValue }) => {
  decodedCryptoToken = decryptToken(Cookies.get("authToken") || "");

  try {
    const response = await axios.post(`${appUrl}/api/plans/createplan`, data, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${decodedCryptoToken}`,
      },
    });

    console.log("response", response.data);
    return response.data;
  } catch (error: any) {
    console.error("Error:", error);
    return rejectWithValue("Failed to create plan");
  }
});

export const updateplan = createAsyncThunk<
  Planresult,
  { CreateUpdateRequest: CreatePlanRequest; id: number },
  { rejectValue: string }
>("plans/update", async ({ CreateUpdateRequest, id }, { rejectWithValue }) => {
  decodedCryptoToken = decryptToken(Cookies.get("authToken") || "");
  console.log("seeing data",CreateUpdateRequest )
  console.log("seeing data id",id )
  try {
    const response = await axios.put(
      `${appUrl}/api/plans/updateplan/${id}`,
      CreateUpdateRequest,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${decodedCryptoToken}`,
        },
      }
    );

    console.log("response of update plan", response.data);
    return response.data;
  } catch (error: any) {
    console.error("Error:", error);
    return rejectWithValue("Failed to update plan");
  }
});

export const deleteplan = createAsyncThunk<
  undefined,
  { id: number },
  { rejectValue: string }
>("plans/delete", async ({ id }, { rejectWithValue }) => {
  decodedCryptoToken = decryptToken(Cookies.get("authToken") || "");

  try {
    const response = await axios.delete(
      `${appUrl}/api/plans/deleteplan/${id}`,
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${decodedCryptoToken}`,
        },
      }
    );

    console.log("response", response.data);
    return response.data;
  } catch (error: any) {
    console.error("Error:", error);
    return rejectWithValue("Failed to delete plan");
  }
});
