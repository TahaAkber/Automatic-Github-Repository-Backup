export const setSelectedPlan = (plan: any) => ({
  type: "SET_SELECTED_PLAN",
  payload: plan,
});
