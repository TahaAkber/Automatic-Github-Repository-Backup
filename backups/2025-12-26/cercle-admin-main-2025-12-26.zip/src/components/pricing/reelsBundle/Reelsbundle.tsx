import { useAppDispatch } from "../../../components/hooks/hooks";
import { useEffect, useState } from "react";
import {
  fetchtrackingCredits,
  updateTrackingCredits,
} from "../../../../src/redux/thunks/trackingThunks";
import { useSelector } from "react-redux";
import Parentstyle from "../../../components/Style/Parentstyle";
import Childstyle from "../../../components/Style/childstyle";
import {
  Typography,
  TextField,
  Button,
  CircularProgress,
  Snackbar,
  Alert,
} from "@mui/material";
// import EditIcon from "@mui/icons-material/Edit";
import SaveIcon from "@mui/icons-material/Save";
import EditIcon from "@mui/icons-material/Edit";
import CancelIcon from "@mui/icons-material/Cancel";
import { RoleLike } from "../../functions/Roles";
import { useRolePermissions } from "../../functions/useRolePermissions";
import AccessDenied from "../../merchant/Accessdenied";

const Reelsbundle = () => {
  const dispatch = useAppDispatch();
  const [isEditing, setIsEditing] = useState(false);
  const [editReels, setEditReels] = useState("");
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: "",
    severity: "success" as "success" | "error",
  });

  useEffect(() => {
    dispatch(fetchtrackingCredits());
  }, [dispatch]);
  console.log("reels and bundles  ", fetchtrackingCredits);
  const { state, error, result } = useSelector((state: any) => state.tracking);

    useEffect(() => {
        if (result?.admin_reelNstory_charges) {
            setEditReels(result?.admin_reelNstory_charges ?? "");
        }
    }, [result]);

  const handleEdit = () => {
    setIsEditing(true);
  };

    const handleCancel = () => {
        setIsEditing(false);
        setEditReels(result?.admin_reelNstory_charges ?? "");
    };

  const handleSave = async () => {
    try {
      const updatedData = await dispatch(
        updateTrackingCredits({
          id: result?.admin_setting_id,
          reelNstory_charges: parseFloat(editReels),
          // story_charges: parseFloat(editStories),
          // tracking_charges: result?.tracking_charges ?? 0,   // not using here
        })
      );

      if (updateTrackingCredits.rejected.match(updatedData)) {
        setSnackbar({
          open: true,
          message: "Failed to update tracking charges",
          severity: "error",
        });
        return;
      } else {
        setSnackbar({
          open: true,
          message: "Tracking charges updated successfully!",
          severity: "success",
        });
        setIsEditing(false);
      }

      dispatch(fetchtrackingCredits());
    } catch (err) {
      setSnackbar({
        open: true,
        message: "Failed to update tracking charges",
        severity: "error",
      });
    }
  };

  const handleCloseSnackbar = () => {
    setSnackbar({ ...snackbar, open: false });
  };

  const rawRoles = useSelector((s: any) => s.auth.user?.roles) as
    | RoleLike[]
    | undefined;
  const { can } = useRolePermissions(rawRoles);
  const canWrite = can("plans", "write");
  const canRead = can("plans", "read");
  if (!canRead) {
    return (
      <AccessDenied
        subtitle="Your account is missing read permissions for merchant. Contact an admin if you need access."
        secondaryActionText="Contact admin"
        onSecondaryAction={() => {
          // open your support modal / route / mailto
          // e.g., navigate("/support") or open a dialog
          window.open("https://cymbiote.com/contact-us/", "_blank");
        }}
      />
    );
  }

  return (
    <Parentstyle>
      <Childstyle>
        <div className="space-y-6">
          {/* Header Section */}
          <div className="flex justify-between items-center pb-4 border-b-2 border-gray-200">
            <div>
              <h1 className="text-3xl font-bold text-gray-800 mb-1">
                Reels and Stories Bundle
              </h1>
              <p className="text-sm text-gray-500">
                Manage your Reels and bundle subscription charges
              </p>
            </div>
            {!isEditing && (
              <Button
                variant="contained"
                startIcon={<EditIcon />}
                onClick={handleEdit}
                sx={{
                  background: "#2E7DC1",
                }}
                disabled={!canWrite}
              >
                Edit Charges
              </Button>
            )}
          </div>

          {/* Content Section */}
          {state === "loading" ? (
            <div className="flex justify-center items-center py-12">
              <CircularProgress />
            </div>
          ) : error ? (
            <div className="bg-red-50 border border-red-200 rounded-lg p-6">
              <Typography color="error" className="font-semibold">
                Error: {error}
              </Typography>
            </div>
          ) : (
            <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-xl p-8 shadow-md">
              <div className="space-y-4">
                <Typography
                  variant="h6"
                  className="text-gray-700 font-semibold flex items-center gap-2"
                >
                  <span className="w-2 h-2 bg-blue-500 rounded-full"></span>
                  Reels and Stories Bundle Charges
                </Typography>

                {isEditing ? (
                  <div className="flex flex-col gap-4 mt-4">
                    <TextField
                      fullWidth
                      label="Reels And Stories Sub Charges"
                      value={editReels}
                      onChange={(e) => setEditReels(e.target.value)}
                      variant="outlined"
                      type="number"
                      sx={{
                        backgroundColor: "white",
                        borderRadius: 2,
                        "& .MuiOutlinedInput-root": {
                          "&:hover fieldset": {
                            borderColor: "#2E7DC1",
                          },
                        },
                      }}
                    />
                    {/* <TextField
                                            fullWidth
                                            label="Stories Sub Charges"
                                            value={editStories}
                                            onChange={(e) => setEditStories(e.target.value)}
                                            variant="outlined"
                                            type="number"
                                            sx={{ backgroundColor: "white", borderRadius: 2 }}
                                        /> */}
                                        <div className="flex gap-3 w-1/2">
                                            <Button
                                                variant="contained"
                                                startIcon={<SaveIcon />}
                                                onClick={handleSave}
                                                sx={{
                                                    flex: 1,
                                                    background:
                                                        "linear-gradient(45deg, #2E7DC1 30%, #2E7DC1 90%)",
                                                    "&:hover": {
                                                        background:
                                                            "linear-gradient(45deg, #2E7DC1   30%, #2E7DC1  90%)",
                                                    },
                                                }}
                                            >
                                                Save Changes
                                            </Button>
                                            <Button
                                                variant="outlined"
                                                startIcon={<CancelIcon />}
                                                onClick={handleCancel}
                                                sx={{
                                                    flex: 1,
                                                    borderColor: "#f44336",
                                                    color: "#f44336",
                                                    "&:hover": {
                                                        borderColor: "#d32f2f",
                                                        backgroundColor: "rgba(244, 67, 54, 0.04)",
                                                    },
                                                }}
                                            >
                                                Cancel
                                            </Button>
                                        </div>
                                    </div>
                                ) : (
                                    <>
                                        <div className="bg-white rounded-lg p-6 shadow-sm border-l-4 border-blue-500">
                                            <div className="flex justify-between items-center">
                                                <Typography className="text-gray-600 font-medium">
                                                    Current Reels and Stories Bundle Charges:
                                                </Typography>
                                                <Typography
                                                    variant="h4"
                                                    className="font-bold text-blue-500"
                                                >
                                                    ${result?.admin_reelNstory_charges || "0.00"}
                                                </Typography>
                                            </div>
                                        </div>
                                        {/* <div className="bg-white rounded-lg p-6 shadow-sm border-l-4 border-blue-500">
                                            <div className="flex justify-between items-center">
                                                <Typography className="text-gray-600 font-medium">
                                                    Current Stories Charges:
                                                </Typography>
                                                <Typography
                                                    variant="h4"
                                                    className="font-bold text-blue-500"
                                                >
                                                    ${result?.admin_story_charges || "0.00"}
                                                </Typography>
                                            </div>
                                        </div> */}
                  </>
                )}
              </div>

              {/* Info Section */}
              {!isEditing && (
                <div className="mt-6 bg-blue-100 rounded-lg p-4 border border-blue-200">
                  <Typography className="text-sm text-blue-800">
                    <strong>Note:</strong> This charge applies to all Reels and
                    Stories subscriptions. Any changes will be reflected
                    immediately.
                  </Typography>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Snackbar for notifications */}
        <Snackbar
          open={snackbar.open}
          autoHideDuration={4000}
          onClose={handleCloseSnackbar}
          anchorOrigin={{ vertical: "top", horizontal: "right" }}
        >
          <Alert
            onClose={handleCloseSnackbar}
            severity={snackbar.severity}
            sx={{ width: "100%" }}
          >
            {snackbar.message}
          </Alert>
        </Snackbar>
      </Childstyle>
    </Parentstyle>
  );
};

export default Reelsbundle;
