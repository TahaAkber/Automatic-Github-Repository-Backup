import {
  IconButton,
  Tooltip,
  TextField,
  CircularProgress,
  Snackbar,
  Alert,
} from "@mui/material";
import { useSelector } from "react-redux";
import { RoleLike } from "../../functions/Roles";
import AccessDenied from "../../merchant/Accessdenied";
import { useRolePermissions } from "../../functions/useRolePermissions";
import DriveFileRenameOutlineOutlinedIcon from "@mui/icons-material/DriveFileRenameOutlineOutlined";
import CheckIcon from "@mui/icons-material/Check";
import CloseIcon from "@mui/icons-material/Close";
import { useEffect, useState } from "react";
import { useAppDispatch } from "../../../components/hooks/hooks";
import {
  fetchtiles,
  updateTileThunk,
} from "../../../../src/redux/thunks/merchantThunks";

interface Tile {
  tiles: any[];
  status: number;
  message: string;
  loading: boolean;
  canWrite: boolean;
}

const TilesTable = ({ tiles, canWrite }: Tile) => {
  const dispatch = useAppDispatch();
  const rawRoles = useSelector((state: any) => state.auth.user?.roles) as
    | RoleLike[]
    | undefined;
  const { can } = useRolePermissions(rawRoles);

  const [editRowId, setEditRowId] = useState<number | null>(null);
  const [editData, setEditData] = useState<any>({});
  const [isSaving, setIsSaving] = useState(false);

  const [snackbar, setSnackbar] = useState<{
    open: boolean;
    message: string;
    severity: "success" | "error" | "warning" | "info";
  }>({
    open: false,
    message: "",
    severity: "info",
  });

  const handleCloseSnackbar = () =>
    setSnackbar((prev) => ({ ...prev, open: false }));

  if (!can("plans", "read")) {
    return (
      <AccessDenied
        subtitle="Your account is missing read permissions for plans. Contact an admin if you need access."
        secondaryActionText="Contact admin"
        onSecondaryAction={() =>
          window.open("https://cymbiote.com/contact-us/", "_blank")
        }
      />
    );
  }

  const handleEditClick = (row: any) => {
    setEditRowId(row.shop_tile_id);
    setEditData({
      shop_tile_id: row.shop_tile_id,
      shop_tile_name: row.shop_tile_name,
      shop_tile_charges: row.shop_tile_charges,
    });
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setEditData((prev: any) => ({ ...prev, [name]: value }));
  };

  const handleSave = async () => {
    try {
      setIsSaving(true);

      if (!editData.shop_tile_name?.trim()) {
        setSnackbar({
          open: true,
          message: "Tile name cannot be empty.",
          severity: "warning",
        });
        setIsSaving(false);
        return;
      }

      if (
        editData.shop_tile_charges === "" ||
        isNaN(Number(editData.shop_tile_charges))
      ) {
        setSnackbar({
          open: true,
          message: "Please enter a valid numeric charge.",
          severity: "warning",
        });
        setIsSaving(false);
        return;
      }

      const response = await dispatch(updateTileThunk(editData)).unwrap();

      if (response?.status === 200) {
        setSnackbar({
          open: true,
          message: "Tile updated successfully!",
          severity: "success",
        });
      } else {
        setSnackbar({
          open: true,
          message: response?.message || "Failed to update tile.",
          severity: "error",
        });
      }

      await dispatch(fetchtiles());
    } catch (error: any) {
      console.error("Error while updating tile:", error);
      setSnackbar({
        open: true,
        message: error?.message || "Something went wrong. Please try again.",
        severity: "error",
      });
    } finally {
      setIsSaving(false);
      setEditRowId(null);
    }
  };

  const handleCancel = () => {
    setEditRowId(null);
    setEditData({});
  };

  useEffect(() => {
    dispatch(fetchtiles());
  }, [dispatch]);

  return (
    <>
      <div className="overflow-x-auto border border-gray-200 rounded-lg shadow-sm bg-white">
        <table className="min-w-full text-xs md:text-sm text-left">
          <thead className="bg-gray-50 border-b text-gray-500 font-semibold">
            <tr>
              <th className="px-4 md:px-6 py-3 whitespace-nowrap">Tile Name</th>
              <th className="px-4 md:px-6 py-3 whitespace-nowrap">
                Tile Description
              </th>
              <th className="px-4 md:px-6 py-3 whitespace-nowrap">Tile Type</th>
              <th className="px-4 md:px-6 py-3 whitespace-nowrap">
                Tile Charges
              </th>
              <th className="px-4 md:px-6 py-3 whitespace-nowrap text-center">
                Edit
              </th>
            </tr>
          </thead>
          <tbody>
            {tiles.map((row: any) => {
              const isEditing = editRowId === row.shop_tile_id;
              const isRowSaving = isSaving && isEditing;

              return (
                <tr
                  key={row.shop_tile_id}
                  className={`border-b last:border-none transition-colors duration-150 ${isEditing ? "bg-blue-50/70" : "hover:bg-gray-50"
                    }`}
                >
                  <td className="px-4 md:px-6 py-3 whitespace-nowrap max-w-xs md:max-w-sm overflow-hidden text-ellipsis">
                    {isEditing ? (
                      <TextField
                        name="shop_tile_name"
                        value={editData.shop_tile_name || ""}
                        onChange={handleChange}
                        size="small"
                        variant="outlined"
                      />
                    ) : (
                      <span className="font-medium text-gray-800">
                        {row.shop_tile_name || "No Package Name"}
                      </span>
                    )}
                  </td>

                  <td className="px-4 md:px-6 py-3 whitespace-nowrap max-w-xs md:max-w-md overflow-hidden text-ellipsis text-gray-700">
                    {row.shop_tile_description || "No Description"}
                  </td>

                  <td className="px-4 md:px-6 py-3 whitespace-nowrap text-gray-700">
                    {row.shop_tile_type}
                  </td>

                  <td className="px-4 md:px-6 py-3 whitespace-nowrap">
                    {isEditing ? (
                      <TextField
                        name="shop_tile_charges"
                        value={editData.shop_tile_charges ?? ""}
                        onChange={handleChange}
                        size="small"
                        type="number"
                        variant="outlined"
                        className="w-24 md:w-32"
                        inputProps={{ min: 0 }}
                      />
                    ) : (
                      <span className="text-gray-800">
                        ${row.shop_tile_charges}
                      </span>
                    )}
                  </td>

                  <td className="px-4 md:px-6 py-2 whitespace-nowrap">
                    <div className="flex items-center justify-center gap-1">
                      {isEditing ? (
                        isRowSaving ? (
                          <CircularProgress size={18} />
                        ) : (
                          <>
                            <Tooltip title="Save">
                              <span>
                                <IconButton
                                  size="small"
                                  onClick={handleSave}
                                  disabled={isRowSaving}
                                >
                                  <CheckIcon color="success" fontSize="small" />
                                </IconButton>
                              </span>
                            </Tooltip>
                            <Tooltip title="Cancel">
                              <IconButton
                                size="small"
                                onClick={handleCancel}
                                disabled={isRowSaving}
                              >
                                <CloseIcon color="error" fontSize="small" />
                              </IconButton>
                            </Tooltip>
                          </>
                        )
                      ) : (
                        <Tooltip title={!canWrite ? "No permission to edit" : "Edit"}>
                          <span
                            onClick={() => {
                              if (!canWrite) {
                                setSnackbar({
                                  open: true,
                                  message: "You do not have permission to edit this plan.",
                                  severity: "error",
                                });
                                return;
                              }
                              handleEditClick(row);
                            }}
                            style={{ display: "inline-flex" }}
                          >
                            <IconButton
                              size="small"
                              // onClick={() => handleEditClick(row)}
                              disabled={!canWrite}
                            >


                              <DriveFileRenameOutlineOutlinedIcon
                                fontSize="small"
                                color={canWrite ? "primary" : "disabled"}
                              />
                            </IconButton>
                          </span>
                        </Tooltip>
                      )}
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      <Snackbar
        open={snackbar.open}
        autoHideDuration={4000}
        onClose={handleCloseSnackbar}
        anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
      >
        <Alert
          onClose={handleCloseSnackbar}
          severity={snackbar.severity}
          sx={{ width: "100%" }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </>
  );
};

export default TilesTable;
