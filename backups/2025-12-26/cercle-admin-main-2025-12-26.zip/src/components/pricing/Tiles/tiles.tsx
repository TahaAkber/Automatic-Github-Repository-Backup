import { Card, Divider } from "@mui/material";
import React, { useEffect } from "react";
import Parentstyle from "../../Style/Parentstyle";
import Childstyle from "../../Style/childstyle";
import { useAppDispatch } from "../../hooks/hooks";

import TilesTable from "./TileTable";
import { fetchtiles } from "../../../../src/redux/thunks/merchantThunks";
import { useSelector } from "react-redux";
import { useRolePermissions } from "../../functions/useRolePermissions";
import { RoleLike } from "../../functions/Roles";
import AccessDenied from "../../merchant/Accessdenied";

const Tiles: React.FC = () => {
  const dispatch = useAppDispatch();

  useEffect(() => {
    dispatch(fetchtiles());
  }, [dispatch]);

  const { tiles, status, message, loading } = useSelector(
    (state: any) => state.merchants
  );
  const rawRoles = useSelector((s: any) => s.auth.user?.roles) as
    | RoleLike[]
    | undefined;
  const { can } = useRolePermissions(rawRoles);
  const canWrite = can("plans", "write");
  const canRead = can("plans", "read");
  if (!canRead) {
    return (
      <AccessDenied
        subtitle="Your account is missing read permissions for merchant. Contact an admin if you need access."
        secondaryActionText="Contact admin"
        onSecondaryAction={() => {
          // open your support modal / route / mailto
          // e.g., navigate("/support") or open a dialog
          window.open("https://cymbiote.com/contact-us/", "_blank");
        }}
      />
    );
  }
  return (
    <Parentstyle>
      <Childstyle>
        <div className="flex justify-between pb-5">
          <h1 className="text-2xl font-semibold mb-2">Tiles</h1>

          {/* <Button
            variant="contained"
            size="small"
            onClick={() => {
              navigate("/plans/createplans");
            }}
            sx={{ fontWeight: 300, textTransform: "none" }}
          >
            Create Plans
          </Button> */}
        </div>
        <Card>
          <TilesTable
            tiles={tiles}
            status={status}
            message={message}
            loading={loading}
            canWrite={canWrite}
          />
          <Divider />
        </Card>
      </Childstyle>
    </Parentstyle>
  );
};

export default Tiles;
