import {
  Alert,
  Button,
  Card,
  Grid,
  MenuItem,
  TextField,
  Typography,
  CircularProgress,
} from "@mui/material";
import React, { useState } from "react";
import { useAppDispatch } from "../../hooks/hooks";
import { createplan } from "../../../redux/thunks/plansThunk";
import Parentstyle from "../../Style/Parentstyle";
import Childstyle from "../../Style/childstyle";

interface plans {
  package_name: string;
  package_rate: number;
  package_description: string;
  package_order_limit: number;
  package_limit_exceed_charges: number;
  package_trial_days: number | string;
  package_charges: number;
}

const CreatePlans: React.FC = () => {
  const [message, setmessage] = useState("");
  const [error, seterror] = useState("");
  const [loading, setLoading] = useState(false); // Loading state to control the spinner
  const [timeoutError, setTimeoutError] = useState(""); // Timeout error message
  const dispatch = useAppDispatch();

  const [planData, setPlanData] = useState<plans>({
    package_name: "",
    package_rate: 0,
    package_description: "",
    package_limit_exceed_charges: 0,
    package_order_limit: 0,
    package_trial_days: "",
    package_charges: 0,
  });

  const handleCreatePlan = async () => {
    setLoading(true);
    setTimeoutError("");

    const timeoutId = setTimeout(() => {
      setLoading(false);
      setTimeoutError("The request timed out. Please try again.");
    }, 10000);

    try {
      const result = await dispatch(
        createplan({
          package_name: planData.package_name,
          package_rate: planData.package_rate,
          package_description: planData.package_description,
          package_order_limit: planData.package_order_limit,
          package_limit_exceed_charges: planData.package_limit_exceed_charges,
          package_trial_days:
            typeof planData.package_trial_days === "string"
              ? parseFloat(planData.package_trial_days)
              : planData.package_trial_days,
          package_charges: planData.package_charges,
        })
      ).unwrap();

      console.log("Plan created successfully:", result);
      if (result.status === 200) {
        setmessage(result.message);
        seterror("");
        // Clear the form fields on successful submission
        setPlanData({
          package_name: "",
          package_rate: 0,
          package_description: "",
          package_limit_exceed_charges: 0,
          package_order_limit: 0,
          package_trial_days: "",
          package_charges: 0,
        });
      } else if (result.status === 400) {
        seterror(result.message);
        setmessage("");
      }
    } catch (error) {
      console.error("Error creating plan:", error);
      seterror("An error occurred while creating the plan. Please try again.");
      setmessage("");
    } finally {
      clearTimeout(timeoutId);
      setLoading(false); // Stop loading once the request is complete
    }
    console.log("Create Plan clicked:", planData);
  };

  return (
    <Parentstyle>
      <Childstyle>
        <Typography variant="h6" fontWeight="medium" className="pb-5">
          Create Plans
        </Typography>
        {message && (
          <Alert severity="success" sx={{ mb: 2 }}>
            {message}
          </Alert>
        )}
        {timeoutError && (
          <Alert severity="error" sx={{ mb: 2 }}>
            {timeoutError}
          </Alert>
        )}
        {error && (
          <Alert severity="error" sx={{ mb: 2 }}>
            {error}
          </Alert>
        )}
        <Card
          sx={{
            borderRadius: "12px",
            border: "1px solid #e0e0e0",
            boxShadow: 1,
          }}
        >
          <Grid container direction="column" spacing={2}>
            <Grid
              container
              spacing={0}
              alignItems="center"
              justifyContent="space-between"
              flexWrap="wrap"
              className="max-w-full"
            >
              <Grid size={{ xs: 12, md: 6 }} className="p-5">
                <TextField
                  id="Plan Name"
                  label="Plan Name"
                  variant="outlined"
                  autoComplete="off"
                  fullWidth
                  size="small"
                  value={planData.package_name}
                  onChange={(e) =>
                    setPlanData({ ...planData, package_name: e.target.value })
                  }
                />
              </Grid>

              <Grid size={{ xs: 12, md: 6 }} className="p-5">
                <TextField
                  id="Plan Rate"
                  label="Plan Rate"
                  variant="outlined"
                  autoComplete="off"
                  fullWidth
                  size="small"
                  type="number"
                  value={planData.package_rate}
                  onChange={(e) =>
                    setPlanData({
                      ...planData,
                      package_rate: parseFloat(e.target.value),
                    })
                  }
                />
              </Grid>
              <Grid size={{ xs: 12, md: 8, lg: 12 }} className="px-5">
                <div className="flex flex-col gap-5">
                  <TextField
                    id="Plan Description"
                    label="Plan Description..."
                    variant="outlined"
                    autoComplete="off"
                    fullWidth
                    size="small"
                    multiline
                    minRows={5}
                    value={planData.package_description}
                    onChange={(e) =>
                      setPlanData({
                        ...planData,
                        package_description: e.target.value,
                      })
                    }
                  />
                </div>
              </Grid>
              <Grid size={{ xs: 12, md: 6 }} className="p-5">
                <TextField
                  id="Order Limit"
                  label="Order Limit"
                  variant="outlined"
                  fullWidth
                  size="small"
                  autoComplete="off"
                  select
                  SelectProps={{
                    MenuProps: {
                      PaperProps: {
                        style: {
                          padding: "8px",
                        },
                      },
                    },
                  }}
                  value={planData.package_order_limit}
                  onChange={(e) =>
                    setPlanData({
                      ...planData,
                      package_order_limit: parseFloat(e.target.value),
                    })
                  }
                >
                  <MenuItem value="23" className="py-2">
                    23
                  </MenuItem>
                  <MenuItem value="250" className="py-2">
                    250
                  </MenuItem>
                  <MenuItem value="300" className="py-2">
                    300
                  </MenuItem>
                </TextField>
              </Grid>

              <Grid size={{ xs: 12, md: 6 }} className="px-5">
                <TextField
                  id="Order Limit Exceed Charges"
                  label="Order Limit Exceed Charges"
                  variant="outlined"
                  autoComplete="off"
                  type="number"
                  fullWidth
                  size="small"
                  value={planData.package_limit_exceed_charges}
                  onChange={(e) =>
                    setPlanData({
                      ...planData,
                      package_limit_exceed_charges: parseFloat(e.target.value),
                    })
                  }
                />
              </Grid>
              <Grid size={{ xs: 12, md: 6 }} className="px-5">
                <TextField
                  id="Plan Trial Days"
                  label="Plan Trial Days"
                  variant="outlined"
                  fullWidth
                  autoComplete="off"
                  size="small"
                  select
                  SelectProps={{
                    MenuProps: {
                      PaperProps: {
                        style: {
                          padding: "8px",
                        },
                      },
                    },
                  }}
                  value={planData.package_trial_days}
                  onChange={(e) =>
                    setPlanData({
                      ...planData,
                      package_trial_days: e.target.value,
                    })
                  }
                >
                  <MenuItem value="20" className="py-2">
                    20
                  </MenuItem>
                  <MenuItem value="40" className="py-2">
                    40
                  </MenuItem>
                  <MenuItem value="60" className="py-2">
                    60
                  </MenuItem>
                </TextField>
              </Grid>

              <Grid size={{ xs: 12, md: 6 }} className="px-5">
                <TextField
                  id="Plan Charges"
                  label="Plan Charges"
                  variant="outlined"
                  fullWidth
                  type="number"
                  autoComplete="off"
                  size="small"
                  value={planData.package_charges}
                  onChange={(e) =>
                    setPlanData({
                      ...planData,
                      package_charges: parseFloat(e.target.value),
                    })
                  }
                />
              </Grid>
            </Grid>

            {/* Create Plan Button with CircularProgress */}
            <div className="px-5 my-3">
              <Button
                variant="contained"
                size="small"
                color="primary"
                sx={{ fontWeight: 400 }}
                onClick={handleCreatePlan}
                disabled={loading}
              >
                {loading ? (
                  <CircularProgress size={24} sx={{ color: "white" }} />
                ) : (
                  "Create Plan"
                )}
              </Button>
            </div>
          </Grid>
        </Card>
      </Childstyle>
    </Parentstyle>
  );
};

export default CreatePlans;
