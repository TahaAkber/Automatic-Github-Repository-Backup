import {
  Alert,
  CircularProgress,
  IconButton,
  Snackbar,
  TextField,
  Tooltip,
} from "@mui/material";
import { useSelector } from "react-redux";
import { RoleLike } from "../../functions/Roles";
import AccessDenied from "../../merchant/Accessdenied";
import { useRolePermissions } from "../../functions/useRolePermissions";
import { useEffect, useState } from "react";
import CheckIcon from "@mui/icons-material/Check";
import CloseIcon from "@mui/icons-material/Close";
import DriveFileRenameOutlineOutlinedIcon from "@mui/icons-material/DriveFileRenameOutlineOutlined";
import { useAppDispatch } from "../../../components/hooks/hooks";
import { fetchplans, updateplan } from "../../../../src/redux/thunks/plansThunk";


const PlanTable = ({ canWrite }: { canWrite: boolean }) => {
  const { plansResult } = useSelector((state: any) => state.plans);
  const rawRoles = useSelector((state: any) => state.auth.user?.roles) as
    | RoleLike[]
    | undefined;
  const { can } = useRolePermissions(rawRoles);
  if (!can("plans", "read")) {
    return (
      <AccessDenied
        subtitle="Your account is missing read permissions for plans. Contact an admin if you need access."
        secondaryActionText="Contact admin"
        onSecondaryAction={() => {
          // open your support modal / route / mailto
          // e.g., navigate("/support") or open a dialog
          window.open("https://cymbiote.com/contact-us/", "_blank");
        }}
      />
    );
  }
  console.log("plan result", plansResult);

  const [editRowId, setEditRowId] = useState<number | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [editData, setEditData] = useState<any>({});
  const dispatch = useAppDispatch();
  const [snackbar, setSnackbar] = useState<{
    open: boolean;
    message: string;
    severity: "success" | "error" | "warning" | "info";
  }>({
    open: false,
    message: "",
    severity: "info",
  });

  const handleEditClick = (row: any) => {
    setEditRowId(row.package_id);
    setEditData({
      package_id: row.package_id,
      package_name: row.package_name,
      package_description: row.package_description,
      package_charges: row.package_charges,
      package_video_count: row.package_video_count,
      package_rate: row.package_rate,
      package_order_limit: row.package_order_limit,
      package_limit_exceed_charges: row.package_limit_exceed_charges,
      package_trial_days: row.package_trial_days,
    });
  };
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setEditData((prev: any) => ({ ...prev, [name]: value }));
  };
  const handleCancel = () => {
    setEditRowId(null);
    setEditData({});
  };

  const handleEditPlan = async () => {
    try {
      setIsSaving(true);

      if (!editData.package_description?.trim()) {
        setSnackbar({
          open: true,
          message: "plan description cannot be empty.",
          severity: "warning",
        });
        setIsSaving(false);
        return;
      }

      if (
        editData.package_charges === "" ||
        isNaN(Number(editData.package_charges))
      ) {
        setSnackbar({
          open: true,
          message: "Please enter a valid numeric charge.",
          severity: "warning",
        });
        setIsSaving(false);
        return;
      }

      const response = await dispatch(
        updateplan({
          CreateUpdateRequest: {
            package_name: editData.package_name,
            package_description: editData.package_description,
            package_charges: Number(editData.package_charges),
            package_video_count: Number(editData.package_video_count),

            package_rate: editData.package_rate,
            package_order_limit: editData.package_order_limit,
            package_limit_exceed_charges: editData.package_limit_exceed_charges,
            package_trial_days: editData.package_trial_days,
          },
          id: editData.package_id,
        })
      ).unwrap();

      if (response?.status === 200) {
        setSnackbar({
          open: true,
          message: "Plan updated successfully!",
          severity: "success",
        });
      } else {
        setSnackbar({
          open: true,
          message: response?.message || "Failed to update plan.",
          severity: "error",
        });
      }

      await dispatch(fetchplans({ page: 1 }));
    } catch (error: any) {
      console.error("Error while updating plan:", error);
      setSnackbar({
        open: true,
        message: error?.message || "Something went wrong. Please try again.",
        severity: "error",
      });
    } finally {
      setIsSaving(false);
      setEditRowId(null);
    }
  };

  useEffect(() => {
    dispatch(fetchplans({ page: 1 }));
  }, [dispatch]);

  const handleCloseSnackbar = () =>
    setSnackbar((prev) => ({ ...prev, open: false }));

  return (
    <>
      <div className="overflow-x-auto border-gray-200 rounded-lg shadow-sm">
        <table className="min-w-full text-sm text-left">
          <thead className="bg-gray-50 border-b text-gray-500 font-semibold">
            <tr>
              <th className="px-6 py-3 whitespace-nowrap">Plan Name</th>
              <th className="px-6 py-3 whitespace-nowrap">Plan Description</th>
              <th className="px-6 py-3 whitespace-nowrap">Plan Rate</th>
              <th className="px-6 py-3 whitespace-nowrap">Order Limit</th>
              <th className="px-6 py-3 whitespace-nowrap">Plan Charges</th>
              <th className="px-6 py-3 whitespace-nowrap">Reel Count</th>
              <th className="px-6 py-3 whitespace-nowrap">Trial Days</th>
              <th className="px-6 py-3 whitespace-nowrap">Odr Exceed Charges</th>
              <th className="px-6 py-3 whitespace-nowrap">Edit Plan</th>
              {/* <th className="px-6 py-3 whitespace-nowrap">Action</th> */}
            </tr>
          </thead>
          <tbody>
            {plansResult.map((row: any) => {
              const isEditing = editRowId === row.package_id;
              const isRowSaving = isSaving && isEditing;
              return (

                <tr key={row.package_id} className={`border-b last:border-none transition-colors duration-150 ${isEditing ? "bg-blue-50/70" : "hover:bg-gray-50"
                  }`}>
                  <Tooltip title={row.package_name} placement="top">
                    <td className="px-6 py-4 whitespace-nowrap max-w-xs overflow-hidden text-ellipsis cursor-pointer">
                      {row.package_name || "No Pakage Name"}
                    </td>
                  </Tooltip>
                  <Tooltip title={row.package_description} placement="top">
                    <td className="px-4 md:px-6 py-3 whitespace-nowrap max-w-xs md:max-w-sm overflow-hidden text-ellipsis ">
                      {
                        isEditing ? (
                          <TextField
                            name="package_description"
                            value={editData.package_description || ""}
                            onChange={handleChange}
                            size="small"
                            variant="outlined"
                          />
                        ) : (
                          <span className="font-medium text-gray-800">
                            {row.package_description || "No Pakage Description"}
                          </span>
                        )
                      }
                    </td>
                  </Tooltip>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {row.package_rate}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">

                    {row.package_order_limit}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {
                      isEditing ? (
                        <TextField
                          name="package_charges"
                          value={editData.package_charges ?? ""}
                          onChange={handleChange}
                          size="small"
                          type="number"
                          variant="outlined"
                          className="w-24 md:w-32"
                          inputProps={{ min: 0 }}
                        />
                      ) : (
                        <span className="font-medium text-gray-800">
                          ${row.package_charges}
                        </span>
                      )
                    }
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">

                    {
                      isEditing ? (
                        <TextField
                          name="package_video_count"
                          value={editData.package_video_count ?? ""}
                          onChange={handleChange}
                          size="small"
                          type="number"
                          variant="outlined"
                          className="w-24 md:w-32"
                          inputProps={{ min: 0 }}
                        />
                      ) : (
                        <span className="font-medium text-gray-800">
                          {row.package_video_count}
                        </span>
                      )
                    }
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {row.package_trial_days}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {row.package_limit_exceed_charges}
                  </td>
                  <td className="px-4 md:px-6 py-2 whitespace-nowrap">
                    <div className="flex items-center justify-center gap-1">
                      {isEditing ? (
                        isRowSaving ? (
                          <CircularProgress size={18} />
                        ) : (
                          <>
                            <Tooltip title="Save">
                              <span>
                                <IconButton
                                  size="small"
                                  onClick={handleEditPlan}
                                  disabled={isRowSaving}
                                >
                                  <CheckIcon color="success" fontSize="small" />
                                </IconButton>
                              </span>
                            </Tooltip>
                            <Tooltip title="Cancel">
                              <IconButton
                                size="small"
                                onClick={handleCancel}
                                disabled={isRowSaving}
                              >
                                <CloseIcon color="error" fontSize="small" />
                              </IconButton>
                            </Tooltip>
                          </>
                        )
                      ) : (
                        <Tooltip title={!canWrite ? "No permission to edit" : "Edit"}>
                          <span
                            onClick={() => {
                              if (!canWrite) {
                                setSnackbar({
                                  open: true,
                                  message: "You do not have permission to edit this plan.",
                                  severity: "error",
                                });
                                return;
                              }
                              handleEditClick(row);
                            }}
                            style={{ display: "inline-flex" }}
                          >
                            <IconButton
                              size="small"
                              disabled={!canWrite}
                            >
                              <DriveFileRenameOutlineOutlinedIcon
                                fontSize="small"
                                color={canWrite ? "primary" : "disabled"}
                              />
                            </IconButton>
                          </span>
                        </Tooltip>

                      )}
                    </div>
                  </td>






                  {/* <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center gap-2">
                    <Tooltip title="Edit">
                      <IconButton
                        size="small"
                        onClick={() => handleEditPlan(row)}
                      >
                        <DriveFileRenameOutlineOutlinedIcon
                          fontSize="small"
                          color="primary"
                        />
                      </IconButton>
                    </Tooltip>
                    <Tooltip title="Delete">
                      <IconButton size="small">
                        <DeleteIcon
                          fontSize="small"
                          color="error"
                          onClick={() => handledeleteplan(row.package_id)}
                        />
                      </IconButton>
                    </Tooltip>
                  </div>
                </td> */}






                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      <Snackbar
        open={snackbar.open}
        autoHideDuration={4000}
        onClose={handleCloseSnackbar}
        anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
      >
        <Alert
          onClose={handleCloseSnackbar}
          severity={snackbar.severity}
          sx={{ width: "100%" }}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </>
  );
};

export default PlanTable;
