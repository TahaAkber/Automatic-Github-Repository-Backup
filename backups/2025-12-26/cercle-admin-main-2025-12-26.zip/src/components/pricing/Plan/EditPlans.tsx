import React, { useEffect, useState } from "react";
import {
  Button,
  Card,
  Grid,
  MenuItem,
  TextField,
  Typography,
  CircularProgress,
  Alert,
} from "@mui/material";
import { useSelector } from "react-redux";
import { useAppDispatch } from "../../hooks/hooks";
import { updateplan } from "../../../redux/thunks/plansThunk";
import { useNavigate } from "react-router-dom";
import Parentstyle from "../../Style/Parentstyle";
import Childstyle from "../../Style/childstyle";

const EditPlans: React.FC = () => {
  const dispatch = useAppDispatch();
  const { selectedPlan } = useSelector((state: any) => state.planstate);
  const navigate = useNavigate();

  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false); // Loading state to control the spinner
  const [timeoutError, setTimeoutError] = useState(""); // Timeout error message
  const [planData, setPlanData] = useState({
    package_name: selectedPlan ? selectedPlan.package_name : "",
    package_rate: selectedPlan ? selectedPlan.package_rate : 0,
    package_description: selectedPlan ? selectedPlan.package_description : "",
    package_limit_exceed_charges: selectedPlan
      ? selectedPlan.package_limit_exceed_charges
      : 0,
    package_order_limit: selectedPlan ? selectedPlan.package_order_limit : 0,
    package_trial_days: selectedPlan ? selectedPlan.package_trial_days : "",
    package_charges: selectedPlan ? selectedPlan.package_charges : 0,
  });

  useEffect(() => {
    if (!selectedPlan) {
      navigate("/plans"); // If no selected plan, navigate to the plans list
    }
  }, [selectedPlan, navigate]);

  const handleSave = async () => {
    setLoading(true); // Start loading
    setTimeoutError(""); // Reset timeout error

    const timeoutId = setTimeout(() => {
      setLoading(false);
      setTimeoutError("The request timed out. Please try again.");
    }, 10000); // Set a timeout of 10 seconds

    try {
      const result = await dispatch(
        updateplan({
          CreateUpdateRequest: {
            package_name: planData.package_name,
            package_rate: planData.package_rate,
            package_description: planData.package_description,
            package_order_limit: planData.package_order_limit,
            package_limit_exceed_charges: planData.package_limit_exceed_charges,
            package_trial_days: planData.package_trial_days,
            package_charges: planData.package_charges,
          },
          id: selectedPlan.package_id,
        })
      ).unwrap();

      if (result.status === 200) {
        setMessage(result.message);
        setError("");
      } else {
        setError(result.message);
        setMessage("");
      }
    } catch (error) {
      console.error("Error updating plan:", error);
      setError("An error occurred while updating the plan. Please try again.");
      setMessage("");
    } finally {
      clearTimeout(timeoutId);
      setLoading(false);
    }
  };

  return (
    <Parentstyle>
      <Childstyle>
        <Typography variant="h6" fontWeight="medium" className="pb-5">
          Edit Plans
        </Typography>
        {message && (
          <Alert severity="success" sx={{ mb: 2 }}>
            {message}
          </Alert>
        )}
        {timeoutError && (
          <Alert severity="error" sx={{ mb: 2 }}>
            {timeoutError}
          </Alert>
        )}
        {error && (
          <Alert severity="error" sx={{ mb: 2 }}>
            {error}
          </Alert>
        )}
        <Card
          sx={{
            borderRadius: "12px",
            border: "1px solid #e0e0e0",
            boxShadow: 1,
          }}
        >
          <Grid container direction="column" spacing={2}>
            <Grid
              container
              spacing={0}
              alignItems="center"
              justifyContent="space-between"
              flexWrap="wrap"
              className="max-w-full"
            >
              <Grid size={{ xs: 12, md: 6 }} className="p-5">
                <TextField
                  id="Plan Name"
                  label="Plan Name"
                  variant="outlined"
                  fullWidth
                  size="small"
                  value={planData.package_name}
                  onChange={(e) =>
                    setPlanData({ ...planData, package_name: e.target.value })
                  }
                />
              </Grid>

              <Grid size={{ xs: 12, md: 6 }} className="p-5">
                <TextField
                  id="Plan Rate"
                  label="Plan Rate"
                  variant="outlined"
                  fullWidth
                  size="small"
                  value={planData.package_rate}
                  onChange={(e) =>
                    setPlanData({
                      ...planData,
                      package_rate: parseFloat(e.target.value),
                    })
                  }
                />
              </Grid>
              <Grid size={{ xs: 12, md: 8, lg: 12 }} className="px-5">
                <div className="flex flex-col gap-5">
                  <TextField
                    id="Plan Description"
                    label="Plan Description..."
                    variant="outlined"
                    fullWidth
                    size="small"
                    multiline
                    minRows={5}
                    value={planData.package_description}
                    onChange={(e) =>
                      setPlanData({
                        ...planData,
                        package_description: e.target.value,
                      })
                    }
                  />
                </div>
              </Grid>
              <Grid size={{ xs: 12, md: 6 }} className="p-5">
                <TextField
                  id="Order Limit"
                  label="Order Limit"
                  variant="outlined"
                  fullWidth
                  size="small"
                  select
                  SelectProps={{
                    MenuProps: {
                      PaperProps: {
                        style: {
                          padding: "8px",
                        },
                      },
                    },
                  }}
                  value={planData.package_order_limit}
                  onChange={(e) =>
                    setPlanData({
                      ...planData,
                      package_order_limit: e.target.value,
                    })
                  }
                >
                  <MenuItem value="200" className="py-2">
                    200
                  </MenuItem>
                  <MenuItem value="300" className="py-2">
                    300
                  </MenuItem>
                  <MenuItem value="400" className="py-2">
                    400
                  </MenuItem>
                </TextField>
              </Grid>

              <Grid size={{ xs: 12, md: 6 }} className="px-5">
                <TextField
                  id="Order Limit Exceed Charges"
                  label="Order Limit Exceed Charges"
                  variant="outlined"
                  fullWidth
                  size="small"
                  value={planData.package_limit_exceed_charges}
                  onChange={(e) =>
                    setPlanData({
                      ...planData,
                      package_limit_exceed_charges: parseFloat(e.target.value),
                    })
                  }
                />
              </Grid>
              <Grid size={{ xs: 12, md: 6 }} className="px-5">
                <TextField
                  id="Plan Trial Days"
                  label="Plan Trial Days"
                  variant="outlined"
                  fullWidth
                  size="small"
                  select
                  SelectProps={{
                    MenuProps: {
                      PaperProps: {
                        style: {
                          padding: "8px",
                        },
                      },
                    },
                  }}
                  value={planData.package_trial_days}
                  onChange={(e) =>
                    setPlanData({
                      ...planData,
                      package_trial_days: e.target.value,
                    })
                  }
                >
                  <MenuItem value="7" className="py-2">
                    7
                  </MenuItem>
                  <MenuItem value="14" className="py-2">
                    14
                  </MenuItem>
                  <MenuItem value="21" className="py-2">
                    21
                  </MenuItem>
                </TextField>
              </Grid>

              <Grid size={{ xs: 12, md: 6 }} className="px-5">
                <TextField
                  id="Plan Charges"
                  label="Plan Charges"
                  variant="outlined"
                  fullWidth
                  size="small"
                  value={planData.package_charges}
                  onChange={(e) =>
                    setPlanData({
                      ...planData,
                      package_charges: parseFloat(e.target.value),
                    })
                  }
                />
              </Grid>
            </Grid>

            {/* Save Changes Button */}
            <div className="px-5 my-3">
              <Button
                variant="contained"
                size="small"
                color="primary"
                sx={{ fontWeight: 400 }}
                onClick={handleSave}
                disabled={loading}
              >
                {loading ? (
                  <CircularProgress size={24} sx={{ color: "white" }} />
                ) : (
                  "Save Changes"
                )}
              </Button>
            </div>
          </Grid>
        </Card>
      </Childstyle>
    </Parentstyle>
  );
};

export default EditPlans;
