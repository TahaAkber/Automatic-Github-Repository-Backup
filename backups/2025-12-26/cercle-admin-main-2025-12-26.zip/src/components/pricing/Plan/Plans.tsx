import { Card, Divider, Pagination } from "@mui/material";
import React, { useEffect, useState } from "react";
import PlanTable from "./PlanTable";
import Parentstyle from "../../Style/Parentstyle";
import Childstyle from "../../Style/childstyle";
import { useAppDispatch } from "../../hooks/hooks";
import { fetchplans } from "../../../redux/thunks/plansThunk";
import { useSelector } from "react-redux";
import AccessDenied from "../../../components/merchant/Accessdenied";
import { useRolePermissions } from "../../../components/functions/useRolePermissions";
import { RoleLike } from "../../../components/functions/Roles";

const Plans: React.FC = () => {
  const dispatch = useAppDispatch();

  const [currentPage, setCurrentPage] = useState(1);

  const handlePageChange = (_: React.ChangeEvent<unknown>, page: number) => {
    setCurrentPage(page);
  };

  useEffect(() => {
    dispatch(fetchplans({ page: currentPage }));
  }, [dispatch, currentPage]);

  const { pagination } = useSelector((state: any) => state.plans);
  const rawRoles = useSelector((s: any) => s.auth.user?.roles) as
    | RoleLike[]
    | undefined;
  const { can } = useRolePermissions(rawRoles);
  const canWrite = can("plans", "write");
  const canRead = can("plans", "read");
  if (!canRead) {
    return (
      <AccessDenied
        subtitle="Your account is missing read permissions for merchant. Contact an admin if you need access."
        secondaryActionText="Contact admin"
        onSecondaryAction={() => {
          // open your support modal / route / mailto
          // e.g., navigate("/support") or open a dialog
          window.open("https://cymbiote.com/contact-us/", "_blank");
        }}
      />
    );
  }
  return (

    <Parentstyle>
      <Childstyle>
        <div className="flex justify-between pb-5">
          <h1 className="text-2xl font-semibold mb-2">Plans</h1>

          {/* <Button
            variant="contained"
            size="small"
            onClick={() => {
              navigate("/plans/createplans");
            }}
            sx={{ fontWeight: 300, textTransform: "none" }}
          >
            Create Plans
          </Button> */}
        </div>
        <Card>
          <PlanTable canWrite={canWrite} />
          <Divider />
          <div className="m-5 py-1">
            {pagination?.totalPages > 1 && (
              <Pagination
                onChange={handlePageChange}
                count={pagination?.totalPages || 1}
                page={currentPage}
                variant="outlined"
                shape="rounded"
                color="primary"
              />
            )}
          </div>
        </Card>
      </Childstyle>
    </Parentstyle>
  );
};

export default Plans;
