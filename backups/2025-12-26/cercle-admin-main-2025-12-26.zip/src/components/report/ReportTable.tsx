import React, { useState } from "react";
import {
  Tooltip,
  IconButton,
  Snackbar,
  Alert,
  Typography,
  Backdrop,
  CircularProgress,
  Card,
  Menu,
  MenuItem,
  useTheme,
  useMediaQuery,
  Link,
} from "@mui/material";
import BugReportOutlined from "@mui/icons-material/BugReport";
import { useSelector } from "react-redux";
import { useAppDispatch } from "../hooks/hooks";
import { useRolePermissions } from "../../components/functions/useRolePermissions";
import { RoleLike } from "../functions/Roles";
import { Report } from "../../types/pages/types";
import DeleteOutlineRoundedIcon from "@mui/icons-material/DeleteOutlineRounded";
import {
  deleteReport,
  updateReportStatus,
} from "../../redux/thunks/reportThunk";
import DeleteModal from "../../components/modules/DeleteModal";
import ReportDecisionModal from "../../components/modules/ReportDecisionModal";
import ReportDetailModal from "../../components/modules/ReportDetailModal";

const ReportTable: React.FC = () => {
  const dispatch = useAppDispatch();

  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));

  const rawRoles = useSelector((s: any) => s.auth.user?.roles) as
    | RoleLike[]
    | undefined;

  // Permissions
  const { can } = useRolePermissions(rawRoles);
  const canWrite = can("collections", "write");

  // Data
  const reports = useSelector((s: any) => s.reports?.reports || []);
  const isLoading = useSelector((s: any) => s.reports?.status === "loading");

  // UI state
  const [snackbarSeverity, setSnackbarSeverity] = useState<"success" | "error">(
    "success"
  );
  const [selectedRow, setSelectedRow] = useState<Report | null>(null);
  const [openSnackbar, setOpenSnackbar] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState("");
  const [modalopen, setModalopen] = useState(false);
  const [deleting, setDeleting] = useState(false);

  // Decision modal state
  const [decisionModalOpen, setDecisionModalOpen] = useState(false);
  const [decisionDescription, setDecisionDescription] = useState("");
  const [decisionResult, setDecisionResult] = useState("");
  const [selectedStatus, setSelectedStatus] = useState("");

  // Report Details modal state
  const [detailsModalOpen, setDetailsModalOpen] = useState(false);
  const [selectedReportForDetails, setSelectedReportForDetails] = useState<Report | null>(null);

  // Status Menu (opens on bug icon click)
  const [statusMenuAnchorEl, setStatusMenuAnchorEl] =
    useState<null | HTMLElement>(null);
  const [statusMenuRow, setStatusMenuRow] = useState<Report | null>(null);

  const isStatusMenuOpen = Boolean(statusMenuAnchorEl);

  const openStatusMenu = (e: React.MouseEvent<HTMLElement>, row: Report) => {
    setStatusMenuAnchorEl(e.currentTarget);
    setStatusMenuRow(row);
  };

  const closeStatusMenu = () => {
    setStatusMenuAnchorEl(null);
    setStatusMenuRow(null);
  };

  const handleStatusChange = async (row: any, newStatus: any) => {
    if (newStatus === "pending" || newStatus === "in_review") {
      try {
        const result = await dispatch(
          updateReportStatus({
            id: row.report_id,
            status: newStatus,
          })
        );

        if (updateReportStatus.fulfilled.match(result)) {
          setSnackbarMessage(
            `Status updated to ${
              newStatus === "pending" ? "Pending" : "In Review"
            }!`
          );
          setSnackbarSeverity("success");
          setOpenSnackbar(true);
        } else if (updateReportStatus.rejected.match(result)) {
          setSnackbarMessage(result.payload || "Failed to update status");
          setSnackbarSeverity("error");
          setOpenSnackbar(true);
        }
      } catch (error) {
        setSnackbarMessage("An error occurred while updating status");
        setSnackbarSeverity("error");
        setOpenSnackbar(true);
      }
    } else if (newStatus === "resolved" || newStatus === "rejected") {
      setSelectedRow(row);
      setSelectedStatus(newStatus);
      setDecisionModalOpen(true);
    }
  };

  const getStatusBadge = (status?: string) => {
    if (!status) {
      return <span className="text-gray-500 text-xs">Select</span>;
    }

    // pending more highlighted
    const colorClasses =
      status === "pending"
        ? "bg-yellow-300 text-yellow-900 ring-1 ring-yellow-400"
        : status === "in_review"
        ? "bg-blue-100 text-blue-800"
        : status === "resolved"
        ? "bg-green-100 text-green-800"
        : status === "rejected"
        ? "bg-red-100 text-red-800"
        : "bg-gray-100 text-gray-800";

    const displayName =
      status === "in_review"
        ? "In Review"
        : status === "pending"
        ? "Pending"
        : status === "resolved"
        ? "Resolved"
        : status === "rejected"
        ? "Rejected"
        : status;

    return (
      <span
        className={`px-2 inline-flex text-xs leading-7 font-semibold rounded-full ${colorClasses}`}
      >
        {displayName}
      </span>
    );
  };

  // Handlers (WRITE guarded)
  const handleDelete = (row: Report) => {
    setSelectedRow(row);
    setModalopen(true);
  };

  const handleConfirmDelete = async () => {
    if (!selectedRow || !selectedRow.report_id) {
      setSnackbarMessage("No report selected");
      setSnackbarSeverity("error");
      setOpenSnackbar(true);
      setModalopen(false);
      return;
    }

    setDeleting(true);

    try {
      const result = await dispatch(
        deleteReport({ id: selectedRow.report_id })
      );

      if (deleteReport.fulfilled.match(result)) {
        setSnackbarMessage("Report deleted successfully!");
        setSnackbarSeverity("success");
        setOpenSnackbar(true);
        setModalopen(false);
        setSelectedRow(null);
      } else if (deleteReport.rejected.match(result)) {
        setSnackbarMessage(result.payload || "Failed to delete report");
        setSnackbarSeverity("error");
        setOpenSnackbar(true);
      }
    } catch (error) {
      setSnackbarMessage("An error occurred while deleting the report");
      setSnackbarSeverity("error");
      setOpenSnackbar(true);
    } finally {
      setDeleting(false);
    }
  };

  const handleClose = () => setModalopen(false);

  const handleViewDetails = (row: Report) => {
    setSelectedReportForDetails(row);
    setDetailsModalOpen(true);
  };

  const handleCloseDetailsModal = () => {
    setDetailsModalOpen(false);
    setSelectedReportForDetails(null);
  };

  return (
    <div className="overflow-x-auto border-gray-200 rounded-lg shadow-sm">
      <table className="min-w-full text-sm text-left">
        <thead className="bg-gray-50 border-b text-gray-500 font-semibold">
          <tr>
            <th className="px-6 py-3 whitespace-nowrap">Reported By User</th>
            <th className="px-6 py-3 whitespace-nowrap">Report Type</th>
            <th className="px-6 py-3 whitespace-nowrap">Reported Shop</th>
            <th className="px-6 py-3 whitespace-nowrap">Reported Product</th>
            <th className="px-6 py-3 whitespace-nowrap">Status</th>
            <th className="px-6 py-3 whitespace-nowrap">Main Reason</th>
            <th className="px-6 py-3 whitespace-nowrap">Sub Reason</th>
            <th className="px-6 py-3 whitespace-nowrap">Other Reason</th>
            <th className="px-6 py-3 whitespace-nowrap">Action</th>
            <th className="px-6 py-3 whitespace-nowrap">Report Details</th>
          </tr>
        </thead>

        <tbody>
          {reports.length === 0 ? (
            <tr>
              <td colSpan={9} className="px-6 py-8">
                <Card
                  variant="outlined"
                  sx={{
                    p: 3,
                    borderRadius: 2,
                    borderColor: (t) => t.palette.divider,
                    textAlign: "center",
                  }}
                >
                  <Typography variant="body1" color="text.secondary">
                    No reports found.
                  </Typography>
                </Card>
              </td>
            </tr>
          ) : (
            reports.map((row: Report, index: number) => {
              const statusLocked =
                row.reported_status === "rejected" ||
                row.reported_status === "resolved";

              return (
                <tr
                  key={row.report_id ?? index}
                  className="border-b last:border-none"
                >
                  <td className="px-6 py-4 whitespace-nowrap">
                    {row.user_first_name} {row.user_last_name}
                    <br />
                    <span className="text-xs text-gray-500">
                      {row.user_email}
                    </span>
                  </td>

                  <td className="px-6 py-4 whitespace-nowrap">
                    {row.reported_type}
                  </td>

                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-gray-200 rounded-lg flex items-center justify-center overflow-hidden">
                        {row.shop_logo_url ? (
                          <img
                            src={row.shop_logo_url}
                            alt={row.shop_name || "Shop"}
                            className="w-full h-full object-cover"
                            onError={(e) => {
                              const target = e.target as HTMLImageElement;
                              target.src =
                                "https://cdn.shopify.com/s/files/1/0595/2379/2944/files/img_not_found_cercle.jpg?v=1757333158";
                            }}
                          />
                        ) : (
                          <img
                            src="https://cdn.shopify.com/s/files/1/0595/2379/2944/files/img_not_found_cercle.jpg?v=1757333158"
                            className="w-full h-full object-cover"
                            alt="Shop"
                            onError={(e) => {
                              const target = e.target as HTMLImageElement;
                              target.src =
                                "https://cdn.shopify.com/s/files/1/0595/2379/2944/files/img_not_found_cercle.jpg?v=1757333158";
                            }}
                          />
                        )}
                      </div>
                      <span className="text-sm text-gray-800 font-medium">
                        {row.shop_name || "N/A"}
                      </span>
                    </div>
                  </td>

                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-gray-200 rounded-lg flex items-center justify-center overflow-hidden">
                        {row.product_image_url ? (
                          <img
                            src={row.product_image_url}
                            alt={row.product_name || "Product"}
                            className="w-full h-full object-cover"
                            onError={(e) => {
                              const target = e.target as HTMLImageElement;
                              target.src =
                                "https://cdn.shopify.com/s/files/1/0595/2379/2944/files/img_not_found_cercle.jpg?v=1757333158";
                            }}
                          />
                        ) : (
                          <img
                            src="https://cdn.shopify.com/s/files/1/0595/2379/2944/files/img_not_found_cercle.jpg?v=1757333158"
                            alt="Product"
                            className="w-full h-full object-cover"
                            onError={(e) => {
                              const target = e.target as HTMLImageElement;
                              target.src =
                                "https://cdn.shopify.com/s/files/1/0595/2379/2944/files/img_not_found_cercle.jpg?v=1757333158";
                            }}
                          />
                        )}
                      </div>

                      <Tooltip title={row?.product_name || "N/A"} arrow>
                        <span className="text-sm text-gray-800 font-medium cursor-help">
                          {(row?.product_name || "N/A").length > 20
                            ? (row?.product_name || "N/A").slice(0, 20) + "…"
                            : row?.product_name || "N/A"}
                        </span>
                      </Tooltip>
                    </div>
                  </td>

                  {/* Status badge only */}
                  <td className="px-2 py-4 whitespace-nowrap">
                    {getStatusBadge(row.reported_status)}
                  </td>

                  <td className="px-6 py-4 whitespace-nowrap">
                    <Tooltip title={row.reported_reason_main || ""} arrow>
                      <div className="max-w-[250px] truncate cursor-help">
                        {row.reported_reason_main || "-"}
                      </div>
                    </Tooltip>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <Tooltip title={row.reported_reason_sub || ""} arrow>
                      <div className="max-w-[250px] truncate cursor-help">
                        {row.reported_reason_sub || "-"}
                      </div>
                    </Tooltip>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <Tooltip title={row.reported_reason_other_text || ""} arrow>
                      <div className="max-w-[250px] truncate cursor-help">
                        {row.reported_reason_other_text || "-"}
                      </div>
                    </Tooltip>
                  </td>
                  
                  <td className="px-4 py-4 whitespace-nowrap flex">
                    {/* Update Status (Bug icon opens menu) */}
                    <div className="flex items-center gap-2">
                      {canWrite ? (
                        <Tooltip
                          title={
                            statusLocked
                              ? "Status cannot be updated"
                              : "update Status"
                          }
                        >
                          <span>
                            <IconButton
                              size="small"
                              disabled={statusLocked}
                              onClick={(e) => openStatusMenu(e, row)}
                            >
                              <BugReportOutlined
                                fontSize="small"
                                color={statusLocked ? "action" : "error"}
                              />
                            </IconButton>
                          </span>
                        </Tooltip>
                      ) : (
                        <Tooltip title="You need write permissions to take this action">
                          <span>
                            <IconButton size="small" disabled>
                              <BugReportOutlined
                                fontSize="small"
                                color={statusLocked ? "action" : "error"}
                              />
                            </IconButton>
                          </span>
                        </Tooltip>
                      )}
                    </div>

                    {/* Delete */}
                    <div className="flex items-center gap-2">
                      {canWrite ? (
                        <Tooltip title="Delete">
                          <IconButton
                            size="small"
                            onClick={() => handleDelete(row)}
                          >
                            <DeleteOutlineRoundedIcon
                              fontSize="small"
                              color="error"
                            />
                          </IconButton>
                        </Tooltip>
                      ) : (
                        <Tooltip title="You need write permissions to delete">
                          <span>
                            <IconButton size="small" disabled>
                              <DeleteOutlineRoundedIcon
                                fontSize="small"
                                color="disabled"
                              />
                            </IconButton>
                          </span>
                        </Tooltip>
                      )}
                    </div>
                  </td>
              <td className="text-center px-5 py-3">
                <Link 
                  href="#" 
                  onClick={(e) => {
                    e.preventDefault();
                    handleViewDetails(row);
                  }}
                  sx={{ cursor: 'pointer' }}
                >
                  View Details
                </Link>
              </td>
                </tr>
              );
            })
          )}
        </tbody>
      </table>

      {/* ✅ Responsive Status Menu (dropdown on desktop, bottom-sheet on mobile) */}
      <Menu
        anchorEl={statusMenuAnchorEl}
        open={isStatusMenuOpen}
        onClose={closeStatusMenu}
        anchorOrigin={
          isMobile
            ? { vertical: "bottom", horizontal: "center" }
            : { vertical: "bottom", horizontal: "right" }
        }
        transformOrigin={
          isMobile
            ? { vertical: "bottom", horizontal: "center" }
            : { vertical: "top", horizontal: "right" }
        }
        PaperProps={{
          sx: {
            mt: isMobile ? 0 : 1,

            width: isMobile ? "calc(100vw - 16px)" : "auto",
            maxWidth: isMobile ? "calc(100vw - 16px)" : 320,
            minWidth: isMobile ? "calc(100vw - 16px)" : 220,
            maxHeight: isMobile ? "60vh" : 420,
            overflowY: "auto",

            borderRadius: isMobile ? 3 : 2,
            boxShadow: "0 12px 30px rgba(0,0,0,0.12)",
            border: "1px solid",
            borderColor: "divider",
            overflow: "hidden",
            p: 0.5,

            ...(isMobile && {
              position: "fixed",
              left: 8,
              right: 8,
              bottom: 8,
              top: "auto",
            }),
          },
        }}
      >
        {/* Header */}
        <div className="px-3 py-2">
          {isMobile && (
            <div className="w-12 h-1 bg-gray-200 rounded-full mx-auto mb-2" />
          )}
          <div className="text-xs font-semibold text-gray-700">
            Update Status
          </div>
          <div className="text-[11px] text-gray-500">
            Choose a new status for this report
          </div>
        </div>
        <div className="h-px bg-gray-100 my-1" />

        {[
          { value: "pending", label: "Pending" },
          { value: "in_review", label: "In Review" },
          { value: "resolved", label: "Resolved" },
          { value: "rejected", label: "Rejected" },
        ].map((opt) => {
          const currentStatus = statusMenuRow?.reported_status;

          const colorClasses =
            opt.value === "pending"
              ? "bg-yellow-300 text-yellow-900 ring-1 ring-yellow-400"
              : opt.value === "in_review"
              ? "bg-blue-100 text-blue-800"
              : opt.value === "resolved"
              ? "bg-green-100 text-green-800"
              : opt.value === "rejected"
              ? "bg-red-100 text-red-800"
              : "bg-gray-100 text-gray-800";

          const dotClasses =
            opt.value === "pending"
              ? "bg-yellow-500"
              : opt.value === "in_review"
              ? "bg-blue-500"
              : opt.value === "resolved"
              ? "bg-green-500"
              : opt.value === "rejected"
              ? "bg-red-500"
              : "bg-gray-400";

          const isCurrent = currentStatus === opt.value;

          return (
            <MenuItem
              key={opt.value}
              disabled={isCurrent}
              onClick={() => {
                if (!statusMenuRow) return;
                handleStatusChange(statusMenuRow, opt.value);
                closeStatusMenu();
              }}
              sx={{
                borderRadius: 1.5,
                mx: 0.5,
                my: 0.25,
                py: 1,
                "&.Mui-disabled": { opacity: 0.7 },
              }}
            >
              <div className="w-full flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className={`h-2.5 w-2.5 rounded-full ${dotClasses}`} />
                  <span
                    className={`px-2 inline-flex text-xs leading-7 font-semibold rounded-full ${colorClasses}`}
                  >
                    {opt.label}
                  </span>
                </div>

                {isCurrent && (
                  <span className="text-[10px] font-semibold px-2 py-1 rounded-full bg-gray-100 text-gray-600">
                    Current
                  </span>
                )}
              </div>
            </MenuItem>
          );
        })}
      </Menu>

      <Snackbar
        open={openSnackbar}
        autoHideDuration={2000}
        onClose={() => setOpenSnackbar(false)}
        anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
      >
        <Alert
          onClose={() => setOpenSnackbar(false)}
          severity={snackbarSeverity}
          sx={{ width: "100%" }}
        >
          {snackbarMessage}
        </Alert>
      </Snackbar>

      <DeleteModal
        modalopen={modalopen}
        handleClose={handleClose}
        deleting={deleting}
        title="Are you sure you want to delete this report?"
        handleConfirmDelete={handleConfirmDelete}
      />

      <ReportDecisionModal
        modalopen={decisionModalOpen}
        setDecisionModalOpen={setDecisionModalOpen}
        setDecisionDescription={setDecisionDescription}
        decisionDescription={decisionDescription}
        decisionResult={decisionResult}
        setDecisionResult={setDecisionResult}
        selectedStatus={selectedStatus}
        selectedRow={selectedRow}
        setOpenSnackbar={setOpenSnackbar}
        setSnackbarMessage={setSnackbarMessage}
        setSnackbarSeverity={setSnackbarSeverity}
        openSnackbar={openSnackbar}
        SnackbarMessage={snackbarMessage}
        snackbarSeverity={snackbarSeverity}
      />

      <Backdrop open={isLoading} sx={{ zIndex: 2000 }}>
        <CircularProgress />
      </Backdrop>

      {/* Report Details Modal */}
      <ReportDetailModal
        open={detailsModalOpen}
        onClose={handleCloseDetailsModal}
        selectedReport={selectedReportForDetails}
      />
    </div>
  );
};

export default ReportTable;
