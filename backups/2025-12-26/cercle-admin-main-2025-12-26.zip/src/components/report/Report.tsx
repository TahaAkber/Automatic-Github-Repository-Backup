import {
  Button,
  Card,
  FormControl,
  Grid,
  InputAdornment,
  MenuItem,
  Pagination,
  Select,
  SelectChangeEvent,
  TextField,
  Tooltip,
  Menu,
} from "@mui/material";
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router";
import Parentstyle from "../Style/Parentstyle";
import Childstyle from "../Style/childstyle";
import { useAppDispatch } from "../hooks/hooks";
import { fetchReports } from "../../redux/thunks/reportThunk";
import { useSelector } from "react-redux";
// import { RoleLike } from "../functions/Roles";
// import { useRolePermissions } from "../../components/functions/useRolePermissions";
import GoBackButton from "../button/Goback";
import ReportTable from "./ReportTable";
import SearchIcon from "@mui/icons-material/Search";
import useAutoLimit from "../../components/brands/AutoLimitViewPort";
import { FilterAltOutlined } from "@mui/icons-material";

const Report = () => {
  const navigate = useNavigate();
  const dispatch = useAppDispatch();

  // const rawRoles = useSelector((s: any) => s.auth.user?.roles) as
  //   | RoleLike[]
  //   | undefined;

  // Permissions

  const { pagination } = useSelector((state: any) => state.reports);

  const autoLimit = useAutoLimit();
  const [searchKeyword, setSearchKeyword] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [limit, setLimit] = useState(autoLimit);
  const [status, setStatus] = useState("");
  const [reportedType, setReportedType] = useState("");

  // Filter Menu State
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const openFilter = Boolean(anchorEl);

  const handleFilterClick = (event: React.MouseEvent<HTMLButtonElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const handleFilterClose = () => {
    setAnchorEl(null);
  };

  const handleReportedTypeChange = (type: string) => {
    setReportedType(type);
    setCurrentPage(1);
    handleFilterClose();
  };

  // Debounce Search
  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedSearch(searchKeyword);
    }, 500);
    return () => clearTimeout(handler);
  }, [searchKeyword]);

  // Fetch Reports
  useEffect(() => {
    dispatch(
      fetchReports({
        page: currentPage,
        limit: limit,
        search: debouncedSearch,
        status: status,
        reported_type: reportedType,
      })
    );
  }, [dispatch, currentPage, limit, debouncedSearch, status, reportedType]);

  const handlePageChange = (_: React.ChangeEvent<unknown>, page: number) => {
    setCurrentPage(page);
  };

  return (
    <Parentstyle>
      <div className="mb-3">
        <GoBackButton onClick={() => navigate(-1)} />
      </div>
      <Childstyle>
        <div className="pb-5">
          <h1 className="text-2xl font-semibold mb-4">Reported Item List</h1>

          <Grid
            container
            spacing={2}
            alignItems="center"
            justifyContent="space-between"
          >
            <Grid size={{ xs: 12, sm: 6, md: 5 }}>
              <TextField
                size="small"
                id="input-with-icon-textfield"
                autoComplete="off"
                label="Search"
                fullWidth
                slotProps={{
                  input: {
                    endAdornment: (
                      <InputAdornment position="end">
                        <SearchIcon />
                      </InputAdornment>
                    ),
                  },
                }}
                variant="outlined"
                value={searchKeyword}
                onChange={(e) => {
                  setSearchKeyword(e.target.value);
                  setCurrentPage(1);
                }}
              />
            </Grid>

            <Grid size={{ xs: 12, sm: 6, md: 7 }}>
              <div className="flex flex-wrap gap-2 justify-end">
                <FormControl size="small" sx={{ minWidth: 120 }}>
                  <Select
                    size="small"
                    labelId="helper-label1"
                    id="select-helper1"
                    value={limit.toString()}
                    displayEmpty
                    onChange={(e: SelectChangeEvent) => {
                      setLimit(Number(e.target.value));
                      setCurrentPage(1);
                    }}
                    renderValue={(limit) => {
                      if (!limit)
                        return <span className="text-gray-500">Limit</span>;
                      return (
                        <span className="text-gray-500">Limit: {limit}</span>
                      );
                    }}
                  >
                    <MenuItem value={10}>10</MenuItem>
                    <MenuItem value={12}>12</MenuItem>
                    <MenuItem value={20}>20</MenuItem>
                    <MenuItem value={50}>50</MenuItem>
                    <MenuItem value={100}>100</MenuItem>
                  </Select>
                </FormControl>

                <FormControl size="small" sx={{ minWidth: 120 }}>
                  <Select
                    size="small"
                    labelId="helper-label2"
                    id="select-helper2"
                    value={status}
                    displayEmpty
                    onChange={(e) => {
                      setStatus(e.target.value);
                      setCurrentPage(1);
                    }}
                    renderValue={(status) => {
                      if (!status)
                        return <span className="text-gray-500">All</span>;
                      return <span className="text-gray-500">{status}</span>;
                    }}
                  >
                    <MenuItem value="" className="text-gray-500">
                      All
                    </MenuItem>
                    <MenuItem value="pending">Pending</MenuItem>
                    <MenuItem value="resolved">Resolved</MenuItem>
                    <MenuItem value="rejected">Rejected</MenuItem>
                  </Select>
                </FormControl>

                <Tooltip title="Filter by Type">
                  <Button
                    id="filter-button"
                    aria-controls={openFilter ? "filter-menu" : undefined}
                    aria-haspopup="true"
                    aria-expanded={openFilter ? "true" : undefined}
                    onClick={handleFilterClick}
                    variant="outlined"
                    sx={{ minWidth: "40px", padding: "8px" }}
                  >
                    <FilterAltOutlined />
                  </Button>
                </Tooltip>
                <Menu
                  id="filter-menu"
                  anchorEl={anchorEl}
                  open={openFilter}
                  onClose={handleFilterClose}
                  MenuListProps={{
                    "aria-labelledby": "filter-button",
                  }}
                >
                  <MenuItem onClick={() => handleReportedTypeChange("")}>
                    All
                  </MenuItem>
                  <MenuItem onClick={() => handleReportedTypeChange("story")}>
                    Story
                  </MenuItem>
                  <MenuItem onClick={() => handleReportedTypeChange("reel")}>
                    Reel
                  </MenuItem>
                  <MenuItem onClick={() => handleReportedTypeChange("product")}>
                    Product
                  </MenuItem>
                  <MenuItem onClick={() => handleReportedTypeChange("shop")}>
                    Shop
                  </MenuItem>
                </Menu>
              </div>
            </Grid>
          </Grid>
        </div>
        <Card>
          <ReportTable />

          {pagination?.totalPages > 1 && (
            <div className="m-5 py-1 flex justify-center">
              <Pagination
                onChange={handlePageChange}
                count={pagination?.totalPages || 1}
                page={currentPage}
                variant="outlined"
                shape="rounded"
                color="primary"
              />
            </div>
          )}
        </Card>
      </Childstyle>
    </Parentstyle>
  );
};

export default Report;
