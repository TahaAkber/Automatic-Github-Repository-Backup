import React, { useEffect, useMemo, useState } from "react";
import {
  Card,
  FormControl,
  InputAdornment,
  MenuItem,
  Pagination,
  Select,
  SelectChangeEvent,
  TextField,
} from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";
import { useSelector } from "react-redux";
import Childstyle from "../Style/childstyle";
import Parentstyle from "../Style/Parentstyle";
import { RoleLike } from "../../components/functions/Roles";
import { useRolePermissions } from "../../components/functions/useRolePermissions";
import AccessDenied from "../../components/merchant/Accessdenied";
import { useAppDispatch } from "../../components/hooks/hooks";
import { fetchReviews } from "../../../src/redux/thunks/reviewThunks";
import { ClipWithTooltip } from "./customToolTip";
import DataTable, { DataTableColumn } from "../../components/modules/DataTable";

const Reviews = () => {
  const dispatch = useAppDispatch();

  const [search, setSearch] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [limit, setLimit] = useState(10);

  const rawRoles = useSelector((state: any) => state.auth.user?.roles) as
    | RoleLike[]
    | undefined;

  const { can } = useRolePermissions(rawRoles);
  const canRead = can("users", "read");
  const canWrite = can("users", "write");

  const { reviews, loading, message, status, pagination } = useSelector(
    (state: any) => state.productReviews
  );

  useEffect(() => {
    dispatch(fetchReviews({ page: currentPage, limit, search }));
  }, [dispatch, currentPage, limit, search]);

  const rows = useMemo(
    () => (Array.isArray(reviews) ? reviews : []),
    [reviews]
  );

  const formatDate = (value?: string) => {
    if (!value) return "—";
    const d = new Date(value);
    return isNaN(d.getTime()) ? "—" : d.toLocaleDateString();
  };

  const columns: DataTableColumn<any>[] = useMemo(
    () => [
      {
        key: "review",
        header: "Reviews",
        thClassName: "text-left px-6 py-3",
        tdClassName: "align-top px-6 py-4 text-sm text-gray-800",
        render: (review) => {
          const comment =
            review?.order_item_review_comment ?? review?.comment ?? "";
          return <ClipWithTooltip text={comment} maxWords={15} />;
        },
      },
      {
        key: "store",
        header: "Store",
        thClassName: "text-left px-5 py-3",
        tdClassName: "align-top px-5 py-4",
        render: (review) => {
          const shopLogo =
            review?.shop_logo_url ||
            "https://cdn.shopify.com/s/files/1/0595/2379/2944/files/No_image_available.webp?v=1756886203";
          const shopName = review?.shop_name || "—";

          return (
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gray-200 rounded-lg flex items-center justify-center overflow-hidden">
                {shopLogo ? (
                  <img
                    src={shopLogo}
                    alt={shopName}
                    className="w-8 h-8 rounded object-cover"
                  />
                ) : (
                  <span className="text-xs text-gray-500">No Logo</span>
                )}
              </div>
              <span className="text-sm text-gray-800 font-medium">
                {shopName}
              </span>
            </div>
          );
        },
      },
      {
        key: "product",
        header: "Product",
        thClassName: "text-left px-5 py-3",
        tdClassName: "align-top px-5 py-4",
        render: (review) => {
          const productName = review?.product_name || "";
          const productImage =
            review?.variant_image_url ||
            "https://cdn.shopify.com/s/files/1/0595/2379/2944/files/No_image_available.webp?v=1756886203";

          return (
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gray-200 rounded-lg flex items-center justify-center overflow-hidden">
                {productImage ? (
                  <img
                    src={productImage}
                    alt={productName || "Product"}
                    className="w-8 h-8 rounded object-cover"
                  />
                ) : (
                  <span className="text-xs text-gray-500">No Img</span>
                )}
              </div>

              <span className="text-sm text-gray-800">
                <ClipWithTooltip text={productName} maxWords={15} />
              </span>
            </div>
          );
        },
      },
      {
        key: "user",
        header: "User",
        thClassName: "text-left px-5 py-3",
        tdClassName: "align-top px-5 py-4 text-sm text-gray-800",
        render: (review) => {
          const userName =
            review?.user_name ?? review?.customer_name ?? review?.user ?? "—";

          return <ClipWithTooltip text={userName} maxChars={18} />;
        },
      },
      {
        key: "date",
        header: "Date",
        thClassName: "text-left px-5 py-3",
        tdClassName: "align-top px-5 py-4 text-sm text-gray-600",
        render: (review) => {
          const dateValue =
            review?.order_item_review_created_at ??
            review?.created_at ??
            review?.updated_at ??
            null;

          return formatDate(dateValue);
        },
      },
    ],
    []
  );

  const emptyText =
    status === "error"
      ? message || "Failed to load reviews."
      : "No reviews found.";

  const handlePageChange = (_: React.ChangeEvent<unknown>, page: number) => {
    setCurrentPage(page);
  };

  if (!canRead) {
    return (
      <AccessDenied
        subtitle="Your account is missing read permissions for user. Contact an admin if you need access."
        secondaryActionText="Contact admin"
        onSecondaryAction={() => {
          window.open("https://cymbiote.com/contact-us/", "_blank");
        }}
      />
    );
  }

  return (
    <Parentstyle>
      <Childstyle>
        <h1 className="text-2xl font-semibold mb-2">Reviews</h1>

        <Card className="w-full p-5">
          {/* keep filters optional for write users like your current logic */}
          {canWrite && (
            <div className="flex my-5 justify-between">
              <TextField
                size="small"
                autoComplete="off"
                label="Search Products..."
                className="border-x-black border-solid border w-96 rounded-md"
                slotProps={{
                  input: {
                    endAdornment: (
                      <InputAdornment position="end">
                        <SearchIcon />
                      </InputAdornment>
                    ),
                  },
                }}
                variant="outlined"
                placeholder="e.g... Elite Smart Watch"
                value={search}
                onChange={(e) => {
                  setSearch(e.target.value);
                  setCurrentPage(1);
                }}
              />

              <div className="flex gap-x-4">
                <FormControl className="w-32" size="small">
                  <Select
                    size="small"
                    className="w-32"
                    value={limit.toString()}
                    displayEmpty
                    onChange={(e: SelectChangeEvent) => {
                      setLimit(Number(e.target.value));
                      setCurrentPage(1);
                    }}
                    renderValue={(val) => (
                      <span className="text-gray-500">Limit: {val}</span>
                    )}
                  >
                    <MenuItem value={10}>Data Number</MenuItem>
                    <MenuItem value={20}>Twenty</MenuItem>
                    <MenuItem value={50}>Fifty</MenuItem>
                    <MenuItem value={100}>Hundred</MenuItem>
                  </Select>
                </FormControl>
              </div>
            </div>
          )}

          {/* ✅ DataTable directly */}
          <DataTable
            columns={columns}
            rows={rows}
            loading={Boolean(loading)}
            emptyText={emptyText}
            rowKey={(review, idx) =>
              review?.order_item_review_id ??
              review?.id ??
              `${review?.order_item_id || "row"}-${idx}`
            }
            wrapperClassName="overflow-x-auto bg-white"
            tableClassName="min-w-full border-collapse"
            theadClassName="bg-gray-50 border-b border-gray-200 text-sm font-medium text-gray-500"
            rowClassName="border-b border-gray-200 hover:bg-gray-50 transition-colors"
          />

          <div className="m-5 py-1">
            <Pagination
              onChange={handlePageChange}
              count={pagination?.totalPages || 1}
              page={currentPage}
              variant="outlined"
              shape="rounded"
              color="primary"
            />
          </div>
        </Card>
      </Childstyle>
    </Parentstyle>
  );
};

export default Reviews;
