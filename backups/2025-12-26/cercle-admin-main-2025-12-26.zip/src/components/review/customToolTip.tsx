import { Tooltip } from "@mui/material";

type ClipProps = {
  text?: string | null;
  maxWords?: number; // optional (word-based)
  maxChars?: number; // optional (char-based)
  className?: string;
};

export const ClipWithTooltip = ({
  text,
  maxWords,
  maxChars,
  className,
}: ClipProps) => {
  const full = (text ?? "").trim();
  if (!full) return <span className={className}>—</span>;

  let shown = full;
  let truncated = false;

  // Prefer char limit when provided; fall back to word limit
  if (typeof maxChars === "number" && maxChars > 0 && full.length > maxChars) {
    shown = full.slice(0, maxChars).trimEnd() + "…";
    truncated = true;
  } else if (typeof maxWords === "number" && maxWords > 0) {
    const words = full.split(/\s+/).filter(Boolean);
    if (words.length > maxWords) {
      shown = words.slice(0, maxWords).join(" ") + "…";
      truncated = true;
    }
  }

  return truncated ? (
    <Tooltip title={full} arrow placement="top">
      <span className={className} style={{ cursor: "help" }}>
        {shown}
      </span>
    </Tooltip>
  ) : (
    <span className={className}>{shown}</span>
  );
};
