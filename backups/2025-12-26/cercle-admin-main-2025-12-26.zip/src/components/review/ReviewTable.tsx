import React, { useEffect, useMemo } from "react";
import { useSelector } from "react-redux";
import { fetchReviews } from "../../../src/redux/thunks/reviewThunks";
import { useAppDispatch } from "../../components/hooks/hooks";
import { ClipWithTooltip } from "./customToolTip";

// ✅ old DataTable
import DataTable, { DataTableColumn } from "../../components/modules/DataTable";

interface ReviewsTableProps {
  limit: number;
  search: string;
  currentPage: number;
}

const ReviewTable = ({ limit, search, currentPage }: ReviewsTableProps) => {
  const dispatch = useAppDispatch();

  const { reviews, loading, message, status } = useSelector(
    (state: any) => state.productReviews
  );

  useEffect(() => {
    dispatch(fetchReviews({ page: currentPage, limit, search }));
  }, [dispatch, search, limit, currentPage]);

  const rows = useMemo(
    () => (Array.isArray(reviews) ? reviews : []),
    [reviews]
  );

  const formatDate = (value?: string) => {
    if (!value) return "—";
    const d = new Date(value);
    return isNaN(d.getTime()) ? "—" : d.toLocaleDateString();
  };

  const columns: DataTableColumn<any>[] = useMemo(
    () => [
      {
        key: "review",
        header: "Reviews",
        render: (review) => {
          const comment =
            review?.order_item_review_comment ?? review?.comment ?? "";
          return <ClipWithTooltip text={comment} maxWords={15} />;
        },
        tdClassName: "align-top px-6 py-4 text-sm text-gray-800",
        thClassName: "text-left px-6 py-3",
      },
      {
        key: "store",
        header: "Store",
        render: (review) => {
          const shopLogo =
            review?.shop_logo_url ||
            "https://cdn.shopify.com/s/files/1/0595/2379/2944/files/No_image_available.webp?v=1756886203";
          const shopName = review?.shop_name || "—";

          return (
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gray-200 rounded-lg flex items-center justify-center overflow-hidden">
                {shopLogo ? (
                  <img
                    src={shopLogo}
                    alt={shopName}
                    className="w-8 h-8 rounded object-cover"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      target.src =
                        "https://cdn.shopify.com/s/files/1/0595/2379/2944/files/img_not_found_cercle.jpg?v=1757333158";
                    }}
                  />
                ) : (
                  <span className="text-xs text-gray-500">No Logo</span>
                )}
              </div>
              <span className="text-sm text-gray-800 font-medium">
                {shopName}
              </span>
            </div>
          );
        },
        tdClassName: "align-top px-5 py-4",
        thClassName: "text-left px-5 py-3",
      },
      {
        key: "product",
        header: "Product",
        render: (review) => {
          const productName = review?.product_name || "";
          const productImage =
            review?.variant_image_url ||
            "https://cdn.shopify.com/s/files/1/0595/2379/2944/files/No_image_available.webp?v=1756886203";

          return (
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gray-200 rounded-lg flex items-center justify-center overflow-hidden">
                {productImage ? (
                  <img
                    src={productImage}
                    alt={productName || "Product"}
                    className="w-8 h-8 rounded object-cover"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      target.src =
                        "https://cdn.shopify.com/s/files/1/0595/2379/2944/files/img_not_found_cercle.jpg?v=1757333158";
                    }}
                  />
                ) : (
                  <span className="text-xs text-gray-500">No Img</span>
                )}
              </div>

              <span className="text-sm text-gray-800">
                <ClipWithTooltip text={productName} maxWords={15} />
              </span>
            </div>
          );
        },
        tdClassName: "align-top px-5 py-4",
        thClassName: "text-left px-5 py-3",
      },
      {
        key: "user",
        header: "User",
        render: (review) => {
          const userName =
            review?.user_name ?? review?.customer_name ?? review?.user ?? "—";

          return <ClipWithTooltip text={userName} maxChars={18} />;
        },
        tdClassName: "align-top px-5 py-4 text-sm text-gray-800",
        thClassName: "text-left px-5 py-3",
      },
      {
        key: "date",
        header: "Date",
        render: (review) => {
          const dateValue =
            review?.order_item_review_created_at ??
            review?.created_at ??
            review?.updated_at ??
            null;

          return formatDate(dateValue);
        },
        tdClassName: "align-top px-5 py-4 text-sm text-gray-600",
        thClassName: "text-left px-5 py-3",
      },
    ],
    []
  );

  const emptyText =
    status === "error"
      ? message || "Failed to load reviews."
      : "No reviews found.";

  return (
    <div className="bg-white">
      <DataTable
        columns={columns}
        rows={rows}
        loading={Boolean(loading)}
        emptyText={emptyText}
        rowKey={(review, idx) =>
          review?.order_item_review_id ??
          review?.id ??
          `${review?.order_item_id || "row"}-${idx}`
        }
        // keep same styling as before
        wrapperClassName="overflow-x-auto bg-white"
        tableClassName="min-w-full border-collapse"
        theadClassName="bg-gray-50 border-b border-gray-200 text-sm font-medium text-gray-500"
        rowClassName="border-b border-gray-200 hover:bg-gray-50 transition-colors"
      />
    </div>
  );
};

export default ReviewTable;
