import {
  Card,
  CardMedia,
  Grid,
  Pagination,
  Typography,
  Modal,
  Box,
  CircularProgress,
  TextField,
  InputAdornment,
  Tooltip,
  Skeleton,
  IconButton,
} from "@mui/material";
import React, { useEffect, useState } from "react";
import Childstyle from "../Style/childstyle";
import { appUrl } from "../../redux/thunks/authThunks";
import Cookies from "js-cookie";
import Parentstyle from "../Style/Parentstyle";
import SearchIcon from "@mui/icons-material/Search";
import ClearAllOutlinedIcon from "@mui/icons-material/ClearAllOutlined";
type Product = {
  product_name: string;
  product_image_url: string;
  product_description?: string; // backend may use this
  description?: string; // or this
  variant_price?: number;
};

const Productslist = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(0);
  const [open, setOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [searchKeyword, setSearchKeyword] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");

  const [selectedProduct, setSelectedProduct] = useState<{
    image: string;
    name: string;
    description?: string;
  } | null>(null);

  const fetchProducts = async (page: number, search: string) => {
    try {
      setIsLoading(true);
      console.log(`Fetching products: page=${page}, search="${search}"`); // Debug log

      const response = await fetch(
        `${appUrl}/api/products/all?page=${page}&limit=20&search=${search}`,
        {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${Cookies.get("authToken")}`,
          },
        }
      );

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      console.log("API Response:", data); // Debug log

      setProducts(data.Products ?? []);
      setTotalPages(data?.pagination?.totalPages ?? 0);
    } catch (e) {
      console.error("Error fetching products:", e); // Debug log
      setProducts([]);
      setTotalPages(0);
    } finally {
      setIsLoading(false);
    }
  };

  // Debounce Effect (500ms)
  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedSearch(searchKeyword);
    }, 500);
    return () => clearTimeout(handler);
  }, [searchKeyword]);

  // Initial load
  useEffect(() => {
    fetchProducts(1, "");
  }, []);

  // When search changes, reset to page 1 and fetch with new search
  useEffect(() => {
    if (debouncedSearch !== searchKeyword) return; // Only run when debounce is complete
    setCurrentPage(1);
    fetchProducts(1, debouncedSearch);
  }, [debouncedSearch]);

  // FIXED: Use debouncedSearch instead of empty string
  const handlePageChange = async (
    _: React.ChangeEvent<unknown>,
    page: number
  ) => {
    console.log(`Page changed to: ${page}, search: "${debouncedSearch}"`); // Debug log
    setCurrentPage(page);
    await fetchProducts(page, debouncedSearch); // Use debouncedSearch here
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleImageClick = (product: Product) => {
    setSelectedProduct({
      image: product.product_image_url,
      name: product.product_name,
      description: product.product_description ?? product.description ?? "",
    });
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
    setSelectedProduct(null);
  };

  // Debug: Log current state
  useEffect(() => {
    console.log({
      currentPage,
      totalPages,
      productsCount: products.length,
      searchKeyword,
      debouncedSearch,
      isLoading,
    });
  }, [
    currentPage,
    totalPages,
    products.length,
    searchKeyword,
    debouncedSearch,
    isLoading,
  ]);
  const skeletons = Array.from({ length: 8 });

  return (
    <Parentstyle>
      <Childstyle>
        <h1 className="text-2xl font-semibold mb-2">Products</h1>

        <Card className="w-full p-5" sx={{ position: "relative" }}>
          <div className="flex py-5 justify-between items-center">
            <TextField
              size="small"
              label="Search"
              variant="outlined"
              autoComplete="off"
              // placeholder="e.g. Cercle"
              value={searchKeyword}
              onChange={(e) => setSearchKeyword(e.target.value)}
              fullWidth
              sx={{ maxWidth: 420 }}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <SearchIcon fontSize="small" />
                  </InputAdornment>
                ),
                endAdornment: (
                  <InputAdornment position="end">
                    {isLoading ? (
                      <CircularProgress size={16} />
                    ) : searchKeyword ? (
                      <IconButton
                        size="small"
                        onClick={() => setSearchKeyword("")}
                        edge="end"
                        aria-label="Clear search"
                      >
                        <ClearAllOutlinedIcon fontSize="small" />
                      </IconButton>
                    ) : null}
                  </InputAdornment>
                ),
              }}
            />
          </div>

          <Grid
            container
            spacing={3}
            sx={{
              justifyContent: { xs: "center", md: "center", lg: "flex-start" },
              opacity: isLoading ? 0.6 : 1,
              pointerEvents: isLoading ? "none" : "auto",
            }}
          >
            {isLoading
              ? skeletons.map((_, i) => (
                <Grid key={`s-${i}`} size={{ xs: 12, sm: 6, md: 4, lg: 3 }}>
                  <Card sx={{ height: 280, p: 2 }}>
                    <Skeleton
                      variant="rectangular"
                      height={180}
                      sx={{ borderRadius: 1 }}
                    />
                    <Skeleton variant="text" width="90%" sx={{ mt: 1 }} />
                    <Skeleton variant="text" width="40%" />
                  </Card>
                </Grid>
              ))
              : products?.map((product, index) => (
                <Grid
                  key={`${product.product_name}-${index}`}
                  size={{ xs: 12, sm: 6, md: 4, lg: 3 }}
                >
                  <Card
                    className="rounded-md"
                    sx={{
                      width: "100%",
                      height: 280,
                      display: "flex",
                      flexDirection: "column",
                      justifyContent: "space-between",
                      p: 2,
                    }}
                  >
                    <CardMedia
                      sx={{
                        height: 180,
                        borderRadius: "8px",
                        cursor: "pointer",
                      }}
                      image={
                        product.product_image_url ||
                        "https://cdn.shopify.com/s/files/1/0595/2379/2944/files/img_not_found_cercle.jpg?v=1757333158"
                      }
                      title={product.product_name}
                      onClick={() => handleImageClick(product)}
                    />
                    <div className="mt-2">
                      <Tooltip
                        title={product.product_name}
                        placement="bottom"
                      >
                        <Typography
                          fontSize={15}
                          component="div"
                          sx={{
                            textAlign: "start",
                            fontWeight: 500,
                            display: "-webkit-box",
                            WebkitLineClamp: 2,
                            WebkitBoxOrient: "vertical",
                            overflow: "hidden",
                            textOverflow: "ellipsis",
                            lineHeight: "1.4em",
                            minHeight: "2.8em",
                            cursor: "pointer",
                          }}
                        >
                          {product.product_name}
                        </Typography>
                      </Tooltip>

                      <Typography
                        fontSize={12}
                        sx={{ color: "text.secondary", textAlign: "start" }}
                      >
                        {product.variant_price
                          ? `Rs ${product.variant_price}`
                          : ""}
                      </Typography>
                    </div>
                  </Card>
                </Grid>
              ))}
          </Grid>

          {isLoading && (
            <Box
              sx={{
                position: "absolute",
                inset: 0,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                pointerEvents: "none",
              }}
            >
              <CircularProgress />
            </Box>
          )}

          {!isLoading && products.length === 0 && (
            <Box sx={{ textAlign: "center", py: 4 }}>
              <Typography variant="h6" color="text.secondary">
                {debouncedSearch
                  ? `No products found for "${debouncedSearch}"`
                  : "No products available"}
              </Typography>
            </Box>
          )}
        </Card>
      </Childstyle>

      {!isLoading && products.length > 0 && totalPages > 1 && (
        <div className="m-5 py-1">
          <Pagination
            onChange={handlePageChange}
            count={totalPages}
            page={currentPage}
            variant="outlined"
            shape="rounded"
            color="primary"
          />
        </div>
      )}

      <Modal open={open} onClose={handleClose}>
        <Box
          sx={{
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            backgroundColor: "white",
            maxWidth: "90%",
            maxHeight: "90%",
            overflow: "auto",
            boxShadow: 10,
            borderRadius: 2,
            p: 2,
          }}
        >
          {selectedProduct && (
            <>
              <Typography
                variant="h6"
                gutterBottom
                sx={{ fontWeight: 700, mb: 2 }}
              >
                {selectedProduct.name}
              </Typography>

              <img
                src={
                  selectedProduct.image ||
                  "https://cdn.shopify.com/s/files/1/0595/2379/2944/files/img_not_found_cercle.jpg?v=1757333158"
                }
                alt={selectedProduct.name}
                style={{
                  width: "100%",
                  height: "auto",
                  maxHeight: "60vh",
                  objectFit: "contain",
                  marginBottom: 20,
                  borderRadius: 8,
                }}
                loading="lazy"
                onError={(e) => {
                  const target = e.target as HTMLImageElement;
                  target.src = "https://cdn.shopify.com/s/files/1/0595/2379/2944/files/img_not_found_cercle.jpg?v=1757333158";
                }}
              />

              <Box sx={{ px: 1 }}>
                <Typography
                  variant="inherit"
                  sx={{ fontWeight: "bold", color: "text.secondary", mb: 0.5 }}
                >
                  Description
                </Typography>
                <Typography
                  variant="body2"
                  color="text.primary"
                  sx={{ lineHeight: 1.6, whiteSpace: "pre-line" }}
                >
                  {selectedProduct.description || "No description available."}
                </Typography>
              </Box>
            </>
          )}
        </Box>
      </Modal>
    </Parentstyle>
  );
};

export default Productslist;
