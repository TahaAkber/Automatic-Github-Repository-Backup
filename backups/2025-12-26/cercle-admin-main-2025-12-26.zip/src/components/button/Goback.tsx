import React from "react";
import { Button, Typography } from "@mui/material";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";

const GoBackButton: React.FC<{ onClick: () => void }> = ({ onClick }: any) => {
  return (
    <Button
      onClick={onClick}
      variant="text"
      startIcon={<ArrowBackIcon />}
      sx={{
        color: "#5a5a5a",
        textTransform: "none",
        fontSize: "15px",
        display: "flex",
        alignItems: "center",
        "&:hover": {
          backgroundColor: "transparent",
          color: "#333",
        },
      }}
    >
      <Typography variant="body2">go back</Typography>
    </Button>
  );
};

export default GoBackButton;
