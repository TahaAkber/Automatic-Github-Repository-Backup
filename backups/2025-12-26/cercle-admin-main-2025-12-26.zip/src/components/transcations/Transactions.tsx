import { Card, Divider, Pagination } from "@mui/material";
import React from "react";
import TransactionTable from "./TransactionTable";
import Parentstyle from "../Style/Parentstyle";
import Childstyle from "../Style/childstyle";
import { useRolePermissions } from "../../components/functions/useRolePermissions";
import { RoleLike } from "../../components/functions/Roles";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router";
import GoBackButton from "../button/Goback";

const Transactions: React.FC = () => {
  const navigate = useNavigate();
  // permissions
  const rawRoles = useSelector((s: any) => s.auth.user?.roles) as
    | RoleLike[]
    | undefined;
  const { can } = useRolePermissions(rawRoles);
  const canRead = can("transactions", "read");
  console.log("canRead", canRead);
  return (
    <Parentstyle>
      <div className="mb-3">
        <GoBackButton onClick={() => navigate(-1)} />
      </div>
      <Childstyle>
        <div className="flex justify-between pb-5">
          <h1 className="text-2xl font-semibold mb-2">Transactions</h1>
        </div>
        <Card>
          <TransactionTable canRead={canRead} />
          <Divider />
          <div className="m-5 py-1">
            {canRead && (
              <Pagination
                count={1}
                variant="outlined"
                shape="rounded"
                color="primary"
              />
            )}
          </div>
        </Card>
      </Childstyle>
    </Parentstyle>
  );
};

export default Transactions;
