import React from "react";
import AccessDenied from "../../components/merchant/Accessdenied";

type TableBodyRowType = {
  title: string;
  date: string;
  description: string; // Merchant
  transactionType: string;
  orderAmount: string;
  debit: string;
  credit: string;
  closingBalance: string;
};

const rowsData: TableBodyRowType[] = [
  {
    title: "Transaction for order #1055",
    date: "06 May, 2025",
    description: "Outfitter.",
    transactionType: "Purchase",
    orderAmount: "$199.99",
    debit: "$199.99",
    credit: "$0.00",
    closingBalance: "$800.01",
  },
  {
    title: "Subscription Charges",
    date: "06 May, 2025",
    description: "Outfitter.",
    transactionType: "Purchase",
    orderAmount: "$199.99",
    debit: "$199.99",
    credit: "$0.00",
    closingBalance: "$800.01",
  },
  {
    title: "Subscribed a shop tile subscription",
    date: "06 May, 2025",
    description: "Outfitter.",
    transactionType: "Purchase",
    orderAmount: "$199.99",
    debit: "$199.99",
    credit: "$0.00",
    closingBalance: "$800.01",
  },
  {
    title: "Credits against voucher created",
    date: "06 May, 2025",
    description: "Outfitter.",
    transactionType: "Purchase",
    orderAmount: "$199.99",
    debit: "$199.99",
    credit: "$0.00",
    closingBalance: "$800.01",
  },
  {
    title: "Trasaction for order #1055",
    date: "06 May, 2025",
    description: "Outfitter.",
    transactionType: "Purchase",
    orderAmount: "$199.99",
    debit: "$199.99",
    credit: "$0.00",
    closingBalance: "$800.01",
  },
  {
    title: "Transaction for order #1055",
    date: "06 May, 2025",
    description: "Outfitter.",
    transactionType: "Purchase",
    orderAmount: "$199.99",
    debit: "$199.99",
    credit: "$0.00",
    closingBalance: "$800.01",
  },
  {
    title: "Subscription Charges",
    date: "06 May, 2025",
    description: "Outfitter.",
    transactionType: "Purchase",
    orderAmount: "$199.99",
    debit: "$199.99",
    credit: "$0.00",
    closingBalance: "$800.01",
  },
  {
    title: "Subscribed a shop tile subscription",
    date: "06 May, 2025",
    description: "Outfitter.",
    transactionType: "Purchase",
    orderAmount: "$199.99",
    debit: "$199.99",
    credit: "$0.00",
    closingBalance: "$800.01",
  },
  {
    title: "Credits against voucher created",
    date: "06 May, 2025",
    description: "Outfitter.",
    transactionType: "Purchase",
    orderAmount: "$199.99",
    debit: "$199.99",
    credit: "$0.00",
    closingBalance: "$800.01",
  },
  {
    title: "Trasaction for order #1055",
    date: "06 May, 2025",
    description: "Outfitter.",
    transactionType: "Purchase",
    orderAmount: "$199.99",
    debit: "$199.99",
    credit: "$0.00",
    closingBalance: "$800.01",
  },
];
interface TableProps {
  canRead: boolean;
}
const TransactionTable: React.FC<TableProps> = ({ canRead }) => {
  // READ gate for transactions
  if (!canRead) {
    return (
      <AccessDenied
        subtitle="Your account is missing the 'transactions:read' permission. Contact an admin if you need access."
        secondaryActionText="Contact admin"
        onSecondaryAction={() => {
          // e.g., open support route or mailto
          window.open("https://cymbiote.com/contact-us/", "_blank");
        }}
      />
    );
  }

  return (
    <div className="overflow-x-auto rounded-lg border-gray-200 shadow-sm py-5">
      <table className="min-w-full text-sm text-left">
        <thead className="border-b text-gray-500 font-semibold">
          <tr>
            <th className="px-6 py-3">Transaction Details</th>
            <th className="px-6 py-3">Date</th>
            <th className="px-6 py-3">Merchant</th>
            <th className="px-6 py-3">Transaction Type</th>
            <th className="px-6 py-3">Order Amount</th>
            <th className="px-6 py-3">Debit</th>
            <th className="px-6 py-3">Credit</th>
            <th className="px-6 py-3">Closing Balance</th>
          </tr>
        </thead>
        <tbody>
          {rowsData.map((row, index) => (
            <tr
              key={index}
              className="border-b last:border-none hover:bg-gray-50 transition"
            >
              <td className="px-6 py-4 text-blue-700 font-semibold">
                {row.title}
              </td>
              <td className="px-6 py-4 whitespace-nowrap">{row.date}</td>
              <td className="px-6 py-4">
                <div className="flex items-center gap-2">
                  <img
                    src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQoFRQjM-wM_nXMA03AGDXgJK3VeX7vtD3ctA&s"
                    alt="avatar"
                    className="w-8 h-8 rounded object-cover"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      target.src = "https://cdn.shopify.com/s/files/1/0595/2379/2944/files/img_not_found_cercle.jpg?v=1757333158";
                    }}
                  />
                  <span className="font-medium text-gray-800">
                    {row.description}
                  </span>
                </div>
              </td>
              <td className="px-6 py-4 text-wrap">{row.transactionType}</td>
              <td className="px-6 py-4 text-wrap">{row.orderAmount}</td>
              <td className="px-6 py-4 text-wrap">{row.debit}</td>
              <td className="px-6 py-4 text-wrap">{row.credit}</td>
              <td className="px-6 py-4 text-wrap">{row.closingBalance}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default TransactionTable;
