import { useState } from "react";
import {
  Button,
  Card,
  Grid,
  TextField,
  Typography,
  CircularProgress,
} from "@mui/material";
import Parentstyle from "../Style/Parentstyle";
import Childstyle from "../Style/childstyle";
import { useAppDispatch } from "../hooks/hooks";
import { registerUser } from "../../redux/thunks/authThunks";
import TempModal from "./UserModal";
import UserCheckbox from "./UserRoleCheckbox";
import { useNavigate } from "react-router";
import GoBackButton from "../button/Goback";

const CreateRole = () => {
  const navigate = useNavigate();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [checkedRoles, setCheckedRoles] = useState<{
    [key: string]: { read: boolean; write: boolean };
  }>({});
  const [roles, setRoles] = useState<any[]>([]);
  const [_, setShowSpinner] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [createrole, setRole] = useState({
    username: "",
    useremail: "",
    roles: [],
  });
  const dispatch = useAppDispatch();
  const selectedRoles = Object.entries(checkedRoles)
    .filter(([_, val]) => val.read || val.write)
    .map(([roleId, val]) => ({
      roleId: Number(roleId),
      read: val.read,
      write: val.write,
    }));

  const handleCreateRole = async () => {
    if (
      !createrole.username ||
      !createrole.useremail ||
      selectedRoles.length === 0
    ) {
      setError("Please fill in all fields and select at least one role.");
      return;
    }

    setLoading(true);
    setShowSpinner(true);

    try {
      await dispatch(
        registerUser({
          username: createrole.username,
          email: createrole.useremail,
          roles: selectedRoles,
        })
      );
      console.log("newUserObject", createrole, selectedRoles);

      setRole({
        username: "",
        useremail: "",
        roles: [],
      });

      setTimeout(() => {
        setLoading(false);
        setShowSpinner(false);
        setIsModalOpen(true);
      }, 2000);
    } catch (error) {
      console.error("Role Creation Failed", error);
      setLoading(false);
      setError("Failed to create role. Please try again.");
    }
  };

  return (
    <Parentstyle>
      <div className="mb-3">
        <GoBackButton onClick={() => navigate(-1)} />
      </div>
      <Childstyle>
        <Typography variant="h6" fontWeight="medium">
          Create Role
        </Typography>
        <Card
          sx={{
            borderRadius: "12px",
            border: "1px solid #e0e0e0",
            boxShadow: 1,
            paddingTop: 3,
            paddingBottom: 2,
          }}
        >
          <Grid
            container
            spacing={2}
            alignItems="center"
            justifyContent="space-between"
            flexWrap="wrap"
            className="max-w-full"
          >
            <Grid size={{ xs: 12, md: 6 }} className="px-5">
              <TextField
                id="User Name"
                label="User Name"
                variant="outlined"
                autoComplete="off"
                fullWidth
                size="small"
                value={createrole.username}
                onChange={(e) =>
                  setRole((prev) => ({ ...prev, username: e.target.value }))
                }
              />
            </Grid>

            <Grid size={{ xs: 12, md: 6 }} className="px-5" container>
              <TextField
                id="User Email"
                label="User Email"
                autoComplete="off"
                variant="outlined"
                fullWidth
                size="small"
                value={createrole.useremail}
                onChange={(e) =>
                  setRole((prev) => ({ ...prev, useremail: e.target.value }))
                }
              />
            </Grid>
            <Grid className="px-5 w-full" container>
              <div>
                <UserCheckbox
                  setCheckedRoles={setCheckedRoles}
                  checkedRoles={checkedRoles}
                  setRoles={setRoles}
                  roles={roles}
                />
              </div>
            </Grid>
            {error && (
              <Typography variant="body2" color="error" sx={{ px: 3 }}>
                {error}
              </Typography>
            )}

            <div className="px-5 mb-3">
              <Button
                variant="contained"
                size="small"
                color="primary"
                sx={{ fontWeight: 400, padding: 1 }}
                onClick={handleCreateRole}
                disabled={loading}
              >
                {loading ? (
                  <CircularProgress size={24} color="inherit" />
                ) : (
                  "Create Role"
                )}
              </Button>
            </div>
          </Grid>
        </Card>
      </Childstyle>
      {isModalOpen && (
        <TempModal open={isModalOpen} onClose={() => setIsModalOpen(false)} />
      )}
    </Parentstyle>
  );
};

export default CreateRole;
