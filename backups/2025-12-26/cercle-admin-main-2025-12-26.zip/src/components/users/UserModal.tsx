import Modal from "@mui/material/Modal";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import IconButton from "@mui/material/IconButton";
import CloseIcon from "@mui/icons-material/Close";
import { useSelector } from "react-redux";

const style = {
  position: "absolute" as "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  width: 500,
  bgcolor: "rgba(255, 255, 255, 0.9)",
  border: "1px solid #00FFFF",
  boxShadow: 25,
  p: 4,
};

const TempModal = ({ open, onClose }: any) => {
  const { message, tempPassword, email } = useSelector(
    (state: any) => state.authRegister
  );

  return (
    <Modal open={open} onClose={onClose}>
      <Box sx={style}>
        <IconButton
          onClick={onClose}
          sx={{
            position: "absolute",
            top: 8,
            right: 8,
          }}
        >
          <CloseIcon />
        </IconButton>
        <Typography sx={{ mt: 2, color: "green" }}>{message}</Typography>
        <Typography sx={{ mt: 2 }} fontSize={15}>
          <strong>Email:</strong> {email || "Not Available"}
        </Typography>
        <Typography sx={{ mt: 2 }} fontSize={15}>
          <strong>Temporary Password:</strong> {tempPassword || "Not Available"}
        </Typography>
      </Box>
    </Modal>
  );
};

export default TempModal;
