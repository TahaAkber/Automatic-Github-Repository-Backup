import {
  Button,
  Card,
  Pagination,
  Snackbar,
  Alert,
} from "@mui/material";
import { useNavigate } from "react-router";
import UserTable from "./UserTable";
import Parentstyle from "../Style/Parentstyle";
import Childstyle from "../Style/childstyle";
import { useAppDispatch } from "../hooks/hooks";
import { useEffect, useState } from "react";
import { fetchadminUsers } from "../../redux/thunks/userThunks";
import { useSelector } from "react-redux";
import { deleteUser } from "../../utils/ApiExtras";
import { RootState } from "src/redux/store/store";
import { RoleLike } from "../../components/functions/Roles";
import { useRolePermissions } from "../../components/functions/useRolePermissions";
import DeleteModal from "../../components/modules/DeleteModal";

const Users = () => {
  const navigate = useNavigate();
  const dispatch = useAppDispatch();
  const { user } = useSelector((s: RootState) => s.auth);
  const rawRoles = useSelector((state: any) => state.auth.user?.roles) as
    | RoleLike[]
    | undefined;

  const { can } = useRolePermissions(rawRoles);

  const isGlobalUser =
    user?.roles
      ?.map((role) => role.admin_role_name)
      .some(
        (role) =>
          role?.toLowerCase() === "global" || role?.toLowerCase() === "users"
      ) || false;

  const [currentPage, setCurrentPage] = useState(1);

  const [selectedUserId, setSelectedUserId] = useState<string | number | null>(
    null
  );

  const [confirmModalopen, setConfirmModalOpen] = useState(false);

  // Snackbar
  const [snackbarOpen, setSnackbarOpen] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState("");
  const [snackbarSeverity, setSnackbarSeverity] = useState<"success" | "error">(
    "success"
  );

  const openDeleteModal = (userId: string | number) => {
    setSelectedUserId(userId);
  };

  const handleCloseModal = () => {
    setSelectedUserId(null);
    setConfirmModalOpen(false);
  };

  const handleConfirmDelete = async () => {
    if (!selectedUserId) return;
    try {
      await deleteUser(selectedUserId);
      setSnackbarMessage("User deleted successfully");
      setSnackbarSeverity("success");
      setSnackbarOpen(true);

      // refresh current page
      dispatch(fetchadminUsers({ page: currentPage }));
    } catch (err) {
      setSnackbarMessage("Failed to delete user");
      setSnackbarSeverity("error");
      setSnackbarOpen(true);
    } finally {
      handleCloseModal();
    }
  };

  const handlePageChange = (_: React.ChangeEvent<unknown>, page: number) => {
    setCurrentPage(page);
  };

  useEffect(() => {
    dispatch(fetchadminUsers({ page: currentPage }));
  }, [dispatch, currentPage]);

  const { pagination } = useSelector((state: any) => state.users);

  return (
    <Parentstyle>
      <Childstyle>
        <div className="flex justify-between pb-5">
          <h1 className="text-2xl font-semibold mb-2">Users</h1>

          {isGlobalUser && (
            <Button
              variant="contained"
              size="small"
              onClick={() => navigate("/users/createrole")}
              sx={{ fontWeight: 300, textTransform: "none" }}
              disabled={!can("users", "write")}
            >
              Create User
            </Button>
          )}
        </div>

        <Card>
          <UserTable
            // Pass modal trigger instead of immediate delete
            handledeleteuser={openDeleteModal}
            isGlobalUser={isGlobalUser}
            setConfirmModalOpen={setConfirmModalOpen}
            confirmModalopen={confirmModalopen}
            setSelectedUserId={setSelectedUserId}
          />

          <div className="m-5 py-1">
            {can("users", "read") && pagination?.totalPages > 1 && (
              <Pagination
                onChange={handlePageChange}
                count={pagination?.totalPages || 1}
                page={currentPage}
                variant="outlined"
                shape="rounded"
                color="primary"
              />
            )}
          </div>
        </Card>

        <DeleteModal
          handleConfirmDelete={handleConfirmDelete}
          modalopen={confirmModalopen}
          handleClose={handleCloseModal}
          title="Are you sure you want to delete this User?"
        />

        {/* Snackbar */}
        <Snackbar
          open={snackbarOpen}
          autoHideDuration={2000}
          onClose={() => setSnackbarOpen(false)}
          anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
        >
          <Alert
            onClose={() => setSnackbarOpen(false)}
            severity={snackbarSeverity}
            sx={{ width: "100%" }}
          >
            {snackbarMessage}
          </Alert>
        </Snackbar>
      </Childstyle>
    </Parentstyle>
  );
};

export default Users;
