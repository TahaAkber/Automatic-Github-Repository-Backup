import { useEffect, useState } from "react";
import {
  Button,
  Card,
  FormControl,
  FormControlLabel,
  FormLabel,
  Grid,
  Radio,
  RadioGroup,
  TextField,
  Typography,
  Alert,
  CircularProgress,
} from "@mui/material";
import Parentstyle from "../Style/Parentstyle";
import Childstyle from "../Style/childstyle";
import { fetchRoles, updateuserRoles } from "../../utils/ApiExtras";
import { useNavigate, useParams } from "react-router";
import UserCheckbox from "./UserRoleCheckbox";
import GoBackButton from "../button/Goback";

const EditRole = () => {
  const navigate = useNavigate();
  const { userId } = useParams();

  const [createrole, setRole] = useState<{
    username: string;
    roles: any[];
    status: boolean | null;
  }>({
    username: "",
    roles: [] as any[],
    status: null,
  });
  const [_, setShowSpinner] = useState(false);
  const [roles, setRoles] = useState<any[]>([]);
  const [checkedRoles, setCheckedRoles] = useState<{
    [key: string]: { read: boolean; write: boolean };
  }>({});
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [successMessage, setSuccessMessage] = useState("");

  useEffect(() => {
    const getRoles = async () => {
      try {
        const rolesData = await fetchRoles();
        setRoles(rolesData);
      } catch (error) {
        console.error("Error fetching roles:", error);
      }
    };
    getRoles();
  }, []);
  const selectedRoles = Object.entries(checkedRoles)
    .filter(([_, val]) => val.read || val.write)
    .map(([roleId, val]) => ({
      roleId: Number(roleId),
      read: val.read,
      write: val.write,
    }));
  const handleCreateRole = async () => {
    setError("");
    setSuccessMessage("");

    if (!createrole.username || selectedRoles.length === 0) {
      setError("Please fill in all fields and select at least one role.");
      return;
    }

    setLoading(true);
    setShowSpinner(true);
    console.log(
      "object",
      userId,
      createrole.username,
      createrole.status ?? true,
      selectedRoles
    );
    try {
      const res = await updateuserRoles(
        userId,
        createrole.username,
        createrole.status ?? true,
        selectedRoles
      );

      const success =
        res?.success === true ||
        res?.status === 200 ||
        res?.updateroles?.success === true;

      const errMsg =
        res?.message ||
        res?.updateroles?.message ||
        "Failed to edit role. Please try again.";

      if (!success) {
        setError(errMsg);
        return;
      }

      setSuccessMessage("User role has been successfully updated.");
    } catch (e: any) {
      setError(
        e?.response?.data?.message ||
          e?.message ||
          "Failed to edit role. Please try again."
      );
    } finally {
      setCheckedRoles({});
      navigate(-1);
      setTimeout(() => {
        setLoading(false);
        setShowSpinner(false);
      }, 500);
    }
  };

  return (
    <Parentstyle>
      <div className="mb-3">
        <GoBackButton onClick={() => navigate(-1)} />
      </div>
      <Childstyle>
        <Typography variant="h6" fontWeight="medium">
          Edit Role
        </Typography>
        <Card
          sx={{
            borderRadius: "12px",
            border: "1px solid #e0e0e0",
            boxShadow: 1,
          }}
        >
          <Grid container direction="column" spacing={2}>
            <Grid
              container
              spacing={0}
              alignItems="center"
              justifyContent="space-between"
              flexWrap="wrap"
              className="max-w-full"
            >
              <Grid size={{ xs: 12, md: 6 }} className="p-5">
                <TextField
                  id="User Name"
                  label="User Name"
                  variant="outlined"
                  autoComplete="off"
                  fullWidth
                  size="small"
                  value={createrole.username}
                  onChange={(e) =>
                    setRole((prev) => ({ ...prev, username: e.target.value }))
                  }
                />
              </Grid>
            </Grid>
            <Grid className="px-5 w-full" container>
              <div>
                <UserCheckbox
                  setCheckedRoles={setCheckedRoles}
                  checkedRoles={checkedRoles}
                  setRoles={setRoles}
                  roles={roles}
                />
              </div>
            </Grid>

            <div className="px-5 mx-1">
              <FormControl>
                <FormLabel
                  id="demo-radio-buttons-group-label"
                  sx={{ fontSize: "0.875rem" }}
                >
                  User Status
                </FormLabel>
                <RadioGroup
                  aria-labelledby="demo-radio-buttons-group-label"
                  defaultValue="Active"
                  name="radio-buttons-group"
                  row
                >
                  <FormControlLabel
                    value="Active"
                    control={
                      <Radio
                        sx={{ padding: "0.5rem", "& svg": { fontSize: 18 } }}
                      />
                    }
                    onChange={() =>
                      setRole((prev) => ({ ...prev, status: true }))
                    }
                    label={<span style={{ fontSize: "0.875rem" }}>Active</span>}
                  />
                  <FormControlLabel
                    value="In Active"
                    control={
                      <Radio
                        sx={{ padding: "0.5rem", "& svg": { fontSize: 18 } }}
                      />
                    }
                    label={
                      <span style={{ fontSize: "0.875rem" }}>In Active</span>
                    }
                    onChange={() =>
                      setRole((prev) => ({ ...prev, status: false }))
                    }
                  />
                </RadioGroup>
              </FormControl>
            </div>

            {error && (
              <Typography variant="body2" color="error" sx={{ px: 3 }}>
                {error}
              </Typography>
            )}

            {/* Display Success Alert */}
            {successMessage && (
              <Alert severity="success" sx={{ mb: 2 }}>
                {successMessage}
              </Alert>
            )}

            <div className="px-5 mb-3">
              <Button
                variant="contained"
                size="small"
                color="primary"
                sx={{ fontWeight: 400 }}
                onClick={handleCreateRole}
                disabled={loading}
              >
                {loading ? (
                  <CircularProgress size={24} color="inherit" />
                ) : (
                  "Save Changes"
                )}
              </Button>
            </div>
          </Grid>
        </Card>
      </Childstyle>
    </Parentstyle>
  );
};

export default EditRole;
