import React, { useEffect, useMemo, useState } from "react";
import { Tooltip, IconButton } from "@mui/material";
import EditIcon from "@mui/icons-material/Edit";
import DeleteOutlineIcon from "@mui/icons-material/DeleteOutline";
import { useNavigate } from "react-router";
import { useSelector } from "react-redux";

import { AntSwitch } from "../button/Switch";
import { updateuserstatus } from "../../utils/ApiExtras";
import { RoleLike } from "../functions/Roles";
import AccessDenied from "../../components/merchant/Accessdenied";
import { useRolePermissions } from "../../components/functions/useRolePermissions";
import DataTable, { DataTableColumn } from "../modules/DataTable";

type Props = {
  handledeleteuser: (id: string | number) => void;
  isGlobalUser: boolean;
  setConfirmModalOpen: (open: boolean) => void;
  confirmModalopen: boolean;
  setSelectedUserId: (id: string | number | null) => void;
};

const UserTable: React.FC<Props> = ({
  setConfirmModalOpen,
  setSelectedUserId,
}) => {
  
  const navigate = useNavigate();
  const { users } = useSelector((state: any) => state.users);

  const [switchStates, setSwitchStates] = useState<{ [key: string]: boolean }>(
    () => {
      const initialState: { [key: string]: boolean } = {};
      (users ?? []).forEach((row: any) => {
        initialState[row.admin_user_id] = !!row.admin_user_isactive;
      });
      return initialState;
    }
  );

  useEffect(() => {
    const next: { [key: string]: boolean } = {};
    (users ?? []).forEach((row: any) => {
      next[row.admin_user_id] = !!row.admin_user_isactive;
    });
    setSwitchStates(next);
  }, [users]);

  const rawRoles = useSelector((state: any) => state.auth.user?.roles) as
    | RoleLike[]
    | undefined;

  const { can } = useRolePermissions(rawRoles);
  const canRead = can("users", "read");
  const canWrite = can("users", "write");

  if (!canRead) {
    return (
      <AccessDenied
        subtitle="Your account is missing read permissions for user. Contact an admin if you need access."
        secondaryActionText="Contact admin"
        onSecondaryAction={() =>
          window.open("https://cymbiote.com/contact-us/", "_blank")
        }
      />
    );
  }

  const handleSwitchChange = (userId: string, currentStatus: boolean) => {
    if (!canWrite) return;
    const updatedStatus = !currentStatus;

    setSwitchStates((prev) => ({ ...prev, [userId]: updatedStatus }));

    updateuserstatus(userId, updatedStatus).catch(() => {
      setSwitchStates((prev) => ({ ...prev, [userId]: currentStatus }));
    });
  };

  const columns: DataTableColumn<any>[] = useMemo(
    () => [
      {
        key: "admin_user_name",
        header: "User Name",
        render: (row) => row?.admin_user_name ?? "Admin Name",
      },
      {
        key: "created_at",
        header: "Assign Date",
        render: (row) =>
          row?.created_at ? String(row.created_at).slice(0, 10) : "N/A",
      },
      {
        key: "Roles",
        header: "Workspace",
        tdClassName:
          "px-6 whitespace-nowrap max-w-xs overflow-hidden text-ellipsis",
        render: (row) => (
          <div className="flex flex-wrap gap-2">
            {(row?.Roles ? String(row.Roles).split(",") : []).map(
              (role: string, idx: number) => (
                <span
                  key={idx}
                  className="border px-2 py-0.5 text-xs rounded-sm text-gray-700 border-gray-300 bg-gray-100"
                >
                  {role.trim()}
                </span>
              )
            )}
          </div>
        ),
      },
      {
        key: "status",
        header: "Status",
        render: (row) => {
          const id = row?.admin_user_id;
          const checked = switchStates[id] ?? !!row?.admin_user_isactive;

          return canWrite ? (
            <AntSwitch
              checked={checked}
              color="primary"
              onChange={() => handleSwitchChange(id, checked)}
              inputProps={{ "aria-label": "controlled" }}
            />
          ) : (
            <Tooltip title="You need users:write (or global) to change status">
              <span>
                <AntSwitch checked={checked} color="primary" disabled />
              </span>
            </Tooltip>
          );
        },
      },
      {
        key: "action",
        header: "Action",
        render: (row) => (
          <div className="flex items-center gap-2">
            {canWrite ? (
              <Tooltip title="Edit">
                <IconButton
                  size="small"
                  onClick={() =>
                    navigate(`/users/editrole/${row?.admin_user_id}`)
                  }
                >
                  <EditIcon fontSize="small" color="primary" />
                </IconButton>
              </Tooltip>
            ) : (
              <Tooltip title="You need users:write (or global) to edit">
                <span>
                  <IconButton size="small" disabled>
                    <EditIcon fontSize="small" color="disabled" />
                  </IconButton>
                </span>
              </Tooltip>
            )}

            {canWrite ? (
              <Tooltip title="Delete">
                <IconButton
                  size="small"
                  onClick={() => {
                    setSelectedUserId(row?.admin_user_id);
                    setConfirmModalOpen(true);
                  }}
                >
                  <DeleteOutlineIcon fontSize="medium" color="error" />
                </IconButton>
              </Tooltip>
            ) : (
              <Tooltip title="You need users:write (or global) to delete">
                <span>
                  <IconButton size="small" disabled>
                    <DeleteOutlineIcon fontSize="medium" color="disabled" />
                  </IconButton>
                </span>
              </Tooltip>
            )}
          </div>
        ),
      },
    ],
    [canWrite, navigate, setConfirmModalOpen, setSelectedUserId, switchStates]
  );

  return (
    <DataTable
      columns={columns}
      rows={users ?? []}
      rowKey={(row) => row?.admin_user_id}
      loading={!users} // replace with redux loading if you have it
      emptyText="No users found"
    />
  );
};

export default UserTable;
