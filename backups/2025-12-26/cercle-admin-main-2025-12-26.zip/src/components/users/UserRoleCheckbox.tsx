import { useEffect } from "react";
import {
  Box,
  Checkbox,
  FormControlLabel,
  Typography,
  Card,
  Divider,
} from "@mui/material";
import { fetchRoles } from "../../utils/ApiExtras";

interface userCheckBox {
  setCheckedRoles: (checkedRoles: any) => void;
  checkedRoles: any;
  setRoles: (roles: any) => void;
  roles: any;
}

export default function UserCheckbox({
  setCheckedRoles,
  checkedRoles,
  setRoles,
  roles,
}: userCheckBox) {
  useEffect(() => {
    const getRoles = async () => {
      try {
        console.log("testing");
        const rolesData = await fetchRoles();
        setRoles(rolesData);

        const initialState: any = {};
        rolesData.forEach((role: any) => {
          initialState[role.admin_role_id] = { read: false, write: false };
        });
        setCheckedRoles(initialState);
      } catch (error) {
        console.error("Error fetching roles:", error);
      }
    };
    getRoles();
  }, []);

  const handleParentChange = (roleId: string, checked: boolean) => {
    setCheckedRoles((prev: any) => ({
      ...prev,
      [roleId]: { read: checked, write: checked },
    }));
  };

  const handleChildChange = (
    roleId: string,
    type: "read" | "write",
    checked: boolean
  ) => {
    setCheckedRoles((prev: any) => ({
      ...prev,
      [roleId]: {
        ...prev[roleId],
        [type]: checked,
      },
    }));
  };

  return (
    <Card
      sx={{
        borderRadius: "8px",
        border: "1px solid #e0e0e0",
        boxShadow: 0,
        p: 2,

        width: "100%",
      }}
    >
      <Typography variant="subtitle1" fontWeight="medium" gutterBottom>
        Assign Roles
      </Typography>
      <Divider sx={{ mb: 2 }} />

      <Box
        sx={{
          display: "flex",
          flexWrap: "wrap",
          flexDirection: "row",
          gap: 5,
          alignItems: "center",
          marginLeft: 2,
        }}
      >
        {roles.map((role: any) => {
          const state = checkedRoles[role.admin_role_id] || {
            read: false,
            write: false,
          };
          const allChecked = state.read && state.write;
          const indeterminate = state.read !== state.write;

          return (
            <Box
              key={role.admin_role_id}
              sx={{
                border: "1px solid #f0f0f0",
                borderRadius: "6px",
                p: 2,
                backgroundColor: "#fafafa",
                minWidth: 220,
              }}
            >
              {/* Parent */}
              <Box sx={{ display: "flex", alignItems: "center", mb: 1 }}>
                <FormControlLabel
                  label={role.admin_role_name.toUpperCase()}
                  control={
                    <Checkbox
                      checked={allChecked}
                      indeterminate={indeterminate}
                      onChange={(e) =>
                        handleParentChange(role.admin_role_id, e.target.checked)
                      }
                    />
                  }
                />
              </Box>

              {/* Child Permissions */}
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column", // FIXED typo
                  ml: 4,
                  gap: 1,
                }}
              >
                <FormControlLabel
                  label="Read"
                  control={
                    <Checkbox
                      checked={state.read}
                      onChange={(e) =>
                        handleChildChange(
                          role.admin_role_id,
                          "read",
                          e.target.checked
                        )
                      }
                    />
                  }
                />
                <FormControlLabel
                  label="Write"
                  control={
                    <Checkbox
                      checked={state.write}
                      onChange={(e) =>
                        handleChildChange(
                          role.admin_role_id,
                          "write",
                          e.target.checked
                        )
                      }
                    />
                  }
                />
              </Box>
            </Box>
          );
        })}
      </Box>
    </Card>
  );
}
