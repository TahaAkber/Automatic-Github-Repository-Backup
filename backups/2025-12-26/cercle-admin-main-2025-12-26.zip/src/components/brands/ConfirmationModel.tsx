// ConfirmationModel.tsx
import React, { useState, useEffect } from "react";
import {
  Box,
  Button,
  Fade,
  Modal,
  Typography,
  TextField,
  Stack,
} from "@mui/material";

type Props = {
  open: boolean;
  action: "approve" | "reject";
  brandName?: string;
  loading?: boolean;
  onClose: () => void;
  onSave: (note: string) => void;
};

const ConfirmationModel: React.FC<Props> = ({
  open,
  action,
  brandName,
  loading = false,
  onClose,
  onSave,
}) => {
  const [note, setNote] = useState("");
  console.log("brandname", brandName);
  useEffect(() => {
    if (open) setNote("");
  }, [open]);

  const title =
    action === "approve"
      ? "ENTER A NOTE TO APPROVE THIS BRAND"
      : "ENTER A NOTE TO REJECT THIS BRAND";

  return (
    <Modal open={open} onClose={onClose} closeAfterTransition>
      <Fade in={open}>
        <Box
          sx={{
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            width: 460,
            bgcolor: "background.paper",
            borderRadius: 2,
            boxShadow: 24,
            p: 3,
          }}
        >
          <Typography variant="body1" sx={{ mb: 0.5 }}>
            {title}
          </Typography>
          {brandName && (
            <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
              Brand: <strong>{brandName}</strong>
            </Typography>
          )}

          <TextField
            autoFocus
            fullWidth
            multiline
            minRows={3}
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder="Optional note..."
            sx={{ mt: 1.5 }}
          />

          <Stack
            direction="row"
            justifyContent="flex-end"
            spacing={1.5}
            sx={{ mt: 3 }}
          >
            <Button variant="text" onClick={onClose} disabled={loading}>
              Cancel
            </Button>
            <Button
              variant="contained"
              onClick={() => onSave(note)}
              disabled={loading || (!note.trim() && action === "reject")}
            >
              {loading ? "Saving..." : "Save"}
            </Button>
          </Stack>
        </Box>
      </Fade>
    </Modal>
  );
};

export default ConfirmationModel;
