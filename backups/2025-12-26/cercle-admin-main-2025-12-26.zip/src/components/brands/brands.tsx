import {
  Badge,
  Box,
  Button,
  Divider,
  FormControl,
  Grid,
  MenuItem,
  Pagination,
  Select,
  TextField,
  Typography,
} from "@mui/material";
import React, { useEffect, useState } from "react";
import BrandsCard from "./BrandsCard";
import Parentstyle from "../Style/Parentstyle";
import Childstyle from "../Style/childstyle";
import { useAppDispatch } from "../hooks/hooks";
import { fetchbrands } from "../../redux/thunks/merchantThunks";
import { useSelector } from "react-redux";
import AccessDenied from "../../components/merchant/Accessdenied";
import { useRolePermissions } from "../../components/functions/useRolePermissions";
import { RoleLike } from "../../components/functions/Roles";
import { clearBrands } from "../../redux/slices/merchantSlice";
import { fetchBrandsRequest } from "../../redux/thunks/merchantThunks";
import BrandRequest from "./BrandRequest";
import useAutoLimit from "./AutoLimitViewPort";
import EditIcon from "@mui/icons-material/Edit";

const Brands = () => {
  const dispatch = useAppDispatch();

  // permissions
  const rawRoles = useSelector((s: any) => s.auth.user?.roles) as
    | RoleLike[]
    | undefined;
  const { can } = useRolePermissions(rawRoles);
  const canRead = can("merchant", "read");

  const [currentPage, setCurrentPage] = useState(1);
  const [searchKeyword, setSearchKeyword] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [brandRequestSearch, setBrandRequestSearch] = useState("");

  const autoLimit = useAutoLimit();
  console.log("data", autoLimit);
  // allow user to override once they touch the Select
  const [limit, setLimit] = useState<number>(autoLimit);

  const [approvalComponentOpen, setApprovalComponentOpen] = useState(false);

  const handlePageChange = (_: React.ChangeEvent<unknown>, page: number) => {
    setCurrentPage(page);
  };

  useEffect(() => {
    if (!canRead) return;
    dispatch(clearBrands());
    dispatch(
      fetchbrands({
        page: currentPage,
        limit: Number(limit),
        searchKeyword: debouncedSearch,
      })
    );
  }, [dispatch, currentPage, debouncedSearch, limit, canRead]);
  // Fetch when page/limit changes
  useEffect(() => {
    dispatch(fetchBrandsRequest({ page: 1, limit: 1, onlyCount: true }));
  }, [dispatch]);
  const { brands_requests_pagination } = useSelector(
    (state: any) => state.merchants
  );
  const [isEditMode, setIsEditMode] = useState(false);
  // Debounce search (500ms)
  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedSearch(searchKeyword);
    }, 500);
    return () => clearTimeout(handler);
  }, [searchKeyword]);
  // Update limit when autoLimit changes
  useEffect(() => {
    setLimit(autoLimit);
  }, [autoLimit]);

  const { brand_pagination } = useSelector((state: any) => state.merchants);
  // Safe fallbacks for pagination-dependent UI
  const safeTotalCount = Number(brands_requests_pagination?.totalCount ?? 0); // <-- NEW
  console.log("safetotalcount", safeTotalCount, brand_pagination);
  // const safeTotalPages = Number(brands_requests_pagination?.totalPages ?? 1); // <-- NEW
  // const safeCurrentPage = Number(
  //   brands_requests_pagination?.currentPage ?? currentPage
  // );
  // READ gate
  if (!canRead) {
    return (
      <AccessDenied
        subtitle="Your account is missing the 'brands:read' permission. Contact an admin if you need access."
        secondaryActionText="Contact admin"
        onSecondaryAction={() => {
          // open your support route or mailto
          window.open("https://cymbiote.com/contact-us/", "_blank");
        }}
      />
    );
  }

  return (
    <Parentstyle>
      <Childstyle>
        {approvalComponentOpen ? (
          <Box
            sx={{ display: "flex", alignItems: "center", gap: 1 }}
            className=" pb-5"
          >
            <Typography
              variant="h6"
              fontWeight={700}
              sx={{ letterSpacing: 0.2 }}
              className="mb-2"
            >
              Total Requests
            </Typography>
            <Badge
              badgeContent={safeTotalCount} // <-- SAFE
              color={safeTotalCount > 0 ? "error" : "default"}
              sx={{ ml: 2 }}
            />
          </Box>
        ) : (
          <Box className="flex justify-between pb-5">
            <h1 className="text-2xl font-semibold mb-2">Brands</h1>
          </Box>
        )}


        <Grid
          container
          spacing={2}
          alignItems="center"
          justifyContent="space-between"
        >
          <Grid size={{ xs: 12, sm: 6, md: 5 }}>
            <TextField
              id="search-brands"
              label="Search Here"
              variant="outlined"
              autoComplete="off"
              fullWidth
              size="small"
              value={approvalComponentOpen ? brandRequestSearch : searchKeyword}
              onChange={(e) => {
                approvalComponentOpen
                  ? setBrandRequestSearch(e.target.value)
                  : setSearchKeyword(e.target.value);
                setCurrentPage(1); // Reset to page 1 when searching
              }}
            />
          </Grid>

          <Button
            variant="outlined"
            onClick={() => setApprovalComponentOpen(!approvalComponentOpen)}
          >
            <span className="text-gray-500">Brands Approval</span>
            <Badge
              badgeContent={`${safeTotalCount > 9 ? `${safeTotalCount}+` : safeTotalCount
                }`} // <-- SAFE
              color={safeTotalCount > 0 ? "primary" : "default"}
              sx={{ ml: 2 }}
            />
          </Button>
          <Grid size={{ xs: 12, sm: 6, md: 3 }}>
            <FormControl size="small" fullWidth>
              {approvalComponentOpen ? null : (
                <Select
                  size="small"
                  id="select-page-limit"
                  displayEmpty
                  value={limit}
                  onChange={(e) => {
                    setLimit(Number(e.target.value));
                    setCurrentPage(1);
                  }}
                  renderValue={(selected) =>
                    selected ? (
                      <span className="text-gray-500">
                        Page Limit: {selected}
                      </span>
                    ) : (
                      <span className="text-gray-500">Page Limit</span>
                    )
                  }
                >
                  <MenuItem value={10}>10</MenuItem>
                  <MenuItem value={12}>12</MenuItem>
                  <MenuItem value={20}>20</MenuItem>
                  <MenuItem value={50}>50</MenuItem>
                  <MenuItem value={100}>100</MenuItem>
                </Select>
              )}
            </FormControl>
          </Grid>
        </Grid>

        <div className="flex justify-end items-center pb-4 mt-3 border-b-2 border-gray-200">
          <Button
            variant="contained"
            startIcon={<EditIcon />}
            onClick={() => setIsEditMode(!isEditMode)}
            sx={{
              background: "#2E7DC1",
            }}
          >

            {isEditMode ? "Disable Edit" : "Edit Brands"}
          </Button>
        </div>
      </Childstyle>

      <div className="ml-5 flex flex-wrap w-full xs:justify-center md:justify-center lg:justify-center xl:justify-center">
        {/* Pass canWrite so the card can enable/disable write actions */}
        {approvalComponentOpen ? (
          <BrandRequest brandRequestSearch={brandRequestSearch} />
        ) : (
          <BrandsCard isEditMode={isEditMode} />
        )}
      </div>

      {!approvalComponentOpen && <Divider />}

      {approvalComponentOpen ? null : (
        <div className="m-5 py-1">
          {brand_pagination?.totalPages > 1 && (
            <Pagination
              onChange={handlePageChange}
              count={brand_pagination?.totalPages || 1}
              page={currentPage}
              variant="outlined"
              shape="rounded"
              color="primary"
            />
          )}
        </div>
      )}
    </Parentstyle>
  );
};

export default Brands;
