import * as React from "react";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import CardActionArea from "@mui/material/CardActionArea";
import Typography from "@mui/material/Typography";
import Box from "@mui/material/Box";
import { Divider, Skeleton } from "@mui/material";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router";
import EditIcon from "@mui/icons-material/Edit";

const BrandsCard: React.FC<{ isEditMode: boolean }> = ({ isEditMode }) => {
  const { brands, loading } = useSelector((state: any) => state.merchants);
  const navigate = useNavigate();

  // How many skeletons to render while loading
  const skeletonArray = new Array(6).fill(null);

  return (
    <div className="flex justify-start flex-wrap sm:gap-2 md:gap-12 lg:gap-18 justify-items-start ">
      {loading
        ? skeletonArray.map((_, idx) => (
          <Card
            key={idx}
            sx={{
              maxWidth: 230,
              textAlign: "center",
              borderRadius: 2,
              border: "1px solid #e0e0e0",
              margin: 2,
            }}
          >
            <CardActionArea>
              <Box className="flex justify-center items-center sm:p-6 md:p-8 lg:p-12">
                <Skeleton variant="rectangular" width={150} height={120} />
              </Box>
              <Divider />
              <CardContent>
                <Skeleton width="60%" height={24} sx={{ mx: "auto" }} />
              </CardContent>
            </CardActionArea>
          </Card>
        ))
        : brands?.map((brand: any) => (
            <Card
              key={brand.brand_id}
              sx={{
                maxWidth: 230,
                textAlign: "center",
                borderRadius: 2,
                border: "1px solid #e0e0e0",
                margin: 2,
                position: "relative",
              }}
              // onClick={() => {
              //   if (!isEditMode) {
              //     navigate(`/merchants/details/${brand.product_shop_id}`);
              //   }
              // }}
            >
              {isEditMode && (
                <div
                  className="
                absolute inset-0 
                bg-black/40 
                flex items-center justify-center 
                z-10
              "
              >
                <div
                  className="
                  w-14 h-14 
                  rounded-full 
                  bg-white 
                  flex items-center justify-center
                  shadow-lg cursor-pointer hover:scale-105 transition
                "
                  onClick={(e) => {
                    e.stopPropagation();
                    navigate(`/brands/edit/${brand.brand_id}`);
                  }}
                >
                  <EditIcon sx={{ fontSize: 28, color: "#2E7DC1" }} />
                </div>
              </div>
            )}
            <CardActionArea>
              <Box className="flex justify-center items-center sm:p-6 md:p-8 lg:p-12">
                <img
                  src={
                    brand.brand_logo_url ||
                    brand.shop_logo_url ||
                    "https://cdn.shopify.com/s/files/1/0595/2379/2944/files/img_not_found_cercle.jpg?v=1757333158"
                  }
                  alt={brand.shop_name}
                  style={{ borderRadius: 8 }}
                  width={150}
                  className="min-h-36"
                  onError={(e) => {
                    const target = e.target as HTMLImageElement;
                    target.src = "https://cdn.shopify.com/s/files/1/0595/2379/2944/files/img_not_found_cercle.jpg?v=1757333158";
                  }}
                />
              </Box>
              <Divider />
              <CardContent>
                <Typography
                  gutterBottom
                  variant="body1"
                  fontWeight="bold"
                  component="div"
                >
                  {brand.brand_name}
                </Typography>
              </CardContent>
            </CardActionArea>
          </Card>
        ))}
    </div>
  );
};

export default BrandsCard;
