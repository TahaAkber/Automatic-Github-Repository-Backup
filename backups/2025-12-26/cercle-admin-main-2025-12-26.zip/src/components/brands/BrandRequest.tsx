import * as React from "react";
import { useState, useEffect } from "react";
import {
  Box,
  Divider,
  IconButton,
  List,
  ListItem,
  ListItemText,
  Typography,
  Button,
  Pagination,
  Stack,
  Tooltip,
  Paper,
  Skeleton,
  ListItemAvatar,
  Avatar,
} from "@mui/material";
import CheckOutlinedIcon from "@mui/icons-material/CheckOutlined";
import ClearOutlinedIcon from "@mui/icons-material/ClearOutlined";
import RefreshOutlinedIcon from "@mui/icons-material/RefreshOutlined";
import { useAppDispatch } from "../hooks/hooks";
import {
  approveBrand,
  fetchBrandsRequest,
} from "../../redux/thunks/merchantThunks";
import { useSelector } from "react-redux";
import ConfirmationModel from "./ConfirmationModel";
import { formatDate } from "../../components/functions/formateDate";

interface BrandRequestProps {
  brandRequestSearch?: string;
}
type NotificationItem = {
  id: string;
  brand_id: string;
  brand_name: string;
  shop_name: string;
  brand_need_desc?: string;
  createdAt: string;
  brand_logo_url?: string;
};

type PaginationMeta =
  | {
      currentPage: number;
      totalPages: number;
      totalCount: number;
    }
  | undefined;

const PAGE_SIZE_DEFAULT = 10;
const FALLBACK_LOGO =
  "https://cdn.shopify.com/s/files/1/0595/2379/2944/files/img_not_found_cercle.jpg?v=1757333158";

export default function BrandRequest({
  brandRequestSearch,
}: BrandRequestProps) {
  const dispatch = useAppDispatch();
  const userID: string[] = useSelector((s: any) => s.auth?.user?.id);

  const {
    brands_requests = [],
    brands_requests_pagination,
    loading,
    status,
  } = useSelector((s: any) => s.merchants) as {
    brands_requests: any[];
    brands_requests_pagination: PaginationMeta;
    status: string;
    loading: boolean;
  };

  const [currentPage, setCurrentPage] = useState<number>(1);
  const [limit] = useState<number>(PAGE_SIZE_DEFAULT);
  const [items, setItems] = useState<NotificationItem[]>([]);
  const [approveLoadingId, setApproveLoadingId] = useState<string | null>(null);
  const [rejectLoadingId, setRejectLoadingId] = useState<string | null>(null);
  const [confirmState, setConfirmState] = useState<{
    open: boolean;
    action: "approve" | "reject";
    note?: string;

    brandId?: number;
    brandName?: string;
  }>({ open: false, action: "approve" });

  const [saving, setSaving] = useState(false);
  useEffect(() => {
    const mapped: NotificationItem[] = (brands_requests || []).map(
      (n: any) => ({
        id: String(n.id ?? n.brand_id),
        brand_id: String(n.brand_id ?? n.id ?? ""),
        brand_name: n.brand_name ?? "Unknown brand",
        brand_need_desc: n.brand_need_desc,
        shop_name: n.shop_name,
        createdAt: formatDate(n.createdAt),
        brand_logo_url: n.brand_logo_url || FALLBACK_LOGO,
      })
    );
    setItems(mapped);

    console.log("items", items);
  }, [brands_requests]);
  const handleApproveBrand = async (
    brand_id: number,
    is_approved: boolean,
    note?: string,
    brandApprovalIsApproved?: boolean
  ) => {
    const result = await dispatch(
      approveBrand({
        brand_id,
        brand_status_is_approved: is_approved,
        brand_note: note,
        brand_approval_is_approved: brandApprovalIsApproved,
        user_id: userID,
      })
    );
    if (result?.payload?.status === 200) {
      dispatch(
        fetchBrandsRequest({ page: currentPage, limit, brandRequestSearch })
      );
    }
  };
  const totalPages = brands_requests_pagination?.totalPages ?? 1;
  const totalCount = brands_requests_pagination?.totalCount ?? items.length;
  const pageForCalc = brands_requests_pagination?.currentPage ?? currentPage;
  const startIdx = totalCount === 0 ? 0 : (pageForCalc - 1) * limit + 1;
  const endIdx = Math.min(pageForCalc * limit, totalCount);

  const closeConfirm = () => setConfirmState((s) => ({ ...s, open: false }));

  const saveConfirm = async (note: string) => {
    if (!confirmState.brandId) return;
    setSaving(true);
    const isApprovedFlag = confirmState.action === "approve" ? true : false;
    const brandApprovalIsApproved =
      confirmState.action === "approve" ? true : false;
    try {
      await handleApproveBrand(
        confirmState.brandId,
        isApprovedFlag,
        note,
        brandApprovalIsApproved
      );
      // clear loading ids (if any) and close modal
      setApproveLoadingId(null);
      setRejectLoadingId(null);
      closeConfirm();
    } finally {
      setSaving(false);
    }
  };

  const handleApprove = (
    e: React.MouseEvent,
    _: string,
    brandIdNum?: number,
    brandName?: string
  ) => {
    e.stopPropagation();
    if (!brandIdNum) return;
    setConfirmState({
      open: true,
      action: "approve",
      brandId: brandIdNum,
      brandName,
    });
  };

  const handleReject = (
    e: React.MouseEvent,
    _: string,
    brandIdNum?: number,
    brandName?: string
  ) => {
    e.stopPropagation();
    if (!brandIdNum) return;
    setConfirmState({
      open: true,
      action: "reject",
      brandId: brandIdNum,
      brandName,
    });
  };

  const handlePageChange = (_: React.ChangeEvent<unknown>, page: number) => {
    setCurrentPage(page);
  };

  const fallbackDesc =
    "New brand request received. Review the submission details and proceed to approve or reject.";

  // Fetch when page/limit changes
  useEffect(() => {
    dispatch(
      fetchBrandsRequest({ page: currentPage, limit, brandRequestSearch })
    );
  }, [dispatch, currentPage, limit, brandRequestSearch]);

  const isLoading = loading || (status === "loading" && items.length === 0);

  return (
    <Box sx={{ width: "100%", mr: 3, pr: 2 }}>
      {/* Actions */}
      <Box
        sx={{
          display: "flex",
          justifyContent: "flex-end",
          width: "100%",
          my: 2,
        }}
      >
        <Stack direction="row" spacing={1}>
          <Tooltip title="Refresh" arrow>
            <Button
              size="small"
              variant="text"
              startIcon={<RefreshOutlinedIcon />}
              onClick={() =>
                dispatch(fetchBrandsRequest({ page: currentPage, limit }))
              }
            >
              Refresh
            </Button>
          </Tooltip>
        </Stack>
      </Box>

      {/* List container */}
      <Paper variant="outlined" sx={{ borderRadius: 2, overflow: "hidden" }}>
        {/* Skeleton UI */}
        {isLoading && (
          <Box sx={{ p: 2 }}>
            {Array.from({ length: 10 }).map((_, i) => (
              <Box key={i}>
                <Box
                  sx={{
                    display: "flex",
                    alignItems: "center",
                    py: 1.5,
                    px: 0.5,
                  }}
                >
                  <Skeleton
                    variant="circular"
                    width={36}
                    height={36}
                    sx={{ mr: 2 }}
                  />
                  <Box sx={{ flex: 1, minWidth: 0 }}>
                    <Skeleton width="35%" height={18} />
                    <Skeleton width="85%" height={14} sx={{ mt: 0.8 }} />
                  </Box>
                  <Stack direction="row" spacing={1} sx={{ ml: 2 }}>
                    <Skeleton variant="rounded" width={36} height={36} />
                    <Skeleton variant="rounded" width={36} height={36} />
                  </Stack>
                </Box>
                {i < 5 && <Divider />}
              </Box>
            ))}
          </Box>
        )}

        {/* Empty state */}
        {!isLoading && items.length === 0 && (
          <Box sx={{ py: 7, textAlign: "center", px: 2 }}>
            <Typography variant="subtitle1" fontWeight={600}>
              All caught up
            </Typography>
            <Typography variant="body2" color="text.secondary" sx={{ mt: 0.5 }}>
              No brand requests to show right now.
            </Typography>
            <Button
              size="small"
              startIcon={<RefreshOutlinedIcon />}
              sx={{ mt: 2 }}
              onClick={() =>
                dispatch(fetchBrandsRequest({ page: currentPage, limit }))
              }
            >
              Refresh
            </Button>
          </Box>
        )}

        {/* List */}
        {!isLoading && items.length > 0 && (
          <List dense disablePadding>
            {items.map((n, idx) => (
              <React.Fragment key={n.id}>
                <ListItem
                  alignItems="flex-start"
                  sx={{
                    cursor: "pointer",
                    transition: (theme) =>
                      theme.transitions.create(["background-color"], {
                        duration: 120,
                      }),
                    py: 1.25,
                    px: 2,
                  }}
                  secondaryAction={
                    <Stack direction="row" spacing={1} alignItems="center">
                      <Tooltip title="Approve" arrow>
                        <span>
                          <IconButton
                            size="small"
                            disableRipple
                            loading={
                              approveLoadingId === n.id ||
                              rejectLoadingId === n.id
                            }
                            onClick={(e) =>
                              handleApprove(e, n.id, Number(n.brand_id))
                            }
                            sx={{
                              width: 36,
                              height: 36,
                              border: 1,
                              borderColor: "success.main",
                              color: "success.main",
                              borderRadius: "50%",
                              position: "relative",
                            }}
                          >
                            {approveLoadingId === n.id ? (
                              <Skeleton
                                variant="circular"
                                width={20}
                                height={20}
                                sx={{ bgcolor: "success.main", opacity: 0.5 }}
                              />
                            ) : (
                              <CheckOutlinedIcon sx={{ fontSize: 20 }} />
                            )}
                          </IconButton>
                        </span>
                      </Tooltip>

                      <Tooltip title="Reject" arrow>
                        <span>
                          <IconButton
                            size="small"
                            disableRipple
                            loading={
                              approveLoadingId === n.id ||
                              rejectLoadingId === n.id
                            }
                            onClick={(e) =>
                              handleReject(e, n.id, Number(n.brand_id))
                            }
                            sx={{
                              width: 36,
                              height: 36,
                              border: 1,
                              borderColor: "error.main",
                              color: "error.main",
                              borderRadius: "50%",
                              position: "relative",
                            }}
                          >
                            {rejectLoadingId === n.id ? (
                              <Skeleton
                                variant="circular"
                                width={20}
                                height={20}
                                sx={{ bgcolor: "error.main", opacity: 0.5 }}
                              />
                            ) : (
                              <ClearOutlinedIcon sx={{ fontSize: 20 }} />
                            )}
                          </IconButton>
                        </span>
                      </Tooltip>
                    </Stack>
                  }
                >
                  <ListItemAvatar sx={{ minWidth: 42, mr: 1 }}>
                    <Avatar
                      src={n.brand_logo_url || undefined}
                      alt={n.brand_name}
                      sx={{ width: 32, height: 32, fontSize: 14 }}
                    >
                      {n.brand_name?.[0] || "B"}
                    </Avatar>
                  </ListItemAvatar>
                  <ListItemText
                    sx={{ pr: 12 }}
                    primary={
                      <Box
                        sx={{
                          display: "flex",
                          justifyContent: "space-between",
                          gap: 1,
                          minWidth: 0,
                        }}
                      >
                        <Typography
                          variant="body1"
                          fontWeight={600}
                          noWrap
                          title={n.brand_name}
                          sx={{ minWidth: 0, flex: 1 }}
                        >
                          {n.brand_name}
                          {n.shop_name ? ` (Requested By ${n.shop_name})` : ""}
                        </Typography>
                      </Box>
                    }
                    secondary={
                      <Typography
                        variant="body2"
                        color="text.secondary"
                        sx={{
                          display: "-webkit-box",
                          WebkitLineClamp: 2,
                          WebkitBoxOrient: "vertical",
                          overflow: "hidden",
                        }}
                        title={n.brand_need_desc || fallbackDesc}
                      >
                        {n.brand_need_desc || fallbackDesc}
                      </Typography>
                    }
                  />
                </ListItem>
                {idx < items.length - 1 && <Divider component="li" />}
              </React.Fragment>
            ))}
          </List>
        )}

        <ConfirmationModel
          open={confirmState.open}
          action={confirmState.action}
          brandName={items[0]?.brand_name}
          loading={saving}
          onClose={closeConfirm}
          onSave={saveConfirm}
        />
        {/* Footer */}
        <Divider />
        <Box
          sx={{ py: 4, px: 2, display: "flex", justifyContent: "flex-start" }}
        >
          <Stack direction="row" alignItems="center" spacing={1}>
            <Pagination
              count={totalPages}
              page={brands_requests_pagination?.currentPage ?? currentPage}
              onChange={handlePageChange}
              variant="outlined"
              shape="rounded"
              color="primary"
              siblingCount={0}
              boundaryCount={1}
            />
            <Typography variant="caption" color="text.secondary">
              {`Showing ${startIdx}-${endIdx} of ${totalCount}`}
            </Typography>
          </Stack>
        </Box>
      </Paper>
    </Box>
  );
}
