import { useEffect, useState } from "react";

export default function useAutoLimit() {
  const calc = () => {
    if (typeof window === "undefined") return 12;

    const w = window.innerWidth;
    const h = window.innerHeight;

    // Calculate screen diagonal in inches
    const dppx = window.devicePixelRatio || 1;
    const widthInches = (w * dppx) / 96;
    const heightInches = (h * dppx) / 96;
    const diagonalInches = Math.sqrt(widthInches ** 2 + heightInches ** 2);

    const isBig = w >= 1920 && h >= 1200;
    const isHighDensity = dppx > 1;
    const result = isBig || isHighDensity === false ? 15 : 12;

    console.log({
      dimensions: `${w}x${h}`,
      diagonal: `${diagonalInches.toFixed(1)}"`,
      devicePixelRatio: dppx,
      isBig,
      isHighDensity,
      RESULT: result,
    });

    return result;
  };

  const [autoLimit, setAutoLimit] = useState(calc);

  useEffect(() => {
    const onResize = () => setAutoLimit(calc());
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, []);

  return autoLimit;
}
