import styled from "@emotion/styled";

const Childstyle = styled.div`
  margin-left: 2px;
  margin-right: 2px;
  padding-left: 2px;
  padding-right: 2px;
`;

export default Childstyle;
