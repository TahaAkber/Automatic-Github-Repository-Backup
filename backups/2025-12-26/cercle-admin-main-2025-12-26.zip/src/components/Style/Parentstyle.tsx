import styled from "@emotion/styled";

const Parentstyle = styled.div`
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin-top: 0px;
`;

export default Parentstyle;
