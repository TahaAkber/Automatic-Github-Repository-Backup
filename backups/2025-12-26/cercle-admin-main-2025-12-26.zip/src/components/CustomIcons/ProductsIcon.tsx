import * as React from "react";

const ProductsIcon: React.FC = (props: any) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width={16}
    height={22}
    fill="none"
    {...props}
  >
    <path
      fill="#000"
      fillRule="evenodd"
      d="M3.232.732A2.5 2.5 0 0 1 5 0h6a2.5 2.5 0 0 1 2.5 2.5v2.13l2.26 2.64a1 1 0 0 1 .24.651v10.125a1 1 0 0 1-.237.646l-2.5 2.954A1 1 0 0 1 12.5 22h-9a1 1 0 0 1-.763-.354l-2.5-2.954A1 1 0 0 1 0 18.046V7.922a1 1 0 0 1 .24-.65L2.5 4.63V2.5A2.5 2.5 0 0 1 3.232.732ZM3.96 6 2 8.291v9.389L3.964 20h8.072L14 17.68V8.29L12.04 6H3.96Zm7.54-2V2.5A.5.5 0 0 0 11 2H5a.5.5 0 0 0-.5.5V4h7Zm-7 5a1 1 0 0 1 1-1h5a1 1 0 1 1 0 2h-5a1 1 0 0 1-1-1Z"
      clipRule="evenodd"
    />
    <path
      fill="#000"
      fillRule="evenodd"
      d="M8 13.5a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3ZM4.5 15a3.5 3.5 0 1 1 7 0 3.5 3.5 0 0 1-7 0Z"
      clipRule="evenodd"
    />
  </svg>
);
export default ProductsIcon;
