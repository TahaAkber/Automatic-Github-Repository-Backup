import { forwardRef } from "react";
import { Link as RouterLink } from "react-router-dom";
import type { ForwardedRef, MouseEvent, ComponentProps } from "react";

type Props = Omit<ComponentProps<typeof RouterLink>, "to" | "onClick"> & {
  href?: string;
  onClick?: (event: MouseEvent<HTMLAnchorElement>) => void;
};

const Link = (props: Props, ref: ForwardedRef<HTMLAnchorElement>) => {
  const { href, onClick, ...rest } = props;

  return (
    <RouterLink
      ref={ref}
      {...rest}
      to={href || "/"}
      onClick={
        onClick
          ? (e) => onClick(e)
          : !href
          ? (e) => e.preventDefault()
          : undefined
      }
    />
  );
};

export default forwardRef(Link);
