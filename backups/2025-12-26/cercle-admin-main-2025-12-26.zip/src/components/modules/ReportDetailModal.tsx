import React, { useEffect, useState } from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Typography,
  CircularProgress,
  Box,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  TablePagination,
  Avatar,
  Menu,
  MenuItem,
  ListItemIcon,
  ListItemText,
  Tooltip,
} from "@mui/material";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import BlockIcon from "@mui/icons-material/Block";
import VisibilityOffIcon from "@mui/icons-material/VisibilityOff";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import CancelIcon from "@mui/icons-material/Cancel";
import { useAppDispatch } from "../hooks/hooks";
import { useSelector } from "react-redux";
import { getReportsById } from "../../redux/thunks/reportThunk";
import { Report } from "../../types/pages/types";

interface ReportDetailModalProps {
  open: boolean;
  onClose: () => void;
  selectedReport: Report | null;
}

const ReportDetailModal: React.FC<ReportDetailModalProps> = ({
  open,
  onClose,
  selectedReport,
}) => {
  const dispatch = useAppDispatch();
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [decisionAnchorEl, setDecisionAnchorEl] = useState<null | HTMLElement>(null);
  const isDecisionMenuOpen = Boolean(decisionAnchorEl);

  const detailedReports = useSelector(
    (s: any) => s.reports?.detailedReports || []
  );
  const detailedReportsStatus = useSelector(
    (s: any) => s.reports?.detailedReportsStatus || "idle"
  );
  const detailedReportsPagination = useSelector(
    (s: any) => s.reports?.detailedReportsPagination
  );

  useEffect(() => {
    if (open && selectedReport) {
      fetchReports(page + 1, rowsPerPage);
    }
  }, [open, selectedReport, page, rowsPerPage]);

  const fetchReports = (currentPage: number, limit: number) => {
    if (!selectedReport) return;

    const reportType = selectedReport.reported_type?.toLowerCase();

    let params: any = {
      reported_type: selectedReport.reported_type,
      limit: limit,
      page: currentPage,
    };

    if (reportType === "product") {
      params.reported_product_id = selectedReport.product_id?.toString() || "";
    } else if (reportType === "shop") {
      params.reported_shop_id = selectedReport.shop_id?.toString() || "";
    } else if (reportType === "reel" || reportType === "story") {
      params.reported_reference_id = selectedReport.reported_reference_id?.toString() || "";
    }

    dispatch(getReportsById(params));
  };

  const handleChangePage = (event: unknown, newPage: number) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event: React.ChangeEvent<HTMLInputElement>) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const handleOpenDecisionMenu = (event: React.MouseEvent<HTMLElement>) => {
    setDecisionAnchorEl(event.currentTarget);
  };

  const handleCloseDecisionMenu = () => {
    setDecisionAnchorEl(null);
  };

  const handleDecision = (decision: string) => {
    console.log("Decision selected:", decision, "for report:", selectedReport);
    // TODO: Implement API call to update product/shop status
    handleCloseDecisionMenu();
  };

  const getStatusBadge = (status?: string) => {
    if (!status) {
      return <span className="text-gray-500 text-xs">Select</span>;
    }

    // pending more highlighted
    const colorClasses =
      status === "pending"
        ? "bg-yellow-300 text-yellow-900 ring-1 ring-yellow-400"
        : status === "in_review"
        ? "bg-blue-100 text-blue-800"
        : status === "resolved"
        ? "bg-green-100 text-green-800"
        : status === "rejected"
        ? "bg-red-100 text-red-800"
        : "bg-gray-100 text-gray-800";

    const displayName =
      status === "in_review"
        ? "In Review"
        : status === "pending"
        ? "Pending"
        : status === "resolved"
        ? "Resolved"
        : status === "rejected"
        ? "Rejected"
        : status;

    return (
      <span
        className={`px-2 inline-flex text-xs leading-7 font-semibold rounded-full ${colorClasses}`}
      >
        {displayName}
      </span>
    );
  };

  const getReportTypeLabel = () => {
    if (!selectedReport) return "";
    const type = selectedReport.reported_type?.toLowerCase();
    
    if (type === "product") {
      return `Product: ${selectedReport.product_name || "N/A"}`;
    } else if (type === "shop") {
      return `Shop: ${selectedReport.shop_name || "N/A"}`;
    } else if (type === "reel") {
      return `Reel ID: ${selectedReport.reported_reference_id || "N/A"}`;
    } else if (type === "story") {
      return `Story ID: ${selectedReport.reported_reference_id || "N/A"}`;
    }
    return selectedReport.reported_type || "N/A";
  };



  return (
    <Dialog 
      open={open} 
      onClose={onClose} 
      maxWidth={false}
      PaperProps={{
        sx: {
          width: '90vw',
          maxWidth: '1200px',
          height: '80vh',
          maxHeight: '800px',
        }
      }}
    >
      <DialogTitle>
        <Box display="flex" alignItems="center" justifyContent="space-between" width="100%">
          <Box display="flex" alignItems="center" gap={2}>
            <Box
              sx={{
                width: 56,
                height: 56,
                borderRadius: 1.5,
                overflow: "hidden",
                backgroundColor: "grey.100",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                flexShrink: 0,
              }}
            >
              <img
                src={
                  selectedReport?.reported_type?.toLowerCase() === "product"
                    ? selectedReport?.product_image_url || "https://cdn.shopify.com/s/files/1/0595/2379/2944/files/img_not_found_cercle.jpg?v=1757333158"
                    : selectedReport?.shop_logo_url || "https://cdn.shopify.com/s/files/1/0595/2379/2944/files/img_not_found_cercle.jpg?v=1757333158"
                }
                alt={
                  selectedReport?.reported_type?.toLowerCase() === "product"
                    ? selectedReport?.product_name || "Product"
                    : selectedReport?.shop_name || "Shop"
                }
                style={{
                  width: "100%",
                  height: "100%",
                  objectFit: "cover",
                }}
                onError={(e) => {
                  const target = e.target as HTMLImageElement;
                  target.src = "https://cdn.shopify.com/s/files/1/0595/2379/2944/files/img_not_found_cercle.jpg?v=1757333158";
                }}
              />
            </Box>
            <Box>
              <Typography variant="h6" component="div" sx={{ lineHeight: 1.2, mb: 0.5 }}>
                {getReportTypeLabel()}
              </Typography>
              <Box display="flex" flexDirection="column">
                {(selectedReport?.reported_type?.toLowerCase() === "reel" || 
                  selectedReport?.reported_type?.toLowerCase() === "story" ||
                  selectedReport?.reported_type?.toLowerCase() === "product") && selectedReport?.shop_name && (
                  <Box display="flex" alignItems="center" gap={1}>
                   
                    <Typography variant="caption" color="text.primary" fontWeight={600}>
                      Shop: {selectedReport?.shop_name}
                    </Typography>
                     <Avatar 
                      src={selectedReport?.shop_logo_url || ""} 
                      sx={{ width: 30, height: 30, fontSize: '0.625rem' }}
                    >
                      {selectedReport?.shop_name?.charAt(0)}
                    </Avatar>
                  </Box>
                )}
                {detailedReportsPagination && (
                  <Typography variant="caption" color="text.secondary">
                    Total Reports: {detailedReportsPagination.totalCount || 0}
                  </Typography>
                )}
              </Box>
            </Box>
          </Box>

          {/* Decision Dropdown */}
          <Box>
            <Button
              variant="outlined"
              endIcon={<MoreVertIcon />}
              onClick={handleOpenDecisionMenu}
              size="small"
            >
              Take Action
            </Button>
            <Menu
              anchorEl={decisionAnchorEl}
              open={isDecisionMenuOpen}
              onClose={handleCloseDecisionMenu}
              anchorOrigin={{
                vertical: 'bottom',
                horizontal: 'right',
              }}
              transformOrigin={{
                vertical: 'top',
                horizontal: 'right',
              }}
            >
              <MenuItem onClick={() => handleDecision('disable')}>
                <ListItemIcon>
                  <BlockIcon fontSize="small" color="error" />
                </ListItemIcon>
                <ListItemText>Disable {selectedReport?.reported_type}</ListItemText>
              </MenuItem>
              <MenuItem onClick={() => handleDecision('inactive')}>
                <ListItemIcon>
                  <VisibilityOffIcon fontSize="small" color="warning" />
                </ListItemIcon>
                <ListItemText>Mark as Inactive</ListItemText>
              </MenuItem>
              <MenuItem onClick={() => handleDecision('approve')}>
                <ListItemIcon>
                  <CheckCircleIcon fontSize="small" color="success" />
                </ListItemIcon>
                <ListItemText>Approve {selectedReport?.reported_type}</ListItemText>
              </MenuItem>
              <MenuItem onClick={() => handleDecision('reject')}>
                <ListItemIcon>
                  <CancelIcon fontSize="small" color="error" />
                </ListItemIcon>
                <ListItemText>Reject Reports</ListItemText>
              </MenuItem>
            </Menu>
          </Box>
        </Box>
      </DialogTitle>

      <DialogContent dividers sx={{ height: 'calc(100% - 140px)', overflow: 'auto' }}>
        {detailedReportsStatus === "loading" ? (
          <Box
            sx={{
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              minHeight: "200px",
            }}
          >
            <CircularProgress />
          </Box>
        ) : detailedReportsStatus === "failed" ? (
          <Box textAlign="center" py={4}>
            <Typography color="error">
              Failed to load report details. Please try again.
            </Typography>
          </Box>
        ) : detailedReports.length === 0 ? (
          <Box textAlign="center" py={4}>
            <Typography color="text.secondary">
              No reports found for this {selectedReport?.reported_type?.toLowerCase()}.
            </Typography>
          </Box>
        ) : (
          <TableContainer component={Paper} variant="outlined">
            <Table size="small" stickyHeader>
              <TableHead>
                <TableRow>
                  <TableCell sx={{ backgroundColor: "grey.50", fontWeight: 'bold' }}>Reported By</TableCell>
                  <TableCell sx={{ backgroundColor: "grey.50", fontWeight: 'bold' }}>Status</TableCell>
                  <TableCell sx={{ backgroundColor: "grey.50", fontWeight: 'bold' }}>Main Reason</TableCell>
                  <TableCell sx={{ backgroundColor: "grey.50", fontWeight: 'bold' }}>Sub Reason</TableCell>
                  <TableCell sx={{ backgroundColor: "grey.50", fontWeight: 'bold' }}>Other Reason</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {detailedReports.map((report: Report) => (
                  <TableRow
                    key={report.report_id}
                    sx={{
                      "&:hover": { backgroundColor: "grey.50" },
                      backgroundColor:
                        report.report_id === selectedReport?.report_id
                          ? "primary.50"
                          : "inherit",
                    }}
                  >
                    <TableCell>
                      <Box display="flex" alignItems="center" gap={1}>
                        <Avatar sx={{ width: 32, height: 32, fontSize: '0.875rem' }}>
                          {report.user_first_name?.charAt(0)}{report.user_last_name?.charAt(0)}
                        </Avatar>
                        <Box>
                          <Typography variant="body2" fontWeight={500}>
                            {report.user_first_name} {report.user_last_name}
                          </Typography>
                          <Typography variant="caption" color="text.secondary">
                            {report.user_email}
                          </Typography>
                        </Box>
                      </Box>
                    </TableCell>
                    <TableCell>{getStatusBadge(report.reported_status)}</TableCell>
                    <TableCell>
                      <Tooltip title={report.reported_reason_main || ""} arrow>
                        <Typography
                          variant="body2"
                          sx={{
                            maxWidth: 250,
                            overflow: "hidden",
                            textOverflow: "ellipsis",
                            whiteSpace: "nowrap",
                          }}
                        >
                          {report.reported_reason_main || "-"}
                        </Typography>
                      </Tooltip>
                    </TableCell>
                    <TableCell>
                      <Tooltip title={report.reported_reason_sub || ""} arrow>
                        <Typography
                          variant="body2"
                          sx={{
                            maxWidth: 250,
                            overflow: "hidden",
                            textOverflow: "ellipsis",
                            whiteSpace: "nowrap",
                          }}
                        >
                          {report.reported_reason_sub || "-"}
                        </Typography>
                      </Tooltip>
                    </TableCell>
                    <TableCell>
                      <Tooltip title={report.reported_reason_other_text || ""} arrow>
                        <Typography
                          variant="body2"
                          sx={{
                            maxWidth: 200,
                            overflow: "hidden",
                            textOverflow: "ellipsis",
                            whiteSpace: "nowrap",
                          }}
                        >
                          {report.reported_reason_other_text || "-"}
                        </Typography>
                      </Tooltip>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        )}
      </DialogContent>

      <DialogActions sx={{ justifyContent: 'flex-end', px: 3, py: 2 }}>
        <Box display="flex" alignItems="center" gap={2}>
          {detailedReportsPagination && (
            <TablePagination
              component="div"
              count={detailedReportsPagination.totalCount || 0}
              page={page}
              onPageChange={handleChangePage}
              rowsPerPage={rowsPerPage}
              onRowsPerPageChange={handleChangeRowsPerPage}
              rowsPerPageOptions={[5, 10, 25, 50]}
            />
          )}
          <Button onClick={onClose} variant="contained">
            Close
          </Button>
        </Box>
      </DialogActions>
    </Dialog>
  );
};

export default ReportDetailModal;
