import React from "react";
import { Box, Button, Fade, Modal, TextField, Typography } from "@mui/material";
import { useAppDispatch } from "../../components/hooks/hooks";
import { updateReportStatus } from "../../../src/redux/thunks/reportThunk";

type ReportDecisionModalProps = {
  modalopen?: boolean;
  setDecisionModalOpen?: (open: boolean) => void;
  decisionDescription?: string;
  setDecisionDescription?: (desc: string) => void;
  decisionResult?: string;
  setDecisionResult?: (desc: string) => void;
  selectedStatus?: string;
  selectedRow?: any; // (replace `any` with your row type/interface)
  confirmText?: string;
  cancelText?: string;
  showLoader?: boolean;
  showCancelButton?: boolean;
  showConfirmButton?: boolean;
  setOpenSnackbar?: (open: boolean) => void;
  setSnackbarMessage?: (desc: string) => void;
  setSnackbarSeverity?: (severity: "success" | "error") => void;
  openSnackbar?: boolean;
  SnackbarMessage?: string;
  snackbarSeverity?: "success" | "error";
};

const ReportDecisionModal: React.FC<ReportDecisionModalProps> = ({
  modalopen = false,
  setDecisionModalOpen,
  setDecisionDescription,
  setDecisionResult,
  decisionDescription,
  decisionResult,
  selectedStatus,
  selectedRow,
  setOpenSnackbar,
  setSnackbarMessage,
  setSnackbarSeverity,
}) => {
  const dispatch = useAppDispatch();

  return (
    <Modal
      open={modalopen}
      onClose={() => setDecisionModalOpen?.(false)}
      closeAfterTransition
    >
      <Fade in={modalopen}>
        <Box
          sx={{
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            width: { xs: "calc(100vw - 32px)", sm: 520 },
            maxWidth: 720,
            bgcolor: "background.paper",
            borderRadius: 2,
            boxShadow: 24,
            p: { xs: 2.5, sm: 4 },
            maxHeight: "80vh",
            overflowY: "auto",
          }}
        >
          <Typography variant="h6" sx={{ mb: 3 }}>
            {selectedStatus === "resolved" ? "Resolve Report" : "Reject Report"}
          </Typography>

          <TextField
            label="Decision Description"
            fullWidth
            multiline
            rows={3}
            value={decisionDescription}
            onChange={(e) => setDecisionDescription?.(e.target.value)}
            sx={{ mb: 2 }}
          />

          <TextField
            label="Decision Result"
            fullWidth
            multiline
            rows={3}
            value={decisionResult}
            onChange={(e) => setDecisionResult?.(e.target.value)}
            sx={{ mb: 3 }}
          />

          <Box
            sx={{
              display: "flex",
              justifyContent: "flex-end",
              gap: 2,
              flexWrap: "wrap",
            }}
          >
            <Button
              variant="outlined"
              color="primary"
              onClick={() => {
                setDecisionModalOpen?.(false);
                setDecisionDescription?.("");
                setDecisionResult?.("");
              }}
            >
              Cancel
            </Button>

            <Button
              variant="contained"
              color="primary"
              onClick={async () => {
                if (!decisionDescription?.trim() || !decisionResult?.trim()) {
                  setSnackbarMessage?.(
                    "Please fill in both Decision Description and Decision Result"
                  );
                  setSnackbarSeverity?.("error");
                  setOpenSnackbar?.(true);
                  return;
                }

                if (!selectedRow) {
                  setSnackbarMessage?.("No report selected");
                  setSnackbarSeverity?.("error");
                  setOpenSnackbar?.(true);
                  return;
                }

                try {
                  const result = await dispatch(
                    updateReportStatus({
                      id: selectedRow.report_id,
                      status: selectedStatus ?? "",
                      decision_description: decisionDescription,
                      decision_result: decisionResult,
                    })
                  );

                  if (updateReportStatus.fulfilled.match(result)) {
                    setDecisionModalOpen?.(false);
                    setDecisionDescription?.("");
                    setDecisionResult?.("");
                    setSnackbarMessage?.(
                      `Report ${
                        selectedStatus === "resolved" ? "resolved" : "rejected"
                      } successfully!`
                    );
                    setSnackbarSeverity?.("success");
                    setOpenSnackbar?.(true);
                  } else if (updateReportStatus.rejected.match(result)) {
                    setSnackbarMessage?.(
                      result.payload || "Failed to update report"
                    );
                    setSnackbarSeverity?.("error");
                    setOpenSnackbar?.(true);
                  }
                } catch (error) {
                  setSnackbarMessage?.(
                    "An error occurred while updating the report"
                  );
                  setSnackbarSeverity?.("error");
                  setOpenSnackbar?.(true);
                }
              }}
            >
              Submit
            </Button>
          </Box>
        </Box>
      </Fade>
    </Modal>
  );
};

export default ReportDecisionModal;
