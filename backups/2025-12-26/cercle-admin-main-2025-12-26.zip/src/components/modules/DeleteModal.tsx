import React from "react";
import {
  Modal,
  Fade,
  Box,
  Typography,
  Button,
  CircularProgress,
} from "@mui/material";

type DeleteModalProps = {
  modalopen?: boolean;
  handleClose?: () => void;

  title?: string;
  description?: string;

  handleConfirmDelete?: () => void;
  confirmText?: string; // default: "Yes"
  cancelText?: string; // default: "No"

  deleting?: boolean;

  showLoader?: boolean; 
  showCancelButton?: boolean; // default: true
  showConfirmButton?: boolean; // default: true
};

const DeleteModal: React.FC<DeleteModalProps> = ({
  modalopen = false,
  handleClose,

  title = "Are you sure you want to delete this?",
  description,

  handleConfirmDelete,
  confirmText = "Yes",
  cancelText = "No",

  deleting = false,

  showLoader = true,
  showCancelButton = true,
  showConfirmButton = true,
}) => {
  const isDeleting = Boolean(deleting);

  // If you prefer: return null when closed
  // if (!modalopen) return null;

  return (
    <Modal
      open={Boolean(modalopen)}
      onClose={() => handleClose?.()}
      closeAfterTransition
    >
      <Fade in={Boolean(modalopen)}>
        <Box
          sx={{
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            width: { xs: "calc(100vw - 32px)", sm: 420 },
            maxWidth: 520,
            bgcolor: "background.paper",
            borderRadius: 2,
            boxShadow: 24,
            p: { xs: 2.5, sm: 4 },
            textAlign: "center",
          }}
        >
          {!!title && (
            <Typography variant="h6" sx={{ mb: description ? 1.5 : 3 }}>
              {title}
            </Typography>
          )}

          {!!description && (
            <Typography variant="body2" sx={{ mb: 3, opacity: 0.8 }}>
              {description}
            </Typography>
          )}

          <Box
            sx={{
              display: "flex",
              justifyContent: "center",
              gap: 2,
              alignItems: "center",
              flexWrap: "wrap",
            }}
          >
            {showConfirmButton && !!handleConfirmDelete && (
              <Button
                variant="outlined"
                color="error"
                onClick={() => handleConfirmDelete?.()}
                disabled={isDeleting}
              >
                {isDeleting ? "Deleting..." : confirmText}
              </Button>
            )}

            {showCancelButton && (
              <Button
                variant="outlined"
                color="primary"
                onClick={() => handleClose?.()}
                disabled={isDeleting}
              >
                {cancelText}
              </Button>
            )}

            {showLoader && isDeleting && <CircularProgress size={24} />}
          </Box>
        </Box>
      </Fade>
    </Modal>
  );
};

export default DeleteModal;
