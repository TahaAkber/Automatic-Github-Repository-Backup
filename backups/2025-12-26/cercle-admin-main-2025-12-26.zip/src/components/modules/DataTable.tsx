import React from "react";
import { Skeleton } from "@mui/material";

export type DataTableColumn<RowType = any> = {
  key: string;
  header: React.ReactNode;

  // Optional: custom cell renderer
  render?: (row: RowType, index: number) => React.ReactNode;

  // Optional: classes
  thClassName?: string;
  tdClassName?: string;
};

type DataTableProps<RowType = any> = {
  columns: DataTableColumn<RowType>[];
  rows?: RowType[];
  loading?: boolean;

  rowKey?: (row: RowType, index: number) => string | number;

  wrapperClassName?: string;
  tableClassName?: string;
  theadClassName?: string;
  rowClassName?: string;

  emptyText?: string;
  skeletonHeight?: number;
};

const DataTable = <RowType,>({
  columns,
  rows = [],
  loading = false,
  rowKey,

  wrapperClassName = "overflow-x-auto border-gray-200 rounded-lg shadow-sm",
  tableClassName = "min-w-full text-sm text-left",
  theadClassName = "bg-gray-50 border-b text-gray-500 font-semibold",
  rowClassName = "border-b last:border-none text-gray-600",

  emptyText = "No data found",
  skeletonHeight = 64,
}: DataTableProps<RowType>) => {
  const colSpan = columns?.length || 1;

  return (
    <div className={wrapperClassName}>
      <table className={tableClassName}>
        <thead className={theadClassName}>
          <tr>
            {columns.map((col, i) => (
              <th
                key={col.key ?? i}
                className={col.thClassName ?? "px-6 py-3 whitespace-nowrap"}
              >
                {col.header}
              </th>
            ))}
          </tr>
        </thead>

        <tbody>
          {!loading && rows?.length > 0 ? (
            rows.map((row, index) => (
              <tr
                key={rowKey ? rowKey(row, index) : (row as any)?.id ?? index}
                className={rowClassName}
              >
                {columns.map((col, cIdx) => (
                  <td
                    key={col.key ?? cIdx}
                    className={col.tdClassName ?? "px-6 py-4 whitespace-nowrap"}
                  >
                    {col.render
                      ? col.render(row, index)
                      : (row as any)?.[col.key] ?? "—"}
                  </td>
                ))}
              </tr>
            ))
          ) : loading ? (
            <tr>
              <td colSpan={colSpan} className="px-6 py-4">
                <Skeleton
                  variant="rounded"
                  width="100%"
                  height={skeletonHeight}
                />
              </td>
            </tr>
          ) : (
            <tr>
              <td colSpan={colSpan} className="px-6 py-4 text-gray-500">
                {emptyText}
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
};

export default DataTable;
