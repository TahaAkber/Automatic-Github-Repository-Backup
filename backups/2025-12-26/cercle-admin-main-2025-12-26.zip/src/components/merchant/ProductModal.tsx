import React from "react";
import { Modal, Box, Typography, Chip } from "@mui/material";

type Product = {
  name: string;
  image?: string;
  description?: string;
  product_custom_category_hierarchy?: string;
};

interface ProductModalProps {
  open: boolean;
  handleClose: () => void;
  selectedProduct: Product | null;
}

const ProductModal: React.FC<ProductModalProps> = ({
  open,
  handleClose,
  selectedProduct,
}) => {
  return (
    <Modal open={open} onClose={handleClose}>
      <Box
        sx={{
          position: "absolute",
          top: "50%",
          left: "50%",
          transform: "translate(-50%, -50%)",
          backgroundColor: "white",
          maxWidth: "90%",
          maxHeight: "90%",
          overflow: "auto",
          boxShadow: 10,
          borderRadius: 2,
          p: 2,
        }}
      >
        {selectedProduct && (
          <>
            <Typography
              variant="h6"
              gutterBottom
              sx={{ fontWeight: 700, mb: 2 }}
            >
              {selectedProduct.name}
            </Typography>

            <img
              src={
                selectedProduct.image ||
                "https://cdn.shopify.com/s/files/1/0595/2379/2944/files/No_image_available.webp?v=1756886203"
              }
              alt={selectedProduct.name}
              style={{
                width: "100%",
                height: "auto",
                maxHeight: "60vh",
                objectFit: "contain",
                marginBottom: 20,
                borderRadius: 8,
                backgroundColor: "transparent",
              }}
              loading="lazy"
              onError={(e) => {
                const target = e.target as HTMLImageElement;
                target.src = "https://cdn.shopify.com/s/files/1/0595/2379/2944/files/img_not_found_cercle.jpg?v=1757333158";
              }}
            />

            <Box sx={{ px: 1 }}>
              <Typography
                variant="inherit"
                sx={{ fontWeight: "bold", color: "text.secondary", mb: 0.5 }}
              >
                Category Hierarchy{" "}
              </Typography>
              <Chip
                label={
                  selectedProduct.product_custom_category_hierarchy ||
                  "No category"
                }
                style={{ fontSize: 15, marginBottom: 10 }}
              />

              <Typography
                variant="inherit"
                sx={{ fontWeight: "bold", color: "text.secondary", mb: 0.5 }}
              >
                Description{" "}
              </Typography>
              <Typography
                variant="body2"
                color="text.primary"
                sx={{
                  lineHeight: 1.6,
                  whiteSpace: "pre-line",
                }}
              >
                {selectedProduct.description || "No description available."}
              </Typography>
            </Box>
          </>
        )}
      </Box>
    </Modal>
  );
};

export default ProductModal;
