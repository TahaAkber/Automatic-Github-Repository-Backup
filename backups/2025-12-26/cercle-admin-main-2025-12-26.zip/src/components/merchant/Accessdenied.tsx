import { Box, Card, CardContent, Typography, Button } from "@mui/material";
import LockOutlinedIcon from "@mui/icons-material/LockOutlined";
import { useNavigate } from "react-router";

type AccessDeniedProps = {
  title?: string;
  subtitle?: string;
  primaryActionText?: string;
  onPrimaryAction?: () => void;
  secondaryActionText?: string;
  onSecondaryAction?: () => void;
};

export default function AccessDenied({
  title = "Access denied",
  subtitle = "You don’t have permission to view this page.",
  primaryActionText = "Go back",
  onPrimaryAction,
  secondaryActionText = "Request access",
  onSecondaryAction,
}: AccessDeniedProps) {
  const navigate = useNavigate();

  return (
    <Box
      sx={{
        minHeight: 420,
        display: "grid",
        placeItems: "center",
        p: 2,
      }}
    >
      <Card
        elevation={0}
        sx={{
          width: 520,
          maxWidth: "100%",
          borderRadius: 4,
          border: (t) => `1px solid ${t.palette.divider}`,
        }}
      >
        <CardContent
          sx={{
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            gap: 2,
            py: 5,
          }}
        >
          <Box
            sx={{
              width: 64,
              height: 64,
              borderRadius: "50%",
              display: "grid",
              placeItems: "center",
              bgcolor: (t) => t.palette.action.hover,
            }}
            aria-hidden
          >
            <LockOutlinedIcon sx={{ fontSize: 32, color: "text.secondary" }} />
          </Box>

          <Typography variant="h5" fontWeight={700}>
            {title}
          </Typography>

          <Typography
            variant="body2"
            color="text.secondary"
            align="center"
            sx={{ maxWidth: 420 }}
          >
            {subtitle}
          </Typography>

          <Box sx={{ display: "flex", gap: 1.5, mt: 1.5 }}>
            <Button
              variant="contained"
              onClick={onPrimaryAction ?? (() => navigate(-1))}
            >
              {primaryActionText}
            </Button>

            <Button
              variant="text"
              onClick={
                onSecondaryAction ??
                (() => {
                  // you can open a modal / route to support page
                  navigate("/users"); // example: send to users page or a help route
                })
              }
            >
              {secondaryActionText}
            </Button>
          </Box>
        </CardContent>
      </Card>
    </Box>
  );
}
