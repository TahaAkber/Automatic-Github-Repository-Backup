import React from "react";
import {
  Card,
  CardContent,
  Typography,
  Divider,
  Skeleton,
  Box,
  Tooltip,
  Button,
} from "@mui/material";
import Grid from "@mui/material/Grid";
import Action from "./Actiondropdown";
import { RoleLike } from "../functions/Roles";
import { useSelector } from "react-redux";
import { useRolePermissions } from "../../components/functions/useRolePermissions";

type OrdersCount = {
  total_orders: number;
  fulfilled_orders: number;
  partially_fulfilled_orders: number;
  pending_orders: number;
  unfulfilled_orders: number;
  restocked_orders: number;
  cancelled_orders: number;
};

interface MerchantDetailsCardProps {
  merchantDetails?: any; // made optional defensively
  orderTotalPrice?: number; // made optional defensively
  orderTotalDeducted?: number; // made optional defensively
  ordersCount?: Partial<OrdersCount>; // can arrive undefined/partial initially
  triggerAlert: (status: string) => void;
}

/** Coerce to Number, fallback if NaN/undefined/null */
const toNum = (v: unknown, fallback = 0) => {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
};

/** Build a normalized OrdersCount object with numeric values */
const normalizeOrders = (oc?: Partial<OrdersCount>): OrdersCount => ({
  total_orders: toNum(oc?.total_orders),
  fulfilled_orders: toNum(oc?.fulfilled_orders),
  partially_fulfilled_orders: toNum(oc?.partially_fulfilled_orders),
  pending_orders: toNum(oc?.pending_orders),
  unfulfilled_orders: toNum(oc?.unfulfilled_orders),
  restocked_orders: toNum(oc?.restocked_orders),
  cancelled_orders: toNum(oc?.cancelled_orders),
});

const MerchantDetailsCard: React.FC<MerchantDetailsCardProps> = ({
  merchantDetails,
  orderTotalPrice,
  orderTotalDeducted,
  ordersCount,
  triggerAlert,
}) => {
  const rawRoles = useSelector((state: any) => state.auth.user?.roles) as
    | RoleLike[]
    | undefined;

  const { can } = useRolePermissions(rawRoles);

  // ---- Safe derived values ----
  const currency = merchantDetails?.shop_currency ?? "Currency";

  const fmtMoney = (v: unknown) => `${toNum(v, 0).toFixed(2)} ${currency}`;

  const fmtCredits = (v: unknown) => `${toNum(v, 0)} ${currency}`;
  console.log("mechant details  package description:", merchantDetails?.package_description)
  // make ordersCount safe
  const oc = normalizeOrders(ordersCount);

  // shop visuals (guarded)
  const shopColor = (merchantDetails?.shop_color || "").toString().trim();
  const bannerColor =
    shopColor && shopColor.toLowerCase() !== "#fff" ? shopColor : "lightgray";

  const logoSrc =
    merchantDetails?.shop_logo_url ??
    "https://cdn.shopify.com/s/files/1/0923/5460/9434/files/no-photo-or-blank-image-icon-loading-images-or-missing-image-mark-image-not-available-or-image-coming-soon-sign-simple-nature-silhouette-in-frame-isolated-illustration-vector.jpg?v=1746776130";

  const shopName = merchantDetails?.shop_name ?? "Title";
  const shopAddress =
    merchantDetails?.shop_address ??
    "3891 Ranchview Dr. Richardson, California 62639";

  const shopEmail = merchantDetails?.shop_email ?? "Email";
  const shopNumber =
    merchantDetails?.shop_number ?? "(229) 555-0109, (808) 555-0111";

const formattedTileType = Array.isArray(merchantDetails?.shop_tile_type)
  ? (merchantDetails.shop_tile_type as (string | number)[])
      .map((v: string | number, i: number) =>
        i === 0
          ? String(v).charAt(0).toUpperCase() + String(v).slice(1) // Capitalize
          : String(v)
      )
      .join(" ")
  : merchantDetails?.shop_tile_type;



  return (
    <Card>
      <Grid>
        {/* Banner */}
        <div
          style={{
            backgroundColor: shopColor || "transparent",
            zIndex: -1,
            height: "6rem",
          }}
        >
          {!shopColor ? (
            <Skeleton variant="rounded" width="100%" height="6rem" />
          ) : (
            <div
              style={{
                backgroundColor: bannerColor,
                zIndex: -1,
                height: "6rem",
              }}
            />
          )}
        </div>

        {/* Logo + Basic Info */}
        <div className="flex flex-col flex-wrap md:flex-row md:flex-nowrap">
          <div
            style={{ position: "relative", width: 150, zIndex: 1, margin: 25 }}
          >
            <img
              src={logoSrc}
              alt={shopName}
              style={{ position: "absolute", bottom: -40, borderRadius: 10 }}
              className="h-36"
              onError={(e) => {
                // graceful fallback if logo url 404s
                (e.currentTarget as HTMLImageElement).src =
                  "https://cdn.shopify.com/s/files/1/0923/5460/9434/files/no-photo-or-blank-image-icon-loading-images-or-missing-image-mark-image-not-available-or-image-coming-soon-sign-simple-nature-silhouette-in-frame-isolated-illustration-vector.jpg?v=1746776130";
              }}
            />

            {!merchantDetails?.shop_logo_url && (
              <Skeleton
                variant="rounded"
                width="100%"
                height="9rem"
                style={{ position: "absolute", bottom: -40, borderRadius: 10 }}
              />
            )}
          </div>

          <div className="flex justify-between w-4/5 flex-wrap ml-5 md:ml-0">
            <div className="my-5">
              <Typography fontSize={20} fontWeight={500}>
                {shopName}
              </Typography>
              <Typography variant="body2" color="gray">
                {shopAddress}
              </Typography>
            </div>

            {/* Shop Status: only if merchants:write */}
            <div className="m-5">
              {can("merchants", "write") ? (
                <Action setMerchantStatus={triggerAlert} />
              ) : (
                <Tooltip title="You need merchants:write (or global) to change shop status">
                  <span>
                    <Button variant="outlined" size="small" disabled>
                      Change Status
                    </Button>
                  </span>
                </Tooltip>
              )}
            </div>
          </div>
        </div>

        <div className="h-10 mt-5 pt-5">
          <Divider />
        </div>

        {/* Stats */}
        <div className="flex flex-wrap ">
          {/* Sales / Revenue / Credits */}
          <Card
            variant="outlined"
            sx={{
              // height: "90%",
              width: "14.7em",
              borderRadius: 2,
              display: "flex",
              gap: 2,
              marginLeft: 3,
              marginBottom: 3,
              marginRight: 3,
            }}
          >
            <CardContent>
              <Typography variant="h6" color="text.secondary">
                Cercle sales:
              </Typography>
              <Typography variant="body1" color="primary" fontWeight="bold">
                {fmtMoney(orderTotalPrice)}
              </Typography>

              <Typography variant="h6" color="text.secondary">
                Cercle Revenue:
              </Typography>
              <Typography variant="body1" color="primary" fontWeight="bold">
                {fmtMoney(orderTotalDeducted)}
              </Typography>

              <Typography variant="h6" color="text.secondary">
                Cercle Credits Assigned:
              </Typography>
              <Typography variant="body1" color="primary" fontWeight="bold">
                {fmtCredits(merchantDetails?.shop_credits)}
              </Typography>
            </CardContent>
          </Card>

          {/* Orders */}
          <Card
            variant="outlined"
            sx={{
              borderRadius: 2,
              width: { xs: "100%", md: "80%", lg: "60%" },
              display: "flex",
              marginBottom: 3,
              marginRight: { xs: 0, md: 3 },
            }}
            className="ml-6 xl:ml-0"
          >
            <CardContent sx={{ width: "100%" }}>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 gap-4">
                {[
                  { label: "Total Number Orders", value: oc.total_orders },
                  {
                    label: "Total Fulfilled Orders",
                    value: oc.fulfilled_orders,
                  },
                  {
                    label: "Total Partial Fulfilled Orders",
                    value: oc.partially_fulfilled_orders,
                  },
                  { label: "Total Pending Orders", value: oc.pending_orders },
                  {
                    label: "Total Unfulfilled Orders",
                    value: oc.unfulfilled_orders,
                  },
                  {
                    label: "Total Restocked Orders",
                    value: oc.restocked_orders,
                  },
                  {
                    label: "Total Cancelled Orders",
                    value: oc.cancelled_orders,
                  },
                ].map((stat, idx) => (
                  <div className="flex items-center" key={idx}>
                    <Typography variant="h6" color="text.secondary">
                      {stat.label}:
                    </Typography>
                    <Typography
                      color="primary"
                      fontWeight="bold"
                      sx={{ ml: 1 }}
                    >
                      {toNum(stat.value, 0)}
                    </Typography>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Contacts */}
          <Card
            variant="outlined"
            sx={{
              borderRadius: 2,
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              gap: 2,
              marginBottom: 3,
              marginRight: 3,
              textAlign: "center",
              padding: 2,
            }}
            className="ml-6"
          >
            <Box sx={{ textAlign: "left" }}>
              <Typography
                variant="h6"
                sx={{ fontWeight: "bold", marginBottom: 1 }}
              >
                Contacts
              </Typography>
              <Typography variant="body2" color="text.secondary">
                {shopEmail}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                {shopNumber}
              </Typography>
            </Box>
          </Card>

          <Card
            variant="outlined"
            sx={{
              borderRadius: 2,
              width: { xs: "100%", md: "100%", lg: "60%", xl:"80%"},
              display: "flex",
              marginBottom: 3,
              marginRight: { xs: 0, md: 3 },
              marginLeft:{ xs: 0, md: 0, lg:0,xl:3}
              
            }}
            className="ml-6 xl:ml-0"
          >

            <CardContent sx={{ width: "100%",}}>
              <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-2 gap-3">
                {[
                  { label: "Plan", value: merchantDetails?.package_name },

                  {
                    label: "Tile Type",
                    value: formattedTileType
                  },
                  {
                    label: "Plan Charges",
                    value: merchantDetails?.package_charges
                  },
                  {
                    label: "Tile Name",
                    value: merchantDetails?.shop_tile_name
                  },

                  {
                    label: "Plan Discription",
                    value: merchantDetails?.package_description
                  },
                  {
                    label: "Tile Charges",
                    value: merchantDetails?.shop_tile_charges
                  },
                      {
                    label: "Extra Reels Purchased",
                    value: merchantDetails?.shop_tile_charges
                  },
                ]
                  .map((stat, idx) => (
                    <div className="flex items-center" key={idx}>
                      <Typography variant="h6" color="text.secondary">
                        {stat.label}:
                      </Typography>
                      <Typography
                        color="primary"
                        fontWeight="bold"
                        sx={{ ml: 1 }}
                      >
                        {stat.value ?? "N/A"}
                      </Typography>
                    </div>
                  ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </Grid>
    </Card>
  );
};

export default MerchantDetailsCard;
