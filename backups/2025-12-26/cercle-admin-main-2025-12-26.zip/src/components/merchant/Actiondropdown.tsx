import { useState } from "react";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select, { SelectChangeEvent } from "@mui/material/Select";
import { useAppDispatch } from "../hooks/hooks";
import { updateMerchant } from "../../redux/thunks/merchantThunks";
import { useParams } from "react-router";

// MUI icons
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import CancelIcon from "@mui/icons-material/Cancel";

interface MerchantStatus {
  setMerchantStatus: (value: any) => void;
}

export default function Action({ setMerchantStatus }: MerchantStatus) {
  const { merchantId } = useParams();
  const [value, setValue] = useState<boolean | "">("");

  const dispatch = useAppDispatch();

  const updateStatus = async (val: boolean) => {
    const result = await dispatch(
      updateMerchant({ id: Number(merchantId), isEnable: val })
    );
    if (result.payload.status === 200) {
      setMerchantStatus(result.payload.message);
    } else {
      setMerchantStatus("Failed to update status");
    }
    return result;
  };

  const handleChange = (event: SelectChangeEvent<any>) => {
    const newValue = event.target.value === "true"; 
    setValue(newValue);
    updateStatus(newValue);
  };

  return (
    <div>
      <FormControl variant="outlined" sx={{ m: 0, minWidth: 150 }} size="small">
        <InputLabel id="shop-status-label">Shop Status</InputLabel>
        <Select
          labelId="shop-status-label"
          id="shop-status-select"
          value={value === "" ? "" : String(value)} // keep controlled
          onChange={handleChange}
        >
          <MenuItem value={"true"}>
            <CancelIcon
              fontSize="small"
              color="error"
              style={{ marginRight: 8 }}
            />
            Delist
          </MenuItem>
          <MenuItem value={"false"}>
            <CheckCircleIcon
              fontSize="small"
              color="success"
              style={{ marginRight: 8 }}
            />
            Enlist
          </MenuItem>
        </Select>
      </FormControl>
    </div>
  );
}
