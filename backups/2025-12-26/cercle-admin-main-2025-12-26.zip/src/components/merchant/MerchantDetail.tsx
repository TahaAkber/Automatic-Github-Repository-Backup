import React, { useEffect, useState } from "react";
import Childstyle from "../Style/childstyle";
import { useNavigate, useParams } from "react-router";
import {
  Alert,
  Backdrop,
  Box,
  Card,
  CircularProgress,
  FormControl,
  Grid,
  MenuItem,
  Pagination,
  Select,
  Typography,
  ListItemIcon,
  ListItemText,
} from "@mui/material";
import { useSelector } from "react-redux";
import { useAppDispatch } from "../hooks/hooks";
import {
  fetchmerchantdetail,
  fetchMerchantProducts,
} from "../../redux/thunks/merchantThunks";
import TextField from "@mui/material/TextField";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import CancelIcon from "@mui/icons-material/Cancel";
import ProductModal from "./ProductModal";
import MerchantDetailsCard from "./MerchantDetailCart";
import ProductSkeletonCard from "./ProductSkeletonCard";
import ProductCard from "./ProductCard";
import GoBackButton from "../button/Goback";

const MerchantDetail = () => {
  const { merchantId: shop_id } = useParams();
  const navigate = useNavigate();
  const dispatch = useAppDispatch();

  // UI state
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedProduct, setSelectedProduct] = useState<{
    image: string;
    name: string;
    description?: string;
    product_custom_category: string;
    product_custom_category_hierarchy: string;
  } | null>(null);
  const [open, setOpen] = useState(false);
  const [loadedProducts, setLoadedProducts] = useState<Set<number>>(new Set());
  const [searchKeyword, setsearchKeyword] = useState("");
  const [productStatus, setProductStatus] = useState<"all" | "true" | "false">(
    "all"
  );

  // Redux state
  const {
    merchantDetails,
    orderTotalPrice,
    ordersCount,
    orderTotalDeducted,
    loading: detailsLoading,
  } = useSelector((state: any) => state.merchantdetails);

  const {
    merchant_product_pagination,
    Products,
    loading: productsLoading,
  } = useSelector((state: any) => state.merchants);

  // Global loader: true while ANY fetch is in progress
  const isFetching = detailsLoading || productsLoading;

  // Anti-flicker debounce for the loader
  const [showLoader, setShowLoader] = useState(false);
  useEffect(() => {
    if (isFetching) {
      setShowLoader(true);
      return;
    }
    const t = setTimeout(() => setShowLoader(false), 200); // smooth finish
    return () => clearTimeout(t);
  }, [isFetching]);

  // Alerts
  const [showAlert, setShowAlert] = useState(false);
  const [alertMessage, setAlertMessage] = useState("");
  const triggerAlert = (msg: string) => {
    setAlertMessage(msg);
    setShowAlert(true);
    setTimeout(() => setShowAlert(false), 2000);
  };

  // Handlers
  const handleImageClick = (product: any) => {
    setSelectedProduct({
      image: product.product_image_url,
      name: product.product_name,
      description: product.product_description ?? product.description ?? "",
      product_custom_category: product.product_custom_category ?? "",
      product_custom_category_hierarchy:
        product.product_custom_category_hierarchy ?? "",
    });
    setOpen(true);
  };
  const handleClose = () => {
    setOpen(false);
    setSelectedProduct(null);
  };
  const handlePageChange = (_: React.ChangeEvent<unknown>, page: number) => {
    setCurrentPage(page);
    setLoadedProducts(new Set());
  };
  const handleImageLoad = (index: number) => {
    setLoadedProducts((prev) => new Set([...prev, index]));
  };

  // Fetch merchant details (refetch on shop_id/page change if your API supports page)
  useEffect(() => {
    if (!shop_id) return;
    dispatch(fetchmerchantdetail({ id: Number(shop_id), page: currentPage }));
  }, [dispatch, shop_id, currentPage]);

  // Fetch products (react to filters/search/page)
  useEffect(() => {
    if (!shop_id) return;
    const isActive =
      productStatus === "all" ? undefined : productStatus === "true";
    dispatch(
      fetchMerchantProducts({
        shopId: Number(shop_id),
        page: currentPage,
        limit: 12,
        searchKeyword,
        isActive,
      })
    );
  }, [dispatch, shop_id, currentPage, searchKeyword, productStatus]);

  return (
    <div>
      {/* Global Backdrop Loader */}
      <Backdrop
        sx={{ color: "#fff", zIndex: (theme) => theme.zIndex.drawer + 9999 }}
        open={showLoader}
      >
        <CircularProgress color="inherit" />
      </Backdrop>

      <div className="mb-3">
        <GoBackButton onClick={() => navigate(-1)} />
      </div>

      {showAlert && <Alert>{alertMessage}</Alert>}

      {/* Merchant Details */}
      {!merchantDetails ? (
        <Alert severity="info">No merchant details available.</Alert>
      ) : (
        <MerchantDetailsCard
          merchantDetails={merchantDetails}
          orderTotalPrice={orderTotalPrice}
          orderTotalDeducted={orderTotalDeducted}
          ordersCount={ordersCount}
          triggerAlert={triggerAlert}
        />
      )}

      <div className="h-8" />

      {/* Products */}
      <Card>
        <Childstyle>
          {/* Toolbar */}
          <div className="m-5 w-11/12 flex justify-between">
            <TextField
              label="Search Products..."
              variant="outlined"
              slotProps={{ input: { type: "search" } }}
              onChange={(e) => setsearchKeyword(e.target.value)}
              sx={{
                "& .MuiOutlinedInput-root": { borderRadius: "9999px" },
                "& .MuiOutlinedInput-notchedOutline": {
                  borderRadius: "9999px",
                },
              }}
              className="w-1/3"
            />

            <FormControl
              variant="outlined"
              sx={{ m: 0, minWidth: 180 }}
              size="small"
            >
              <Select
                value={productStatus}
                onChange={(e) =>
                  setProductStatus(
                    (e.target.value as "all" | "true" | "false") ?? "all"
                  )
                }
                sx={{
                  "& .MuiSelect-select": {
                    display: "flex",
                    alignItems: "center",
                    gap: 1,
                  },
                  borderRadius: "9999px",
                }}
                displayEmpty
              >
                <MenuItem value="all">
                  <ListItemIcon sx={{ minWidth: "auto", mr: 1 }}>
                    <CheckCircleIcon
                      sx={{ opacity: 0.5, fontSize: "1.2rem" }}
                    />
                  </ListItemIcon>
                  <ListItemText primary="All Products" />
                </MenuItem>

                <MenuItem value="true">
                  <ListItemIcon sx={{ minWidth: "auto", mr: 1 }}>
                    <CheckCircleIcon
                      sx={{ color: "#4caf50", fontSize: "1.2rem" }}
                    />
                  </ListItemIcon>
                  <ListItemText primary="Active Products" />
                </MenuItem>

                <MenuItem value="false">
                  <ListItemIcon sx={{ minWidth: "auto", mr: 1 }}>
                    <CancelIcon sx={{ color: "#f44336", fontSize: "1.2rem" }} />
                  </ListItemIcon>
                  <ListItemText primary="Inactive Products" />
                </MenuItem>
              </Select>
            </FormControl>
          </div>

          {/* Grid */}
          <Grid
            container
            spacing={4}
            sx={{
              justifyContent: {
                xs: "center",
                md: "flex-start",
                lg: "flex-start",
              },
              marginLeft: 2,
            }}
          >
            {(productsLoading ? Array.from({ length: 8 }) : Products)?.map(
              (item: any, index: number) => (
                <Grid key={index} size={{ sm: 5, md: 4, lg: 3, xl: 2 }}>
                  {productsLoading ? (
                    <ProductSkeletonCard key={index} />
                  ) : (
                    <ProductCard
                      item={item}
                      index={index}
                      merchantCurrency={merchantDetails?.shop_currency || "PKR"}
                      loadedProducts={loadedProducts}
                      handleImageLoad={handleImageLoad}
                      handleImageClick={handleImageClick}
                    />
                  )}
                </Grid>
              )
            )}
          </Grid>

          {/* Empty state */}
          {!productsLoading && (!Products || Products.length === 0) && (
            <Box sx={{ py: 4, textAlign: "center", width: "100%" }}>
              <Typography color="text.secondary">
                No products to display.
              </Typography>
            </Box>
          )}
        </Childstyle>

        {/* Pagination */}
        <div className="m-5 py-1">
          {merchant_product_pagination?.totalPages > 1 && (
            <Pagination
              onChange={handlePageChange}
              count={merchant_product_pagination?.totalPages || 1}
              page={currentPage || 1}
              variant="outlined"
              shape="rounded"
              color="primary"
            />
          )}
        </div>
      </Card>

      {/* Product modal */}
      <ProductModal
        open={open}
        handleClose={handleClose}
        selectedProduct={selectedProduct}
      />
    </div>
  );
};

export default MerchantDetail;
