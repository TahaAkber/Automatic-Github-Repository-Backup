import React from "react";
import {
  Card,
  CardMedia,
  Typography,
  Chip,
  Box,
  Skeleton,
  Grow,
  Fade,
  Slide,
} from "@mui/material";

interface ProductCardProps {
  item: any;
  index: number;
  merchantCurrency: string;
  loadedProducts: Set<number>;
  handleImageLoad: (index: number) => void;
  handleImageClick: (item: any) => void;
}

const ProductCard: React.FC<ProductCardProps> = ({
  item,
  index,
  merchantCurrency,
  loadedProducts,
  handleImageLoad,
  handleImageClick,
}) => {
  return (
    <Grow
      in={true}
      timeout={((index % 4) + 1) * 200}
      style={{
        transformOrigin: "center bottom",
        marginLeft: 5,
      }}
    >
      <Card
        className="rounded-md"
        sx={{
          width: 200,
          height: 240,
          display: "flex",
          flexDirection: "column",
          justifyContent: "space-between",
          p: 2,
          transition: "all 0.3s ease-in-out",
          "&:hover": {
            transform: "translateY(-4px)",
            boxShadow: "0 8px 25px rgba(0,0,0,0.15)",
          },
        }}
      >
        {/* Product Image */}
        <Box
          sx={{
            position: "relative",
            overflow: "hidden",
            borderRadius: "8px",
          }}
        >
          {!loadedProducts.has(index) && (
            <Skeleton
              variant="rounded"
              height={150}
              sx={{
                borderRadius: "8px",
                position: "absolute",
                top: 0,
                left: 0,
                right: 0,
                bottom: 0,
                zIndex: 1,
              }}
            />
          )}
          <Fade in={loadedProducts.has(index)} timeout={500}>
            <CardMedia
              sx={{
                height: 150,
                borderRadius: "8px",
                cursor: "pointer",
                transition: "transform 0.3s ease-in-out",
                "&:hover": {
                  transform: "scale(1.05)",
                },
              }}
              image={item.product_image_url}
              title={item.product_name}
              onClick={() => handleImageClick(item)}
              component="div"
            />
          </Fade>
          {/* hidden preload image to trigger handleImageLoad */}
          <img
            src={item.product_image_url}
            alt={item.product_name}
            onLoad={() => handleImageLoad(index)}
            style={{
              opacity: 0,
              position: "absolute",
              top: "-9999px",
              left: "-9999px",
            }}
          />
        </Box>

        {/* Product Details */}
        <Slide
          direction="up"
          in={loadedProducts.has(index)}
          appear={true}
          timeout={400}
        >
          <div className="my-1">
            <Typography
              fontSize={15}
              component="div"
              className="text-start font-medium line-clamp-2"
              sx={{
                opacity: loadedProducts.has(index) ? 1 : 0,
                transition: "opacity 0.3s ease-in-out",
              }}
            >
              {item.product_name}
            </Typography>

            <Typography
              fontSize={12}
              sx={{
                color: "text.secondary",
                textAlign: "start",
                opacity: loadedProducts.has(index) ? 1 : 0,
                transition: "opacity 0.3s ease-in-out",
              }}
            >
              {merchantCurrency} {item.variant_price}
            </Typography>

            <Chip
              label={item.product_custom_category}
              style={{ fontSize: 12, marginTop: 3 }}
            />
          </div>
        </Slide>
      </Card>
    </Grow>
  );
};

export default ProductCard;
