import {
  Alert,
  Button,
  Card,
  CircularProgress,
  Grid,
  Snackbar,
  TextField,
  Typography,
} from "@mui/material";
import React, { useEffect, useRef, useState } from "react";
import InputFileUpload from "../../components/Notifications/ImageUpload";
import Parentstyle from "../Style/Parentstyle";
import Childstyle from "../Style/childstyle";
import { useAppDispatch, useAppSelector } from "../hooks/hooks";
import { useNavigate, useParams } from "react-router-dom";
import GoBackButton from "../button/Goback";
import {
  fetchbrands,
  updateBrandThunk,
} from "../../redux/thunks/merchantThunks";

export const appUrl = import.meta.env.VITE_APP_URL;
const UPLOAD_API = `${appUrl}/api/upload/`;

const MerchantEdit: React.FC = () => {
  const { brandId } = useParams<{ brandId: string }>();
  const navigate = useNavigate();
  const dispatch = useAppDispatch();
  // Brand fields
  const [brandName, setBrandName] = useState("");
  const [brandDesc, setBrandDesc] = useState("");

  // Image upload states
  const [previewImage, setPreviewImage] = useState<string | null>(null);
  const [uploadedUrl, setUploadedUrl] = useState<string>("");
  const [uploadingImage, setUploadingImage] = useState(false);

  // UI states
  const [loading, setLoading] = useState(false);
  const [openSnackbar, setOpenSnackbar] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState("");
  const [snackbarSeverity, setSnackbarSeverity] = useState<"success" | "error">(
    "success"
  );

  const hiddenFileInputRef = useRef<HTMLInputElement>(null);

  // ================================
  // 🔹 Fetch brand details
  // ================================
  useEffect(() => {
    dispatch(fetchbrands({ page: 1, limit: 1000, searchKeyword: "" }));
  }, []);

  const { brands } = useAppSelector((state) => state.merchants);

  useEffect(() => {
    if (brands?.length && brandId) {
      const brand = brands.find((b) => Number(b.brand_id) === Number(brandId));

      if (brand) {
        setBrandDesc(brand.brand_need_desc || "");
        setUploadedUrl(brand.brand_logo_url || "");
        setPreviewImage(brand.brand_logo_url || "");
        setBrandName(brand.brand_name || "");
      }
    }
  }, [brands, brandId]);
  console.log("brands", brands);
  console.log("brandId", brandId);
  // const fetchBrand = async () => {
  //     try {
  //         const res = await axios.get(`${appUrl}/api/brands/${brandId}`);
  //         const brand = res.data?.data;
  //
  //         console.log("Fetched Brand Details:", brand);
  //
  //         setBrandDesc(brand?.brand_need_desc || "");
  //         setUploadedUrl(brand?.brand_logo_url || "");
  //         setPreviewImage(brand?.brand_logo_url || "");
  //     } catch (err) {
  //         console.log("Error fetching brand:", err);
  //     }
  // };

  // ================================
  // 🔹 Upload Image
  // ================================
  const uploadImage = async (file: File) => {
    setUploadingImage(true);
    try {
      const fd = new FormData();
      fd.append("file", file);

      const res = await fetch(UPLOAD_API, { method: "POST", body: fd });
      const data = await res.json();

      console.log("Image Upload Response:", data);

      setUploadedUrl(data.url);
      setSnackbarMessage("Image uploaded successfully.");
      setSnackbarSeverity("success");
      setOpenSnackbar(true);
    } catch (err) {
      setSnackbarMessage("Image upload failed.");
      setSnackbarSeverity("error");
      setOpenSnackbar(true);
    } finally {
      setUploadingImage(false);
    }
  };

  const handleHiddenInputChange = (e: any) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const preview = URL.createObjectURL(file);
    setPreviewImage(preview);

    uploadImage(file);
  };

  // ================================
  // 🔹 Update Brand
  // ================================
  const handleSubmit = async () => {
    if (!uploadedUrl || !brandName.trim() || !brandDesc.trim()) {
      setSnackbarSeverity("error");
      setSnackbarMessage("Please fill all fields");
      setOpenSnackbar(true);
      return;
    }

    const payload = {
      brand_id: Number(brandId),
      brand_need_desc: brandDesc,
      brand_logo_url: uploadedUrl,
      brand_name: brandName,
    };
    console.log("Payload sending to backend:", payload);

    setLoading(true);

    const res = await dispatch(updateBrandThunk(payload));
    console.log("res of the  merchant  brand name", res);

    if (updateBrandThunk.rejected.match(res)) {
      setSnackbarSeverity("error");
      setSnackbarMessage(res.payload || "Failed to update brand");
      setOpenSnackbar(true);
      setLoading(false);
      console.log("res.payload", res);
      return;
    }

    setSnackbarSeverity("success");
    setSnackbarMessage("Brand updated successfully!");
    setOpenSnackbar(true);

    setLoading(false);

    setTimeout(() => navigate("/brands"), 1200);
  };

  return (
    <Parentstyle>
      <div className="mb-3">
        <GoBackButton onClick={() => navigate(-1)} />
      </div>

      <Childstyle>
        <Typography variant="h6" fontWeight="medium" className="pb-5">
          Edit Brand
        </Typography>

        <Card
          sx={{
            borderRadius: "12px",
            border: "1px solid #e0e0e0",
            boxShadow: 1,
          }}
        >
          <Grid container direction="column">
            <Grid className="p-5">
              <div className="flex flex-col gap-5">
                <TextField
                  label="Brand Name"
                  fullWidth
                  size="small"
                  value={brandName}
                  onChange={(e) => setBrandName(e.target.value)}
                />

                <TextField
                  label="Brand Description"
                  fullWidth
                  size="small"
                  multiline
                  minRows={4}
                  value={brandDesc}
                  onChange={(e) => setBrandDesc(e.target.value)}
                />
              </div>
            </Grid>
          </Grid>

          {/* IMAGE */}
          <div className="flex justify-between items-center border-t border-b border-gray-200">
            <div className="p-5">
              {previewImage ? (
                <div className="relative inline-block">
                  <img
                    src={previewImage}
                    style={{
                      width: "140px",
                      height: "140px",
                      objectFit: "cover",
                      borderRadius: "12px",
                      border: "1px solid #ccc",
                    }}
                  />

                  <button
                    className="absolute bottom-2 right-2 rounded-md px-3 py-1 text-sm bg-white shadow border"
                    onClick={() => hiddenFileInputRef.current?.click()}
                  >
                    {uploadingImage ? "Uploading..." : "Change"}
                  </button>

                  <input
                    type="file"
                    accept="image/*"
                    ref={hiddenFileInputRef}
                    onChange={handleHiddenInputChange}
                    style={{ display: "none" }}
                  />
                </div>
              ) : (
                <InputFileUpload
                  onFileSelect={(files) =>
                    handleHiddenInputChange({ target: { files } })
                  }
                />
              )}
            </div>

            <div className="pr-5 flex items-center gap-4">
              <Button
                variant="contained"
                size="large"
                onClick={handleSubmit}
                disabled={loading || uploadingImage || !brandName}
              >
                Save Changes
              </Button>

              {(loading || uploadingImage) && <CircularProgress size={24} />}
            </div>
          </div>
        </Card>

        <Snackbar
          open={openSnackbar}
          autoHideDuration={2500}
          onClose={() => setOpenSnackbar(false)}
          anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
        >
          <Alert severity={snackbarSeverity}>{snackbarMessage}</Alert>
        </Snackbar>
      </Childstyle>
    </Parentstyle>
  );
};

export default MerchantEdit;
