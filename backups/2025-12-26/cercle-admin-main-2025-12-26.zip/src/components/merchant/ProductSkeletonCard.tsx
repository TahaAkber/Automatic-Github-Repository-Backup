import React from "react";
import { Card, Skeleton } from "@mui/material";

const ProductSkeletonCard: React.FC = () => {
  return (
    <Card
      className="rounded-md"
      sx={{
        width: 200,
        height: 240,
        display: "flex",
        flexDirection: "column",
        justifyContent: "space-between",
        p: 2,
      }}
    >
      <Skeleton variant="rounded" height={150} sx={{ borderRadius: "8px" }} />
      <div className="my-1">
        <Skeleton variant="text" width="90%" />
        <Skeleton variant="text" width="60%" />
      </div>
    </Card>
  );
};

export default ProductSkeletonCard;
