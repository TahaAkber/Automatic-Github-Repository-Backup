// MUI Imports
import Card from "@mui/material/Card";
import CardMedia from "@mui/material/CardMedia";
import CardContent from "@mui/material/CardContent";
import Avatar from "@mui/material/Avatar";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import Skeleton from "@mui/material/Skeleton";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router";
import { Box } from "@mui/material";
import AccessDenied from "./Accessdenied";

interface Props {
  canRead: boolean;
}
const MerchantCard = ({ canRead }: Props) => {
  const navigate = useNavigate();
  const { merchants, loading } = useSelector(
    (state: any) => state.merchants?.merchants
  );
  if (!canRead) {
    return (
      <AccessDenied
        subtitle="Your account is missing read permissions for merchant. Contact an admin if you need access."
        secondaryActionText="Contact admin"
        onSecondaryAction={() => {
          // open your support modal / route / mailto
          // e.g., navigate("/support") or open a dialog
          window.open("https://cymbiote.com/contact-us/", "_blank");
        }}
      />
    );
  }
  const skeletonArray = new Array(6).fill(null);
  return (
    <div className="flex justify-center  flex-wrap sm:gap-2 md:gap-16 lg:gap-x-20 justify-items-start">
      {loading
        ? skeletonArray.map((_, idx) => (
            <Card
              key={idx}
              elevation={0}
              sx={{
                width: 230,
                height: 320,
                display: "flex",
                flexDirection: "column",
                justifyContent: "space-between",
                borderRadius: 6,
              }}
              className="border-2 border-[#d05454]"
            >
              <Skeleton variant="rectangular" width="100%" height={112} />
              <CardContent className="flex flex-col items-center">
                <Skeleton variant="circular" width={100} height={100} />
                <Skeleton width="60%" height={30} sx={{ mt: 2, mb: 1 }} />
                <Skeleton width="80%" height={20} />
                <Skeleton width="70%" height={20} sx={{ mb: 2 }} />
                <Skeleton variant="rectangular" width={100} height={36} />
              </CardContent>
            </Card>
          ))
        : merchants?.map((merchant: any) => (
            <Card
              key={merchant.shop_url_id}
              elevation={0}
              sx={{
                width: 230,
                height: 300,
                display: "flex",
                flexDirection: "column",
                justifyContent: "space-between",
                borderRadius: 6,
              }}
              className="border-2 border-[#E5E5E5] mb-2 sm:mb-1.5 md:mb-0"
            >
              <Box position="relative">
                <CardMedia
                  component="img"
                  className="h-24"
                  sx={{
                    objectFit: "cover",
                    backgroundColor:
                      merchant.shop_color === "#fff"
                        ? "lightgray"
                        : merchant.shop_color,
                  }}
                  image={merchant.shop_image}
                />

                {merchant.shop_delisted && (
                  <Box
                    className="absolute top-0 left-0 w-full h-full flex items-center justify-center "
                    sx={{
                      position: "absolute",
                      top: "35%",
                      left: "50%",
                      transform: "translate(-50%, -50%)",
                      color: "red",

                      fontSize: "15px",
                      fontWeight: "",
                      borderRadius: "4px",
                      textAlign: "center",
                    }}
                  >
                    Delisted due to cancelled orders exceeding the threshold
                    amount
                  </Box>
                )}
              </Box>

              <CardContent className="flex flex-col items-center">
                <div className="relative flex flex-col items-center gap-3">
                  <Avatar
                    src={
                      merchant.shop_logo_url ||
                      "https://cdn.shopify.com/s/files/1/0595/2379/2944/files/img_not_found_cercle.jpg?v=1757333158"
                    }
                    alt={merchant.shop_name}
                    sx={{
                      width: 100,
                      height: 100,
                      border: "4px solid #fff",
                      marginTop: -8,
                    }}
                  />
                  <Box
                    display="flex"
                    alignItems="center"
                    justifyContent="center"
                    gap={1}
                  >
                    <Typography variant="h6" fontWeight="medium" noWrap>
                      {merchant.shop_name}
                    </Typography>

                    <Box
                      sx={{
                        width: 7,
                        height: 7,
                        borderRadius: "50%",
                        bgcolor: merchant.shop_delisted ? "red" : "#44b700",
                        display: "inline-block",
                      }}
                    />
                  </Box>
                  <div className="mb-3">
                    <span
                      className="flex flex-row justify-center items-center gap-1 w-full text-sm"
                      style={{
                        color: "gray",
                      }}
                    >
                      Seller ID # {merchant.shop_id}
                    </span>
                    <span
                      className="flex flex-row justify-center items-center gap-1 w-full text-sm"
                      style={{
                        color: "gray",
                      }}
                    >
                      {merchant.shop_email ? merchant.shop_email : "Email"}
                    </span>
                  </div>
                </div>
                <Button
                  variant="contained"
                  size="small"
                  style={{ backgroundColor: "#6966CD", marginTop: "auto" }}
                  className="mb-2"
                  onClick={() => {
                    navigate(`/merchants/details/${merchant.shop_id}`);
                  }}
                >
                  View Details
                </Button>
              </CardContent>
            </Card>
          ))}
    </div>
  );
};

export default MerchantCard;
