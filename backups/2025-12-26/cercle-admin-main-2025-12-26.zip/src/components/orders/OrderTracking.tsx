import { Card, Divider, Typography } from "@mui/material";
import React, { useEffect } from "react";
import CalendarTodayIcon from "@mui/icons-material/CalendarToday";
import TrackingStatuses from "./TrackingStatuses";
import OrderTrackingTable from "./OrderTrackingTable";
import Parentstyle from "../Style/Parentstyle";
import Childstyle from "../Style/childstyle";
import { useSelector } from "react-redux";
import { useNavigate, useParams } from "react-router";
import { useAppDispatch } from "../hooks/hooks";
import { formatOrderDate } from "../functions/formatOrderDate";
import { fetchtracking } from "../../redux/thunks/trackingThunks";
import GoBackButton from "../button/Goback";

const OrderTracking: React.FC = () => {
  const navigate = useNavigate();
  const dispatch = useAppDispatch();
  const { orderId } = useParams();

  useEffect(() => {
    if (orderId) {
      dispatch(fetchtracking({ id: parseInt(orderId) }));
    }
  }, [orderId, dispatch]);

  const trackingData = useSelector((state: any) => state.tracking.data);

  const order = trackingData?.order;
  const tracking = trackingData?.tracking;

  const formatteddate = formatOrderDate(order?.order_date ?? "Date");

  return (
    <Parentstyle>
      <div className="mb-3">
        <GoBackButton onClick={() => navigate(-1)} />
      </div>
      <Childstyle>
        <div className="m-2 p-1">
          <Typography variant="h6" fontWeight="medium">
            Order Details
          </Typography>
          <Typography
            variant="body2"
            className="pb-3 "
            color="text.secondary"
            fontSize={14}
          >
            Order ID {order?.order_title ?? "Title"}
          </Typography>
        </div>
        <Card
          sx={{
            borderRadius: "12px",
            border: "1px solid #e0e0e0",
            boxShadow: 1,
          }}
        >
          <div className="flex items-start p-2 m-2 gap-2">
            <CalendarTodayIcon color="primary" />
            <div className="flex flex-col gap-1">
              <Typography variant="body2" fontWeight="normal" color="primary">
                {formatteddate}
              </Typography>
              <Typography
                variant="body1"
                fontWeight="light"
                color="gray"
                className="text-gray-600"
              >
                Details for Order {order?.order_title ?? "Title"}
              </Typography>
            </div>
          </div>

          <Divider />
          <div className="p-2 m-5 shadow-sm">
            <div className="">
              <Typography fontSize={25} color="textprimary" fontWeight="medium">
                Details
              </Typography>
              <Typography
                fontSize={13}
                color="textprimary"
                fontStyle="normal"
                fontWeight="normal"
                className="text-gray-600"
              >
                Your items is on the way. Tracking information will be available
                within 24 hours.
              </Typography>
            </div>
          </div>
          <div className="m-5 py-5">
            <TrackingStatuses tracking={tracking} />
          </div>
          <div className="m-5 p-5">
            <OrderTrackingTable tracking={tracking} />
          </div>
        </Card>
      </Childstyle>
    </Parentstyle>
  );
};

export default OrderTracking;
