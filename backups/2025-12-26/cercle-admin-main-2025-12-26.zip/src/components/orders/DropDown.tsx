import React from "react";
import {
  FormControl,
  Select,
  MenuItem,
  InputLabel,
  Box,
  SelectChangeEvent,
  SxProps,
} from "@mui/material";

interface ShowDropdownProps<T extends string | number> {
  label?: string;
  options?: T[];
  value: T;
  onChange?: (value: T) => void;
  minWidth?: number;
  size?: "small" | "medium";
  sx?: SxProps;
}

const ShowDropdown: React.FC<{
  label?: string;
  options?: (string | number)[];
  value: string | number;
  onChange?: (value: string | number) => void;
  minWidth?: number;
  size?: "small" | "medium";
  sx?: SxProps;
}> = <T extends string | number>({
  label = "Select",
  options = [],
  value,
  onChange,
  minWidth = 110,
  size = "small",
  sx = {},
}: ShowDropdownProps<T>) => {
  const handleChange = (event: SelectChangeEvent<unknown>) => {
    const newValue = event.target.value as T;
    onChange?.(newValue);
  };

  return (
    <Box display="flex" alignItems="center" gap={1}>
      <FormControl
        size={size}
        variant="outlined"
        sx={{
          minWidth,
          "& .MuiOutlinedInput-root": {
            paddingRight: "8px",
          },
          ...sx,
        }}
      >
        <InputLabel id={`${label}-label`}>{label}</InputLabel>
        <Select
          labelId={`${label}-label`}
          value={value}
          onChange={handleChange}
          label={label}
        >
          {options.map((option) => (
            <MenuItem key={option} value={option}>
              {option}
            </MenuItem>
          ))}
        </Select>
      </FormControl>
    </Box>
  );
};

export default ShowDropdown;
