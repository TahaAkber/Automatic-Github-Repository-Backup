import { Card, Chip, Divider, Typography, Skeleton } from "@mui/material";
import React, { useEffect } from "react";
import CalendarTodayIcon from "@mui/icons-material/CalendarToday";
import CustomAvatar from "../../@core/components/mui/Avatar";
import OrderDetailTable from "./OrderDetailTable";
import { useNavigate, useParams } from "react-router";
import Parentstyle from "../Style/Parentstyle";
import Childstyle from "../Style/childstyle";
import { useAppDispatch } from "../hooks/hooks";
import { orderdetail } from "../../redux/thunks/orderThunks";
import { useSelector } from "react-redux";
import { formatOrderDate } from "../functions/formatOrderDate";
import LocalShippingIcon from "@mui/icons-material/LocalShipping";
import InfoIcon from "@mui/icons-material/Info";
import AccountBalanceWalletIcon from "@mui/icons-material/AccountBalanceWallet";
import GoBackButton from "../button/Goback";

const OrderDetail: React.FC = () => {
  const navigate = useNavigate();
  const dispatch = useAppDispatch();
  const { orderId } = useParams();

  useEffect(() => {
    if (orderId) {
      dispatch(orderdetail({ id: parseInt(orderId) }));
    }
  }, [dispatch, orderId]);

  const { orders, orderdetail_loading } = useSelector(
    (state: any) => state.orders
  );

  const isEmptyObj = (obj: any) =>
    !obj || (typeof obj === "object" && Object.keys(obj).length === 0);
  const isLoading = Boolean(orderdetail_loading ?? isEmptyObj(orders));

  const SafeText: React.FC<{
    children?: React.ReactNode;
    width?: number | string;
  }> = ({ children, width = 120 }) => {
    if (isLoading) return <Skeleton variant="text" width={width} height={18} />;
    const value = children as any;
    const isZero = value === 0 || value === "0";
    return <>{value || (isZero ? "0" : "–")}</>;
  };

  const formatMoney = (currency?: string, amount?: number) => {
    if (isLoading) return <Skeleton variant="text" width={100} height={18} />;
    if (amount == null) return "–";
    return `${currency ?? ""}${currency ? " " : ""}${amount.toFixed(2)}`;
  };

  const formattedDate = isLoading
    ? null
    : formatOrderDate(orders?.order_date || null);

  const subtotal = orders?.order_total_amount ?? 0;
  const shipCost = orders?.order_shipping ?? 0;
  const grand = subtotal + shipCost;
  const currency = orders?.transaction_currency ?? orders?.shop_currency;

  return (
    <Parentstyle>
      <div className="mb-3">
        <GoBackButton onClick={() => navigate(-1)} />
      </div>
      <Childstyle>
        <Typography variant="h6" fontWeight="medium">
          Order Details
        </Typography>
        <Typography
          variant="body2"
          className="pb-3"
          color="text.secondary"
          fontSize={14}
        >
          <SafeText>{`Order ID ${orders?.order_title ?? ""}`}</SafeText>
        </Typography>

        <Card
          sx={{
            borderRadius: "12px",
            border: "1px solid #e0e0e0",
            boxShadow: 1,
          }}
        >
          {/* Date + Order title */}
          <div className="flex items-start p-2 m-2 gap-2">
            <CalendarTodayIcon color="primary" fontSize="small" />
            <div className="flex flex-col gap-1">
              <Typography variant="body2" fontWeight="light" color="primary">
                <SafeText>{formattedDate}</SafeText>
              </Typography>
              <Typography
                variant="body1"
                fontWeight="light"
                color="#686868"
                className="text-gray-600"
              >
                <SafeText>{`Details for Order ${
                  orders?.order_title ?? ""
                }`}</SafeText>
              </Typography>
            </div>
          </div>

          <Divider />

          {/* Customer / Order Info / Deliver To */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-0 p-4">
            {/* Customer */}
            <div className="p-4 shadow-sm">
              <div className="flex gap-4">
                <CustomAvatar
                  color="primary"
                  className="self-start"
                  size={40}
                />
                <div className="flex flex-col gap-1">
                  <Typography fontSize={18} color="#686868">
                    Customer
                  </Typography>
                  <div
                    className="flex flex-col text-sm gap-1"
                    style={{ color: "#8F8F8F" }}
                  >
                    <span>
                      <SafeText>
                        {`${orders?.user_first_name ?? ""} ${
                          orders?.user_last_name ?? ""
                        }`.trim()}
                      </SafeText>
                    </span>
                    <span>
                      <SafeText>{orders?.user_email}</SafeText>
                    </span>
                    <span>
                      <SafeText>{orders?.user_phone}</SafeText>
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Order Info */}
            <div className="p-4 shadow-sm">
              <div className="flex gap-4">
                <CustomAvatar color="primary" className="self-start" size={40}>
                  <InfoIcon />
                </CustomAvatar>
                <div className="flex flex-col gap-1">
                  <Typography fontSize={18} color="#686868">
                    Order Info
                  </Typography>
                  <div
                    className="flex flex-col text-sm gap-1"
                    style={{ color: "#8F8F8F" }}
                  >
                    <span>
                      Shipping:{" "}
                      {isLoading ? (
                        <Skeleton variant="text" width={180} height={18} />
                      ) : orders?.order_delivery_address ? (
                        orders.order_delivery_address
                      ) : (
                        "–"
                      )}
                    </span>
                    <span>
                      Status:{" "}
                      <SafeText>{orders?.order_fulfillment_status}</SafeText>
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Deliver To */}
            <div className="p-4 shadow-sm">
              <div className="flex gap-4">
                <CustomAvatar color="primary" className="self-start" size={40}>
                  <LocalShippingIcon />
                </CustomAvatar>
                <div className="flex flex-col gap-1">
                  <Typography fontSize={18} color="#686868">
                    Deliver To
                  </Typography>
                  <div
                    className="flex flex-col text-sm gap-1"
                    style={{ color: "#8F8F8F" }}
                  >
                    {isLoading ? (
                      <>
                        <Skeleton variant="text" width={220} height={16} />
                        <Skeleton variant="text" width={180} height={16} />
                        <Skeleton variant="text" width={200} height={16} />
                      </>
                    ) : orders?.order_shipping_address ? (
                      orders.order_shipping_address
                        .split(",")
                        .map((line: any, index: number) => (
                          <span key={index}>{String(line).trim() || "–"}</span>
                        ))
                    ) : (
                      <span>No shipping address available</span>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Billing Info */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-0 p-4">
            <div className="p-4 shadow-sm">
              <div className="flex gap-4">
                <CustomAvatar color="primary" className="self-start" size={40}>
                  <AccountBalanceWalletIcon />
                </CustomAvatar>
                <div className="flex flex-col gap-1">
                  <Typography fontSize={18} color="#686868">
                    Billing Info
                  </Typography>
                  <div
                    className="flex flex-col text-sm gap-1"
                    style={{ color: "#8F8F8F" }}
                  >
                    <span>
                      Cercle Commission Rate:{" "}
                      <SafeText>{`${
                        orders?.order_charge_rate ?? "–"
                      }%`}</SafeText>
                    </span>
                  </div>

                  <div
                    className="flex flex-col text-sm gap-1"
                    style={{ color: "#8F8F8F" }}
                  >
                    <span>
                      Cercle Commission:{" "}
                      {isLoading ? (
                        <Skeleton variant="text" width={100} height={18} />
                      ) : (
                        (
                          (orders?.order_total_amount ?? 0) *
                          ((orders?.order_charge_rate ?? 0) / 100)
                        ).toFixed(2)
                      )}
                    </span>
                  </div>

                  <div
                    className="flex flex-col text-sm gap-1"
                    style={{ color: "#8F8F8F" }}
                  >
                    <span>
                      Transaction Status:{" "}
                      <SafeText>{orders?.order_payment_status}</SafeText>
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Table */}
          <div className="flex flex-col lg:flex-row gap-6 lg:gap-14">
            <div className="grid grid-cols-1 gap-0 p-4 w-full lg:w-full">
              {isLoading ? (
                <>
                  <Skeleton variant="rounded" height={40} sx={{ mb: 1 }} />
                  <Skeleton variant="rounded" height={40} sx={{ mb: 1 }} />
                  <Skeleton variant="rounded" height={40} sx={{ mb: 1 }} />
                </>
              ) : (
                <OrderDetailTable />
              )}
              <Divider />
            </div>
          </div>

          {/* Totals */}
          <div className="w-11/12 flex flex-col items-end max-w-full my-5">
            <div className="flex justify-between w-full max-w-48">
              <Typography fontSize={14} color="textprimary">
                Subtotal:
              </Typography>
              <Typography fontSize={14} fontWeight="bold">
                {formatMoney(currency, subtotal)}
              </Typography>
            </div>
            <div className="flex justify-between w-full max-w-48">
              <Typography fontSize={14} color="textprimary">
                Shipping Cost:
              </Typography>
              <Typography fontSize={14} fontWeight="bold">
                {formatMoney(currency, shipCost)}
              </Typography>
            </div>
            <div className="flex justify-between w-full max-w-48">
              <Typography fontSize={14} color="textprimary">
                Grandtotal:
              </Typography>
              <Typography fontSize={14} fontWeight="bold">
                {formatMoney(currency, grand)}
              </Typography>
            </div>
            <div className="flex justify-between w-full max-w-48">
              <Typography fontSize={14} color="textprimary">
                Status:
              </Typography>
              {isLoading ? (
                <Skeleton variant="rounded" width={80} height={20} />
              ) : (
                <Chip
                  label={orders?.order_payment_status || "–"}
                  sx={{
                    backgroundColor: "#afffd4",
                    color: "#000",
                    fontWeight: 400,
                    height: 20,
                  }}
                />
              )}
            </div>
          </div>
        </Card>
      </Childstyle>
    </Parentstyle>
  );
};

export default OrderDetail;
