import { useEffect } from "react";
import { useSelector } from "react-redux";
import { useAppDispatch } from "../../components/hooks/hooks";
import { cancelOrders } from "../../../src/redux/thunks/orderThunks";
import { formatDate } from "../../components/functions/formateDate";
import { Avatar, Link, CircularProgress } from "@mui/material";

interface ReviewsTableProps {
  limit: number;
  search: string;
  currentPage: number;
  filters: string;
}

const CancelledOrders = ({
  limit,
  search,
  currentPage,
  filters,
}: ReviewsTableProps) => {
  const dispatch = useAppDispatch();

  useEffect(() => {
    dispatch(
      cancelOrders({
        page: currentPage,
        limit,
        search,
        order_cancelled_by: filters,
      })
    );
  }, [dispatch, currentPage, limit, search, filters]);

  const { cancelledOrders = [], loading } = useSelector(
    (state: any) => state.orders
  );

  return (
    <div className="overflow-x-auto bg-white">
      <table className="min-w-full border-collapse">
        <thead className="bg-gray-50 border-b border-gray-200">
          <tr className="text-sm font-medium text-gray-500">
            <th className="text-left px-6 py-3">Order Title</th>
            <th className="text-left px-5 py-3">Store</th>
            <th className="text-left px-5 py-3">Cancelled By</th>
            <th className="text-left px-5 py-3">Staff Notes</th>
            <th className="text-left px-5 py-3">Order Date</th>
            <th className="text-left px-5 py-3">Order Details</th>
          </tr>
        </thead>

        <tbody>
          {loading ? (
            <tr>
              <td colSpan={5} className="px-6 py-8">
                <div className="flex items-center justify-center gap-3 text-gray-500">
                  <CircularProgress size={22} />
                  <span>Loading cancelled orders…</span>
                </div>
              </td>
            </tr>
          ) : cancelledOrders.length === 0 ? (
            <tr>
              <td colSpan={5} className="px-6 py-8 text-center ">
                No cancelled orders found.
              </td>
            </tr>
          ) : (
            cancelledOrders.map((order: any) => (
              <tr
                key={order.order_id}
                className="text-sm font-medium  border-b"
              >
                <td className="text-left px-6 py-3">{order.order_title}</td>
                <td className="text-left px-5 py-3">
                  <div className="flex items-center gap-2">
                    <Avatar
                      src={order.shop_logo_url}
                      alt={order.shop_name}
                      sx={{ objectFit: "cover", width: 36, height: 36 }}
                    />
                    {order.shop_name}
                  </div>
                </td>
                <td className="text-left px-5 py-3">
                  {order.order_cancelled_by}
                </td>
                <td className="text-left px-5 py-3">
                  {order.order_cancelled_staff_notes || "No Notes"}
                </td>
                <td className="text-left px-5 py-3">
                  {formatDate(order.order_date)}
                </td>
                <td className="text-left px-5 py-3">
                  <Link href={`/orders/${order.order_id}`}>View Details</Link>
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
};

export default CancelledOrders;
