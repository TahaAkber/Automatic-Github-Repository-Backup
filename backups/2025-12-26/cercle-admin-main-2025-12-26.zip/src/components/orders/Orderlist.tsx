import React, { useEffect, useState } from "react";
import {
  Grid,
  TextField,
  Box,
  Card,
  Divider,
  Pagination,
  InputAdornment,
  MenuItem,
  Select,
  FormControl,
  SelectChangeEvent,
} from "@mui/material";
import Table from "../../views/dashboard/Table";
import Parentstyle from "../Style/Parentstyle";
import { useAppDispatch } from "../hooks/hooks";
import { fetchOrders } from "../../redux/thunks/orderThunks";
import { useSelector } from "react-redux";
import SearchIcon from "@mui/icons-material/Search";
import { RoleLike } from "../../components/functions/Roles";
import { useRolePermissions } from "../../components/functions/useRolePermissions";
const Orderlist = () => {
  const { pagination, loading } = useSelector((state: any) => state.orders);
  const dispatch = useAppDispatch();

  const [currentPage, setCurrentPage] = useState(1);
  const [limit, setLimit] = useState(10);
  const [fulfilementStatus, setfulfilementStatus] = useState("All");
  const [searchKeyword, setSearchKeyword] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  console.log(loading, "loading from orderlist");
  const handlePageChange = (_: React.ChangeEvent<unknown>, page: number) => {
    setCurrentPage(page);
  };
  const rawRoles = useSelector((state: any) => state.auth.user?.roles) as
    | RoleLike[]
    | undefined;
  const { can } = useRolePermissions(rawRoles);
  const canRead = can("orders", "read");

  useEffect(() => {
    dispatch(
      fetchOrders({
        page: currentPage,
        limit,
        fulfilementstatus: fulfilementStatus === "All" ? "" : fulfilementStatus,
        shopName: debouncedSearch,
      })
    );
  }, [dispatch, currentPage, limit, fulfilementStatus, debouncedSearch]);
  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedSearch(searchKeyword);
    }, 200);
    return () => clearTimeout(handler);
  }, [searchKeyword]);
  return (
    <Parentstyle>
      <h1 className="text-2xl font-semibold mb-2">Orders</h1>

      <Card
        className="px-4 w-full"
        sx={{
          borderRadius: "12px",
          border: "1px solid #e0e0e0",
          boxShadow: 1,
        }}
      >
        <Grid container direction="column">
          {canRead && (
            <Grid
              container
              alignItems="center"
              justifyContent="space-between"
              flexWrap="wrap"
              className="max-w-full"
            >
              <Grid
                size={{ xs: 12, md: 5 }}
                sx={{ padding: { xs: "10px", md: "0px" } }}
              >
                <TextField
                  id="search-orders"
                  label="Search Merchant"
                  variant="outlined"
                  autoComplete="off"
                  fullWidth
                  size="small"
                  value={searchKeyword}
                  onChange={(e) => {
                    setSearchKeyword(e.target.value);
                    setCurrentPage(1); // Reset to page 1 when searching
                  }}
                  InputProps={{
                    endAdornment: (
                      <InputAdornment position="end">
                        <SearchIcon />
                      </InputAdornment>
                    ),
                  }}
                />
              </Grid>

              <Grid
                className="max-w-full"
                sx={{ padding: { xs: "10px", md: "20px" } }}
              >
                <Box
                  display="flex"
                  gap={5}
                  justifyContent={{ xs: "center", md: "flex-start" }}
                  alignItems="center"
                >
                  <FormControl className="w-32" size="small">
                    <Select
                      size="small"
                      labelId="helper-label1"
                      id="select-helper1"
                      className="w-32"
                      value={limit.toString()}
                      onChange={(e: SelectChangeEvent) => {
                        setLimit(Number(e.target.value));
                        setCurrentPage(1); // reset page to 1 when limit changes
                      }}
                    >
                      <MenuItem value={10}>Data Number</MenuItem>
                      {/* <MenuItem value={10}>Ten</MenuItem> */}
                      <MenuItem value={20}>Twenty</MenuItem>
                      <MenuItem value={50}>Fifty</MenuItem>
                      <MenuItem value={100}>Hundred</MenuItem>
                    </Select>
                  </FormControl>
                  <FormControl className="w-32" size="small">
                    <Select
                      size="small"
                      labelId="helper-label1"
                      id="select-helper1"
                      className="w-32"
                      value={fulfilementStatus.toString() || "status"}
                      onChange={(e: SelectChangeEvent) => {
                        setfulfilementStatus(e.target.value);
                        setCurrentPage(1);
                      }}
                    >
                      <MenuItem value={"All"}>All</MenuItem>
                      <MenuItem value={"Fulfilled"}>Fulfilled</MenuItem>
                      <MenuItem value={"Unfulfilled"}>Unfulfilled</MenuItem>
                      <MenuItem value={"Partial"}>Partial</MenuItem>
                      <MenuItem value={"Pending"}>Pending</MenuItem>
                    </Select>
                  </FormControl>
                </Box>
              </Grid>
            </Grid>
          )}
          <Divider />
          <Grid className="max-w-full">
            <Table canRead={canRead} />
          </Grid>
        </Grid>
        <Divider />
        <div className="m-5 py-1">
          {canRead && pagination?.totalPages > 1 && (
            <Pagination
              onChange={handlePageChange}
              count={pagination?.totalPages || 1}
              page={currentPage}
              variant="outlined"
              shape="rounded"
              color="primary"
            />
          )}
        </div>
      </Card>
    </Parentstyle>
  );
};

export default Orderlist;
