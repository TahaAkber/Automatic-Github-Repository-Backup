import React from "react";
import tableStyles from "../../@core/styles/table.module.css";

type TableBodyRowType = {
  time: string;
  date: string;
  description: string;
  location: string;
};

const OrderTrackingTable: React.FC<{ tracking: any }> = ({ tracking }: any) => {
  let rowsData: TableBodyRowType[] = [];
  try {
    const parsedEvents = JSON.parse(tracking?.tracking_events || "[]");
    console.log("tracking", parsedEvents, rowsData);

    rowsData = parsedEvents.map((event: any) => {
      // Use time_raw if available, otherwise fallback to time_iso
      let date = event.time_raw?.date;
      let time = event.time_raw?.time;

      if (!date || !time) {
        // Try parsing time_iso fallback: e.g., "Mar 4, 2025(07:23 PM),"
        const timeIso = event.time_iso || "";
        const [datePart, timePartWithComma] = timeIso.split("(");
        date = date || datePart?.trim();
        time = time || timePartWithComma?.replace("),", "").trim();
      }

      return {
        date: date || "-",
        time: time || "-",
        description: event.description || "-",
        location:
          event.address?.city ||
          event.address?.street ||
          event.address?.state ||
          "Unknown",
      };
    });
  } catch (e) {
    console.error("Failed to parse tracking events", e);
  }

  return (
    <div className="overflow-x-auto">
      <table className={tableStyles.table}>
        <thead className="bg-gray-100 border-b border-gray-200">
          <tr className="font-bold text-[#343942B2]">
            <th className="px-6 py-3">Date</th>
            <th className="px-6 py-3">Time</th>
            <th className="px-6 py-3">Description</th>
            <th className="px-6 py-3">Location</th>
          </tr>
        </thead>
        <tbody>
          {rowsData.map((row, index) => (
            <tr
              key={index}
              className="border-b border-gray-200 text-sm text-gray-800"
            >
              <td className="px-6 py-4 whitespace-nowrap">{row.date}</td>
              <td className="px-6 py-4 whitespace-nowrap">{row.time}</td>
              <td className="px-6 py-4">{row.description}</td>
              <td className="px-6 py-4">{row.location}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default OrderTrackingTable;
