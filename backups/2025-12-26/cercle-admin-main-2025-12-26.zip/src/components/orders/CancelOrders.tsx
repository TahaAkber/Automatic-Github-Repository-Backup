import {
  Card,
  FormControl,
  InputAdornment,
  MenuItem,
  Pagination,
  Select,
  SelectChangeEvent,
  TextField,
} from "@mui/material";
import Childstyle from "../Style/childstyle";
import Parentstyle from "../Style/Parentstyle";
import SearchIcon from "@mui/icons-material/Search";
import { useState } from "react";
import { useSelector } from "react-redux";
import { RoleLike } from "../../components/functions/Roles";
import { useRolePermissions } from "../../components/functions/useRolePermissions";
import AccessDenied from "../../components/merchant/Accessdenied";
import CancelledOrders from "./CancelledOrders";

const CancelOrders = () => {
  const [search, setSearch] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [limit] = useState(10);
  const rawRoles = useSelector((state: any) => state.auth.user?.roles) as
    | RoleLike[]
    | undefined;
  const [filters, setFilters] = useState("");
  const { pagination } = useSelector((state: any) => state.orders);
  const { can } = useRolePermissions(rawRoles);
  const handlePageChange = (_: React.ChangeEvent<unknown>, page: number) => {
    setCurrentPage(page);
  };
  const canRead = can("users", "read");
  const canWrite = can("users", "write");

  if (!canRead) {
    return (
      <AccessDenied
        subtitle="Your account is missing read permissions for user. Contact an admin if you need access."
        secondaryActionText="Contact admin"
        onSecondaryAction={() => {
          // open your support modal / route / mailto
          // e.g., navigate("/support") or open a dialog
          window.open("https://cymbiote.com/contact-us/", "_blank");
        }}
      />
    );
  }
  return (
    <Parentstyle>
      <Childstyle>
        <h1 className="text-2xl font-semibold mb-2">Cancelled Orders</h1>
        {canWrite && (
          <Card className="w-full p-5">
            <div className="flex my-5 justify-between ">
              <TextField
                size="small"
                id="input-with-icon-textfield"
                autoComplete="off"
                label="Search Shops..."
                className="border-x-black border-solid border w-96 rounded-md"
                slotProps={{
                  input: {
                    endAdornment: (
                      <InputAdornment position="end">
                        <SearchIcon />
                      </InputAdornment>
                    ),
                  },
                }}
                variant="outlined"
                placeholder="e.g... Zero LifeStyle"
                value={search}
                onChange={(e) => {
                  setSearch(e.target.value);
                  setCurrentPage(1); // Reset to page 1 when searching
                }}
              />

              <div className="flex gap-x-4">
                <FormControl className="w-32" size="small">
                  <Select
                    size="small"
                    labelId="helper-label1"
                    id="select-helper1"
                    className="w-32"
                    value={filters.toString()}
                    displayEmpty
                    onChange={(e: SelectChangeEvent) => {
                      setFilters(e.target.value);
                      setCurrentPage(1); // reset page to 1 when limit changes
                    }} // onChange={handleChange}
                    renderValue={(filters) => {
                      if (!filters)
                        return <span className="text-gray-500">Filters</span>;
                      return <span className="text-gray-500">{filters}</span>;
                    }}
                  >
                    <MenuItem value="">All</MenuItem>
                    <MenuItem value="Customer">Customer</MenuItem>
                    <MenuItem value="Merchant">Merchant</MenuItem>
                  </Select>
                </FormControl>
              </div>
            </div>

            <div>
              <CancelledOrders
                limit={limit}
                currentPage={currentPage}
                search={search}
                filters={filters}
              />
            </div>

            <div className="m-5 py-1">
              <Pagination
                onChange={handlePageChange}
                count={pagination?.totalPages}
                page={currentPage}
                variant="outlined"
                shape="rounded"
                color="primary"
              />
            </div>
          </Card>
        )}
      </Childstyle>
    </Parentstyle>
  );
};

export default CancelOrders;
