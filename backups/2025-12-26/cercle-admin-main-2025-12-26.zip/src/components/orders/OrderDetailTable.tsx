import React, { useEffect, useState } from "react";
import { Button, Menu, MenuItem, Tooltip } from "@mui/material";
import tableStyles from "../../@core/styles/table.module.css";
import axios from "axios";
import { appUrl } from "../../redux/thunks/authThunks";
import Cookies from "js-cookie";
import { useNavigate, useParams } from "react-router";
import {
  decryptToken,
} from "../../components/functions/encryption";

let decodedCryptoToken = decryptToken(Cookies.get("authToken") || "");
const fetchOrderItems = async (id: string | undefined) => {
  const { data } = await axios.get(`${appUrl}/api/orders/orderitems/${id}`, {
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${decodedCryptoToken}`,
    },
  });
  return data;
};

type TrackingRow = {
  tracking_id: number | string;
  tracking_order_item_id: number | string;
  count?: number; // when backend groups with COUNT(*)
};

type OrderItem = {
  product_image_url: string;
  product_name: string;
  order_item_price: number;
  order_item_quantity: number;
  order_item_id: string | number;
  // Expecting array of grouped rows; each row may have .count
  tracking_items?: TrackingRow[];
};

type OrderItemsPayload = {
  orderItems: OrderItem[];
};

const OrderDetailTable = () => {
  const navigate = useNavigate();
  const { orderId } = useParams();

  // data
  const [orderitems, setOrderitems] = useState<OrderItemsPayload>({
    orderItems: [],
  });
  const [loading, setLoading] = useState<boolean>(false);

  // per-row menu state
  const [menuAnchor, setMenuAnchor] = useState<HTMLElement | null>(null);
  const [menuRowIndex, setMenuRowIndex] = useState<number | null>(null);

  const openMenuForRow = (
    event: React.MouseEvent<HTMLButtonElement>,
    idx: number
  ) => {
    setMenuAnchor(event.currentTarget);
    setMenuRowIndex(idx);
  };
  const closeMenu = () => {
    setMenuAnchor(null);
    setMenuRowIndex(null);
  };

  useEffect(() => {
    if (!orderId) return;
    setLoading(true);
    fetchOrderItems(orderId)
      .then((data) => setOrderitems(data))
      .catch((err) => console.error("Error fetching order items:", err))
      .finally(() => setLoading(false));
  }, [orderId]);

  return (
    <div className="overflow-x-auto">
      <table className={tableStyles.table}>
        <thead className="bg-gray-100">
          <tr className="font-bold text-gray-500">
            <th>Product</th>
            <th>Unit Price</th>
            <th>Quantity</th>
            <th>Total</th>
            <th>Action</th>
          </tr>
        </thead>

        <tbody>
          {loading ? (
            <tr>
              <td colSpan={5} className="text-center text-gray-500">
                Loading…
              </td>
            </tr>
          ) : orderitems.orderItems.length > 0 ? (
            orderitems.orderItems.map((item, index) => {
              const hasTracking =
                Array.isArray(item.tracking_items) &&
                item.tracking_items.length > 0;

              return (
                <tr key={index} className="text-black">
                  <td className="font-medium">
                    <div className="flex items-center gap-3">
                      <img
                        src={
                          item.product_image_url ||
                          "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQoFRQjM-wM_nXMA03AGDXgJK3VeX7vtD3ctA&s"
                        }
                        alt="image"
                        className="w-10 h-10 object-cover rounded"
                        onError={(e) => {
                          const target = e.target as HTMLImageElement;
                          target.src = "https://cdn.shopify.com/s/files/1/0595/2379/2944/files/img_not_found_cercle.jpg?v=1757333158";
                        }}
                      />
                      <span>{item.product_name || "No Product Name"}</span>
                    </div>
                  </td>

                  <td>{item.order_item_price?.toLocaleString?.() ?? "N/A"}</td>
                  <td>{item.order_item_quantity?.toLocaleString?.() ?? "0"}</td>
                  <td>
                    {(
                      (item.order_item_price || 0) *
                      (item.order_item_quantity || 0)
                    ).toLocaleString()}
                  </td>

                  <td>
                    <div>
                      <Tooltip
                        title={
                          hasTracking
                            ? ""
                            : "No tracking available for this item"
                        }
                        disableHoverListener={hasTracking}
                        arrow
                      >
                        <span>
                          <Button
                            variant="outlined"
                            color="primary"
                            size="small"
                            className="cursor-pointer"
                            id={`view-tracking-${index}`}
                            aria-controls={
                              menuRowIndex === index
                                ? "tracking-menu"
                                : undefined
                            }
                            aria-haspopup="true"
                            aria-expanded={
                              menuRowIndex === index ? "true" : undefined
                            }
                            onClick={(e) => openMenuForRow(e, index)}
                            disabled={!hasTracking}
                          >
                            View Tracking
                          </Button>
                        </span>
                      </Tooltip>

                      {/* Per-row menu */}
                      <Menu
                        id="tracking-menu"
                        anchorEl={menuAnchor}
                        open={menuRowIndex === index}
                        onClose={closeMenu}
                        MenuListProps={{
                          "aria-labelledby": `view-tracking-${index}`,
                        }}
                        sx={{ mt: 1 }}
                      >
                        {hasTracking ? (
                          // For each grouped tracking row, if 'count' > 1, repeat entries
                          item.tracking_items!.flatMap((trackingItem) => {
                            const repeat = Math.max(1, trackingItem.count ?? 1);
                            return Array.from({ length: repeat }).map(
                              (_, n) => {
                                const labelSuffix =
                                  repeat > 1 ? ` (#${n + 1})` : "";
                                return (
                                  <MenuItem
                                    key={`${trackingItem.tracking_id}-${n}`}
                                    onClick={() => {
                                      navigate(
                                        `/orders/tracking/${trackingItem.tracking_id}`
                                      );
                                      closeMenu();
                                    }}
                                    sx={{ mb: 1 }}
                                  >
                                    {`Tracking ID: ${trackingItem.tracking_id}${labelSuffix}`}
                                  </MenuItem>
                                );
                              }
                            );
                          })
                        ) : (
                          <MenuItem onClick={closeMenu} sx={{ mb: 1 }}>
                            No tracking items available
                          </MenuItem>
                        )}
                      </Menu>
                    </div>
                  </td>
                </tr>
              );
            })
          ) : (
            <tr>
              <td colSpan={5} className="text-center text-gray-500">
                No items found for this order.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
};

export default OrderDetailTable;
