import React from "react";
import { Stepper, Step, StepLabel, Box, Typography } from "@mui/material";
import { formatToAMPM } from "../functions/formatOrderDate";

const statusColors: Record<string, string> = {
  "Order Received": "#2e7dc0", //
  Shipped: "#fcb913",
  "In Transit": "#f67f21",
  Delivered: "#23b577",
  Failed: "#FF0000",
};

const CustomStepIcon: React.FC<{
  active?: boolean;
  completed?: boolean;
  label: string;
}> = ({
  active,
  completed,
  label,
}: {
  active?: boolean;
  completed?: boolean;
  label: string;
}) => {
  const bgColor = completed || active ? statusColors[label] || "#ccc" : "#ccc";

  return (
    <Box
      sx={{
        width: 45,
        height: 45,
        borderRadius: "50%",
        backgroundColor: bgColor,
        display: "inline-block",
        zIndex: 1,
      }}
    />
  );
};

const statusStepMap: Record<string, number> = {
  ORDER_RECEIVED: 0,
  SHIPPED: 1,
  IN_TRANSIT: 2,
  DELIVERED: 3,
  FAILURE: 4,
};

const getTimeForStage = (events: any[], stage: string) => {
  const found = events.find(
    (e) =>
      (e.stage || "").toUpperCase() === stage ||
      (e.sub_status || "").toUpperCase().includes(stage)
  );
  console.log("found", found);
  return found?.time_raw?.time || "";
};

const TrackingStatuses = ({ tracking }: any) => {
  const currentStatus =
    tracking?.tracking_status?.toUpperCase() || "ORDER_RECEIVED";
  const activeStepIndex = statusStepMap[currentStatus] ?? 0;

  let events: any[] = [];
  try {
    events = JSON.parse(tracking.tracking_events || "[]");
  } catch (e) {
    console.error("Invalid tracking_events JSON", e);
  }

  const steps = [
    { label: "Order Received", stageKey: "ORDER_RECEIVED" },
    { label: "Shipped", stageKey: "SHIPPED" },
    { label: "In Transit", stageKey: "IN_TRANSIT" },
    { label: "Delivered", stageKey: "DELIVERED" },
    { label: "Failed", stageKey: "FAILURE" },
  ];

  const computedSteps = steps.map((step, index) => {
    let time = "";
    if (index === 0) {
      const orderDate = tracking?.order_date;
      time = orderDate
        ? new Date(orderDate).toLocaleDateString("en-GB", {
            day: "2-digit",
            month: "short",
            year: "numeric",
          })
        : "";
    } else {
      const eventTime = getTimeForStage(events, step.stageKey);
      time = formatToAMPM(eventTime);
    }

    // Special handling when current status is FAILURE
    let status: "completed" | "active" | "pending" = "pending";

    if (currentStatus === "FAILURE") {
      // Only the Failed step is active, all others pending (gray)
      status = index === activeStepIndex ? "active" : "pending";
    } else {
      // Normal flow for other statuses
      if (index < activeStepIndex) status = "completed";
      else if (index === activeStepIndex) status = "active";
      else status = "pending";
    }

    return { ...step, formattedtime: time, status };
  });

  return (
    <Box sx={{ width: "100%", position: "relative", overflowX: "auto", py: 1 }}>
      <Box
        sx={{
          position: "absolute",
          top: 30,
          left: 0,
          right: 0,
          height: 2,
          backgroundColor: "#e0e0e0",
          zIndex: 0,
        }}
      />
      <Stepper
        alternativeLabel
        activeStep={activeStepIndex}
        connector={null}
        sx={{ position: "relative", zIndex: 1 }}
      >
        {computedSteps.map((step, index) => (
          <Step key={index}>
            <StepLabel
              StepIconComponent={() => (
                <CustomStepIcon
                  active={step.status === "active"}
                  completed={step.status === "completed"}
                  label={step.label}
                />
              )}
            >
              <Typography fontWeight={500}>{step.label}</Typography>
              <Typography variant="caption" color="textSecondary">
                {step.formattedtime}
              </Typography>
            </StepLabel>
          </Step>
        ))}
      </Stepper>
    </Box>
  );
};

export default TrackingStatuses;
