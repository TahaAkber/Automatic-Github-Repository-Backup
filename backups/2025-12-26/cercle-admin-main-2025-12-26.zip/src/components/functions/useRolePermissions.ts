// src/utils/useRolePermissions.ts
import { useMemo, useCallback } from "react";
import { buildRoleMap, canAccess, RoleMap } from "./AccessRoles";
import { RoleLike } from "./Roles";

export function useRolePermissions(rawRoles: RoleLike[] | undefined) {
  const roleMap: RoleMap = useMemo(() => buildRoleMap(rawRoles), [rawRoles]);

  const can = useCallback(
    (roleName: string, perm: "read" | "write" = "read") =>
      canAccess(roleMap, roleName, perm),
    [roleMap]
  );

  return { roleMap, can };
}
