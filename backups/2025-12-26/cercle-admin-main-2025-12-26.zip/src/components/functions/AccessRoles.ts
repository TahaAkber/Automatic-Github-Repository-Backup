// src/utils/roles.ts
import { normalizeRole, RoleLike } from "./Roles";

export type RolePerms = { read: boolean; write: boolean };
export type RoleMap = Map<string, RolePerms>;

/** Build role map: role name -> { read, write } (OR-merge duplicates) */
export function buildRoleMap(roles: RoleLike[] | undefined): RoleMap {
  const map: RoleMap = new Map();
  (roles ?? []).forEach((r) => {
    const { name, read, write } = normalizeRole(r);
    if (!name) return;
    const key = name.toLowerCase();
    const prev = map.get(key) || { read: false, write: false };
    map.set(key, { read: prev.read || !!read, write: prev.write || !!write });
  });
  return map;
}

/**
 * Permission checker: write ≠ read; 'global' respected as-is (no blanket bypass).
 * If global has only read, user can read but cannot write.
 */
export function canAccess(
  roleMap: RoleMap,
  roleName: string,
  perm: "read" | "write" = "read"
): boolean {
  const key = roleName.toLowerCase();

  const role = roleMap.get(key);
  const allowedByRole =
    perm === "write" ? role?.write === true : role?.read === true;

  const global = roleMap.get("global");
  const allowedByGlobal =
    perm === "write" ? global?.write === true : global?.read === true;

  return Boolean(allowedByRole || allowedByGlobal);
}
