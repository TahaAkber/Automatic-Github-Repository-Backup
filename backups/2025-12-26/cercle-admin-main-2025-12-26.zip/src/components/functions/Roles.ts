// ⬇️ Add these helper types/functions near the top
export type RoleLike =
  | string
  | {
      admin_role_name?: string;
      role_assigned_read?: boolean | 0 | 1;
      role_assigned_write?: boolean | 0 | 1;
      // tolerate older variants too:
      name?: string;
      read?: boolean | 0 | 1;
      write?: boolean | 0 | 1;
      roles_isread?: boolean | 0 | 1;
      roles_iswrite?: boolean | 0 | 1;
      is_read?: boolean | 0 | 1;
      is_write?: boolean | 0 | 1;
    };

const truthy = (v: any) => v === true || v === 1 || v === "1";
export const normalizeRole = (r: RoleLike) => {
  if (typeof r === "string") {
    const n = r.toLowerCase().trim();
    return { name: n, read: n === "global", write: false }; // strings non-permissive except 'global'
  }
  const name = (r.admin_role_name ?? r.name ?? "").toLowerCase().trim();

  const write =
    truthy(r.role_assigned_write) ||
    truthy(r.write) ||
    truthy(r.roles_iswrite) ||
    truthy(r.is_write);

  // ⬇️ IMPORTANT: do NOT derive read from write anymore
  const read =
    truthy(r.role_assigned_read) ||
    truthy(r.read) ||
    truthy(r.roles_isread) ||
    truthy(r.is_read);

  return { name, read, write };
};
