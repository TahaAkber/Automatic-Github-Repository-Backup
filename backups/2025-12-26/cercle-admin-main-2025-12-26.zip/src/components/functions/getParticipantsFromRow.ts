export default function getParticipantsFromRow(row: any): string[] {
  try {
    // Prefer parsed array from backend if present
    if (Array.isArray(row?.shop_logos)) {
      const urls = row.shop_logos.filter(
        (u: any) => typeof u === "string" && u.trim()
      );
      const seen = new Set<string>();
      return urls.filter((u: string) =>
        seen.has(u) ? false : (seen.add(u), true)
      );
    }

    const src = row?.shops_json;
    const arr = typeof src === "string" ? JSON.parse(src) : src;
    if (!Array.isArray(arr)) return [];
    const urls = arr
      .map((x: any) => x?.shop_logo_url)
      .filter((u: any) => typeof u === "string" && u.trim());
    const seen = new Set<string>();
    return urls.filter((u: string) =>
      seen.has(u) ? false : (seen.add(u), true)
    );
  } catch {
    return [];
  }
}
