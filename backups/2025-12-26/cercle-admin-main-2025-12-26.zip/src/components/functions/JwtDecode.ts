import { jwtVerify } from "jose";

export async function decodeAndVerifyJWT(token: string, secret?: string) {
  try {
    if (secret) {
      const encoder = new TextEncoder();
      const secretKey = encoder.encode(secret);

      const { payload } = await jwtVerify(token, secretKey);
      console.log("✅ Token verified. Payload:", payload);
      return payload;
    } else {
      // No secret? Just decode payload without verification
      const base64Url = token.split(".")[1];
      const base64 = base64Url.replace(/-/g, "+").replace(/_/g, "/");
      const jsonPayload = decodeURIComponent(
        atob(base64)
          .split("")
          .map((c) => `%${("00" + c.charCodeAt(0).toString(16)).slice(-2)}`)
          .join("")
      );
      const payload = JSON.parse(jsonPayload);
      console.log("⚠️ Token decoded without verification. Payload:", payload);
      return payload;
    }
  } catch (error) {
    console.error("❌ Invalid Token:", error);
    return null;
  }
}
