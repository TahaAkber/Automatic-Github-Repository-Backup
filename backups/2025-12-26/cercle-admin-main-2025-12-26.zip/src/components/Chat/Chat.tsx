import { Card, Grid, TextField, Typography } from "@mui/material";
import React from "react";
import SearchIcon from "@mui/icons-material/Search";
import Messages from "./Messages";
import ChatHeader from "./ChatHeader";
import ChatContent from "./ChatContent";
import Parentstyle from "../Style/Parentstyle";
import Childstyle from "../Style/childstyle";

const Chat: React.FC = () => {
  return (
    <Parentstyle>
      <Childstyle>
        <div className="flex flex-col gap-4">
          <Typography variant="h6" fontWeight="bold">
            Inbox
          </Typography>
          <Card>
            <Grid spacing={4} container className="p-5">
              <Grid
                container
                spacing={3}
                direction="column"
                size={{ xs: 12, sm: 8, md: 6, lg: 4 }}
              >
                <Typography fontSize={22} fontWeight="bold">
                  Messages
                </Typography>

                <Grid
                  className="flex flex-col justify-self-center border-none bg-gray-100"
                  container
                  size={{ xs: 12 }}
                >
                  <TextField
                    id="search-messages"
                    label={
                      <>
                        <SearchIcon
                          fontSize="small"
                          sx={{
                            mr: 0.5,
                            verticalAlign: "middle",
                            backgroundColor: "#f1f1f1",
                          }}
                        />
                        Search Messages
                      </>
                    }
                    variant="outlined"
                    fullWidth
                    size="small"
                    sx={{
                      color: "text.secondary",
                      border: "none",
                    }}
                  />
                </Grid>

                <Grid
                  container
                  sx={{
                    flexDirection: "row",
                    mt: 2,
                    pr: 1,
                    overflowY: "auto",
                    height: "calc(100vh - 380px)",
                    justifyContent: "space-between",
                  }}
                >
                  {Array.from({ length: 20 }).map((_, index) => (
                    <Messages key={index} />
                  ))}
                </Grid>
              </Grid>

              <Grid
                size={8}
                container
                direction="column"
                sx={{
                  height: "80vh",
                  borderLeft: "1px solid #eee",
                  width: "full",
                }}
                gap={5}
              >
                <ChatHeader />
                <ChatContent />
              </Grid>
            </Grid>
          </Card>
        </div>
      </Childstyle>
    </Parentstyle>
  );
};

export default Chat;
