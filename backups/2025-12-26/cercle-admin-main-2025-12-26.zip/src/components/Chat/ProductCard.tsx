import { Box, Card, CardMedia, Rating, Typography } from "@mui/material";
import React from "react";

const ProductCard: React.FC = () => {
  return (
    <Card sx={{ display: "flex", width: "fit-content", p: 2 }}>
      <CardMedia
        component="img"
        sx={{ width: 90, height: 90, borderRadius: 2 }}
        image="https://cdn.shopify.com/s/files/1/0595/2379/2944/files/img_not_found_cercle.jpg?v=1757333158"
        alt="Product Image"
      />
      <Box display="flex" flexDirection="column" p={1}>
        <Typography fontWeight="bold" noWrap>
          Super Cropped Button...
        </Typography>
        <Box display="flex" alignItems="center" gap={1}>
          <Typography fontSize={14} fontWeight="bold">
            4.5
          </Typography>
          <Rating
            name="half-rating-read"
            defaultValue={2.5}
            precision={0.5}
            readOnly
            size="small"
          />
        </Box>
        <Typography variant="body2" color="primary" fontWeight="bold">
          $104.99
        </Typography>
      </Box>
    </Card>
  );
};

export default ProductCard;
