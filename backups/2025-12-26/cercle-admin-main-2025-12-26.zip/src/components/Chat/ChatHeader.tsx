import React from "react";
import { Avatar, Box, Typography, Divider } from "@mui/material";

const ChatHeader: React.FC = () => {
  return (
    <>
      <Box display="flex" alignItems="center" gap={2} px={2}>
        <Avatar
          alt="Florencio Dorrance"
          src="your-image-url.jpg"
          sx={{ width: 40, height: 40 }}
        />
        <Box display="flex" flexDirection="column">
          <Typography fontWeight="bold">Florencio Dorrance</Typography>
          <Box display="flex" alignItems="center" gap={1}>
            <Box
              sx={{
                width: 8,
                height: 8,
                borderRadius: "50%",
                backgroundColor: "green",
              }}
            />
            <Typography variant="body2" color="text.secondary">
              Online
            </Typography>
          </Box>
        </Box>
      </Box>
      <Divider />
    </>
  );
};

export default ChatHeader;
