import { Avatar, Box, Grid, Typography } from "@mui/material";
import React from "react";

const Messages: React.FC = () => {
  return (
    <Grid
      container
      className="flex justify-between  h-12 cursor-pointer"
      size={12}
    >
      <Box display="flex" alignItems="center" gap={2}>
        <Avatar
          alt="Florencio Dorrance"
          src="your-image-url.jpg"
          sx={{ width: 40, height: 40 }}
        />
        <Box display="flex" flexDirection="column">
          <Typography fontWeight="bold" fontSize={15}>
            Florencio Dorrance
          </Typography>
          <Box display="flex" alignItems="center" gap={1}>
            <Typography fontSize={12} color="text.secondary">
              Hi how are you?
            </Typography>
          </Box>
        </Box>
      </Box>
      <Typography fontSize={12} color="text.secondary">
        12m
      </Typography>
    </Grid>
  );
};

export default Messages;
