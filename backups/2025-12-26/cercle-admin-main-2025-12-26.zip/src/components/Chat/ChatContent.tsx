import React from "react";
import {
  Box,
  Typography,
  TextField,
  IconButton,
  Avatar,
  Grid,
} from "@mui/material";
import SendIcon from "@mui/icons-material/Send";
import ProductCard from "./ProductCard";

const ChatContent: React.FC = () => {
  return (
    <>
      <Box overflow="auto" p={2} display="flex" flexDirection="column" gap={5}>
        <ProductCard />

        {/* Messages Section */}
        <Grid container direction="column" spacing={2}>
          <Grid size={{ xs: 12 }}>
            <Box
              display="flex"
              flexDirection="column"
              alignItems="flex-start"
              gap={1}
            >
              <Box sx={{ display: "flex", alignItems: "center" }}>
                <Avatar />
                <Box
                  sx={{
                    backgroundColor: "#f1f1f1",
                    borderRadius: 2,
                    px: 2,
                    py: 1,
                    ml: 1,
                    maxWidth: { xs: "90%", sm: "80%" }, // Adjust based on screen size
                  }}
                >
                  <Typography variant="body2">It's Available?</Typography>
                </Box>
              </Box>
              <Box
                sx={{
                  backgroundColor: "#f1f1f1",
                  borderRadius: 2,
                  px: 2,
                  py: 1,
                  maxWidth: { xs: "90%", sm: "70%" }, // Adjust based on screen size
                }}
              >
                <Typography variant="body2">omg, this is amazing</Typography>
              </Box>
              <Box
                sx={{
                  backgroundColor: "#f1f1f1",
                  borderRadius: 2,
                  px: 2,
                  py: 1,
                  maxWidth: { xs: "90%", sm: "70%" }, // Adjust based on screen size
                }}
              >
                <Typography variant="body2">I want this product</Typography>
              </Box>
            </Box>
          </Grid>

          {/* Reply Section */}
          <Grid size={{ xs: 12 }}>
            <Box
              display="flex"
              flexDirection="column"
              alignItems="flex-end"
              gap={1}
            >
              <Box
                sx={{
                  display: "flex",
                  justifyContent: "flex-end",
                  width: "100%",
                }}
              >
                <Box
                  sx={{
                    display: "flex",
                    justifyContent: "flex-end",
                    width: "100%",
                    alignItems: "center",
                  }}
                >
                  <Box
                    sx={{
                      backgroundColor: "#7367f0",
                      color: "white",
                      borderRadius: 2,
                      px: 2,
                      py: 1,
                      mr: 1,
                      maxWidth: { xs: "90%", sm: "70%" }, // Adjust based on screen size
                    }}
                  >
                    <Typography variant="body2">Yes Its Available</Typography>
                  </Box>
                  <Avatar />
                </Box>
              </Box>
              <Box
                sx={{
                  backgroundColor: "#7367f0",
                  color: "white",
                  borderRadius: 2,
                  px: 2,
                  py: 1,
                  maxWidth: { xs: "90%", sm: "70%" }, // Adjust based on screen size
                }}
              >
                <Typography variant="body2">
                  we give you same product as you show in online store
                </Typography>
              </Box>
              <Box
                sx={{
                  backgroundColor: "#7367f0",
                  color: "white",
                  borderRadius: 2,
                  px: 2,
                  py: 1,
                  maxWidth: { xs: "90%", sm: "70%" }, // Adjust based on screen size
                }}
              >
                <Typography variant="body2">thank you!</Typography>
              </Box>
            </Box>
          </Grid>
        </Grid>

        {/* Message Input Section */}
        <Box
          p={2}
          display="flex"
          alignItems="center"
          justifyContent="center"
          gap={2}
          sx={{ borderTop: "1px solid #eee", marginTop: "auto" }}
        >
          <TextField
            placeholder="Type a message"
            fullWidth
            size="small"
            sx={{
              backgroundColor: "#f9f9f9",
              borderRadius: 2,
              maxWidth: { xs: "90%", sm: "100%" }, // Adjust width for smaller screens
            }}
          />
          <IconButton color="primary">
            <SendIcon />
          </IconButton>
        </Box>
      </Box>
    </>
  );
};

export default ChatContent;
