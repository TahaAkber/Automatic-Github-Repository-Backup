// src/search/useGlobalSearch.ts
import * as React from "react";
import { flattenRoutesForNav } from "./flattenRoutes";
import { filterByRoles, searchNav, NavResult } from "./localSearch";
import { useEffect } from "react";
import axios from "axios";
import Cookies from "js-cookie";
export const appUrl = import.meta.env.VITE_APP_URL;
import {
  decryptToken,
} from "../../components/functions/encryption";

let decodedCryptoToken = decryptToken(Cookies.get("authToken") || "");
type RemoteItem = {
  id: string;
  title: string;
  subtitle?: string;
  url: string;
  thumbnail?: string;
};
type Section = {
  items: RemoteItem[];
  loading: boolean;
  nextCursor?: string | null;
  error?: string | null;
};

export type GlobalResults = {
  nav: NavResult[];
  shops: Section;
  products: Section;
  // users: Section;
};

const emptySection = {
  items: [],
  loading: false,
  page: 1, // 👈 default page
  hasMore: true, // 👈 assume more initially
  error: null,
};

export default function useGlobalSearch(userRoles: string[] = []) {
  const [query, setQuery] = React.useState("");
  const [results, setResults] = React.useState<GlobalResults>({
    nav: [],
    shops: { ...emptySection },
    products: { ...emptySection },
    // users: { ...emptySection },
  });

  const navIndex = React.useMemo(() => {
    const all = flattenRoutesForNav();
    return filterByRoles(all, userRoles);
  }, [userRoles]);

  // LOCAL (instant)
  useEffect(() => {
    if (!query.trim()) {
      setResults((r) => ({ ...r, nav: [] }));
      return;
    }
    const nav = searchNav(navIndex, query);
    setResults((r) => ({ ...r, nav }));
  }, [query, navIndex]);

  // REMOTE (debounced)
  useEffect(() => {
    const q = query.trim();
    if (q.length < 2) {
      setResults((r) => ({
        ...r,
        shops: { ...emptySection },
        products: { ...emptySection },
      }));
      return;
    }

    const ctrl = new AbortController();
    const t = setTimeout(async () => {
      // Mark loading
      setResults((r) => ({
        ...r,
        shops: { ...r.shops, loading: true, error: null },
        products: { ...r.products, loading: true, error: null },
      }));

      try {
        // TODO: Replace with your API endpoint
        const res = await axios.get(
          `${appUrl}/api/search?query=${query}&page=1&limit=10`,
          {
            method: "GET",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${decodedCryptoToken}`,
            },
          }
        );
        // const data = await res.json();
        console.log("Data", res.data);
        const sections = res.data.result ?? {};
        const raw = Array.isArray(res.data?.result) ? res.data.result : [];

        // group by source
        const grouped = raw.reduce(
          (acc: Record<"shops" | "products" | "users", any[]>, row: any) => {
            const key = String(row.source || "").toLowerCase(); // 'shops' | 'products' | 'users'
            if (key === "shops" || key === "products" || key === "users") {
              acc[key].push(row);
            }
            return acc;
          },
          { shops: [], products: [], users: [] }
        );

        // helper: map backend row -> RemoteItem
        const toItem = (row: any) => {
          const id = row.id ?? row.shop_id ?? row.product_id ?? row.user_id;

          const title =
            row.title ??
            row.shop_name ??
            row.product_name ??
            row.user_name ??
            "";

          const subtitle =
            row.subtitle ??
            row.description ??
            row.shop_description ??
            row.product_description ??
            null;

          // build a URL per source (tweak to your routes)
          const src = String(row.source || "").toLowerCase();
          const url = src === "shops" ? `/merchants/details/${id}` : null;

          return {
            id: String(id),
            title: String(title),
            subtitle: subtitle ?? undefined,
            url,
            thumbnail: row.image_url,
          } as RemoteItem;
        };

        // map each group to RemoteItem[]
        const shopItems = grouped.shops.map(toItem);
        const productItems = grouped.products.map(toItem);
        const userItems = grouped.users.map(toItem);
        // finally set state
        setResults((r) => ({
          ...r,
          shops: {
            items: shopItems,
            loading: false,
            nextCursor: null,
            error: null,
          },
          products: {
            items: productItems,
            loading: false,
            nextCursor: null,
            error: null,
          },
          users: {
            items: userItems,
            loading: false,
            nextCursor: null,
            error: null,
          },
        }));

        console.log("sections", sections);
      } catch (e: any) {
        if (e.name === "AbortError") return;
        setResults((r) => ({
          ...r,
          shops: { ...r.shops, loading: false, error: "Failed" },
          products: { ...r.products, loading: false, error: "Failed" },
          // users: { ...r.users, loading: false, error: "Failed" },
        }));
      }
    }, 250);

    return () => {
      clearTimeout(t);
      ctrl.abort();
    };
  }, [query]);

  // “Show more” per-section
  const showMore = React.useCallback(
    async (section: "products" | "shops" | "users") => {
      // current page nikaalo (default 1)
      const currentPage = (results as any)[section]?.page ?? 1;
      const nextPage = currentPage + 1;

      setResults((r) => ({
        ...r,
        [section]: { ...(r as any)[section], loading: true },
      }));

      try {
        const res = await fetch(
          `${appUrl}/api/search?query=${encodeURIComponent(
            query
          )}&page=${nextPage}&limit=10`,
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${decodedCryptoToken}`,
            },
          }
        );

        const data = await res.json();
        const raw = Array.isArray(data?.result) ? data.result : [];

        // group rows by source
        const grouped = raw.reduce(
          (acc: Record<"shops" | "products" | "users", any[]>, row: any) => {
            const key = String(row.source || "").toLowerCase();
            if (key === "shops" || key === "products" || key === "users") {
              acc[key].push(row);
            }
            return acc;
          },
          { shops: [], products: [], users: [] }
        );

        // normalize row → RemoteItem
        const toItem = (row: any) => {
          const id = row.id ?? row.shop_id ?? row.product_id ?? row.user_id;
          const title =
            row.title ??
            row.shop_name ??
            row.product_name ??
            row.user_name ??
            "";
          const subtitle =
            row.subtitle ??
            row.description ??
            row.shop_description ??
            row.product_description ??
            null;
          const src = String(row.source || "").toLowerCase();
          const url = src === "shops" ? `/merchants/details/${id}` : null;
          return {
            id: String(id),
            title: String(title),
            subtitle: subtitle ?? undefined,
            url,
            thumbnail: row.image_url ? `${appUrl}${row.image_url}` : undefined,
          } as RemoteItem;
        };

        const newItems = grouped[section].map(toItem);

        // update only that section with append
        setResults((r) => ({
          ...r,
          [section]: {
            items: [...(r as any)[section].items, ...newItems],
            loading: false,
            page: nextPage,
            hasMore: newItems.length > 0, // check if more data available
            error: null,
          },
        }));
      } catch (err) {
        setResults((r) => ({
          ...r,
          [section]: {
            ...(r as any)[section],
            loading: false,
            error: "Failed",
          },
        }));
      }
    },
    [query, results]
  );

  return { query, setQuery, results, showMore };
}
