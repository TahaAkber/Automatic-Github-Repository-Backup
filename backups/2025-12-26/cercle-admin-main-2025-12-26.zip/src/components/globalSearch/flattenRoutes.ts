// src/search/flattenRoutes.ts
import type { RouteObject } from "react-router";
import router from "../../routes/routes";

export type NavHit = {
  path: string;
  label: string;
  keywords: string[];
  requiredRoles?: string[];
};

function joinPaths(parent: string, child?: string) {
  if (!child) return parent;
  const p = parent.endsWith("/") ? parent.slice(0, -1) : parent;
  const c = child.startsWith("/") ? child : `/${child}`;
  return (p + c).replace(/\/+/g, "/");
}

function getRequiredRoles(el: any): string[] | undefined {
  // Your PrivateRoute is used via `element: <PrivateRoute component={X} requiredRoles={[...]} />`
  return el?.props?.requiredRoles ?? undefined;
}

export function flattenRoutesForNav(
  routes: RouteObject[] = router.routes,
  parentPath = ""
): NavHit[] {
  const out: NavHit[] = [];
  for (const r of routes) {
    const thisPath = r.index
      ? parentPath || "/"
      : joinPaths(parentPath || "", r.path as string | undefined);
    const handle = (r as any).handle?.nav;
    const requiredRoles = getRequiredRoles((r as any).element);

    if (handle?.label) {
      out.push({
        path: thisPath || "/",
        label: handle.label,
        keywords: handle.keywords ?? [],
        requiredRoles,
      });
    }

    if (r.children?.length) {
      out.push(...flattenRoutesForNav(r.children, thisPath));
    }
  }
  // Deduplicate by path
  const seen = new Set<string>();
  return out.filter((h) =>
    seen.has(h.path) ? false : (seen.add(h.path), true)
  );
}
