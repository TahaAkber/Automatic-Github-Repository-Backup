// src/search/localSearch.ts
import type { NavHit } from "./flattenRoutes";

type RoleLike =
  | string
  | {
      admin_role_name?: string;
      role_assigned_read?: boolean | 0 | 1;
      role_assigned_write?: boolean | 0 | 1;
      // tolerate older variants too
      name?: string;
      read?: boolean | 0 | 1;
      write?: boolean | 0 | 1;
      roles_isread?: boolean | 0 | 1;
      roles_iswrite?: boolean | 0 | 1;
      is_read?: boolean | 0 | 1;
      is_write?: boolean | 0 | 1;
    };

const truthy = (v: any) => v === true || v === 1 || v === "1";

const normalizeRoleNames = (userRoles: RoleLike[]) => {
  const names = new Set<string>();
  for (const r of userRoles) {
    if (typeof r === "string") {
      names.add(r.toLowerCase());
      continue;
    }
    const name = (r.admin_role_name ?? r.name ?? "")
      .toString()
      .toLowerCase()
      .trim();
    if (!name) continue;

    // include role if user has read or write (write implies read)
    const hasWrite =
      truthy(r.role_assigned_write) ||
      truthy(r.write) ||
      truthy(r.roles_iswrite) ||
      truthy(r.is_write);
    const hasRead =
      hasWrite ||
      truthy(r.role_assigned_read) ||
      truthy(r.read) ||
      truthy(r.roles_isread) ||
      truthy(r.is_read);

    if (hasRead) names.add(name);
  }
  return names;
};

export function filterByRoles(hits: NavHit[], userRoles: RoleLike[] = []) {
  return hits.filter((h) => {
    if (!h.requiredRoles?.length) return true;

    const userRoleNames = normalizeRoleNames(userRoles);
    return h.requiredRoles.some((r) =>
      userRoleNames.has(String(r).toLowerCase())
    );
  });
}

function norm(s: string) {
  return s.toLowerCase().trim();
}

export type NavResult = NavHit & {
  score: number;
  highlightRanges?: [number, number][];
};

export function searchNav(hits: NavHit[], q: string): NavResult[] {
  const nQ = norm(q);
  if (!nQ) return [];
  return hits
    .map((h) => {
      const label = norm(h.label);
      const kws = h.keywords.map(norm);
      let score = 0;

      if (label === nQ) score += 6;
      else if (label.startsWith(nQ)) score += 4;
      else if (label.includes(nQ)) score += 2;

      if (kws.some((k) => k === nQ)) score += 3;
      if (kws.some((k) => k.startsWith(nQ))) score += 2;
      if (kws.some((k) => k.includes(nQ))) score += 1;

      return { ...h, score };
    })
    .filter((r) => r.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, 7);
}
