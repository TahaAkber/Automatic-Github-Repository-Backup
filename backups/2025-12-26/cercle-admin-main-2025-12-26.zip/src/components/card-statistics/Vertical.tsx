// MUI Imports
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import Typography from "@mui/material/Typography";

// Types Imports

// Components Imports
import CustomAvatar from "../../@core/components/mui/Avatar";
import OptionMenu from "../../@core/components/option-menu";

const CardStatVertical = (props: any) => {
  // Props
  const {
    title,
    stats,
    avatarIcon,
    avatarColor,
    trendNumber,
    trend,
    subtitle,
    avatarSkin,
    avatarSize,
    moreOptions,
  } = props;

  return (
    <Card className="bs-full">
      <CardContent>
        <div className="flex justify-between items-center is-full mbe-5">
          <CustomAvatar
            color={avatarColor}
            skin={avatarSkin}
            size={avatarSize}
            className="shadow-xs"
          >
            <i className={avatarIcon} />
          </CustomAvatar>
          <OptionMenu
            {...(moreOptions
              ? moreOptions
              : {
                  options: ["Refresh", "Share", "Update"],
                  iconButtonProps: { className: "text-textPrimary" },
                })}
          />
        </div>
        <div className="flex flex-col gap-3">
          <Typography
            color="text.primary"
            className="font-medium"
            style={{ fontFamily: '"Nunito Sans", sans-serif' }}
          >
            {title}
          </Typography>
          <div className="flex gap-x-2 gap-y-1.5 items-center flex-wrap">
            <Typography
              variant="h4"
              style={{ fontFamily: '"Nunito Sans", sans-serif' }}
            >
              {stats}
            </Typography>
            <Typography
              color={trend === "negative" ? "error.main" : "success.main"}
              style={{ fontFamily: '"Nunito Sans", sans-serif' }}
            >
              {`${trend === "negative" ? "-" : "+"}${trendNumber}`}
            </Typography>
          </div>
          <Typography
            variant="body2"
            style={{ fontFamily: '"Nunito Sans", sans-serif' }}
          >
            {subtitle}
          </Typography>
        </div>
      </CardContent>
    </Card>
  );
};

export default CardStatVertical;
