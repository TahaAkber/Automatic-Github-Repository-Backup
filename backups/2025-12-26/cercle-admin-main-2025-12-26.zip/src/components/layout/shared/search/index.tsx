import { useEffect, useRef, useState } from "react";
import IconButton from "@mui/material/IconButton";
import TextField from "@mui/material/TextField";
import InputAdornment from "@mui/material/InputAdornment";
import SearchIcon from "@mui/icons-material/Search";
import {
  Box,
  CircularProgress,
  Divider,
  List,
  ListItemButton,
  ListItemText,
  ListItemAvatar,
  Avatar,
  Popper,
  Paper,
  Typography,
  Button,
} from "@mui/material";

// Hook Imports
import useVerticalNav from "../../../../@menu/hooks/useVerticalNav";
import useGlobalSearch from "../../../globalSearch/useGlobalSearch";
import { useSelector } from "react-redux";
import ClickAwayListener from "@mui/material/ClickAwayListener";
const NavSearch = () => {
  const { isBreakpointReached } = useVerticalNav(); // true => mobile (icon only)
  const [searchText, setSearchText] = useState("");
  const anchorRef = useRef<HTMLInputElement | null>(null);

  // Read roles from your Redux auth slice (adjust to your store shape)
  const userRoles: string[] = useSelector(
    (s: any) => s.auth?.user?.roles ?? []
  );

  const { setQuery, results, showMore } = useGlobalSearch(userRoles);

  // Keep the hook's query in sync with the field
  const handleChange = (v: string) => {
    setSearchText(v);
    setQuery(v);
  };

  const open = !!searchText.trim();

  // ===== Responsive sizes (recompute on resize / open) =====
  const [sizes, setSizes] = useState({ width: 560, maxHeight: 480 });

  useEffect(() => {
    const compute = () => {
      const vw = window.innerWidth;
      const vh = window.innerHeight;

      // Width: use input width if good, otherwise responsive vw
      const inputW = anchorRef.current?.offsetWidth ?? 0;
      const baseWidth = inputW && vw >= 900 ? inputW : Math.min(vw * 0.92, 560); // up to 560px, or ~92vw on small screens

      // Height: cap to ~70vh
      const maxHeight = Math.max(320, Math.floor(vh * 0.7)); // never too short
      setSizes({ width: Math.floor(baseWidth), maxHeight });
    };

    compute();
    if (open) {
      window.addEventListener("resize", compute);
    }
    return () => window.removeEventListener("resize", compute);
  }, [open]);

  const hasRemoteLoading = results.products.loading || results.shops.loading;

  if (isBreakpointReached) {
    return (
      <IconButton
        className="color"
        onClick={() => {
          const ev = new CustomEvent("open-global-search");
          window.dispatchEvent(ev);
        }}
      >
        <i className="ri-search-line" />
      </IconButton>
    );
  }

  return (
    <Box position="relative">
      <TextField
        inputRef={anchorRef}
        value={searchText}
        onChange={(e) => handleChange(e.target.value)}
        placeholder="Search products, shops…"
        size="small"
        variant="outlined"
        autoComplete="off"
        type="search"
        fullWidth
        InputProps={{
          startAdornment: (
            <InputAdornment position="start">
              <SearchIcon fontSize="small" />
            </InputAdornment>
          ),
          sx: {
            borderColor: "1px solid #E5E5E5",
            borderRadius: "8px",
          },
        }}
        onKeyDown={(e) => {
          if (e.key === "Escape") {
            setSearchText("");
            setQuery("");
          }
        }}
      />

      <Popper
        open={open}
        anchorEl={anchorRef.current}
        placement="bottom-start"
        sx={{ zIndex: 1300 }}
        modifiers={[
          { name: "flip", enabled: true },
          {
            name: "preventOverflow",
            enabled: true,
            options: { padding: 8, altBoundary: true },
          },
          { name: "offset", options: { offset: [0, 8] } },
        ]}
      >
        <ClickAwayListener
          onClickAway={() => {
            setSearchText("");
            setQuery("");
          }}
        >
          <Paper
            elevation={8}
            sx={{
              mt: 0.5,
              borderRadius: 2,
              width: `${sizes.width}px`,
              maxWidth: "92vw",
              maxHeight: `${sizes.maxHeight}px`,
              display: "flex",
              flexDirection: "column",
              overflow: "hidden",
            }}
          >
            {/* 👇 Scrollable wrapper (Navigation + Results together) */}
            <Box
              sx={{
                flex: 1,
                overflowY: "auto",
                scrollbarWidth: "thin", // Firefox
                scrollbarColor: "#B0B0B0 transparent",
                "&::-webkit-scrollbar": { width: 8 },
                "&::-webkit-scrollbar-thumb": {
                  backgroundColor: "#B0B0B0",
                  borderRadius: 8,
                },
                "&::-webkit-scrollbar-track": {
                  backgroundColor: "transparent",
                },
              }}
            >
              {/* Navigation */}
              <Box
                sx={{
                  bgcolor: "background.paper",
                }}
              >
                <Typography
                  variant="overline"
                  sx={{ px: 2, pt: 1.5, display: "block" }}
                >
                  Navigation
                </Typography>
                <List dense disablePadding>
                  {results.nav.map((r) => (
                    <ListItemButton
                      key={r.path}
                      onMouseDown={(e) => e.preventDefault()}
                      onClick={() => {
                        window.location.href = r.path;
                      }}
                    >
                      <ListItemText
                        primary={r.label}
                        secondary={r.path}
                        primaryTypographyProps={{ noWrap: true }}
                        secondaryTypographyProps={{ noWrap: true }}
                      />
                    </ListItemButton>
                  ))}
                </List>
                <Divider />
              </Box>

              {/* Results */}
              <Box
                sx={{
                  px: 2,
                  py: 1,
                  position: "sticky",
                  top: !!results.nav.length ? 40 : 0, // shift down if nav exists
                  bgcolor: "background.paper",
                  zIndex: 2,
                }}
              >
                <Typography variant="overline">Results</Typography>
              </Box>

              {(["shops", "products", "users"] as const).map((sectionKey) => {
                const sec = (results as any)[sectionKey];
                if (!sec?.items?.length && !sec?.loading) return null;

                const titleMap: Record<typeof sectionKey, string> = {
                  shops: "Shops",
                  products: "Products",
                  users: "Admin Users",
                };

                return (
                  <Box key={sectionKey}>
                    <Typography
                      variant="subtitle2"
                      sx={{ px: 2, pb: 0.5, color: "text.secondary" }}
                    >
                      {titleMap[sectionKey]}
                    </Typography>

                    <List dense disablePadding>
                      {sec.items.slice(0, 5).map((it: any) => (
                        <ListItemButton
                          key={`${sectionKey}-${it.id}`}
                          onMouseDown={(e) => e.preventDefault()}
                          onClick={() => {
                            if (sectionKey !== "products" && it.url) {
                              window.location.href = it.url;
                            }
                          }}
                        >
                          {it.thumbnail && (
                            <ListItemAvatar>
                              <Avatar
                                src={it.thumbnail}
                                alt={it.title}
                                variant="rounded"
                              />
                            </ListItemAvatar>
                          )}
                          <ListItemText
                            primary={it.title}
                            secondary={it.subtitle}
                            primaryTypographyProps={{ noWrap: true }}
                            secondaryTypographyProps={{ noWrap: true }}
                          />
                        </ListItemButton>
                      ))}
                    </List>

                    <Box
                      sx={{
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                        px: 2,
                        pb: 1,
                      }}
                    >
                      {sec.loading ? (
                        <Box
                          sx={{ display: "flex", alignItems: "center", gap: 1 }}
                        >
                          <CircularProgress size={14} />
                          <Typography variant="caption" color="text.secondary">
                            Loading…
                          </Typography>
                        </Box>
                      ) : (
                        sec.hasMore && (
                          <Button
                            size="small"
                            onMouseDown={(e) => e.preventDefault()}
                            onClick={() => showMore(sectionKey as any)}
                          >
                            Show more
                          </Button>
                        )
                      )}
                    </Box>
                    <Divider />
                  </Box>
                );
              })}

              {/* Empty state */}
              {!results.nav.length &&
                !results.products.items.length &&
                !results.shops.items.length &&
                !hasRemoteLoading && (
                  <Box sx={{ px: 2, py: 2 }}>
                    <Typography variant="body2" color="text.secondary">
                      No results. Try <b>type:product</b>, <b>order:#1234</b>,
                      or <b>shop:acrylicbazaar</b>.
                    </Typography>
                  </Box>
                )}
            </Box>
          </Paper>
        </ClickAwayListener>
      </Popper>
    </Box>
  );
};
export default NavSearch;
