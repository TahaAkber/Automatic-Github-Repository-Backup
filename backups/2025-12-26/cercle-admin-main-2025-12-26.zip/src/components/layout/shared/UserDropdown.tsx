"use client";

import { useRef, useState } from "react";
import type { MouseEvent } from "react";

import { useNavigate } from "react-router-dom";

import { styled } from "@mui/material/styles";
import Badge from "@mui/material/Badge";
import Avatar from "@mui/material/Avatar";
import Popper from "@mui/material/Popper";
import Fade from "@mui/material/Fade";
import Paper from "@mui/material/Paper";
import ClickAwayListener from "@mui/material/ClickAwayListener";
import MenuList from "@mui/material/MenuList";
import Typography from "@mui/material/Typography";
import Divider from "@mui/material/Divider";
import Button from "@mui/material/Button";

import { logout } from "../../../redux/slices/authSlice";
import { useDispatch, useSelector } from "react-redux";
import { persistor, RootState } from "../../../redux/store/store";

import LogoutIcon from "@mui/icons-material/Logout";

// Styled badge indicator
const BadgeContentSpan = styled("span")({
  width: 8,
  height: 8,
  borderRadius: "50%",
  cursor: "pointer",
  backgroundColor: "var(--mui-palette-success-main)",
  boxShadow: "0 0 0 2px var(--mui-palette-background-paper)",
});

const UserDropdown = ({ isMobile }: any) => {
  const user = useSelector((state: RootState) => state.auth.user);
  const dispatch = useDispatch();
  const [open, setOpen] = useState(false);
  const anchorRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();

  const handleDropdownOpen = () => {
    setOpen((prev) => !prev);
  };

  const handleDropdownClose = async (
    event?: MouseEvent<HTMLLIElement> | (MouseEvent | TouchEvent),
    url?: string
  ) => {
    if (
      anchorRef.current &&
      anchorRef.current.contains(event?.target as HTMLElement)
    ) {
      return;
    }

    if (url) {
      dispatch(logout());
      await persistor.purge();
      navigate(url);
    }
    setOpen(false);
  };

  return (
    <>
      <Badge
        ref={anchorRef}
        overlap="circular"
        badgeContent={<BadgeContentSpan onClick={handleDropdownOpen} />}
        anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
        className={!isMobile ? "ml-2" : "ml-2 mt-2"}
      >
        <Avatar
          alt={user?.username || "User"}
          src={"/default-avatar.png"}
          onClick={handleDropdownOpen}
          className="cursor-pointer w-10 h-10"
        />
      </Badge>
      <div className="flex items-center py-2 px-1">
        <div className={isMobile ? "flex flex-col mt-1" : "flex flex-col"}>
          <Typography
            className="font-medium "
            color="text.primary"
            style={{ fontFamily: '"Nunito Sans", sans-serif' }}
          >
            {!isMobile && user?.username}
          </Typography>
          <Typography
            fontSize={12}
            color="#999999"
            style={{ fontFamily: '"Nunito Sans", sans-serif' }}
          >
            Admin
          </Typography>
        </div>
      </div>
      <Popper
        open={open}
        transition
        disablePortal
        placement="bottom-end"
        anchorEl={anchorRef.current}
        className="min-w-[240px] mb-4 z-[1]"
      >
        {({ TransitionProps, placement }) => (
          <Fade
            {...TransitionProps}
            style={{
              transformOrigin:
                placement === "bottom-end" ? "right top" : "left top",
            }}
          >
            <Paper className="shadow-lg">
              <ClickAwayListener
                onClickAway={(e) =>
                  handleDropdownClose(e as MouseEvent | TouchEvent)
                }
              >
                <MenuList>
                  <div
                    className="flex items-center py-2 px-4 gap-2"
                    tabIndex={-1}
                  >
                    <Avatar
                      alt={user?.username || "User"}
                      src={"/default-avatar.png"}
                      className="w-10 h-10"
                    />
                    <div className="flex flex-col">
                      <Typography
                        className="font-medium"
                        color="text.primary"
                        style={{ fontFamily: '"Nunito Sans", sans-serif' }}
                      >
                        {user?.username}
                      </Typography>
                      <Typography
                        fontSize={12}
                        style={{ fontFamily: '"Nunito Sans", sans-serif' }}
                      >
                        Admin
                      </Typography>
                    </div>
                  </div>

                  <Divider className="my-1" />

                  {/* profile, settings and FAQ route and pages */}
                  {/* <div>
                    <MenuItem
                      className="gap-3"
                      onClick={(e) => handleDropdownClose(e)}
                    >
                      <AccountCircleIcon fontSize="small" />
                      <Typography
                        color="text.primary"
                        style={{ fontFamily: '"Nunito Sans", sans-serif' }}
                      >
                        My Profile
                      </Typography>
                    </MenuItem>

                    <MenuItem
                      className="gap-3"
                      onClick={(e) => handleDropdownClose(e)}
                    >
                      <SettingsIcon fontSize="small" />
                      <Typography
                        color="text.primary"
                        style={{ fontFamily: '"Nunito Sans", sans-serif' }}
                      >
                        Settings
                      </Typography>
                    </MenuItem>

                    <MenuItem
                      className="gap-3"
                      onClick={(e) => handleDropdownClose(e)}
                    >
                      <MonetizationOnIcon fontSize="small" />
                      <Typography
                        color="text.primary"
                        style={{ fontFamily: '"Nunito Sans", sans-serif' }}
                      >
                        Pricing
                      </Typography>
                    </MenuItem>

                    <MenuItem
                      className="gap-3"
                      onClick={(e) => handleDropdownClose(e)}
                    >
                      <HelpOutlineIcon fontSize="small" />
                      <Typography
                        color="text.primary"
                        style={{ fontFamily: '"Nunito Sans", sans-serif' }}
                      >
                        FAQ
                      </Typography>
                    </MenuItem>
                  </div> */}

                  <div className="flex items-center py-2 px-4">
                    <Button
                      fullWidth
                      variant="contained"
                      color="error"
                      size="small"
                      endIcon={<LogoutIcon />}
                      onClick={(e) => handleDropdownClose(e, "/auth/login")}
                      sx={{
                        "& .MuiButton-endIcon": { marginLeft: 1.5 },
                      }}
                      style={{ fontFamily: '"Nunito Sans", sans-serif' }}
                    >
                      Logout
                    </Button>
                  </div>
                </MenuList>
              </ClickAwayListener>
            </Paper>
          </Fade>
        )}
      </Popper>
    </>
  );
};

export default UserDropdown;
