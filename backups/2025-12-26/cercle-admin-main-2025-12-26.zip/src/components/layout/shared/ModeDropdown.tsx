import { useRef } from "react";

// MUI Imports
import Tooltip from "@mui/material/Tooltip";
import IconButton from "@mui/material/IconButton";
import LightModeIcon from "@mui/icons-material/LightMode";
const ModeDropdown = () => {
  // Refs
  const anchorRef = useRef<HTMLButtonElement>(null);

  return (
    <Tooltip title="Mode" PopperProps={{ className: "capitalize" }}>
      <IconButton ref={anchorRef} className="text-textPrimary">
        <LightModeIcon />
      </IconButton>
    </Tooltip>
  );
};

export default ModeDropdown;
