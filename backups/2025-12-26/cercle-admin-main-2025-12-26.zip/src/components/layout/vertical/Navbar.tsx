// Component Imports
import NavbarContent from "./NavbarContent";

const Navbar = () => {
  return <NavbarContent />;
};

export default Navbar;
