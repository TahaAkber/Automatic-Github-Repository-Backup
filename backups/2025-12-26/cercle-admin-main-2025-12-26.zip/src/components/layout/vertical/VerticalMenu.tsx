// src/layouts/components/vertical-nav/VerticalMenu.tsx
import { useTheme } from "@mui/material/styles";
import { Menu, SubMenu, MenuSection } from "../../../@menu/vertical-menu";
import useVerticalNav from "../../../@menu/hooks/useVerticalNav";
import HomeOutlinedIcon from "@mui/icons-material/HomeOutlined";
import NotificationsNoneIcon from "@mui/icons-material/NotificationsNone";
import StorefrontIcon from "@mui/icons-material/Storefront";
import menuItemStyles from "../../../@core/styles/vertical/menuItemStyles";
import menuSectionStyles from "../../../@core/styles/vertical/menuSectionStyles";
import PeopleOutlineOutlinedIcon from "@mui/icons-material/PeopleOutlineOutlined";
import StarsOutlinedIcon from "@mui/icons-material/StarsOutlined";
import PlansMaster from "../../CustomIcons/PlansMaster";
import OrdersIcon from "../../CustomIcons/Orders";
import ProductsIcon from "../../CustomIcons/ProductsIcon";
import ReviewsOutlinedIcon from "@mui/icons-material/ReviewsOutlined";
import NestedOptions from "../../CustomIcons/NestedOptions";
import { useSelector } from "react-redux";
import { RootState } from "../../../redux/store/store";
import { NavMenuItem } from "./NavMenuItem";
import { useLocation } from "react-router";
import ReportProblemOutlinedIcon from "@mui/icons-material/ReportProblemOutlined";

const VerticalMenu = ({
  scrollMenu,
  setsidebarOpen,
  isMobile,
}: {
  scrollMenu: (container: any) => void;
  setsidebarOpen: any;
  isMobile: boolean;
}) => {
  const { pathname } = useLocation();
  const userRoles = useSelector((state: RootState) =>
    state.auth.user?.roles.map((role) => role.admin_role_name)
  );
  const isReadUserRoleDisabled = !userRoles?.includes("users");
  const isMerchantRoleDisabled = !userRoles?.includes("merchants");
  const isCollectedRoleDisabled = !userRoles?.includes("collections");
  const istransactionRoleDisabled = !userRoles?.includes("transactions");
  const isorders = !userRoles?.includes("orders");
  const isglobal = !userRoles?.includes("global");
  const isplans = !userRoles?.includes("plans");
  const isNotificationRoleDisabled = !userRoles?.includes("notification");

  const theme = useTheme();
  const { isBreakpointReached } = useVerticalNav();

  const adjustedMenuItemStyles = {
    ...menuItemStyles(theme),
    root: {
      ...(menuItemStyles(theme)?.root || {}),
      fontSize: "0.85rem",
      "&.c-active": {
        color: theme.palette.primary.main,
        backgroundColor: theme.palette.action.selected,
        fontWeight: 600,
        borderRadius: 100,
        "& svg": { color: theme.palette.primary.main },
      },
    },
  };

  const ordersOpen =
    pathname.startsWith("/orders") || pathname.startsWith("/transactions");
  const notificationsOpen = pathname.startsWith("/notifications");
  const productsOpen =
    pathname.startsWith("/products") || pathname.startsWith("/collections");
  const usersOpen = pathname.startsWith("/users");
  const plansOpen = pathname.startsWith("/plans");

  return (
    <div
      {...(isBreakpointReached
        ? {
            className: "bs-full overflow-y-auto overflow-x-hidden",
            onScroll: (container) => scrollMenu(container),
          }
        : {
            options: { wheelPropagation: false, suppressScrollX: true },
            onScrollY: (container: any) => scrollMenu(container),
          })}
    >
      <Menu
        menuItemStyles={adjustedMenuItemStyles}
        menuSectionStyles={menuSectionStyles(theme)}
      >
        <NavMenuItem
          icon={<HomeOutlinedIcon />}
          setsidebarOpen={setsidebarOpen}
          isMobile={isMobile}
          to="/"
        >
          DASHBOARD
        </NavMenuItem>

        <MenuSection label="All Pages">
          {!(isglobal && isMerchantRoleDisabled) && (
            <NavMenuItem
              className="text-md"
              icon={<StorefrontIcon />}
              to="/merchants"
              setsidebarOpen={setsidebarOpen}
              isMobile={isMobile}
            >
              Merchant
            </NavMenuItem>
          )}

          {!(isglobal && isNotificationRoleDisabled) && (
            <SubMenu
              label="
              Notifications"
              className="text-md"
              icon={<NotificationsNoneIcon />}
              key={`Notifications-${notificationsOpen}`}
            >
              <NavMenuItem
                icon={<NestedOptions />}
                to="/notifications/app"
                href="/notifications/app"
                setsidebarOpen={setsidebarOpen}
                isMobile={isMobile}
              >
                In App
              </NavMenuItem>
              <NavMenuItem
                icon={<NestedOptions />}
                to="/notifications/scheduled"
                href="/notifications/scheduled"
                setsidebarOpen={setsidebarOpen}
                isMobile={isMobile}
              >
                Campaign
              </NavMenuItem>
            </SubMenu>
          )}

          {!(isglobal && istransactionRoleDisabled && isorders) && (
            <SubMenu
              label="Orders"
              className="text-md"
              icon={<OrdersIcon />}
              key={`orders-${ordersOpen}`}
            >
              {!(isglobal && isorders) && (
                <NavMenuItem
                  icon={<NestedOptions />}
                  href="/orders/orderlisting"
                  to="/orders/orderlisting"
                  setsidebarOpen={setsidebarOpen}
                  isMobile={isMobile}
                >
                  Order listing
                </NavMenuItem>
              )}

              {!(isglobal && isorders) && (
                <NavMenuItem
                  icon={<NestedOptions />}
                  href="/orders/cancelled-orders"
                  to="/orders/cancelled-orders"
                  setsidebarOpen={setsidebarOpen}
                  isMobile={isMobile}
                >
                  Cancelled Orders
                </NavMenuItem>
              )}
              {!(
                istransactionRoleDisabled &&
                isglobal &&
                istransactionRoleDisabled
              ) && (
                <NavMenuItem
                  icon={<NestedOptions />}
                  href="/transactions"
                  to="/transactions"
                  setsidebarOpen={setsidebarOpen}
                  isMobile={isMobile}
                >
                  Transactions
                </NavMenuItem>
              )}
            </SubMenu>
          )}

          {!(isCollectedRoleDisabled && isglobal) && (
            <SubMenu
              label="Collections"
              icon={<ProductsIcon />}
              className="text-md"
              key={`products-${productsOpen}`}
            >
              {/* <NavMenuItem
              icon={<NestedOptions />}
              to="/products"
              href="/products"
            >
              Product Listing
            </NavMenuItem> */}
              <NavMenuItem
                icon={<NestedOptions />}
                to="/collections"
                href="/collections"
                setsidebarOpen={setsidebarOpen}
                isMobile={isMobile}
              >
                Trending Collection
              </NavMenuItem>
            </SubMenu>
          )}
          {!(
            isglobal &&
            isReadUserRoleDisabled &&
            isCollectedRoleDisabled &&
            isorders &&
            isNotificationRoleDisabled &&
            isMerchantRoleDisabled &&
            istransactionRoleDisabled &&
            isplans
          ) && (
            <NavMenuItem
              icon={<ReviewsOutlinedIcon />}
              to="/reviews"
              className="text-md"
              setsidebarOpen={setsidebarOpen}
              isMobile={isMobile}
            >
              Reviews
            </NavMenuItem>
          )}

          {!isglobal && (
            <NavMenuItem
              icon={<StarsOutlinedIcon />}
              to="/brands"
              className="text-md"
              setsidebarOpen={setsidebarOpen}
              isMobile={isMobile}
            >
              Brands
            </NavMenuItem>
          )}

          {!(isReadUserRoleDisabled && isglobal) && (
            <SubMenu
              label="User Roles"
              icon={<PeopleOutlineOutlinedIcon />}
              className="text-md"
              key={`users-${usersOpen}`}
            >
              <NavMenuItem
                icon={<NestedOptions />}
                to="/users"
                href="/users"
                setsidebarOpen={setsidebarOpen}
                isMobile={isMobile}
              >
                {" "}
                Users
              </NavMenuItem>
            </SubMenu>
          )}

          {!(isplans && isglobal) && (
            <SubMenu
              label="Pricing"
              icon={<PlansMaster />}
              className="text-md"
              key={`plans-${plansOpen}`}
            >
              <NavMenuItem
                icon={<NestedOptions />}
                to="/pricing/plans"
                href="/pricing/plans"
                setsidebarOpen={setsidebarOpen}
                isMobile={isMobile}
              >
                Plans
              </NavMenuItem>
              <NavMenuItem
                icon={<NestedOptions />}
                to="/pricing/tile-charges"
                href="/pricing/tile-charges"
                setsidebarOpen={setsidebarOpen}
                isMobile={isMobile}
              >
                Tiles Charges
              </NavMenuItem>
              <NavMenuItem
                icon={<NestedOptions />}
                to="/pricing/tracking-charges"
                href="/pricing/tracking-charges"
                setsidebarOpen={setsidebarOpen}
                isMobile={isMobile}
              >
                Tracking Charges
              </NavMenuItem>
              <NavMenuItem
                icon={<NestedOptions />}
                to="/pricing/reels-bundle"
                href="/pricing/reels-bundle"
                setsidebarOpen={setsidebarOpen}
                isMobile={isMobile}
              >
                Reels Bundle
              </NavMenuItem>
            </SubMenu>
          )}
          {!(
            isglobal &&
            isReadUserRoleDisabled &&
            isCollectedRoleDisabled &&
            isorders &&
            isNotificationRoleDisabled &&
            isMerchantRoleDisabled &&
            istransactionRoleDisabled &&
            isplans
          ) && (
            // <SubMenu
            //   label="Reports"
            //   icon={<NestedOptions />}
            //   className="text-md"
            //   key={`reports-${reportsOpen}`}
            // >
            <NavMenuItem
              icon={<ReportProblemOutlinedIcon />}
              to="/report"
              className="text-md"
              setsidebarOpen={setsidebarOpen}
              isMobile={isMobile}
            >
              Reports
            </NavMenuItem>
            // </SubMenu>
          )}
        </MenuSection>
      </Menu>
    </div>
  );
};

export default VerticalMenu;
