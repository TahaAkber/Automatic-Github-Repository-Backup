// React Imports
import { useRef, useEffect } from "react";

// MUI Imports
import { styled, useTheme } from "@mui/material/styles";
import useMediaQuery from "@mui/material/useMediaQuery";
import CloseIcon from "@mui/icons-material/Close";

// Component Imports
import VerticalNav, { NavHeader } from "../../../@menu/vertical-menu";
import VerticalMenu from "./VerticalMenu";
import Logo from "../../layout/shared/Logo";

// Style Imports
import navigationCustomStyles from "../../../@core/styles/vertical/navigationCustomStyles";

const StyledBoxForShadow = styled("div")(({ theme }) => ({
  top: 60,
  left: -8,
  zIndex: 2,
  opacity: 0,
  position: "absolute",
  pointerEvents: "none",
  width: "calc(100% + 15px)",
  height: theme.mixins.toolbar.minHeight,
  transition: "opacity .15s ease-in-out",
  background: `linear-gradient(var(--mui-palette-background-default) 5%, rgb(var(--mui-palette-background-defaultChannel) / 0.85) 30%, rgb(var(--mui-palette-background-defaultChannel) / 0.5) 65%, rgb(var(--mui-palette-background-defaultChannel) / 0.3) 75%, transparent)`,
  "&.scrolled": {
    opacity: 1,
  },
}));

const Navigation = ({ setsidebarOpen, sidebarOpen }: any) => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("md"));

  const shadowRef = useRef<HTMLDivElement>(null);
  const navRef = useRef<HTMLDivElement>(null);

  // Handle body scroll lock on mobile
  useEffect(() => {
    document.body.style.overflow = sidebarOpen && isMobile ? "hidden" : "";
  }, [sidebarOpen, isMobile]);

  // Click outside to close
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        sidebarOpen &&
        navRef.current &&
        !navRef.current.contains(event.target as Node)
      ) {
        setsidebarOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [sidebarOpen]);

  const scrollMenu = (container: any) => {
    container = isMobile ? container.target : container;

    if (shadowRef && container.scrollTop > 0) {
      shadowRef.current?.classList.add("scrolled");
    } else {
      shadowRef.current?.classList.remove("scrolled");
    }
  };

  return (
    <>
      {/* Backdrop for mobile */}
      {isMobile && sidebarOpen && (
        <div
          onClick={() => setsidebarOpen(false)}
          className="fixed inset-0 bg-black bg-opacity-50 z-30"
        />
      )}

      {/* Sidebar */}
      <div
        ref={navRef}
        className={`h-full w-[250px] bg-white transition-transform duration-300 ease-in-out ${
          isMobile
            ? `${
                sidebarOpen ? "translate-x-0" : "-translate-x-full"
              } fixed top-0 left-0 z-40 shadow-lg`
            : "relative translate-x-0 shadow-none"
        } md:relative md:translate-x-0 md:shadow-none`}
      >
        <VerticalNav customStyles={navigationCustomStyles(theme)}>
          <NavHeader>
            <a href="/" onClick={() => setsidebarOpen(false)}>
              <Logo />
            </a>
            {isMobile && (
              <CloseIcon
                fontSize="medium"
                className="cursor-pointer text-gray-700 ml-8 mb-10"
                onClick={() => setsidebarOpen(false)}
              />
            )}
          </NavHeader>

          <StyledBoxForShadow ref={shadowRef} />
          <VerticalMenu
            scrollMenu={scrollMenu}
            setsidebarOpen={setsidebarOpen}
            isMobile={isMobile}
          />
        </VerticalNav>
      </div>
    </>
  );
};

export default Navigation;
