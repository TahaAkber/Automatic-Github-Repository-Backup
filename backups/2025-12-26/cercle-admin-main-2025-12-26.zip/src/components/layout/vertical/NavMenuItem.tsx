// src/layouts/components/vertical-nav/NavMenuItem.tsx
import React from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { MenuItem as VMenuItem } from "../../../@menu/vertical-menu";

interface NavMenuItemProps {
  to: string;
  icon?: React.ReactNode;
  children: React.ReactNode;
  className?: string;
  [key: string]: any;
}

export const NavMenuItem: React.FC<NavMenuItemProps> = ({
  to,
  icon,
  children,
  className,
  ...rest
}) => {
  const navigate = useNavigate();
  const { pathname } = useLocation();

  // active if exact or nested path
  const isActive = pathname === to || pathname.startsWith(to + "/");

  return (
    <VMenuItem
      {...rest}
      icon={
        React.isValidElement(icon) ? (
          icon
        ) : icon !== undefined && icon !== null ? (
          <span>{icon}</span>
        ) : undefined
      }
      className={`${className || ""} ${isActive ? "c-active" : ""}`}
      onClick={(e: React.MouseEvent) => {
        e.preventDefault();
        navigate(to);
        if (rest.isMobile) rest.setsidebarOpen(false);
      }}
    >
      {children}
    </VMenuItem>
  );
};
