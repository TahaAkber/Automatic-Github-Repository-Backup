// Third-party Imports
import classnames from "classnames";
// Component Imports
import NavToggle from "./NavToggle";
import NavSearch from "../shared/search";
import UserDropdown from "../shared/UserDropdown";
// import ChatIcon from "@mui/icons-material/Chat"; // Util Imports
import { verticalLayoutClasses } from "../../../@layouts/utils/layoutClasses";
import { useLocation } from "react-router";
import useMediaQuery from "@mui/material/useMediaQuery";
import { useTheme } from "@mui/material";

const NavbarContent = () => {
  const location = useLocation();
  console.log("location", location.pathname);

  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("md"));

  return (
    <div
      className={classnames(
        verticalLayoutClasses.navbarContent,
        "flex items-center justify-between gap-4 w-full "
      )}
      style={{ fontFamily: '"Nunito Sans", sans-serif' }}
    >
      <div className="flex items-center gap-2 sm:gap-4 flex-grow">
        <NavToggle />

        {location.pathname === "/" && (
          <div
            className="w-full rounded-full ml-3"
            style={{ fontFamily: '"Nunito Sans", sans-serif' }}
          >
            <NavSearch />
          </div>
        )}
      </div>

      <div className="flex items-center gap-1 text-gray-500">
        {/* <ChatIcon className="cursor-pointer" /> */}
        <UserDropdown isMobile={isMobile} />
      </div>
    </div>
  );
};

export default NavbarContent;
