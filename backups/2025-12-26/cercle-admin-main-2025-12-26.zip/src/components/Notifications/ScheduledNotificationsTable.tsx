import React from "react";
import { Switch, Tooltip } from "@mui/material";
import { appUrl } from "../../redux/thunks/authThunks";
import AccessDenied from "../../components/merchant/Accessdenied";

interface ScheduledNotificationsTableProps {
  data: any;
  loading: boolean;
  onDelete: (id: number) => void;
  onToggle: (id: number, currentActive: boolean) => void;
  canRead: boolean;
  canWrite: boolean;
}

const ScheduledNotificationsTable: React.FC<
  ScheduledNotificationsTableProps
> = ({ data, loading, onToggle, canRead, canWrite }) => {
  console.log(data, "<>data<>");
  // READ gate
  if (!canRead) {
    return (
      <AccessDenied
        subtitle="Your account is missing read permissions for notifications. Contact an admin if you need access."
        secondaryActionText="Contact admin"
        onSecondaryAction={() => {
          window.open("https://cymbiote.com/contact-us/", "_blank");
        }}
      />
    );
  }
  if (loading) return <div>Loading...</div>;
  return (
    <div className="overflow-x-auto rounded-lg border-gray-200 shadow-sm py-5">
      <table className="min-w-full text-sm text-left">
        <thead className=" border-b text-gray-500 font-semibold ">
          <tr>
            <th className="px-6 py-3">Notification Title</th>
            <th className="px-6 py-3">Notification Description</th>
            <th className="px-6 py-3">Start Date</th>
            <th className="px-6 py-3">End Date</th>
            <th className="px-6 py-3">Schedule</th>
            <th className="px-6 py-3">Status</th>
            {/* <th className="px-6 py-3">Created By</th> */}
            {/* <th className="px-6 py-3">Time</th> */}
            <th className="px-6 py-3">Action</th>
          </tr>
        </thead>
        <tbody className="">
          {data?.map((row: any, index: number) => (
            <tr key={index} className="border-b last:border-none">
              <td className="px-6 py-4">
                <div className="flex items-center gap-3">
                  <img
                    src={
                      row?.app_notification_image_url?.startsWith("/")
                        ? appUrl + row?.app_notification_image_url
                        : row?.app_notification_image_url ??
                        "https://cdn.shopify.com/s/files/1/0595/2379/2944/files/img_not_found_cercle.jpg?v=1757333158"
                    }
                    alt="avatar"
                    className="w-10 h-10 rounded object-cover"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      target.src = "https://cdn.shopify.com/s/files/1/0595/2379/2944/files/img_not_found_cercle.jpg?v=1757333158";
                    }}
                  />
                  <Tooltip title={row?.app_notification_title || ""} arrow>
                    <span style={{ cursor: "pointer", whiteSpace: "nowrap" }}>
                      {row?.app_notification_title
                        ?.split(" ")
                        .slice(0, 2)
                        .join(" ")}
                      {row?.app_notification_title?.split(" ").length > 2 &&
                        "..."}
                    </span>
                  </Tooltip>
                </div>
              </td>
              <td className="px-6 py-4">
                <Tooltip title={row?.app_notification_body || ""} arrow>
                  <span style={{ cursor: "pointer", whiteSpace: "nowrap" }}>
                    {row?.app_notification_body
                      ?.split(" ")
                      .slice(0, 5)
                      .join(" ")}
                    {row?.app_notification_body?.split(" ").length > 5 && "..."}
                  </span>
                </Tooltip>
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                {row?.app_notification_starts_at
                  ? new Date(row.app_notification_starts_at).toLocaleString(
                    "en-US",
                    {
                      year: "numeric",
                      month: "short", // e.g. Sep
                      day: "2-digit",
                      hour: "2-digit",
                      minute: "2-digit",
                      hour12: true, // 12-hour format with AM/PM
                    }
                  )
                  : ""}
              </td>
              <td className="px-6 py-4 whitespace-nowrap">
                {row?.app_notification_ends_at
                  ? new Date(row.app_notification_ends_at).toLocaleString(
                    "en-US",
                    {
                      year: "numeric",
                      month: "short", // e.g. Sep
                      day: "2-digit",
                      hour: "2-digit",
                      minute: "2-digit",
                      hour12: true, // 12-hour format with AM/PM
                    }
                  )
                  : ""}
              </td>
              <td className="px-6 py-4">
                {row?.app_notifcation_schedule_type
                  ? row?.app_notifcation_schedule_type
                  : "-"}
              </td>
              {/* <td className="px-6 py-4">
                {row?.app_notifcation_schedule_type ? "Admin" : "Default"}
              </td> */}
              {/* <td className="px-6 py-4">
                {row?.app_notification_time_slot
                  ? row?.app_notification_time_slot
                  : "-"}
              </td> */}
              <td>
                <span
                  style={{
                    backgroundColor:
                      row?.status === "pending"
                        ? "orange"
                        : row?.status === "ongoing"
                          ? "green"
                          : row?.status === "ended"
                            ? "red"
                            : "transparent",
                    color: "white",
                    textAlign: "center",
                    padding: "4px 8px",
                    borderRadius: "20px",
                  }}
                >
                  {row?.status ? row?.status : "-"}
                </span>
              </td>{" "}
              {/* <td>
                <Tooltip title="Delete">
                  <IconButton
                    size="small"
                    onClick={() => onDelete(row.app_notification_id)}
                  >
                    <DeleteOutlineIcon
                      fontSize="medium"
                      color="error"
                      // onClick={() => {
                      //   handledeleteuser(row.admin_user_id);
                      // }}
                    />
                  </IconButton>
                </Tooltip>
              </td> */}
              <td>
                <Tooltip
                  title={
                    row.app_notification_active ? "Deactivate" : "Activate"
                  }
                >
                  <Switch
                    disabled={!canWrite}
                    checked={!!row.app_notification_active}
                    onChange={() =>
                      onToggle(
                        row.app_notification_id,
                        row.app_notification_active
                      )
                    }
                    color="primary"
                  />
                </Tooltip>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default ScheduledNotificationsTable;
