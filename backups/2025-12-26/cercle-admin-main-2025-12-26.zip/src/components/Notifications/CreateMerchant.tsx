import {
  Button,
  Card,
  Grid,
  MenuItem,
  TextField,
  Typography,
} from "@mui/material";
import React, { useState } from "react";
import InputFileUpload from "./ImageUpload";
import Parentstyle from "../Style/Parentstyle";
import Childstyle from "../Style/childstyle";

const CreateMerchant: React.FC = () => {
  const [notificationTitle, setNotificationTitle] = useState("");
  const [notificationDescription, setNotificationDescription] = useState("");
  const [notificationType, setNotificationType] = useState("");
  const [schedule, setSchedule] = useState("");
  const [timeSlot, setTimeSlot] = useState("");
  const [uploadedImages, setUploadedImages] = useState<File[]>([]);
  const [previewImages, setPreviewImages] = useState<string[]>([]);

  const handleFileSelect = (files: File[]) => {
    if (files.length > 0) {
      const singleFile = files[0];
      setUploadedImages([singleFile]);
      setPreviewImages([URL.createObjectURL(singleFile)]);
    }
  };
  const handleCreateMerchant = () => {
    const formData = {
      notificationTitle,
      notificationDescription,
      notificationType,
      schedule,
      timeSlot,
      uploadedImages,
    };
    console.log("Merchant Form Submitted:", formData);
  };

  return (
    <Parentstyle>
      <Childstyle>
        <Typography variant="h5" fontWeight="medium" className="pb-5">
          Create Merchant Notification
        </Typography>
        <Card
          sx={{
            borderRadius: "12px",
            border: "1px solid #e0e0e0",
            boxShadow: 1,
          }}
        >
          <Grid container direction="column" spacing={2}>
            <Grid
              container
              spacing={0}
              alignItems="center"
              justifyContent="space-between"
              flexWrap="wrap"
              className="max-w-full"
            >
              <Grid size={{ xs: 12, md: 8, lg: 12 }} className="p-5">
                <div className="flex flex-col gap-5">
                  <TextField
                    id="Notification Title"
                    label="Notification Title..."
                    variant="outlined"
                    fullWidth
                    size="small"
                    onChange={(e) => setNotificationTitle(e.target.value)}
                  />
                  <TextField
                    id="Notification Description"
                    label="Notification Description..."
                    variant="outlined"
                    fullWidth
                    size="small"
                    multiline
                    onChange={(e) => setNotificationDescription(e.target.value)}
                    minRows={5}
                  />
                  <TextField
                    id="Notification Type"
                    label="Notification Type"
                    variant="outlined"
                    fullWidth
                    size="small"
                    select
                    onChange={(e) => setNotificationType(e.target.value)}
                    SelectProps={{
                      MenuProps: {
                        PaperProps: {
                          style: {
                            padding: "8px",
                          },
                        },
                      },
                    }}
                  >
                    <MenuItem value="All" className="py-2">
                      All
                    </MenuItem>
                    <MenuItem value="None" className="py-2">
                      None
                    </MenuItem>
                  </TextField>
                </div>
              </Grid>
              <Grid size={{ xs: 12, md: 6 }} className="px-5">
                <TextField
                  id="schedule"
                  label="Schedule"
                  variant="outlined"
                  fullWidth
                  size="small"
                  select
                  onChange={(e) => setSchedule(e.target.value)}
                  SelectProps={{
                    MenuProps: {
                      PaperProps: {
                        style: {
                          padding: "8px",
                        },
                      },
                    },
                  }}
                >
                  <MenuItem value="daily" className="py-2">
                    Daily
                  </MenuItem>
                  <MenuItem value="weekly" className="py-2">
                    Weekly
                  </MenuItem>
                  <MenuItem value="monthly" className="py-2">
                    Monthly
                  </MenuItem>
                </TextField>
              </Grid>

              <Grid size={{ xs: 12, md: 6 }} className="px-5">
                <TextField
                  id="time-slot"
                  label="Time Slot"
                  variant="outlined"
                  fullWidth
                  size="small"
                  select
                  onChange={(e) => setTimeSlot(e.target.value)}
                  SelectProps={{
                    MenuProps: {
                      PaperProps: {
                        style: {
                          padding: "8px",
                        },
                      },
                    },
                  }}
                >
                  <MenuItem value="morning" className="py-2">
                    Morning (8 AM - 12 PM)
                  </MenuItem>
                  <MenuItem value="afternoon" className="py-2">
                    Afternoon (12 PM - 4 PM)
                  </MenuItem>
                  <MenuItem value="evening" className="py-2">
                    Evening (4 PM - 8 PM)
                  </MenuItem>
                </TextField>
              </Grid>
            </Grid>
          </Grid>
          {previewImages.length > 0 && (
            <div className="flex flex-wrap gap-4 p-5">
              {previewImages.map((src, index) => (
                <img
                  key={index}
                  src={src}
                  alt={`preview-${index}`}
                  style={{
                    width: "100px",
                    height: "100px",
                    objectFit: "cover",
                    borderRadius: "8px",
                    border: "1px solid #ccc",
                  }}
                />
              ))}
            </div>
          )}
          <div className="flex  justify-between p-5">
            <InputFileUpload onFileSelect={handleFileSelect} />
            <Button
              variant="contained"
              className="self-end"
              onClick={handleCreateMerchant}
            >
              Submit
            </Button>
          </div>
        </Card>
      </Childstyle>
    </Parentstyle>
  );
};

export default CreateMerchant;
