import {
  Button,
  Card,
  Pagination,
  Typography,
  Snackbar,
  Alert,
} from "@mui/material";
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router";
import Parentstyle from "../Style/Parentstyle";
import Childstyle from "../Style/childstyle";
import { useAppDispatch, useAppSelector } from "../hooks/hooks";
import {
  deleteNotification,
  fetchScheduledNotifications,
  toggleNotification,
} from "../../redux/thunks/notificationThunks";
import ScheduledNotificationsTable from "./ScheduledNotificationsTable";
import { useSelector } from "react-redux";
import { RoleLike } from "../../components/functions/Roles";
import { useRolePermissions } from "../../components/functions/useRolePermissions";

const ScheduledNotification: React.FC = () => {
  const navigate = useNavigate();
  const dispatch = useAppDispatch();

  const { scheduledNotifications, status, scheduledTotalPages } =
    useAppSelector((state) => state.notification);

  const [page, setPage] = useState(1);
  const [openSnackbar, setOpenSnackbar] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState("");
  const limit = 10;

  useEffect(() => {
    dispatch(fetchScheduledNotifications({ page, limit }));
  }, [page, dispatch]);

  const handlePageChange = (_: React.ChangeEvent<unknown>, value: number) => {
    setPage(value);
  };

  const handleDelete = async (id: number) => {
    const result = await dispatch(deleteNotification(id));

    // Redux delete thunk returns fulfilled with payload
    if (deleteNotification.fulfilled.match(result)) {
      setSnackbarMessage(
        result.payload.message || "Notification deleted successfully"
      );
      setOpenSnackbar(true);
    }
  };

  const handleToggle = async (id: number, currentActive: boolean) => {
    console.log(id, currentActive, "id,currentActive");
    const result = await dispatch(
      toggleNotification({ id, active: !currentActive })
    );

    if (toggleNotification.fulfilled.match(result)) {
      setSnackbarMessage(
        result.payload.message ||
        `Notification ${result.payload.active ? "activated" : "deactivated"
        } successfully`
      );
      setOpenSnackbar(true);
    } else {
      setSnackbarMessage("Failed to toggle notification");
      setOpenSnackbar(true);
    }
  };
  const rawRoles = useSelector((state: any) => state.auth.user?.roles) as
    | RoleLike[]
    | undefined;

  const { can } = useRolePermissions(rawRoles);
  const canRead = can("notification", "read");
  const canWrite = can("notification", "write");

  return (
    <Parentstyle>
      <Childstyle>
        <div className="flex justify-between pb-5">
          <Typography variant="h6" fontWeight="medium">
            App Notification
          </Typography>
          <Button
            onClick={() => navigate("/notifications/app/createappnotification")}
            variant="contained"
            size="small"
            sx={{ fontWeight: 300, textTransform: "none" }}
            disabled={!canWrite}
          >
            Create Notification
          </Button>
        </div>

        <Card>
          <ScheduledNotificationsTable
            data={scheduledNotifications}
            loading={status === null}
            onDelete={handleDelete}
            onToggle={handleToggle}
            canRead={canRead}
            canWrite={canWrite}
          />
          <div className="m-5 py-1">
            {canRead && scheduledTotalPages && scheduledTotalPages > 1 && (
              <Pagination
                count={scheduledTotalPages || 1}
                page={page}
                onChange={handlePageChange}
                variant="outlined"
                shape="rounded"
                color="primary"
              />
            )}
          </div>
        </Card>

        {/* Success Snackbar */}
        <Snackbar
          open={openSnackbar}
          autoHideDuration={2000}
          onClose={() => setOpenSnackbar(false)}
          anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
        >
          <Alert
            onClose={() => setOpenSnackbar(false)}
            severity="success"
            sx={{ width: "100%" }}
          >
            {snackbarMessage}
          </Alert>
        </Snackbar>
      </Childstyle>
    </Parentstyle>
  );
};

export default ScheduledNotification;
