import { Button, Card, Pagination, Typography } from "@mui/material";
import React from "react";
import NotificatiosTable from "./NotificationsTable";
import { useNavigate } from "react-router";
import Parentstyle from "../Style/Parentstyle";
import Childstyle from "../Style/childstyle";

const MerchantNotification: React.FC = () => {
  const navigate = useNavigate();
  return (
    <Parentstyle>
      <Childstyle>
        <div className="flex justify-between pb-5">
          <Typography variant="h6" fontWeight="medium">
            Merchant Notification
          </Typography>

          <Button
            onClick={() => {
              navigate("/notifications/merchant/createmerchantnotification");
            }}
            variant="contained"
            size="small"
            sx={{ fontWeight: 300, textTransform: "none" }}
          >
            Create Notification
          </Button>
        </div>
        <Card>
          <NotificatiosTable
            data={[]}
            loading={false}
            onDelete={() => {}}
            canRead
          />
          <div className="m-5 py-1">
            <Pagination
              count={5}
              variant="outlined"
              shape="rounded"
              color="primary"
            />
          </div>
        </Card>
      </Childstyle>
    </Parentstyle>
  );
};

export default MerchantNotification;
