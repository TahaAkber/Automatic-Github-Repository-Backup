import React, { useEffect, useMemo, useRef, useState } from "react";
import {
  Button,
  Card,
  Grid,
  MenuItem,
  TextField,
  Typography,
  Snackbar,
  Alert,
  Autocomplete,
  CircularProgress,
  Box,
  Avatar,
} from "@mui/material";
import InputFileUpload from "./ImageUpload";
import Parentstyle from "../Style/Parentstyle";
import Childstyle from "../Style/childstyle";
import { useAppDispatch } from "../hooks/hooks";
import { createNotification } from "../../redux/thunks/notificationThunks";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { DateTimePicker } from "@mui/x-date-pickers/DateTimePicker";
import type { Dayjs } from "dayjs";
import dayjs from "dayjs";
import {
  fetchMerchantsDropdown,
  fetchProductsDropdown,
} from "../../redux/thunks/notificationDropdownThunks";
import { RootState } from "src/redux/store/store";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router";
import GoBackButton from "../button/Goback";

/** Debounce hook */
function useDebouncedValue<T>(value: T, delay = 400) {
  const [v, setV] = useState(value);
  useEffect(() => {
    const id = setTimeout(() => setV(value), delay);
    return () => clearTimeout(id);
  }, [value, delay]);
  return v;
}

type ShopLite = {
  shop_id: number;
  shop_name: string;
  shop_logo_url?: string | null;
};
type ProductLite = {
  product_id: number;
  product_name: string;
  product_image_url?: string | null;
};

type FormErrors = {
  title?: string;
  type?: string;
  shop?: string;
  product?: string;
  startsAt?: string;
  endsAt?: string;
};
export const appUrl = import.meta.env.VITE_APP_URL;

const UPLOAD_API = `${appUrl}/api/upload/`;

const CreateApp: React.FC = () => {
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  // Core fields
  const [notificationTitle, setNotificationTitle] = useState("");
  const [notificationDescription, setNotificationDescription] = useState("");
  const [notificationType, setNotificationType] = useState(""); // broadcast | store_following | product_wishlist | send_all
  const [schedule, setSchedule] = useState("once"); // once | daily | weekly | monthly
  const [timeSlot, setTimeSlot] = useState(""); // optional meta (keep if you still use it)
  const [screenName, setScreenName] = useState(""); // deep-link target (optional)

  // Images
  const [_, setUploadedImages] = useState<File[]>([]);
  const [previewImages, setPreviewImages] = useState<string[]>([]);
  const [previewImage, setPreviewImage] = useState<string | null>(null);
  const [uploadedUrl, setUploadedUrl] = useState<string>("");
  const [uploadingImage, setUploadingImage] = useState(false);

  const hiddenFileInputRef = useRef<HTMLInputElement>(null);

  // Date range
  const [startsAt, setStartsAt] = useState<Dayjs | null>(null);
  const [endsAt, setEndsAt] = useState<Dayjs | null>(null);

  // Dropdowns + search
  const [selectedShop, setSelectedShop] = useState<ShopLite | null>(null);
  const [selectedProduct, setSelectedProduct] = useState<ProductLite[] | []>(
    []
  );
  const [shopSearch, setShopSearch] = useState("");
  const [productSearch, setProductSearch] = useState("");
  const debShop = useDebouncedValue(shopSearch, 400);
  const debProduct = useDebouncedValue(productSearch, 400);

  const merchantsDD = useSelector(
    (s: RootState) => s.notificationDropdown.merchants
  );
  const productsDD = useSelector(
    (s: RootState) => s.notificationDropdown.products
  );

  // UI feedback
  const [openSnackbar, setOpenSnackbar] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState("");
  const [snackbarSeverity, setSnackbarSeverity] = useState<"success" | "error">(
    "success"
  );

  // Validation
  const [errors, setErrors] = useState<FormErrors>({});
  console.log(uploadedUrl, "uploadedUrl");
  useEffect(() => {
    if (notificationType === "store_following") {
      dispatch(fetchMerchantsDropdown({ limit: 10, search: debShop }));
    }
  }, [debShop, notificationType, dispatch]);

  useEffect(() => {
    if (notificationType === "product_wishlist") {
      dispatch(fetchProductsDropdown({ limit: 10, search: debProduct }));
    }
  }, [debProduct, notificationType, dispatch]);

  /** Validation */
  const validate = (): FormErrors => {
    const next: FormErrors = {};

    if (!notificationTitle.trim()) next.title = "Title is required.";
    if (!notificationType) next.type = "Notification type is required.";

    if (notificationType === "store_following" && !selectedShop?.shop_id) {
      next.shop = "Please select a store.";
    }
    if (
      notificationType === "product_wishlist" &&
      selectedProduct?.length === 0
    ) {
      next.product = "Please select a product.";
    }

    if (!startsAt) {
      next.startsAt = "Start date & time is required.";
    } else {
      if (dayjs(startsAt).isBefore(dayjs())) {
        next.startsAt = "Start must be in the future.";
      }
      if (endsAt && dayjs(endsAt).isBefore(startsAt)) {
        next.endsAt = "End must be after start.";
      }
    }

    return next;
  };

  const isSubmitDisabled = useMemo(() => {
    if (!notificationTitle.trim()) return true;
    if (!notificationType) return true;
    if (!startsAt) return true;
    if (notificationType === "store_following" && !selectedShop?.shop_id)
      return true;
    if (notificationType === "product_wishlist" && selectedProduct.length === 0)
      return true;
    return false;
  }, [
    notificationTitle,
    notificationType,
    startsAt,
    selectedShop,
    selectedProduct,
  ]);

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const nextErrors = validate();
    setErrors(nextErrors);
    if (Object.keys(nextErrors).length > 0) {
      setSnackbarSeverity("error");
      setSnackbarMessage("Please fix the highlighted fields.");
      setOpenSnackbar(true);
      return;
    }

    const payload = {
      app_notification_title: notificationTitle.trim(),
      app_notification_body: notificationDescription.trim(),
      app_notification_type: notificationType,
      app_notifcation_schedule_type: schedule,
      app_notification_time_slot: timeSlot,
      app_notification_read: false,
      app_notification_starts_at: startsAt
        ? dayjs(startsAt).toISOString()
        : null,
      app_notification_ends_at: endsAt ? dayjs(endsAt).toISOString() : null,
      app_notification_screen_name:
        notificationType === "store_following"
          ? "Brand"
          : notificationType === "product_wishlist"
          ? "ProductDetails"
          : screenName || null,
      app_notification_shop_id:
        notificationType === "store_following" && selectedShop?.shop_id
          ? selectedShop.shop_id
          : null,

      app_notification_product_ids:
        notificationType === "product_wishlist" && selectedProduct?.length
          ? selectedProduct.map((p) => p.product_id) // array of IDs
          : [],
      app_notification_image_url: uploadedUrl || null,
    };

    try {
      const resultAction = await dispatch(createNotification(payload));

      if (createNotification.fulfilled.match(resultAction)) {
        setSnackbarSeverity("success");
        setSnackbarMessage(
          resultAction.payload.message || "Notification created"
        );
        setOpenSnackbar(true);

        // reset form
        setNotificationTitle("");
        setNotificationDescription("");
        setNotificationType("");
        setSchedule("once");
        setTimeSlot("");
        setStartsAt(null);
        setEndsAt(null);
        setSelectedShop(null);
        setSelectedProduct([]);
        setShopSearch("");
        setProductSearch("");
        setUploadedImages([]);
        setPreviewImages([]);
        setScreenName("");
        setErrors({});
        navigate(-1);
      } else {
        setSnackbarSeverity("error");
        setSnackbarMessage("Failed to create notification");
        setOpenSnackbar(true);
      }
    } catch (err: any) {
      console.error("Submit failed:", err);
      setSnackbarSeverity("error");
      setSnackbarMessage(err?.message || "Something went wrong");
      setOpenSnackbar(true);
    }
  };

  useEffect(() => {
    return () => {
      if (previewImage) URL.revokeObjectURL(previewImage);
    };
  }, [previewImage]);

  // Upload helper
  const uploadImage = async (file: File) => {
    setUploadingImage(true);
    try {
      const fd = new FormData();
      fd.append("file", file);

      const res = await fetch(UPLOAD_API, { method: "POST", body: fd });
      if (!res.ok) throw new Error(`Upload failed with status ${res.status}`);

      const data = await res.json();
      if (!data?.url) throw new Error("Server did not return a URL");

      setUploadedUrl(data.url);
      setSnackbarSeverity("success");
      setSnackbarMessage("Image uploaded successfully.");
      setOpenSnackbar(true);
    } catch (err: any) {
      console.error("Upload failed:", err);
      setUploadedUrl("");
      setSnackbarSeverity("error");
      setSnackbarMessage(err?.message || "Image upload failed.");
      setOpenSnackbar(true);
    } finally {
      setUploadingImage(false);
    }
  };

  const handleSingleFile = (file?: File) => {
    if (!file) return;

    if (previewImage) URL.revokeObjectURL(previewImage);
    const nextUrl = URL.createObjectURL(file);
    setPreviewImage(nextUrl);

    setUploadedUrl(""); // reset previous url until new upload completes
    uploadImage(file);
  };

  const handleFileSelect = (files: File[]) => {
    handleSingleFile(files?.[0]);
  };

  const handleClickChange = () => {
    hiddenFileInputRef.current?.click();
  };

  const handleHiddenInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    handleSingleFile(file);
    e.currentTarget.value = ""; // allow same-file reselect
  };

  return (
    <Parentstyle>
      <div className="mb-3">
        <GoBackButton onClick={() => navigate(-1)} />
      </div>
      <Childstyle>
        <Typography variant="h5" fontWeight="medium" className="pb-5">
          Create App Notification
        </Typography>

        <Card
          sx={{
            borderRadius: "12px",
            border: "1px solid #e0e0e0",
            boxShadow: 1,
          }}
        >
          <form onSubmit={onSubmit} noValidate>
            <Grid container direction="column" spacing={2}>
              <Grid
                container
                spacing={0}
                alignItems="center"
                justifyContent="space-between"
                flexWrap="wrap"
                className="max-w-full"
              >
                <Grid size={{ xs: 12, md: 8, lg: 12 }} className="p-5">
                  <div className="flex flex-col gap-5">
                    <TextField
                      label="Notification Title"
                      variant="outlined"
                      fullWidth
                      required
                      size="small"
                      value={notificationTitle}
                      onChange={(e) => setNotificationTitle(e.target.value)}
                      error={!!errors.title}
                      helperText={errors.title || ""}
                    />

                    <TextField
                      label="Notification Description"
                      variant="outlined"
                      fullWidth
                      size="small"
                      multiline
                      minRows={5}
                      value={notificationDescription}
                      onChange={(e) =>
                        setNotificationDescription(e.target.value)
                      }
                    />

                    <TextField
                      label="Notification Type"
                      variant="outlined"
                      fullWidth
                      size="small"
                      value={notificationType}
                      select
                      onChange={(e) => setNotificationType(e.target.value)}
                      error={!!errors.type}
                      helperText={errors.type || ""}
                      SelectProps={{
                        MenuProps: {
                          PaperProps: { style: { padding: "8px" } },
                        },
                      }}
                    >
                      <MenuItem value="broadcast" className="py-2">
                        <Box>
                          <Typography variant="body2" fontWeight="500">
                            Broadcast
                          </Typography>
                          <Typography variant="caption" color="text.secondary">
                            Send to everyone who has notifications enabled.
                          </Typography>
                        </Box>
                      </MenuItem>

                      <MenuItem value="store_following" className="py-2">
                        <Box>
                          <Typography variant="body2" fontWeight="500">
                            Store Following
                          </Typography>
                          <Typography variant="caption" color="text.secondary">
                            Send only to users who follow this store.
                          </Typography>
                        </Box>
                      </MenuItem>

                      <MenuItem value="product_wishlist" className="py-2">
                        <Box>
                          <Typography variant="body2" fontWeight="500">
                            Product Wishlist
                          </Typography>
                          <Typography variant="caption" color="text.secondary">
                            Send only to users who have this product in their
                            wishlist.
                          </Typography>
                        </Box>
                      </MenuItem>

                      <MenuItem value="send_all" className="py-2">
                        <Box>
                          <Typography variant="body2" fontWeight="500">
                            Send to All
                          </Typography>
                          <Typography variant="caption" color="text.secondary">
                            Force send to all users (ignores preferences).
                          </Typography>
                        </Box>
                      </MenuItem>
                    </TextField>
                  </div>
                </Grid>

                {/* STORE DROPDOWN */}
                {notificationType === "store_following" && (
                  <Grid size={{ xs: 12 }} className="px-5">
                    <Autocomplete
                      options={
                        Array.isArray(merchantsDD.data) ? merchantsDD.data : []
                      }
                      loading={merchantsDD.loading}
                      value={selectedShop}
                      onChange={(_, val) => setSelectedShop(val)}
                      onInputChange={(_, val) => setShopSearch(val)}
                      getOptionLabel={(o) => o?.shop_name ?? ""}
                      isOptionEqualToValue={(o, v) => o.shop_id === v.shop_id}
                      renderOption={(props, option) => (
                        <Box
                          component="li"
                          {...props}
                          sx={{
                            display: "flex",
                            alignItems: "center",
                            gap: 1,
                            p: 1,
                          }}
                        >
                          {/* ✅ Show logo if available */}
                          {option?.shop_logo_url ? (
                            <Avatar
                              src={option.shop_logo_url}
                              alt={option.shop_name}
                              sx={{ width: 30, height: 30 }}
                            />
                          ) : (
                            <Avatar sx={{ width: 30, height: 30 }}>
                              {option.shop_name[0]}
                            </Avatar>
                          )}
                          <Typography variant="body2">
                            {option.shop_name}
                          </Typography>
                        </Box>
                      )}
                      renderInput={(params) => (
                        <TextField
                          {...params}
                          label="Select Store"
                          size="small"
                          error={!!errors.shop}
                          helperText={errors.shop || ""}
                          InputProps={{
                            ...params.InputProps,
                            endAdornment: (
                              <>
                                {merchantsDD.loading ? (
                                  <CircularProgress size={18} />
                                ) : null}
                                {params.InputProps.endAdornment}
                              </>
                            ),
                          }}
                        />
                      )}
                    />
                  </Grid>
                )}

                {/* PRODUCT DROPDOWN */}
                {notificationType === "product_wishlist" && (
                  <Grid size={{ xs: 12 }} className="px-5">
                    <Autocomplete
                      multiple
                      disableCloseOnSelect
                      options={
                        Array.isArray(productsDD.data) ? productsDD.data : []
                      }
                      loading={productsDD.loading}
                      value={selectedProduct || []} // <-- Array now
                      onChange={(_, val) => setSelectedProduct(val)} // val is array
                      onInputChange={(_, val) => setProductSearch(val)} // search handler
                      getOptionLabel={(o) => o?.product_name ?? ""}
                      isOptionEqualToValue={(o, v) =>
                        o.product_id === v.product_id
                      }
                      renderOption={(props, option, {}) => (
                        <Box
                          component="li"
                          {...props}
                          sx={{
                            display: "flex",
                            alignItems: "center",
                            gap: 1,
                            p: 1,
                          }}
                        >
                          <Avatar
                            variant="square"
                            src={option.product_image_url || ""}
                            alt={option.product_name}
                            sx={{ width: 36, height: 36, borderRadius: 1 }}
                          >
                            {!option.product_image_url &&
                              option.product_name[0]}
                          </Avatar>
                          <Typography variant="body2">
                            {option.product_name}
                          </Typography>
                        </Box>
                      )}
                      renderInput={(params) => (
                        <TextField
                          {...params}
                          label="Select Products"
                          size="small"
                          error={!!errors.product}
                          helperText={errors.product || ""}
                          InputProps={{
                            ...params.InputProps,
                            endAdornment: (
                              <>
                                {productsDD.loading ? (
                                  <CircularProgress size={18} />
                                ) : null}
                                {params.InputProps.endAdornment}
                              </>
                            ),
                          }}
                        />
                      )}
                    />
                  </Grid>
                )}

                {/* DATE RANGE */}
                <Grid container spacing={2} className="px-5 mb-5 mt-4 w-full">
                  <Grid size={{ xs: 12, md: 6 }}>
                    <LocalizationProvider dateAdapter={AdapterDayjs}>
                      <DateTimePicker
                        label="Start Date & Time"
                        value={startsAt}
                        onChange={(v) => {
                          setStartsAt(v);
                          const isPast = !!v && v.isBefore(dayjs());
                          setErrors((prev) => ({
                            ...prev,
                            startsAt: isPast
                              ? "Start must be in the future"
                              : "",
                          }));
                        }}
                        // Blocks any selection before the current moment
                        disablePast
                        minDateTime={dayjs()}
                        slotProps={{
                          textField: {
                            size: "small",
                            fullWidth: true,
                            required: true,
                            error: !!errors.startsAt,
                            helperText: errors.startsAt || "",
                          },
                        }}
                      />
                    </LocalizationProvider>
                  </Grid>
                  <Grid size={{ xs: 12, md: 6 }}>
                    <LocalizationProvider dateAdapter={AdapterDayjs}>
                      <DateTimePicker
                        label="End Date & Time (optional)"
                        value={endsAt}
                        minDateTime={startsAt || dayjs()} // disable all dates before startsAt (or today if null)
                        onChange={(v) => {
                          setEndsAt(v);
                          // Simple validation: end date must be after start date
                          if (startsAt && v && v.isBefore(startsAt)) {
                            setErrors((prev) => ({
                              ...prev,
                              endsAt: "End must be after start date/time",
                            }));
                          } else {
                            setErrors((prev) => ({ ...prev, endsAt: "" }));
                          }
                        }}
                        slotProps={{
                          textField: {
                            size: "small",
                            fullWidth: true,
                            error: !!errors.endsAt,
                            helperText: errors.endsAt || "",
                          },
                        }}
                      />
                    </LocalizationProvider>
                  </Grid>
                </Grid>

                {/* Schedule + Time Slot */}
                <Grid size={{ xs: 12, md: 12 }} className="px-5">
                  <TextField
                    label="Schedule"
                    variant="outlined"
                    fullWidth
                    size="small"
                    value={schedule}
                    select
                    onChange={(e) => setSchedule(e.target.value)}
                    SelectProps={{
                      MenuProps: { PaperProps: { style: { padding: "8px" } } },
                    }}
                  >
                    <MenuItem value="once" className="py-2">
                      <Box>
                        <Typography variant="body2" fontWeight="500">
                          Once
                        </Typography>
                        <Typography variant="caption" color="text.secondary">
                          Send only one time at the selected start date & time.
                        </Typography>
                      </Box>
                    </MenuItem>

                    <MenuItem value="daily" className="py-2">
                      <Box>
                        <Typography variant="body2" fontWeight="500">
                          Daily
                        </Typography>
                        <Typography variant="caption" color="text.secondary">
                          Send every day between the selected start and end
                          dates.
                        </Typography>
                      </Box>
                    </MenuItem>

                    <MenuItem value="weekly" className="py-2">
                      <Box>
                        <Typography variant="body2" fontWeight="500">
                          Weekly
                        </Typography>
                        <Typography variant="caption" color="text.secondary">
                          Send once a week on the same weekday as the start
                          date.
                        </Typography>
                      </Box>
                    </MenuItem>

                    <MenuItem value="monthly" className="py-2">
                      <Box>
                        <Typography variant="body2" fontWeight="500">
                          Monthly
                        </Typography>
                        <Typography variant="caption" color="text.secondary">
                          Send once a month on the same day of the month as the
                          start date.
                        </Typography>
                      </Box>
                    </MenuItem>
                  </TextField>
                </Grid>
              </Grid>
            </Grid>

            {/* Image previews */}
            {previewImages.length > 0 && (
              <div className="flex flex-wrap gap-4 p-5">
                {previewImages.map((src, index) => (
                  <img
                    key={index}
                    src={src}
                    alt={`preview-${index}`}
                    style={{
                      width: "100px",
                      height: "100px",
                      objectFit: "cover",
                      borderRadius: "8px",
                      border: "1px solid #ccc",
                    }}
                  />
                ))}
              </div>
            )}

            {/* Actions */}
            <div className="flex justify-between p-5">
              <div className="p-5">
                {previewImage ? (
                  <div className="relative inline-block">
                    <img
                      src={previewImage}
                      alt="preview"
                      style={{
                        width: "140px",
                        height: "140px",
                        objectFit: "cover",
                        borderRadius: "12px",
                        border: "1px solid #ccc",
                        display: "block",
                      }}
                    />
                    <button
                      type="button"
                      onClick={handleClickChange}
                      className="absolute bottom-2 right-2 rounded-md px-3 py-1 text-sm bg-white/90 hover:bg-white shadow border border-gray-200"
                    >
                      {uploadingImage ? "Uploading..." : "Change"}
                    </button>

                    <input
                      ref={hiddenFileInputRef}
                      type="file"
                      accept="image/*"
                      onChange={handleHiddenInputChange}
                      style={{ display: "none" }}
                    />
                  </div>
                ) : (
                  <InputFileUpload onFileSelect={handleFileSelect} />
                )}
              </div>
              {/* <InputFileUpload onFileSelect={handleFileSelect} /> */}
              <Button
                type="submit"
                variant="contained"
                className="self-end"
                disabled={isSubmitDisabled}
              >
                Submit
              </Button>
            </div>
          </form>
        </Card>

        {/* Snackbar */}
        <Snackbar
          open={openSnackbar}
          autoHideDuration={2500}
          onClose={() => setOpenSnackbar(false)}
          anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
        >
          <Alert
            onClose={() => setOpenSnackbar(false)}
            severity={snackbarSeverity}
            sx={{ width: "100%" }}
          >
            {snackbarMessage}
          </Alert>
        </Snackbar>
      </Childstyle>
    </Parentstyle>
  );
};

export default CreateApp;
