import {
  Button,
  Card,
  Pagination,
  Typography,
  Snackbar,
  Alert,
} from "@mui/material";
import React, { useEffect, useState } from "react";
import NotificationsTable from "./NotificationsTable";
import { useNavigate } from "react-router";
import Parentstyle from "../Style/Parentstyle";
import Childstyle from "../Style/childstyle";
import { useAppDispatch, useAppSelector } from "../hooks/hooks";
import {
  fetchNotifications,
  deleteNotification,
} from "../../redux/thunks/notificationThunks";
import { useSelector } from "react-redux";
import { RoleLike } from "../../components/functions/Roles";
import { useRolePermissions } from "../../components/functions/useRolePermissions";

const AppNotification: React.FC = () => {
  const navigate = useNavigate();
  const dispatch = useAppDispatch();

  const { notifications, status, totalPages } = useAppSelector(
    (state) => state.notification
  );
  const [page, setPage] = useState(1);
  const [openSnackbar, setOpenSnackbar] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState("");
  const limit = 10;

  useEffect(() => {
    dispatch(fetchNotifications({ page, limit }));
  }, [page, dispatch]);

  const handlePageChange = (_: React.ChangeEvent<unknown>, value: number) => {
    setPage(value);
  };

  const handleDelete = async (id: number) => {
    const result = await dispatch(deleteNotification(id));

    // Redux delete thunk returns fulfilled with payload
    if (deleteNotification.fulfilled.match(result)) {
      setSnackbarMessage(
        result.payload.message || "Notification deleted successfully"
      );
      setOpenSnackbar(true);
    }
  };
  const rawRoles = useSelector((state: any) => state.auth.user?.roles) as
    | RoleLike[]
    | undefined;

  const { can } = useRolePermissions(rawRoles);

  const canRead = can("notification", "read");
  const canWrite = can("notification", "write");

  console.log("canRead", canRead, canWrite);

  return (
    <Parentstyle>
      <Childstyle>
        <div className="flex justify-between pb-5">
          <Typography variant="h6" fontWeight="medium">
            App Notification
          </Typography>
          <Button
            onClick={() => navigate("/notifications/app/createappnotification")}
            variant="contained"
            size="small"
            disabled={!canWrite}
            sx={{ fontWeight: 300, textTransform: "none" }}
          >
            Create Notification
          </Button>
        </div>

        <Card>
          <NotificationsTable
            data={notifications}
            loading={status === null}
            onDelete={handleDelete}
            canRead={canRead}
          />
          <div className="m-5 py-1">
            {canRead && totalPages > 1 && (
              <Pagination
                count={totalPages || 1}
                page={page}
                onChange={handlePageChange}
                variant="outlined"
                shape="rounded"
                color="primary"
              />
            )}
          </div>
        </Card>

        {/* Success Snackbar */}
        <Snackbar
          open={openSnackbar}
          autoHideDuration={2000}
          onClose={() => setOpenSnackbar(false)}
          anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
        >
          <Alert
            onClose={() => setOpenSnackbar(false)}
            severity="success"
            sx={{ width: "100%" }}
          >
            {snackbarMessage}
          </Alert>
        </Snackbar>
      </Childstyle>
    </Parentstyle>
  );
};

export default AppNotification;
