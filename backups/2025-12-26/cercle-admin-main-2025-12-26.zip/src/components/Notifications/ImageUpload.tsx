import * as React from "react";
import { styled } from "@mui/material/styles";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import IconButton from "@mui/material/IconButton";
import AddPhotoAlternateIcon from "@mui/icons-material/AddPhotoAlternate";

const HiddenInput = styled("input")({
  display: "none",
});

const UploadBox = styled(Box)(({ theme }) => ({
  border: "2px dashed #ccc",
  borderRadius: theme.shape.borderRadius,
  padding: theme.spacing(2),
  textAlign: "center",
  cursor: "pointer",
  transition: "border-color 0.3s",
  "&:hover": {
    borderColor: theme.palette.primary.main,
  },
}));

interface ImageUploaderProps {
  onFileSelect: (files: File[]) => void;
}

export default function ImageUploader({ onFileSelect }: ImageUploaderProps) {
  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files?.length) {
      const filesArray = Array.from(event.target.files);
      console.log("Selected files:", filesArray);
      onFileSelect(filesArray);
    }
  };

  return (
    <label htmlFor="upload-photo">
      <UploadBox>
        <IconButton disabled>
          <AddPhotoAlternateIcon sx={{ fontSize: 40, color: "#ccc" }} />
        </IconButton>
        <Typography variant="body1" color="textSecondary">
          Insert Photo(s)
        </Typography>
      </UploadBox>
      <HiddenInput
        accept="image/*"
        id="upload-photo"
        type="file"
        multiple // <-- allow multiple file selection
        onChange={handleChange}
      />
    </label>
  );
}
