import React, { useMemo, useState } from "react";
import {
  Avatar,
  Tooltip,
  IconButton,
  Snackbar,
  Alert,
  Typography,
  Backdrop,
  CircularProgress,
  Card,
} from "@mui/material";
import DeleteIcon from "@mui/icons-material/Delete";
import { AntSwitch } from "../button/Switch";
import { useNavigate } from "react-router";
import { useSelector } from "react-redux";
import getParticipantsFromRow from "../../components/functions/getParticipantsFromRow";
import { useAppDispatch } from "../../components/hooks/hooks";
import {
  deleteCollection,
  updateTrendingCollectionStatus,
} from "../../../src/redux/thunks/collectionThunks";
import AccessDenied from "../../components/merchant/Accessdenied";
import { useRolePermissions } from "../../components/functions/useRolePermissions";
import { RoleLike } from "../functions/Roles";
import DeleteModal from "../../components/modules/DeleteModal";

const defaultAvatars = [
  "/images/avatars/1.png",
  "/images/avatars/2.png",
  "/images/avatars/3.png",
];

const TrendingCollectionTable: React.FC = () => {
  const navigate = useNavigate();
  const dispatch = useAppDispatch();

  const rawRoles = useSelector((s: any) => s.auth.user?.roles) as
    | RoleLike[]
    | undefined;

  // Permissions
  const { can } = useRolePermissions(rawRoles);

  // Data
  const collections = useSelector((s: any) => s.collections?.collections || []);
  const isLoadingDelete =
    useSelector(
      (s: any) =>
        s.collections?.isDeleting || s.collections?.deleteStatus === "pending"
    ) || false;

  // UI state
  const [snackbarSeverity, setSnackbarSeverity] = useState<"success" | "error">(
    "success"
  );
  const [selectedRow, setSelectedRow] = useState<any>(null);
  const [openSnackbar, setOpenSnackbar] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState("");
  const [modalopen, setModalopen] = useState(false);
  const [deletedIds, setDeletedIds] = useState<Set<number | string>>(new Set());

  const visibleCollections = useMemo(
    () => collections.filter((c: any) => !deletedIds.has(c.trending_id)),
    [collections, deletedIds]
  );

  // READ gate
  if (!can("collections", "read")) {
    return (
      <AccessDenied
        subtitle="Your account is missing read permissions for collections. Contact an admin if you need access."
        secondaryActionText="Contact admin"
        onSecondaryAction={() => {
          window.open("https://cymbiote.com/contact-us/", "_blank");
        }}
      />
    );
  }

  // Handlers (WRITE guarded)
  const handleDelete = (row?: any) => {
    if (!can("collections", "write")) {
      setSnackbarMessage("You need collections:write (or global) to delete.");
      setSnackbarSeverity("error");
      setOpenSnackbar(true);
      return;
    }
    setSelectedRow(row);
    setModalopen(true);
  };

  const handleUpdate = async (row?: any) => {
    if (!can("collections", "write")) {
      setSnackbarMessage(
        "You need collections:write (or global) to change status."
      );
      setSnackbarSeverity("error");
      setOpenSnackbar(true);
      return;
    }
    const result = await dispatch(
      updateTrendingCollectionStatus({
        trending_id: row.trending_id,
        is_active: !row.trending_is_active,
      })
    );
    if (updateTrendingCollectionStatus.fulfilled.match(result)) {
      setSnackbarMessage(
        result.payload?.message || "Collection updated successfully"
      );
      setSnackbarSeverity("success");
      setOpenSnackbar(true);
    } else {
      setSnackbarMessage(
        (result.payload as string) || "Failed to update collection"
      );
      setSnackbarSeverity("error");
      setOpenSnackbar(true);
    }
  };

  const handleConfirmDelete = async () => {
    if (!selectedRow?.trending_id) return;

    if (!can("collections", "write")) {
      setSnackbarMessage("You need collections:write (or global) to delete.");
      setSnackbarSeverity("error");
      setOpenSnackbar(true);
      return;
    }

    const result = await dispatch(
      deleteCollection({ collectionId: String(selectedRow.trending_id) })
    );

    if (deleteCollection.fulfilled.match(result)) {
      setDeletedIds((prev) => new Set(prev).add(selectedRow.trending_id));
      setSnackbarMessage(
        result.payload?.message || "Collection deleted successfully"
      );
      setSnackbarSeverity("success");
      setOpenSnackbar(true);
      setModalopen(false);
    } else {
      setSnackbarMessage(
        (result.payload as string) || "Failed to delete collection"
      );
      setSnackbarSeverity("error");
      setOpenSnackbar(true);
    }
  };

  const handleClose = () => setModalopen(false);

  const canWrite = can("collections", "write");

  return (
    <div className="overflow-x-auto border-gray-200 rounded-lg shadow-sm">
      <table className="min-w-full text-sm text-left">
        <thead className="bg-gray-50 border-b text-gray-500 font-semibold">
          <tr>
            <th className="px-6 py-3 whitespace-nowrap">Collection Title</th>
            <th className="px-6 py-3 whitespace-nowrap">
              Collection Description
            </th>
            <th className="px-6 py-3 whitespace-nowrap">Participants</th>
            <th className="px-6 py-3 whitespace-nowrap">Products tag</th>
            <th className="px-6 py-3 whitespace-nowrap">Status</th>
            <th className="px-6 py-3 whitespace-nowrap">Action</th>
          </tr>
        </thead>

        <tbody>
          {visibleCollections.length === 0 ? (
            <tr>
              <td colSpan={6} className="px-6 py-8">
                <Card
                  variant="outlined"
                  sx={{
                    p: 3,
                    borderRadius: 2,
                    borderColor: (t) => t.palette.divider,
                    textAlign: "center",
                  }}
                >
                  <Typography variant="body1" color="text.secondary">
                    No collections found.
                  </Typography>
                </Card>
              </td>
            </tr>
          ) : (
            visibleCollections.map((row: any, index: number) => {
              const participants = getParticipantsFromRow(row);
              const avatars = participants.length
                ? participants
                : defaultAvatars;

              const shownCount = Math.min(3, avatars.length);
              const extraCount = Math.max(
                0,
                (Number(row?.shop_count) || 0) - shownCount
              );

              return (
                <tr
                  key={row.trending_id ?? index}
                  className="border-b last:border-none"
                >
                  <td
                    className={`px-6 py-4 whitespace-nowrap ${canWrite ? "cursor-pointer" : "cursor-default"
                      }`}
                    onClick={() => {
                      if (canWrite) {
                        navigate(
                          `/collections/EditCollection/${row.trending_id ?? index + 1
                          }`
                        );
                      }
                    }}
                  >
                    <div className="flex items-center gap-3">
                      <img
                        src={
                          row.trending_banner_url ||
                          "https://cdn.shopify.com/s/files/1/0595/2379/2944/files/img_not_found_cercle.jpg?v=1757333158"
                        }
                        alt="banner"
                        className="w-8 h-8 rounded object-contain"
                        loading="lazy"
                        onError={(e) => {
                          const target = e.target as HTMLImageElement;
                          target.src = "https://cdn.shopify.com/s/files/1/0595/2379/2944/files/img_not_found_cercle.jpg?v=1757333158";
                        }}
                      />
                      {canWrite ? (
                        <span className="text-gray-800">
                          {row.trending_name || "Untitled"}
                        </span>
                      ) : (
                        <Tooltip title="You need collections:write (or global) to edit">
                          <span className="text-gray-800">
                            {row.trending_name || "Untitled"}
                          </span>
                        </Tooltip>
                      )}
                    </div>
                  </td>

                  <Tooltip title={row.trending_description} placement="top">
                    <td className="px-6 py-4 whitespace-nowrap max-w-xs overflow-hidden text-ellipsis">
                      {row.trending_description || "No description available"}
                    </td>
                  </Tooltip>

                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center gap-1">
                      {avatars.slice(0, 3).map((src: string, i: number) => (
                        <Avatar
                          key={i}
                          src={src}
                          imgProps={{
                            onError: (e) => {
                              (e.currentTarget as HTMLImageElement).src =
                                defaultAvatars[i % defaultAvatars.length];
                            },
                            loading: "lazy",
                          }}
                          sx={{
                            width: 24,
                            height: 24,
                            fontSize: 10,
                            border: "2px solid white",
                            zIndex: 3 - i,
                            ml: i > 0 ? -1.5 : 0,
                          }}
                        />
                      ))}
                      {extraCount > 0 && (
                        <span className="ml-2 text-xs font-medium text-gray-700">
                          +{extraCount}
                        </span>
                      )}
                    </div>
                  </td>

                  <td className="px-6 py-4 whitespace-nowrap">
                    {Number(row?.total_product_count) || 0}
                  </td>

                  {/* Status toggle: write required */}
                  <td className="px-6 py-4 whitespace-nowrap">
                    {canWrite ? (
                      <AntSwitch
                        defaultChecked={Boolean(
                          row?.trending_is_active ?? true
                        )}
                        color="primary"
                        onClick={() => handleUpdate(row)}
                      />
                    ) : (
                      <Tooltip title="You need collections:write (or global) to change status">
                        <span>
                          <AntSwitch
                            defaultChecked={Boolean(
                              row?.trending_is_active ?? true
                            )}
                            color="primary"
                            disabled
                          />
                        </span>
                      </Tooltip>
                    )}
                  </td>

                  {/* Delete: write required */}
                  <td className="px-8 py-4 whitespace-nowrap">
                    <div className="flex items-center gap-2">
                      {canWrite ? (
                        <Tooltip title="Delete">
                          <IconButton
                            size="small"
                            onClick={() => handleDelete(row)}
                          >
                            <DeleteIcon fontSize="small" color="error" />
                          </IconButton>
                        </Tooltip>
                      ) : (
                        <Tooltip title="You need collections:write (or global) to delete">
                          <span>
                            <IconButton size="small" disabled>
                              <DeleteIcon fontSize="small" color="disabled" />
                            </IconButton>
                          </span>
                        </Tooltip>
                      )}
                    </div>
                  </td>
                </tr>
              );
            })
          )}
        </tbody>
      </table>

      <Snackbar
        open={openSnackbar}
        autoHideDuration={2000}
        onClose={() => setOpenSnackbar(false)}
        anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
      >
        <Alert
          onClose={() => setOpenSnackbar(false)}
          severity={snackbarSeverity}
          sx={{ width: "100%" }}
        >
          {snackbarMessage}
        </Alert>
      </Snackbar>

      <DeleteModal
        title="Are you sure you want to delete this Collection?"
        modalopen={modalopen}
        handleConfirmDelete={handleConfirmDelete}
        deleting={isLoadingDelete}
        handleClose={handleClose}
      />
      <Backdrop open={isLoadingDelete} sx={{ zIndex: 2000 }}>
        <CircularProgress />
      </Backdrop>
    </div>
  );
};

export default TrendingCollectionTable;
