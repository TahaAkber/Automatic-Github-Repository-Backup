import {
  Alert,
  Button,
  Card,
  CircularProgress,
  Grid,
  Snackbar,
  TextField,
  Typography,
} from "@mui/material";
import React, { useEffect, useRef, useState } from "react";
import InputFileUpload from "../../components/Notifications/ImageUpload";
import Parentstyle from "../Style/Parentstyle";
import Childstyle from "../Style/childstyle";
import dayjs, { Dayjs } from "dayjs";
import { createCollection } from "../../redux/thunks/collectionThunks";
import { useAppDispatch } from "../hooks/hooks";
import DatePicker from "./DatePicker";
import { useNavigate } from "react-router";
import GoBackButton from "../button/Goback";

export const appUrl = import.meta.env.VITE_APP_URL;

const UPLOAD_API = `${appUrl}/api/upload/`;
console.log("uploaded", UPLOAD_API);
const CreateCollections: React.FC = () => {
  const dispatch = useAppDispatch();
  const navigate = useNavigate();

  const [collectiontitle, setcollectiontitle] = useState("");
  const [collectiondescription, setcollectiondescription] = useState("");
  const [timeslot, settimeslot] = useState<Dayjs | null>(dayjs());

  const [loading, setLoading] = useState(false);
  const [openSnackbar, setOpenSnackbar] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState("");
  const [snackbarSeverity, setSnackbarSeverity] = useState<"success" | "error">(
    "success"
  );
  const [openReadySnackbar, setOpenReadySnackbar] = useState(false);

  // File & image states
  const [previewImage, setPreviewImage] = useState<string | null>(null);
  const [uploadedUrl, setUploadedUrl] = useState<string>(""); // <- server URL (e.g., http://localhost:3500/uploads/xxx.jpeg)
  const [uploadingImage, setUploadingImage] = useState(false);

  const hiddenFileInputRef = useRef<HTMLInputElement>(null);
  const formWasCompleteRef = useRef(false);
  const navigateTimeoutRef = useRef<number | null>(null);

  useEffect(() => {
    return () => {
      if (previewImage) URL.revokeObjectURL(previewImage);
    };
  }, [previewImage]);

  useEffect(() => {
    return () => {
      if (navigateTimeoutRef.current) {
        clearTimeout(navigateTimeoutRef.current);
      }
    };
  }, []);

  useEffect(() => {
    const isComplete = Boolean(
      uploadedUrl &&
      collectiontitle?.trim() &&
      collectiondescription?.trim() &&
      timeslot
    );
    if (isComplete && !formWasCompleteRef.current) {
      setOpenReadySnackbar(true);
    }
    formWasCompleteRef.current = isComplete;
  }, [uploadedUrl, collectiontitle, collectiondescription, timeslot]);

  // ---- Upload helper
  const uploadImage = async (file: File) => {
    setUploadingImage(true);
    try {
      const fd = new FormData();
      fd.append("file", file);
      const res = await fetch(UPLOAD_API, { method: "POST", body: fd });
      if (!res.ok) {
        throw new Error(`Upload failed with status ${res.status}`);
      }
      const data = await res.json();
      if (!data?.url) throw new Error("Server did not return a URL");
      setUploadedUrl(data.url);
      setSnackbarSeverity("success");
      setSnackbarMessage("Image uploaded successfully.");
      setOpenSnackbar(true);
    } catch (err: any) {
      console.error("Upload failed:", err);
      setUploadedUrl("");
      setSnackbarSeverity("error");
      setSnackbarMessage(err?.message || "Image upload failed.");
      setOpenSnackbar(true);
    } finally {
      setUploadingImage(false);
    }
  };

  const handleSingleFile = (file?: File) => {
    if (!file) return;

    if (previewImage) URL.revokeObjectURL(previewImage);

    const nextUrl = URL.createObjectURL(file);
    setPreviewImage(nextUrl);

    setUploadedUrl("");

    uploadImage(file);
  };

  const handleFileSelect = (files: File[]) => {
    handleSingleFile(files?.[0] || undefined);
  };

  const handleClickChange = () => {
    hiddenFileInputRef.current?.click();
  };

  const handleHiddenInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    handleSingleFile(file);
    e.currentTarget.value = "";
  };

  const handleSubmit = async () => {
    if (!uploadedUrl) {
      setSnackbarSeverity("error");
      setSnackbarMessage("Please wait for the image to finish uploading.");
      setOpenSnackbar(true);
      return;
    }

    setLoading(true);

    const end_Date = timeslot?.startOf("day").toISOString();

    const payload = {
      collection_Title: collectiontitle,
      collection_Description: collectiondescription,
      collection_image_url: uploadedUrl,
      end_Date,
    };
    console.log("payload", payload);

    try {
      const resultAction = await dispatch(createCollection(payload));

      if (createCollection.fulfilled.match(resultAction)) {
        console.log("✅ Collection created:", resultAction.payload);
        setSnackbarSeverity("success");
        setSnackbarMessage("Collection created successfully!");
        setOpenSnackbar(true);

        navigateTimeoutRef.current = window.setTimeout(() => {
          navigate("/collections");
        }, 2000);
      } else {
        console.error("❌ Failed:", resultAction.payload);
        setSnackbarSeverity("error");
        setSnackbarMessage(
          (resultAction as any)?.error?.message ||
          "Failed to create collection!"
        );
        setOpenSnackbar(true);
      }
    } catch (error) {
      console.error("🚨 Error while submitting:", error);
      setSnackbarSeverity("error");
      setSnackbarMessage("Something went wrong while creating the collection.");
      setOpenSnackbar(true);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Parentstyle>
      <div className="mb-3">
        <GoBackButton onClick={() => navigate(-1)} />
      </div>
      <Childstyle>
        <Typography variant="h6" fontWeight="medium" className="pb-5">
          Create Collection
        </Typography>

        <Card
          sx={{
            borderRadius: "12px",
            border: "1px solid #e0e0e0",
            boxShadow: 1,
          }}
        >
          <Grid container direction="column" spacing={2}>
            <Grid
              container
              spacing={0}
              alignItems="center"
              justifyContent="space-between"
              flexWrap="wrap"
              className="max-w-full"
            >
              <Grid size={{ xs: 12, md: 8, lg: 12 }} className="p-5">
                <div className="flex flex-col gap-5">
                  <TextField
                    id="Collection Title"
                    label="Collection Title..."
                    variant="outlined"
                    autoComplete="off"
                    fullWidth
                    size="small"
                    onChange={(e) => setcollectiontitle(e.target.value)}
                  />
                  <TextField
                    id="Collection Description"
                    label="Collection Description..."
                    variant="outlined"
                    autoComplete="off"
                    fullWidth
                    size="small"
                    multiline
                    onChange={(e) => setcollectiondescription(e.target.value)}
                    minRows={5}
                  />
                </div>
              </Grid>

              <Grid size={{ xs: 12, md: 6 }} className="px-5">
                <DatePicker settimeslot={settimeslot} timeslot={timeslot} />
              </Grid>
            </Grid>
          </Grid>

          <div className="flex justify-between items-center border-t border-b border-gray-200">
            <div className="p-5">
              {previewImage ? (
                <div className="relative inline-block">
                  <img
                    src={previewImage}
                    alt="preview"
                    style={{
                      width: "140px",
                      height: "140px",
                      objectFit: "cover",
                      borderRadius: "12px",
                      border: "1px solid #ccc",
                      display: "block",
                    }}
                  />
                  <button
                    type="button"
                    onClick={handleClickChange}
                    className="absolute bottom-2 right-2 rounded-md px-3 py-1 text-sm bg-white/90 hover:bg-white shadow border border-gray-200"
                  >
                    {uploadingImage ? "Uploading..." : "Change"}
                  </button>

                  <input
                    ref={hiddenFileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleHiddenInputChange}
                    style={{ display: "none" }}
                  />
                </div>
              ) : (
                <InputFileUpload onFileSelect={handleFileSelect} />
              )}
            </div>

            <div className="mr-4 pr-2 flex items-center gap-4">
              <Button
                variant="contained"
                size="large"
                onClick={handleSubmit}
                disabled={
                  loading ||
                  uploadingImage ||
                  !uploadedUrl ||
                  !collectiontitle ||
                  !timeslot ||
                  !collectiondescription
                }
              >
                Submit
              </Button>
              {(loading || uploadingImage) && <CircularProgress size={24} />}
            </div>
          </div>
        </Card>

        <Snackbar
          open={openSnackbar}
          autoHideDuration={2000}
          onClose={() => setOpenSnackbar(false)}
          anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
        >
          <Alert
            onClose={() => setOpenSnackbar(false)}
            severity={snackbarSeverity}
            sx={{ width: "100%" }}
          >
            {snackbarMessage}
          </Alert>
        </Snackbar>

        <Snackbar
          open={openReadySnackbar}
          autoHideDuration={3000}
          onClose={() => setOpenReadySnackbar(false)}
          anchorOrigin={{ vertical: "top", horizontal: "center" }}
        >
          <Alert
            onClose={() => setOpenReadySnackbar(false)}
            severity="info"
            sx={{ width: "100%" }}
          >
            Your collection is ready to be published!
          </Alert>
        </Snackbar>
      </Childstyle>
    </Parentstyle>
  );
};

export default CreateCollections;
