import React from "react";

type Props = {
  originalUrl?: string | null;
  previewUrl?: string | null;
  uploading?: boolean;
  onChangeClick?: () => void;
  onRevert?: () => void;
};

export const ImageSwapPreview: React.FC<Props> = ({
  originalUrl,
  previewUrl,
  uploading,
  onChangeClick,
  onRevert,
}) => {
  const hasPreview = !!previewUrl;

  return (
    <div className="relative inline-block">
      {/* Base (original) image */}
      {originalUrl ? (
        <img
          src={originalUrl}
          alt="original"
          style={{
            width: 140,
            height: 140,
            objectFit: "cover",
            borderRadius: 12,
            border: "1px solid #ccc",
            display: "block",
            opacity: hasPreview ? 0.4 : 1, // dim when preview exists
            transition: "opacity .2s ease",
          }}
        />
      ) : (
        <div
          style={{
            width: 140,
            height: 140,
            borderRadius: 12,
            border: "1px solid #ccc",
            display: "grid",
            placeItems: "center",
            fontSize: 12,
            color: "#666",
            background: "#f7f7f7",
          }}
        >
          No image
        </div>
      )}

      {/* Overlay preview (only when user selected a new file) */}
      {hasPreview && (
        <>
          <img
            src={previewUrl || ""}
            alt="preview"
            style={{
              position: "absolute",
              inset: 0,
              width: 140,
              height: 140,
              objectFit: "cover",
              borderRadius: 12,
              border: "1px solid #ccc",
            }}
          />
          <span
            style={{
              position: "absolute",
              top: 6,
              left: 6,
              fontSize: 11,
              background: "rgba(0,0,0,.7)",
              color: "#fff",
              padding: "2px 6px",
              borderRadius: 6,
            }}
          >
            {uploading ? "Uploading…" : "Preview"}
          </span>

          <button
            type="button"
            onClick={onRevert}
            className="absolute bottom-2 left-2 rounded-md px-2 py-1 text-xs bg-white/90 hover:bg-white shadow border border-gray-200"
          >
            Revert
          </button>
        </>
      )}

      <button
        type="button"
        onClick={onChangeClick}
        className="absolute bottom-2 right-2 rounded-md px-3 py-1 text-sm bg-white/90 hover:bg-white shadow border border-gray-200"
      >
        {uploading ? "Uploading..." : "Change"}
      </button>
    </div>
  );
};
