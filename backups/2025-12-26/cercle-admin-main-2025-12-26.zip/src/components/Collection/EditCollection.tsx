import {
  Alert,
  Button,
  Card,
  CircularProgress,
  Grid,
  Snackbar,
  TextField,
  Typography,
} from "@mui/material";
import React, { useEffect, useRef, useState } from "react";
import Participants from "./Participants";
import Parentstyle from "../Style/Parentstyle";
import Childstyle from "../Style/childstyle";
import InputFileUpload from "../../components/Notifications/ImageUpload";
import { useAppDispatch } from "../../components/hooks/hooks";
import {
  fetchCollectionById,
  updateTrendingCollection,
} from "../../../src/redux/thunks/collectionThunks";
import { useSelector } from "react-redux";
import { useNavigate, useParams } from "react-router";
import GoBackButton from "../../components/button/Goback";
import { ImageSwapPreview } from "./ImageSwapPreview";

export const appUrl = import.meta.env.VITE_APP_URL;
const UPLOAD_API = `${appUrl}/api/upload/`;

const EditCollection: React.FC = () => {
  const navigate = useNavigate();
  const dispatch = useAppDispatch();
  const { collectionId } = useParams();
  const [openSnackbar, setOpenSnackbar] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState("");
  const [snackbarSeverity, setSnackbarSeverity] = useState<"success" | "error">(
    "success"
  );
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");
  useEffect(() => {
    if (collectionId !== undefined) {
      dispatch(fetchCollectionById({ collection_id: Number(collectionId) }));
    }
  }, []);

  const { collections } = useSelector((state: any) => state.collections);
  const [description, setDescription] = useState(
    collections[0]?.trending_description ?? ""
  );
  useEffect(() => {
    setDescription(collections[0]?.trending_description);
  }, [collections]);

  const normalizeImageUrl = (img?: string | null) => {
    if (!img) return "";
    if (/^https?:\/\//i.test(img)) return img; // already absolute
    const base = (appUrl || "").replace(/\/+$/, "");
    const path = img.startsWith("/") ? img : `/${img}`;
    return `${base}${path}`;
  };

  const safeRevoke = (url?: string | null) => {
    if (url && url.startsWith("blob:")) {
      try {
        URL.revokeObjectURL(url);
      } catch {}
    }
  };

  const [originalImage, setOriginalImage] = useState<string>(""); // server-saved image
  useEffect(() => {
    setOriginalImage(normalizeImageUrl(collections?.[0]?.trending_banner_url));
  }, [collections]);

  const [previewImage, setPreviewImage] = useState<string | null>(null);
  const [uploadedUrl, setUploadedUrl] = useState<string>("");
  const [uploadingImage, setUploadingImage] = useState(false);
  const hiddenFileInputRef = useRef<HTMLInputElement>(null);

  const handleClickChange = () => {
    hiddenFileInputRef.current?.click();
  };

  const handleHiddenInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    handleSingleFile(file);
    e.currentTarget.value = "";
  };

  const handleFileSelect = (files: File[]) => {
    handleSingleFile(files?.[0] || undefined);
  };

  const handleSingleFile = (file?: File) => {
    if (!file) return;

    safeRevoke(previewImage);
    const localUrl = URL.createObjectURL(file);
    setPreviewImage(localUrl); // <-- overlay shows up
    setUploadedUrl("");

    uploadImage(file);
  };

  const uploadImage = async (file: File) => {
    setUploadingImage(true);
    try {
      const fd = new FormData();
      fd.append("file", file);
      const res = await fetch(UPLOAD_API, { method: "POST", body: fd });
      if (!res.ok) throw new Error(`Upload failed with status ${res.status}`);

      const data = await res.json();
      if (!data?.url) throw new Error("Server did not return a URL");

      const finalUrl = normalizeImageUrl(data.url);
      console.log("image", finalUrl);
      setUploadedUrl(finalUrl);

      setOriginalImage(finalUrl);
      safeRevoke(previewImage);
      setPreviewImage(null);

      setSnackbarSeverity("success");
      setSnackbarMessage("Image uploaded successfully.");
      setOpenSnackbar(true);
    } catch (err: any) {
      console.error("Upload failed:", err);
      setUploadedUrl("");
      setSnackbarSeverity("error");
      setSnackbarMessage(err?.message || "Image upload failed.");
      setOpenSnackbar(true);
    } finally {
      setUploadingImage(false);
    }
  };

  const handleRevert = () => {
    safeRevoke(previewImage);
    setPreviewImage(null);
    setUploadedUrl("");
  };

  const handleUpdate = async () => {
    setLoading(true);
    const response = await dispatch(
      updateTrendingCollection({
        collection_id: Number(collectionId),
        collection_Description: description,
        collection_image_url: uploadedUrl,
      })
    );
    const payload = (response as any)?.payload;
    if (payload?.status === 200) {
      setMessage(payload.message);
      setLoading(false);
      setSnackbarSeverity("success");
      setSnackbarMessage("Collection updated successfully!");
      setOpenSnackbar(true);
      navigate(`/collections`);
    }
  };
  return (
    <Parentstyle>
      <div className="mb-3">
        <GoBackButton onClick={() => navigate(-1)} />
      </div>
      <Childstyle>
        <Typography variant="h6" fontWeight="medium" className="pb-5">
          Edit Collection
        </Typography>
        <Card
          sx={{
            borderRadius: "12px",
            border: "1px solid #e0e0e0",
            boxShadow: 1,
          }}
        >
          <Grid container direction="column" spacing={2}>
            <Grid
              container
              spacing={0}
              alignItems="center"
              justifyContent="space-between"
              flexWrap="wrap"
              className="max-w-full"
            >
              <Grid size={{ xs: 12, md: 8, lg: 12 }} className="p-5">
                <div className="flex flex-col gap-5">
                  <Typography fontSize={18} fontWeight="medium">
                    Collection Title
                  </Typography>
                  <TextField
                    id="Collection Title"
                    variant="outlined"
                    autoComplete="off"
                    fullWidth
                    size="small"
                    value={collections[0]?.trending_name}
                    disabled={true}
                  />
                  <Typography fontSize={18} fontWeight="medium">
                    Collection Description
                  </Typography>

                  <TextField
                    id="Collection Description"
                    variant="outlined"
                    fullWidth
                    autoComplete="off"
                    size="small"
                    multiline
                    minRows={5}
                    onChange={(e) => setDescription(e.target.value)}
                    value={description}
                  />
                </div>
              </Grid>
            </Grid>
            <div className="flex justify-between">
              <div className="p-5 flex items-center gap-4">
                <ImageSwapPreview
                  originalUrl={
                    originalImage || normalizeImageUrl(uploadedUrl) || undefined
                  }
                  previewUrl={previewImage || undefined}
                  uploading={uploadingImage}
                  onChangeClick={handleClickChange}
                  onRevert={handleRevert}
                />

                <input
                  ref={hiddenFileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleHiddenInputChange}
                  style={{ display: "none" }}
                />

                {!previewImage && !originalImage && (
                  <InputFileUpload onFileSelect={handleFileSelect} />
                )}
              </div>
            </div>
          </Grid>
          <div className="flex justify-between ">
            <div className="flex flex-col p-5 rounded-lg">
              <div className="flex justify-between mb-4">
                <Typography fontSize={18} fontWeight="medium">
                  Participants
                </Typography>
              </div>
              <div className="flex gap-5 flex-wrap">
                {collections.map((shop: any) => (
                  <Participants
                    shopName={shop.shop_name_ref}
                    shopLogo={shop.shop_logo_url_ref}
                    productCount={shop.collection_product_count_ref}
                  />
                ))}
              </div>
            </div>
            <div className="mr-4 pr-2  mt-4 pt-4 flex items-center gap-4">
              <Button
                variant="contained"
                size="large"
                onClick={handleUpdate}
                disabled={loading || !description}
              >
                Submit
              </Button>
              {loading && <CircularProgress size={24} />}
            </div>{" "}
          </div>
        </Card>
      </Childstyle>
      <Snackbar
        open={openSnackbar}
        autoHideDuration={2000}
        onClose={() => setOpenSnackbar(false)}
        anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
      >
        <Alert
          onClose={() => setOpenSnackbar(false)}
          severity={snackbarSeverity}
          sx={{ width: "100%" }}
        >
          {snackbarMessage || message}
        </Alert>
      </Snackbar>
    </Parentstyle>
  );
};

export default EditCollection;
