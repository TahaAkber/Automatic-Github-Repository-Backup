import { Typography } from "@mui/material";
interface ParticipantsProps {
  shopName: string;
  shopLogo: string;
  productCount: string | number;
}
const Participants = ({
  shopName,
  shopLogo,
  productCount,
}: ParticipantsProps) => {
  return (
    <div className="flex items-center gap-2 border-2 p-2 rounded-lg ">
      <img
        src={shopLogo || ""}
        className="rounded-lg w-12 h-12 min-w-12 object-cover"
        onError={(e) => {
          const target = e.target as HTMLImageElement;
          target.src = "https://cdn.shopify.com/s/files/1/0595/2379/2944/files/img_not_found_cercle.jpg?v=1757333158";
        }}
      />
      <div className="">
        <Typography
          fontWeight="medium"
          className="truncate"
          sx={{ maxWidth: "80px" }}
        >
          {shopName}
        </Typography>
        <Typography fontSize={12} color="gray">
          {productCount} Products
        </Typography>
      </div>
    </div>
  );
};

export default Participants;
