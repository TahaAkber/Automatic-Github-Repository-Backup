import { DemoContainer } from "@mui/x-date-pickers/internals/demo";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { DateTimePicker } from "@mui/x-date-pickers/DateTimePicker";
import dayjs, { Dayjs } from "dayjs";
import React from "react";

interface DatePickerProps {
  timeslot: Dayjs | null;
  settimeslot: (val: Dayjs | null) => void;
}

export default function DatePicker({ timeslot, settimeslot }: DatePickerProps) {
  const [now, setNow] = React.useState(dayjs());

  // keep "now" fresh so minDateTime moves forward
  React.useEffect(() => {
    const id = setInterval(() => setNow(dayjs()), 30_000); // every 30s
    return () => clearInterval(id);
  }, []);

  const handleChange = (newValue: Dayjs | null) => {
    if (newValue && dayjs(newValue).isValid()) {
      settimeslot(newValue);
    } else {
      console.warn("Invalid time selected");
      settimeslot(null);
    }
  };

  return (
    <LocalizationProvider dateAdapter={AdapterDayjs}>
      <DemoContainer components={["DateTimePicker"]}>
        <DateTimePicker
          label="Select Date & Time"
          value={timeslot}
          onChange={handleChange}
          disablePast
          minDateTime={now} // blocks anything before current time
          // optional UI tweaks:
          // minutesStep={5}
          // slotProps={{ textField: { size: "small", fullWidth: true } }}
        />
      </DemoContainer>
    </LocalizationProvider>
  );
}
