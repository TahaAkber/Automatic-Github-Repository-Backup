import { Button, Card, Pagination, Tooltip } from "@mui/material";
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router";
import TrendingCollectionTable from "./TrendingCollectionTable";
import Parentstyle from "../Style/Parentstyle";
import Childstyle from "../Style/childstyle";
import { useAppDispatch } from "../hooks/hooks";
import { fetchcollections } from "../../redux/thunks/collectionThunks";
import { useSelector } from "react-redux";
import { RoleLike } from "../functions/Roles";
import { useRolePermissions } from "../../components/functions/useRolePermissions";
import GoBackButton from "../button/Goback";
const TrendingCollections = () => {
  const navigate = useNavigate();
  const [currentpage, setcurrentpage] = useState(1);
  const dispatch = useAppDispatch();
  useEffect(() => {
    dispatch(fetchcollections({ page: currentpage }));
  }, [dispatch]);
  const rawRoles = useSelector((s: any) => s.auth.user?.roles) as
    | RoleLike[]
    | undefined;

  // Permissions
  const { can } = useRolePermissions(rawRoles);

  const { pagination } = useSelector((state: any) => state.collections);

  const handlePageChange = (_: React.ChangeEvent<unknown>, page: number) => {
    setcurrentpage(page);
  };

  console.log("collections", pagination);

  return (
    <Parentstyle>
      <div className="mb-3">
        <GoBackButton onClick={() => navigate(-1)} />
      </div>
      <Childstyle>
        <div className="flex justify-between pb-5">
          <h1 className="text-2xl font-semibold mb-2">Trending Collection</h1>

          {can("collections", "write") ? (
            <div className="mt-5">
              <Button
                variant="contained"
                size="small"
                onClick={() => {
                  navigate("/collections/CreateCollection");
                }}
                sx={{ fontWeight: 300, textTransform: "none" }}
              >
                Create Collection
              </Button>
            </div>
          ) : (
            <div className="mt-5">
              <Tooltip title="You need merchants:write (or global) to change shop status">
                <span>
                  <Button
                    variant="contained"
                    size="small"
                    disabled={true}
                    sx={{ fontWeight: 300, textTransform: "none" }}
                  >
                    Create Collection
                  </Button>
                </span>
              </Tooltip>
            </div>
          )}
        </div>
        <Card>
          <TrendingCollectionTable />

          {pagination?.totalpage > 1 && (
            <div className="m-5 py-1">
              <Pagination
                onChange={handlePageChange}
                count={pagination?.totalpage || 1}
                variant="outlined"
                shape="rounded"
                color="primary"
              />
            </div>
          )}
        </Card>
      </Childstyle>
    </Parentstyle>
  );
};

export default TrendingCollections;
