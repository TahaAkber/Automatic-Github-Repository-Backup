import "./App.css";
import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { RouterProvider } from "react-router-dom";
import { CssVarsProvider } from "@mui/material";
import { Provider } from "react-redux";
import store from "./redux/store/store";
import router from "./routes/routes";
import { persistor } from "./redux/store/store";
import { PersistGate } from "redux-persist/integration/react";

createRoot(document.getElementById("root")!).render(
  <CssVarsProvider>
    <StrictMode>
      <Provider store={store}>
        <PersistGate loading={null} persistor={persistor}>
          <RouterProvider router={router} />
        </PersistGate>
      </Provider>
    </StrictMode>
  </CssVarsProvider>
);
