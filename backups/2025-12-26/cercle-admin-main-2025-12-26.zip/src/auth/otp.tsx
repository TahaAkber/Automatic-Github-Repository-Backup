import React, { useState, useRef, KeyboardEvent, useEffect } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import Logo from "../@core/svg/Logo";
import { ArrowBack, ArrowForward } from "@mui/icons-material";
import { forgotPassword } from "../redux/thunks/authThunks";
import { useAppDispatch } from "../components/hooks/hooks";
import { useSelector } from "react-redux";
import Snackbar from "@mui/material/Snackbar";
import Alert from "@mui/material/Alert";
import { resetAuthStatus } from "../redux/slices/authSlice";

const useImageVariant = (mode: "light" | "dark", light: string, dark: string) =>
    mode === "dark" ? dark : light;

const Illustrations = ({ maskImg }: { maskImg: { src: string } }) => (
    <img
        src={maskImg.src}
        alt="Illustration"
        style={{
            position: "absolute",
            bottom: 0,
            right: 0,
            maxWidth: "300px",
            opacity: 0.5,
        }}
        onError={(e) => {
            const target = e.target as HTMLImageElement;
            target.src = "https://cdn.shopify.com/s/files/1/0595/2379/2944/files/img_not_found_cercle.jpg?v=1757333158";
        }}
    />
);

const DirectionalIcon = ({ isRtl }: { isRtl: boolean }) => {
    return isRtl ? <ArrowForward /> : <ArrowBack fontSize="small" />;
};

type Mode = "light" | "dark";

const OTPVerification = ({ mode }: { mode: Mode }) => {
    const navigate = useNavigate();
    const darkImg = "/images/pages/auth-v1-mask-dark.png";
    const lightImg = "/images/pages/auth-v1-mask-light.png";
    const authBackground = useImageVariant(mode, lightImg, darkImg);
    const isRtl = false;

    const [otp, setOtp] = useState<string[]>(["", "", "", "", "", "", "", ""]);
    const inputRefs = useRef<(HTMLInputElement | null)[]>([]);
    const [email, setEmail] = useState("");
    const location = useLocation();
    const dispatch = useAppDispatch();
    const [openSnackbar, setOpenSnackbar] = useState(false);
    const [snackbarMessage, setSnackbarMessage] = useState("");
    const [snackbarSeverity, setSnackbarSeverity] = useState<"success" | "error">("success");

    const [isVerifying, setIsVerifying] = useState(false);

    const {
        forgotPasswordLoading,
        forgotPasswordError,
        forgotPasswordSuccess,
    } = useSelector((state: any) => state.auth);

    useEffect(() => {
        if (location.state?.email) {
            setEmail(location.state.email);
        }
    }, [location.state]);

    // Reset verification status on mount (we might want to keep forgotPasswordSuccess for a bit if we just arrived)
    // But actually, each page should probably handle its own "success" state transition.
    useEffect(() => {
        // We only want to reset OTP verification status, not necessarily forgotPasswordSuccess yet 
        // because we might want to show "Email sent" if we just came from ForgotPassword.
        // However, the user said they get the message "Email sent successfully" AGAIN or prematurely.
        // Let's reset on mount.
        dispatch(resetAuthStatus());
    }, [dispatch]);

    const handleChange = (index: number, value: string) => {
        // Only allow numbers
        if (value && !/^\d$/.test(value)) return;

        const newOtp = [...otp];
        newOtp[index] = value;
        setOtp(newOtp);

        // Auto-focus next input
        if (value && index < 7) {
            inputRefs.current[index + 1]?.focus();
        }
    };

    const handleKeyDown = (index: number, e: KeyboardEvent<HTMLInputElement>) => {
        // Handle backspace
        if (e.key === "Backspace" && !otp[index] && index > 0) {
            inputRefs.current[index - 1]?.focus();
        }
    };

    const handlePaste = (e: React.ClipboardEvent) => {
        e.preventDefault();
        const pastedData = e.clipboardData.getData("text").slice(0, 8);
        const digits = pastedData.match(/\d/g);

        if (digits) {
            const newOtp = [...otp];
            digits.forEach((digit, index) => {
                if (index < 8) {
                    newOtp[index] = digit;
                }
            });
            setOtp(newOtp);

            // Focus the next empty input or the last one
            const nextEmptyIndex = newOtp.findIndex((val) => !val);
            if (nextEmptyIndex !== -1) {
                inputRefs.current[nextEmptyIndex]?.focus();
            } else {
                inputRefs.current[7]?.focus();
            }
        }
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        const otpValue = otp.join("");

        if (otpValue.length === 8 && email) {
            try {
                setIsVerifying(true);
                setSnackbarMessage("Verifying OTP...");
                setSnackbarSeverity("success");
                setOpenSnackbar(true);
                
                console.log("=== OTP Verification Request ===");
                console.log("Email:", email);
                console.log("OTP Token:", otpValue);
                console.log("API URL:", `${import.meta.env.VITE_APP_URL}/api/auth/reset-password`);
                
                // Call reset-password API with OTP to verify it
                const response = await fetch(`${import.meta.env.VITE_APP_URL}/api/auth/reset-password`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        email: email,
                        otpToken: otpValue,
                        oldPassword: otpValue,
                        newPassword: "" // Empty password for verification only
                    })
                });

                console.log("=== API Response ===");
                console.log("Response Status:", response.status);
                console.log("Response OK:", response.ok);

                const data = await response.json();
                console.log("Response Data:", data);
                console.log("Data Status:", data.status);
                console.log("Data Message:", data.message);

                // Check if OTP verification was successful
                // Backend should return status 200 for valid OTP
                if (response.ok && data.status === 200) {
                    console.log("✅ OTP Verified Successfully");
                    setSnackbarMessage("OTP verified successfully!");
                    setSnackbarSeverity("success");
                    setOpenSnackbar(true);
                    setTimeout(() => {
                        navigate("/auth/changepasswordotp", { state: { email, otp: otpValue } });
                    }, 1000);
                } else {
                    // Invalid OTP or error
                    console.log("❌ OTP Verification Failed");
                    console.log("Error Message:", data.message || "Invalid OTP");
                    setSnackbarMessage(data.message || "Invalid OTP. Please try again.");
                    setSnackbarSeverity("error");
                    setOpenSnackbar(true);
                }
            } catch (error) {
                console.error("=== OTP Verification Error ===");
                console.error("Error:", error);
                setSnackbarMessage("OTP verification failed. Please try again.");
                setSnackbarSeverity("error");
                setOpenSnackbar(true);
            } finally {
                setIsVerifying(false);
            }
        }
    };





    useEffect(() => {
        if (forgotPasswordSuccess) {
            setSnackbarMessage("OTP resent successfully!");
            setSnackbarSeverity("success");
            setOpenSnackbar(true);
        }
    }, [forgotPasswordSuccess]);

    useEffect(() => {
        if (forgotPasswordError) {
            setSnackbarMessage(forgotPasswordError);
            setSnackbarSeverity("error");
            setOpenSnackbar(true);
        }
    }, [forgotPasswordError]);

    const handleResend = async (e: React.FormEvent) => {
        e.preventDefault();

        if (!email || !/\S+@\S+\.\S+/.test(email)) {
            return;
        }

        // Dispatch the forgot password thunk
        dispatch(forgotPassword({ email }));
        console.log("send otp again:", email);
    };

    const handleCloseSnackbar = () => {
        setOpenSnackbar(false);
    };

    const isOtpComplete = otp.every((digit) => digit !== "");

    return (
        <div className="flex flex-col justify-center items-center min-h-screen relative p-6">
            <Card className="flex flex-col sm:w-[450px]">
                <CardContent className="p-6 sm:p-12">
                    <Link to="/" className="flex justify-center items-center mb-6">
                        <Logo />
                    </Link>
                    <Typography variant="h5" className="mb-2">
                        Two Step Verification 💬
                    </Typography>
                    <Typography variant="body2" className="mb-6 text-gray-600">
                        We sent a verification code to your email. Enter the code from the
                        email in the field below.
                    </Typography>

                    <form onSubmit={handleSubmit} className="flex flex-col gap-5">
                        <div className="flex justify-center gap-2 sm:gap-3">
                            {otp.map((digit, index) => (
                                <input
                                    key={index}
                                    ref={(el) => { inputRefs.current[index] = el; }}
                                    type="text"
                                    inputMode="numeric"
                                    maxLength={1}
                                    value={digit}
                                    onChange={(e) => handleChange(index, e.target.value)}
                                    onKeyDown={(e) => handleKeyDown(index, e)}
                                    onPaste={handlePaste}
                                    className="w-8 h-8 sm:w-10 sm:h-10 text-center text-xl font-semibold border-2 border-gray-300 rounded-lg focus:border-indigo-500 focus:outline-none transition-colors"
                                    autoFocus={index === 0}
                                />
                            ))}
                        </div>

                        <Button
                            fullWidth
                            variant="contained"
                            type="submit"
                            disabled={!isOtpComplete || isVerifying}
                            sx={{
                                bgcolor: isOtpComplete ? "#4F46E5" : "#A5B4FC",
                                "&:hover": {
                                    bgcolor: isOtpComplete ? "#4338CA" : "#A5B4FC",
                                },
                            }}
                        >
                            {isVerifying ? "Verifying..." : "Verify OTP"}
                        </Button>

                        <div className="flex justify-center items-center gap-1">
                            <Typography variant="body2" className="text-gray-600">
                                Didn't get the code?
                            </Typography>
                            <Button
                                variant="text"
                                size="small"
                                onClick={handleResend}
                                sx={{
                                    textTransform: "none",
                                    color: "#4F46E5",
                                    "&:hover": {
                                        bgcolor: "transparent",
                                        textDecoration: "underline",
                                    },
                                }}
                            >
                                Resend
                            </Button>
                        </div>

                        <Typography
                            className="flex justify-center items-center"
                            color="primary"
                        >
                            <Link to="/auth/login" className="flex items-center">
                                <DirectionalIcon isRtl={isRtl} />
                                <span className="ms-1">Back to Login</span>
                            </Link>
                        </Typography>
                    </form>
                </CardContent>
            </Card>
            <Illustrations maskImg={{ src: authBackground }} />

            <Snackbar
                open={openSnackbar}
                autoHideDuration={3000}
                onClose={handleCloseSnackbar}
                anchorOrigin={{ vertical: "top", horizontal: "center" }}
            >
                <Alert
                    onClose={handleCloseSnackbar}
                    severity={snackbarSeverity}
                    sx={{ width: "100%" }}
                >
                    {snackbarMessage}
                </Alert>
            </Snackbar>
        </div>
    );
};

export default OTPVerification;