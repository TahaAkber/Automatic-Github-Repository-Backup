import { useState, FormEvent, useEffect } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";

// MUI Imports
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import Typography from "@mui/material/Typography";
import TextField from "@mui/material/TextField";
import IconButton from "@mui/material/IconButton";
import InputAdornment from "@mui/material/InputAdornment";
import Checkbox from "@mui/material/Checkbox";
import Button from "@mui/material/Button";
import FormControlLabel from "@mui/material/FormControlLabel";
import Divider from "@mui/material/Divider";

import VisibilityIcon from "@mui/icons-material/Visibility";
import RemoveRedEyeOutlinedIcon from "@mui/icons-material/RemoveRedEyeOutlined";

import type { Mode } from "../@core/types";
import Logo from "../@core/svg/Logo";
import { useAppDispatch } from "../components/hooks/hooks";
import { resetpassword } from "../redux/thunks/authThunks";
import { useSelector } from "react-redux";
import { resetResetPasswordStatus } from "../redux/slices/ResetpasswordSlice";
import { resetAuthStatus } from "../redux/slices/authSlice";
const Register: React.FC<{ mode: Mode }> = () => {
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const [isOldPasswordShown, setIsOldPasswordShown] = useState(false);
  const [isNewPasswordShown, setIsNewPasswordShown] = useState(false);
  const [isConfirmPasswordShown, setIsConfirmPasswordShown] = useState(false);
  const [oldpassword, setOldPassword] = useState("");
  const [newpassword, setNewPassword] = useState("");
  const [confirmpassword, setConfirmPassword] = useState("");
  const [termsAccepted, setTermsAccepted] = useState(false);
  const [termsError, setTermsError] = useState(false);
  const [passwordMatchError, setPasswordMatchError] = useState(false);
  const [message, setmessage] = useState("");
  const [error, seterror] = useState();

  const handleClickShowOldPassword = () =>
    setIsOldPasswordShown((show) => !show);
  const handleClickShowNewPassword = () =>
    setIsNewPasswordShown((show) => !show);
  const handleClickShowConfirmPassword = () =>
    setIsConfirmPasswordShown((show) => !show);

  const data = useSelector((state: any) => state.authReset);
  const authUser = useSelector((state: any) => state.auth.user);
  const location = useLocation();

  const emailFromState = location.state?.email || authUser?.email;
  const otpFromState = location.state?.otp || "";

  // If we came from OTP, pre-set the "Old Password" to the OTP
  useEffect(() => {
    if (otpFromState) {
      setOldPassword(otpFromState);
    }
  }, [otpFromState]);

  useEffect(() => {
    dispatch(resetResetPasswordStatus());
    // Also reset auth status (forgotPassword/OTP) since we finished that flow
    dispatch(resetAuthStatus());
  }, [dispatch]);

  const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    if (!termsAccepted) {
      setTermsError(true);
      return;
    }

    if (newpassword !== confirmpassword) {
      setPasswordMatchError(true);
      return;
    }

    setPasswordMatchError(false);
    setTermsError(false);

    console.log("Form Data:", {
      oldpassword,
      confirmpassword,
      newpassword,
      termsAccepted,
    });

    await dispatch(
      resetpassword({
        email: emailFromState,
        oldPassword: oldpassword,
        newPassword: newpassword,
        otpToken: otpFromState,
      })
    );

    if (data.status === 200) {
      setmessage(data.message);
      setTimeout(() => {
        navigate("/auth/login");
      }, 500);
    } else if (data.status === 400) {
      seterror(data.message);
    }
  };

  return (
    <div className="flex flex-col justify-center items-center min-h-screen relative p-6">
      <Card className="flex flex-col sm:w-[450px]">
        <CardContent className="p-6 sm:p-12">
          <Link to="/" className="flex justify-center items-start mb-6">
            <Logo />
          </Link>
          <Typography variant="h5">Enter Your Credentials</Typography>
          <div className="flex flex-col gap-5">
            <Typography className="mt-1" variant="body2">
              Make your app management easy and fun!
            </Typography>
            <form
              noValidate
              autoComplete="off"
              onSubmit={handleSubmit}
              className="flex flex-col gap-5"
            >
              <TextField
                autoFocus
                fullWidth
                autoComplete="off"
                label="Old Password"
                size="small"
                type={isOldPasswordShown ? "text" : "password"}
                value={oldpassword}
                onChange={(e) => setOldPassword(e.target.value)}
                InputProps={{
                  endAdornment: (
                    <InputAdornment position="end">
                      <IconButton
                        size="small"
                        edge="end"
                        onClick={handleClickShowOldPassword}
                        onMouseDown={(e) => e.preventDefault()}
                      >
                        {isOldPasswordShown ? (
                          <RemoveRedEyeOutlinedIcon />
                        ) : (
                          <VisibilityIcon />
                        )}
                      </IconButton>
                    </InputAdornment>
                  ),
                }}
              />
              <TextField
                fullWidth
                label="New Password"
                size="small"
                autoComplete="off"
                type={isNewPasswordShown ? "text" : "password"}
                value={newpassword}
                onChange={(e) => setNewPassword(e.target.value)}
                InputProps={{
                  endAdornment: (
                    <InputAdornment position="end">
                      <IconButton
                        size="small"
                        edge="end"
                        onClick={handleClickShowNewPassword}
                        onMouseDown={(e) => e.preventDefault()}
                      >
                        {isNewPasswordShown ? (
                          <RemoveRedEyeOutlinedIcon />
                        ) : (
                          <VisibilityIcon />
                        )}
                      </IconButton>
                    </InputAdornment>
                  ),
                }}
              />
              <TextField
                fullWidth
                label="Confirm Password"
                size="small"
                autoComplete="off"
                type={isConfirmPasswordShown ? "text" : "password"}
                value={confirmpassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                InputProps={{
                  endAdornment: (
                    <InputAdornment position="end">
                      <IconButton
                        size="small"
                        edge="end"
                        onClick={handleClickShowConfirmPassword}
                        onMouseDown={(e) => e.preventDefault()}
                      >
                        {isConfirmPasswordShown ? (
                          <RemoveRedEyeOutlinedIcon />
                        ) : (
                          <VisibilityIcon />
                        )}
                      </IconButton>
                    </InputAdornment>
                  ),
                }}
              />
              {passwordMatchError && (
                <Typography variant="caption" color="error">
                  New password and confirm password must match.
                </Typography>
              )}
              <FormControlLabel
                control={
                  <Checkbox
                    checked={termsAccepted}
                    onChange={(e) => {
                      setTermsAccepted(e.target.checked);
                      if (e.target.checked) {
                        setTermsError(false);
                      }
                    }}
                  />
                }
                label={
                  <>
                    <span>I agree to </span>
                    <Link
                      className="text-primary text-sm"
                      to="/login"
                      onClick={(e) => e.preventDefault()}
                    >
                      privacy policy & terms
                    </Link>
                  </>
                }
              />
              {termsError && (
                <Typography variant="caption" color="error">
                  You must accept the terms and conditions.
                </Typography>
              )}
              <Button fullWidth variant="contained" type="submit">
                Reset Password
              </Button>

              {/* Handle Success or Error */}
              {message && (
                <Typography variant="body2" color="success">
                  {message}
                </Typography>
              )}

              {error && (
                <Typography variant="body2" color="error">
                  {error}
                </Typography>
              )}

              <div className="flex justify-center items-center flex-wrap gap-2">
                <Typography>Already have an account?</Typography>
                <Typography component={Link} to="/auth/login" color="primary">
                  Sign in instead
                </Typography>
              </div>
              <Divider></Divider>
            </form>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Register;
