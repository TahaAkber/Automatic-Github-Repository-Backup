import { useState, FormEvent, useEffect } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";

// MUI Imports
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import Typography from "@mui/material/Typography";
import TextField from "@mui/material/TextField";
import IconButton from "@mui/material/IconButton";
import InputAdornment from "@mui/material/InputAdornment";
import Checkbox from "@mui/material/Checkbox";
import Button from "@mui/material/Button";
import FormControlLabel from "@mui/material/FormControlLabel";
import Divider from "@mui/material/Divider";
import Snackbar from "@mui/material/Snackbar";
import Alert from "@mui/material/Alert";

import VisibilityIcon from "@mui/icons-material/Visibility";
import RemoveRedEyeOutlinedIcon from "@mui/icons-material/RemoveRedEyeOutlined";

import type { Mode } from "../@core/types";
import Logo from "../@core/svg/Logo";
import { useAppDispatch } from "../components/hooks/hooks";
import { resetpassword } from "../redux/thunks/authThunks";
import { useSelector } from "react-redux";
import { resetResetPasswordStatus } from "../redux/slices/ResetpasswordSlice";
import { resetAuthStatus } from "../redux/slices/authSlice";

const ChangePasswordOtp: React.FC<{ mode: Mode }> = () => {
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const [isNewPasswordShown, setIsNewPasswordShown] = useState(false);
  const [isConfirmPasswordShown, setIsConfirmPasswordShown] = useState(false);
  const [newpassword, setNewPassword] = useState("");
  const [confirmpassword, setConfirmPassword] = useState("");
  const [termsAccepted, setTermsAccepted] = useState(false);
  const [termsError, setTermsError] = useState(false);
  const [passwordMatchError, setPasswordMatchError] = useState(false);
  const [openSnackbar, setOpenSnackbar] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState("");
  const [snackbarSeverity, setSnackbarSeverity] = useState<"success" | "error">("success");

  const handleClickShowNewPassword = () =>
    setIsNewPasswordShown((show) => !show);
  const handleClickShowConfirmPassword = () =>
    setIsConfirmPasswordShown((show) => !show);

  const data = useSelector((state: any) => state.authReset);
  const authUser = useSelector((state: any) => state.auth.user);
  const location = useLocation();

  const emailFromState = location.state?.email || authUser?.email;
  const otpFromState = location.state?.otp || "";

  useEffect(() => {
    // Redirect if no OTP in state
    if (!otpFromState) {
      navigate("/auth/forgot-password");
    }
  }, [otpFromState, navigate]);

  useEffect(() => {
    dispatch(resetResetPasswordStatus());
    dispatch(resetAuthStatus());
  }, [dispatch]);

  // Handle password reset response
  useEffect(() => {
    if (data.status === 200 && data.message) {
      setSnackbarMessage(data.message || "Password reset successfully!");
      setSnackbarSeverity("success");
      setOpenSnackbar(true);
      setTimeout(() => {
        navigate("/auth/login");
      }, 1500);
    } else if (data.error) {
      setSnackbarMessage(data.error);
      setSnackbarSeverity("error");
      setOpenSnackbar(true);
    }
  }, [data.status, data.message, data.error, navigate]);

  const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    if (!termsAccepted) {
      setTermsError(true);
      return;
    }

    if (newpassword !== confirmpassword) {
      setPasswordMatchError(true);
      return;
    }

    if (newpassword.length < 6) {
      setSnackbarMessage("Password must be at least 6 characters long");
      setSnackbarSeverity("error");
      setOpenSnackbar(true);
      return;
    }

    setPasswordMatchError(false);
    setTermsError(false);

    console.log("=== Password Reset Request ===");
    console.log("Email:", emailFromState);
    console.log("OTP Token:", otpFromState);
    console.log("New Password Length:", newpassword.length);

    dispatch(
      resetpassword({
        email: emailFromState,
        oldPassword: otpFromState,
        newPassword: newpassword,
        otpToken: otpFromState,
      })
    );
  };

  const handleCloseSnackbar = () => {
    setOpenSnackbar(false);
  };

  return (
    <div className="flex flex-col justify-center items-center min-h-screen relative p-6">
      <Card className="flex flex-col sm:w-[450px]">
        <CardContent className="p-6 sm:p-12">
          <Link to="/" className="flex justify-center items-start mb-6">
            <Logo />
          </Link>
          <Typography variant="h5">Reset Your Password</Typography>
          <div className="flex flex-col gap-5">
            <Typography className="mt-1" variant="body2">
              Enter your new password below
            </Typography>
            <form
              noValidate
              autoComplete="off"
              onSubmit={handleSubmit}
              className="flex flex-col gap-5"
            >
              <TextField
                autoFocus
                fullWidth
                label="New Password"
                size="small"
                autoComplete="off"
                type={isNewPasswordShown ? "text" : "password"}
                value={newpassword}
                onChange={(e) => setNewPassword(e.target.value)}
                InputProps={{
                  endAdornment: (
                    <InputAdornment position="end">
                      <IconButton
                        size="small"
                        edge="end"
                        onClick={handleClickShowNewPassword}
                        onMouseDown={(e) => e.preventDefault()}
                      >
                        {isNewPasswordShown ? (
                          <RemoveRedEyeOutlinedIcon />
                        ) : (
                          <VisibilityIcon />
                        )}
                      </IconButton>
                    </InputAdornment>
                  ),
                }}
              />
              <TextField
                fullWidth
                label="Confirm Password"
                size="small"
                autoComplete="off"
                type={isConfirmPasswordShown ? "text" : "password"}
                value={confirmpassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                InputProps={{
                  endAdornment: (
                    <InputAdornment position="end">
                      <IconButton
                        size="small"
                        edge="end"
                        onClick={handleClickShowConfirmPassword}
                        onMouseDown={(e) => e.preventDefault()}
                      >
                        {isConfirmPasswordShown ? (
                          <RemoveRedEyeOutlinedIcon />
                        ) : (
                          <VisibilityIcon />
                        )}
                      </IconButton>
                    </InputAdornment>
                  ),
                }}
              />
              {passwordMatchError && (
                <Typography variant="caption" color="error">
                  New password and confirm password must match.
                </Typography>
              )}
              <FormControlLabel
                control={
                  <Checkbox
                    checked={termsAccepted}
                    onChange={(e) => {
                      setTermsAccepted(e.target.checked);
                      if (e.target.checked) {
                        setTermsError(false);
                      }
                    }}
                  />
                }
                label={
                  <>
                    <span>I agree to </span>
                    <Link
                      className="text-primary text-sm"
                      to="/login"
                      onClick={(e) => e.preventDefault()}
                    >
                      privacy policy & terms
                    </Link>
                  </>
                }
              />
              {termsError && (
                <Typography variant="caption" color="error">
                  You must accept the terms and conditions.
                </Typography>
              )}
              <Button fullWidth variant="contained" type="submit" disabled={data.loading}>
                {data.loading ? "Resetting Password..." : "Reset Password"}
              </Button>

              <div className="flex justify-center items-center flex-wrap gap-2">
                <Typography>Already have an account?</Typography>
                <Typography component={Link} to="/auth/login" color="primary">
                  Sign in instead
                </Typography>
              </div>
              <Divider></Divider>
            </form>
          </div>
        </CardContent>
      </Card>

      <Snackbar
        open={openSnackbar}
        autoHideDuration={3000}
        onClose={handleCloseSnackbar}
        anchorOrigin={{ vertical: "top", horizontal: "center" }}
      >
        <Alert
          onClose={handleCloseSnackbar}
          severity={snackbarSeverity}
          sx={{ width: "100%" }}
        >
          {snackbarMessage}
        </Alert>
      </Snackbar>
    </div>
  );
};

export default ChangePasswordOtp;
