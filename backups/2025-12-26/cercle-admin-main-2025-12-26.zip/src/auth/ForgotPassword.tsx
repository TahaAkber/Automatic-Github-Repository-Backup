import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAppDispatch } from "../components/hooks/hooks";
import { useSelector } from "react-redux";
import { forgotPassword } from "../redux/thunks/authThunks";
import { resetAuthStatus } from "../redux/slices/authSlice";

// MUI Imports
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import Typography from "@mui/material/Typography";
import TextField from "@mui/material/TextField";
import Button from "@mui/material/Button";
import Snackbar from "@mui/material/Snackbar";
import Alert from "@mui/material/Alert";
import Logo from "../@core/svg/Logo";
import { ArrowBack, ArrowForward } from "@mui/icons-material";

// Dummy theme and component mocks
const useImageVariant = (mode: "light" | "dark", light: string, dark: string) =>
  mode === "dark" ? dark : light;

const Illustrations = ({ maskImg }: { maskImg: { src: string } }) => (
  <img
    src={maskImg.src}
    alt="Illustration"
    style={{
      position: "absolute",
      bottom: 0,
      right: 0,
      maxWidth: "300px",
      opacity: 0.5,
    }}
    onError={(e) => {
      const target = e.target as HTMLImageElement;
      target.src = "https://cdn.shopify.com/s/files/1/0595/2379/2944/files/img_not_found_cercle.jpg?v=1757333158";
    }}
  />
);

const DirectionalIcon = ({ isRtl }: { isRtl: boolean }) => {
  return isRtl ? <ArrowForward /> : <ArrowBack fontSize="small" />;
};

const Form = ({ children, ...props }: React.ComponentProps<"form">) => (
  <form {...props}>{children}</form>
);

type Mode = "light" | "dark";

const ForgotPassword = ({ mode }: { mode: Mode }) => {
  const navigate = useNavigate();
  const dispatch = useAppDispatch();
  const darkImg = "/images/pages/auth-v1-mask-dark.png";
  const lightImg = "/images/pages/auth-v1-mask-light.png";
  const authBackground = useImageVariant(mode, lightImg, darkImg);

  const isRtl = false;
  const [email, setEmail] = useState("");
  const [openSnackbar, setOpenSnackbar] = useState(false);

  // Get Redux state
  const { forgotPasswordLoading, forgotPasswordError, forgotPasswordSuccess } =
    useSelector((state: any) => state.auth);

  // Handle success - navigate to OTP screen
  useEffect(() => {
    if (forgotPasswordSuccess) {
      setOpenSnackbar(true);
      // Navigate to OTP screen after showing success message
      setTimeout(() => {
        navigate("/auth/otp", { state: { email } });
      }, 1500);
    }
  }, [forgotPasswordSuccess, navigate, email]);

  // Reset status on mount
  useEffect(() => {
    dispatch(resetAuthStatus());
  }, [dispatch]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!email || !/\S+@\S+\.\S+/.test(email)) {
      return;
    }

    // Dispatch the forgot password thunk
    dispatch(forgotPassword({ email }));
  };

  const handleCloseSnackbar = () => {
    setOpenSnackbar(false);
  };

  return (
    <div className="flex flex-col justify-center items-center min-h-screen relative p-6">
      <Card className="flex flex-col sm:w-[450px]">
        <CardContent className="p-6 sm:p-12">
          <Link to="/" className="flex justify-center items-center mb-6">
            <Logo />
          </Link>
          <Typography variant="h5">Forgot Password 🔒</Typography>
          <div className="flex flex-col gap-5">
            <Typography className="mt-1" variant="body2">
              Enter your email and we&apos;ll send you instructions to reset
              your password
            </Typography>
            <Form noValidate autoComplete="off" className="flex flex-col gap-5" onSubmit={handleSubmit}>
              <TextField
                autoFocus
                fullWidth
                label="Email"
                type="email"
                autoComplete="off"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                error={!!forgotPasswordError}
                helperText={forgotPasswordError}
              />
              <Button
                fullWidth
                variant="contained"
                type="submit"
                disabled={forgotPasswordLoading || !email}
              >
                {forgotPasswordLoading ? "Sending..." : "Send reset link"}
              </Button>
              <Typography
                className="flex justify-center items-center"
                color="primary"
              >
                <Link to="/auth/login" className="flex items-center">
                  <DirectionalIcon isRtl={isRtl} />
                  <span className="ms-1">Back to Login</span>
                </Link>
              </Typography>
            </Form>
          </div>
        </CardContent>
      </Card>
      <Illustrations maskImg={{ src: authBackground }} />

      {/* Success Snackbar */}
      <Snackbar
        open={openSnackbar}
        autoHideDuration={1500}
        onClose={handleCloseSnackbar}
        anchorOrigin={{ vertical: "top", horizontal: "center" }}
      >
        <Alert
          onClose={handleCloseSnackbar}
          severity="success"
          sx={{ width: "100%" }}
        >
          Email has been successfully sent! Redirecting to OTP screen...
        </Alert>
      </Snackbar>
    </div>
  );
};

export default ForgotPassword;

