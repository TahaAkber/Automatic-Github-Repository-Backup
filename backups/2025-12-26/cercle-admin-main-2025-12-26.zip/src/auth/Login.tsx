import { useState, FormEvent } from "react";
import { Link, useNavigate } from "react-router-dom";
import themeConfig from "../configs/themeConfig";
import Logo from "../@core/svg/Logo";
import { useAppDispatch } from "../components/hooks/hooks";
import { loginUser } from "../redux/thunks/authThunks";
import VisibilityOutlinedIcon from "@mui/icons-material/VisibilityOutlined";
import VisibilityOffOutlinedIcon from "@mui/icons-material/VisibilityOffOutlined";
import { AuthResponse } from "src/types/pages/types";

const Login: React.FC<{ mode: any }> = () => {
  const [isPasswordShown, setIsPasswordShown] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [rememberMe, setRememberMe] = useState(false);
  const [loading, setLoading] = useState(false);
  const [loginError, setLoginError] = useState<string | null>(null);

  const dispatch = useAppDispatch();
  const navigate = useNavigate();

  const handleClickShowPassword = () => setIsPasswordShown(!isPasswordShown);
  const validateEmail = (email: string) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const handleSubmit = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setLoginError(null);

    if (!email || !password) {
      setLoginError("Email and password are required.");
      return;
    }
    if (!validateEmail(email)) {
      setLoginError("Please enter a valid email address.");
      return;
    }
    if (password.length < 2) {
      setLoginError("Password must be at least 2 characters.");
      return;
    }

    setLoading(true);
    try {
      const action = await dispatch(loginUser({ email, password }));
      const payload = action.payload as AuthResponse;

      if (
        payload.status === 200 &&
        payload.isValidToken &&
        payload.user.onboarded
      ) {
        setTimeout(() => {
          setLoading(false);
          navigate("/");
        }, 800);
      } else if (payload.status === 200 && payload.user.onboarded === false) {
        setLoading(false);
        navigate("/auth/changepassword");
      } else {
        setTimeout(() => {
          setLoginError("Invalid email or password.");
          setLoading(false);
        }, 500);
      }
    } catch (err) {
      setLoginError("Login failed. Please try again.");
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center px-4">
      <div className="w-full max-w-md rounded-2xl border border-gray-200 bg-white shadow-lg">
        <div className="p-6 sm:p-10">
          <Link to="/" className="mb-6 flex items-center justify-center">
            <div className="flex items-center gap-2">
              <Logo />
            </div>
          </Link>

          <div className="mb-6 text-center">
            <h1 className="text-xl font-semibold">
              {`Welcome to ${themeConfig.templateName}! 👋🏻`}
            </h1>
            <p className="mt-3 text-sm text-gray-600">
              Please sign in to your account and continue your journey.
            </p>
          </div>

          {loginError && (
            <div className="mb-4 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
              {loginError}
            </div>
          )}

          <form
            className="flex flex-col gap-4"
            noValidate
            onSubmit={handleSubmit}
          >
            {/* Email */}
            <div className="flex flex-col gap-1.5">
              <label
                htmlFor="email"
                className="text-sm font-medium text-gray-800"
              >
                Email
              </label>
              <input
                id="email"
                type="email"
                placeholder="you@email.com"
                className={`w-full rounded-lg border px-3 py-2 text-sm outline-none transition
                  ${loginError
                    ? "border-red-300 focus:border-red-400"
                    : "border-gray-300 focus:border-indigo-500"
                  }`}
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                disabled={loading}
                autoComplete="email"
              />
            </div>

            {/* Password */}
            <div className="flex flex-col gap-1.5">
              <label
                htmlFor="password"
                className="text-sm font-medium text-gray-800"
              >
                Password
              </label>
              <div className="relative">
                <input
                  id="password"
                  type={isPasswordShown ? "text" : "password"}
                  placeholder="••••••••"
                  className={`w-full rounded-lg border px-3 py-2 pr-10 text-sm outline-none transition
                    ${loginError
                      ? "border-red-300 focus:border-red-400"
                      : "border-gray-300 focus:border-indigo-500"
                    }`}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  disabled={loading}
                  autoComplete="current-password"
                />
                <button
                  type="button"
                  onClick={handleClickShowPassword}
                  className="absolute right-2 top-1/2 -translate-y-1/2 rounded-md p-1 text-gray-500 hover:bg-gray-100"
                  aria-label={
                    isPasswordShown ? "Hide password" : "Show password"
                  }
                >
                  <button
                    type="button"
                    onClick={handleClickShowPassword}
                    className="absolute right-2 top-1/2 -translate-y-1/2 rounded-md p-1 text-gray-500 hover:bg-gray-100"
                    aria-label={
                      isPasswordShown ? "Hide password" : "Show password"
                    }
                  >
                    {isPasswordShown ? (
                      <VisibilityOffOutlinedIcon fontSize="small" />
                    ) : (
                      <VisibilityOutlinedIcon fontSize="small" />
                    )}
                  </button>
                </button>
              </div>
              {/* Optional field-level helper text */}
              {/* {loginError && <p className="text-xs text-red-600">Password must be at least 2 characters.</p>} */}
            </div>

            {/* Remember + Forgot */}
            <div className="mt-1 flex flex-wrap items-center justify-between gap-2">
              <label className="inline-flex cursor-pointer items-center gap-2 text-sm text-gray-700">
                <input
                  type="checkbox"
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                  className="h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                />
                Remember me
              </label>

              <Link
                to="/auth/forgot-password"
                className="text-xs font-medium text-indigo-600 hover:underline"
              >
                Forgot password?
              </Link>
            </div>

            {/* Submit */}
            <button
              type="submit"
              disabled={loading}
              className={`relative mt-2 inline-flex w-full items-center justify-center rounded-lg px-4 py-2.5 text-sm font-semibold text-white transition
                ${loading
                  ? "bg-indigo-400"
                  : "bg-indigo-600 hover:bg-indigo-700"
                }`}
            >
              {loading ? (
                <>
                  <svg
                    className="mr-2 h-4 w-4 animate-spin"
                    viewBox="0 0 24 24"
                  >
                    <circle
                      className="opacity-25"
                      cx="12"
                      cy="12"
                      r="10"
                      stroke="white"
                      strokeWidth="4"
                    ></circle>
                    <path
                      className="opacity-75"
                      fill="white"
                      d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"
                    ></path>
                  </svg>
                  Processing...
                </>
              ) : (
                "Log In"
              )}
            </button>

            <div className="my-4 h-px w-full bg-gray-200" />

            {/* If you want register link later */}
            {/* <div className="flex items-center justify-center gap-2 text-sm">
              <span className="text-gray-700">New to our platform?</span>
              <Link to="/auth/register" className="font-medium text-indigo-600 hover:underline">
                Create an account
              </Link>
            </div> */}
          </form>
        </div>
      </div>
    </div>
  );
};

export default Login;
