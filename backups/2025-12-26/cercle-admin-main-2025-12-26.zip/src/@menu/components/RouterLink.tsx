// React Imports
import { forwardRef } from 'react'

// Type Imports
import type { ChildrenType } from '../types'

type RouterLinkProps = any &
  Partial<ChildrenType> & {
    className?: string
  }

export const RouterLink = forwardRef((props: RouterLinkProps, ref: any) => {
  // Props
  const { href, className, ...other } = props

  return (
    <a ref={ref} href={href} className={className} {...other}>
      {props.children}
    </a>
  )
})
