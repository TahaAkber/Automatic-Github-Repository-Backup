// Common classes for menu components
export const menuClasses = {
  root: "ts-menu-root",
  menuSectionRoot: "ts-menusection-root",
  menuItemRoot: "ts-menuitem-root",
  subMenuRoot: "ts-submenu-root",
  button: "ts-menu-button",
  prefix: "ts-menu-prefix",
  suffix: "ts-menu-suffix",
  label: "ts-menu-label",
  icon: "ts-menu-icon",
  menuSectionWrapper: "ts-menu-section-wrapper",
  menuSectionContent: "ts-menu-section-content",
  menuSectionLabel: "ts-menu-section-label",
  subMenuContent: "ts-submenu-content",
  subMenuExpandIcon: "ts-submenu-expand-icon",
  disabled: "ts-disabled",
  active: "ts-active",
  open: "ts-open",
};

// Classes for vertical navigation menu
export const verticalNavClasses = {
  root: "ts-vertical-nav-root",
  container: "ts-vertical-nav-container",
  bgColorContainer: "ts-vertical-nav-bg-color-container",
  header: "ts-vertical-nav-header flex items-center justify-between p-4",
  backdrop:
    "ts-vertical-nav-backdrop fixed inset-0 bg-black bg-opacity-50 z-40",
  toggled:
    "ts-toggled transform translate-x-0 transition-transform duration-300 ease-in-out",
  breakpointReached: "ts-breakpoint-reached md:static md:translate-x-0",
};
