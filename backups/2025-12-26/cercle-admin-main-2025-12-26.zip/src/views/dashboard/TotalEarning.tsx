// MUI Imports
import {
  Card,
  CardHeader,
  CardContent,
  Avatar,
  Typography,
  LinearProgress,
  Box,
  Skeleton,
} from "@mui/material";

import OptionMenu from "../../@core/components/option-menu";
import formatK from "../../../src/utils/formatCurrency";

interface Props {
  shop_products: any[];
  totalAmountInPKR: number;
  loading: boolean;
}

const TotalEarning = ({ shop_products, loading, totalAmountInPKR }: Props) => {
  return (
    <Card style={{ minHeight: "530px" }}>
      <CardHeader
        title="Last 30 Days Earning"
        action={
          <OptionMenu
            iconClassName="text-textPrimary"
            options={["Last 28 Days", "Last Month", "Last Year"]}
          />
        }
      />

      <CardContent>
        {/* Summary Header */}
        <Box display="flex" flexDirection="column" gap={4} pb={2}>
          {loading ? (
            <>
              <Skeleton variant="text" width={120} height={36} />
              <Skeleton variant="text" width={160} height={20} />
            </>
          ) : (
            <>
              <Box display="flex" alignItems="center" gap={2}>
                <Typography
                  variant="h4"
                  style={{ fontFamily: '"Nunito Sans", sans-serif' }}
                >
                  {formatK(totalAmountInPKR)}{" "}
                  <Typography
                    variant="caption"
                    style={{
                      fontFamily: '"Nunito Sans", sans-serif',
                      fontSize: "1.4rem",
                      opacity: 1.0,
                    }}
                  >
                    PKR
                  </Typography>
                </Typography>
              </Box>
              <Typography
                variant="body2"
                color="text.secondary"
                style={{
                  fontFamily: '"Nunito Sans", sans-serif',
                  fontWeight: 600,
                }}
              >
                Top Selling Products by Shop
              </Typography>
            </>
          )}
        </Box>

        {/* List - mobile vertical scroller */}
        <div className="max-h-[65vh] overflow-y-auto pr-2 -mr-2 overscroll-contain md:max-h-none md:overflow-visible md:pr-0 md:mr-0">
          <Box display="flex" flexDirection="column" gap={2}>
            {loading
              ? Array.from({ length: 5 }).map((_, index) => (
                  <Box
                    key={index}
                    display="flex"
                    gap={2}
                    alignItems="flex-start"
                    justifyContent="space-between"
                  >
                    {/* Avatar skeleton */}
                    <Skeleton
                      variant="rounded"
                      width={40}
                      height={40}
                      animation="wave"
                    />

                    {/* Shop name + products skeleton */}
                    <Box
                      display="flex"
                      flexDirection="column"
                      justifyContent="center"
                      flex={1}
                      gap={0.5}
                    >
                      <Skeleton width="40%" height={20} animation="wave" />
                      <Skeleton width="80%" height={18} animation="wave" />
                    </Box>

                    {/* Amount + progress skeleton */}
                    <Box
                      display="flex"
                      flexDirection="column"
                      alignItems="flex-end"
                      width="150px"
                      gap={1}
                    >
                      <Skeleton width="50%" height={20} animation="wave" />
                      <Skeleton
                        variant="rectangular"
                        width="100%"
                        height={6}
                        animation="wave"
                        sx={{ borderRadius: 5 }}
                      />
                    </Box>
                  </Box>
                ))
              : shop_products?.slice(0, 5).map((item, index) => (
                  <Box
                    key={index}
                    display="flex"
                    gap={2}
                    alignItems="flex-start"
                    justifyContent="space-between"
                  >
                    <Avatar src={item.shop_logo_url} variant="rounded" />

                    <Box
                      display="flex"
                      flexDirection="column"
                      justifyContent="center"
                      flex={1}
                      gap={0}
                    >
                      <Typography
                        fontWeight={500}
                        color="text.primary"
                        style={{ fontFamily: '"Nunito Sans", sans-serif' }}
                      >
                        {item.shop_name}
                      </Typography>
                      <Typography
                        variant="subtitle2"
                        color="text.secondary"
                        style={{ fontFamily: '"Nunito Sans", sans-serif' }}
                      >
                        {item.top_products
                          .map((p: any) => p.product_name)
                          .join(", ")}
                      </Typography>
                    </Box>

                    <Box
                      display="flex"
                      flexDirection="column"
                      alignItems="flex-end"
                      width="150px"
                      gap={1}
                    >
                      <Typography
                        fontWeight={500}
                        color="text.primary"
                        style={{ fontFamily: '"Nunito Sans", sans-serif' }}
                      >
                        {formatK(item.total_sales_amount)}
                      </Typography>
                      <LinearProgress
                        variant="determinate"
                        value={100}
                        color={item.color || "inherit"}
                        sx={{ width: "100%", height: 3, borderRadius: 5 }}
                      />
                    </Box>
                  </Box>
                ))}
          </Box>
        </div>
      </CardContent>
    </Card>
  );
};

export default TotalEarning;
