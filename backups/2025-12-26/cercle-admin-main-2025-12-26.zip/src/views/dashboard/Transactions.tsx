// MUI Imports
import Card from "@mui/material/Card";
import CardHeader from "@mui/material/CardHeader";
import CardContent from "@mui/material/CardContent";
import Typography from "@mui/material/Typography";
import Grid from "@mui/material/Grid";
import Skeleton from "@mui/material/Skeleton";

// Type Imports
import type { ThemeColor } from "../../@core/types";

// Components Imports
import OptionMenu from "../../@core/components/option-menu";
import CustomAvatar from "../../@core/components/mui/Avatar";
import formatK from "../../../src/utils/formatCurrency";

// ====== OPTIONAL: centralize your custom hex colors here ======
const COLORS = {
  orderAmountBg: "#EE1F23", // Dodger Blue
  orderAmountFg: "#FFFFFF",

  usersBg: "#23B477", // Emerald
  usersFg: "#0B1B13",

  productsBg: "#F57F21", // Amber
  productsFg: "#1C1400",

  revenueBg: "#2E7DC1", // Sky
  revenueFg: "#03141A",

  adminBg: "#FFDE59",
  adminfg: "#1C1B1A",

  shopCountBg: "#8D6F64",
  shopCountfg: "#1C1B1A"
};

type DataType = {
  icon: string;
  stats: string | number;
  title: string;
  // keep original color for backward-compatibility if you want to still pass ThemeColor
  color?: ThemeColor;
  isCurrency?: boolean;

  // new custom color fields (hex or any valid CSS color)
  bg?: string; // background
  fg?: string; // foreground (icon/text)
};

const Transactions = ({ transactions, loading }: any) => {
  const orderAmountPKR = Number(transactions?.orderAmountPKR ?? 0);
  const cercleRevenue = Number(transactions?.cercleRevenue ?? 0);
  const userCount = Number(transactions?.userCount ?? 0);
  const productCount = Number(transactions?.productCount ?? 0);
  const adminCount = Number(transactions?.adminCount ?? 0);
  const shopCount = Number(transactions?.shopCount ?? 0);

  const data: DataType[] = [
    {
      stats: formatK(orderAmountPKR),
      title: "Total Order Amount",
      icon: "ri-pie-chart-2-line",
      isCurrency: true,
      bg: COLORS.orderAmountBg,
      fg: COLORS.orderAmountFg,
    },
    {
      stats: formatK(userCount),
      title: "Total Users",
      icon: "ri-group-line",
      isCurrency: false,
      bg: COLORS.usersBg,
      fg: COLORS.usersFg,
    },
    {
      stats: formatK(productCount),
      title: "Total Products",
      icon: "ri-macbook-line",
      isCurrency: false,
      bg: COLORS.productsBg,
      fg: COLORS.productsFg,
    },
    {
      stats: formatK(cercleRevenue),
      title: "Total Cercle Revenue",
      icon: "ri-money-dollar-circle-line",
      isCurrency: true,
      bg: COLORS.revenueBg,
      fg: COLORS.revenueFg,
    },
    {
      stats: formatK(adminCount),
      title: "Admin Users",
      icon: "ri-money-dollar-circle-line",
      isCurrency: false,
      bg: COLORS.adminBg,
      fg: COLORS.adminBg,
    },
    {
      stats: formatK(shopCount),
      title: "Total Shops",
      icon: "ri-money-dollar-circle-line",
      isCurrency: false,
      bg: COLORS.shopCountBg,
      fg: COLORS.shopCountfg,
    },
  ];

  return (
    <Card className="bs-full " sx={{
      display: "flex",
      flexDirection: "column",
      justifyContent: "space-between",
      minHeight: { xs: "auto", sm: 256 }, // auto on mobile, fixed on desktop
      p: { xs: 2, sm: 1.1 },
    }}>
      <CardHeader
        title="Transactions"
        action={
          <OptionMenu
            iconClassName="text-textPrimary"
            options={["Refresh", "Share", "Update"]}
          />
        }
        subheader={
          <p
            className="mbs-3"
            style={{ fontFamily: '"Nunito Sans", sans-serif' }}
          >
            <span className="font-medium text-textPrimary">
              Commulative Transactions
            </span>
          </p>
        }
      />

      <CardContent className="!pbs-5">
        <Grid container spacing={2}>
          {loading
            ? // 🔹 Skeleton Loader
            Array.from({ length: 4 }).map((_, index) => (
              <Grid size={{ xs: 12, md: 6 }} key={index}>
                <div className="flex items-center gap-3">
                  <Skeleton
                    variant="rounded"
                    width={40}
                    height={40}
                    animation="wave"
                  />
                  <div style={{ width: "100%" }}>
                    <Skeleton width="40%" height={20} animation="wave" />
                    <Skeleton width="60%" height={28} animation="wave" />
                  </div>
                </div>
              </Grid>
            ))
            : // 🔹 Actual Data
            data.map((item, index) => (
              <Grid size={{ xs: 12, sm: 6, md: 4 }} key={index}>
                <div className="flex items-center gap-3">
                  <CustomAvatar
                    variant="rounded"
                    className="shadow-xs"
                    // Override avatar colors with your hex codes
                    sx={{
                      bgcolor: item.bg ?? "primary.main",
                      color: item.fg ?? "common.white",
                      width: 40,
                      height: 40,
                    }}
                  >
                    <i className={item.icon}></i>
                  </CustomAvatar>

                  <div>
                    <Typography
                      style={{ fontFamily: '"Nunito Sans", sans-serif' }}
                    >
                      {item.title}
                    </Typography>

                    <div
                      style={{
                        display: "flex",
                        alignItems: "baseline",
                        gap: "4px",
                      }}
                    >
                      <Typography
                        variant="h5"
                        style={{
                          fontFamily: '"Nunito Sans", sans-serif',
                        }}
                      >
                        {item.stats}
                      </Typography>

                      {item.isCurrency && (
                        <Typography
                          variant="caption"
                          style={{
                            fontFamily: '"Nunito Sans", sans-serif',
                            fontSize: "0.8rem",
                            opacity: 1.0,
                          }}
                        >
                          PKR
                        </Typography>
                      )}
                    </div>
                  </div>
                </div>
              </Grid>
            ))}
        </Grid>
      </CardContent>
    </Card>
  );
};

export default Transactions;
