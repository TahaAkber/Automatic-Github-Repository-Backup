import React, { Suspense, useMemo, useRef, useEffect, useState } from "react";
import {
  Card,
  CardHeader,
  CardContent,
  Typography,
  Skeleton,
  Box,
} from "@mui/material";
import { useTheme } from "@mui/material/styles";
import type { ApexOptions } from "apexcharts";
import OptionsMenu from "../../@core/components/option-menu";

const AppReactApexCharts = React.lazy(() => import("../../libs/ApexCharts"));

interface WeeklyOverviewProps {
  shops: any[];
  currencyDetails?: { totalAmountInPKR?: number };
  loading: boolean;
}

const CUSTOM_COLORS = [
  "#23B477",
  "#2E7DC1",
  "#EE1F23",
  "#F57F21",
  "#6966CD",
  "#FCB914",
];

const formatCompact = (v: number) => {
  const n = Number(v);
  const abs = Math.abs(n);
  if (!Number.isFinite(n)) return "0";
  if (abs >= 1_000_000_000)
    return (n / 1_000_000_000).toFixed(1).replace(/\.0$/, "") + "B";
  if (abs >= 1_000_000)
    return (n / 1_000_000).toFixed(1).replace(/\.0$/, "") + "M";
  if (abs >= 1_000) return (n / 1_000).toFixed(1).replace(/\.0$/, "") + "K";
  return n.toString();
};

const truncateForAxis = (text: string, maxChars = 12) => {
  if (!text) return "";
  const trimmed = text.trim();
  if (trimmed.length <= maxChars) return trimmed;

  const words = trimmed.split(/\s+/);
  if (words.length > 1 && words[0].length <= maxChars) return words[0];

  return trimmed.substring(0, maxChars - 1) + "…";
};

const WeeklyOverview = ({
  shops,
  currencyDetails,
  loading,
}: WeeklyOverviewProps) => {
  const theme = useTheme();
  const divider = theme.palette.divider;
  const disabled = theme.palette.text.disabled;
  const chartRef = useRef<any>(null);
  const [activeBar, setActiveBar] = useState(0);

  useEffect(() => {
    if (loading) return;
    const handleWheel = (e: WheelEvent) => {
      e.preventDefault();
      const direction = e.deltaY > 0 ? 1 : -1;
      setActiveBar((prev) => Math.max(0, Math.min(6, prev + direction)));
    };

    const el = chartRef.current;
    if (!el) return;
    el.addEventListener("wheel", handleWheel, { passive: false });
    return () => el.removeEventListener("wheel", handleWheel);
  }, [loading]);

  useEffect(() => {
    if (loading) return;
    if (chartRef.current) {
      const chart = chartRef.current?.querySelector(".apexcharts-canvas");
      if (chart) {
        const barElements = chart.querySelectorAll(".apexcharts-bar-area");
        if (barElements[activeBar]) {
          const mouseEnterEvent = new MouseEvent("mouseenter", {
            bubbles: true,
          });
          barElements[activeBar].dispatchEvent(mouseEnterEvent);
        }
      }
    }
  }, [activeBar, loading]);

  // prepare top 7 shops + apply custom colors
  const { labelsFull, labelsAxis, data, yMax, colors } = useMemo(() => {
    const rows = (shops || [])
      .map((s) => ({
        full: s.shop_name ?? String(s.shop_id),
        axis: truncateForAxis(s.shop_name ?? String(s.shop_id), 12),
        val: Number.isFinite(Number(s.total_amount_pkr))
          ? Number(s.total_amount_pkr)
          : 0,
      }))
      .sort((a, b) => b.val - a.val)
      .slice(0, 7);

    const values = rows.map((r) => r.val);
    const maxVal = Math.max(0, ...values);
    const yMaxCalc = maxVal <= 0 ? 10 : Math.ceil(maxVal * 1.1);

    // Cycle through your custom color list
    const barColors = rows.map(
      (_, i) => CUSTOM_COLORS[i % CUSTOM_COLORS.length]
    );

    return {
      labelsFull: rows.map((r) => r.full),
      labelsAxis: rows.map((r) => r.axis),
      data: values,
      yMax: yMaxCalc,
      colors: barColors,
    };
  }, [shops]);

  const options: ApexOptions = {
    chart: {
      parentHeightOffset: 0,
      toolbar: { show: false },
      type: "bar",
      animations: {
        enabled: true,
        dynamicAnimation: { enabled: true, speed: 350 },
      },
    },
    plotOptions: {
      bar: {
        borderRadius: 8,
        distributed: true, // important to apply per-bar colors from `colors`
        columnWidth: "55%",
        dataLabels: { position: "top" },
      },
    },
    dataLabels: { enabled: false },
    legend: { show: false },
    stroke: { width: 2, colors: [theme.palette.background.paper] },
    grid: {
      xaxis: { lines: { show: false } },
      strokeDashArray: 7,
      padding: { left: -9, top: -20, bottom: 15 },
      borderColor: divider,
    },
    colors, // <- your custom color array
    xaxis: {
      categories: labelsAxis,
      tickPlacement: "on",
      labels: {
        rotate: -45,
        rotateAlways: false,
        trim: true,
        hideOverlappingLabels: true,
        style: { colors: disabled, fontSize: "11px" },
      },
      axisTicks: { show: false },
      axisBorder: { show: false },
    },
    yaxis: {
      min: 0,
      max: yMax,
      tickAmount: 5,
      labels: {
        offsetY: 2,
        offsetX: -10,
        style: {
          colors: disabled,
          fontSize: theme.typography.body2.fontSize as string,
        },
        formatter: (value: number) => formatCompact(value),
      },
    },
    tooltip: {
      enabled: true,
      shared: false,
      intersect: true,
      custom: ({ series, seriesIndex, dataPointIndex }) => {
        const shopName = labelsFull[dataPointIndex] || "";
        const value = series[seriesIndex][dataPointIndex];
        const formattedValue = new Intl.NumberFormat("en-PK", {
          maximumFractionDigits: 0,
        }).format(value);

        return `
          <div style="
            padding: 8px 12px;
            background: ${theme.palette.mode === "dark" ? "#1e1e1e" : "#fff"};
            border: 1px solid ${divider};
            border-radius: 4px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.15);
            max-width: 250px;">
            <div style="
              font-size: 12px; font-weight: 600;
              color: ${theme.palette.text.primary};
              margin-bottom: 4px; word-wrap: break-word;">
              ${shopName}
            </div>
            <div style="font-size: 13px; font-weight: 500; color: ${
              theme.palette.primary.main
            };">
              ${formattedValue} PKR
            </div>
          </div>
        `;
      },
    },
    states: {
      hover: { filter: { type: "lighten" } },
      active: { filter: { type: "darken" } },
    },
  };

  // ---------- Loader Skeleton ----------
  if (loading) {
    return (
      <Card style={{ height: "452px" }}>
        <CardHeader
          title={<Skeleton variant="text" width={260} height={28} />}
          action={<Skeleton variant="circular" width={32} height={32} />}
        />
        <CardContent>
          <Box mb={2}>
            <Skeleton
              variant="rectangular"
              height={350}
              sx={{ borderRadius: 2 }}
            />
          </Box>
          <Box display="flex" alignItems="center" gap={2}>
            <Skeleton variant="text" width={140} height={28} />
            <Skeleton variant="text" width={220} height={24} />
          </Box>
        </CardContent>
      </Card>
    );
  }

  // ---------- Normal Render ----------
  return (
    <Card style={{ minHeight: "452px", maxHeight: "700px" }}>
      <CardHeader
        className="font-sans"
        title="Top 7 Shops by Revenue (Last Seven Days)"
        titleTypographyProps={{ className: "font-sans" }}
        action={
          <OptionsMenu
            iconClassName="text-textPrimary"
            options={["Refresh", "Update", "Delete"]}
          />
        }
      />
      <CardContent
        ref={chartRef}
        sx={{
          "& .apexcharts-xcrosshairs.apexcharts-active": { opacity: 1 },
          "& .apexcharts-tooltip": { zIndex: 10 },
          position: "relative",
        }}
      >
        <Suspense
          fallback={
            <Skeleton
              variant="rectangular"
              height={350}
              sx={{ borderRadius: 2 }}
            />
          }
        >
          <AppReactApexCharts
            type="bar"
            height={350}
            width="100%"
            series={[{ name: "Total Amount (PKR)", data }]}
            options={options}
          />
        </Suspense>

        <div className="flex items-center mt-3 gap-2">
          <Typography
            variant="h6"
            sx={{ fontFamily: '"Nunito Sans", sans-serif' }}
          >
            {currencyDetails?.totalAmountInPKR
              ? `${formatCompact(currencyDetails.totalAmountInPKR)} `
              : "--"}
            <Typography
              variant="caption"
              component="span"
              sx={{
                fontFamily: '"Nunito Sans", sans-serif',
                fontSize: "0.8rem",
                opacity: 1,
              }}
            >
              PKR
            </Typography>
          </Typography>
          <Typography sx={{ fontFamily: '"Nunito Sans", sans-serif' }}>
            Total Revenue (Last 7 Days)
          </Typography>
        </div>
      </CardContent>
    </Card>
  );
};

export default WeeklyOverview;
