import React from "react";
import { Chip, Typography } from "@mui/material";
import tableStyles from "../../@core/styles/table.module.css";
import CustomAvatar from "../../@core/components/mui/Avatar";
import { useNavigate } from "react-router";
import { useSelector } from "react-redux";
import FiberManualRecordIcon from "@mui/icons-material/FiberManualRecord";
import { darken } from "@mui/system";
import { useAppDispatch } from "../../components/hooks/hooks";
import { orderdetail } from "../../redux/thunks/orderThunks";
import AccessDenied from "../../components/merchant/Accessdenied";

type TableBodyRowType = {
  order_cancel_reason?: string;
  order_cancelled_at?: string;
  order_cancelled_by?: string;
  order_channel?: string;
  order_charge_rate?: number;
  order_date?: string;
  order_delivery_address?: string;
  order_delivery_status?: string;
  order_fulfillment_status?: string;
  order_items?: any[];
  order_id?: number;
  order_payment_status?: string;
  order_shipping?: number;
  order_shop_id?: string | number;
  order_shopify_id?: string;
  order_tax?: number;
  order_tax_rate?: number;
  order_title?: string;
  order_total_amount?: number;
  order_user_id?: number;
  user_name?: string;
  user_email?: string;
  shop_name?: string;
  shop_currency?: string;
  shop_logo_url?: string;
  item_count?: number;
  tracking_status?: string;
  transaction_amount?: number;
};

const getStatusColor = (status: string) => {
  switch (status.toLowerCase()) {
    //tracking status
    case "out_for_delievery":
      return "#27b276";
    case "failure":
      return "#EE1F23";
    case "in_transit":
      return "#F57F21";
    case "in_progress":
      return "#2E7DC1";
    case "delivered":
      return "#27b276";

    case "shipped":
      return "#fcb913";
    // payement_status
    case "paid":
      return "#B4FED2";
    case "voided":
      return "#F0F0F0";
    case "refunded":
    case "cancelled":
    case "order_payment_status":
      return "#F44336";
    case "partially_paid":
      return "#FCB914";
    case "unavailable":
      return "#f5be08";

    case "pending":
    case "Unfulfilled":
      return "#c2dada";
    case "processing":
    case "fulfilled":
      return "#D8D8D8";
    case "expired":
      return "#bf77f6";
    default:
      return "#F0F0F0";
  }
};

interface TableProps {
  canRead: boolean;
}

const Table: React.FC<TableProps> = ({ canRead }) => {
  const navigate = useNavigate();
  const { orders } = useSelector((state: any) => state.orders?.orders);
  const rowsData: TableBodyRowType[] = orders ?? [];

  rowsData.forEach((row: TableBodyRowType, index: number) => {
    console.log(`Row ${index}:`, row);
  });
  const dispatch = useAppDispatch();

  const handleclick = async (row: any) => {
    console.log("row", row);
    if (row.user_email !== null) {
      const result = await dispatch(orderdetail({ id: row.order_id }));
      if (result) {
        navigate(`/orders/${row.order_id}`);
      } else {
        navigate(`/orders/orderlisting`);
      }
    }
  };

  const formatCurrency = (amount: number, currency: string = "PKR") => {
    return new Intl.NumberFormat(undefined, {
      style: "currency",
      currency,
      minimumFractionDigits: 2,
    }).format(amount);
  };
  if (!canRead) {
    return (
      <AccessDenied
        subtitle="Your account is missing read permissions for orders. Contact an admin if you need access."
        secondaryActionText="Contact admin"
        onSecondaryAction={() => {
          // open your support modal / route / mailto
          // e.g., navigate("/support") or open a dialog
          window.open("https://cymbiote.com/contact-us/", "_blank");
        }}
      />
    );
  }

  return (
    <>
      <div className="overflow-x-auto">
        <table className={tableStyles.table}>
          <thead>
            <tr className="font-bold">
              <th>Order</th>
              <th>Merchant</th>
              <th>Date</th>
              <th>Customer</th>
              <th>Total Order Amount</th>
              <th>Items</th>
              <th>Trans Rate</th>
              <th>Cercle Commission</th>
              <th>Fulfillment Status</th>
              <th>Delivery Status</th>
              <th>Trans Status</th>
            </tr>
          </thead>
          <tbody>
            {rowsData.map((row, index) => (
              <tr
                key={index + 1}
                className="text-black cursor-pointer"
                onClick={() => {
                  handleclick(row);
                }}
              >
                <td className="font-bold ">{row.order_title}</td>

                <td className="p-0 m-0">
                  <div className="flex items-center gap-2">
                    <CustomAvatar src={row.shop_logo_url} size={35} />
                    <div className="flex flex-col ">
                      <Typography variant="body2" fontWeight="bold">
                        {row.shop_name || "Not available"}
                      </Typography>
                    </div>
                  </div>
                </td>

                <td>{row.order_date?.slice(0, 10)}</td>
                <td>
                  {row.user_email || (
                    <span>
                      <Typography color="error" variant="inherit">
                        User not found
                      </Typography>
                    </span>
                  )}
                </td>

                <td>
                  {formatCurrency(
                    row.order_total_amount ?? 0,
                    row.shop_currency
                  )}
                </td>
                <td>{row.item_count}</td>
                <td>{row.order_charge_rate}%</td>
                <td>
                  {row.shop_currency}{" "}
                  {(
                    ((row.order_total_amount ?? 0) *
                      (row.order_charge_rate ?? 0)) /
                    100
                  ).toFixed(2)}{" "}
                </td>
                <td>
                  <Chip
                    label={row.order_fulfillment_status || "Not available"}
                    avatar={
                      <FiberManualRecordIcon
                        sx={{
                          color: darken(
                            getStatusColor(row.order_fulfillment_status || ""),
                            0.3
                          ),
                        }}
                      />
                    }
                    sx={{
                      backgroundColor: getStatusColor(
                        row.order_fulfillment_status || ""
                      ),
                      color: "#000", // optional: adjust text color for readability
                      padding: "2px",
                    }}
                    size="small"
                    className="capitalize"
                  />
                </td>
                <td>
                  <Chip
                    label={row.tracking_status?.toLowerCase() || "unavailable"}
                    sx={{
                      backgroundColor: getStatusColor(
                        row.tracking_status || "cancelled"
                      ),
                      color: "#fff",
                      fontWeight: 400,
                      borderRadius: "15px",
                      fontSize: 12,
                    }}
                    size="small"
                    className="capitalize"
                  />
                </td>

                <td>
                  <Chip
                    label={row.order_payment_status || "Not available"}
                    sx={{
                      backgroundColor: getStatusColor(
                        row.order_payment_status || ""
                      ),
                      color: "#000",
                      padding: "2px",
                    }}
                    size="small"
                    className="capitalize"
                  />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
};

export default Table;
