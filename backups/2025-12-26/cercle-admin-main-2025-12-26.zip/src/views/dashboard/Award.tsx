// MUI Imports
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import Typography from "@mui/material/Typography";
import { useTheme } from "@mui/material/styles";
import Box from "@mui/material/Box";

// Icons

import { useSelector } from "react-redux";
import { RootState } from "../../redux/store/store";
import formatK from "../../../src/utils/formatCurrency";

interface BestSellerShop {
  shop_name: string;
  total_amount_pkr: number;
  total_orders: number;
  order_count: number;
}

interface propsAwards {
  best_seller_shop: BestSellerShop;
  loading: boolean;
}

const Award = ({ best_seller_shop }: propsAwards) => {
  const theme = useTheme();
  const user = useSelector((state: RootState) => state.auth.user);

  const shopName = best_seller_shop?.shop_name || "N/A Shop";
  const totalAmount = best_seller_shop?.total_amount_pkr || 0;
  const totalOrders = best_seller_shop?.order_count || 0; // NEW
  const username = user?.username || "Valued User";
  // logic (above your JSX)
  const digitLen = String(
    Math.trunc(Math.abs(Number(totalAmount) || 0))
  ).length;
  // stack orders under sales if totalAmount has 5+ digits
  const stack = digitLen >= 5;

  return (
    <Card
      sx={{
        boxShadow: 3,
        position: "relative",
        overflow: "hidden",
        borderRadius: 1.5,
      }}
    >
      <CardContent
        sx={{
          display: "flex",
          flexDirection: "column",
          justifyContent: "space-between",
          minHeight: { xs: "auto", sm: 256 }, // auto on mobile, fixed on desktop
          p: { xs: 2, sm: 3.6 },
        }}
      >
        <Box>
          <Typography
            variant="h5"
            component="div"
            sx={{
              fontWeight: 700,
              fontFamily: '"Nunito Sans", sans-serif',
              color: theme.palette.text.primary,
              mb: 0.5,
            }}
          >
            {`Congratulations ${username}`} 🎉
          </Typography>
          <Typography
            variant="body2"
            color="text.secondary"
            className="flex gap-1"
          >
            Best Shop{" "}
            <Typography variant="body2" fontWeight={700} color="text.secondary">
              {shopName}
            </Typography>
            of the month!
          </Typography>
        </Box>

        {/* Middle Section: Metrics (Sales Amount & Orders) */}
        <div
          className={`mt-1 mb-2 grid gap-3 ${stack ? "sm:grid-cols-1" : "sm:grid-cols-2"
            } items-center`}
        >
          {/* 1) Sales Amount */}
          <div>
            <p className="text-blue-600 font-extrabold font-sans leading-none text-[1.75rem] sm:text-[2.5rem] break-words">
              {formatK(totalAmount)}
            </p>
            <span className="text-xs text-gray-500 flex items-center gap-1 mt-1">
              PKR Total Sales
            </span>
          </div>

          {/* 2) Total Orders */}
          <div className={`${stack ? "" : "sm:border-l sm:pl-3"} pt-1 sm:pt-0`}>
            <p className="font-bold font-sans leading-tight text-[1.2rem] sm:text-[1.5rem] text-emerald-600">
              {Number(totalOrders || 0).toLocaleString()}
            </p>
            <span className="text-xs text-gray-500 flex items-center gap-1">
              {/* no components; keep it simple */}
              {/* 🛒 */} Highest Orders
            </span>
          </div>
        </div>

        <Box
          sx={{
            position: "absolute",
            bottom: 0,
            right: 0,
            width: 150,
            height: 150,
            borderRadius: "50%",
            background: `radial-gradient(circle, ${theme.palette.primary.light} 0%, transparent 70%)`,
            opacity: 0.2,
            transform: "translate(20%, 20%)",
            display: { xs: "none", sm: "block" },
          }}
        />
        <img
          src="/images/pages/trophy.png"
          alt="trophy image"
          style={{
            position: "absolute",
            bottom: theme.spacing(2),
            right: theme.spacing(3),
            height: "120px",
            zIndex: 1,
          }}
          className="hidden sm:block"
        />
      </CardContent>
    </Card>
  );
};

export default Award;
