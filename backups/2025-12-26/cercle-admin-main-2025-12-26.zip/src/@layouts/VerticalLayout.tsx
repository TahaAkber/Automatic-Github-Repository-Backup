import React from "react";

interface ProvidersProps {
  direction: "ltr" | "rtl";
  children: React.ReactNode;
}

export const VerticalLayout: React.FC<ProvidersProps> = ({
  direction,
  children,
}) => {
  return <div dir={direction}>{children}</div>;
};
