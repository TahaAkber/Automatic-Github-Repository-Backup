// src/routes/PrivateRoute.tsx
import React from "react";
import { Navigate } from "react-router-dom";
import { useSelector } from "react-redux";
import { RootState } from "../redux/store/store";
import { RoleLike } from "../components/functions/Roles";
import { useRolePermissions } from "../components/functions/useRolePermissions";

interface PrivateRouteProps {
  component: React.ComponentType<any>;
  /** Which domain roles can unlock this route (ANY-of). Example: ["orders"] */
  requiredRoles: string[];
  /** If provided, enforce this permission on the required roles. If omitted, no perm check. */
  requiredPerm?: "read" | "write";
}

const PrivateRoute = ({
  component: Component,
  requiredRoles,
  requiredPerm, // intentionally no default
  ...rest
}: PrivateRouteProps) => {
  const rawRoles = useSelector((s: RootState) => s.auth.user?.roles) as
    | RoleLike[]
    | undefined;

  if (!rawRoles || rawRoles.length === 0) return <Navigate to="/" />;

  const { roleMap, can } = useRolePermissions(rawRoles);

  // If no roles specified, allow (auth-only route)
  if (!requiredRoles || requiredRoles.length === 0) {
    return <Component {...rest} />;
  }

  // Global fallbacks
  const hasGlobalRead = can("global", "read");
  const hasGlobalWrite = can("global", "write");

  // Case A: requiredPerm omitted -> role membership OR global:read
  const hasRoleOnly =
    requiredPerm === undefined &&
    (requiredRoles.some((r) => roleMap.has(r.toLowerCase())) || hasGlobalRead);

  // Case B: requiredPerm = read -> role:read OR global:read
  const hasRoleWithRead =
    requiredPerm === "read" &&
    (requiredRoles.some((r) => can(r, "read")) || hasGlobalRead);

  // Case C: requiredPerm = write -> role:write OR global:write
  const hasRoleWithWrite =
    requiredPerm === "write" &&
    (requiredRoles.some((r) => can(r, "write")) || hasGlobalWrite);

  const hasAccess = hasRoleOnly || hasRoleWithRead || hasRoleWithWrite;

  return hasAccess ? <Component {...rest} /> : <Navigate to="/" />;
};

export default PrivateRoute;
