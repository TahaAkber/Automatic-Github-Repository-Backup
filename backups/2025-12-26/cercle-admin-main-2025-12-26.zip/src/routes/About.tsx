import React from "react";

export const About: React.FC = () => {
  return <div>About</div>;
};
