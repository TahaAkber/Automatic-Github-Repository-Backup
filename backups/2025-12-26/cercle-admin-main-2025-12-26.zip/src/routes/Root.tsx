import { Navigate, Outlet } from "react-router";
import Navigation from "../components/layout/vertical/Navigation";
import Navbar from "../components/layout/vertical/Navbar";
import { useSelector } from "react-redux";
import { RootState } from "../redux/store/store";
import { useState } from "react";
import Cookies from "js-cookie";
import MenuIcon from "@mui/icons-material/Menu";

export default function Root() {
  const Userroles = useSelector((state: RootState) => state.auth.user?.roles);

  console.log("user roles", Userroles);
  const IsSession = Cookies.get("authToken");
  const [sidebarOpen, setSidebarOpen] = useState(false);

  if (!IsSession) {
    return <Navigate to="/auth/login" replace />;
  }

  return (
    <div className="flex h-screen overflow-hidden">
      <div
        className={`bg-gray-500 fixed lg:relative z-20 transition-transform duration-300 ease-in-out ${
          sidebarOpen ? "translate-x-0" : "-translate-x-full"
        } lg:translate-x-0 w-64`}
      >
        <Navigation setsidebarOpen={setSidebarOpen} sidebarOpen={sidebarOpen} />
      </div>

      <div className="flex-1 flex flex-col overflow-hidden bg-gray-50 ml-0 sm:ml-0 md:ml-0 lg:ml-0">
        <div className="flex items-center justify-between mx-4  gap-5 bg-gray-50 shadow-md">
          <button
            className="lg:hidden"
            onClick={() => setSidebarOpen((prev) => !prev)}
          >
            <MenuIcon />
          </button>

          <Navbar />
        </div>

        <div className="flex-1 overflow-auto px-5 bg-gray-50">
          <Outlet />
        </div>
      </div>
    </div>
  );
}
