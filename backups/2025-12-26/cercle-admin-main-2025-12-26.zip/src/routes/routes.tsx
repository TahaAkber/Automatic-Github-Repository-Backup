import {
  createBrowserRouter,
  isRouteErrorResponse,
  Outlet,
} from "react-router";
import { Home } from "./Home";
import { About } from "./About";
import { RegisterPage } from "./Register";
import { LoginPage } from "./Login";
import { ForgotPasswordPage } from "./ForgotPassword";
import { OTPPage } from "./OTP";
import { ChangePasswordOtpPage } from "./ChangePasswordOtp";
import OrdersPage from "./Orders";
import { Merchants } from "./Merchants";
import Root from "./Root";
import OrderDetail from "../components/orders/OrderDetail";
import CreateMerchant from "../components/Notifications/CreateMerchant";
import CreateApp from "../components/Notifications/CreateApp";
import AppNotification from "../components/Notifications/AppNotification";
import MerchantNotification from "../components/Notifications/MerchantNotification";
import OrderTracking from "../components/orders/OrderTracking";
import CreateCollections from "../components/Collection/CreateCollections";
import TrendingCollections from "../components/Collection/TrendingCollections";
import Plans from "../components/pricing/Plan/Plans";
import Transactions from "../components/transcations/Transactions";
import brands from "../components/brands/brands";
import Users from "../components/users/Users";
import CreateRole from "../components/users/CreateRole";
import EditRole from "../components/users/EditRole";
import EditCollection from "../components/Collection/EditCollection";
import Chat from "../components/Chat/Chat";
import PrivateRoute from "./PrivateRoute";
import MerchantDetail from "../components/merchant/MerchantDetail";
import ScheduledNotification from "../components/Notifications/ScheduledNotification";
import Reviews from "../components/review/Reviews";
import CancelOrders from "../components/orders/CancelOrders";
import tiles from "../components/pricing/Tiles/tiles";
import tracking from "../components/pricing/tracking/tracking";
import Reelsbundle from "../components/pricing/reelsBundle/Reelsbundle";
import MerchantEdit from "../components/merchant/MerchantEdit";
import Report from "../components/report/Report";

export const AuthLayout = () => (
  <div className="bg-gray-200">
    <Outlet />
  </div>
);

export function ErrorBoundary({ error }: { error: any } | any) {
  let message = "Oops!";
  let details = "An unexpected error occurred. ";
  let stack: string | undefined;

  if (isRouteErrorResponse(error)) {
    message = error.status === 404 ? "404" : "Error";
    details =
      error.status === 404
        ? "The requested page could not be found."
        : error.statusText || details;
  } else if (import.meta.env.DEV && error && error instanceof Error) {
    details = error.message;
    stack = error.stack;
  }

  return (
    <main id="error-page">
      <h1>{message}</h1>
      <p>{details}</p>
      {stack && (
        <pre>
          <code>{stack}</code>
        </pre>
      )}
    </main>
  );
}

const router = createBrowserRouter([
  {
    path: "auth",
    Component: AuthLayout,
    children: [
      { index: true, Component: LoginPage },
      { path: "login", Component: LoginPage },
      { path: "changepassword", Component: RegisterPage },
      { path: "changepasswordotp", Component: ChangePasswordOtpPage },
      { path: "forgot-password", Component: ForgotPasswordPage },
      { path: "otp", Component: OTPPage },
    ],
  },
  {
    path: "/",
    Component: Root,
    handle: { nav: { label: "Home", keywords: ["dashboard", "home", "/"] } },
    ErrorBoundary,
    children: [
      { index: true, Component: Home },
      {
        path: "about",
        Component: About,
        handle: { nav: { label: "About", keywords: ["about", "/"] } },
      },

      // Merchants (read for list/detail)
      {
        path: "merchants",
        handle: {
          nav: { label: "merchant", keywords: ["merchants", "shops", "/"] },
        },
        element: (
          <PrivateRoute component={Merchants} requiredRoles={["merchants"]} />
        ),
      },
      {
        path: "merchants/details/:merchantId",
        element: (
          <PrivateRoute
            component={MerchantDetail}
            requiredRoles={["merchants"]}
            requiredPerm="read"
          />
        ),
      },
    ],
  },

  // Orders (read for list/detail/tracking)
  {
    path: "orders",
    Component: Root,
    children: [
      {
        path: "orderlisting",
        index: true,
        element: (
          <PrivateRoute component={OrdersPage} requiredRoles={["orders"]} />
        ),
      },
      {
        path: ":orderId",
        element: (
          <PrivateRoute
            component={OrderDetail}
            requiredRoles={["orders"]}
            requiredPerm="read"
          />
        ),
      },
      {
        path: "cancelled-orders",
        element: (
          <PrivateRoute
            component={CancelOrders}
            requiredRoles={["orders"]}
            requiredPerm="read"
          />
        ),
      },
      {
        path: "tracking/:orderId",
        element: (
          <PrivateRoute
            component={OrderTracking}
            requiredRoles={["orders"]}
            requiredPerm="read"
          />
        ),
      },
    ],
  },

  // Notifications
  {
    path: "notifications",
    Component: Root,
    children: [
      // read pages
      {
        path: "app",
        handle: {
          nav: {
            label: "app",
            keywords: ["app", "app notifications", "/"],
          },
        },
        element: (
          <PrivateRoute
            component={AppNotification}
            requiredRoles={["notification"]}
          />
        ),
      },
      {
        path: "scheduled",
        handle: {
          nav: {
            label: "app",
            keywords: ["app", "app notifications", "/"],
          },
        },
        element: (
          <PrivateRoute
            component={ScheduledNotification}
            requiredRoles={["notification"]}
          />
        ),
      },
      // create pages (write)
      {
        path: "app/Createappnotification",
        handle: {
          nav: {
            label: "app",
            keywords: ["create app", "create app notifications", "/"],
          },
        },
        element: (
          <PrivateRoute
            component={CreateApp}
            requiredRoles={["notification"]}
            requiredPerm="write"
          />
        ),
      },
      {
        path: "merchant",
        element: (
          <PrivateRoute
            component={MerchantNotification}
            requiredRoles={["notification"]}
          />
        ),
      },
      {
        path: "merchant/Createmerchantnotification",
        element: (
          <PrivateRoute
            component={CreateMerchant}
            requiredRoles={["notification"]}
            requiredPerm="write"
          />
        ),
      },
    ],
  },

  // Collections

  {
    path: "collections",
    Component: Root,
    handle: {
      nav: {
        label: "collections",
        keywords: ["trending", "trending collections", "collections", "/"],
      },
    },
    children: [
      {
        index: true,
        element: (
          <PrivateRoute
            component={TrendingCollections}
            requiredRoles={["collections"]}
          />
        ),
      },
      // create/edit need write
      {
        path: "CreateCollection",
        handle: {
          nav: {
            label: "create collection",
            keywords: [
              "create trending",
              "create trending collections",
              "create collections",
              "/",
            ],
          },
        },
        element: (
          <PrivateRoute
            component={CreateCollections}
            requiredRoles={["collections"]}
            requiredPerm="write"
          />
        ),
      },
      {
        path: "EditCollection/:collectionId",
        element: (
          <PrivateRoute
            component={EditCollection}
            requiredRoles={["collections"]}
            requiredPerm="write"
          />
        ),
      },
    ],
  },

  // Plans
  {
    path: "pricing",
    Component: Root,
    handle: {
      nav: {
        label: "pricing",
        keywords: ["price, pricing", "subscription pricing", "/"],
      },
    },
    children: [
      {
        path: "plans",
        handle: {
          nav: {
            label: "plans",
            keywords: ["plans", "plans pricing", "/"],
          },
        },
        element: (
          <PrivateRoute
            component={Plans}
            requiredRoles={["plans"]}
            requiredPerm="read"
          />
        ),
      },
      {
        path: "tile-charges",
        element: (
          <PrivateRoute
            component={tiles}
            requiredRoles={["plans"]}
            requiredPerm="read"
          />
        ),
      },
      {
        path: "tracking-charges",
        element: (
          <PrivateRoute
            component={tracking}
            requiredRoles={["plans"]}
            requiredPerm="read"
          />
        ),
      },
      {
        path: "reels-bundle",
        element: (
          <PrivateRoute
            component={Reelsbundle}
            requiredRoles={["plans"]}
            requiredPerm="read"
          />
        ),
      },
    ],
  },

  // Users
  {
    path: "users",
    Component: Root,
    handle: {
      nav: {
        label: "users",
        keywords: ["users", "user management", "roles", "/"],
      },
    },
    children: [
      {
        index: true,
        element: <PrivateRoute component={Users} requiredRoles={["users"]} />,
      },
      {
        path: "createrole",
        handle: {
          nav: {
            label: "roles",
            keywords: ["create roles", "roles", "user roles", "/"],
          },
        },
        element: (
          <PrivateRoute
            component={CreateRole}
            requiredRoles={["users"]}
            requiredPerm="write"
          />
        ),
      },
      {
        path: "editrole/:userId",
        element: (
          <PrivateRoute
            component={EditRole}
            requiredRoles={["users"]}
            requiredPerm="write"
          />
        ),
      },
    ],
  },

  // Transactions (read)
  {
    path: "transactions",
    Component: Root,
    handle: {
      nav: {
        label: "transactions",
        keywords: ["transactions", "transaction history", "history", "/"],
      },
    },
    children: [
      {
        index: true,
        element: (
          <PrivateRoute
            component={Transactions}
            requiredRoles={["transactions"]}
          />
        ),
      },
    ],
  },

  // Brands (read)
  {
    path: "brands",
    handle: {
      nav: {
        label: "brands",
        keywords: [
          "brands",
          "brand management",
          "brand",
          "products",
          "merchants",
          "/",
        ],
      },
    },
    Component: Root,
    children: [
      {
        index: true,
        element: <PrivateRoute component={brands} requiredRoles={["brands"]} />,
      },
      {
        path: "edit/:brandId",
        element: <PrivateRoute component={MerchantEdit} requiredRoles={["brands"]} />,
      },
    ],
  },

  // Brands (read)
  {
    path: "reviews",
    handle: {
      nav: {
        label: "reviews",
        keywords: ["reviews", "product reviews", "products", "/"],
      },
    },
    Component: Root,
    children: [
      {
        index: true,
        element: (
          <PrivateRoute
            component={Reviews}
            requiredRoles={[
              "users",
              "merchant",
              "orders",
              "collections",
              "transactions",
              "notifcation",
              "plans",
            ]}
          />
        ),
      },
    ],
  },
  {
    path: "report",
    handle: {
      nav: {
        label: "report",
        keywords: ["report", "product reviews", "products", "/"],
      },
    },
    Component: Root,
    children: [
      {
        index: true,
        element: (
          <PrivateRoute
            component={Report}
            requiredRoles={[
              "users",
              "merchant",
              "orders",
              "collections",
              "transactions",
              "notifcation",
              "plans",
            ]}
          />
        ),
      },
    ],
  },

  // Chat (public)
  {
    path: "chat",
    Component: Root,
    children: [{ index: true, Component: Chat }],
  },
]);

export default router;
