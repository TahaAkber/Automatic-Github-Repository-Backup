import React from "react";
import OTPVerification from "../auth/otp";

export const OTPPage: React.FC = () => {
    return (
        <div>
            <OTPVerification mode="dark" />
        </div>
    );
};
