import React from "react";
import DashboardAnalytics from "../app/(dashboard)/page";

export const Home: React.FC = () => {
  return (
    <div>
      <DashboardAnalytics />
    </div>
  );
};
