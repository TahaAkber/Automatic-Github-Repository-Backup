import React, { useEffect, useState } from "react";
import MerchantCard from "../components/merchant/MerchantCard";
import {
  Card,
  Divider,
  FormControl,
  InputAdornment,
  MenuItem,
  Pagination,
  Select,
  SelectChangeEvent,
  TextField,
} from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";
import Parentstyle from "../components/Style/Parentstyle";
import Childstyle from "../components/Style/childstyle";
import { useAppDispatch } from "../components/hooks/hooks";
import { fetchmerchants } from "../redux/thunks/merchantThunks";
import { useSelector } from "react-redux";
import { useRolePermissions } from "../components/functions/useRolePermissions";
import { RoleLike } from "../components/functions/Roles";
import useAutoLimit from "../components/brands/AutoLimitViewPort";

export const Merchants: React.FC = () => {
  const dispatch = useAppDispatch();
  const { merchant_pagination } = useSelector((state: any) => state.merchants);

  const autoLimit = useAutoLimit(); // Get auto-detected limit
  const [currentPage, setCurrentPage] = useState(1);
  const [limit, setLimit] = useState(autoLimit); // Initialize with auto limit
  const [status, setStatus] = useState("");

  const [searchKeyword, setSearchKeyword] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");

  // Update limit when autoLimit changes (on resize)
  useEffect(() => {
    setLimit(autoLimit);
  }, [autoLimit]);

  // Debounce Effect (500ms)
  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedSearch(searchKeyword);
    }, 500);
    return () => clearTimeout(handler);
  }, [searchKeyword]);

  useEffect(() => {
    dispatch(
      fetchmerchants({
        page: currentPage,
        limit,
        searchKeyword: debouncedSearch,
        status: status,
      })
    );
  }, [dispatch, currentPage, debouncedSearch, limit, status]);

  const handlePageChange = (_: React.ChangeEvent<unknown>, page: number) => {
    setCurrentPage(page);
  };

  const rawRoles = useSelector((state: any) => state.auth.user?.roles) as
    | RoleLike[]
    | undefined;
  const { can } = useRolePermissions(rawRoles);
  const canRead = can("merchants", "read");

  return (
    <Parentstyle>
      <Childstyle>
        <h1 className="text-2xl font-semibold mb-2">Merchants</h1>
        <Card className="w-full p-5">
          {canRead && (
            <div className="py-2 flex flex-col md:flex-row md:items-center justify-between gap-3 md:gap-4">
              <TextField
                size="small"
                id="input-with-icon-textfield"
                autoComplete="off"
                label="Search"
                className="border-x-black border-solid border w-auto rounded-md"
                slotProps={{
                  input: {
                    endAdornment: (
                      <InputAdornment position="end">
                        <SearchIcon />
                      </InputAdornment>
                    ),
                  },
                }}
                variant="outlined"
                value={searchKeyword}
                onChange={(e) => {
                  setSearchKeyword(e.target.value);
                  setCurrentPage(1);
                }}
              />

              <div className="w-full md:w-auto grid grid-cols-2 gap-3 md:grid-cols-none md:flex md:gap-4 flex-wrap">
                <FormControl className="w-32" size="small">
                  <Select
                    size="small"
                    labelId="helper-label1"
                    id="select-helper1"
                    className="w-32"
                    value={limit.toString()}
                    displayEmpty
                    onChange={(e: SelectChangeEvent) => {
                      setLimit(Number(e.target.value));
                      setCurrentPage(1);
                    }}
                    renderValue={(limit) => {
                      if (!limit)
                        return <span className="text-gray-500">Limit</span>;
                      return (
                        <span className="text-gray-500">Limit: {limit}</span>
                      );
                    }}
                  >
                    <MenuItem value={10}>10</MenuItem>
                    <MenuItem value={12}>12</MenuItem>
                    <MenuItem value={20}>20</MenuItem>
                    <MenuItem value={50}>50</MenuItem>
                    <MenuItem value={100}>100</MenuItem>
                  </Select>
                </FormControl>
                <FormControl size="small" className="w-32">
                  <Select
                    size="small"
                    labelId="helper-label2"
                    id="select-helper2"
                    className="w-32"
                    value={status}
                    displayEmpty
                    onChange={(e) => {
                      setStatus(e.target.value);
                      setCurrentPage(1);
                    }}
                    renderValue={(status) => {
                      if (!status)
                        return <span className="text-gray-500">All</span>;
                      return <span className="text-gray-500">{status}</span>;
                    }}
                  >
                    <MenuItem value="" className="text-gray-500">
                      All
                    </MenuItem>
                    <MenuItem value="active">Active</MenuItem>
                    <MenuItem value="delisted">Delisted</MenuItem>
                    <MenuItem value="unactive">Inactive</MenuItem>
                  </Select>
                </FormControl>
              </div>
            </div>
          )}

          <div className="my-5 py-5 flex justify-items-center ">
            <MerchantCard canRead={canRead} />
          </div>

          <Divider />
          <div className="m-5 py-1">
            {canRead && merchant_pagination?.totalPages > 1 && (
              <Pagination
                onChange={handlePageChange}
                count={merchant_pagination?.totalPages || 1}
                page={currentPage}
                variant="outlined"
                shape="rounded"
                color="primary"
              />
            )}
          </div>
        </Card>
      </Childstyle>
    </Parentstyle>
  );
};
