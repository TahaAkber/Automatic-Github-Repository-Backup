import React from "react";
import ForgotPassword from "../auth/ForgotPassword";

export const ForgotPasswordPage: React.FC = () => {
  return (
    <div>
      <ForgotPassword mode="dark" />
    </div>
  );
};
