import Parentstyle from "../components/Style/Parentstyle";
import Childstyle from "../components/Style/childstyle";
import Orderlist from "../components/orders/Orderlist";

const OrdersPage: React.FC = () => {
  return (
    <Parentstyle>
      <Childstyle>
        <Orderlist />
      </Childstyle>
    </Parentstyle>
  );
};

export default OrdersPage;
