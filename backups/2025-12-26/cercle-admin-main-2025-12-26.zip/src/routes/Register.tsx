import React from "react";
import Register from "../auth/changePassword";

export const RegisterPage: React.FC = () => {
  return <Register mode="dark" />;
};
