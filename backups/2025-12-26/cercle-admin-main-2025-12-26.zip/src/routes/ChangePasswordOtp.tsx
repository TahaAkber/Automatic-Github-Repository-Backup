import React from "react";
import ChangePasswordOtp from "../auth/changePasswordOtp";

export const ChangePasswordOtpPage: React.FC = () => {
  return <ChangePasswordOtp mode="light" />;
};
