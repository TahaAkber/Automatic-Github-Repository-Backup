import React from "react";
import Login from "../auth/Login";

export const LoginPage: React.FC = () => {
  return <Login mode="dark" />;
};
