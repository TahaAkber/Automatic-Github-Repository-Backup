/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html", // if you use this
    "./src/**/*.{js,ts,jsx,tsx}", // include all source files
  ],
  theme: {
    extend: {
      fontFamily: {
        sans: ['"Nunito Sans"', "sans-serif"],
      },
    },
  },
  plugins: [],
};
