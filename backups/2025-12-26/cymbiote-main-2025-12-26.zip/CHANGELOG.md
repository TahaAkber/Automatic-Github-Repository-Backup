# @shopify/shopify-app-template-remix

## v2024.07.16

Started tracking changes and releases using calver
