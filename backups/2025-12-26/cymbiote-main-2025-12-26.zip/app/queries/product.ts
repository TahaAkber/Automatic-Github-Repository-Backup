import { AdminApiContext } from "@shopify/shopify-app-remix/server";

export const productsQuery = async (
  admin: AdminApiContext,
  afterCursor: string | null = null,
  beforeCursor: string | null = null,
  productsFetchQuery: string = "status:ACTIVE",
) => {
  const query = `
    query ${afterCursor || beforeCursor ? "($cursor: String)" : ""} {
      products(
        ${afterCursor ? "first: 50, after: $cursor" : ""}
        ${beforeCursor ? "last: 50, before: $cursor" : ""}
        ${!afterCursor && !beforeCursor ? "first: 50" : ""}
        query: "${productsFetchQuery}"
      ) {
        nodes {
          id
          category { name }
          title
          description
          descriptionHtml
          status
          images(first: 250) { nodes { url } }
          totalInventory
          productType
          tags
          variants(first: 250) {
            nodes {
              title
              price
              image { url id }
              id
              selectedOptions { name value }
            }
          }
          metafields(first: 250) { nodes { key value } }
        }
        pageInfo {
          hasNextPage
          hasPreviousPage
          endCursor
          startCursor
        }
      }
    }
  `;

  // Choose the appropriate cursor variable based on availability
  const variables = {
    cursor: afterCursor || beforeCursor || null,
  };

  const productsQueryRequest = await admin.graphql(query, { variables });
  const shopifyProducts = await productsQueryRequest.json();
  return shopifyProducts;
};

export const metafieldsUpdate = async (
  admin: AdminApiContext,
  productShopifyId: string,
  product_id: any,
) => {
  const query = `
    query GetProductById($id: ID!) {
      node(id: $id) {
        ... on Product {
          id
          title
          metafields(first: 100) {
            nodes {
              key
              value
            }
          }
        }
      }
    }`;

  try {
    const productVariables = { id: productShopifyId };

    const productsQueryRequest = await admin.graphql(query, {
      variables: productVariables,
    });

    const shopifyProducts = await productsQueryRequest.json();

    const metafields = shopifyProducts?.data?.node?.metafields?.nodes ?? [];

    const targetMetafield = metafields.find(
      (mf: any) => mf.key === "cymbiote_product_category",
    );

    if (targetMetafield) {
      const metaObjectQuery = `
        query GetMetaobject($id: ID!) {
          metaobject(id: $id) {
            displayName
            type
            handle
            id
            fields {
              value
              type
            }
          }
        }
      `;

      const metaobjectVariables = {
        id: targetMetafield.value,
      };

      const response = await admin.graphql(metaObjectQuery, {
        variables: metaobjectVariables,
      });

      const metaobjectData = await response.json();
      const title = metaobjectData.data.metaobject.displayName ?? "";

      const taxonomyQuery = `
      query GetTaxonomy($search: String!) {
        taxonomy {
          categories(search: $search, first: 1) {
            nodes {
              id
              name
              isLeaf
              fullName
              isRoot
              level
            }
          }
        }
      }
    `;

      const taxonomyVariables = {
        search: title,
      };

      const taxonomyResponse = await admin.graphql(taxonomyQuery, {
        variables: taxonomyVariables,
      });

      const metafieldcategory = await taxonomyResponse.json();
      const customcategory =
        metafieldcategory.data.taxonomy.categories.nodes[0]?.id;
      const categoryHierarchy =
        metafieldcategory.data.taxonomy.categories.nodes[0]?.fullName;
      if (customcategory) {
        try {
          await prisma.products.update({
            where: {
              product_id: product_id,
            },
            data: {
              product_custom_category_id: customcategory,
              product_custom_category_hierarchy: categoryHierarchy,
            },
          });
        } catch (error) {
          console.error("Failed to update product category:", error);
        }
      }
    } else {
      console.log("Metafield cymbiote_product_category not found.");
    }
  } catch (error: any) {
    console.log("Error while fetching product with Shopify ID:", error.message);
    return null;
  }
};
