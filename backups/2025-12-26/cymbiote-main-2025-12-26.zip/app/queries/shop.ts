import { AdminApiContext } from "@shopify/shopify-app-remix/server";

export const getshopemailandcurrency = async (admin: AdminApiContext) => {
  const getshopdetails = `query {
  shop {
    email
    currencyCode
  }
}`;
  const shopdetailrequest = await admin.graphql(getshopdetails);

  const shopdetails = await shopdetailrequest.json();

  // console.log("shopdetails", shopdetails);
  return shopdetails;
};
