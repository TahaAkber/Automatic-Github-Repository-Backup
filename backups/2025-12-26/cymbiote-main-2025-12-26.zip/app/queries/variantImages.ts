import { AdminApiContext } from "@shopify/shopify-app-remix/server";

export const getVariantImages = async (
  admin: any,
  variantIds: string[],
): Promise<any> => {
  const query = `
        query getVariantImages($variantIds: [ID!]!) {
            nodes(ids: $variantIds) {
                ... on ProductVariant {
                    id
                    image {
                        url
                    }
                    product {
                        images(first: 1) {
                            nodes {
                                url
                            }
                        }
                    }
                }
            }
        }
    `;

  const variables = {
    variantIds,
  };

  const response = await admin.graphql(query, { variables });
  const responseJson = await response.json();

  if (responseJson.errors) {
    throw new Error(JSON.stringify(responseJson.errors));
  }

  // console.log("responseJson", responseJson.data.nodes);

  return responseJson.data.nodes.map((node: any) => ({
    variantId: node.id,
    imageUrl: node.image?.url || node.product?.images?.nodes?.[0]?.url,
  }));
};

export const getAppDomains = async (admin: AdminApiContext): Promise<any> => {
  try {
    const query = `
      {
        shop {
          domains {
            id
            host
            url
          }
        }
      }
    `;

    const response = await admin.graphql(query);
    const responseJson = await response.json();

    if (responseJson.data.errors) {
      throw new Error(JSON.stringify(responseJson.data.errors));
    }

    return responseJson.data?.shop?.domains;
  } catch (error: any) {
    throw new Error("Error in getting domains" + error.message);
  }
};
