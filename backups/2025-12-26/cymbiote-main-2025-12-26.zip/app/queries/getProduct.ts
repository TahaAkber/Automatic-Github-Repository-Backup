import { AdminApiContext } from "@shopify/shopify-app-remix/server";

export const getProductFromShopify = async (
  productId: string,
  admin: AdminApiContext,
): Promise<{
  status: number;
  jbody?: any;
  message: string;
}> => {
  const productQuery = `{
    product(id: "${productId}") {
      id
      title
      description
      descriptionHtml
      status
      productType
      tags
      totalInventory
      category {
        name
      }
      images(first: 250) {
        nodes {
          url
        }
      }
      variants(first: 250) {
        nodes {
          title
          price
          image {
            url
            id
          }
          id
          selectedOptions {
            name
            value
          }
          inventoryQuantity
          inventoryItem {
            id
          }
        }
      }
      metafields(first: 250) {
        edges {
          node {
            namespace
            key
            value
            type
            definition {
              name
              description
            }
          }
        }
      }
    }
  }`;

  try {
    const productsQueryRequest = await admin.graphql(productQuery);
    const jbody = await productsQueryRequest.json();

    return { status: 200, jbody, message: "success" };
  } catch (error: any) {
    return {
      status: 500,
      jbody: null,
      message: error.message,
    };
  }
};

export const fetchShopifyCategoryHierarchy = async (
  product_title: string,
  admin: AdminApiContext,
) => {
  try {
    const categoryQuery = `
    query GetCategories($search: String!) {
    taxonomy {
    categories(first: 1, search: $search) {
      nodes {
        id
        name
        isLeaf
        fullName
        isRoot
        }
      }
    }
  }
`;

    const variables = {
      search: product_title,
    };
    const productsCategoryRequest = await admin.graphql(categoryQuery, {
      variables,
    });
    const categories = await productsCategoryRequest.json();
    const Result = categories.data.taxonomy.categories.nodes[0];
    return Result;
  } catch (error: any) {
    console.log("Error while fetching category hierarchy", error.message);
  }
};
