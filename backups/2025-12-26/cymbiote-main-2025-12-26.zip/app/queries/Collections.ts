import { AdminApiContext } from "@shopify/shopify-app-remix/server";

export const CollectionsQuery = async (admin: AdminApiContext) => {
  const collectionquery = `{
  collections(first: 50) {
    nodes {
      id
      handle
      title
      updatedAt
      descriptionHtml
      publishedOnCurrentPublication
      sortOrder
      templateSuffix
      image {
        url
      }
      description
      productsCount{
        count
      }
    }
  }
}`;

  const CollectionQueryRequest = await admin.graphql(collectionquery);

  const shopifyCollections = await CollectionQueryRequest.json();
  // console.log("Shopify Collections", shopifyCollections);
  return shopifyCollections;
};
