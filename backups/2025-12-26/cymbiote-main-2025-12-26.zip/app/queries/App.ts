import { AdminApiContext } from "@shopify/shopify-app-remix/server";

type ApiSub = {
  id: string;
  name: string;
  createdAt: string;
  status: string;
  currentPeriodEnd?: string | null;
};

const appInstalledQuery = `
    query AppInstallWithBilling {
        currentAppInstallation {
            id
            activeSubscriptions {
                id
                status
                createdAt
                trialDays
                currentPeriodEnd
                lineItems {
                    plan {
                        pricingDetails {
                            __typename
                            ... on AppRecurringPricing {
                                interval   # EVERY_30_DAYS or EVERY_365_DAYS
                            }
                        }
                    }
                }
            }
        }
    }
  `;

export const fetchAppInstallation = async (admin: AdminApiContext) => {
  try {
    const appInstalled = await admin.graphql(appInstalledQuery);
    const appInstalledData = await appInstalled.json();

    console.log(
      "app installed",
      appInstalledData?.data?.currentAppInstallation?.activeSubscriptions[0]
        ?.currentPeriodEnd,
    );
    return appInstalledData?.data?.currentAppInstallation;
  } catch (error) {
    console.error("Error fetching app installation:", error);
    return null;
  }
};

export const fetchAllAppSubscriptions = async (admin: AdminApiContext) => {
  try {
    const query = `
            query AppInstallWithBilling {
                currentAppInstallation {
                    allSubscriptions(first: 100) {
                        nodes {
                            createdAt
                            currentPeriodEnd
                            name
                            id
                            status
                        }
                    }
                    activeSubscriptions {
                        id
                        status
                        createdAt
                        trialDays
                        name
                        currentPeriodEnd
                        lineItems {
                            plan {
                                pricingDetails {
                                    __typename
                                    ... on AppRecurringPricing {
                                        interval
                                    }
                                }
                            }
                        }
                    }
                }
            }
        `;

    const appInstalled = await admin.graphql(query);
    const appInstalledData = await appInstalled.json();

    return {
      allSubscriptions:
        appInstalledData?.data?.currentAppInstallation?.allSubscriptions.nodes,
      activeSubscriptions:
        appInstalledData?.data?.currentAppInstallation?.activeSubscriptions,
    };
  } catch (error: any) {
    console.error("Error fetching app subscriptions:", error);
    return {
      allSubscriptions: null,
      activeSubscriptions: null,
    };
  }
};

export async function syncSubsEfficient(
  adminData: ApiSub[] | null,
  shopId: number,
) {
  if (!adminData?.length) {
    return { total: 0, inserted: 0, skippedExisting: 0 };
  }

  // 1) normalize subs
  const subs = adminData.map((s) => {
    const extractedId = s.id.split("/").pop() ?? s.id; // keep full if you widened column
    return {
      status: s.status,
      confirmationId: extractedId, // store full if column is NVARCHAR(128)
      name: s.name?.trim() ?? "",
      createdAt: new Date(s.createdAt),
      endsAt: s.currentPeriodEnd ? new Date(s.currentPeriodEnd) : null,
    };
  });

  // 2) fetch all packages in one go
  const uniqueNames = Array.from(
    new Set(subs.map((s) => s.name).filter(Boolean)),
  );
  const packages = await prisma.packages.findMany({
    where: { package_name: { in: uniqueNames } }, // SQL Server is usually case-insensitive by collation
    select: { package_id: true, package_name: true },
  });
  const pkgByName = new Map(
    packages.map((p) => [p.package_name.toLowerCase(), p.package_id]),
  );

  // 3) fetch existing subs (per shop) in one go
  const ids = Array.from(new Set(subs.map((s) => s.confirmationId)));
  const existing = await prisma.subscriptions.findMany({
    where: {
      subscription_shop_id: shopId,
      subscription_confirmation_id: { in: ids },
    },
    select: { subscription_confirmation_id: true },
  });
  const existingSet = new Set(
    existing.map((e) => e.subscription_confirmation_id),
  );

  const activeSubscription: any[] = [];

  // 4) prepare new rows only
  const toInsert = subs
    .filter((s) => !existingSet.has(s.confirmationId))
    .filter((s) => s.status !== "PENDING")
    .map((s) => {
      const pkgId = pkgByName.get(s.name.toLowerCase()) ?? null;
      if (s.status === "ACTIVE") {
        activeSubscription.push(s);
      }
      return {
        subscription_confirmation_id: s.confirmationId,
        subscription_shop_id: shopId,
        subscription_package_id: pkgId!, // if required NOT NULL, ensure pkg exists or handle fallback
        subscription_confirmed: false,
        subscription_enabled: false,
        subscription_charge_date: s.createdAt, // per your requirement
        subscription_created_at: s.createdAt,
        subscription_ends_at: (s.endsAt as Date) || new Date(),
        subscription_appRecurringPricingDetails_id: `gid://shopify/AppSubscriptionLineItem/${s.confirmationId}?v=1&index=0`,
        subscription_appUsagePricingDetails_id: `gid://shopify/AppSubscriptionLineItem/${s.confirmationId}?v=1&index=1`,
      };
    })
    // optional: drop rows with no matching package
    .filter((row) => row.subscription_package_id != null);

  // 5) bulk insert once
  let inserted = 0;
  if (toInsert.length > 0) {
    const res = await prisma.subscriptions.createMany({
      data: toInsert,
    });
    inserted = res.count;
  }

  if (activeSubscription.length) {
    const activeSub = await prisma.subscriptions.findFirst({
      where: {
        subscription_shop_id: shopId,
        subscription_confirmation_id: activeSubscription[0]?.confirmationId,
      },
    });
    console.log("updateActiveSubs");
    await prisma.subscriptions.update({
      data: {
        subscription_ends_at: activeSubscription[0]?.endsAt,
      },
      where: {
        subscription_id: activeSub?.subscription_id,
      },
    });
  }

  return {
    total: subs.length,
    inserted,
    skippedExisting: subs.length - inserted,
  };
}
