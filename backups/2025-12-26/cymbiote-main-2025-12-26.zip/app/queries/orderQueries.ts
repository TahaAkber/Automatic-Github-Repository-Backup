export const generateOrderQuery = (channelId: string, orderType: string) => {
  if (orderType === "cancelled") {
    return `
    {
        orders(first: 150, query: "channel_id:${channelId} AND status:cancelled") {
            nodes {
                id
                channelInformation {
                    app {
                        description
                        developerName
                        developerType
                        embedded
                        title
                    }
                    channelId
                    channelDefinition {
                        channelName
                    }
                }
            }
        }
    }
  `;
  } else {
    return `
    {
        orders(first: 150, query: "channel_id:${channelId} AND -status:cancelled") {
        nodes {
            id
            channelInformation {
            app {
                description
                developerName
                developerType
                embedded
                title
            }
            channelId
            channelDefinition {
                channelName
            }
            }
        }
        }
    }
  `;
  }
};
