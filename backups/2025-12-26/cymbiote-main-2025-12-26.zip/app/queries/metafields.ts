import { AdminApiContext } from "@shopify/shopify-app-remix/server";
import { wait } from "~/functions/common";

// Types for Metaobject and Field structures
export interface MetaobjectField {
  key: string;
  value: string;
  type: string;
  definition: {
    name: string;
  } | null;
}

export interface Metaobject {
  id: string;
  type: string;
  handle: string;
  fields: MetaobjectField[];
}

const THROTTLE_THRESHOLD = 500;

export const fetchExistingMetafield = async (
  ownerType: string,
  metafieldName: string,
  admin: AdminApiContext,
) => {
  const fetchQuery = `
        query FindExistingMetafield {
          metafieldDefinitions(ownerType:${ownerType},first: 10, query:"${metafieldName}") {
            nodes {
                name
                id
            }
          }
        }
      `;

  const fetchResponse = await admin.graphql(fetchQuery);
  const fetchResult = await fetchResponse.json();

  // Filter the fetched metafield definitions by key and namespace
  const existingMetafield = fetchResult.data.metafieldDefinitions.nodes;

  if (existingMetafield) {
    console.log("Found existing metafield definition:", existingMetafield);
    return existingMetafield[0]; // Return the existing metafield definition
  }
  return {};
};

// export const fetchProductMetafields = async (
//   admin: AdminApiContext,
//   metafieldName: string,
// ) => {
//   const query = `
//   query getProductMetafields($title: String!) {
//     products(first: 1, query: $title) {
//       edges {
//         node {
//           title
//           metafields(first: 20) {
//             edges {
//               node {
//                 namespace
//                 key
//                 value
//                 type
//                 definition {
//                   name
//                   description
//                 }
//               }
//             }
//           }
//         }
//       }
//     }
//   }
// `;

//   const variables = {
//     title: metafieldName,
//   };

//   const response = await admin.graphql(query, {
//     variables: {
//       title: `title:'${metafieldName}'`,
//     },
//   });
//   const data = await response.json();
//   const fetchedData = data?.data?.products?.edges;
//   console.log("metafieldsdata", fetchedData);
//   return fetchedData;
// };

export const fetchProductMetafields = async (
  admin: AdminApiContext,
  metafieldName: string,
) => {
  const query = `
    query getProductMetafields($title: String!) {
      products(first: 1, query: $title) {
        edges {
          node {
            title
            metafields(first: 100) {
              edges {
                node {
                  namespace
                  key
                  value
                  type
                  definition {
                    name
                    description
                  }
                }
              }
            }
          }
        }
      }
    }
  `;

  const response = await admin.graphql(query, {
    variables: {
      title: `${metafieldName}`,
    },
  });

  const json = await response.json();
  const product = json?.data?.products?.edges?.[0]?.node;

  if (!product) return null;

  const metafields = product.metafields.edges.map((e: any) => e.node);

  // 🧩 Extract all referenced metaobject GIDs from metafield values
  const metaobjectGids: string[] = [];

  metafields.forEach((field: any) => {
    if (field.type.includes("metaobject_reference")) {
      try {
        const parsed = JSON.parse(field.value); // list = JSON array, single = string
        if (Array.isArray(parsed)) {
          metaobjectGids.push(...parsed);
        } else if (typeof parsed === "string") {
          metaobjectGids.push(parsed);
        }
      } catch (err) {
        // fallback if it's not JSON
        if (
          typeof field.value === "string" &&
          field.value.startsWith("gid://shopify/Metaobject/")
        ) {
          metaobjectGids.push(field.value);
        }
      }
    }
  });

  return {
    title: product.title,
    metafields,
    metaobjectGids: Array.from(new Set(metaobjectGids)),
  };
};

export const buildMetaobjectQuery = (gids: string[]) => {
  const queries = gids.map((gid, index) => {
    return `
      m${index}: metaobject(id: "${gid}") {
        id
        type
        handle
        fields {
          key
          value
          type
          definition {
            name
          }
        }
      }
    `;
  });

  return `
    query {
      ${queries.join("\n")}
    }
  `;
};

export const fetchMetaobjectDetails = async (
  admin: AdminApiContext,
  metaobjectGids: string[],
): Promise<Metaobject[]> => {
  if (!Array.isArray(metaobjectGids) || metaobjectGids.length === 0) return [];

  try {
    const query = buildMetaobjectQuery(metaobjectGids);
    const response = await admin.graphql(query);

    if (!response.ok) {
      throw new Error(
        `Network error: ${response.status} ${response.statusText}`,
      );
    }

    const json = await response.json();

    // Check throttle status
    if (json.extensions?.cost?.throttleStatus) {
      const { currentlyAvailable, maximumAvailable, restoreRate } =
        json.extensions.cost.throttleStatus;
      if (currentlyAvailable < THROTTLE_THRESHOLD) {
        // safer threshold
        // How long to wait? Let’s wait until we’re at least half full
        const waitUnits = Math.ceil(maximumAvailable / 2 - currentlyAvailable);
        const waitMs = Math.max((waitUnits / restoreRate) * 1000, 1000);
        console.log(
          `Throttled: Waiting ${waitMs}ms to let bucket refill... (current: ${currentlyAvailable}, max: ${maximumAvailable})`,
        );
        await wait(waitMs);
      }
    }

    const metaobjects: Metaobject[] = [];
    for (const key in json.data) {
      const obj = json.data[key];
      if (
        obj &&
        typeof obj.id === "string" &&
        typeof obj.type === "string" &&
        typeof obj.handle === "string" &&
        Array.isArray(obj.fields)
      ) {
        metaobjects.push(obj as Metaobject);
      }
    }

    return metaobjects;
  } catch (error) {
    console.error("fetchMetaobjectDetails error:", error);
    return [];
  }
};
