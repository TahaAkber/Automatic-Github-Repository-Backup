import { useCallback } from "react";

export function usePolarisSound(name = "success") {
  return useCallback(() => {
    const audio = new window.Audio(`/sounds/${name}.mp3`);
    audio.currentTime = 0;
    audio.play();
  }, [name]);
}
