import { useEffect, useRef } from "react";

// API response type
type PublishedItemsResponse = {
  publishedItemsCount?: number;
  publishedTotalCount?: number;
};

// State setter types
type StatusSetter = React.Dispatch<React.SetStateAction<string>>;
type CountSetter = React.Dispatch<React.SetStateAction<number>>;

const POLL_INTERVAL = 5000; // 5 seconds

/**
 * Polls the publish status and updates state, but only when shouldPoll is true.
 * Triggers onComplete callback when the process is finished.
 *
 * @param searchUrl The URL search part for your API
 * @param publishRequestId The ID of the publish request
 * @param setPublishedCount State setter for published items count
 * @param setTotalCount State setter for total count
 * @param setPublishStatus State setter for publish status message
 * @param shouldPoll If true, polling is active; if false, polling stops
 * @param onComplete (optional) Callback invoked ONCE when process completes
 */
function usePublishPolling(
  searchUrl: string,
  publishRequestId: string,
  setPublishedCount: CountSetter,
  setTotalCount: CountSetter,
  setPublishStatus: StatusSetter,
  shouldPoll: boolean,
  onComplete?: () => void,
) {
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  // To ensure onComplete only triggers once per cycle
  const hasCompleted = useRef(false);

  const checkPublishedItems = async (
    searchUrl: string,
    publishRequestId: string,
  ) => {
    try {
      const encodedId = encodeURIComponent(publishRequestId); // Encode searchTerm
      const response = await fetch(
        `/api/checkpublished${searchUrl}&publishRequestId=${encodedId}`,
      );
      const data = await response.json();
      return data;
    } catch (error: any) {
      console.log("failed to fetch categories", error.message);
      return {};
    }
  };

  useEffect(() => {
    let isMounted = true;
    hasCompleted.current = false; // reset when effect re-runs (new poll cycle)

    if (!shouldPoll) {
      if (timerRef.current) clearTimeout(timerRef.current);
      return;
    }

    const poll = async () => {
      const data: PublishedItemsResponse = await checkPublishedItems(
        searchUrl,
        publishRequestId,
      );

      if (!isMounted) return;

      setPublishedCount(data.publishedItemsCount ?? 0);
      setTotalCount(data.publishedTotalCount ?? 0);

      // Status logic
      if ((data.publishedItemsCount ?? 0) === 0) {
        setPublishStatus("Fetching your products...");
      } else if (
        (data.publishedItemsCount ?? 0) < (data.publishedTotalCount ?? 0)
      ) {
        setPublishStatus(
          `${data.publishedItemsCount} out of ${data.publishedTotalCount} published...`,
        );
      } else if (
        data.publishedItemsCount === data?.publishedTotalCount &&
        (data.publishedTotalCount ?? 0) > 0
      ) {
        setPublishStatus("Publish complete!");

        // Fire callback only once
        if (!hasCompleted.current && typeof onComplete === "function") {
          hasCompleted.current = true;
          onComplete();
        }

        // Auto-clear status after 3 seconds
        setTimeout(() => {
          if (isMounted) setPublishStatus("");
        }, 3000);
        return; // Stop polling if done
      }

      // Continue polling if not complete
      timerRef.current = setTimeout(poll, POLL_INTERVAL);
    };

    poll();

    return () => {
      isMounted = false;
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, [
    searchUrl,
    publishRequestId,
    setPublishedCount,
    setTotalCount,
    setPublishStatus,
    shouldPoll,
    onComplete,
  ]);
}

export default usePublishPolling;
