import { useLocation } from "@remix-run/react";
import { useEffect, useState, useTransition } from "react";

const useDetectUrlChange = () => {
  const location = useLocation(); // Get the current location
  const [url, setUrl] = useState(location.pathname); // Track the current URL

  const transition = useTransition(); // Track the transition status of the current page

  useEffect(() => {
    // When location changes, update the URL state
    setUrl(location.pathname);
  }, [location]);

  return { url, isTransitioning: transition[0] }; // Return the URL and loading state
};

export default useDetectUrlChange;
