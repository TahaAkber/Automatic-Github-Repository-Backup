import { createAppSubscription } from "~/mutations/appSubscription";
import { authenticate } from "~/shopify.server";
import { retryOperation, uploadToShopify, wait } from "./common";

export const authenticateAdmin = async (request: Request) => {
  const { admin } = await authenticate.admin(request);
  if (!admin) throw new Error("Authentication failed");

  const url = new URL(request.url);
  const shopDomain = url.searchParams.get("shop");
  if (!shopDomain) throw new Error("Missing shop");

  return { admin, shopDomain };
};

export const parseCustomizerForm = async (request: Request) => {
  const formData = await request.formData();

  return {
    headerText: formData.get("headerText")?.toString(),
    displayOption: formData.get("displayOption")?.toString(),
    shopTileOption: formData.get("tileTypeId")?.toString(),
    bannerType: formData.get("bannerType")?.toString() || "image",
    filters: JSON.parse(formData.get("filters")?.toString() || "[]"),
    layout_sequence: formData.get("sequence")?.toString().split(","),
    tileType: formData.get("tileType")?.toString(),
    tileCharges: formData.get("tileCharges")?.toString() || "0",
    newTileId: formData.get("newTileId")?.toString() || "0",
    filterOptions: JSON.parse(
      formData.get("filterOptions")?.toString() || "{}",
    ),
    banner: formData.get("banner") as File,
    logo: formData.get("logo") as File,
    shopColor: formData.get("storeColor"),
    shopFont: formData.get("fontColor"),
    shopCover: formData.get("shopCover") as File,
    selectedShopCollections:
      formData.get("selectedShopCollections")?.toString() || "",
    email: formData.get("email")?.toString() || "",
    phoneNumber: formData.get("phoneNumber")?.toString() || "",
    address: formData.get("address")?.toString() || "",
    privacyPolicy: formData.get("privacyPolicy")?.toString() || "",
    returnPolicy: formData.get("returnPolicy")?.toString() || "",
    instagram: formData.get("instagram")?.toString() || "",
    facebook: formData.get("facebook")?.toString() || "",
    twitter: formData.get("twitter")?.toString() || "",
  };
};

export const getShopAndHandleSubscription = async (
  admin: any,
  shopDomain: string,
  formData: any,
  testPayment: boolean = true,
) => {
  const shop = await retryOperation(async () => {
    return await prisma.shops.findFirst({
      where: { shop_domain: shopDomain },
      include: {
        Subscriptions: {
          include: { Packages: true },
          where: {
            subscription_confirmed: true,
            subscription_enabled: true,
          },
        },
      },
    });
  });

  const tileType = formData.tileType;
  const tileCharges = parseFloat(formData.tileCharges);
  const newTileId = formData.newTileId;
  const isSubscribed = shop?.shop_tile_subscribed === true;

  let redirectUrl = "";

  const shouldStartSubscription = !isSubscribed && tileType === "video";

  const shouldRemoveSubscription =
    isSubscribed && (tileType === "basic" || tileType === "modern");

  console.log("isSubscribed", isSubscribed, "tileType", tileType);

  console.log(
    "start sub",
    shouldStartSubscription,
    "remove sub",
    shouldRemoveSubscription,
  );

  const packageInfo = shop?.Subscriptions?.[0]?.Packages;

  // Safeguard if package is missing
  if (!packageInfo) return { shop, redirectUrl };

  if (shouldStartSubscription) {
    const updatedCharges = packageInfo.package_charges ?? 0;

    const subscriptionResponse = await createAppSubscription(
      admin,
      prisma,
      shopDomain,
      packageInfo.package_name,
      updatedCharges.toString(),
      packageInfo.package_rate.toString(),
      packageInfo.package_id.toString(),
      false,
      tileType,
      newTileId,
      undefined,
      0,
      testPayment,
    );

    const { confirmationUrl } = await subscriptionResponse;
    redirectUrl = confirmationUrl;
  }

  if (shouldRemoveSubscription) {
    const updatedCharges = packageInfo.package_charges ?? 0;

    // Update the shop subscription plan with new (lower) charges
    const subscriptionResponse = await createAppSubscription(
      admin,
      prisma,
      shopDomain,
      packageInfo.package_name,
      updatedCharges.toString(),
      packageInfo.package_rate.toString(),
      packageInfo.package_id.toString(),
      false,
      tileType,
      newTileId,
      undefined,
      0,
      testPayment,
    );

    const { confirmationUrl } = await subscriptionResponse;
    redirectUrl = confirmationUrl;

    // Update shop flag
    await retryOperation(async () => {
      return await prisma.shops.update({
        where: { shop_id: shop?.shop_id },
        data: { shop_tile_subscribed: false, updated_at: new Date() },
      });
    });
  }

  return { shop, redirectUrl };
};

export const uploadAssetsAndFetchUrls = async (admin: any, formData: any) => {
  const uploadedBannerNodeId = formData.banner
    ? await uploadToShopify(
        formData.banner,
        admin,
        "banner",
        formData.bannerType === "video" ? "VIDEO" : "IMAGE",
      )
    : null;

  const uploadedLogoNodeId = formData.logo
    ? await uploadToShopify(formData.logo, admin, "logo")
    : null;

  const uploadedshopCoverId = formData.shopCover
    ? await uploadToShopify(formData.shopCover, admin, "shopCover")
    : null;

  const ids = [
    uploadedBannerNodeId,
    uploadedLogoNodeId,
    uploadedshopCoverId,
  ].filter(Boolean);
  if (!ids.length)
    return {
      uploadedBannerNodeId,
      bannerImageUrl: null,
      logoImageUrl: null,
      bannerlogoUrl: null,
    };

  // ✅ Add delay before querying nodes
  await wait(1500); // wait 1.5 seconds

  const query = `
    {
      nodes(ids: [${ids.map((id) => `"${id}"`).join(",")}]) {
        id
        ... on MediaImage {
          preview { image { url id } }
        }
        ... on Video { sources { url } }
      }
    }
  `;

  const fileNodeResponse = await admin.graphql(query);
  const nodes = (await fileNodeResponse.json()).data.nodes;

  let bannerImageUrl = null;
  let logoImageUrl = null;
  let shopCoverUrl = null;
  for (const node of nodes) {
    if (node.id === uploadedBannerNodeId) {
      bannerImageUrl = node.sources?.[0]?.url || node.preview?.image?.url;
    } else if (node.id === uploadedLogoNodeId) {
      logoImageUrl = node.preview?.image?.url;
    } else if (node.id === uploadedshopCoverId) {
      shopCoverUrl = node.preview?.image?.url;
    }
  }

  return { uploadedBannerNodeId, bannerImageUrl, logoImageUrl, shopCoverUrl };
};

export const updateShopConfiguration = async (
  shop: any,
  formData: any,
  bannerImageUrl: string | null,
  logoImageUrl: string | null,
  shopCoverUrl: string | null,
) => {
  const updateData = {
    ...(logoImageUrl ? { shop_logo_url: logoImageUrl } : {}),
    ...(bannerImageUrl ? { shop_banner_url: bannerImageUrl } : {}),
    ...(shopCoverUrl ? { shop_cover_url: shopCoverUrl } : {}),
    ...(formData.displayOption
      ? { shop_header_type: formData.displayOption }
      : {}),
    ...(formData.headerText ? { shop_name: formData.headerText } : {}),
    ...(formData.bannerType ? { shop_banner_type: formData.bannerType } : {}),
    ...(formData.shopTileOption
      ? { shop_tile_type: parseInt(formData.shopTileOption) }
      : {}),
    ...(formData.shopColor ? { shop_color: formData.shopColor } : {}),
    ...(formData.shopFont ? { shop_font_color: formData.shopFont } : {}),
    ...(formData.selectedShopCollections
      ? { shop_selected_collections: formData.selectedShopCollections }
      : { shop_selected_collections: null }),
    ...(formData.email ? { shop_email: formData.email } : {}),
    ...(formData.phoneNumber ? { shop_number: formData.phoneNumber } : {}),
    ...(formData.address ? { shop_address: formData.address } : {}),
    ...(formData.privacyPolicy
      ? { shop_privacy_policy_url: formData.privacyPolicy }
      : {}),
    ...(formData.returnPolicy
      ? { shop_return_policy_url: formData.returnPolicy }
      : {}),
    ...(formData.instagram ? { shop_instagram_url: formData.instagram } : {}),
    ...(formData.facebook ? { shop_facebook_url: formData.facebook } : {}),
    ...(formData.twitter ? { shop_twitter_url: formData.twitter } : {}),
    updated_at: new Date().toISOString(),
  };
  console.log("updated data", updateData);
  await prisma.shops.update({
    where: { shop_id: shop.shop_id },
    data: updateData,
  });

  // Update layout sequence
  const sequence = await retryOperation(async () => {
    return await prisma.layout_Sequence.findFirst({
      where: { layout_shop_id: shop.shop_id },
    });
  });
  if (sequence) {
    await retryOperation(async () => {
      return await prisma.layout_Sequence.update({
        where: { layout_id: sequence.layout_id },
        data: {
          layout_sequence_one: formData.layout_sequence?.[0] || "banner",
          layout_sequence_two: formData.layout_sequence?.[1] || "filter",
          layout_sequence_three:
            formData.layout_sequence?.[2] || "productCards",
          layout_sequence_four:
            formData.layout_sequence?.[3] || "productItemsList",
          layout_sequence_five:
            formData.layout_Sequence?.[4] || "productVideos",
        },
      });
    });
  }
  console.log("sequence", sequence);
  // Update filters
  for (const filterValue of formData.filters) {
    const exists = await retryOperation(async () => {
      return await prisma.shop_Filters.findFirst({
        where: {
          shop_filter_shop_id: shop.shop_id,
          shop_filter_value: filterValue,
        },
      });
    });

    if (!exists) {
      await retryOperation(async () => {
        return await prisma.shop_Filters.create({
          data: {
            shop_filter_shop_id: shop.shop_id,
            shop_filter_value: filterValue,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
          },
        });
      });
    }
  }

  // Update filter options
  for (const [key, values] of Object.entries(formData.filterOptions)) {
    const filter = await retryOperation(async () => {
      return await prisma.shop_Filters.findFirst({
        where: { shop_filter_shop_id: shop.shop_id, shop_filter_value: key },
      });
    });
    if (filter) {
      for (const value of values as string[]) {
        const exists = await retryOperation(async () => {
          return await prisma.filter_Options.findFirst({
            where: {
              filter_option_shop_filter_id: filter.shop_filter_id,
              filter_option_value: value,
            },
          });
        });

        if (!exists) {
          await await retryOperation(async () => {
            return await prisma.filter_Options.create({
              data: {
                filter_option_shop_filter_id: filter.shop_filter_id,
                filter_option_value: value,
                created_at: new Date().toISOString(),
                updated_at: new Date().toISOString(),
              },
            });
          });
        }
      }
    }
  }
};
