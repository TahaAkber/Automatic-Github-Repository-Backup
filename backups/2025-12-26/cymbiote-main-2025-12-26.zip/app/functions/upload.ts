export const checkVideoSources = async (
  nodeId: string,
  admin: any,
  retryCount = 10,
  delay = 5000,
) => {
  let videoUrl = null;

  for (let i = 0; i < retryCount; i++) {
    const videoNodeQuery = `
        {
          node(id: "${nodeId}") {
            ... on Video {
              sources {
                url
              }
            }
          }
        }
      `;

    const response = await admin.graphql(videoNodeQuery);
    const nodeData = await response.json();

    const sources = nodeData.data?.node?.sources;
    if (sources && sources.length > 0) {
      videoUrl = sources[0].url;
      break;
    }

    // Wait before retrying
    await new Promise((resolve) => setTimeout(resolve, delay));
  }

  return videoUrl;
};
