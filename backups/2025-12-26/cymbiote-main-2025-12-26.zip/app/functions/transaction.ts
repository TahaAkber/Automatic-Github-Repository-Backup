export const fetchFilteredTransactions = async (
  shopId: number,
  startDate: Date,
  endDate: Date,
) => {
  return await prisma.transactions.findMany({
    where: {
      transaction_shop_id: shopId,
      created_date: {
        gte: startDate,
        lte: endDate,
      },
    },
    include: {
      Orders: {
        select: {
          order_id: true,
          order_date: true,
          order_total_amount: true,
          order_delivery_address: true,
          order_fulfillment_status: true,
          order_charge_rate: true,
          order_shopify_id: true,
        },
      },
    },
    orderBy: {
      created_date: "desc",
    },
  });
};

export const fetchAllTransactions = async (
  shopId: number,
  page: number,
  itemsPerPage: number,
) => {
  return await prisma.transactions.findMany({
    where: {
      transaction_shop_id: shopId,
    },
    include: {
      Orders: {
        select: {
          order_id: true,
          order_date: true,
          order_total_amount: true,
          order_delivery_address: true,
          order_fulfillment_status: true,
          order_charge_rate: true,
          order_shopify_id: true,
        },
      },
    },
    skip: (page - 1) * itemsPerPage,
    take: itemsPerPage,
    orderBy: {
      created_date: "desc",
    },
  });
};
