import { Badge, Text } from "@shopify/polaris";
import dayjs from "dayjs";

export const transformOrders = (orders: any[]) => {
  return orders.map((order) => {
    const formattedDate = dayjs(order?.order_date).format("DD MMM YYYY");
    const totalQuantity = order?.Order_Items?.reduce(
      (sum: number, item: any) => sum + (item.order_item_quantity || 0),
      0,
    );

    console.log("Total order items quantity:", totalQuantity);

    let paymentBadge;
    switch (order?.order_payment_status?.toLowerCase()) {
      case "paid":
        paymentBadge = (
          <Badge progress="complete" tone="success">
            Paid
          </Badge>
        );
        break;
      case "partially_paid":
        paymentBadge = (
          <Badge progress="partiallyComplete" tone="attention">
            Partially Paid
          </Badge>
        );
        break;
      default:
        paymentBadge = <Badge progress="incomplete">Unpaid</Badge>;
        break;
    }

    let fulfillmentBadge;
    switch (order.order_fulfillment_status?.toLowerCase()) {
      case "fulfilled":
        fulfillmentBadge = <Badge progress="complete">Fulfilled</Badge>;
        break;
      case "unfulfilled":
        fulfillmentBadge = <Badge progress="incomplete">Unfulfilled</Badge>;
        break;
      case "pending":
        fulfillmentBadge = <Badge progress="partiallyComplete">Pending</Badge>;
        break;
      case "restocked":
        fulfillmentBadge = <Badge progress="complete">ReStocked</Badge>;
        break;
      default:
        fulfillmentBadge = <Badge progress="incomplete">Unfulfilled</Badge>;
        break;
    }

    const totalTransactionAmount =
      order.Transactions?.reduce((total: number, e: any) => {
        const amount = parseFloat(e.transaction_amount) || 0;
        const kind = e.transaction_kind?.toLowerCase();
        let adjustedAmount = 0;

        if (kind === "refund") adjustedAmount = -amount;
        else if (kind === "sale") adjustedAmount = amount;
        else adjustedAmount = amount;

        return total + adjustedAmount;
      }, 0) || 0;

    console.log("Transactions array:", order.Transactions);

    const displayFinancialStatus = () => {
      const status = order?.order_payment_status?.toLowerCase();
      switch (status) {
        case "paid":
          return <Badge tone="success">Paid</Badge>;
        case "pending":
          return <Badge tone="warning">Pending</Badge>;
        case "refunded":
          return <Badge tone="critical">Refunded</Badge>;
        case "partially_refunded":
          return <Badge tone="info">Partially Refunded</Badge>;
        case "voided":
          return <Badge tone="info">Voided</Badge>;
        case "partially_paid":
          return <Badge tone="attention">Partially Paid</Badge>;
        default:
          return (
            <Badge tone="new">
              {order.order_payment_status || "Unknown Status"}
            </Badge>
          );
      }
    };

    return {
      id: `gid://shopify/Order/${order.order_shopify_id}`,
      order_id: order?.order_id,
      order: (
        <Text as="span" variant="bodyMd" fontWeight="semibold">
          {order.order_title}
        </Text>
      ),
      date: formattedDate,
      customer: order.Users?.user_email || "Not available",
      total: ` ${order.order_total_amount.toLocaleString() || "0.00"}`,
      paymentStatus: paymentBadge,
      fulfillmentStatus: fulfillmentBadge,
      totalTransectionAmt: totalTransactionAmount.toFixed(2),

      displayFinancialStatus: displayFinancialStatus(),
      orderRate: order.order_charge_rate || 0,
      totalQuantity: totalQuantity || 0,
      order_delivery_status: order.order_delivery_status || "Not available",
    };
  });
};
