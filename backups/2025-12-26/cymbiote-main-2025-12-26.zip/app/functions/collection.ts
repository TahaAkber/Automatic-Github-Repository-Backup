// Helper function to check if collection is Shopify type
export const isShopifyCollection = (
  collectionId: string,
  tabIndex: number,
  collections: any[],
  filterCollection: any[],
): boolean => {
  if (tabIndex === 0) {
    // Simple Collection tab
    const collection = collections.find(
      (c) => c.collection_shopify_id === collectionId,
    );
    return collection?.collection_is_shopify === true;
  } else if (tabIndex === 2) {
    // Filter Collection tab
    const collection = filterCollection.find(
      (c) => c.collection_shopify_id === collectionId,
    );
    return collection?.collection_is_shopify === true;
  }
  return false;
};

// Custom selection handler with validation
export const createValidatedSelectionHandler = (
  originalHandler: (
    selectionType: any,
    toggleType: any,
    selection?: any,
  ) => void,
  tabIndex: number,
  collections: any[],
  filterCollection: any[],
  simpleSelected: any[],
  filterSelected: any[],
) => {
  return (selectionType: any, toggleType: any, selection?: any) => {
    // Allow deselection always
    if (toggleType === false) {
      originalHandler(selectionType, toggleType, selection);
      return;
    }

    // For "all" selection, check if it's safe
    if (selectionType === "all") {
      const currentData =
        tabIndex === 0 ? collections : tabIndex === 2 ? filterCollection : [];

      const allShopify = currentData.every(
        (c) => c.collection_is_shopify === true,
      );
      const allNonShopify = currentData.every(
        (c) => c.collection_is_shopify !== true,
      );

      // Only allow if all are same type
      if (allShopify || allNonShopify) {
        originalHandler(selectionType, toggleType, selection);
      }
      return;
    }

    // For single selection
    if (selection) {
      const isCurrentShopify = isShopifyCollection(
        selection,
        tabIndex,
        collections,
        filterCollection,
      );

      // Get current selections
      const currentSelections =
        tabIndex === 0 ? simpleSelected : tabIndex === 2 ? filterSelected : [];

      // If first selection, allow
      if (currentSelections.length === 0) {
        originalHandler(selectionType, toggleType, selection);
        return;
      }

      // Check if first selected item is Shopify
      const firstSelectedIsShopify = isShopifyCollection(
        currentSelections[0],
        tabIndex,
        collections,
        filterCollection,
      );

      // Only allow if same type
      if (isCurrentShopify === firstSelectedIsShopify) {
        originalHandler(selectionType, toggleType, selection);
      }
    }
  };
};
