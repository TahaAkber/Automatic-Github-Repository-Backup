import { addMonths, setDate } from "date-fns";

export function getCycleDates(sub: any): {
  start: Date | null;
  end: Date | null;
} {
  const endIso = sub?.currentPeriodEnd;
  if (!endIso) return { start: null, end: null };

  const end = new Date(endIso);

  // interval from pricing details
  const interval =
    sub?.lineItems?.[0]?.plan?.pricingDetails?.interval || "EVERY_30_DAYS";
  const days = interval === "EVERY_365_DAYS" ? 365 : 30;

  // naive start = end - interval
  const start = new Date(end);
  start.setUTCDate(start.getUTCDate() - days);

  // If currently in trial, the “cycle” effectively begins at createdAt
  if (sub.trialDays) {
    const trialEnd = new Date(
      new Date(sub.createdAt).getTime() + sub.trialDays * 86400000,
    );
    if (trialEnd >= end) return { start: new Date(sub.createdAt), end };
  }

  return { start, end };
}

export function toCycleStart(d: Date, billingDay: number) {
  // If date’s day >= billingDay → cycle start is this month’s billingDay; else previous month’s
  const monthStartCandidate = setDate(new Date(d), billingDay);
  return d.getDate() >= billingDay
    ? monthStartCandidate
    : setDate(addMonths(new Date(d), -1), billingDay);
}

const fmt = new Intl.DateTimeFormat("en-US", {
  month: "long",
  day: "numeric",
  year: "numeric",
});

/** Safely create a UTC date at 00:00 */
function utcDate(y: number, m: number, d: number) {
  return new Date(Date.UTC(y, m, d, 0, 0, 0, 0));
}

/** Days in month (UTC) */
function daysInMonthUTC(y: number, m: number) {
  return new Date(Date.UTC(y, m + 1, 0)).getUTCDate();
}

/** Set day safely: if billingDay > daysInMonth, clamp to last day */
export function setUTCDateClamped(dt: Date, day: number) {
  const y = dt.getUTCFullYear();
  const m = dt.getUTCMonth();
  const max = daysInMonthUTC(y, m);
  return utcDate(y, m, Math.min(day, max));
}

/** Add months (UTC) while keeping/clamping day */
export function addMonthsUTC(dt: Date, months: number, keepDay?: number) {
  const y = dt.getUTCFullYear();
  const m = dt.getUTCMonth();
  const target = utcDate(y, m + months, 1);
  const day = keepDay ?? dt.getUTCDate();
  return setUTCDateClamped(target, day);
}

/**
 * Compute the cycle start for a given transaction date:
 * If date’s day >= billingDay → cycle starts this month on billingDay (clamped)
 * else → previous month on billingDay (clamped)
 */
export function toCycleStartUTC(d: Date, billingDay: number) {
  const y = d.getUTCFullYear();
  const m = d.getUTCMonth();
  const day = d.getUTCDate();
  if (day >= billingDay) {
    return setUTCDateClamped(utcDate(y, m, 1), billingDay);
  } else {
    const prev = utcDate(y, m - 1, 1);
    return setUTCDateClamped(prev, billingDay);
  }
}

/** Pretty label: "Billing Cycle from {start} to {end-1}" */
export function makeLabel(fromUTC: Date, toUTC: Date) {
  const endMinus1 = new Date(toUTC.getTime() - 24 * 60 * 60 * 1000);
  return `Billing Cycle from ${fmt.format(fromUTC)} to ${fmt.format(endMinus1)}`;
}

type Tx = { created_date: Date };

export function buildBillingCycleOptions(
  txs: Tx[],
  billingDay: number
): Array<{ label: string; value: { gte: Date; lt: Date } }> {
  // Map each tx to its cycleStart (UTC @ 00:00)
  const cycleStarts = txs.map(t => toCycleStartUTC(new Date(t.created_date), billingDay));

  // Unique + sort ascending
  const uniqueKeys = new Map<string, Date>();
  for (const cs of cycleStarts) {
    uniqueKeys.set(cs.toISOString(), cs);
  }
  const starts = [...uniqueKeys.values()].sort((a, b) => a.getTime() - b.getTime());

  // Build options: gte = cycleStart, lt = nextMonth(cycleStart, same billingDay)
  return starts.map(start => {
    const lt = addMonthsUTC(start, 1, billingDay);
    return {
      label: makeLabel(start, lt),
      value: { gte: start, lt },
    };
  });
}