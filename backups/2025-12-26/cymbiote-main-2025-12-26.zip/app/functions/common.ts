import axios from "axios";
import { API_KEY, API_URL } from "~/routes/app._index";

// Note that this method is not a function component, but rather, a simple file containing helper functions
export const wait = (ms: number) => new Promise((res) => setTimeout(res, ms));

export function disambiguateLabel(key: string, value: string | any[]): string {
  switch (key) {
    case "moneySpent":
      return `Money spent is between $${value[0]} and $${value[1]}`;
    case "taggedWith":
      return `Tagged with ${value}`;
    case "accountStatus":
      return (value as string[]).map((val) => `Customer ${val}`).join(", ");
    default:
      return value as string;
  }
}

export function isEmpty(value: string | any[]) {
  if (Array.isArray(value)) {
    return value.length === 0;
  } else {
    return value === "" || value == null;
  }
}

export function removeNonNumericCharacters(input: string): number {
  return parseInt(input.replace(/\D/g, "")); // \D matches any non-digit character
}

export async function uploadToShopify(
  file: File,
  admin: any,
  fileName: string,
  uploadType = "IMAGE",
) {
  const stagedUploadQuery = `
    mutation stagedUploadsCreate($input: [StagedUploadInput!]!) {
      stagedUploadsCreate(input: $input) {
        stagedTargets {
          url
          resourceUrl
          parameters {
            name
            value
          }
        }
        userErrors {
          field
          message
        }
      }
    }
  `;

  const stagedUploadVariables = {
    input: [
      {
        filename: fileName + "_" + file.name,
        mimeType: file.type,
        resource: uploadType === "IMAGE" ? "FILE" : "VIDEO",
        httpMethod: "POST",
        fileSize: `${file.size}`,
      },
    ],
  };

  console.log("stagedUploadVariables", stagedUploadVariables);

  const stagedUploadResponse = await admin.graphql(stagedUploadQuery, {
    variables: stagedUploadVariables,
  });

  let parsedData = await stagedUploadResponse.json();

  const { stagedTargets, userErrors } = parsedData.data.stagedUploadsCreate;

  if (userErrors.length > 0) {
    throw new Error(userErrors[0].message);
  }

  const { url: uploadUrl, resourceUrl, parameters } = stagedTargets[0];

  // Step 2: Upload the file to Shopify's S3
  const formDataToUpload = new FormData();
  parameters.forEach(({ name, value }: { name: string; value: string }) =>
    formDataToUpload.append(name, value),
  );
  formDataToUpload.append("file", file);

  const s3Response = await fetch(uploadUrl, {
    method: "POST",
    body: formDataToUpload,
  });

  if (!s3Response.ok) {
    throw new Error("Failed to upload file to S3");
  }

  // Step 3: Use `fileCreate` to link the file to Shopify
  const fileCreateQuery = `
    mutation fileCreate($files: [FileCreateInput!]!) {
      fileCreate(files: $files) {
        files {
          id
          alt
          createdAt
          fileStatus
          preview {
            image {
              url
              altText
              width
              height
              id
            }
          }
        }
        userErrors {
          field
          message
        }
      }
    }
  `;

  const fileCreateVariables = {
    files: [
      {
        alt: "Uploaded Banner",
        originalSource: resourceUrl,
        contentType: uploadType,
      },
    ],
  };

  console.log("fileCreateVariables", fileCreateVariables);

  const fileCreateResponse = await admin.graphql(fileCreateQuery, {
    variables: fileCreateVariables,
  });

  parsedData = await fileCreateResponse.json();

  const fileCreateData = parsedData.data.fileCreate;

  console.log("fileCreateData", fileCreateData.files);

  if (fileCreateData.userErrors.length > 0) {
    throw new Error(fileCreateData.userErrors[0].message);
  }

  return fileCreateData.files[0].id;
}

export function getCurrentTime() {
  const now = new Date();

  let hours = now.getHours();
  const minutes = now.getMinutes();
  const amPm = hours >= 12 ? "PM" : "AM";

  // Convert to 12-hour format
  hours = hours % 12 || 12;

  // Pad minutes with leading zero if needed
  const formattedMinutes = minutes < 10 ? `0${minutes}` : minutes;

  return `${hours}:${formattedMinutes} ${amPm}`;
}

export const getCurrentCurrencyRate = async (
  currency: string,
  convertingCurrency: string,
  EXCHANGE_API_URL: string = API_URL,
  EXCHANGE_API_KEY: string = API_KEY,
): Promise<number> => {
  const CURRENCY_RATES_API = `${EXCHANGE_API_URL}/${EXCHANGE_API_KEY}/latest/${currency}`;
  console.log(`Fetching currency rates from: ${CURRENCY_RATES_API}`);
  let currentUSDRate = 0;

  try {
    if (!EXCHANGE_API_KEY && !EXCHANGE_API_URL) {
      throw new Error("Missing Exchange API credentials");
    }
    const currentRates = await axios.get(CURRENCY_RATES_API);

    if (
      currentRates.status === 200 &&
      currentRates.data?.conversion_rates?.[convertingCurrency]
    ) {
      currentUSDRate = parseFloat(
        currentRates.data.conversion_rates[convertingCurrency],
      );

      console.log(
        `Current ${currency} to ${convertingCurrency} rate:`,
        currentUSDRate,
      );
    } else {
      console.warn("Conversion rate not found in response");
    }
  } catch (error) {
    console.error("Failed to fetch currency rates:", error);
  }

  return currentUSDRate;
};

export async function fetchGoogleTaxonomy() {
  const response = await fetch(
    "https://www.google.com/basepages/producttype/taxonomy.en-US.txt",
  );
  const data = await response.text();
  const categories = data
    .split("\n")
    .filter((line) => line && !line.startsWith("#"));
  return categories;
}

// Function to convert month number to name
export const getMonthName = (month: number) => {
  const monthNames = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ];
  return monthNames[month]; // Month is zero-based
};

export function formatToHumanDate(dateString: string) {
  const date = new Date(dateString); // Convert the string to a Date object

  // Create a human-readable date format using toLocaleString
  return date.toLocaleString("en-US", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  });
}

export const retryOperation = async <T>(
  operation: () => Promise<T>,
  retries: number = 5,
  delay: number = 2000, // Delay in ms before retrying
): Promise<T | undefined> => {
  let attempt = 0;

  while (attempt < retries) {
    try {
      return await operation(); // Try the operation
    } catch (error: any) {
      attempt++;
      console.log(
        `Attempt ${attempt} Issue:${error.message} failed. Retrying...`,
      );

      if (attempt >= retries) {
        throw new Error(
          `Operation failed after ${retries} attempts: ${error.message}`,
        );
      }

      // Wait for a delay before retrying
      await new Promise((resolve) => setTimeout(resolve, delay));
    }
  }
};

export function getInitials(str: string): string {
  return str
    .split(" ") // Split the string into words
    .map((word) => word.charAt(0).toUpperCase()) // Get the first character of each word
    .join(""); // Join them together
}

export const getUrlParams = (window?: any) => {
  if (!window || !window.location) {
    return {};
  }
  const params = new URLSearchParams(window.location.search);
  const paramObject: Record<string, string> = {};
  for (const [key, value] of params.entries()) {
    paramObject[key] = value;
  }
  return paramObject;
};
