export async function trimToSeconds(
  file: File,
  seconds = 3,
): Promise<{ clipped: File; tmpDir: string }> {
  const [{ default: ffmpeg }, { default: ffmpegStatic }] = await Promise.all([
    import("fluent-ffmpeg"),
    import("ffmpeg-static"),
  ]);
  const fs = await import("node:fs/promises");
  const fssync = await import("node:fs");
  const path = await import("node:path");
  const os = await import("node:os");

  // @ts-ignore
  ffmpeg.setFfmpegPath(ffmpegStatic as string);

  const tmpDir = await fs.mkdtemp(path.join(os.tmpdir(), "reel-"));
  const inPath = path.join(tmpDir, file.name || "input.mp4");
  const outPath = path.join(tmpDir, `clip-${seconds}s.mp4`);

  const buf = Buffer.from(await file.arrayBuffer());
  await fs.writeFile(inPath, buf);

  // Try fast stream copy first; fallback to re-encode if needed
  async function run(cmdOpts: string[]) {
    await new Promise<void>((resolve, reject) => {
      // @ts-ignore
      ffmpeg(inPath)
        .outputOptions(cmdOpts)
        .on("end", () => resolve())
        .on("error", reject)
        .save(outPath);
    });
  }

  try {
    await run([`-t ${seconds}`, "-c copy"]);
  } catch {
    await run([
      `-t ${seconds}`,
      "-c:v libx264",
      "-preset veryfast",
      "-crf 23",
      "-c:a aac",
      "-movflags +faststart",
    ]);
  }

  const clippedBuffer = await fs.readFile(outPath);
  const clipped = new File([clippedBuffer], `clip-${seconds}s.mp4`, {
    type: "video/mp4",
  });
  return { clipped, tmpDir };
}
