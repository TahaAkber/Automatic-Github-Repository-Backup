import { redirect } from "@remix-run/node";
import { AdminApiContext } from "@shopify/shopify-app-remix/server";
import { setDiscountValueInMetafield } from "~/mutations/updateMetafield";
import { getProductFromShopify } from "~/queries/getProduct";
import { productsQuery } from "~/queries/product";
import { Image } from "~/types/Products/Image";
import { ProductCategory } from "~/types/Products/ProductCategory";
import { Variant } from "~/types/Products/Variants";
import { retryOperation, wait } from "./common";
import { fetchMetaobjectDetails, Metaobject } from "~/queries/metafields";
import { ShopifyProduct } from "~/types/Products/ShopifyProduct";
import { Prisma } from "@prisma/client";

const MAX_CONCURRENT_REQUESTS = 5;
const THROTTLE_THRESHOLD = 500;

const fetchProductWithThrottleCheck = async (
  productId: string,
  admin: AdminApiContext,
): Promise<ShopifyProduct | null> => {
  let attempt = 0;
  const maxAttempts = 3; // Retry the request up to 3 times in case of throttle

  while (attempt < maxAttempts) {
    try {
      const { jbody, status } = await getProductFromShopify(productId, admin);

      if (!jbody?.data?.product && status !== 200) {
        return null;
      }

      // If throttle is too high, wait before retrying
      if (
        jbody?.extensions?.cost?.throttleStatus?.currentlyAvailable <
        THROTTLE_THRESHOLD
      ) {
        console.log("Waiting to recover from throttle...");
        await wait(1000); // Wait for a short time before retrying
      } else {
        return jbody.data.product; // Return the product if no throttle issue
      }
    } catch (error: any) {
      console.error(`Error fetching product ${productId}: ${error.message}`);
      return null;
    }

    attempt++;
  }

  return null; // Return null after exceeding max attempts
};

// Fetch products with throttle handling
const fetchProductsWithThrottleHandling = async (
  productIds: string[],
  admin: AdminApiContext,
): Promise<ShopifyProduct[]> => {
  const results: ShopifyProduct[] = [];

  // Process requests sequentially but limit the concurrent ones
  for (let i = 0; i < productIds.length; i += MAX_CONCURRENT_REQUESTS) {
    const batch = productIds.slice(i, i + MAX_CONCURRENT_REQUESTS);

    // Fetch products with throttle handling in parallel for each batch
    const batchResults = await Promise.all(
      batch.map(async (productId) =>
        fetchProductWithThrottleCheck(productId, admin),
      ),
    );

    // Filter out null values (failed requests)
    results.push(
      ...batchResults.filter(
        (product): product is ShopifyProduct => product !== null,
      ),
    );

    // Optionally, wait a bit between batches if needed
    await wait(500); // You can adjust this based on your needs
  }

  return results;
};

export const addCatalogItems = async (
  shopDomain: string,
  queryString: string,
  productIds: string[],
  productCategories: ProductCategory[],
  admin: AdminApiContext,
) => {
  console.log("addCatalogItems", shopDomain, productIds, productCategories);
  let currentProcess = "function start";
  try {
    // Fetch shop details with retry logic
    currentProcess = "fetching shop details";
    const shop = await retryOperation(async () => {
      return await prisma.shops.findFirst({
        where: {
          shop_domain: shopDomain,
        },
      });
    });

    if (!shop) throw new Error(`Shop with domain ${shopDomain} not found`);

    currentProcess = "checking subscription";
    // Check if the subscription is confirmed with retry logic
    const checkSub = await retryOperation(async () => {
      return await prisma.subscriptions.findFirst({
        where: {
          Shops: {
            shop_domain: shopDomain,
          },
          subscription_confirmed: true,
        },
      });
    });

    if (!checkSub) {
      console.log("No subscription found", checkSub);
      return redirect(`/app/subscription?${queryString}`);
    }

    currentProcess = "fetching shopify products";
    // Fetch details for the selected products from Shopify
    const shopifyProducts = await fetchProductsWithThrottleHandling(
      productIds,
      admin,
    );

    if (
      !shopifyProducts ||
      shopifyProducts.every((product) => product === null)
    ) {
      console.log("No products found");
      return; // No products found to process
    }

    currentProcess = "inserting products started";
    const insertedProducts = await Promise.all(
      shopifyProducts.map(async (product: any) => {
        if (!product) return; // Skip if product is null due to error above

        let customCategory = productCategories.find(
          (e) => e.productId === product?.id,
        )?.productCategory;
        let customCategoryId = productCategories.find(
          (e) => e.productId === product?.id,
        )?.productCategoryId;
        let customCategoryFullname = productCategories.find(
          (e) => e.productId === product?.id,
        );
        let customBrandId = productCategories.find(
          (e) => e.productId === product?.id,
        )?.brandId;

        const prodImage = product?.images as Image | undefined;
        const imgSrc =
          prodImage?.nodes &&
          Array.isArray(prodImage?.nodes) &&
          prodImage.nodes.length > 0
            ? prodImage.nodes.map((img) => img?.url)
            : [];
        const mainImage = imgSrc.length > 0 ? imgSrc[0] : "";
        const productTags = product?.tags ? product.tags.join(",") : "";

        console.log("productTags", productTags);

        currentProcess = "checking if product exists";
        // Check if the product already exists in the database
        const existingProduct = await retryOperation(async () => {
          return await prisma.products.findFirst({
            where: { product_shopify_id: product.id },
          });
        });

        // metafield processing
        const metafields = product.metafields.edges.map((e: any) => e.node);

        const metaobjectGids: string[] = [];

        currentProcess = "checking subscription";
        metafields.forEach((field: any) => {
          if (field.type.includes("metaobject_reference")) {
            try {
              const parsed = JSON.parse(field.value); // list = JSON array, single = string
              if (Array.isArray(parsed)) {
                metaobjectGids.push(...parsed);
              } else if (typeof parsed === "string") {
                metaobjectGids.push(parsed);
              }
            } catch (err) {
              // fallback if it's not JSON
              if (
                typeof field.value === "string" &&
                field.value.startsWith("gid://shopify/Metaobject/")
              ) {
                metaobjectGids.push(field.value);
              }
            }
          }
        });

        currentProcess = "fetching metaobject details";
        const chunkArray: any = (arr: any[], size: number) =>
          arr.length
            ? [arr.slice(0, size), ...chunkArray(arr.slice(size), size)]
            : [];

        const allMetaobjects: Metaobject[] = [];
        for (const chunk of chunkArray(metaobjectGids, 5)) {
          // batch of 5
          const chunkResults = await fetchMetaobjectDetails(admin, chunk);
          allMetaobjects.push(...chunkResults);
        }
        // const metaobjects = await fetchMetaobjectDetails(admin, metaobjectGids);

        const resolved = metafields
          .filter((field: any) => field.type.includes("metaobject_reference"))
          .map((field: any) => {
            const key = field.definition?.name;

            let gids: string[] = [];
            try {
              const parsed = JSON.parse(field.value);
              gids = Array.isArray(parsed) ? parsed : [parsed];
            } catch {
              if (field.value.startsWith("gid://")) {
                gids = [field.value];
              }
            }

            const matchedValues = allMetaobjects
              .filter((meta) => {
                return gids.includes(meta.id);
              })
              .flatMap((meta) =>
                meta.fields
                  .map((f: any) => f.value)
                  .flatMap((val: any) => {
                    try {
                      const parsed = JSON.parse(val);
                      return Array.isArray(parsed) ? parsed : [parsed];
                    } catch {
                      return [val];
                    }
                  })
                  .filter((v: string) => {
                    if (typeof v !== "string") return false;
                    return v && !v.startsWith("gid://shopify/TaxonomyValue");
                  }),
              );

            return {
              key,
              values: matchedValues,
            };
          })
          .filter((item: any) => item.values.length > 0);

        console.log("🧩 Final structured values per key:", resolved);

        if (existingProduct) {
          currentProcess = "deleting old product images";
          await retryOperation(async () => {
            return await prisma.product_Images.deleteMany({
              where: {
                product_image_product_id: existingProduct.product_id,
              },
            });
          });

          imgSrc?.forEach(async (img) => {
            currentProcess = "inserting product images";
            await retryOperation(async () => {
              return await prisma.product_Images.create({
                data: {
                  product_image_url: img,
                  product_image_product_id: existingProduct.product_id,
                },
              });
            });
          });

          // If the product exists, update it and mark it as active
          currentProcess = "updating existing product";
          const updatedProduct = await retryOperation(async () => {
            return await prisma.products.update({
              where: { product_id: existingProduct.product_id },
              data: {
                product_name: product?.title || "",
                product_description: product?.description || "",
                product_description_html: product?.descriptionHtml || "",
                product_shopify_category:
                  product?.category?.name || "Not available",
                product_image_url: mainImage,
                product_custom_category: customCategory,
                product_custom_category_id: customCategoryId,
                product_custom_category_hierarchy:
                  customCategoryFullname?.categoryFullname,
                product_is_active: true,
                product_metafields: JSON.stringify(resolved),
                ...(customBrandId
                  ? { product_brand_id: parseInt(customBrandId) }
                  : {}),
                product_tags: productTags,
                updated_at: new Date(),
              },
            });
          });

          // Update existing product variants
          const variants = product?.variants?.nodes as Variant[] | undefined;
          const discountedVariants = productCategories.find(
            (e) => e.productId === product?.id,
          )?.DiscountedVariants;

          if (variants && variants.length > 0) {
            await Promise.all(
              variants.map(async (variant: any) => {
                const matchingDiscount = discountedVariants?.find(
                  (dv) => dv.variant_shopify_id === variant.id,
                );
                const options = variant.selectedOptions || [];

                const variantData = {
                  variant_price: parseFloat(variant.price),
                  variant_quantity: variant?.inventoryQuantity,
                  variant_color: variant.option1,
                  variant_name: variant.title,
                  variant_inventory_id: variant.inventoryItem
                    ? variant.inventoryItem.id
                    : "0",
                  variant_image_url: variant.image?.url || mainImage,
                  variant_discounted_price: matchingDiscount
                    ? parseFloat(matchingDiscount.discounted_price)
                    : 0,
                  variant_option_key_one: options[0]?.name || null,
                  variant_option_value_one: options[0]?.value || null,
                  variant_option_key_two: options[1]?.name || null,
                  variant_option_value_two: options[1]?.value || null,
                  variant_option_key_third: options[2]?.name || null,
                  variant_option_value_third: options[2]?.value || null,
                };

                currentProcess = "updating existing variant";
                const existingVariant = await retryOperation(async () => {
                  return await prisma.product_Variants.findFirst({
                    where: { variant_shopify_id: variant.id },
                  });
                });

                if (existingVariant) {
                  currentProcess = "updating existing variant data";
                  await retryOperation(async () => {
                    return await prisma.product_Variants.update({
                      where: { variant_id: existingVariant.variant_id },
                      data: variantData,
                    });
                  });
                } else {
                  currentProcess = "inserting new variant data";
                  await retryOperation(async () => {
                    return await prisma.product_Variants.create({
                      data: {
                        ...variantData,
                        variant_shopify_id: variant.id.toString(),
                        variant_product_id: existingProduct?.product_id,
                      },
                    });
                  });
                }

                if (matchingDiscount) {
                  currentProcess = "setting discount value in metafield";
                  setDiscountValueInMetafield(
                    variant.id,
                    matchingDiscount?.discounted_price as string,
                    admin,
                  );
                }
              }),
            );
          }

          return updatedProduct;
        } else {
          // If the product does not exist, insert it as a new product
          currentProcess = "inserting new product";
          const insertedProduct = await retryOperation(async () => {
            return await prisma.products.create({
              data: {
                product_name: product?.title || "",
                product_description: product?.description || "",
                product_description_html: product?.descriptionHtml || "",
                product_shopify_category:
                  product?.category?.name || "Not available",
                product_image_url: mainImage || "",
                product_shopify_id: product?.id ? product.id.toString() : "",
                product_shop_id: shop?.shop_id || 2,
                product_custom_category: customCategory,
                product_custom_category_hierarchy:
                  customCategoryFullname?.categoryFullname,
                product_custom_category_id: customCategoryId,
                product_is_active: true,
                product_brand_id: customBrandId
                  ? parseInt(customBrandId)
                  : null,
                product_tags: productTags,
                product_metafields: JSON.stringify(resolved),
              },
            });
          });

          if (!insertedProduct) {
            return;
          }

          imgSrc?.forEach(async (img) => {
            currentProcess = "inserting product images";
            await retryOperation(async () => {
              return await prisma.product_Images.create({
                data: {
                  product_image_url: img,
                  product_image_product_id: insertedProduct.product_id,
                },
              });
            });
          });

          const variants = product?.variants?.nodes as Variant[] | undefined;
          const discountedVariants = productCategories.find(
            (e) => e.productId === product?.id,
          )?.DiscountedVariants;

          if (variants && variants.length > 0) {
            const variantsToAdd = variants.map((variant: any) => {
              const matchingDiscount = discountedVariants?.find(
                (dv) => dv.variant_shopify_id === variant.id,
              );
              const options = variant.selectedOptions || [];

              if (matchingDiscount) {
                currentProcess =
                  "setting discount value in metafield for new variant";
                setDiscountValueInMetafield(
                  variant.id,
                  matchingDiscount?.discounted_price as string,
                  admin,
                );
              }
              return {
                variant_shopify_id: variant.id.toString(),
                variant_price: parseFloat(variant.price),
                variant_quantity: variant?.inventoryQuantity,
                variant_color: variant.option1, // Assuming color is stored in option1
                variant_product_id: insertedProduct.product_id, // Foreign key
                variant_name: variant.title,
                variant_inventory_id: variant.inventoryItem
                  ? variant.inventoryItem.id
                  : "0",
                variant_image_url: variant.image?.url || mainImage,
                variant_discounted_price: matchingDiscount
                  ? parseFloat(matchingDiscount.discounted_price)
                  : 0,
                variant_option_key_one: options[0]?.name || null,
                variant_option_value_one: options[0]?.value || null,
                variant_option_key_two: options[1]?.name || null,
                variant_option_value_two: options[1]?.value || null,
                variant_option_key_third: options[2]?.name || null,
                variant_option_value_third: options[2]?.value || null,
              };
            });

            // Insert the variants into the Product_Variants table
            currentProcess = "inserting new variants";
            await retryOperation(async () => {
              return await prisma.product_Variants.createMany({
                data: variantsToAdd,
              });
            });
          }

          return insertedProduct;
        }
      }),
    );

    return insertedProducts;
  } catch (error: any) {
    console.error(
      "Error in addCatalogItems function:",
      currentProcess,
      error.message,
    );
    throw new Error(`Error processing catalog items: ${error.message}`);
  }
};

export const updateCatalogItems = async (
  shopDomain: string,
  products: ProductCategory[],
  productIds: string[],
  admin: AdminApiContext,
) => {
  const shop = await retryOperation(async () => {
    return await prisma.shops.findFirst({
      where: {
        shop_domain: shopDomain,
      },
    });
  });

  if (!shop) {
    console.log("No shop found", shopDomain);
    return null;
  }

  const updates: (Prisma.BatchPayload | undefined)[] = [];

  for (const product of products) {
    const { productId, DiscountedVariants } = product;

    if (!DiscountedVariants || DiscountedVariants.length === 0) continue;

    for (const variant of DiscountedVariants) {
      const existingProduct = await retryOperation(async () => {
        return await prisma.products.findFirst({
          where: { product_shopify_id: productId },
        });
      });
      const updated = await retryOperation(async () => {
        return prisma.product_Variants.updateMany({
          where: {
            variant_shopify_id: variant.variant_shopify_id,
            variant_product_id: existingProduct?.product_id, // assuming this relationship exists
          },
          data: {
            variant_discounted_price: parseFloat(variant.discounted_price),
            updated_at: new Date(), // Ensure to update the timestamp
          },
        });
      });

      updates.push(updated);

      setDiscountValueInMetafield(
        variant.variant_shopify_id,
        variant.discounted_price,
        admin,
      );
    }

    const updatedProducts = await retryOperation(async () => {
      return await prisma.$transaction(updates as any[]);
    });

    const Products = await retryOperation(async () => {
      return await prisma.products.findMany({
        where: {
          product_shop_id: shop?.shop_id,
          product_is_active: true,
        },
      });
    });
    return Products;
  }
};

export const fetchPaginatedProducts = async (
  admin: AdminApiContext,
  direction: "next" | "previous",
  cursor: string | null = null,
  selected: string | "0",
  shopId: number | 0,
  searchTerm: string | undefined = undefined,
) => {
  let allProducts: any[] = [];
  let hasNextPage = true;
  let hasPreviousPage = true;
  let afterCursor: string | null = null;
  let beforeCursor: string | null = null;

  // Set the correct cursor based on the direction (next or previous)
  if (direction === "next") {
    afterCursor = cursor; // For "next", use the provided cursor as the afterCursor
  } else if (direction === "previous") {
    beforeCursor = cursor; // For "previous", use the provided cursor as the beforeCursor
  }

  let productsFetchQuery = "status:ACTIVE";

  if (searchTerm) {
    productsFetchQuery += ` AND (title:*${searchTerm}*)`;
  }

  console.log("selected", selected);
  if (selected === "0") {
    const publishedProducts = await retryOperation(async () => {
      return await prisma.products.findMany({
        where: {
          product_is_active: true,
          product_shop_id: shopId,
        },
      });
    });
    if (publishedProducts && publishedProducts.length > 0) {
      // Ensure we wrap the existing conditions in parentheses if we already have a search query
      const existingQuery = `status:ACTIVE ${publishedProducts.length > 0 ? `AND ${publishedProducts.map((e) => e.product_shopify_id.split("/")[4]).join(" OR ")}` : ""}`;

      if (searchTerm) {
        productsFetchQuery = `${existingQuery} AND (title:*${searchTerm}*)`;
      } else {
        productsFetchQuery = existingQuery;
      }
    }
  } else {
    const publishedProducts = await retryOperation(async () => {
      return await prisma.products.findMany({
        where: {
          product_is_active: true,
          product_shop_id: shopId,
        },
      });
    });

    if (publishedProducts && publishedProducts.length > 0) {
      const existingQuery = `status:ACTIVE ${publishedProducts.length > 0 ? `AND NOT ${publishedProducts.map((e) => e.product_shopify_id.split("/")[4]).join(" AND NOT ")}` : ""}`;

      if (searchTerm) {
        productsFetchQuery = `${existingQuery} AND (title:*${searchTerm}*)`;
      } else {
        productsFetchQuery = existingQuery;
      }
    }
  }

  // Fetch the products
  const shopifyProducts = await productsQuery(
    admin,
    afterCursor,
    beforeCursor,
    productsFetchQuery,
  );

  // Get the products from the current page
  const products = shopifyProducts.data?.products?.nodes ?? [];
  allProducts = [...allProducts, ...products];

  // Update the pagination info
  hasNextPage = shopifyProducts.data?.products?.pageInfo?.hasNextPage;
  hasPreviousPage = shopifyProducts.data?.products?.pageInfo?.hasPreviousPage;
  afterCursor = shopifyProducts.data?.products?.pageInfo?.endCursor;
  beforeCursor = shopifyProducts.data?.products?.pageInfo?.startCursor;

  // Return products along with pagination info
  return {
    products: allProducts,
    hasNextPage,
    hasPreviousPage,
    nextCursor: afterCursor,
    previousCursor: beforeCursor,
  };
};
