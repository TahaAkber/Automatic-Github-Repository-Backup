import { getCurrentCurrencyRate, retryOperation } from "./common";

export const getShopWithSubscription = async (shopDomain: string | null) => {
  if (!shopDomain) throw new Error("Missing shop domain");

  return prisma.shops.findFirst({
    where: { shop_domain: shopDomain },
    include: { Subscriptions: true },
  });
};

export const handleShopSubscription = async (
  shop: any,
  tileTypeId: string | null,
  chargesId: string | null,
  activeSub: any[],
  EXCHANGE_API_URL: string,
  EXCHANGE_API_KEY: string,
) => {
  const tileType = parseInt(tileTypeId || "0");

  const oldSubscriptions = await prisma.subscriptions.findMany({
    where: {
      subscription_shop_id: shop?.shop_id,
      subscription_confirmation_id: {
        not: chargesId, // Don't delete the one with the new confirmation ID
      },
      subscription_confirmed: true,
      subscription_enabled: true,
    },
    include: { Packages: true },
  });

  if (oldSubscriptions.length > 0) {
    // discontinue old subscriptions
    const updatePromises = oldSubscriptions.map((sub) =>
      prisma.subscriptions.update({
        where: { subscription_id: sub.subscription_id },
        data: {
          subscription_enabled: false,
          subscription_ends_at: new Date(),
        },
      }),
    );

    await Promise.all(updatePromises);
    console.log(`Deleted ${oldSubscriptions.length} old subscriptions.`);
  } else {
    console.warn("No old subscriptions found to delete.");
  }

  const newSubscription = await prisma.subscriptions.findFirst({
    where: {
      subscription_confirmation_id: chargesId,
    },
  });

  const tile = await prisma.shop_Tiles.findFirst({
    where: { shop_tile_id: tileType },
  });

  const conversionRate = await getCurrentCurrencyRate(
    "USD",
    shop?.shop_currency || "PKR",
    EXCHANGE_API_URL,
    EXCHANGE_API_KEY,
  );

  let baseSubscriptionCharge =
    oldSubscriptions[0]?.Packages.package_charges || 0;
  let baseTileCharge = tile?.shop_tile_charges || 0;
  let baseTrackingCharge = 0; // The third charge component, initialized to zero

  // Calculate the individual converted charges
  const subscriptionChargeConverted = baseSubscriptionCharge * conversionRate;
  const tileChargeConverted = baseTileCharge * conversionRate;
  let trackingChargeConverted = 0; // Converted tracking charge, initialized to zero

  // Check for and apply tracking charges
  if (shop && shop.shop_active_tracking) {
    // Note: await inside an if block is fine if the scope handles it
    const adminSettings = await prisma.admin_Settings.findFirst();

    if (adminSettings) {
      // Capture the base and converted tracking charge values
      baseTrackingCharge = adminSettings.admin_tracking_sub_charges;
      trackingChargeConverted = baseTrackingCharge * conversionRate;
    }
  }

  // Calculate the total charges before and after conversion by summing all three components
  const totalChargePreConversion =
    baseSubscriptionCharge + baseTileCharge + baseTrackingCharge;
  const totalChargePostConversion =
    subscriptionChargeConverted + tileChargeConverted + trackingChargeConverted;

  if (newSubscription) {
    await prisma.subscriptions.update({
      where: { subscription_id: newSubscription.subscription_id },
      data: {
        subscription_confirmed: true,
        subscription_enabled: true,
        subscription_charge_date: new Date(),
        subscription_ends_at: activeSub[0]?.currentPeriodEnd || new Date(),
      },
    });

    await prisma.transactions.create({
      data: {
        transaction_amount_usd: totalChargePreConversion,
        transaction_amount: totalChargePostConversion,
        transaction_detail: `Subscribed ${oldSubscriptions[0]?.Packages.package_name} with a shop tile subscription${shop?.shop_active_tracking ? ` and with tracking subscription` : ``}`,
        transaction_shop_id: shop?.shop_id,
        transaction_subscription_id:
          newSubscription?.subscription_id ||
          oldSubscriptions[0]?.subscription_id,
        transaction_type: "subscription",
        transaction_kind: "recurring",
        transaction_currency: shop?.shop_currency || "PKR",
        created_date: new Date(),
      },
    });
  } else {
    console.error("No new subscription found with this chargesId");
  }

  console.log("newsubscription", newSubscription);
  const updatedShop = await prisma.shops.update({
    where: { shop_id: shop?.shop_id },
    data: {
      shop_tile_type: tileType,
      shop_tile_subscribed: tileType >= 7,
    },
    include: { Subscriptions: true },
  });

  return updatedShop;
};

export const createLayoutIfMissing = async (shopId: number | undefined) => {
  if (!shopId) return null;

  const layout = await prisma.layout_Sequence.findFirst({
    where: { layout_shop_id: shopId },
  });

  if (!layout) {
    await prisma.layout_Sequence.create({
      data: {
        layout_sequence_one: "banner",
        layout_sequence_two: "filters",
        layout_sequence_three: "productCards",
        layout_sequence_four: "productItemsList",
        layout_sequence_five: "productVideos",
        layout_shop_id: shopId,
      },
    });
    return [
      "banner",
      "filters",
      "productCards",
      "productItemsList",
      "productVideos",
    ];
  }

  return [
    layout.layout_sequence_one,
    layout.layout_sequence_two,
    layout.layout_sequence_three,
    layout.layout_sequence_four,
    layout.layout_sequence_five,
  ];
};

export const getTilesOptions = async (shop: any) => {
  const tiles = await prisma.shop_Tiles.findMany({
    include: { Permitted_Tile_Packages: true },
  });

  return tiles.map((tile) => {
    const permitted = tile.Permitted_Tile_Packages.some(
      (p) => p.package_id === shop?.Subscriptions[0]?.subscription_package_id,
    );

    return {
      label: tile.shop_tile_name,
      value: tile.shop_tile_id.toString(),
      disabled: !permitted,
      helpText: permitted
        ? tile.shop_tile_charges > 0
          ? `${tile.shop_tile_charges}$ monthly`
          : "Free"
        : "Not available in this package",
      tileUrl: tile.shop_tile_url,
      tileCharges: tile.shop_tile_charges,
      tileType: tile.shop_tile_type,
    };
  });
};

export const getShopProducts = async (shopDomain: string | null) => {
  if (!shopDomain) return [];

  return await retryOperation(async () => {
    return prisma.products.findMany({
      where: {
        product_is_active: true,
        Shops: { shop_domain: shopDomain },
      },
      include: {
        Product_Variants: true,
      },
      take: 6,
    });
  });
};

export const getFiltersAndOptions = async (shopId: number | undefined) => {
  if (!shopId) return { filters: [], filterOptions: {} };

  const filtersData = await retryOperation(async () => {
    return await prisma.shop_Filters.findMany({
      where: { shop_filter_shop_id: shopId },
      include: { Filter_Options: true },
    });
  });

  const filters = (filtersData ?? []).map((f) => f.shop_filter_value);
  const filterOptions = (filtersData ?? []).reduce(
    (acc, filter) => {
      acc[filter.shop_filter_value] = filter.Filter_Options.map(
        (opt) => opt.filter_option_value,
      );
      return acc;
    },
    {} as Record<string, string[]>,
  );

  return { filters, filterOptions };
};

export const getfilterCollections = async (shopId: number | undefined) => {
  if (!shopId) return;

  const filtersData = await prisma.collections.findMany({
    where: { collection_type_id: 3 },
  });

  return filtersData;
};

export const getsimpleCollections = async (shopId: number | undefined) => {
  if (!shopId) return;

  const simplecollection = await prisma.collections.findMany({
    where: { collection_type_id: 1, collection_shop_id: shopId },
  });

  return simplecollection;
};

export const getshopBannerLogo = async (shopId: number | undefined) => {
  if (!shopId) return;
  const bannerUrl = await retryOperation(async () => {
    return await prisma.shops.findFirst({
      where: { shop_id: shopId },
    });
  });
  return bannerUrl?.shop_banner_url;
};

export const getshopreviews = async (shopId: number | undefined) => {
  if (!shopId) return;

  const orders = await retryOperation(async () => {
    return await prisma.orders.findMany({
      where: {
        order_shop_id: shopId,
      },
      include: {
        Order_Items: {
          include: {
            _count: {
              select: {
                Order_Item_Review: true,
              },
            },
          },
        },
      },
    });
  });
  let result = 0;
  const order = orders?.forEach((order) => {
    order.Order_Items.forEach((item) => {
      result += item._count.Order_Item_Review;
    });
  });

  return result;
};

export const getshopvideos = async (shopId: number | undefined) => {
  const videos = await retryOperation(async () => {
    return await prisma.shops.findMany({
      where: {
        shop_id: shopId,
      },
      include: {
        Videos: true,
      },
    });
  });

  const videoUrls = videos?.flatMap((shop) =>
    shop.Videos.map((video) => ({
      video_url: video.video_url,
      thumbnail_url: video.video_thumbnail_url,
    })),
  );

  return videoUrls;
};
