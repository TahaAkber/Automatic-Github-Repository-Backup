import { PrismaClient } from "@prisma/client";

declare global {
  var prisma: PrismaClient;
}

const prisma: PrismaClient = global.prisma || new PrismaClient();

if (process.env.NODE_ENV !== "production") {
  if (!global.prisma) {
    console.log("NODE_ENV", process.env.NODE_ENV);
    global.prisma = new PrismaClient();
  }
} else {
  // In production, just create a new instance of Prisma Client
  global.prisma = new PrismaClient();
}

export default prisma;
