import {
  ActionFunctionArgs,
  json,
  LoaderFunctionArgs,
  redirect,
  TypedResponse,
} from "@remix-run/node";
import {
  useFetcher,
  useLoaderData,
  useNavigate,
  useParams,
  useSubmit,
} from "@remix-run/react";
import {
  BlockStack,
  Box,
  Button,
  Card,
  DataTable,
  InlineStack,
  Link,
  Page,
  TableData,
  Text,
} from "@shopify/polaris";
import { useCallback, useEffect, useState } from "react";
// import { CalendarButton } from "~/components/common/CalendarButton";
import { Loader } from "~/components/common/Loader";
import { formatToHumanDate, retryOperation } from "~/functions/common";
import {
  fetchAllTransactions,
  fetchFilteredTransactions,
} from "~/functions/transaction";
import { authenticate } from "~/shopify.server";
import { Transaction } from "~/types/TrasectionsLoaderReturn";
import { jsPDF } from "jspdf";
import autoTable from "jspdf-autotable";
import { PrintIcon } from "@shopify/polaris-icons";
import { SubscriptionLoaderReturn } from "~/types/Subscriptions/SubscriptionLoaderReturn";

type ActionResponse = {
  success: boolean;
  message: string;
  transactions: any[];
  totalTransactions: number;
  itemsPerPage: number;
  currentPage: number;
  search: string;
};

export const loader = async ({
  request,
  params: p,
}: LoaderFunctionArgs): Promise<TypedResponse<SubscriptionLoaderReturn>> => {
  const { admin } = await authenticate.admin(request);
  const url = new URL(request.url);

  const shopDomain = url.searchParams.get("shop");
  const page = Number(url.searchParams.get("page")) || 1;
  const itemsPerPage = 10; // Number of items per page
  const skip = (page - 1) * itemsPerPage;

  // Load session using the shop domain
  const shop = await prisma.shops.findFirst({
    where: {
      shop_domain: shopDomain,
    },
    include: {
      Subscriptions: {
        where: {
          subscription_enabled: true,
          subscription_confirmed: true,
        },
      },
    },
  });
  // console.log("papa", p);

  try {
    // const appInstalledData = await fetchAppInstallation(admin);

    // Fetch total count of transactions
    const totalTransactions = await prisma.transactions.count({
      where: {
        transaction_shop_id: shop?.shop_id,
        transaction_subscription_id: Number(p.subId),
      },
    });

    const billingCycle = {
      start: shop?.Subscriptions[0]?.subscription_charge_date || new Date(),
      end: shop?.Subscriptions[0]?.subscription_ends_at || new Date(),
    };

    const txs = await prisma.transactions.findMany({
      where: {
        transaction_shop_id: shop?.shop_id,
        transaction_subscription_id: Number(p.subId),
      },
      select: { transaction_id: true, created_date: true },
    });

    // Fetch transactions with their associated order details with pagination
    const transactionsWithOrders = await retryOperation(async () => {
      return await prisma.transactions.findMany({
        where: {
          transaction_shop_id: shop?.shop_id,
          transaction_subscription_id: Number(p.subId),
        },
        include: {
          Orders: {
            select: {
              order_id: true,
              order_date: true,
              order_total_amount: true,
              order_delivery_address: true,
              order_fulfillment_status: true,
              order_charge_rate: true,
              order_shopify_id: true,
            },
          },
        },
        skip,
        take: itemsPerPage,
        orderBy: {
          created_date: "desc",
        },
      });
    });

    return json({
      transactions: transactionsWithOrders || [],
      totalTransactions,
      itemsPerPage,
      currentPage: page,
      search: url.search,
      billingCycle,
    });
  } catch (error) {
    console.error("Error getting transactions:", error);
    throw new Response("Error getting transactions", {
      status: 500,
    });
  }
};

export const action = async ({ request }: ActionFunctionArgs) => {
  console.log("transaction action called");
  const url = new URL(request.url);
  const params = new URLSearchParams(url.search);
  const queryString = params.toString();
  const shopDomain = url.searchParams.get("shop");
  const page = 1;
  const itemsPerPage = 10; // Number of items per page

  // Load session using the shop domain
  const shop = await prisma.shops.findFirst({
    where: {
      shop_domain: shopDomain,
    },
  });

  if (!shop) {
    return json(
      {
        error: "shop not found",
      },
      { status: 404 },
    );
  }

  const formData = await request.formData();
  const actionType = formData.get("actionType") as string;

  if (actionType === "filterTransactions") {
    const startDate = new Date(formData.get("startDate") as string);
    const endDate = new Date(formData.get("endDate") as string);
    const currentDatetime = new Date();

    // Check if the dates match today's date
    const isToday =
      startDate.toDateString() === currentDatetime.toDateString() &&
      endDate.toDateString() === currentDatetime.toDateString();

    if (isToday) {
      // Reset filter if dates match today's date
      const totalTransactions = await prisma.transactions.count({
        where: {
          transaction_shop_id: shop?.shop_id,
        },
      });

      const transactionsWithOrders = await fetchAllTransactions(
        shop?.shop_id,
        page,
        itemsPerPage,
      );

      return json({
        transactions: transactionsWithOrders || [],
        totalTransactions,
        itemsPerPage,
        currentPage: page,
        search: url.search,
        message: "All Transactions fetched",
        success: true,
      });
    } else {
      // Fetch filtered transactions based on the selected date range
      const transactionsWithOrders = await fetchFilteredTransactions(
        shop?.shop_id,
        startDate,
        endDate,
      );

      return json({
        transactions: transactionsWithOrders || [],
        totalTransactions: transactionsWithOrders.length,
        itemsPerPage, // Assuming a fixed number of items per page
        currentPage: 1, // Reset to first page after filtering
        search: url.search,
        message: "Transactions filtered successfully",
        success: true,
      });
    }
  } else {
    const orderId = formData.get("orderId") as string;
    const updateSessions = await prisma.shops.update({
      data: {
        shop_selectedOrder: orderId,
        updated_at: new Date(),
      },
      where: {
        shop_id: shop?.shop_id,
      },
    });

    const redirectUrl = `/app/orders/orderdetails?${queryString}`;
    return redirect(redirectUrl);
  }
};

export default function Transactions() {
  const navigate = useNavigate();
  const { subId } = useParams();
  const [actionListActive, setActionListActive] = useState(false);
  const fetcher = useFetcher<ActionResponse>();
  const [currentPage, setcurrentPage] = useState(1);
  const [rangeSelected, setRangeSelected] = useState(false);
  const submit = useSubmit();
  const {
    search,
    transactions,
    totalTransactions,
    itemsPerPage,
    billingCycle,
  } = useLoaderData<SubscriptionLoaderReturn>();
  const [sortedRows, setSortedRows] = useState<TableData[][] | null>(null);
  const [isPostBack, setIsPostBack] = useState(false);
  const [transactionsData, setTransactionsData] =
    useState<Transaction[]>(transactions);
  const [totalTransactionsData, setTotalTransactionsData] =
    useState(totalTransactions);
  const [itemsPerPageData, setItemsPerPageData] = useState(itemsPerPage);
  const [{ month, year }, setDate] = useState({
    month: new Date().getMonth(),
    year: new Date().getFullYear(),
  });
  const [selectedDates, setSelectedDates] = useState({
    start: new Date(),
    end: new Date(),
  });
  const [customSelect, setCustomSelect] = useState(false);

  const handleOnBillingCycleClick = useCallback(() => {
    console.log("Exported action");
    setActionListActive(false);
  }, []);

  const fetchdata = useCallback(async (page: number, search: string) => {
    try {
      setIsPostBack(false);
      const response = await fetch(
        `/api/transactions?page=${page}&subId=${subId}&search=${search}`,
      );
      const data = await response.json();

      if (data.transactions.length) {
        setTransactionsData(data.transactions);
        setTotalTransactionsData(data.totalTransactions);
        setItemsPerPageData(data.itemsPerPage);
        setcurrentPage(page);
      }
      setIsPostBack(true);
    } catch (error) {
      console.error("Error fetching transactions:", error);
    }
  }, []);

  const clearSelectedDates = useCallback(() => {
    setSelectedDates({
      start: new Date(),
      end: new Date(),
    });
    setRangeSelected(false);
    setCustomSelect(false);
  }, []);

  useEffect(() => {
    const currentDate = new Date();

    // Skip if start and end dates are the same and not today's date, or if it's a postback
    if (
      (selectedDates.start.getDate() === selectedDates.end.getDate() &&
        selectedDates.start.getDate() !== currentDate.getDate()) ||
      !isPostBack
    ) {
      return;
    }

    // Set rangeSelected to true if the start date is different from today, else false
    setRangeSelected(
      selectedDates.start.toDateString() !== currentDate.toDateString(),
    );

    setIsPostBack(false);

    // Prepare and submit the form data
    const form = new FormData();
    form.append("startDate", selectedDates.start.toISOString());
    form.append("endDate", selectedDates.end.toISOString());
    form.append("actionType", "filterTransactions");

    fetcher.submit(form, { method: "POST" });
  }, [selectedDates]);

  useEffect(() => {
    setIsPostBack(true);
  }, []);

  useEffect(() => {
    if (
      fetcher.data &&
      fetcher.data.success &&
      fetcher.data?.transactions?.length > 0
    ) {
      console.log("fetcher.data", fetcher.data);
      setTransactionsData(fetcher.data.transactions);
      setTotalTransactionsData(fetcher.data.totalTransactions);
      setItemsPerPageData(fetcher.data.itemsPerPage);
      setcurrentPage(fetcher.data.currentPage);
    }
    setIsPostBack(true);
  }, [fetcher.data]);

  const createTableData = (transactionsData: Transaction[]): TableData[][] => {
    return transactionsData.map((transactionData) => {
      // 1. Determine if this is a Credit (Negative)
      const isCredit =
        transactionData.transaction_type.toLowerCase() === "credit";
      const multiplier = isCredit ? -1 : 1;

      // 2. Calculate Values
      // Assuming transactionData.transaction_amount is a number (based on your .toFixed usage)
      const txnAmt = transactionData.transaction_amount * multiplier;
      const usdAmt = transactionData.transaction_amount_usd || 0; // Keep positive for formatting logic below

      let orderAmtDisplay = "-";
      if (transactionData?.Orders) {
        const rawOrderAmt = transactionData.Orders.order_total_amount;
        // Apply multiplier to order amount too, if you want that column to reflect negative on refunds
        orderAmtDisplay = (rawOrderAmt * multiplier).toFixed(2) + " PKR";
      }

      // 3. Format USD (cleaner negative placement: "-$10" instead of "$-10")
      const usdDisplay = isCredit
        ? `-$${usdAmt.toFixed(2)}`
        : `$${usdAmt.toFixed(2)}`;

      return [
        <Link
          removeUnderline
          onClick={() =>
            selectTrasaction(transactionData.Orders.order_id.toString())
          }
          key={transactionData.transaction_order_id + "abc"}
        >
          {transactionData.transaction_detail}
        </Link>,
        `${
          transactionData?.Orders
            ? transactionData?.Orders?.order_charge_rate.toFixed(2) + "%"
            : "-"
        }`,
        transactionData.transaction_type.toUpperCase(),
        formatToHumanDate(transactionData.created_date.toString()),

        // Updated Columns:
        orderAmtDisplay, // Order Amount
        `${txnAmt.toFixed(3)} PKR`, // Txn Amount (Negative if credit)
        usdDisplay, // USD Amount (Negative if credit)
      ];
    });
  };

  const initiallySortedRows = createTableData(transactionsData);
  // console.log("initiallySortedRows", initiallySortedRows, sortedRows);
  const rows = sortedRows ? sortedRows : initiallySortedRows;

  const generatePdf = async () => {
    const doc = new jsPDF("p", "mm", "a4");

    // --- CONFIGURATION ---
    const primaryColor = "#1A73E8";
    const secondaryColor = "#64748B";
    const footerBgColor = "#F1F5F9";
    const marginLeft = 15;
    const marginRight = 15;
    const pageWidth = doc.internal.pageSize.getWidth();
    const currentY = 20;

    // --- 1. HEADER SECTION ---
    doc.setFont("helvetica", "bold");
    doc.setFontSize(18);
    doc.setTextColor(primaryColor);
    doc.text("Cercle - Transaction Report", marginLeft, currentY);

    doc.setDrawColor(primaryColor);
    doc.setLineWidth(0.5);
    doc.line(marginLeft, currentY + 4, pageWidth - marginRight, currentY + 4);

    // --- 2. META INFO ---
    doc.setFont("helvetica", "normal");
    doc.setFontSize(10);
    doc.setTextColor(0, 0, 0);

    const today = new Date().toLocaleDateString();
    doc.text(`Generated on: ${today}`, marginLeft, currentY + 12);
    doc.text(
      `Total Transactions: ${transactionsData.length}`,
      marginLeft,
      currentY + 17,
    );

    if (billingCycle?.start && billingCycle?.end) {
      const cycleText = `Billing Cycle: ${new Date(billingCycle.start).toLocaleDateString()} - ${new Date(billingCycle.end).toLocaleDateString()}`;
      const textWidth = doc.getTextWidth(cycleText);
      doc.text(cycleText, pageWidth - marginRight - textWidth, currentY + 12);
    }

    // --- 3. DATA FETCHING ---
    const headers = [
      [
        "Transaction Details",
        "Rate",
        "Type",
        "Date",
        "Order Amt",
        "Txn Amt",
        "USD Amt",
      ],
    ];

    const response = await fetch(
      `/api/transactions?page=0&subId=${subId}&search=${search}`,
    );
    const data = await response.json();

    // --- 4. PROCESS DATA (Calculate Negatives & Totals) ---
    let totalOrder = 0;
    let totalTxn = 0;
    let totalUsd = 0;

    // Helper to format numbers with commas (e.g. -1,200.50)
    const formatCurrency = (num: number) =>
      num.toLocaleString("en-US", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
      });

    const rows = data.transactions.map((txn: any) => {
      // 1. Determine if this is a Credit (Negative)
      const isCredit = txn.transaction_type?.toLowerCase() === "credit";
      const multiplier = isCredit ? -1 : 1;

      // 2. Get raw values
      const orderAmt = txn.Orders
        ? parseFloat(txn.Orders.order_total_amount)
        : 0;
      const txnAmt = parseFloat(txn.transaction_amount);
      const usdAmt = parseFloat(txn.transaction_amount_usd);

      // 3. Update Running Totals (Subtracts if credit, Adds if debit)
      totalOrder += orderAmt * multiplier;
      totalTxn += txnAmt * multiplier;
      totalUsd += usdAmt * multiplier;

      // 4. Format Display Strings
      // If credit, this becomes negative (e.g., -500.00)
      const displayOrder = orderAmt
        ? `${formatCurrency(orderAmt * multiplier)} PKR`
        : "-";
      const displayTxn = `${formatCurrency(txnAmt * multiplier)} PKR`;

      // Handle USD sign placement: "-$5.00" is cleaner than "$-5.00"
      const displayUsd = isCredit
        ? `-$${formatCurrency(usdAmt)}`
        : `$${formatCurrency(usdAmt)}`;

      return [
        txn.transaction_detail,
        txn.Orders
          ? `${parseFloat(txn.Orders.order_charge_rate).toFixed(2)}%`
          : "-",
        txn.transaction_type.toUpperCase(),
        new Date(txn.created_date).toLocaleDateString(), // Or use your formatToHumanDate helper
        displayOrder,
        displayTxn,
        displayUsd,
      ];
    });

    // --- 5. TABLE CONFIGURATION ---
    autoTable(doc, {
      head: headers,
      body: rows,

      // FOOTER: Display the net totals calculated above
      foot: [
        [
          { content: "Net Total", colSpan: 4, styles: { halign: "center" } },
          formatCurrency(totalOrder),
          formatCurrency(totalTxn),
          formatCurrency(totalUsd),
        ],
      ],

      startY: currentY + 25,
      margin: { top: 20, right: marginRight, bottom: 20, left: marginLeft },
      theme: "grid",

      styles: {
        font: "helvetica",
        fontSize: 8,
        textColor: "#333333",
        lineColor: "#E2E8F0",
        lineWidth: 0.1,
        cellPadding: 3,
        valign: "middle",
      },

      headStyles: {
        fillColor: primaryColor,
        textColor: "#FFFFFF",
        fontSize: 9,
        fontStyle: "bold",
        halign: "left",
      },

      // Style the total row to stand out
      footStyles: {
        fillColor: footerBgColor,
        textColor: "#000000",
        fontSize: 9,
        fontStyle: "bold",
        halign: "right",
        lineColor: "#E2E8F0",
        lineWidth: 0.1,
      },

      alternateRowStyles: {
        fillColor: "#F8FAFC",
      },

      // Column sizing (Optimized for A4)
      columnStyles: {
        0: { cellWidth: "auto", halign: "left" },
        1: { cellWidth: 15, halign: "center" },
        2: { cellWidth: 20, halign: "center" },
        3: { cellWidth: 25, halign: "center" },
        4: { cellWidth: 25, halign: "right" },
        5: { cellWidth: 25, halign: "right" },
        6: { cellWidth: 25, halign: "right" },
      },

      didDrawPage: (data) => {
        doc.setFontSize(8);
        doc.setTextColor(secondaryColor);
        doc.text(
          `Page ${data.pageNumber}`,
          pageWidth / 2,
          doc.internal.pageSize.getHeight() - 10,
          { align: "center" },
        );
      },
    });

    doc.save(`Cercle_Report_${today.replace(/\//g, "-")}.pdf`);
  };

  const handleSort = useCallback(
    (index: number, direction: "ascending" | "descending") =>
      setSortedRows(sortCurrency(rows, index, direction)),
    [rows],
  );

  const handlePagination = (page: number) => {
    fetchdata(page, search ?? "");
  };

  const selectTrasaction = (selected: string) => {
    const formData = new FormData();
    formData.append("orderId", selected);

    submit(formData, { method: "POST" });
  };

  if (!isPostBack) {
    return (
      <Page fullWidth>
        <Loader />
      </Page>
    );
  }

  const costTotals = calculateTotals(transactionsData);

  const totalPages = rangeSelected
    ? totalTransactionsData / totalTransactionsData
    : Math.ceil(totalTransactionsData / itemsPerPageData);

  const shouldFillViewport = rows.length <= 10;

  console.log("shouldFillViewport", shouldFillViewport, rows.length);

  return (
    <Page
      backAction={{
        content: "Transections",
        onAction: () => navigate({ pathname: "/app/subscriptions", search }),
      }}
      title="Transactions"
      fullWidth
    >
      {transactionsData.length > 0 ? (
        <>
          <Card>
            <Box minHeight={"30vh"}>
              <BlockStack gap={"300"}>
                <InlineStack
                  align="space-between"
                  blockAlign="center"
                  gap={"300"}
                >
                  <Button
                    icon={PrintIcon}
                    variant="primary"
                    onClick={() => generatePdf()}
                  >
                    Print Ledger
                  </Button>
                  {/* {customSelect ? (
                    <ButtonGroup>
                      <Text as="p" fontWeight="bold">
                        Date Range
                      </Text>
                      <CalendarButton
                        month={month}
                        selectedDates={selectedDates}
                        setDate={setDate}
                        setSelectedDates={setSelectedDates}
                        year={year}
                        borderColor={"#8A8A8A"}
                      />
                      <Button
                        variant="primary"
                        onClick={clearSelectedDates}
                        disabled={!rangeSelected}
                      >
                        Clear
                      </Button>
                    </ButtonGroup>
                  ) : (
                    <ButtonGroup>
                      <ActionListComp
                        active={actionListActive}
                        setActive={setActionListActive}
                        handleBillingCycleClick={handleOnBillingCycleClick}
                      />
                      <Button
                        variant="primary"
                        onClick={() => setCustomSelect(true)}
                      >
                        Custom Date
                      </Button>
                    </ButtonGroup>
                  )} */}
                </InlineStack>
                <InlineStack gap={{ xs: "200" }}>
                  <Text as="p" fontWeight="regular">
                    App Billing Cycle from
                    <b>
                      {billingCycle?.start && billingCycle.end
                        ? " " +
                          formatToHumanDate(billingCycle?.start) +
                          " to " +
                          formatToHumanDate(billingCycle?.end)
                        : "N/AF"}
                    </b>
                  </Text>
                </InlineStack>
              </BlockStack>
              <DataTable
                columnContentTypes={[
                  "text",
                  "text",
                  "text",
                  "text",
                  "numeric",
                  "numeric",
                  "numeric",
                ]}
                headings={[
                  "Transaction details",
                  "Rate",
                  "Transaction type",
                  "Transaction Date",
                  "Order amount",
                  "Transaction amount",
                  "Amount in USD",
                ]}
                rows={rows}
                totals={[
                  "",
                  "",
                  "",
                  "",
                  `${costTotals.totalOrderAmount.toLocaleString(undefined, {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2,
                  })} PKR`,
                  `${costTotals.totalTransactionAmount.toLocaleString(
                    undefined,
                    {
                      minimumFractionDigits: 2,
                      maximumFractionDigits: 2,
                    },
                  )} PKR`,
                  `${costTotals.totalUSDTransactionAmount.toLocaleString(
                    undefined,
                    {
                      minimumFractionDigits: 2,
                      maximumFractionDigits: 2,
                    },
                  )} USD`,
                ]}
                totalsName={{
                  singular: (
                    <Text as="p" fontWeight="semibold">
                      Total in Page
                    </Text>
                  ),
                  plural: (
                    <Text as="p" fontWeight="semibold">
                      Totals in Page
                    </Text>
                  ),
                }}
                sortable={[false, true, false, false, false, true]}
                defaultSortDirection="descending"
                initialSortColumnIndex={4}
                onSort={handleSort}
                footerContent={`Showing ${rows.length} of ${totalTransactionsData} results`}
              />
            </Box>
          </Card>
          <div
            style={{
              marginTop: "20px",
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            <Button
              disabled={currentPage <= 1}
              onClick={() => {
                handlePagination(currentPage - 1);
              }}
            >
              Previous
            </Button>
            <Text as="p">{`Page ${currentPage} of ${totalPages}`}</Text>
            <Button
              disabled={currentPage >= totalPages}
              onClick={() => {
                handlePagination(currentPage + 1);
              }}
            >
              Next
            </Button>
          </div>
        </>
      ) : (
        <Card>
          <Text as="p">No Transactions found</Text>
        </Card>
      )}
    </Page>
  );

  function sortCurrency(
    rows: TableData[][],
    index: number,
    direction: "ascending" | "descending",
  ): TableData[][] {
    return [...rows].sort((rowA, rowB) => {
      const amountA = parseFloat((rowA[index] || 0).toString().substring(1));
      const amountB = parseFloat((rowB[index] || 0).toString().substring(1));

      return direction === "descending" ? amountB - amountA : amountA - amountB;
    });
  }

  function calculateTotals(transactionsData: Transaction[]): {
    totalOrderAmount: number;
    totalTransactionAmount: number;
    totalUSDTransactionAmount: number;
  } {
    return transactionsData.reduce(
      (totals, transaction) => {
        // Determine multiplier: -1 for credit, 1 for others
        const isCredit =
          transaction.transaction_type.toLowerCase() === "credit";
        const multiplier = isCredit ? -1 : 1;

        return {
          totalOrderAmount:
            totals.totalOrderAmount +
            (transaction.Orders?.order_total_amount || 0) * multiplier,

          totalTransactionAmount:
            totals.totalTransactionAmount +
            (transaction.transaction_amount || 0) * multiplier,

          totalUSDTransactionAmount:
            totals.totalUSDTransactionAmount +
            (transaction.transaction_amount_usd || 0) * multiplier,
        };
      },
      {
        totalOrderAmount: 0,
        totalTransactionAmount: 0,
        totalUSDTransactionAmount: 0,
      },
    );
  }
}
