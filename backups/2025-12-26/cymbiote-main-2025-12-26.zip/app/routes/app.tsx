import { HeadersFunction, LoaderFunctionArgs, redirect } from "@remix-run/node";
import {
  json,
  Links,
  Meta,
  Outlet,
  Scripts,
  useLoaderData,
  useRouteError,
} from "@remix-run/react";
import { boundary } from "@shopify/shopify-app-remix/server";
import { AppProvider } from "@shopify/shopify-app-remix/react";
import { NavMenu } from "@shopify/app-bridge-react";
import polarisStyles from "@shopify/polaris/build/esm/styles.css?url";
import appCss from "../css/app.css?url";
import { authenticate } from "../shopify.server";

export const links = () => [
  { rel: "stylesheet", href: appCss },
  { rel: "stylesheet", href: polarisStyles },
];

export const loader = async ({ request }: LoaderFunctionArgs) => {
  try {
    const { admin, session } = await authenticate.admin(request);
    if (!session) throw new Error("No session");

    return json({ apiKey: process.env.SHOPIFY_API_KEY || "" });
  } catch (error) {
    return redirect(
      `/auth?shop=${new URL(request.url).searchParams.get("shop")}`,
    );
  }
};

export default function App() {
  const { apiKey } = useLoaderData<typeof loader>();

  return (
    <AppProvider isEmbeddedApp apiKey={apiKey}>
      <NavMenu>
        <a href="/app" rel="home">
          Home
        </a>
        <a href="/app/catalogue" rel="products">
          Catalogue
        </a>
        <a href="/app/orders">Orders</a>
        <a href="/app/subscriptions">Transactions</a>
        <a href="/app/collection">Collection</a>
        <a href="/customizer">Customize Your App</a>
        <a href="/videos">Reel & Stories</a>
        {/* <a href="/app/chat">Chat</a> */}
        <a href="/app/reviews">Reviews</a>
        <a href="/app/packages">Plans</a>
        <a href="/app/brands">Brands</a>
        <a href="/accounts">Accounts</a>
        <a href="/settings">Settings</a>
      </NavMenu>
      <Outlet />
    </AppProvider>
  );
}

// Shopify needs Remix to catch some thrown responses, so that their headers are included in the response.
export function ErrorBoundary() {
  const error = useRouteError();
  console.error("page error", error);
  return (
    <html>
      <head>
        <title>Oh no!</title>
        <Meta />
        <Links />
      </head>
      <body>
        <Scripts />
      </body>
    </html>
  );
}

export const headers: HeadersFunction = (headersArgs) => {
  return boundary.headers(headersArgs);
};
