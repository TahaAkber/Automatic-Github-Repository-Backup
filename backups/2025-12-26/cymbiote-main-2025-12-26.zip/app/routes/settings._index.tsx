import { useCallback, useEffect, useState } from "react";
import type {
  ActionFunctionArgs,
  LoaderFunctionArgs,
  TypedResponse,
} from "@remix-run/node";
import axios from "axios";
import { json, redirect } from "@remix-run/node";
import { useFetcher, useLoaderData } from "@remix-run/react";
import { useNavigate } from "react-router-dom";
import { Page, Layout, ContextualSaveBar, Frame } from "@shopify/polaris";
import { CustomDivider } from "~/components/common/CustomDivider";
import { ShopCredits } from "~/components/settings/ShopCredits";
import { TrackingSubscription } from "~/components/settings/TrackingSubscription";
import { StoreCategory } from "~/components/settings/StoreCategory";
import { DelistStore } from "~/components/settings/DelistStore";
import { AboutCercle } from "~/components/settings/AboutCercle";
import {
  createAppSubscription,
  createTrackingSubscription,
} from "~/mutations/appSubscription";
import { TrackingNotifications } from "~/components/settings/TrackingNotifications";
import { authenticate } from "~/shopify.server";
import { Loader } from "~/components/common/Loader";
import { StoreDescription } from "~/components/settings/StoreDescription";
import { fetchAppInstallation } from "~/queries/App";
import { getCurrentCurrencyRate, getUrlParams } from "~/functions/common";

interface LoaderReturn {
  shopId: number;
  searchTerm: any;
  billingDate: any;
  shopCategories: any[];
  changeBackUrl: boolean;
  shopDescription: string;
  currentShopCategory: any;
  remainingTrialDays: number;
  subscriptionId: string | any;
  trackingCharges: number | any;
}

export const loader = async ({
  request,
}: LoaderFunctionArgs): Promise<TypedResponse<LoaderReturn>> => {
  const EXCHANGE_RATE_API_URL = process.env.EXCHANGE_RATE_API_URL || "";
  const EXCHANGE_RATE_API_KEY = process.env.EXCHANGE_RATE_API_KEY || "";
  const url = new URL(request.url);
  const shopDomain = url.searchParams.get("shop");

  const { admin } = await authenticate.admin(request);
  let remainingTrialDays = 0;
  const chargesId = url.searchParams.get("charge_id");

  try {
    let shop = await prisma.shops.findFirst({
      where: {
        shop_domain: shopDomain,
      },
      include: {
        Subscriptions: {
          where: {
            subscription_enabled: true,
            subscription_confirmed: true,
          },
          include: {
            Packages: true,
          },
        },
      },
    });

    const { activeSubscriptions: activeSub } =
      await fetchAppInstallation(admin);

    if (!activeSub) {
      console.error("No installed app found");
      return redirect("/app");
    }

    const distinctCategories = await prisma.store_Selected_Categories.findMany({
      where: {
        store_selected_shop_id: shop?.shop_id,
      },
    });
    // console.log("distinctCategories", distinctCategories);

    const currentShopCategory = await prisma.store_Categories.findMany({
      where: {
        category_id: {
          in: distinctCategories.map(
            (category) => category.store_selected_category_id,
          ),
        },
      },
    });

    // console.log("chargesId", chargesId);
    if (chargesId) {
      const currencyRate = await getCurrentCurrencyRate(
        "USD",
        shop?.shop_currency || "PKR",
        EXCHANGE_RATE_API_URL,
        EXCHANGE_RATE_API_KEY,
      );

      const existingSubscription = await prisma.subscriptions.findFirst({
        where: {
          subscription_confirmation_id: chargesId,
        },
      });

      await prisma.subscriptions.update({
        where: {
          subscription_id: existingSubscription?.subscription_id,
        },
        data: {
          subscription_confirmed: true,
          subscription_enabled: true,
          subscription_charge_date: new Date(),
          subscription_ends_at: activeSub[0]?.currentPeriodEnd || new Date(),
        },
      });

      const activeSubscriptions = await prisma.subscriptions.findMany({
        where: {
          subscription_shop_id: shop?.shop_id,
          subscription_enabled: true,
          subscription_confirmed: true,
        },
      });

      // check if more than 1 active subscription exists which means old ones are still active
      if (activeSubscriptions.length < 2) {
        return json({
          shopId: 0,
          searchTerm: url,
          changeBackUrl: false,
          trackingCharges: 0,
          subscriptionId: "",
          shopDescription: "",
          currentShopCategory,
          remainingTrialDays: 0,
          billingDate: new Date(),
          shopCategories: [],
        });
      }

      const subscription = url.searchParams.get("subscription");

      if (subscription === "start") {
        await prisma.shops.update({
          where: {
            shop_domain: shopDomain,
            shop_id: shop?.shop_id,
          },
          data: {
            shop_tracking_subscription_id: `gid://shopify/AppPurchaseOneTime/${chargesId}`,
            shop_active_tracking: true,
          },
        });

        let package_charges =
          shop?.Subscriptions[0]?.Packages?.package_charges || 0;

        if (shop && shop?.shop_tile_subscribed) {
          const tile = await prisma.shop_Tiles.findFirst({
            where: { shop_tile_id: shop.shop_tile_type },
          });

          if (tile) {
            package_charges += tile.shop_tile_charges;
          }
        }

        if (shop) {
          const adminSettings = await prisma.admin_Settings.findFirst();

          if (adminSettings) {
            package_charges += adminSettings.admin_tracking_sub_charges;
          }
        }

        const subscriptionConvertedAmount =
          currencyRate * parseFloat(package_charges.toString());

        await prisma.transactions.create({
          data: {
            transaction_amount_usd: package_charges,
            transaction_amount: subscriptionConvertedAmount,
            transaction_detail:
              `Tracking subscribed on package ${shop?.Subscriptions[0]?.Packages.package_name}` +
              `${shop?.shop_tile_subscribed ? ` with tile subscription` : ``}${shop?.shop_active_tracking ? ` and with tracking subscription` : ``}`,
            transaction_shop_id: shop?.shop_id as number,
            transaction_subscription_id:
              existingSubscription?.subscription_id as number,
            transaction_type: "subscription",
            transaction_kind: "recurring",
            transaction_currency: shop?.shop_currency || "PKR",
            created_date: new Date(),
          },
        });
      } else if (subscription === "remove") {
        await prisma.shops.update({
          where: {
            shop_domain: shopDomain,
            shop_id: shop?.shop_id,
          },
          data: {
            shop_tracking_subscription_id: null,
            shop_active_tracking: false,
          },
        });

        let package_charges =
          shop?.Subscriptions[0]?.Packages?.package_charges || 0;

        if (shop && shop?.shop_tile_subscribed) {
          const tile = await prisma.shop_Tiles.findFirst({
            where: { shop_tile_id: shop.shop_tile_type },
          });

          if (tile) {
            package_charges += tile.shop_tile_charges;
          }
        }

        const subscriptionConvertedAmount =
          currencyRate * parseFloat(package_charges.toString());

        await prisma.transactions.create({
          data: {
            transaction_amount_usd: package_charges,
            transaction_amount: subscriptionConvertedAmount,
            transaction_detail:
              `Removed tracking subscription, replacing ${shop?.Subscriptions[0]?.Packages.package_name}` +
              `${shop?.shop_tile_subscribed ? ` with tile subscription` : ``}`,
            transaction_shop_id: shop?.shop_id as number,
            transaction_subscription_id:
              existingSubscription?.subscription_id as number,
            transaction_type: "subscription",
            transaction_kind: "recurring",
            transaction_currency: shop?.shop_currency || "PKR",
            created_date: new Date(),
          },
        });
      }

      // console.log("activeSubscriptions", activeSubscriptions);
      const subscriptionIDForUpdate =
        (shop?.Subscriptions[0]?.subscription_id as number) || 0;

      // console.log("subscriptionIDForUpdate", subscriptionIDForUpdate);
      // disable old subscription
      await prisma.subscriptions.update({
        where: {
          subscription_id: subscriptionIDForUpdate,
        },
        data: {
          subscription_enabled: false,
        },
      });

      shop = await prisma.shops.findFirst({
        where: {
          shop_domain: shopDomain,
        },
        include: {
          Subscriptions: {
            where: {
              subscription_enabled: true,
              subscription_confirmed: true,
            },
            include: {
              Packages: true,
            },
          },
        },
      });
    }

    const subscriptionId = await prisma.shops.findFirst({
      where: {
        shop_domain: shopDomain,
        shop_id: shop?.shop_id,
      },
    });

    const shopCategories = await prisma.store_Categories.findMany();

    const trackingCharges = await prisma.admin_Settings.findFirst({});
    const modifiedCategories = shopCategories.map((category: any) => ({
      id: category.category_id,
      fullName: category.category_name,
    }));
    const subscriptionChargeDate = await prisma.subscriptions.findFirst({
      where: {
        subscription_shop_id: shop?.shop_id,
      },
      include: {
        Packages: true,
      },
    });

    if (subscriptionChargeDate) {
      const chargeDate = new Date(
        subscriptionChargeDate.subscription_charge_date,
      );
      const trialDays = subscriptionChargeDate.Packages.package_trial_days;

      const now = new Date();

      const trialEndDate = new Date(chargeDate);
      trialEndDate.setDate(trialEndDate.getDate() + trialDays);

      const diffMs = trialEndDate.getTime() - now.getTime();

      remainingTrialDays = Math.max(
        Math.floor(diffMs / (1000 * 60 * 60 * 24)),
        0,
      );
      console.log("Remaining trial days:", remainingTrialDays);
    }

    if (!shop) {
      console.error("Shop not found in the database");
      return json({
        shopId: 0,
        searchTerm: url,
        changeBackUrl: false,
        trackingCharges: 0,
        subscriptionId: "",
        shopDescription: "",
        currentShopCategory,
        remainingTrialDays: 0,
        billingDate: new Date(),
        shopCategories: modifiedCategories,
      });
    }

    return json({
      searchTerm: url,
      remainingTrialDays,
      currentShopCategory,
      shopId: shop.shop_id,
      changeBackUrl: chargesId !== null,
      shopCategories: modifiedCategories,
      shopDescription: shop?.shop_description || "",
      trackingCharges: trackingCharges?.admin_tracking_sub_charges,
      subscriptionId: subscriptionId?.shop_tracking_subscription_id,
      billingDate: activeSub[0]?.currentPeriodEnd || new Date(),
    });
  } catch (error) {
    console.error("Error fetching product categories:", error);
    throw new Response("Error fetching product categories", { status: 500 });
  }
};

export const action = async ({ request }: ActionFunctionArgs) => {
  try {
    const APP_ON_TEST = process.env.APP_ON_TEST === "true";
    console.log("APP_ON_TEST in action", APP_ON_TEST);
    const url = new URL(request.url);
    // console.log("url in settings", url);
    const params = new URLSearchParams(url.search);
    const queryString = params.toString();
    const formData = await request.formData();
    const shopName = formData.get("shopName") as string;
    const shopDescription = formData.get("shopDescription") as string;
    const iconStream = formData.get("iconStream");
    const iconName = formData.get("iconName");
    const iconFile = formData.get("iconFile") as File;
    const iconType = formData.get("iconType")?.toString();
    const shopDomain = url.searchParams.get("shop");
    const subscription = formData.get("subscription");
    const delist = formData.get("delist");
    const enlist = formData.get("enlist");
    const categoryId = formData.get("categoryId");
    const value = formData.get("value");
    const selectedCategories = formData.getAll("selectedCategory") as string[];

    const { admin } = await authenticate.admin(request);
    console.log("result", delist);
    // Upload the icon to Shopify using the GraphQL API
    let imageId = null;
    console.log("shopDomain", shopDomain);

    const shop = await prisma.shops.findFirst({
      where: {
        shop_domain: shopDomain,
      },
      include: {
        Subscriptions: {
          where: {
            subscription_confirmed: true,
            subscription_enabled: true,
          },
          include: {
            Packages: true,
          },
        },
      },
    });

    const subscriptions = shop?.Subscriptions ?? [];
    if (subscriptions.length === 0) {
      console.error("No active subscriptions found");
      return json(
        {
          success: false,
          message: "No active subscriptions found",
        },
        { status: 404 },
      );
    }

    if (subscription === "start") {
      // trial days remaining logic
      const firstSubscription = await prisma.subscriptions.findFirst({
        where: {
          subscription_shop_id: shop?.shop_id,
        },
        orderBy: {
          subscription_id: "asc",
        },
      });
      let trialDays = 0;
      if (firstSubscription) {
        // Calculate difference in days between the subscription charge date and now.
        // Use getTime()/Date.now() so subtraction operates on numbers (milliseconds).
        const diffMs =
          new Date(firstSubscription.subscription_charge_date).getTime() -
          Date.now();
        trialDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
      }
      console.log("trial days", trialDays);
      if (shopDomain) {
        const trackingSubscription = await createAppSubscription(
          admin,
          prisma,
          shopDomain,
          shop?.Subscriptions[0].Packages.package_name as string,
          shop?.Subscriptions[0].Packages.package_charges.toString() as string,
          shop?.Subscriptions[0].Packages.package_rate.toString() as string,
          (shop?.Subscriptions[0].Packages.package_id as number).toString(),
          false,
          "",
          "",
          true,
          trialDays > 0 ? trialDays : 0,
          APP_ON_TEST,
        );
        // await prisma.shops.update({
        //   where: {
        //     shop_domain: shopDomain,
        //     shop_id: shop?.shop_id,
        //   },
        //   data: {
        //     shop_tracking_subscription_id: trackingSubscription?.id,
        //   },
        // });

        // console.log("trackingSubscription", trackingSubscription);

        return json({
          confirmationUrl: trackingSubscription?.confirmationUrl,
          success: true,
        });
      } else {
        return json({ error: "Shop domain is missing" }, { status: 400 });
      }
    } else if (subscription === "remove") {
      // trial days remaining logic
      const firstSubscription = await prisma.subscriptions.findFirst({
        where: {
          subscription_shop_id: shop?.shop_id,
        },
        orderBy: {
          subscription_id: "asc",
        },
      });
      let trialDays = 0;
      if (firstSubscription) {
        // Calculate difference in days between the subscription charge date and now.
        // Use getTime()/Date.now() so subtraction operates on numbers (milliseconds).
        const diffMs =
          new Date(firstSubscription.subscription_charge_date).getTime() -
          Date.now();
        trialDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
      }
      console.log("trial days", trialDays);
      if (shopDomain) {
        const trackingSubscription = await createAppSubscription(
          admin,
          prisma,
          shopDomain,
          shop?.Subscriptions[0].Packages.package_name as string,
          shop?.Subscriptions[0].Packages.package_charges.toString() as string,
          shop?.Subscriptions[0].Packages.package_rate.toString() as string,
          (shop?.Subscriptions[0].Packages.package_id as number).toString(),
          false,
          "",
          "",
          false,
          trialDays > 0 ? trialDays : 0,
          APP_ON_TEST,
        );
        // await prisma.shops.update({
        //   where: {
        //     shop_domain: shopDomain,
        //     shop_id: shop?.shop_id,
        //   },
        //   data: {
        //     shop_tracking_subscription_id: trackingSubscription?.id,
        //   },
        // });

        console.log("trackingSubscription", trackingSubscription);

        return json({
          confirmationUrl: trackingSubscription?.confirmationUrl,
          success: true,
        });
      } else {
        return json({ error: "Shop domain is missing" }, { status: 400 });
      }
    } else if (selectedCategories && !delist && !enlist) {
      const shop = await prisma.shops.findFirst({
        where: {
          shop_domain: shopDomain,
        },
      });
      if (selectedCategories.length > 0 && shop?.shop_id !== undefined) {
        await prisma.store_Selected_Categories.deleteMany({
          where: {
            store_selected_shop_id: shop.shop_id,
          },
        });

        await prisma.store_Selected_Categories.createMany({
          data: selectedCategories.map((categoryId) => ({
            store_selected_shop_id: shop.shop_id,
            store_selected_category_id: parseInt(categoryId),
          })),
        });
      }
      return json({
        success: true,
      });
    } else if (delist || enlist) {
      try {
        const shop = await prisma.shops.findFirst({
          where: {
            shop_domain: shopDomain,
          },
        });

        if (!shop) {
          return json(
            { success: false, message: "Shop not found" },
            { status: 404 },
          );
        }

        if (delist) {
          const result = await prisma.shops.update({
            where: {
              shop_id: shop.shop_id,
            },
            data: {
              shop_is_active: false,
            },
          });
          return json({
            result,
            success: true,
            message: "Store is delisted successfully",
          });
        } else if (enlist) {
          const result = await prisma.shops.update({
            where: {
              shop_id: shop.shop_id,
            },
            data: {
              shop_is_active: true,
            },
          });
          return json({
            result,
            success: true,
            message: "Store is enlisted successfully",
          });
        }
      } catch (error: any) {
        return json(
          {
            success: false,
            message: "An error occurred",
            error: error.message,
          },
          { status: 500 },
        );
      }
    } else if (iconStream && iconName && iconType && shopDomain) {
      const file = base64ToFile(
        iconStream.toString(),
        iconName.toString(),
        iconType,
      );

      try {
        const stagedResponse = await admin.graphql(
          `#graphql
          mutation stagedUploadsCreate($input: [StagedUploadInput!]!) {
            stagedUploadsCreate(input: $input) {
              stagedTargets {
                url
                resourceUrl
                parameters {
                  name
                  value
                }
              }
            }
          }`,
          {
            variables: {
              input: [
                {
                  filename: iconName,
                  mimeType: iconType,
                  httpMethod: "POST",
                  fileSize: file.size + "",
                  resource: "IMAGE",
                },
              ],
            },
          },
        );

        const stagedData = await stagedResponse.json();

        const imgFormData = new FormData();

        console.log(
          "StagedUploadsCreatePayload returns",
          stagedData?.data?.stagedUploadsCreate,
        );

        const [{ url, parameters, resourceUrl }] =
          stagedData?.data?.stagedUploadsCreate?.stagedTargets;

        parameters.forEach(
          ({ name, value }: { name: string; value: string }) => {
            imgFormData.append(name, value);
          },
        );

        imgFormData.append("file", iconFile);
        console.log("imgFormData", imgFormData);

        const uploadResponse = await axios.postForm(url, imgFormData);

        if (uploadResponse.status <= 400) {
          try {
            console.log("uploadResponse", uploadResponse.data);
          } catch (error) {
            console.error("Failed to parse JSON:", error);
          }
        } else {
          const rawResponse = await uploadResponse.statusText;
          console.error("Unexpected response:", rawResponse);
        }

        const response = await admin.graphql(
          `#graphql
          mutation fileCreate($files: [FileCreateInput!]!) {
            fileCreate(files: $files) {
              files {
                id
                fileStatus
                alt
                createdAt
              }
            }
          }`,
          {
            variables: {
              files: [{ contentType: "IMAGE", originalSource: resourceUrl }],
            },
          },
        );

        const data = await response.json();
        console.log("upload response", data.data.fileCreate.files);

        if (data.data.fileCreate.files[0].fileStatus === "UPLOADED") {
          imageId = data.data.fileCreate.files[0].id;
          console.log("image upload", imageId);
        } else {
          return json({ error: "Failed to upload the image" }, { status: 500 });
        }
      } catch (error) {
        console.error("Error during image upload:", error);
        return json({ error: "Image upload failed" }, { status: 500 });
      }
    }
    // Save the information to the Prisma database
    try {
      const shop = await prisma.shops.findFirst({
        where: {
          shop_domain: shopDomain,
        },
      });
      console.log("updating domain", shopDomain);
      const update = await prisma.shops.update({
        data: {
          shop_logo_url: imageId,
          shop_name: shopName || shop?.shop_name,
          shop_description: shopDescription,
          updated_at: new Date(),
        },
        where: {
          shop_id: shop?.shop_id,
        },
      });
      // console.log("profile updated", update);
      // const redirectUrl = `/app?${queryString}`;
      // return redirect(redirectUrl); // Redirect after successful save
      return json({
        success: true,
      });
    } catch (error) {
      console.error("Error saving to the database:", error);
      return json({ error: "Failed to save the information" }, { status: 500 });
    }
  } catch (error) {
    console.error("Unexpected error:", error);
    return json({ error: "An unexpected error occurred" }, { status: 500 });
  }
};

export default function Index() {
  const navigate = useNavigate();
  const {
    shopId,
    searchTerm,
    billingDate,
    changeBackUrl,
    shopCategories,
    subscriptionId,
    shopDescription,
    trackingCharges,
    remainingTrialDays,
    currentShopCategory,
  } = useLoaderData<LoaderReturn>();
  const fetcher = useFetcher<{ confirmationUrl?: string; success?: boolean }>();
  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isPostBack, setIsPostBack] = useState(true);
  const [showSaveBar, setShowSaveBar] = useState(false);
  const [url, setUrl] = useState("");
  const [loadingCredits, setLoadingCredits] = useState(false);
  const [loadingSubscription, setLoadingSubscription] = useState(false);
  const [delistbuttonloading, setdelistbuttonloading] = useState(false);
  const [availableCredits, setAvailableCredits] = useState<number | null>(null);
  const [selectedCategories, setSelectedCategories] = useState<
    { value: string; id: string }[]
  >([]);
  const [urlParams, setUrlParams] = useState(getUrlParams());
  const [description, setDescription] = useState(shopDescription || "");

  useEffect(() => {
    fetchCredits(shopId, new Date(billingDate));
    cleanUrlParamsOnLoad(["charge_id", "subscription"]);
  }, []);

  useEffect(() => {
    setUrl(fetcher.data?.confirmationUrl ?? "");
    // setLoadingSubscription(false);
  }, [fetcher.data?.confirmationUrl]);

  useEffect(() => {
    if (fetcher.data?.success === true) {
      setdelistbuttonloading(false);
    }
  }, [fetcher.data]);

  useEffect(() => {
    if (!url) return;
    const cleanUrl = `${window.location.origin}${window.location.pathname}`;
    window.history.replaceState(null, "", cleanUrl);

    if (window.top) {
      window.top.location.href = url;
    } else {
      window.location.href = url;
    }
    // setLoadingSubscription(false);
  }, [url]);

  const cleanUrlParamsOnLoad = (paramsToRemove: string[]) => {
    const currentParams = new URLSearchParams(window.location.search);
    let paramsChanged = false;

    // Check if any of the target parameters exist and delete them
    paramsToRemove.forEach((paramKey) => {
      if (currentParams.has(paramKey)) {
        currentParams.delete(paramKey);
        paramsChanged = true;
      }
    });

    // Only update history if parameters were actually removed
    if (paramsChanged) {
      // Construct the new URL path (pathname + cleaned search string)
      const newUrl = `${window.location.pathname}${currentParams.toString() ? "?" + currentParams.toString() : ""}`;

      // Update the browser history state without causing a page reload
      window.history.replaceState(null, "", newUrl);

      // Update component state to reflect the clean URL
      setUrlParams(getUrlParams(window));
    }
  };

  const fetchCredits = async (shopId: number, billingDate: Date) => {
    setLoadingCredits(true);
    setError("");

    try {
      console.log("called fetch credits", billingDate.toISOString());
      const response = await fetch(
        `/api/credits?shopId=${shopId}&billingDate=${encodeURIComponent(billingDate.toISOString())}`,
      );
      const dataJson = await response.json();

      if (response.ok) {
        console.log("credits data", dataJson);
        setAvailableCredits(dataJson.totalCredits.toFixed(2));
      } else {
        throw new Error(dataJson.message || "Failed to fetch credits");
      }
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoadingCredits(false);
    }
  };

  const handleDescriptionChange = useCallback(
    (newValue: string) => setDescription(newValue),
    [],
  );

  const handleSave = async () => {
    // const formData = new FormData();
    // formData.append("shopName", formState.shopName);
    // formData.append("shopDescription", formState.shopDescription);
    // formData.append("shopDomain", shopDetails.shop_domain);
    // console.log("iconFile", iconFile);
    if (selectedCategories.length === 0) {
      return shopify.toast.show(
        "Please select at least one category before saving.",
      );
    }
    setIsLoading(true);
    changedCategory();
  };

  const listingStore = (value: string) => {
    const formdata = new FormData();
    if (value === "delist") {
      formdata.append(value, "delist");
    } else if (value === "enlist") {
      formdata.append(value, "enlist");
    }
    fetcher.submit(formdata, {
      method: "POST",
      encType: "multipart/form-data",
    });
    console.log("data", Object.fromEntries(formdata.entries()));
  };
  const handleSubscription = (url: any) => {
    const formdata = new FormData();
    formdata.append(
      "subscription",
      subscriptionId !== null ? "remove" : "start",
    );
    fetcher.submit(formdata, {
      method: "POST",
      encType: "multipart/form-data",
    });
    setLoadingSubscription(true);
    console.log("handleSubscription", Object.fromEntries(formdata.entries()));
  };
  const handleDiscard = () => {
    setShowSaveBar(false);
    setSelectedCategories([]);
  };

  const removeCategory = async (category: string, id: string) => {};
  const changedCategory = async () => {
    const formdata = new FormData();
    if (selectedCategories.length < 1) {
      shopify.toast.show("Kindly select atleast one cateogry first");
      return;
    }
    selectedCategories.forEach((item) =>
      formdata.append("selectedCategory", item.id),
    );
    fetcher.submit(formdata, {
      method: "POST",
      encType: "multipart/form-data",
    });
    console.log("object", Object.fromEntries(formdata.entries()));
  };

  useEffect(() => {
    if (fetcher?.data?.success) {
      setIsLoading(false);
    }
    setShowSaveBar(false);
  }, [fetcher?.data]);

  useEffect(() => {
    setIsPostBack(false);
  }, []);

  if (isPostBack) {
    return (
      <Page fullWidth>
        <Loader />
      </Page>
    );
  }
  return (
    <Frame>
      {showSaveBar && (
        <ContextualSaveBar
          message="Unsaved changes"
          saveAction={{
            onAction: handleSave,
            loading: isLoading,
            disabled: false,
          }}
          discardAction={{
            onAction: handleDiscard,
          }}
          fullWidth
        />
      )}
      <Page title="Settings">
        <Layout>
          {/* Add-ons Section */}
          <TrackingNotifications />

          <CustomDivider />

          <TrackingSubscription
            handleSubscription={() => handleSubscription(url)}
            loadingSubscription={loadingSubscription}
            subscriptionId={subscriptionId}
            remainingTrialDays={remainingTrialDays}
            trackingCharges={trackingCharges}
          />

          <CustomDivider />

          <StoreCategory
            changedCategory={changedCategory}
            removeCategory={removeCategory}
            selectedCategories={selectedCategories}
            setSelectedCategories={setSelectedCategories}
            shopCategories={shopCategories}
            currentShopCategory={currentShopCategory}
            isPostBack={isPostBack}
            setShowSaveBar={setShowSaveBar}
          />

          <CustomDivider />

          <StoreDescription
            handleDescriptionChange={handleDescriptionChange}
            description={description}
          />

          <CustomDivider />

          {/* Shop Credits */}
          <ShopCredits
            availableCredits={availableCredits as number}
            billingDate={billingDate}
            fetchCredits={fetchCredits}
            loadingCredits={loadingCredits}
            shopId={shopId}
          />

          <CustomDivider />

          {/* Delist My Store */}
          <DelistStore
            listingStore={listingStore}
            searchTerm={searchTerm}
            setdelistbuttonloading={setdelistbuttonloading}
            delistbuttonloading={delistbuttonloading}
          />

          <CustomDivider />

          <AboutCercle />
        </Layout>
        <div style={{ height: 20 }} />
      </Page>
    </Frame>
  );
}

function base64ToFile(base64Data: string, fileName: string, mimeType: string) {
  // Remove the data URL prefix if it exists
  const base64WithoutPrefix = base64Data.split(",")[1];

  // Convert base64 to ArrayBuffer
  const binaryString = Buffer.from(base64WithoutPrefix, "base64").toString(
    "binary",
  );
  const len = binaryString.length;
  const bytes = new Uint8Array(len);

  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }

  const arrayBuffer = bytes.buffer;

  // Create a File-like object
  const file = {
    name: fileName,
    type: mimeType,
    size: arrayBuffer.byteLength,
    arrayBuffer: () => Promise.resolve(arrayBuffer),
    slice: (start: number, end: number) =>
      new Blob([arrayBuffer.slice(start, end)], { type: mimeType }),
  };

  return file;
}
