import { ActionFunctionArgs, json } from "@remix-run/node";

const getOrderSortByField = (sortValue: string) => {
  // Remove quotes if they exist in the string
  const cleanedSortValue = sortValue.replace(/^"|"$/g, "").trim();

  switch (cleanedSortValue) {
    case "order asc":
      return { order_date: "asc" as any };
    case "order desc":
      return { order_date: "desc" as any };
    case "customer asc":
      return { Users: { user_email: "asc" as any } };
    case "customer desc":
      return { Users: { user_email: "desc" as any } };
    case "date asc":
      return { created_at: "asc" as any };
    case "date desc":
      return { created_at: "desc" as any };
    default:
      console.log("FALLING TO DEFAULT - Unknown sort value:", cleanedSortValue);
      return { order_date: "asc" as any };
  }
};

export const action = async ({ request }: ActionFunctionArgs) => {
  let filteredOrders: any[] = [];
  const url = new URL(request.url);
  console.log("API ACTION TRIGGERED");
  try {
    const formData = await request.formData();
    const method = request.method;
    const querySearchTerm = url.searchParams.get("querySearch");
    const sortField = formData.get("Sorting")?.toString() || "";
    const orderBy = getOrderSortByField(sortField);
    console.log("sortField", sortField);
    console.log("orderBy", orderBy);
    if (method === "POST" && formData.get("orderFilter")) {
      const orderFilter = formData.get("orderFilter")?.toString();
      const shopDomain = formData.get("shopDomain")?.toString();

      if (!shopDomain) {
        return json({ error: "Missing shop" }, { status: 400 });
      }

      // Find the shop
      const shop = await prisma.shops.findFirst({
        where: { shop_domain: shopDomain },
      });

      if (!shop) {
        return json({ error: "Shop not found" }, { status: 404 });
      }

      switch (orderFilter) {
        case "Unpaid":
          const unpaidOrders = await prisma.orders.findMany({
            where: {
              order_channel: { in: ["cercle", "cymbiote", "cercleDev"] },
              order_shop_id: shop?.shop_id,
              order_payment_status: "pending",
              ...(querySearchTerm && {
                Users: {
                  user_email: {
                    contains: querySearchTerm,
                  },
                },
              }),
            },
            include: {
              Users: true,
              Transactions: true,
            },
            orderBy,
          });
          filteredOrders = [...filteredOrders, ...unpaidOrders];
          break;

        case "Closed":
          const closedOrders = await prisma.orders.findMany({
            where: {
              order_channel: { in: ["cercle", "cymbiote", "cercleDev"] },
              order_shop_id: shop?.shop_id,
              order_payment_status: "paid",
              ...(querySearchTerm && {
                Users: {
                  user_email: {
                    contains: querySearchTerm,
                  },
                },
              }),
            },
            include: {
              Users: true,
              Transactions: true,
            },
            orderBy,
          });
          filteredOrders = [...filteredOrders, ...closedOrders];
          break;

        case "Cancelled":
          const cancelledOrders = await prisma.orders.findMany({
            where: {
              order_channel: { in: ["cercle", "cymbiote", "cercleDev"] },
              order_shop_id: shop?.shop_id,
              order_cancelled_at: { not: null },
              ...(querySearchTerm && {
                Users: {
                  user_email: {
                    contains: querySearchTerm,
                  },
                },
              }),
            },
            include: {
              Users: true,
              Transactions: true,
            },
            orderBy,
          });
          filteredOrders = [...filteredOrders, ...cancelledOrders];
          break;

        case "Open":
          const openOrders = await prisma.orders.findMany({
            where: {
              order_channel: { in: ["cercle", "cymbiote", "cercleDev"] },
              order_shop_id: shop?.shop_id,
              OR: [
                { order_fulfillment_status: "unfulfilled" },
                { order_fulfillment_status: null },
              ],
              ...(querySearchTerm && {
                Users: {
                  user_email: {
                    contains: querySearchTerm,
                  },
                },
              }),
            },
            include: {
              Users: true,
              Transactions: true,
            },
            orderBy,
          });
          filteredOrders = [...filteredOrders, ...openOrders];
          break;

        default:
          // If no filter is provided, return all orders with search term applied
          filteredOrders = await prisma.orders.findMany({
            where: {
              order_channel: { in: ["cercle", "cymbiote", "cercleDev"] },
              order_shop_id: shop?.shop_id,
              ...(querySearchTerm && {
                Users: {
                  user_email: {
                    contains: querySearchTerm,
                  },
                },
              }),
            },
            include: {
              Users: true,
              Transactions: true,
            },
            orderBy,
          });
      }

      return json({
        success: 200,
        message: "Orders fetched successfully",
        data: filteredOrders,
      });
    }

    return json({ error: "Invalid request" }, { status: 400 });
  } catch (error) {
    console.error("Fetching orders unsuccessful:", error);
    return json({ error: "Fetching orders unsuccessful" }, { status: 500 });
  }
};
