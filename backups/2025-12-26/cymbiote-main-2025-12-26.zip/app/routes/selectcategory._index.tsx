import { useEffect, useState } from "react";
import type {
  ActionFunctionArgs,
  LoaderFunctionArgs,
  TypedResponse,
} from "@remix-run/node";
import { json } from "@remix-run/node";
import { useLoaderData, useNavigate, useSubmit } from "@remix-run/react";
import {
  Page,
  Layout,
  Text,
  Card,
  Button,
  ButtonGroup,
} from "@shopify/polaris";
import { useAppBridge } from "@shopify/app-bridge-react";
import { authenticate } from "~/shopify.server";
import { SearchDropdown } from "~/components/dashboard/SearchDropdown";
import { ShopResourceFeedbackCreate } from "~/mutations/appSubscription";
import { SearchStoreCategory } from "~/components/dashboard/SearchStoreCategory";

interface LoaderReturn {
  shopCategories: any[];
  queryString: string;
}

export const loader = async ({
  request,
}: LoaderFunctionArgs): Promise<TypedResponse<LoaderReturn>> => {
  const url = new URL(request.url);
  const searchTerm = url.searchParams.get("searchTerm") || "";
  const params = new URLSearchParams(url.search);
  const queryString = params.toString();

  const { admin } = await authenticate.admin(request);

  const variablesInput = {
    messages: ["Subscribe To A Plan And Select Shop Category To Get Started."],
    state: "REQUIRES_ACTION",
    feedbackGeneratedAt: new Date().toISOString(),
  };

  const shopfeedback = await ShopResourceFeedbackCreate(admin, variablesInput);
  console.log("shopfeedback", shopfeedback);
  const query = `
      {
        taxonomy {
          categories(first: 25 ${searchTerm ? ', search: "' + searchTerm + '"' : ""}) {
            nodes {
              fullName
              isRoot
              id
            }
          }
        }
      }`;
  // console.log("query", query);

  try {
    const response = await admin.graphql(query);
    const data = await response.json(); // Parse the ReadableStream to JSON

    const shopCategories = await prisma.store_Categories.findMany();

    const modifiedCategories = shopCategories.map((category) => ({
      id: category.category_id,
      fullName: category.category_name,
    }));

    // console.log("data found", data);
    return json({
      queryString,
      shopCategories: modifiedCategories,
    });
  } catch (error) {
    console.error("Error fetching product categories:", error);
    throw new Response("Error fetching product categories", { status: 500 });
  }
};

export const action = async ({ request }: ActionFunctionArgs) => {
  console.log("category action triggered");
  const { admin } = await authenticate.admin(request);
  const url = new URL(request.url);
  const shopDomain = url.searchParams.get("shop");
  const formData = await request.formData();
  // const selectedCategory = formData.get("selectedCategory") as string;
  const selectedCategories = formData.getAll("selectedCategory") as string[];

  const shop = await prisma.shops.findFirst({
    where: {
      shop_domain: shopDomain,
    },
  });

  await prisma.shops.update({
    data: {
      // shop_category: parseInt(selectedCategory),
      shop_first_load: false,
      updated_at: new Date(),
    },
    where: {
      shop_id: shop?.shop_id,
    },
  });

  if (selectedCategories.length > 0 && shop?.shop_id !== undefined) {
    await prisma.store_Selected_Categories.createMany({
      data: selectedCategories.map((categoryId) => ({
        store_selected_shop_id: shop.shop_id,
        store_selected_category_id: parseInt(categoryId),
      })),
    });
  }

  return json({ success: true });
};

export default function Index() {
  const shopify = useAppBridge();
  const submit = useSubmit();
  const [loading, setLoading] = useState(false);

  const navigate = useNavigate();
  const { shopCategories, queryString } = useLoaderData<LoaderReturn>();
  const [selectedCategories, setSelectedCategories] = useState<
    { value: string; id: string }[]
  >([]);

  const handleGoNext = (): void => {
    setLoading(true);
    if (selectedCategories.length < 1) {
      shopify.toast.show("Kindly select atleast one cateogry first");
      setLoading(false);
      return;
    }

    const formData = new FormData();
    selectedCategories.forEach((item) =>
      formData.append("selectedCategory", item.id),
    );
    submit(formData, { method: "POST" });

    console.log("formData", Object.fromEntries(formData.entries()));
    setTimeout(() => {
      navigate({ pathname: "/app/packages", search: queryString });
    }, 3000);
  };

  const removeCategory = async (category: string, id: string) => {};

  return (
    <Page fullWidth>
      <Layout sectioned>
        <Card>
          <Text as="h2" variant="heading3xl" fontWeight="semibold">
            Before we start
          </Text>
          <Text as="h5">Tell us about your store category.</Text>
          <div style={{ width: 250, marginTop: 20, marginBottom: 20 }}>
            <SearchStoreCategory
              initialCategoryItems={shopCategories.length ? shopCategories : []}
              selectedOptions={selectedCategories}
              setSelectedOptions={setSelectedCategories}
              allowMultiSelect={true}
              removeASelectedCategory={removeCategory}
            />
          </div>

          <ButtonGroup>
            <Button onClick={handleGoNext} loading={loading}>
              Next
            </Button>
          </ButtonGroup>
        </Card>
      </Layout>
    </Page>
  );
}
