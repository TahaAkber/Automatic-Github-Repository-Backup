import { ActionFunctionArgs, json } from "@remix-run/node";
import { authenticate } from "~/shopify.server";

// export const loader = async ({ request }: ActionFunctionArgs) => {
//   try {
//     const url = new URL(request.url);

//     const { admin } = await authenticate.admin(request);

//     // Get query parameters
//     const videoNodeId = url.searchParams.get("videoNodeId"); // Video Node ID
//     const shopId = parseInt(url.searchParams.get("shopId") || "1"); // Shop ID

//     let videoUrl = null;

//     if (videoNodeId) {
//       const videoNodeQuery = `
//           {
//             node(id: "${videoNodeId}") {
//               ... on Video {
//                 sources {
//                   url
//                 }
//               }
//             }
//           }
//         `;

//       const videoResponse = await admin.graphql(videoNodeQuery);
//       const nodeData = await videoResponse.json();

//       const sources = nodeData.data?.node?.sources;
//       if (sources && sources.length > 0) {
//         videoUrl = sources[0].url;

//         // Update the shop's banner URL in the database
//         await prisma.shops.update({
//           where: { shop_id: shopId },
//           data: { shop_banner_url: videoUrl },
//         });

//         console.log("Fetched video URL:", videoUrl);
//       }
//     }

//     return json({
//       videoUrl, // Return video URL if found, otherwise null
//     });
//   } catch (error) {
//     console.error("Video URL fetch error message", error);
//     return json({});
//   }
// };
export const loader = async ({ request }: ActionFunctionArgs) => {
  try {
    const url = new URL(request.url);
    const { admin } = await authenticate.admin(request);

    const videoNodeId = url.searchParams.get("videoNodeId"); // Video Node ID
    const shopId = parseInt(url.searchParams.get("shopId") || "1"); // Shop ID

    if (!videoNodeId) {
      console.error("❌ Missing videoNodeId in request.");
      return json({ error: "videoNodeId is required." }, { status: 400 });
    }

    let videoUrl = null;

    try {
      const videoNodeQuery = `
        {
          node(id: "${videoNodeId}") {
            ... on Video {
              sources {
                url
              }
            }
          }
        }
      `;

      const videoResponse = await admin.graphql(videoNodeQuery);
      console.log(`🔄 GraphQL API Called: ${videoNodeId}`);

      if (!videoResponse.ok) {
        const errorText = await videoResponse.text();
        throw new Error(
          `GraphQL request failed with status ${videoResponse.status}: ${errorText}`,
        );
      }

      const nodeData = await videoResponse.json();
      console.log(
        "📥 GraphQL Response:",
        JSON.stringify(nodeData.data.node.sources, null, 2),
      );

      if (!nodeData?.data?.node?.sources) {
        throw new Error("Invalid response structure or missing sources.");
      }

      const sources = nodeData.data.node.sources;
      if (sources.length > 0) {
        videoUrl = sources[0].url;

        try {
          // Update the shop's banner URL in the database
          console.log("📝 Updating shop banner in DB...");
          const result = await prisma.shops.update({
            where: { shop_id: shopId },
            data: { shop_banner_url: videoUrl, updated_at: new Date() },
          });
          console.log("✅ Updated");
        } catch (dbError) {
          console.error("❌ Database update error:", dbError);
          return json({ error: "Failed to update database." }, { status: 500 });
        }
      } else {
        console.warn("⚠️ No video sources found.");
      }
    } catch (graphqlError) {
      console.error("❌ GraphQL fetch error:", graphqlError);
      return json({ error: "Failed to fetch video data." }, { status: 500 });
    }

    return json({ videoUrl: videoUrl || null }); // Ensure response is always consistent
  } catch (error) {
    console.error(
      "❌ Unexpected error:",
      error instanceof Error ? error.message : error,
    );
    console.error(
      "📌 Error Stack:",
      error instanceof Error ? error.stack : "No stack available",
    );
    return json({ error: "An unexpected error occurred." }, { status: 500 });
  }
};
