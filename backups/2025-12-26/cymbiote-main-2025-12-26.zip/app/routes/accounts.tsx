import type { HeadersFunction, LoaderFunctionArgs } from "@remix-run/node";
import { json } from "@remix-run/node";
import { Outlet, useLoaderData, useRouteError } from "@remix-run/react";
import { boundary } from "@shopify/shopify-app-remix/server";
import { AppProvider } from "@shopify/shopify-app-remix/react";
import polarisStyles from "@shopify/polaris/build/esm/styles.css?url";
import appCss from "../css/app.css?url";
import { NavMenu } from "@shopify/app-bridge-react";

export const links = () => [
  { rel: "stylesheet", href: appCss },
  { rel: "stylesheet", href: polarisStyles },
];

export const loader = async ({ request }: LoaderFunctionArgs) => {
  // await authenticate.admin(request);
  const url = new URL(request.url);
  const shopDomain = url.searchParams.get("shop");

  const shop = await prisma.shops.findFirst({
    where: {
      shop_domain: shopDomain,
    },
  });

  console.log("found shop", shop);

  return json({ apiKey: process.env.SHOPIFY_API_KEY || "", shop });
};

export default function Accounts() {
  const { apiKey, shop } = useLoaderData<typeof loader>();

  return (
    <AppProvider isEmbeddedApp={true} apiKey={apiKey}>
      <NavMenu>
        {shop?.shop_is_active && (
          <a href="/app" rel="home">
            Home
          </a>
        )}
        {shop?.shop_is_active && (
          <a href="/app/catalogue" rel="products">
            Catalogue
          </a>
        )}
        {shop?.shop_is_active && <a href="/app/orders">Orders</a>}
        {shop?.shop_is_active && <a href="/app/transactions">Transactions</a>}
        {shop?.shop_is_active && <a href="/app/collection">Collection</a>}
        {shop?.shop_is_active && <a href="/customizer">Customize Your App</a>}
        {shop?.shop_is_active && <a href="/videos">Reel & Stories</a>}
        {/* <a href="/app/chat">Chat</a> */}
        {shop?.shop_is_active && <a href="/app/reviews">Reviews</a>}
        {shop?.shop_is_active && <a href="/app/subscription">Plans</a>}
        {shop?.shop_is_active && <a href="/app/brands">Brands</a>}
        <a href="/accounts">Accounts</a>
        {shop?.shop_is_active && <a href="/settings">Settings</a>}
      </NavMenu>
      <Outlet />
    </AppProvider>
  );
}

// Shopify needs Remix to catch some thrown responses, so that their headers are included in the response.
export function ErrorBoundary() {
  return boundary.error(useRouteError());
}

export const headers: HeadersFunction = (headersArgs) => {
  return boundary.headers(headersArgs);
};
