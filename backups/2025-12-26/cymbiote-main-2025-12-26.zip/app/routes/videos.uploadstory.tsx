import {
  ActionFunctionArgs,
  LoaderFunctionArgs,
  TypedResponse,
} from "@remix-run/node";
import { useLoaderData, useNavigate } from "@remix-run/react";
import { Page } from "@shopify/polaris";
import { authenticate } from "../shopify.server";
import { json } from "@remix-run/node";
import { useEffect, useState } from "react";
import Upload from "~/components/reelsnstories/Upload";
import { uploadToShopify } from "~/functions/common";
import { Loader } from "~/components/common/Loader";
import axios from "axios";

interface loaderreturn {
  search: string;
}
export const action = async ({ request }: ActionFunctionArgs) => {
  const { admin } = await authenticate.admin(request);
  const url = new URL(request.url);
  const shopDomain = url.searchParams.get("shop");
  const ApiKey = process.env.ENV_URL;

  if (!admin) {
    throw new Response("Unauthorized", { status: 401 });
  }
  let imageSrc: string | null = null;
  let videoSrc: string | null = null;
  try {
    const formData = await request.formData();
    const thumbnail = formData.get("thumbnail") as File | null;
    const video = formData.get("video") as File | null;

    const product = formData.get("product") as string;

    console.log("Thumbnail", thumbnail);
    console.log("Video:", video);
    console.log("product", JSON.parse(product));

    if (thumbnail && video) {
      try {
        const imageUpload = await uploadToShopify(
          thumbnail,
          admin,
          thumbnail.name,
        );
        console.log("Image Upload Response:", imageUpload);

        if (imageUpload) {
          const nodeId: string = imageUpload;

          const wait = (ms: number) =>
            new Promise((res) => setTimeout(res, ms));

          const getUploadedImageUrl = async (retries = 5, delay = 2000) => {
            for (let i = 0; i < retries; i++) {
              console.log(
                `Fetching Uploaded Image URL... Attempt ${i + 1}/${retries}`,
              );

              const fileNodeQuery = `
                  {
                    nodes(ids: ["${nodeId}"]) {
                      id
                      ... on MediaImage {
                        image {
                          url
                          id
                        }
                      }
                    }
                  }`;

              try {
                const fileNodeResponse = await admin.graphql(fileNodeQuery);
                const parsedNodeData = await fileNodeResponse.json();
                const fetchedImageSrc =
                  parsedNodeData?.data?.nodes?.[0]?.image?.url;
                console.log("Fetched Image URL:", parsedNodeData?.data?.nodes);
                if (fetchedImageSrc) {
                  return fetchedImageSrc;
                }

                console.log(
                  `Image URL not available yet, retrying in ${delay / 1000} seconds...`,
                );
                await wait(delay);
              } catch (error) {
                console.error("Error fetching image URL:", error);
              }
            }
            throw new Error("Image URL not available after multiple retries.");
          };

          imageSrc = await getUploadedImageUrl(); // Assign value to the outer variable
          console.log("Uploaded Image URL:", imageSrc);
        }
      } catch (imageError) {
        console.error("Failed to upload image:", imageError);
      }
      try {
        const videoupload = await uploadToShopify(
          video,
          admin,
          video.name,
          "VIDEO",
        );
        console.log("Video Upload Response:", videoupload);

        if (videoupload) {
          const nodeId: string = videoupload;

          const wait = (ms: number) =>
            new Promise((res) => setTimeout(res, ms));

          const getUploadedVideoUrl = async (retries = 12, delay = 10000) => {
            for (let i = 0; i < retries; i++) {
              console.log(
                `Fetching Uploaded Video URL... Attempt ${i + 1}/${retries}`,
              );

              const fileNodeQuery = `
            {
             nodes(ids: ["${nodeId}"]) {
                id
                ... on Video {
                  sources {
                      url
                  }
                }
              }
            }
          `;

              try {
                const fileNodeResponse = await admin.graphql(fileNodeQuery);
                const parsedNodeData = await fileNodeResponse.json();
                const FetchedVideoSrc =
                  parsedNodeData?.data?.nodes?.[0]?.sources?.length > 0
                    ? parsedNodeData.data.nodes[0].sources
                    : null;

                console.log("Fetched Video URL:", FetchedVideoSrc);
                if (FetchedVideoSrc) {
                  return FetchedVideoSrc;
                }

                console.log(
                  `Video URL not available yet, retrying in ${delay / 10000} seconds...`,
                );
                ``;
                await wait(delay);
              } catch (error) {
                console.error("Error fetching Video URL:", error);
              }
            }
            throw new Error(
              "Video URL not available yet after multiple retries.",
            );
          };

          videoSrc = await getUploadedVideoUrl(); // Assign value to the outer variable
          console.log("Uploaded Video URL:", videoSrc);        

          const ApiTrigger = axios.post(`${ApiKey}/video-worker/start`)
          console.log("Video Worker Triggered", ApiTrigger)

        }
      } catch (VideoError) {
        console.error("Failed to upload Video:", VideoError);
      }

      const shop = await prisma.shops.findFirst({
        where: {
          shop_domain: shopDomain,
        },
      });
      const video_480 = Array.isArray(videoSrc)
        ? videoSrc.find((v) => v.url.includes("480p"))?.url || null
        : null;
      const video_720 = Array.isArray(videoSrc)
        ? videoSrc.find((v) => v.url.includes("720p"))?.url || null
        : null;
      const video_1080 = Array.isArray(videoSrc)
        ? videoSrc.find((v) => v.url.includes("1080p"))?.url || null
        : null;

      if (shop?.shop_id && videoSrc !== null) {
        const VideoResponse = await prisma.videos.create({
          data: {
            video_shop_id: shop.shop_id,
            //default video url is removed because of video optimization
            // video_url: video_480,
            video_url: video_720,
            video_url_480p: video_480,
            video_url_1080p: video_1080,
            video_url_720p: video_720,
            video_thumbnail_url: imageSrc,
            updated_at: new Date(),
          },
        });
        const VideoId = VideoResponse.video_id;
        console.log("product", product);
        const ReelsProductResponse = await prisma.reels_Products.create({
          data: {
            reel_video_id: VideoId,
            reel_product_id: JSON.parse(product)[0]?.product_id,
          },
        });

        const ReelsNStoryResponse = await prisma.reelsNStories.create({
          data: {
            video_title: JSON.parse(product)[0]?.product_name,
            video_url_id: VideoId,
            video_type: "STORY",
            video_likes_count: 0,
            video_view_count: 0,
            updated_at: new Date(),
          },
        });

      console.log("ReelsProductResponse", ReelsProductResponse);
      console.log("VideoResponse", VideoResponse);
      console.log("ReelsNStoryResponse", ReelsNStoryResponse);

      const ApiTrigger = axios.post(`${ApiKey}/video-worker/start`)
      console.log("Video Worker Triggered", ApiTrigger)
        
      } else {
        console.error("Shop ID is undefined. Cannot create video entry.");
      }
    }

    return json({ success: true });
  } catch (error: any) {
    console.error("Error uploading Story:", error);
    throw new Response(error, { status: 500 });
  }
};

export const loader = async ({ request }: LoaderFunctionArgs) => {
  const url = new URL(request.url);
  return json({ search: url.search });
};

export default function uploadstory() {
  const [isLoading, setIsLoading] = useState(false);
  const { search } = useLoaderData<loaderreturn>();
  const navigate = useNavigate();
  useEffect(() => {
    setIsLoading(true);
  }, []);

  if (!isLoading) {
    return (
      <Page fullWidth>
        <Loader />
      </Page>
    );
  }
  return (
    <Page
      backAction={{
        content: "Reels & Stories",
        onAction: () => navigate({ pathname: "/videos", search }),
      }}
      title="Reels & Stories"
      fullWidth
    >
      <Upload title="Upload Story" search={search} />
    </Page>
  );
}
