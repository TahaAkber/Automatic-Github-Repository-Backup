import { useEffect, useState } from "react";
import type {
  ActionFunctionArgs,
  LoaderFunctionArgs,
  TypedResponse,
} from "@remix-run/node";
import { json, redirect } from "@remix-run/node";
import { useLoaderData, useNavigate, useParams } from "@remix-run/react";
import { Page, Layout, Text } from "@shopify/polaris";
import { authenticate } from "../shopify.server";
import { CalendarButton } from "~/components/common/CalendarButton";
import { CardsSection } from "~/components/dashboard/CardsSection/CardsSection";
import { MiddleSection } from "~/components/dashboard/MiddleSection/MiddleSection";
import { RecentOrderTable } from "~/components/orders/RecentOrderTable";
import { transformOrders } from "~/functions/order";
import { ShopResourceFeedbackCreate } from "~/mutations/appSubscription";
import { useAppBridge } from "@shopify/app-bridge-react";
import { Loader } from "~/components/common/Loader";
import { getUrlParams, retryOperation } from "~/functions/common";
import { Prisma } from "@prisma/client";
import { getshopemailandcurrency } from "~/queries/shop";
import { getAppDomains } from "~/queries/variantImages";

export let API_URL = "";
export let API_KEY = "";

interface LoaderReturn {
  userDetails: any;
  productCount: number;
  orders: {
    count: number;
    cancelledCount: number;
    recentOrders: any[];
  };
  search: string | undefined;
  queryString: string;
  subscriptionRate: number;
  cancellationRate: number;
  shopDomain: string;
  fetchedCircleOrders: any[];
  firstTimeAppLoad: boolean;
  redirectUrl?: string;
  collections?: {
    items: any[];
    count: number;
  };
  productCounts: {
    product_id: number;
    product_name: string;
    count: number;
  }[];
  ENV_URL: string;
  totalSoldOrders: number;
  shopCurrency: any;
  minDate?: Date;
  maxDate?: Date;
}

interface CancellationData {
  ShopID: number;
  ShopDomain: string;
  TotalOrders: number;
  CanceledOrders: number;
  CancellationRate: number;
}

interface DateFilter {
  created_at?: {
    gte: Date;
    lt: Date;
  };
}

export const loader = async ({
  request,
}: LoaderFunctionArgs): Promise<TypedResponse<LoaderReturn>> => {
  console.log("home loader called");
  const { admin } = await authenticate.admin(request);
  const url = new URL(request.url);
  const shopDomain = url.searchParams.get("shop");
  const params = new URLSearchParams(url.search);
  const queryString = params.toString();
  const startDateParam = params.get("startDate");
  const endDateParam = params.get("endDate");

  const filterStartDate = startDateParam ? new Date(startDateParam) : undefined;

  let filterEndDate = endDateParam ? new Date(endDateParam) : undefined;
  if (filterEndDate) {
    filterEndDate.setHours(23, 59, 59, 999);
  }

  const dateFilter: DateFilter = {};
  if (filterStartDate && filterEndDate) {
    dateFilter.created_at = {
      gte: filterStartDate,
      lt: new Date(filterEndDate.getTime() + 86400000), // Add 1 day to include the end date fully if it's 00:00
      // Adjust logic if needed based on CalendarButton output
    };
  }

  API_URL = process.env.EXCHANGE_RATE_API_URL || "";
  API_KEY = process.env.EXCHANGE_RATE_API_KEY || "";
  // let channelId = "";

  const channelQuery = `{
    channels (first: 50){
      edges{
        node{
          id
          name
        }
      }
    }
  }`;

  try {
    // Fetch shop details from Shopify
    const shopDetails = await admin.rest.resources.Shop.all({
      session: admin.rest.session,
    });

    // console.log("shopDetails", shopDetails.data[0]);

    if (shopDetails.data?.length < 1) {
      return json({
        orders: {
          cancelledCount: 0,
          count: 0,
          recentOrders: [],
        },
        userDetails: {},
        productCount: 0,
        search: "",
        queryString,
        subscriptionRate: 0,
        cancellationRate: 0,
        shopDomain: shopDetails + "",
        fetchedCircleOrders: [],
        firstTimeAppLoad: false,
        ENV_URL: process.env.ENV_URL || "",
        productCounts: [],
        totalSoldOrders: 0,
        shopCurrency: "PKR",
      });
    }

    // console.log("shopDetails", shopDetails.data[0]);

    const shopShopifyId = shopDetails.data[0].id; // Assuming 'id' is the Shopify shop ID

    // Check if the shop already exists in the database
    let existingShop = await prisma.shops.findFirst({
      where: {
        shop_domain: shopDomain,
      },
      include: {
        Subscriptions: {
          include: {
            Packages: true,
          },
        },
        Collections: {
          where: {
            collection_type_id: 2,
          },
          include: {
            Collection_Products: true,
          },
        },
      },
    });

    // console.log("existingShop", existingShop);

    const existingSession = await retryOperation(async () => {
      return await prisma.session.findFirst({
        where: {
          shop: shopDetails.data[0].myshopify_domain
            ? shopDetails.data[0].myshopify_domain
            : "",
        },
      });
    });

    // console.log("existingSession", existingSession);

    let domains = await getAppDomains(admin);
    let hostsString = "";

    // If the shop doesn't exist, create a new entry
    if (!existingShop) {
      domains = await getAppDomains(admin);
      hostsString = domains.map((d: any) => d.host).join(",");

      console.log("domains", domains, hostsString);

      const emailandshop = await getshopemailandcurrency(admin);
      existingShop = (await retryOperation(async () => {
        return await prisma.shops.create({
          data: {
            shop_name: shopDetails.data[0].name + "",
            shop_description: shopDetails.data[0].description || null,
            shop_logo_url: shopDetails.data[0].image?.src || null,
            shop_shopify_id: shopShopifyId + "",
            shop_access_token: existingSession?.accessToken,
            shop_address:
              (shopDetails.data[0].address1 ?? "") +
              " " +
              (shopDetails.data[0].address2 ?? ""),
            shop_number: shopDetails.data[0].phone || null,
            shop_domain: existingSession?.shop,
            shop_other_domains: hostsString || null,
            shop_banner_type: "image",
            shop_email: emailandshop?.data?.shop?.email || null,
            shop_currency: emailandshop?.data?.shop?.currencyCode || null,
          },
          include: {
            Subscriptions: {
              include: {
                Packages: true,
              },
            },
            Collections: {
              where: {
                collection_type_id: 2,
              },
              include: {
                Collection_Products: true,
              },
            },
          },
        });
      })) as any;
    } else if (
      existingSession?.accessToken !== existingShop?.shop_access_token ||
      (!existingShop?.shop_other_domains && existingShop !== null)
    ) {
      domains = await getAppDomains(admin);
      hostsString = domains.map((d: any) => d.host).join(",");

      console.log("domains", domains, hostsString);
      existingShop = await prisma.shops.update({
        data: {
          shop_address:
            (shopDetails.data[0].address1 ?? "") +
            " " +
            (shopDetails.data[0].address2 ?? ""),
          shop_number: shopDetails.data[0].phone || null,
          shop_access_token: existingSession?.accessToken,
          shop_other_domains: hostsString || null,
          updated_at: new Date(),
        },
        where: {
          shop_id: existingShop.shop_id,
        },
        include: {
          Subscriptions: {
            include: {
              Packages: true,
            },
          },
          Collections: {
            where: {
              collection_type_id: 2,
            },
            include: {
              Collection_Products: true,
            },
          },
        },
      });
    } else {
      await prisma.shops.update({
        data: {
          shop_address:
            (shopDetails.data[0].address1 ?? "") +
            " " +
            (shopDetails.data[0].address2 ?? ""),
          shop_number: shopDetails.data[0].phone || null,
        },
        where: {
          shop_id: existingShop.shop_id,
        },
      });
    }

    if (existingShop?.shop_delisted === true) {
      console.log("tried to navigate to delisted");
      const redirectUrl = `/delistedreview?` + queryString;
      return redirect(redirectUrl);
    }

    if (existingShop?.shop_is_active === false) {
      console.log("tried to navigate to delisted");
      const redirectUrl = `/accounts?` + queryString;
      return redirect(redirectUrl);
    }

    // Get the product count from the database
    const productCount = await prisma.products.count({
      where: {
        product_is_active: true,
        Shops: {
          shop_domain: shopDomain,
        },
      },
    });

    const channelDetails = await admin.graphql(channelQuery);
    const fetchedChannels = await channelDetails.json();

    const cymbioteChannel = fetchedChannels.data.channels.edges.find(
      (edge: any) => edge.node.name === "cymbiote",
    );

    // Get its ID and extract the numeric part
    // channelId = cymbioteChannel
    //   ? cymbioteChannel.node.id.split("/").pop().toString()
    //   : "";

    // console.log("getCurrentCurrencyRate", getCurrentCurrencyRate("PKR", "USD"));

    // console.log("channelId", channelId);

    const fetchedOrders = await prisma.orders.findMany({
      where: {
        OR: [
          {
            order_channel: "cymbiote",
          },
          {
            order_channel: "cercle",
          },
          {
            order_channel: "cercledev",
          },
        ],
        order_shop_id: existingShop?.shop_id,
        ...dateFilter,
      },
    });

    // Fetch min and max date for orders to constrain calendar
    const orderDateRange = await prisma.orders.aggregate({
      _min: {
        created_at: true,
      },
      _max: {
        created_at: true,
      },
      where: {
        order_shop_id: existingShop?.shop_id,
      },
    });

    const minDate = orderDateRange._min.created_at || undefined;
    const maxDate = orderDateRange._max.created_at || undefined;

    const currentDate = new Date();
    const startOfYear = new Date(currentDate.getFullYear(), 0, 1);
    const endOfYear = new Date(currentDate.getFullYear() + 1, 0, 1);

    const fetchedCircleOrders = await prisma.orders.findMany({
      where: {
        OR: [
          { order_channel: "cymbiote" },
          { order_channel: "cercle" },
          { order_channel: "cercle2" },
        ],
        order_shop_id: existingShop?.shop_id,
        created_at: {
          gte: startOfYear,
          lt: endOfYear,
        },
      },
    });

    const fetchedCancelledOrders = await retryOperation(async () => {
      return await prisma.orders.findMany({
        where: {
          OR: [
            { order_channel: "cymbiote" },
            { order_channel: "cercle" },
            { order_channel: "cercledev" },
          ],
          order_shop_id: existingShop?.shop_id,
          order_cancelled_at: { not: null },
          ...dateFilter,
        },
      });
    });

    const shop = await retryOperation(async () => {
      return await prisma.shops.findFirst({
        where: {
          shop_domain: shopDomain,
          shop_first_load: false,
          Subscriptions: {
            some: {
              subscription_confirmed: true,
              subscription_enabled: true,
            },
          },
        },
      });
    });

    if (shop) {
      const variablesInput = {
        state: "ACCEPTED",
        feedbackGeneratedAt: new Date().toISOString(),
      };
      await ShopResourceFeedbackCreate(admin, variablesInput);
    }

    const cancellationData: CancellationData[] = await prisma.$queryRaw`
      EXEC GetShopCancellationRateByDomain ${shopDomain}`;

    // console.log("cancellationData", cancellationData);

    const recentOrders = await retryOperation(async () => {
      return await prisma.orders.findMany({
        where: {
          OR: [
            { order_channel: "cymbiote" },
            { order_channel: "cercle" },
            { order_channel: "cercledev" },
          ],
          order_shop_id: existingShop?.shop_id,
        },
        include: {
          Users: true,
          Transactions: true,
          Order_Items: true,
        },
        orderBy: {
          created_at: "desc",
        },
        take: 10,
      });
    });

    const soldOrders = await retryOperation(async () => {
      return await prisma.orders.findMany({
        where: {
          order_shop_id: shop?.shop_id,

          order_fulfillment_status: "fulfilled",
          ...dateFilter,
        },
        include: {
          Order_Items: {
            include: {
              Product_Variants: {
                include: {
                  Products: true,
                },
              },
            },
          },
        },
      });
    });
    const totalSoldOrders = soldOrders?.reduce(
      (sum, order) => sum + (order.order_total_amount || 0),
      0,
    );
    const productCountMap: Record<number, { name: string; count: number }> = {};

    soldOrders?.forEach((order) => {
      order.Order_Items.forEach((item) => {
        const product = item.Product_Variants?.Products;
        if (product) {
          const productId = product.product_id;
          if (!productCountMap[productId]) {
            productCountMap[productId] = {
              name: product.product_name,
              count: 1,
            };
          } else {
            productCountMap[productId].count += 1;
          }
        }
      });
    });

    // Convert to array if needed
    const productCounts = Object.entries(productCountMap).map(
      ([product_id, data]) => ({
        product_id: Number(product_id),
        product_name: data.name,
        count: data.count,
      }),
    );
    const shopCurrency = await retryOperation(async () => {
      return await prisma.shops.findFirst({
        where: {
          shop_domain: shopDomain,
        },
      });
    });

    const respObj = {
      shopCurrency: shopCurrency?.shop_currency,
      totalSoldOrders: totalSoldOrders as number,
      productCounts,
      orders: {
        count: fetchedOrders?.length ? fetchedOrders?.length : 0,
        cancelledCount: fetchedCancelledOrders?.length
          ? fetchedCancelledOrders?.length
          : 0,
        recentOrders: recentOrders as any[],
      },
      collections: {
        items:
          existingShop?.Collections as Prisma.Collection_ProductsDefaultArgs[],
        count: existingShop?.Collections?.length as number,
      },
      userDetails: shopDetails.data[0],
      productCount,
      search: url.search,
      queryString,
      subscriptionRate: existingShop?.Subscriptions
        ? existingShop.Subscriptions[0]?.Packages.package_rate || 0 // Ensure you handle null Packages
        : 0,
      cancellationRate:
        cancellationData?.length > 0 ? cancellationData[0].CancellationRate : 0,
      shopDomain: shopDomain + "",
      fetchedCircleOrders: fetchedCircleOrders,
      firstTimeAppLoad: existingShop?.shop_first_load || false,
      redirectUrl: existingShop?.shop_first_load
        ? `/selectcategory?` + queryString
        : "",
      ENV_URL: process.env.ENV_URL || "",
      minDate,
      maxDate,
    };
    // console.log("respObj", respObj);
    return json<LoaderReturn>(respObj);
  } catch (error) {
    console.error("Error getting home page loader:", error);
    throw new Response("Error getting home page loader", {
      status: 500,
    });
  }
};

export const action = async ({ request }: ActionFunctionArgs) => {
  // const { admin } = await authenticate.admin(request);

  return json({});
};

export default function Index() {
  const {
    userDetails,
    productCount,
    orders,
    search,
    queryString,
    subscriptionRate,
    cancellationRate,
    shopDomain,
    fetchedCircleOrders,
    shopCurrency,
    firstTimeAppLoad,
    redirectUrl,
    collections,
    productCounts,
    ENV_URL,
    totalSoldOrders,
    minDate,
    maxDate,
  } = useLoaderData<LoaderReturn>();

  let alreadyCalled = false;
  const shopify = useAppBridge();
  const [{ month, year }, setDate] = useState({
    month: new Date().getMonth(),
    year: new Date().getFullYear(),
  });
  const [selectedDates, setSelectedDates] = useState(() => {
    // data.search comes from loader, so no need for window.location
    const params = new URLSearchParams(search);
    const start = params.get("startDate");
    const end = params.get("endDate");
    return {
      start: start ? new Date(start) : new Date(),
      end: end ? new Date(end) : new Date(),
    };
  });
  const [urlParams, setUrlParams] = useState(getUrlParams());
  const [firstTimeLoad, setFirstTimeLoad] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    console.log("firstTimeAppLoad", firstTimeAppLoad);
    if (firstTimeAppLoad) {
      navigate(redirectUrl ? redirectUrl : "");
      return;
    }
    // if (shopify) {
    //   console.log("user", userDetails);
    // }
    // console.log("subscriptionRate", subscriptionRate);

    cleanUrlParamsOnLoad(["charge_id"]);
    setFirstTimeLoad(false);
  }, []);

  useEffect(() => {
    if (!firstTimeLoad && selectedDates?.start && selectedDates?.end) {
      const currentParams = new URLSearchParams(window.location.search);
      const startStr = selectedDates.start.toISOString().split("T")[0]; // Use standard date string? or just ISO
      const endStr = selectedDates.end.toISOString().split("T")[0];

      if (
        currentParams.get("startDate") !== startStr ||
        currentParams.get("endDate") !== endStr
      ) {
        currentParams.set("startDate", startStr);
        currentParams.set("endDate", endStr);
        const newUrl = `${window.location.pathname}?${currentParams.toString()}`;
        navigate(newUrl); // Use navigate to trigger loader reload
      }
    }
  }, [selectedDates]);

  useEffect(() => {
    const callMetaField = async () => {
      const metaUrl = `/api/createMetafield?${queryString}`;
      console.log("metaUrl", metaUrl);
      const response = await fetch(metaUrl);
      const dataJson = await response.json();
      console.log("API response", dataJson);
    };
    if (shopDomain && !alreadyCalled) {
      alreadyCalled = true;
      callMetaField();
    }
  }, []);

  // console.log("Object", totalSoldOrders);

  useEffect(() => {
    // Check if App Bridge and Web Vitals are available
    if (shopify.webVitals.onReport) {
      shopify.webVitals.onReport((metrics) => {
        // Send the metrics to your server for custom tracking or logging
        console.log("Web Vitals metrics:", metrics);

        // Optionally, you can send this to your own endpoint or a third-party tool
        const monitorUrl = ENV_URL + "/web-vitals-metrics"; // Modify this URL
        console.log("monitorUrl", monitorUrl);
        const data = JSON.stringify(metrics);
        navigator.sendBeacon(monitorUrl, data); // Send data to server
      });
    }
  }, [shopify]);

  const cleanUrlParamsOnLoad = (paramsToRemove: string[]) => {
    const currentParams = new URLSearchParams(window.location.search);
    let paramsChanged = false;

    // Check if any of the target parameters exist and delete them
    paramsToRemove.forEach((paramKey) => {
      if (currentParams.has(paramKey)) {
        currentParams.delete(paramKey);
        paramsChanged = true;
      }
    });

    // Only update history if parameters were actually removed
    if (paramsChanged) {
      // Construct the new URL path (pathname + cleaned search string)
      const newUrl = `${window.location.pathname}${currentParams.toString() ? "?" + currentParams.toString() : ""}`;

      // Update the browser history state without causing a page reload
      window.history.replaceState(null, "", newUrl);

      // Update component state to reflect the clean URL
      setUrlParams(getUrlParams(window));
    }
  };

  if (firstTimeLoad) {
    return (
      <Page fullWidth>
        <Loader />
      </Page>
    );
  }

  return (
    <Page fullWidth>
      <div>
        <Layout>
          <Layout.Section>
            <div style={{ display: "flex", justifyContent: "space-between" }}>
              <Text as="h4" fontWeight="semibold" variant="heading2xl">
                Dashboard
              </Text>
              <CalendarButton
                month={month}
                selectedDates={selectedDates}
                setDate={setDate}
                setSelectedDates={setSelectedDates}
                year={year}
                minDate={minDate ? new Date(minDate) : undefined}
                maxDate={maxDate ? new Date(maxDate) : undefined}
              />
            </div>
          </Layout.Section>

          <Layout.Section>
            <CardsSection
              publishedProducts={productCount}
              totalOrders={orders.count}
              cancelledOrders={orders.cancelledCount}
              totalSale={totalSoldOrders}
              shopCurrency={shopCurrency}
            />
          </Layout.Section>

          <Layout.Section>
            <MiddleSection
              fetchedCircleOrders={fetchedCircleOrders}
              trendingCollections={collections?.items || []}
              productCounts={productCounts}
              search={search}
            />
          </Layout.Section>

          <Layout.Section>
            <RecentOrderTable
              orders={transformOrders(orders.recentOrders)}
              viewType="Recent"
              shopCurrency={shopCurrency}
            />
          </Layout.Section>
        </Layout>
      </div>
    </Page>
  );
}
