import react, { useCallback, useEffect, useState } from "react";
import { Page } from "@shopify/polaris";
import {
  json,
  LoaderFunctionArgs,
  TypedResponse,
  ActionFunctionArgs,
} from "@remix-run/node";
import { useFetcher, useLoaderData, useNavigate } from "@remix-run/react";
import CollectionTable from "~/components/collection/CollectionTable";
import { CollectionAction, CollectionLoader } from "~/types/CollectionLoader";
import { authenticate } from "~/shopify.server";
import { CollectionsQuery } from "~/queries/Collections";
import {
  addShopifyCollectiontoDatabase,
  removeCollection,
} from "~/mutations/createCollection";
import { Loader } from "~/components/common/Loader";
import { useLocation } from "@remix-run/react";

export const loader = async ({
  request,
}: LoaderFunctionArgs): Promise<TypedResponse<CollectionLoader>> => {
  const url = new URL(request.url);
  const shopDomain = url.searchParams.get("shop");

  if (!shopDomain) {
    throw new Response("Missing shop domain", { status: 400 });
  }

  try {
    const { admin } = await authenticate.admin(request);

    const collectionsResponse = await CollectionsQuery(admin);

    if (!collectionsResponse?.data?.collections?.nodes) {
      throw new Error("Invalid collections response");
    }
    const shop = await prisma.shops.findFirst({
      where: {
        shop_domain: shopDomain,
      },
    });
    const filterCollection = await prisma.collections.findMany({
      where: {
        collection_shop_id: shop?.shop_id,
        collection_type_id: 3,
      },
      include: {
        Collection_Types: true,
      },
    });
    const trendingCollection = await prisma.collections.findMany({
      where: {
        collection_shop_id: shop?.shop_id,
        collection_type_id: 2,
      },
      include: {
        Collection_Types: true,
      },
    });
    const simpleCollection = await prisma.collections.findMany({
      where: {
        collection_type_id: 1,
        collection_shop_id: shop?.shop_id,
      },
      include: {
        Collection_Types: true,
      },
    });
    const shopifyCollections =
      collectionsResponse?.data?.collections?.nodes || [];
    const shopifyCollectionIds =
      collectionsResponse?.data?.collections?.nodes.map((node: any) => node.id);

    const filterTrendingAndSimpleIds = new Set([
      ...filterCollection.map((c: any) => c.collection_shopify_id),
      ...trendingCollection.map((c: any) => c.collection_shopify_id),
      ...simpleCollection.map((c: any) => c.collection_shopify_id),
    ]);

    const filteredShopifyCollections = shopifyCollections.filter(
      (collection: any) => !filterTrendingAndSimpleIds.has(collection.id),
    );

    return json({
      search: url.search,
      collections: simpleCollection,
      filterCollection: filterCollection,
      trendingCollection: trendingCollection,
      shopifyCollections: filteredShopifyCollections,
    });
  } catch (error) {
    console.error("Error in loader:", error);
    return json(
      {
        search: "",
        collections: [],
        filterCollection: [],
        trendingCollection: [],
        // collectionfilters: [],
        shopifyCollections: [],
        error: "Failed to load data",
      },
      { status: 500 },
    );
  }
};

export const action = async ({
  request,
}: ActionFunctionArgs): Promise<TypedResponse<CollectionAction>> => {
  console.log("Action Triggered");
  try {
    const url = new URL(request.url);
    const shopDomain = url.searchParams.get("shop");
    if (!shopDomain) {
      throw new Response("Missing shop domain", { status: 400 });
    }
    const { admin } = await authenticate.admin(request);
    if (!admin) {
      console.log("Admin Authentication failed");
    }

    const formData = await request.formData();
    const selected = formData.get("type");
    const rawShopifyId = formData.get("Shopify_id");
    const deleteFlag = formData.get("delete");
    const simpleFlag = formData.get("MoveToSimple");
    const shopify_id = rawShopifyId
      ? rawShopifyId
          .toString()
          .split(",")
          .map((id) => id.trim())
      : [];
    const shop = await prisma.shops.findFirst({
      where: {
        shop_domain: shopDomain,
      },
    });
    if (shopify_id.length === 0) {
      console.error("No Shopify IDs found to delete!");
    }

    if (selected == "3") {
      const addCollectionPromises = shopify_id.map(async (id) => {
        return await addShopifyCollectiontoDatabase(admin, id, shop);
      });
      const collectionData = await Promise.all(addCollectionPromises);
    } else if (
      deleteFlag === "delete" &&
      (selected == "0" || selected == "2")
    ) {
      const shopifyIds = Array.isArray(shopify_id) ? shopify_id : [shopify_id];

      const targetTypeId = selected == "0" ? 1 : 3;

      const collectionsByType = await prisma.collections.findMany({
        where: {
          collection_shopify_id: {
            in: shopifyIds,
          },
          collection_type_id: targetTypeId,
          collection_shop_id: shop?.shop_id,
        },
      });

      const collectionIds = collectionsByType.map((c: any) => c.collection_id);

      if (collectionIds.length === 0) {
        console.warn("No collections found to delete for deleteFlag flow");
      } else {
        await prisma.collection_Products.deleteMany({
          where: {
            collection_id: {
              in: collectionIds,
            },
          },
        });

        await prisma.collections.deleteMany({
          where: {
            collection_id: {
              in: collectionIds,
            },
            collection_shop_id: shop?.shop_id,
          },
        });
      }
    } else if (simpleFlag === "MoveToSimple" && selected == "2") {
      const existingSimple = await prisma.collections.findMany({
        where: {
          collection_shopify_id: {
            in: shopify_id,
          },
          collection_type_id: 1,
          collection_shop_id: shop?.shop_id,
        },
        select: { collection_shopify_id: true },
      });

      const existingSimpleIds = new Set(
        existingSimple.map((c: any) => c.collection_shopify_id),
      );
      const moveableShopifyIds = shopify_id.filter(
        (id: string) => !existingSimpleIds.has(id),
      );

      if (moveableShopifyIds.length === 0) {
        console.warn("All selected collections already exist in Simple");
        return json({ success: true });
      }

      const collections = await prisma.collections.findMany({
        where: {
          collection_shopify_id: {
            in: moveableShopifyIds,
          },
          collection_type_id: 3,
          collection_shop_id: shop?.shop_id,
        },
      });

      if (collections.length > 0) {
        const newRows = collections.map((row: any) => {
          const { collection_id, ...rest } = row;

          return {
            ...rest,
            collection_type_id: 1,
          };
        });

        await prisma.collections.createMany({
          data: newRows,
        });
      } else {
        console.warn("No filter collections found to move to Simple");
      }
    } else {
      const deletionPromises = shopify_id.map(async (id) => {
        return await removeCollection(admin, id);
      });
      const removecollectiondata = await Promise.all(deletionPromises);

      let existingCollections = await prisma.collections.findMany({
        where: {
          collection_shopify_id: { in: shopify_id },
          collection_shop_id: shop?.shop_id,
        },
        select: { collection_shopify_id: true, collection_id: true },
      });

      let existingIds = existingCollections.map(
        (c: any) => c.collection_shopify_id,
      );

      if (existingIds.length === 0) {
        console.warn(
          "No matching collections found by Shopify ID, checking by collection_id.",
        );

        const numericIds = shopify_id
          .map((id) => Number(id.split("/").pop()))
          .filter((id) => !isNaN(id));

        if (numericIds.length > 0) {
          existingCollections = await prisma.collections.findMany({
            where: {
              collection_id: { in: numericIds },
              collection_shop_id: shop?.shop_id,
            },
            select: { collection_shopify_id: true, collection_id: true },
          });

          existingIds = existingCollections.map((c: any) =>
            c.collection_id.toString(),
          );
        } else {
          console.warn("No valid numeric collection IDs found in fallback.");
        }
      }

      if (existingIds.length === 0) {
        console.warn("No matching collections found in DB. Skipping deletion.");
        return json({
          success: false,
          message: "No matching collections found in DB",
        });
      }
      const collectionShopifyIds = existingCollections.map(
        (c: any) => c.collection_shopify_id,
      );
      const collectionIds = existingCollections.map(
        (c: any) => c.collection_id,
      );

      let response;
      if (collectionShopifyIds.length > 0) {
        await prisma.collection_Products.deleteMany({
          where: {
            collection_id: { in: collectionIds },
          },
        });
        response = await prisma.collections.deleteMany({
          where: {
            collection_shopify_id: { in: collectionShopifyIds },
          },
        });
      }

      if (collectionIds.length > 0) {
        await prisma.collection_Products.deleteMany({
          where: {
            collection_id: { in: collectionIds },
          },
        });
        response = await prisma.collections.deleteMany({
          where: {
            collection_id: { in: collectionIds },
          },
        });
      }
    }

    return json({ success: true });
  } catch (error) {
    console.error("Error in Action:", error);
    return json({ success: false });
  }
};

export default function collection() {
  const navigate = useNavigate();
  const location = useLocation();
  const fetcher = useFetcher();
  const {
    search,
    collections,
    filterCollection,
    trendingCollection,
    shopifyCollections,
  } = useLoaderData<CollectionLoader>();
  const [deleteloading, setdeleteloading] = useState(false);
  const [editloading, seteditloading] = useState(false);
  const [collectionloading, setcollectionloading] = useState(false);
  const [unPublishCollectionLoading, setunPublishCollectionLoading] =
    useState(false);
  const [trendingcollection, settrendingcollection] =
    useState(trendingCollection);
  const [filtercollection, setfiltercollection] = useState(filterCollection);
  const [simplecollection, setsimplecollection] = useState(collections);
  const [resetSelections, setResetSelections] = useState(false);
  const [isPostBack, setIsPostBack] = useState(false);
  const [currentTabSelections, setCurrentTabSelections] = useState<string[]>(
    [],
  );
  const [MoveToSimpleLoading, setMoveToSimpleLoading] = useState(false);
  const [activePublish, setActivePublish] = useState(false);
  const [isPublishing, setisPublishing] = useState(false);
  const [selected, setSelected] = useState(0);
  const { some } = location.state || {};
  const [selectedCollectionType, setSelectedCollectionType] = useState<
    string[]
  >([]);
  const fetchCollections = useCallback(async () => {
    try {
      setIsPostBack(false);
      const response = await fetch(`/api/collections${search}`);
      const data = await response.json();
      settrendingcollection(data.trendingCollection);
      setfiltercollection(data.filterCollection);
      setsimplecollection(data.collections);
      setIsPostBack(true);
    } catch (error) {
      console.error("Error fetching collections:", error);
    }
  }, []);

  useEffect(() => {
    if (some) {
      if (some === "0") {
        setSelected(0);
      } else if (some === "1") {
        setSelected(1);
      } else if (some === "2") {
        setSelected(2);
      }
    }
    fetchCollections();
    setIsPostBack(false);
  }, [some]);

  useEffect(() => {
    setIsPostBack(true);
  }, []);

  const handleDelete = async () => {
    const formData = new FormData();
    formData.append("Shopify_id", currentTabSelections.join(","));
    await fetcher.submit(formData, {
      method: "POST",
      encType: "multipart/form-data",
    });
    setdeleteloading(true);
  };

  const handleEdit = async (currentTabSelections: any) => {
    const gid = currentTabSelections;
    const id = gid[0].split("/").pop();
    seteditloading(true);
    const urlParams = new URLSearchParams(search);
    urlParams.delete("id");
    urlParams.delete("type");
    urlParams.append("id", id || "");
    urlParams.append("type", selected.toString());
    if (search) {
      const existingParams = new URLSearchParams(search);
      existingParams.forEach((value, key) => {
        if (!urlParams.has(key)) {
          urlParams.append(key, value);
        }
      });
    }
    const targetUrl = `/app/collection/editcollection?${urlParams.toString()}`;
    navigate(targetUrl, {
      relative: "path",
    });
  };

  const handlepublish = async (currentTabSelections: any) => {
    // setisPublishing(true);
    // const formData = new FormData();
    // formData.append("Shopify_id", currentTabSelections.join(","));
    // formData.append("type", selected.toString());
    // await fetcher.submit(formData, {
    //   method: "POST",
    //   encType: "multipart/form-data",
    // });
    setActivePublish(true);
  };

  const handleConfirmPublish = async (currentTabSelections: any) => {
    setisPublishing(true);
    const formData = new FormData();
    formData.append("Shopify_id", currentTabSelections.join(","));
    formData.append("type", selected.toString());
    await fetcher.submit(formData, {
      method: "POST",
      encType: "multipart/form-data",
    });
    setActivePublish(false);
  };

  const handleCreateCollection = async () => {
    setcollectionloading(true);
    navigate(`/app/collection/insertcollection${search}`, {
      relative: "path",
      state: { some: selected },
    });
  };

  const selectedIds = new Set(currentTabSelections);
  const isCurrentTabShopify = (() => {
    if (selected === 0) {
      return simplecollection.some(
        (item: any) =>
          selectedIds.has(item.collection_shopify_id) &&
          item.collection_is_shopify === true,
      );
    }

    if (selected === 2) {
      return filtercollection.some(
        (item: any) =>
          selectedIds.has(item.collection_shopify_id) &&
          item.collection_is_shopify === true,
      );
    }

    return false;
  })();
  const hasSelection = currentTabSelections.length > 0;
  const simpleShopifyIdSet = new Set(
    simplecollection.map((item: any) => item.collection_shopify_id),
  );
  const hasSimpleDuplicateSelection =
    selected === 2 &&
    currentTabSelections.some((id: string) => simpleShopifyIdSet.has(id));

  const unPublishCollection = async () => {
    setunPublishCollectionLoading(true);
    const formData = new FormData();
    formData.append("Shopify_id", currentTabSelections.join(","));
    formData.append("delete", "delete");
    formData.append("type", selected.toString());

    await fetcher.submit(formData, {
      method: "POST",
      encType: "multipart/form-data",
    });

    console.log(
      "formdata",
      currentTabSelections.join(","),
      selected.toString(),
    );
  };

  const handleMoveToSimple = async () => {
    setMoveToSimpleLoading(true);
    const formData = new FormData();
    formData.append("Shopify_id", currentTabSelections.join(","));
    formData.append("MoveToSimple", "MoveToSimple");
    formData.append("type", selected.toString());
    await fetcher.submit(formData, {
      method: "POST",
      encType: "multipart/form-data",
    });
  };

  useEffect(() => {
    const data = fetcher?.data as { success?: boolean } | undefined;
    if (data?.success === true) {
      setdeleteloading(false);
      setCurrentTabSelections([]);
      setResetSelections(true);
      seteditloading(false);
      setcollectionloading(false);
      setisPublishing(false);
      setunPublishCollectionLoading(false);
      setMoveToSimpleLoading(false);
    }
    if (data?.success === false) {
      setdeleteloading(false);
      seteditloading(false);
      setcollectionloading(false);
      setResetSelections(true);
      setunPublishCollectionLoading(false);
      setMoveToSimpleLoading(false);
    }
    fetchCollections();
  }, [fetcher?.data]);

  if (!isPostBack) {
    return (
      <Page fullWidth>
        <Loader />
      </Page>
    );
  }

  console.log("selected", selected, currentTabSelections);

  return (
    <Page
      backAction={{
        content: "Collections",
        onAction: () => navigate({ pathname: "/app", search }),
      }}
      title="Collections"
      fullWidth
      primaryAction={
        selected == 3
          ? {
              content: "Publish Collection",
              onAction: () => {
                handlepublish(currentTabSelections);
              },
              loading: isPublishing,
              disabled: currentTabSelections.length == 0,
            }
          : {
              content: "Create Collection",
              onAction: () => {
                handleCreateCollection();
              },
              loading: collectionloading,
            }
      }
      secondaryActions={
        hasSelection && selected != 3 && !isCurrentTabShopify
          ? [
              {
                content: "Delete Collection",
                onAction: () => {
                  handleDelete();
                },
                loading: deleteloading,
              },
              ...(currentTabSelections.length < 2
                ? [
                    {
                      content: "Edit Collection",
                      onAction: () => {
                        handleEdit(currentTabSelections);
                      },
                      loading: editloading,
                    },
                  ]
                : []),
            ]
          : isCurrentTabShopify && hasSelection
            ? [
                {
                  content: "UnPublish Collection",
                  onAction: () => {
                    unPublishCollection();
                  },
                  loading: unPublishCollectionLoading,
                },
                ...(selected == 2 && !hasSimpleDuplicateSelection
                  ? [
                      {
                        content: "Move To Simple Collection",
                        onAction: () => {
                          handleMoveToSimple();
                        },
                        loading: MoveToSimpleLoading,
                      },
                    ]
                  : []),
              ]
            : []
      }
    >
      <CollectionTable
        collections={simplecollection}
        filterCollection={filtercollection}
        trendingCollection={trendingcollection}
        shopifyCollections={shopifyCollections}
        setCurrentTabSelections={setCurrentTabSelections}
        currentTabSelections={currentTabSelections}
        resetSelections={resetSelections}
        setResetSelections={setResetSelections}
        setSelected={setSelected}
        selected={selected}
        setActivePublish={setActivePublish}
        activePublish={activePublish}
        handleConfirmPublish={handleConfirmPublish}
        isPublishing={isPublishing}
        setSelectedCollectionType={setSelectedCollectionType}
        selectedCollectionType={selectedCollectionType}

        // allResourcesSelected={allResourcesSelected}
        // collectionfilters={collectionfilters}
      />
    </Page>
  );
}
