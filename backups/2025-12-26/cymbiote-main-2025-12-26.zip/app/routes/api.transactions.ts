import { json, LoaderFunctionArgs, TypedResponse } from "@remix-run/node";
import { retryOperation } from "~/functions/common";
import { authenticate } from "~/shopify.server";
import { SubscriptionLoaderReturn } from "~/types/Subscriptions/SubscriptionLoaderReturn";

export const loader = async ({
  request,
}: LoaderFunctionArgs): Promise<TypedResponse<SubscriptionLoaderReturn>> => {
  const { admin } = await authenticate.admin(request);
  const url = new URL(request.url);

  const shopDomain = url.searchParams.get("shop");
  const subId = url.searchParams.get("subId");
  const page = Number(url.searchParams.get("page"));
  const itemsPerPage = 10;
  const skip = (page - 1) * itemsPerPage;

  console.log("shopDomain", shopDomain);

  // Fetch shop + subscriptions
  const shop = await prisma.shops.findFirst({
    where: {
      shop_domain: shopDomain,
    },
    include: {
      Subscriptions: {
        where: {
          subscription_enabled: true,
          subscription_confirmed: true,
        },
      },
    },
  });

  console.log("shop_id inside fetch", shop?.shop_id);

  try {
    // Total count
    const totalTransactions = await prisma.transactions.count({
      where: {
        transaction_shop_id: shop?.shop_id,
        transaction_subscription_id: Number(subId),
      },
    });

    let transactionsWithOrders;

    // -----------------------------------------
    // 🆕 If page = 0 → return ALL transactions
    // -----------------------------------------
    if (page === 0) {
      transactionsWithOrders = await retryOperation(async () => {
        return await prisma.transactions.findMany({
          where: {
            transaction_shop_id: shop?.shop_id,
            transaction_subscription_id: Number(subId),
          },
          include: {
            Orders: {
              select: {
                order_id: true,
                order_date: true,
                order_total_amount: true,
                order_delivery_address: true,
                order_fulfillment_status: true,
                order_charge_rate: true,
                order_shopify_id: true,
              },
            },
          },
          orderBy: {
            created_date: "desc",
          },
        });
      });
    } else {
      // -----------------------------------------
      // Normal pagination (page >= 1)
      // -----------------------------------------
      transactionsWithOrders = await retryOperation(async () => {
        return await prisma.transactions.findMany({
          where: {
            transaction_shop_id: shop?.shop_id,
            transaction_subscription_id: Number(subId),
          },
          include: {
            Orders: {
              select: {
                order_id: true,
                order_date: true,
                order_total_amount: true,
                order_delivery_address: true,
                order_fulfillment_status: true,
                order_charge_rate: true,
                order_shopify_id: true,
              },
            },
          },
          skip,
          take: itemsPerPage,
          orderBy: {
            created_date: "desc",
          },
        });
      });
    }

    console.log("transactions with orders found", transactionsWithOrders);

    const billingCycle = {
      start: shop?.Subscriptions[0]?.subscription_charge_date || new Date(),
      end: shop?.Subscriptions[0]?.subscription_ends_at || new Date(),
    };

    return json<SubscriptionLoaderReturn>({
      transactions: transactionsWithOrders || [],
      totalTransactions,
      itemsPerPage,
      currentPage: page,
      search: url.search,
      billingCycle,
    });
  } catch (error) {
    console.error("Error Getting Transactions:", error);
    throw new Response("Error Getting Transactions", {
      status: 500,
    });
  }
};
