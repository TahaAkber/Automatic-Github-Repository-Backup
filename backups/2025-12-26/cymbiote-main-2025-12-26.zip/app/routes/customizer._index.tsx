import { useEffect, useMemo, useRef, useState } from "react";
import { createApp } from "@shopify/app-bridge";
import { Fullscreen } from "@shopify/app-bridge/actions";
import { json, useFetcher, useLoaderData, useNavigate } from "@remix-run/react";
import { redirect, LoaderFunction, ActionFunctionArgs } from "@remix-run/node";
import "../styles/customizerstyles.css";
import { HTML5Backend } from "react-dnd-html5-backend";
import { DndProvider } from "react-dnd";
import { PlayIcon } from "@shopify/polaris-icons";
import { EditIcon } from "@shopify/polaris-icons";
import { NotificationIcon } from "@shopify/polaris-icons";
import { SearchIcon } from "@shopify/polaris-icons";
import {
  Page,
  Layout,
  Card,
  DropZone,
  BlockStack,
  InlineStack,
  Button,
  ChoiceList,
  TextField,
  Text,
  ButtonGroup,
  rgbToHex,
  hsbToRgb,
  hexToRgb,
  rgbToHsb,
  Icon,
  Image as Imager,
  Box,
} from "@shopify/polaris";
import { getCurrentTime } from "~/functions/common";
import { DropZoneDnD } from "~/components/customizer/mobile_view/DropZoneDnD";
import { LoadingSkeleton } from "~/components/customizer/LoadingSkeleton";
import { ShopTiles } from "~/components/customizer/mobile_view/ShopTiles";
import ConfirmationModal from "~/components/modals/ConfirmationModal";
import { Redirect } from "@shopify/app-bridge/actions"; // Corrected import
import VideoModal from "~/components/modals/VideoModal";
import {
  authenticateAdmin,
  getShopAndHandleSubscription,
  parseCustomizerForm,
  updateShopConfiguration,
  uploadAssetsAndFetchUrls,
} from "~/functions/customizer_action";
import {
  createLayoutIfMissing,
  getfilterCollections,
  getFiltersAndOptions,
  getShopProducts,
  getshopreviews,
  getshopvideos,
  getShopWithSubscription,
  getsimpleCollections,
  getTilesOptions,
  handleShopSubscription,
} from "~/functions/customizer_loader";
import { Title } from "~/components/customizer/mobile_view/Title";
import Banner from "~/components/customizer/mobile_view/Banner";
import CollectionDropdown from "~/components/customizer/CollectionDropdown";
import { StoreDetails } from "~/components/customizer/StoreDetails";
import { fetchAppInstallation } from "~/queries/App";
import { authenticate } from "~/shopify.server";

interface Filter {
  shop_filter_value: string; // Adjust according to your actual DB structure
  options: Filter_Options[]; // Assume there's a relation that gives an array of options
}

interface Filter_Options {
  filter_option_id: number;
  filter_option_value: string;
  filter_option_shop_filter_id: number;
  created_at: Date;
  updated_at: Date;
}

type ActionResponse = {
  success: boolean;
  message: string;
  redirectUrl: string;
  videoNodeId?: string;
};

const MIN_LOGO_WIDTH = 200;
const MIN_LOGO_HEIGHT = 200;
const ALLOWED_IMAGE_TYPES = [
  "image/png",
  "image/jpeg",
  "image/jpg",
  "image/gif",
  "image/webp",
  "image/heic",
];

const ALLOWED_VIDEO_TYPES = ["video/mp4", "video/quicktime"];

const MAX_IMAGE_SIZE_MB = 25;
const MAX_VIDEO_SIZE_MB = 50;
const MAX_VIDEO_DURATION = 30;

// Loader to fetch necessary data (e.g., Shopify API key and host)
export const loader: LoaderFunction = async ({ request }) => {
  const EXCHANGE_RATE_API_URL = process.env.EXCHANGE_RATE_API_URL || "";
  const EXCHANGE_RATE_API_KEY = process.env.EXCHANGE_RATE_API_KEY || "";
  const { admin } = await authenticate.admin(request);
  const url = new URL(request.url);
  const host = url.searchParams.get("host");
  const shopDomain = url.searchParams.get("shop");
  const chargesId = url.searchParams.get("charge_id");
  const tileTypeId = url.searchParams.get("tileTypeId");
  const apiKey = process.env.SHOPIFY_API_KEY;

  let shop = await getShopWithSubscription(shopDomain);
  if (chargesId) {
    const { activeSubscriptions: activeSub } =
      await fetchAppInstallation(admin);

    if (!activeSub) {
      console.error("No installed app found");
      return redirect("/app");
    }
    shop = await handleShopSubscription(
      shop,
      tileTypeId,
      chargesId,
      activeSub,
      EXCHANGE_RATE_API_URL,
      EXCHANGE_RATE_API_KEY,
    );
  }

  const layout = await createLayoutIfMissing(shop?.shop_id);
  const choiceArray = await getTilesOptions(shop);
  const products = await getShopProducts(shopDomain);
  const { filters, filterOptions } = await getFiltersAndOptions(shop?.shop_id);
  console.log("filters", filters, filterOptions);
  const ReviewSum = await getshopreviews(shop?.shop_id);
  console.log("ReviewsSum", ReviewSum);
  const filtercollections = await getfilterCollections(shop?.shop_id);
  // console.log("filter collections", filtercollections);
  const videos = await getshopvideos(shop?.shop_id);
  const simplecollection = await getsimpleCollections(shop?.shop_id);

  // console.log("simple", simplecollection);
  return json({
    apiKey,
    host,
    products,
    search: url.search,
    shop,
    shopTileType: tileTypeId || shop?.shop_tile_type,
    filtercollections,
    filters,
    filterOptions,
    shopDomain,
    ReviewSum,
    simplecollection,
    videos,
    sequenceAvailable: layout ?? [
      "banner",
      "filters",
      "productCards",
      "productItemsList",
      "productVideos",
    ],
    choiceArray,
  });
};

// In this function first we check if shopdomain is available
// then If the banner and logo or logotext was provided if not available previously
// then upload the banner and logo if provided
// then wait for 2sec to update logo information on shopify then get image urls
// then save other details and links to the db with store details
// also check if the filters are updated or any new filer is available so add it as well
export const action = async ({ request }: ActionFunctionArgs) => {
  try {
    const APP_ON_TEST = process.env.APP_ON_TEST === "true";
    const { admin, shopDomain } = await authenticateAdmin(request);
    const formData = await parseCustomizerForm(request);
    const { shop, redirectUrl } = await getShopAndHandleSubscription(
      admin,
      shopDomain,
      formData,
      APP_ON_TEST,
    );

    console.log("testingformdata", formData);
    const { uploadedBannerNodeId, bannerImageUrl, logoImageUrl, shopCoverUrl } =
      await uploadAssetsAndFetchUrls(admin, formData);

    console.log(
      "bannerType",
      formData.bannerType,
      formData.tileType,
      redirectUrl,
    );

    setTimeout(() => {
      updateShopConfiguration(
        shop,
        formData,
        bannerImageUrl,
        logoImageUrl,
        shopCoverUrl,
      );
    }, 2000);

    const response: any = {
      success: true,
      message:
        formData.bannerType === "video" &&
        !bannerImageUrl &&
        uploadedBannerNodeId
          ? "partial success"
          : "success",
      redirectUrl,
    };

    if (formData.bannerType === "video") {
      response.videoNodeId = uploadedBannerNodeId;
    }

    return json(response, { status: 201 });
  } catch (error: any) {
    console.error("Customizer Error:", error.message);
    return json(
      { success: false, message: "failed", redirectUrl: "" },
      { status: 500 },
    );
  }
};

export default function Customizestore() {
  const fetcher = useFetcher<ActionResponse>();
  const {
    filters: initialFilters,
    filterOptions: initialFilterOptions,
    apiKey,
    host,
    products,
    search,
    shop,
    sequenceAvailable,
    shopTileType,
    choiceArray,
    ReviewSum,
    videos,
    simplecollection,
    filtercollections,
  } = useLoaderData<typeof loader>();
  const commingCollections = shop.shop_selected_collections?.split(",") || [];
  const [showModal, setShowModal] = useState(false);
  const upcommingHex = hexToRgb(shop?.shop_color);
  const upcommingfontHex = hexToRgb(shop?.shop_font_color);
  const [color, setColor] = useState<any>(
    shop.shop_color
      ? rgbToHsb(upcommingHex)
      : {
          alpha: 1,
          brightness: 1,
          hue: 222.98507462686567,
          saturation: 0.3125,
        },
  );
  const [colorfont, setcolorfont] = useState<any>(
    shop.shop_font_color
      ? rgbToHsb(upcommingfontHex)
      : {
          alpha: 1,
          brightness: 1,
          hue: 222.98507462686567,
          saturation: 0.3125,
        },
  );
  const [storeColor, setStoreColor] = useState(shop?.shop_color);
  const [fontColor, setFontColor] = useState(shop?.shop_font_color);
  const [showfilesizeModal, setShowFilesizeModal] = useState(false);
  const [modalActive, setModalActive] = useState(false);
  const [secondModal, setSecondModal] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isFirstLoad, setIsFirstLoad] = useState(true);
  // const [newFilterName, setNewFilterName] = useState(""); // State for new filter name
  // const [newOption, setNewOption] = useState<{ [key: string]: string }>({});
  const [filters, setFilters] = useState(initialFilters || []); // Initialize filters
  const [filterOptions, setFilterOptions] = useState(
    initialFilterOptions || {},
  );
  const [shopTileOption, setShopTileOption] = useState(
    shopTileType.toString() || "1",
  );
  const [videoThumbnail, setVideoThumbnail] = useState<string | null>(null);

  // States to manage banner, logo, filters, and product layout
  const [banner, setBanner] = useState<File | null>(null);
  const [bannerUrl, setBannerUrl] = useState(shop.shop_cover_url || "");
  const [logo, setLogo] = useState<File | null>(null);
  const [productLayout, setProductLayout] = useState("vertical");
  const [displayOption, setDisplayOption] = useState(
    shop.shop_header_type ? shop.shop_header_type : "logo",
  );
  const [bannerOption, setBannerOption] = useState(
    shop.shop_banner_type ? shop.shop_banner_type : "image",
  );
  const [shopCover, setshopCover] = useState<File | null>(null);
  const [sequence, setSequence] = useState<string[]>(
    sequenceAvailable
      ? sequenceAvailable
      : [
          "banner",
          "filters",
          "productCards",
          "productItemsList",
          "productVideos",
        ],
  );
  const [headerText, setHeaderText] = useState(
    shop.shop_name ? shop.shop_name : "",
  );
  const [shopDetails, setShopDetails] = useState({
    email: "",
    phoneNumber: "",
    address: "",
    instagram: "",
    facebook: "",
    twitter: "",
    returnPolicy: "",
    privacyPolicy: "",
  });
  const shopCurrency = shop?.shop_currency || "PKR";
  const [initialValues, setInitialValues] = useState({
    headerText: shop.shop_name || "",
    displayOption: shop.shop_header_type || "text",
    bannerOption: shop.shop_banner_type || "image",
    shopCover: (shop.shop_cover_url as File) || null,
    shopTileOption: shopTileType.toString() || "1",
    logo: null as File | null,
    banner: null as File | null,
    productLayout: "vertical",
    filters: filters || [],
    filterOptions: filterOptions || {},
    sequence,
    storeColor,
    fontColor,
    selectedCollectionOptions: commingCollections,
    email: shop.shop_email || "",
    phoneNumber: shop.shop_number || "",
    address: shop.shop_address || "",
    instagram: shop.shop_instagram_url || "",
    facebook: shop.shop_facebook_url || "",
    twitter: shop.shop_twitter_url || "",
    privacyPolicy: shop.shop_privacy_policy_url || "",
    returnPolicy: shop.shop_return_policy_url || "",
  });
  const [selectedCollectionOptions, setSelectedCollectionOptions] =
    useState<string[]>(commingCollections);
  const [hasChanges, setHasChanges] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  const navigate = useNavigate();

  useEffect(() => {
    // Initialize Shopify App Bridge
    const app = createApp({
      apiKey,
      host,
    });

    // Enable fullscreen mode
    const fullscreen = Fullscreen.create(app);
    fullscreen.dispatch(Fullscreen.Action.ENTER);

    setIsFirstLoad(false);

    // Cleanup: Exit fullscreen when the component unmounts
    return () => {
      fullscreen.dispatch(Fullscreen.Action.EXIT);
    };
  }, [apiKey, host]);

  useEffect(() => {
    if (shopTileOption === "7" || shopTileOption === "9") {
      console.log("banner option to video");
      setBannerOption("video");
    } else {
      console.log("banner option to image");
      setBannerOption("image");
    }
    console.log("shopTileOption Changed", shopTileOption);
  }, [shopTileOption]);

  // check if something is changed
  useEffect(() => {
    if (banner !== initialValues.banner) {
      console.log("banner changed", banner, initialValues.banner);
      setHasChanges(true);
    } else if (logo !== initialValues.logo) {
      console.log("logo changed");
      setHasChanges(true);
    } else if (displayOption !== initialValues.displayOption) {
      console.log(" displayOption changed");
      setHasChanges(true);
    } else if (bannerOption !== initialValues.bannerOption) {
      console.log("bannerOption changed");
      setHasChanges(true);
    } else if (shopTileOption !== initialValues.shopTileOption) {
      console.log("shopTileOption changed");
      setHasChanges(true);
    } else if (headerText !== initialValues.headerText) {
      console.log("headerText changed");
      setHasChanges(true);
    } else if (productLayout !== initialValues.productLayout) {
      console.log("productLayout changed");
      setHasChanges(true);
    } else if (storeColor !== initialValues.storeColor) {
      console.log("storeColor Changed");
      setHasChanges(true);
    } else if (fontColor !== initialValues.fontColor) {
      console.log("fontcolor Changed");
      setHasChanges(true);
    } else if (shopCover && shopCover !== initialValues.shopCover) {
      console.log("shop Cover Url Changed", shopCover, initialValues.shopCover);
      setHasChanges(true);
    } else if (
      filters.length !== initialValues.filters?.length ||
      !filters.every(
        (filter: Filter, i: number) => filter === initialValues.filters?.[i],
      )
    ) {
      console.log("filters Changed");
      setHasChanges(true);
    } else if (
      JSON.stringify(filterOptions) !==
      JSON.stringify(initialValues.filterOptions)
    ) {
      console.log("filterOptions Changed");
      setHasChanges(true);
    } else if (sequence.some((e, i) => e !== sequenceAvailable[i])) {
      console.log("sequence Changed");
      setHasChanges(true);
    } else if (
      selectedCollectionOptions?.toString() !==
      initialValues.selectedCollectionOptions?.toString()
    ) {
      console.log("filterOptions Changed");
      setHasChanges(true);
    } else if (shopDetails.email) {
      console.log("email Changed");
      setHasChanges(true);
    } else if (shopDetails.phoneNumber) {
      console.log("phoneNumber Changed");
      setHasChanges(true);
    } else if (shopDetails.address) {
      console.log("address Changed");
      setHasChanges(true);
    } else if (shopDetails.facebook) {
      console.log("facebook Changed");
      setHasChanges(true);
    } else if (shopDetails.twitter) {
      console.log("twitter Changed");
      setHasChanges(true);
    } else if (shopDetails.instagram) {
      console.log("instagram Changed");
      setHasChanges(true);
    } else if (shopDetails.privacyPolicy) {
      console.log("privacyPolicy Changed");
      setHasChanges(true);
    } else if (shopDetails.returnPolicy) {
      console.log("returnPolicy Changed");
      setHasChanges(true);
    } else {
      setHasChanges(false);
    }
  }, [
    banner,
    logo,
    bannerOption,
    displayOption,
    headerText,
    productLayout,
    filters,
    filterOptions,
    sequence,
    shopTileOption,
    storeColor,
    fontColor,
    selectedCollectionOptions,
    shopCover,
    shopDetails,
  ]);

  // Listen for action response
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const redirectAgain = urlParams.get("redirectAgain");

    if (redirectAgain && host && apiKey) {
      console.log("First redirect done, now redirecting again...");

      const app = createApp({
        apiKey,
        host,
      });

      const cleanUrl = `${window.location.origin}${window.location.pathname}`;
      window.history.replaceState(null, "", cleanUrl);

      // 1-2 second delay do taake Shopify iframe smoothly handle kar sake
      setTimeout(() => {
        const redirect = Redirect.create(app);
        redirect.dispatch(Redirect.Action.APP, cleanUrl); // Redirect via App Bridge to maintain session
      }, 1000);
      return;
    }

    if (fetcher.data?.message === "success") {
      console.log("Action completed successfully");
      if (fetcher.data.redirectUrl !== "") {
        if (window.top) {
          window.top.location.href = fetcher.data.redirectUrl;
        }
      } else {
        // navigate({ hash: "/customizer", search });
        // window.parent.location.href = window.parent.location.host + "/apps/customizer";
        // window.location.reload();

        setIsLoading(false);
      }
      return;
    } else if (fetcher.data?.message === "partial success") {
      console.log("🟡 Partial success - Polling for video URL...");

      const pollForVideo = async () => {
        let attempts = 0;
        const maxAttempts = 15;
        let videoUrlFound = false; // ✅ Declare outside the loop

        while (attempts < maxAttempts && fetcher.data?.videoNodeId) {
          const apiUrl = `/api/checkVideoUpload?shopId=${shop?.shop_id}&videoNodeId=${fetcher.data?.videoNodeId}`;

          console.log(`🔄 Attempt ${attempts + 1}: Fetching ${apiUrl}`);

          try {
            const checkUpload = await fetch(apiUrl);

            console.log(`✅ API Response Status: ${checkUpload.status}`);

            // Agar response fail ho raha hai, toh error throw karo
            if (!checkUpload.ok) {
              const errorText = await checkUpload.text();
              throw new Error(
                `API request failed! Status: ${checkUpload.status}, Response: ${errorText}`,
              );
            }

            // API ka JSON response dekho
            const data = await checkUpload.json();

            // Agar response format galat hai toh usko bhi error mano
            if (!data || typeof data !== "object") {
              throw new Error(
                `Invalid response format received: ${JSON.stringify(data)}`,
              );
            }

            if (data?.videoUrl) {
              console.log("✅ Video URL Found:", data.videoUrl);
              setBannerUrl(data.videoUrl);
              setBanner(null);
              if (fetcher.data.redirectUrl !== "") {
                if (window.top) {
                  window.top.location.href = fetcher.data.redirectUrl;
                }
              } else {
                setIsLoading(false);
              }
              videoUrlFound = true; // Mark that URL is found
              return;
            }
          } catch (error) {
            console.error(
              "❌ Error while polling video:",
              error instanceof Error ? error.message : error,
            );
            console.error(
              "📌 Error Stack:",
              error instanceof Error ? error.stack : "No stack available",
            );
          }

          console.log(
            `⏳ Polling attempt ${attempts + 1} completed, retrying in 10s...`,
          );
          await new Promise((resolve) => setTimeout(resolve, 10000)); // 10s wait
          attempts++;
        }

        if (!videoUrlFound) {
          console.log("🚨 Max polling attempts reached. No video URL found.");
          setShowModal(true); // ✅ Show modal only when polling fully fails
        }

        setIsLoading(false);
      };

      pollForVideo();
    } else if (fetcher.data?.message === "failed") {
      console.log("❌ Action failed");
      setIsLoading(false);
    }
  }, [fetcher.data]);

  // check logo resolution
  useEffect(() => {
    if (logo) {
      const img = new Image();
      img.src = URL.createObjectURL(logo);

      img.onload = () => {
        // Check logo dimensions (resolution)
        if (img.width < MIN_LOGO_WIDTH || img.height < MIN_LOGO_HEIGHT) {
          shopify.toast.show(
            `Logo image dimensions are too small. The minimum resolution is ${MIN_LOGO_WIDTH}x${MIN_LOGO_HEIGHT} pixels.`,
          );

          return;
        }

        // If all checks are passed, logo is valid
        console.log("Logo image is valid for Shopify.");
      };

      img.onerror = () => {
        shopify.toast.show("Failed to load the logo image.");
      };
    }
  }, [logo]);

  // check for banner validations
  useEffect(() => {
    if (banner) {
      // Check if the banner is an image
      if (bannerOption === "image") {
        // Validate Image Type
        if (!ALLOWED_IMAGE_TYPES.includes(banner.type)) {
          shopify.toast.show(
            "Invalid image file type. Supported formats are .png, .jpg, .jpeg, .gif., .webp, .heic.",
          );
          return;
        }

        // Validate Image Size (25 MB max)
        const imageSizeMB = banner.size / (1024 * 1024); // Convert bytes to MB
        if (imageSizeMB > MAX_IMAGE_SIZE_MB) {
          shopify.toast.show(
            `Image file size exceeds the 25MB limit. Current size: ${imageSizeMB.toFixed(2)}MB.`,
          );
          return;
        }

        // Validate Image Resolution (25MP max)
        const img = new Image();
        img.src = URL.createObjectURL(banner);
        img.onload = () => {
          const imagePixels = img.width * img.height; // Calculate total pixels (width x height)
          const maxPixels = MAX_IMAGE_SIZE_MB * 1000000; // Convert to 25MP (25,000,000 pixels)
          if (imagePixels > maxPixels) {
            shopify.toast.show(
              `Image resolution exceeds 25MP. Current resolution: ${img.width}x${img.height}`,
            );
            return;
          }
          console.log("Image is valid.");
        };

        img.onerror = () => {
          shopify.toast.show("Failed to load the image.");
        };
      } else {
        // Check if the banner is a video
        if (bannerOption === "video") {
          // Validate Video Type
          if (!ALLOWED_VIDEO_TYPES.includes(banner.type)) {
            shopify.toast.show(
              "Invalid video file type. Supported formats are .mp4, .mov.",
            );
            return;
          }

          // Validate Video Size (Mentioned above MB max)
          const videoSizeMB = banner.size / (1024 * 1024); // Convert bytes to MB

          if (videoSizeMB > MAX_VIDEO_SIZE_MB) {
            shopify.toast.show(
              `Video file size exceeds the ${MAX_VIDEO_SIZE_MB}MB limit. Current size: ${videoSizeMB.toFixed(2)}MB.`,
            );
            return;
          }

          // Validate Video Duration (30 seconds max)
          const video = document.createElement("video");
          video.src = URL.createObjectURL(banner);
          video.onloadedmetadata = () => {
            const videoDuration = video.duration; // Duration in seconds
            if (videoDuration > MAX_VIDEO_DURATION) {
              shopify.toast.show(
                `Video duration exceeds 30 seconds. Current duration: ${videoDuration.toFixed(2)} seconds.`,
              );
              return;
            }
            console.log("Video is valid.");
          };

          video.onerror = () => {
            shopify.toast.show("Failed to load the video.");
          };
        }
      }
    }
  }, [banner]);

  // Attach the event listener to the `.mobile` div
  useEffect(() => {
    const container = mobileRef.current;

    if (container) {
      container.addEventListener("scroll", handleScroll);
    }

    return () => {
      if (container) {
        container.removeEventListener("scroll", handleScroll);
      }
    };
  }, []);

  const updateInitialValues = () => {
    setInitialValues({
      headerText: headerText || "",
      displayOption: displayOption || "text",
      bannerOption: bannerOption || "image",
      shopTileOption: shopTileOption || "1",
      logo: logo as File,
      banner: banner as File,
      productLayout: productLayout,
      filters: filters || [],
      filterOptions: filterOptions || {},
      sequence,
      storeColor,
      shopCover: (shopCover as File) || null,
      fontColor,
      selectedCollectionOptions,
      email: shopDetails.email || shop.shop_email || "",
      phoneNumber: shopDetails.phoneNumber || shop.shop_number || "",
      address: shopDetails.address || shop.shop_address || "",
      instagram: shopDetails.instagram || shop.shop_instagram_url || "",
      facebook: shopDetails.facebook || shop.shop_facebook_url || "",
      twitter: shopDetails.twitter || shop.shop_twitter_url || "",
      privacyPolicy:
        shopDetails.privacyPolicy || shop.shop_privacy_policy_url || "",
      returnPolicy:
        shopDetails.returnPolicy || shop.shop_return_policy_url || "",
    });
    setShopDetails({
      email: "",
      phoneNumber: "",
      address: "",
      facebook: "",
      instagram: "",
      twitter: "",
      returnPolicy: "",
      privacyPolicy: "",
    });
  };

  const handleDrop = (itemName: string, targetIndex: number) => {
    // Reorder the sequence based on the dragged item and the target drop zone
    setSequence((prevSequence) => {
      const newSequence = [...prevSequence];
      const fromIndex = newSequence.indexOf(itemName);
      console.log(itemName);

      if (fromIndex !== -1) {
        newSequence.splice(fromIndex, 1); // Remove the item from its original position
        newSequence.splice(targetIndex, 0, itemName); // Insert at the target index
      }
      return newSequence;
    });
  };

  // const handleAddFilter = () => {
  //   if (newFilterName.trim()) {
  //     setFilters([...filters, newFilterName]);
  //     setFilterOptions({ ...filterOptions, [newFilterName]: [] });
  //     setNewFilterName("");
  //   }
  // };

  // // Add individual option to a specific filter
  // const handleAddOption = (filter: string) => {
  //   if (newOption[filter]?.trim()) {
  //     setFilterOptions({
  //       ...filterOptions,
  //       [filter]: [...filterOptions[filter], newOption[filter]],
  //     });
  //     setNewOption({ ...newOption, [filter]: "" }); // Reset option input after adding
  //   }
  // };

  // const handleDeleteOption = async (filter: string, optionToDelete: string) => {
  //   setFilterOptions((prevOptions: any) => ({
  //     ...prevOptions,
  //     [filter]: prevOptions[filter].filter(
  //       (option: any) => option !== optionToDelete,
  //     ),
  //   }));

  //   console.log("filterOption remove", filter, optionToDelete);

  //   const formData = new FormData();

  //   formData.append("filter", filter);
  //   formData.append("filterOption", optionToDelete);
  //   formData.append("shopDomain", shop.shop_domain);

  //   await fetch(`/api/removeFilterOption`, {
  //     method: "POST",
  //     body: formData,
  //   });
  // };

  // const handleRemoveFilter = async (filterToRemove: string) => {
  //   setFilters(filters.filter((filter: string) => filter !== filterToRemove)); // Remove filter from filters array
  //   const updatedFilterOptions = { ...filterOptions };
  //   delete updatedFilterOptions[filterToRemove]; // Remove options associated with the filter
  //   setFilterOptions(updatedFilterOptions); // Update the filter options state

  //   console.log("filterToRemove", filterToRemove);

  //   const formData = new FormData();
  //   formData.append("removeFilter", filterToRemove);
  //   formData.append("shopDomain", shop.shop_domain);

  //   await fetch(`/api/removeFilter`, {
  //     method: "POST",
  //     body: formData,
  //   });
  // };

  const handleSave = () => {
    const selectedTile = choiceArray.find(
      (e: any) => e.value == shopTileOption,
    );
    console.log("Secleted tile test", selectedTile, bannerOption);
    if (!selectedTile) return;

    const tileType = selectedTile.tileType;
    console.log(
      "choiceArray.length",
      choiceArray.length,
      "shop?.shop_tile_subscribed",
      shop?.shop_tile_subscribed,
      "tileType",
      tileType,
    );
    if (choiceArray.length && !shop?.shop_tile_subscribed) {
      if (tileType === "video") {
        setModalActive(true);
        return;
      }
      // Update When rate of video tile changes Now is same so no issue
    } else if (choiceArray.length && shop?.shop_tile_subscribed) {
      if (tileType === "basic" || tileType === "modern") {
        setSecondModal(true);
        return;
      }
    }

    setIsLoading(true);
    const formData = new FormData();
    if (banner) formData.append("banner", banner);
    if (logo) formData.append("logo", logo);

    console.log("send", headerText, displayOption);
    formData.append("headerText", headerText);
    formData.append("bannerType", bannerOption);
    formData.append("tileTypeId", shopTileOption);
    formData.append("displayOption", displayOption);
    // Add filters and filterOptions as JSON strings
    formData.append("filters", JSON.stringify(filters));
    formData.append("filterOptions", JSON.stringify(filterOptions));
    formData.append("sequence", sequence.join(","));
    formData.append("window", window as any);
    if (shopCover) {
      formData.append("shopCover", shopCover);
    }
    formData.append("tileType", tileType);
    formData.append("newTileId", shopTileOption);
    formData.append(
      "selectedShopCollections",
      selectedCollectionOptions.join(","),
    );
    formData.append(
      "tileCharges",
      choiceArray.find((e: any) => e.value == shopTileOption).tileCharges,
    );
    if (initialValues.storeColor !== storeColor)
      formData.append("storeColor", storeColor);

    if (initialValues.fontColor !== fontColor)
      formData.append("fontColor", fontColor);
    if (initialValues.email !== shopDetails.email)
      formData.append("email", shopDetails.email);
    if (initialValues.phoneNumber !== shopDetails.phoneNumber)
      formData.append("phoneNumber", shopDetails.phoneNumber);
    if (initialValues.address !== shopDetails.address)
      formData.append("address", shopDetails.address);
    if (initialValues.privacyPolicy !== shopDetails.privacyPolicy)
      formData.append("privacyPolicy", shopDetails.privacyPolicy);
    if (initialValues.returnPolicy !== shopDetails.returnPolicy)
      formData.append("returnPolicy", shopDetails.returnPolicy);
    if (initialValues.instagram !== shopDetails.instagram)
      formData.append("instagram", shopDetails.instagram);
    if (initialValues.facebook !== shopDetails.facebook)
      formData.append("facebook", shopDetails.facebook);
    if (initialValues.instagram !== shopDetails.twitter)
      formData.append("twitter", shopDetails.twitter);
    for (let pair of formData.entries()) {
      console.log(`formData value ${pair[0]}: ${pair[1]}`);
    }

    // submit(formData, { method: "post", encType: "multipart/form-data" });

    fetcher.submit(formData, {
      method: "post",
      encType: "multipart/form-data",
    });

    updateInitialValues();
    setHasChanges(false);
    setModalActive(false);
  };

  const generateVideoThumbnail = (videoFile: File) => {
    const videoElement = document.createElement("video");
    const fileURL = URL.createObjectURL(videoFile);

    videoElement.src = fileURL;
    videoElement.preload = "metadata";
    videoElement.muted = true;
    videoElement.playsInline = true;

    videoElement.onloadedmetadata = () => {
      videoElement.currentTime = 0.1;
    };

    videoElement.onseeked = () => {
      const canvas = document.createElement("canvas");
      const context = canvas.getContext("2d");

      canvas.width = videoElement.videoWidth;
      canvas.height = videoElement.videoHeight;

      context?.drawImage(videoElement, 0, 0, canvas.width, canvas.height);

      const thumbnailDataUrl = canvas.toDataURL("image/jpeg");
      setVideoThumbnail(thumbnailDataUrl);
    };
  };

  const handleCancel = () => {
    navigate({ hash: "/app", search });
  };

  const handleModalClose = () => {
    setModalActive(false);
    setSecondModal(false);
  };

  const handleModalYesClicked = () => {
    setIsLoading(true);
    const selectedTile = choiceArray.find(
      (e: any) => e.value == shopTileOption,
    );
    console.log("Secleted tile test", selectedTile, bannerOption);
    if (!selectedTile) return;

    const tileType = selectedTile.tileType;
    const formData = new FormData();
    if (banner) formData.append("banner", banner);
    if (logo) formData.append("logo", logo);

    console.log("send", headerText, displayOption);
    formData.append("headerText", headerText);
    formData.append("bannerType", bannerOption);
    formData.append("displayOption", displayOption);
    formData.append("tileTypeId", shopTileType);
    // Add filters and filterOptions as JSON strings
    formData.append("filters", JSON.stringify(filters));
    formData.append("filterOptions", JSON.stringify(filterOptions));
    formData.append("sequence", sequence.join(","));
    formData.append("window", window as any);
    formData.append("tileType", tileType);
    formData.append("newTileId", shopTileOption);
    if (shopCover) {
      formData.append("shopCover", shopCover);
    }
    if (initialValues.email !== shopDetails.email)
      formData.append("email", shopDetails.email);
    if (initialValues.phoneNumber !== shopDetails.phoneNumber)
      formData.append("phoneNumber", shopDetails.phoneNumber);
    if (initialValues.address !== shopDetails.address)
      formData.append("address", shopDetails.address);
    if (initialValues.privacyPolicy !== shopDetails.privacyPolicy)
      formData.append("privacyPolicy", shopDetails.privacyPolicy);
    if (initialValues.returnPolicy !== shopDetails.returnPolicy)
      formData.append("returnPolicy", shopDetails.returnPolicy);
    if (initialValues.instagram !== shopDetails.instagram)
      formData.append("instagram", shopDetails.instagram);
    if (initialValues.facebook !== shopDetails.facebook)
      formData.append("facebook", shopDetails.facebook);
    if (initialValues.instagram !== shopDetails.twitter)
      formData.append("twitter", shopDetails.twitter);
    formData.append(
      "selectedShopCollections",
      selectedCollectionOptions.join(","),
    );
    formData.append(
      "tileCharges",
      choiceArray.find((e: any) => e.value == shopTileOption).tileCharges,
    );

    for (let pair of formData.entries()) {
      console.log(`formData value ${pair[0]}: ${pair[1]}`);
    }

    // submit(formData, { method: "post", encType: "multipart/form-data" });

    fetcher.submit(formData, {
      method: "post",
      encType: "multipart/form-data",
    });
    updateInitialValues();
    setHasChanges(false);
  };

  const handleColorChange = (color: any) => {
    // Convert Hsb to RGB
    const rgb = hsbToRgb(color);
    const hex = rgbToHex(rgb);

    // Set the color state with the hex value
    setStoreColor(hex);
    setColor(color);
  };

  const handleFontChange = (color: any) => {
    // Convert Hsb to RGB
    const rgb = hsbToRgb(color);
    const hex = rgbToHex(rgb);

    // Set the color state with the hex value
    setFontColor(hex);
    setcolorfont(color);
  };

  // Explicitly set the type of the ref
  const mobileRef = useRef<HTMLDivElement | null>(null);

  const handleScroll = () => {
    // console.log("object", mobileRef.current?.scrollTop);
    if (mobileRef.current && mobileRef.current.scrollTop > 100) {
      setIsScrolled(true);
    } else {
      setIsScrolled(false);
    }
  };

  const animatedStyle = useMemo(() => {
    return {
      height: "600px",
      backgroundColor: isScrolled ? "#FFFFFF" : storeColor,
      transition:
        "background-color 0.8s ease, opacity 0.6s ease, transform 0.6s ease",
      opacity: isScrolled ? 0.95 : 1,
      transform: isScrolled ? "scale(0.98)" : "scale(1)",
    };
  }, [isScrolled, storeColor]);

  if (isFirstLoad) {
    return <LoadingSkeleton />;
  }

  return (
    <Page
      fullWidth
      title="Store Screen Customization"
      actionGroups={[
        {
          title: "want to see your store?",
          actions: [
            {
              content: "Guide to your Products",
              onAction() {
                window.open(
                  "https://cymbiote.com/cercle-merchant-preview/",
                  "_blank",
                );
              },
            },
          ],
        },
      ]}
    >
      <Layout>
        {/* Configuration Area */}
        <Layout.Section variant="oneHalf">
          {/* Section for selecting logo */}
          <Layout.Section>
            <Card>
              <Text as="p" fontWeight="bold">
                Header Display Icon
              </Text>
              <ChoiceList
                title="Display Option"
                choices={[
                  // { label: "Text", value: "text" },
                  { label: "Logo", value: "logo" },
                ]}
                selected={[displayOption]}
                onChange={(selected) => setDisplayOption(selected[0])}
              />
              {displayOption === "text" ? (
                <TextField
                  label="Header Text"
                  autoComplete="off"
                  value={headerText}
                  onChange={(value) => setHeaderText(value)}
                  placeholder="Enter header text"
                />
              ) : (
                <Card>
                  <Text as="p" fontWeight="bold">
                    Select Logo
                  </Text>
                  <DropZone
                    onDrop={(files) => setLogo(files[0])}
                    allowMultiple={false}
                    accept="image/png,image/jpeg,image/jpg,image/gif,image/webp,image/heic"
                  >
                    {logo ? (
                      <BlockStack>
                        {/* <Thumbnail
                          size="large"
                          source={URL.createObjectURL(logo)}
                          alt="Logo"
                        /> */}
                        <img
                          src={URL.createObjectURL(logo)}
                          alt="Logo"
                          width={120}
                          height={120}
                          style={{ margin: "0.3rem", borderRadius: "10px" }}
                        />
                        <div
                          style={{
                            position: "absolute",
                            top: "50%",
                            left: "50%",
                            transform: "translate(-50%, -50%)",
                          }}
                        >
                          <Button icon={EditIcon}>Change</Button>
                        </div>
                      </BlockStack>
                    ) : (
                      <DropZone.FileUpload />
                    )}
                  </DropZone>
                </Card>
              )}
            </Card>
          </Layout.Section>

          {/* Shop Tile Type */}
          <Layout.Section>
            <Card>
              <Text as="p" fontWeight="bold">
                Shop Tile
              </Text>
              <ChoiceList
                title="Available Tile Types"
                choices={choiceArray}
                selected={[shopTileOption]}
                onChange={(selected) => setShopTileOption(selected[0])}
              />
            </Card>
          </Layout.Section>

          {/* Select collectsion to show on storee */}
          <Layout.Section>
            <Card>
              <Text as="p" fontWeight="bold">
                Collections to Show
              </Text>

              <CollectionDropdown
                search={search}
                collections={simplecollection.map((e: any) => {
                  return {
                    value: e.collection_name.toLowerCase(),
                    label: e.collection_name,
                  };
                })}
                selectedOptions={selectedCollectionOptions}
                setSelectedOptions={setSelectedCollectionOptions}
              />
            </Card>
          </Layout.Section>

          {/* Section for selecting banner */}
          {(shopTileOption === "7" ||
            shopTileOption === "9" ||
            shopTileOption === "6" ||
            shopTileOption === "4") && (
            <Layout.Section variant="fullWidth">
              {/* <Card>
                <ChoiceList
                  title="Select the type of banner you want to show"
                  choices={[
                    { label: "Image", value: "image" },
                    {
                      label: "Video",
                      value: "video",
                      disabled:
                        shopTileOption === "6" ||
                        shopTileOption === "4" ||
                        !!banner,
                    },
                  ]}
                  selected={[bannerOption]}
                  onChange={(selected) => setBannerOption(selected[0])}
                  disabled={!!banner}
                />
                <Text as="p" fontWeight="bold">
                  {bannerOption === "image"
                    ? "Select Tile Image"
                    : "Select Tile Video"}
                </Text>
                <DropZone
                  onDrop={(files) => {
                    const file = files[0];

                    // Define file size limit (e.g., 30MB)
                    const maxSize = 30 * 1024 * 1024; // 30MB in bytes

                    if (file.size > maxSize) {
                      console.error("❌ File size exceeds the 30MB limit.");
                      setShowFilesizeModal(true);
                      return;
                    }

                    console.log(
                      "✅ File accepted:",
                      file.name,
                      "Size:",
                      file.size,
                    );
                    setBanner(file);
                  }}
                  allowMultiple={false}
                  accept={
                    bannerOption === "image"
                      ? "image/jpeg,image/png,image/gif,image/heic,image/webp"
                      : "video/mp4,video/quicktime"
                  }
                >
                  {banner ? (
                    <InlineStack>
                      <Thumbnail
                        size="large"
                        source={
                          bannerOption === "image"
                            ? URL.createObjectURL(banner)
                            : "https://icons.veryicon.com/png/o/miscellaneous/text-editing-icon/video-91.png"
                        }
                        alt="Banner"
                      />
                    </InlineStack>
                  ) : (
                    <DropZone.FileUpload />
                  )}
                </DropZone>
              </Card> */}
              <Card>
                <ChoiceList
                  title="Select the tile banner you want to show"
                  choices={[
                    {
                      label: "Image",
                      value: "image",
                      disabled:
                        shopTileOption === "7" ||
                        shopTileOption === "9" ||
                        !!banner,
                    },
                    {
                      label: "Video",
                      value: "video",
                      disabled:
                        shopTileOption === "6" ||
                        shopTileOption === "4" ||
                        !!banner,
                    },
                  ]}
                  selected={[bannerOption]}
                  onChange={(selected) => setBannerOption(selected[0])}
                  disabled={!!banner}
                />
                <Text as="p" fontWeight="bold">
                  {bannerOption === "image"
                    ? "Select Tile Image"
                    : "Select Tile Video"}
                </Text>
                <DropZone
                  onDrop={(files) => {
                    const file = files[0];

                    const maxSize = MAX_VIDEO_SIZE_MB * 1024 * 1024; // 50MB

                    if (file.size > maxSize) {
                      console.error("❌ File size exceeds the 50MB limit.");
                      setShowFilesizeModal(true);
                      return;
                    }

                    console.log(
                      "✅ File accepted:",
                      file.name,
                      "Size:",
                      file.size,
                    );

                    if (file.type.startsWith("video/")) {
                      generateVideoThumbnail(file);
                    }

                    setBanner(file);
                  }}
                  allowMultiple={false}
                  accept={
                    bannerOption === "image"
                      ? "image/jpg,image/jpeg,image/png,image/gif,image/heic,image/webp"
                      : "video/mp4,video/quicktime"
                  }
                >
                  {banner ? (
                    <InlineStack>
                      <div style={{ position: "relative" }}>
                        <img
                          src={
                            bannerOption === "image"
                              ? URL.createObjectURL(banner)
                              : videoThumbnail ||
                                "https://icons.veryicon.com/png/o/miscellaneous/text-editing-icon/video-91.png"
                          }
                          alt="Banner"
                          style={{ margin: "0.3rem", borderRadius: "10px" }}
                          width={120}
                          height={120}
                        />
                        {bannerOption === "video" && (
                          <div
                            style={{
                              position: "absolute",
                              top: "50%",
                              left: "50%",
                              transform: "translate(-50%, -50%)",
                              backgroundColor: "rgba(44, 41, 230, 0.4)",
                              padding: "10px",
                              borderRadius: "50%",
                            }}
                          >
                            <Icon source={PlayIcon} tone="emphasis" />
                          </div>
                        )}
                      </div>

                      <div
                        style={{
                          position: "absolute",
                          top: "50%",
                          left: "50%",
                          transform: "translate(-50%, -50%)",
                        }}
                      >
                        <Button icon={EditIcon}>Change</Button>
                      </div>
                    </InlineStack>
                  ) : (
                    <DropZone.FileUpload />
                  )}
                </DropZone>
              </Card>
            </Layout.Section>
          )}

          <Layout.Section>
            <Card>
              <Text as="p" fontWeight="bold">
                Upload Merchant Screen Banner
              </Text>
              <DropZone
                onDrop={(files) => {
                  const file = files[0];
                  const maxSize = MAX_IMAGE_SIZE_MB * 1024 * 1024; // 30MB

                  if (file.size > maxSize) {
                    console.error("❌ File size exceeds the 30MB limit.");
                    setShowFilesizeModal(true);
                    return;
                  }

                  console.log(
                    "✅ File accepted:",
                    file.name,
                    "Size:",
                    file.size,
                  );
                  setshopCover(file);
                }}
                allowMultiple={false}
                accept="image/jpeg,image/png,image/gif,image/heic,image/webp"
              >
                {shopCover ? (
                  <InlineStack>
                    <img
                      src={URL.createObjectURL(shopCover)}
                      alt="Logo"
                      width={120}
                      height={120}
                      style={{ margin: "0.3rem", borderRadius: "10px" }}
                    />
                    <div
                      style={{
                        position: "absolute",
                        top: "50%",
                        left: "50%",
                        transform: "translate(-50%, -50%)",
                      }}
                    >
                      <Button icon={EditIcon}>Change</Button>
                    </div>
                  </InlineStack>
                ) : (
                  <DropZone.FileUpload />
                )}
              </DropZone>
            </Card>
          </Layout.Section>

          {/* This section contains background color picker */}
          {/* <Layout.Section>
            <Card>
              <div style={{ display: "flex", justifyContent: "space-around" }}>
                <div>
                  <Text as="p" fontWeight="bold">
                    Select color for your store theme
                  </Text>
                  <div style={{ marginTop: 10 }}>
                    <ColorPicker onChange={handleColorChange} color={color} />
                  </div>
                </div>
                <div>
                  <Text as="p" fontWeight="bold">
                    Select color for your store Font
                  </Text>
                  <div style={{ marginTop: 10 }}>
                    <ColorPicker
                      onChange={handleFontChange}
                      color={colorfont}
                    />
                  </div>
                </div>
              </div>
            </Card>
          </Layout.Section> */}

          {/* <Layout.Section variant="fullWidth">
            <Card>
              <Text as="p" fontWeight="bold">
                Add Filters and Options
              </Text>
              <TextField
                autoComplete="off"
                label="New Filter Name"
                value={newFilterName}
                onChange={(value) => setNewFilterName(value)}
                placeholder="Enter filter name (e.g., Color)"
              />
              <div style={{ marginTop: 5, marginBottom: 5 }}>
                <Button onClick={handleAddFilter}>Add Filter</Button>
              </div>

              {filters.map((filter: string, index: number) => (
                <div key={index} style={{ marginTop: "10px" }}>
                  <Text as="h4" fontWeight="bold">
                    {filter}
                    <span style={{ marginLeft: "10px" }}>
                      <Button
                        onClick={() => handleRemoveFilter(filter)}
                        size="micro"
                      >
                        Remove
                      </Button>
                    </span>
                  </Text>

                  <div style={{ paddingTop: 5, paddingBottom: 5 }}>
                    <InlineStack gap={"400"}>
                      {filterOptions[filter]?.map(
                        (option: string, idx: number) => (
                          <Tag
                            key={idx}
                            onRemove={() => handleDeleteOption(filter, option)} // Call delete function
                          >
                            {option}
                          </Tag>
                        ),
                      )}
                    </InlineStack>
                  </div>

                  <TextField
                    autoComplete="off"
                    label={`Add Option for ${filter}`}
                    value={newOption[filter] || ""}
                    onChange={(value) =>
                      setNewOption((prev) => ({ ...prev, [filter]: value }))
                    }
                    placeholder="Enter option (e.g., Red)"
                  />
                  <div style={{ marginTop: 5, marginBottom: 5 }}>
                    <Button onClick={() => handleAddOption(filter)}>
                      Add Option
                    </Button>
                  </div>
                </div>
              ))}
            </Card>
          </Layout.Section> */}

          {/* Section for selecting product layout */}
          {/* <Layout.Section variant="fullWidth">
            <Card>
              <Text as="p" fontWeight="bold">
                Product Layout Selection
              </Text>
              <ChoiceList
                title="Select Layout"
                choices={[
                  { label: "Vertical", value: "vertical" },
                  { label: "Horizontal", value: "horizontal" },
                ]}
                selected={[productLayout]}
                onChange={(selected) => setProductLayout(selected[0])}
              />
            </Card>
          </Layout.Section> */}

          {/* Store Details Section */}
          <Layout.Section variant="fullWidth">
            <StoreDetails
              email={initialValues.email || ""}
              address={initialValues.address || ""}
              facebook={initialValues.facebook || ""}
              instagram={initialValues.instagram || ""}
              phoneNumber={initialValues.phoneNumber || ""}
              twitter={initialValues.twitter || ""}
              privacyPolicy={initialValues.privacyPolicy || ""}
              returnPolicy={initialValues.returnPolicy || ""}
              setShopDetails={setShopDetails}
              shopDetails={shopDetails}
            />
          </Layout.Section>

          {/* Buttons section to save and discard changes */}
          <Layout.Section>
            <ButtonGroup>
              <Button onClick={handleCancel}>Cancel</Button>
              <Button
                variant="primary"
                onClick={handleSave}
                disabled={!hasChanges}
                loading={isLoading}
              >
                Save
              </Button>
            </ButtonGroup>
            <div style={{ margin: 7 }} />
          </Layout.Section>
        </Layout.Section>

        {/* Mobile View Sectionz */}
        <Layout.Section variant="oneHalf">
          <Layout.Section>
            <Card>
              <Text as="p" fontWeight="semibold">
                Mobile View
              </Text>
              <div className={"mobileViewParent"}>
                {/* Tile Container */}
                <div className={"mobileContainer"}>
                  <div className={"mobile"}>
                    <div className={"notificationBar"}>
                      <span className={"time"}>{getCurrentTime()}</span>
                      <Box
                        borderRadius="200"
                        width="80px"
                        minHeight="15px"
                        background="bg-fill-brand"
                      />
                      <span className={"statusIcons"}>
                        <span className={"signalIcon"}>
                          <Imager
                            source="https://cdn.shopify.com/s/files/1/0595/2379/2944/files/Mobile_Signal.png?v=1762330902"
                            alt="signal_image"
                            height={10}
                            width={15}
                          />
                        </span>
                        <span className={"wifiIcon"}>
                          <Imager
                            source="https://cdn.shopify.com/s/files/1/0595/2379/2944/files/Wifi.png?v=1762330901"
                            alt="signal_image"
                            height={10}
                            width={15}
                          />
                        </span>
                        <span className={"batteryIcon"}>
                          <Imager
                            source="https://cdn.shopify.com/s/files/1/0595/2379/2944/files/Battery.png?v=1762330901"
                            alt="signal_image"
                            height={10}
                            width={15}
                          />
                        </span>
                      </span>
                    </div>
                    <div className={"shopTitle"}>
                      <ShopTiles shopTileId={shopTileOption} />
                    </div>
                  </div>
                </div>

                {/* Merchant Screen Container */}
                <div className={"mobileContainer"}>
                  <div
                    className={"mobile"}
                    ref={mobileRef}
                    // style={{ backgroundColor: storeColor }}
                    style={animatedStyle}
                    onScroll={handleScroll}
                  >
                    <div className={"notificationBar"}>
                      <span className={"time"}>{getCurrentTime()}</span>
                      <Box
                        borderRadius="200"
                        width="80px"
                        minHeight="15px"
                        background="bg-fill-brand"
                      />
                      <span className={"statusIcons"}>
                        <span className={"signalIcon"}>
                          <Imager
                            source="https://cdn.shopify.com/s/files/1/0595/2379/2944/files/Mobile_Signal.png?v=1762330902"
                            alt="signal_image"
                            height={10}
                            width={15}
                          />
                        </span>
                        <span className={"wifiIcon"}>
                          <Imager
                            source="https://cdn.shopify.com/s/files/1/0595/2379/2944/files/Wifi.png?v=1762330901"
                            alt="signal_image"
                            height={10}
                            width={15}
                          />
                        </span>
                        <span className={"batteryIcon"}>
                          <Imager
                            source="https://cdn.shopify.com/s/files/1/0595/2379/2944/files/Battery.png?v=1762330901"
                            alt="signal_image"
                            height={10}
                            width={15}
                          />
                        </span>
                      </span>
                    </div>

                    <div style={{ position: "relative" }}>
                      <Banner
                        banner={shopCover as File}
                        bannerUrl={bannerUrl}
                        bannerType={bannerOption}
                      />

                      <div
                        style={{
                          position: "absolute",
                          paddingLeft: "10px",
                          paddingRight: "10px",
                          width: "100%",
                          bottom: -140,
                        }}
                      >
                        {/* <div style={{ paddingBottom: 90 }}>
                          <BrandTitle
                            displayOption={displayOption}
                            headerText={headerText}
                            logo={logo as File}
                            logoImage={shop?.shop_logo_url}
                          />
                        </div> */}
                        <div>
                          <Title
                            displayOption={displayOption}
                            headerText={headerText}
                            logo={logo as File}
                            logoImage={shop?.shop_logo_url}
                            shoprating={shop?.shop_rating}
                            ReviewSum={ReviewSum}
                          />
                        </div>
                        <div
                          className="btn-icon"
                          style={{
                            display: "flex",
                            justifyContent: "space-between",
                            alignItems: "center",
                            marginTop: 20,
                          }}
                        >
                          <div
                            style={{
                              display: "flex",
                              gap: "10px",
                              alignItems: "center",
                              width: "68%",
                              // backgroundColor: "black",
                            }}
                          >
                            {/* Follow Button */}
                            <Button
                              size="large"
                              variant="primary"
                              pressed
                              fullWidth
                            >
                              Follow
                            </Button>

                            {/* Notification Button */}
                            <Button
                              size="medium"
                              variant="primary"
                              pressed
                              disabled
                              icon={NotificationIcon}
                            />

                            {/* Search Button */}
                            <Button
                              size="medium"
                              variant="primary"
                              pressed
                              disabled
                              icon={SearchIcon}
                            />
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Drop Zone */}
                    <div
                      style={{
                        position: "relative",
                        marginTop: 45,
                        paddingTop: 45,
                        top: 50,
                      }}
                    >
                      {typeof window !== "undefined" && (
                        <DndProvider backend={HTML5Backend}>
                          <DropZoneDnD
                            filters={filters}
                            products={products}
                            sequence={sequence}
                            onDrop={handleDrop}
                            fontColor={fontColor}
                            filtercollections={filtercollections}
                            videos={videos}
                            simplecollection={simplecollection.filter(
                              (e: any) =>
                                selectedCollectionOptions.includes(
                                  e.collection_name.toLowerCase(),
                                ),
                            )}
                            storeColor={storeColor}
                            isScrolled={isScrolled}
                            shopCurrency={shopCurrency}
                          />
                        </DndProvider>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          </Layout.Section>
        </Layout.Section>
      </Layout>

      <ConfirmationModal
        open={modalActive}
        onClose={handleModalClose}
        title="Confirm Tile Charges"
        message={`You are about to add an additional monthly charge to your subscription plan for 
          <strong>${
            choiceArray.find((item: any) => item.value === shopTileOption)
              ?.label || "Not Found"
          }</strong>.
          Please note that your subscription charges will change starting from the next billing cycle.
          Would you like to proceed?`}
        confirmLabel="Yes"
        cancelLabel="No"
        onConfirm={handleModalYesClicked}
        isLoading={isLoading}
      />

      <ConfirmationModal
        open={secondModal}
        onClose={handleModalClose}
        title="Confirm Remove Tile Charges"
        message={`You are about to remove your tile subscription for 
        <strong>${
          choiceArray.find((item: any) => item.value === shopTileOption)
            ?.label || "Not Found"
        }</strong>.
        Please note that your subscription charges will change starting from the next billing cycle.
        Would you like to proceed?`}
        confirmLabel="Yes"
        cancelLabel="No"
        onConfirm={handleModalYesClicked}
        isLoading={isLoading}
      />
      <>
        {showModal && (
          <VideoModal
            open={true}
            title="Error"
            message="Error While Uploading the video, Try Different Video with Correct Format"
            onClose={() => setShowModal(false)}
          />
        )}
      </>
      <>
        {showfilesizeModal && (
          <VideoModal
            open={true}
            title="File Upload Error"
            message={`File size must be less than ${MAX_VIDEO_SIZE_MB} MB.`}
            onClose={() => setShowFilesizeModal(false)}
          />
        )}
      </>
    </Page>
  );
}

// ( <Layout.Section variant="oneHalf">
//           <Layout.Section>
//             <Card>
//               <Text as="p" fontWeight="semibold">
//                 Mobile View
//               </Text>
//               <div className={"mobileViewParent"}>
//                 {/* Tile Container */}
//                 <div className={"mobileContainer"}>
//                   <div className={"mobile"}>
//                     <div className={"notificationBar"}>
//                       <span className={"time"}>{getCurrentTime()}</span>
//                       <span className={"statusIcons"}>
//                         <span className={"signalIcon"}>📶</span>
//                         <span className={"wifiIcon"}>📡</span>
//                         <span className={"batteryIcon"}>🔋</span>
//                       </span>
//                     </div>
//                     <div className={"shopTitle"}>
//                       <ShopTiles shopTileId={shopTileOption} />
//                     </div>
//                   </div>
//                 </div>

//                 {/* Merchant Screen Container */}
//                 <div className={"mobileContainer"}>
//                   <div
//                     className={"mobile"}
//                     ref={mobileRef}
//                     // style={{ backgroundColor: storeColor }}
//                     style={animatedStyle}
//                     onScroll={handleScroll}
//                   >
//                     <div className={"notificationBar"}>
//                       <span className={"time"}>{getCurrentTime()}</span>
//                       <span className={"statusIcons"}>
//                         <span className={"signalIcon"}>📶</span>
//                         <span className={"wifiIcon"}>📡</span>
//                         <span className={"batteryIcon"}>🔋</span>
//                       </span>
//                     </div>

//                     <div style={{ position: "relative" }}>
//                       <Banner
//                         banner={banner as File}
//                         bannerUrl={bannerUrl}
//                         bannerType={bannerOption}
//                       />

//                       <div
//                         style={{
//                           position: "absolute",
//                           left: 0,
//                           bottom: 0,
//                           width: "100%",
//                           height: "30px",
//                           background: `linear-gradient(to bottom, rgba(0, 0, 0, 0) 0%, ${storeColor} 100%)`,
//                         }}
//                       />

//                       <div
//                         style={{
//                           position: "absolute",
//                           paddingLeft: "10px",
//                           paddingRight: "10px",
//                           width: "100%",
//                           bottom: 20,
//                         }}
//                       >
//                         <div style={{ paddingBottom: 90 }}>
//                           <BrandTitle
//                             displayOption={displayOption}
//                             headerText={headerText}
//                             logo={logo as File}
//                             logoImage={shop?.shop_logo_url}
//                           />
//                         </div>
//                         <div>
//                           <Title
//                             displayOption={displayOption}
//                             headerText={headerText}
//                             logo={logo as File}
//                             logoImage={shop?.shop_logo_url}
//                             shoprating={shop?.shop_rating}
//                             ReviewSum={ReviewSum}
//                           />
//                         </div>
//                       </div>
//                     </div>

//                     {/* Drop Zone */}
//                     <div>
//                       {typeof window !== "undefined" && (
//                         <DndProvider backend={HTML5Backend}>
//                           <DropZoneDnD
//                             filters={filters}
//                             products={products}
//                             sequence={sequence}
//                             onDrop={handleDrop}
//                             fontColor={fontColor}
//                             filtercollections={filtercollections}
//                             videos={videos}
//                             simplecollection={simplecollection.filter(
//                               (e: any) =>
//                                 selectedCollectionOptions.includes(
//                                   e.collection_name.toLowerCase(),
//                                 ),
//                             )}
//                             storeColor={storeColor}
//                             isScrolled={isScrolled}
//                             shopCurrency={shopCurrency}
//                           />
//                         </DndProvider>
//                       )}
//                     </div>
//                   </div>
//                 </div>
//               </div>
//             </Card>
//           </Layout.Section>
//         </Layout.Section>)
