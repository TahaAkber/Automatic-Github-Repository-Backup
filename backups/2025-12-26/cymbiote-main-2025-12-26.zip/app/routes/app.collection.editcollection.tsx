import { useCallback, useEffect, useRef, useState, ChangeEvent } from "react";
import {
  Card,
  Button,
  Select,
  Text,
  Icon,
  Badge,
  Combobox,
  TextField,
  Thumbnail,
  Page,
  Layout,
  InlineStack,
} from "@shopify/polaris";
import { SearchIcon, XIcon } from "@shopify/polaris-icons";
import SearchModal, { Product } from "~/components/collection/SearchModal";
import {
  ActionFunctionArgs,
  LoaderFunctionArgs,
  TypedResponse,
  json,
} from "@remix-run/node";
import {
  EditCollectionAction,
  EditCollectionLoader,
} from "~/types/CollectionLoader";
import { useFetcher, useLoaderData, useNavigate } from "@remix-run/react";
import { addProducts, removeProducts } from "~/mutations/collectionProducts";
import { authenticate } from "~/shopify.server";
import { Loader } from "~/components/common/Loader";
import { uploadToShopify } from "~/functions/common";

export const loader = async ({
  request,
  params,
}: LoaderFunctionArgs): Promise<TypedResponse<EditCollectionLoader>> => {
  const url = new URL(request.url);
  const shopDomain = url.searchParams.get("shop");
  const id = url.searchParams.get("id");
  const type = url.searchParams.get("type");

  if (!shopDomain) {
    throw new Response("Missing shop domain", { status: 400 });
  }

  const shop = await prisma.shops.findFirst({
    where: {
      shop_domain: shopDomain,
    },
  });
  const collectionWithProducts = await prisma.collections.findMany({
    where: {
      collection_shopify_id: `gid://shopify/Collection/${id}`,
    },
    include: {
      Collection_Products: {
        include: {
          Products: true,
        },
      },
    },
  });

  const products = await prisma.products.findMany({
    where: {
      product_shop_id: shop?.shop_id,
      product_is_active: true,
    },
  });

  return json({
    success: 200,
    search: url.search,
    collectionWithProducts,
    products,
    type,
  });
};

export const action = async ({
  request,
  params,
}: ActionFunctionArgs): Promise<TypedResponse<EditCollectionAction>> => {
  const formData = await request.formData();
  const { admin } = await authenticate.admin(request);

  const url = new URL(request.url);
  const shopDomain = url.searchParams.get("shop");
  const id = url.searchParams.get("id");

  const products = formData.get("products");
  const description = formData.get("description") as string;
  const title = formData.get("title") as string;

  const File = formData.get("file") as File;
  let imageSrc = "";
  if (products && title) {
    const shop = await prisma.shops.findFirst({
      where: {
        shop_domain: shopDomain,
      },
    });
    const collectionWithProducts = await prisma.collections.findFirst({
      where: {
        collection_shopify_id: `gid://shopify/Collection/${id}`,
      },
      include: {
        Collection_Products: {
          include: {
            Products: true,
          },
        },
      },
    });

    const imageUpload = await uploadToShopify(File, admin, File.name);
    console.log("Image Upload Response:", imageUpload);

    if (imageUpload) {
      const nodeId: string = imageUpload;

      const wait = (ms: number) => new Promise((res) => setTimeout(res, ms));

      const getUploadedImageUrl = async (retries = 5, delay = 2000) => {
        for (let i = 0; i < retries; i++) {
          console.log(
            `Fetching Uploaded Image URL... Attempt ${i + 1}/${retries}`,
          );

          const fileNodeQuery = `
                {
                  nodes(ids: ["${nodeId}"]) {
                    id
                    ... on MediaImage {
                      image {
                        url
                        id
                      }
                    }
                  }
                }`;

          try {
            const fileNodeResponse = await admin.graphql(fileNodeQuery);
            const parsedNodeData = await fileNodeResponse.json();
            const fetchedImageSrc =
              parsedNodeData?.data?.nodes?.[0]?.image?.url;

            if (fetchedImageSrc) {
              return fetchedImageSrc;
            }

            console.log(
              `Image URL not available yet, retrying in ${delay / 1000} seconds...`,
            );
            await wait(delay);
          } catch (error) {
            console.error("Error fetching image URL:", error);
          }
        }
        throw new Error("Image URL not available after multiple retries.");
      };

      imageSrc = await getUploadedImageUrl(); // Assign value to the outer variable
      console.log("Uploaded Image URL:", imageSrc);
    }

    // Use the unique collection_id for update
    const updatedCollection = await prisma.collections.update({
      where: {
        collection_id: collectionWithProducts?.collection_id,
      },
      data: {
        collection_name: title,
        collection_condition: description || "",
        collection_banner_url: imageSrc || "",
      },
    });

    console.log("updatedCollection", updatedCollection);
    await removeProducts(
      admin,
      `gid://shopify/Collection/${id}`,
      collectionWithProducts,
    );
    const parsedProducts =
      typeof products === "string" ? JSON.parse(products) : [];

    const productIds = parsedProducts.map((p: any) => p.product_shopify_id);
    console.log("productIDs", productIds);

    const input = {
      id: `gid://shopify/Collection/${id}`,
      productIds: productIds,
      title,
      description,
      imageSrc,
    };
    const addedproducts = await addProducts(
      admin,
      input,
      parsedProducts,
      collectionWithProducts,
    );
    console.log("responsedata", addedproducts);
  }

  return json({
    success: 200,
  });
};

export default function Editcollection() {
  const [loader, setloader] = useState(false);
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(true);
  const fetcher = useFetcher();
  const { collectionWithProducts, products, search, type } =
    useLoaderData<EditCollectionLoader>();
  const [sort, setsort] = useState("Best Selling");
  const sortoptions = [{ label: "Best Selling", value: "Best Selling" }];
  const [IsModalOpen, setIsModalOpen] = useState(false);
  const handlesortchange = useCallback((value: string) => setsort(value), []);
  const [title, setTitle] = useState(
    collectionWithProducts[0]?.collection_name || "",
  );
  const [files, setFiles] = useState<File[]>([]);
  const [searchValue, setsearchValue] = useState("");
  const [description, setDescription] = useState(
    collectionWithProducts[0]?.collection_condition || "",
  );
  const [selectedTab, setselectedTab] = useState(type);
  const [bannerImage, setBannerImage] = useState(
    collectionWithProducts[0]?.collection_banner_url || "",
  );

  const initialSelectedProducts =
    collectionWithProducts?.[0]?.Collection_Products?.map(
      (cp: any) => cp.Products,
    ) || [];

  const [selectedproducts, setSelectedproducts] = useState<Product[]>(
    initialSelectedProducts,
  );
  const [searchProducts, setsearchProduct] = useState<Product[]>([]);

  const searchProduct = async () => {
    try {
      const response = await fetch(
        `/api/searchProducts?searchQuery=${searchValue}&searchTerm=${search}`,
      );

      if (!response.ok) {
        const text = await response.text();
        console.warn("Non-200 response:", response.status, text);
        return;
      }

      const data = await response.json();
      setsearchProduct(data || []);
    } catch (error) {
      console.log("Error fetching products", error);
    }
  };

  const removeproduct = (productId: number) => {
    setSelectedproducts((prev) =>
      prev.filter((p) => p.product_id !== productId),
    );
  };

  useEffect(() => {
    searchProduct();
  }, [searchValue]);

  const handlesave = async () => {
    if (!title || title.trim() === "") {
      shopify.toast.show("Please enter a title before saving.");
      return;
    }

    const formData = new FormData();
    formData.append("products", JSON.stringify(selectedproducts));
    formData.append("title", title);
    formData.append("description", description);
    formData.append("file", files[0] || "");
    await fetcher.submit(formData, {
      method: "POST",
      encType: "multipart/form-data",
    });

    setloader(true);
  };

  useEffect(() => {
    if (
      fetcher.data &&
      typeof fetcher.data === "object" &&
      "success" in fetcher.data &&
      (fetcher.data as any).success == 200
    ) {
      setloader(false);
      navigate(`/app/collection${search}`, {
        relative: "path",
        state: { some: selectedTab },
      });
    }
  }, [fetcher.data]);

  useEffect(() => {
    setIsLoading(false);
  }, []);

  const handleTitleChange = useCallback(
    (newValue: string) => setTitle(newValue),
    [setTitle],
  );

  const handleDescriptionChange = useCallback(
    (newValue: string) => setDescription(newValue),
    [setDescription],
  );

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setFiles([file]);

    // Preview update
    const previewUrl = URL.createObjectURL(file);
    setBannerImage(previewUrl);
  };

  const openFileDialog = () => {
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  if (isLoading) {
    return (
      <Page fullWidth>
        <Loader />
      </Page>
    );
  }

  return (
    <Page
      fullWidth
      backAction={{
        content: "Collection",
        onAction: () => navigate({ pathname: "/app/collection", search }),
      }}
      title="Collection"
      primaryAction={{
        content: "Save",
        onAction: handlesave,
        loading: loader,
      }}
    >
      <Layout>
        <Layout.Section>
          <div style={{ marginBottom: "20px" }}>
            {selectedTab == 1 ? (
              <Card>
                <div>
                  <div style={{ marginTop: "20px", marginBottom: "20px" }}>
                    <Text as="p" variant="headingMd">
                      Title
                    </Text>
                    <Text as="p" variant="bodyMd">
                      {title}
                    </Text>
                  </div>
                  <div style={{ marginTop: "20px", marginBottom: "20px" }}>
                    <Text as="p" variant="headingMd">
                      Description
                    </Text>
                    <Text as="p" variant="bodyMd">
                      {description}
                    </Text>
                  </div>
                </div>
              </Card>
            ) : (
              <Card>
                <div>
                  <div style={{ marginTop: "20px", marginBottom: "20px" }}>
                    <div style={{ marginBottom: "5px" }}>Title</div>
                    <TextField
                      label=""
                      value={title}
                      onChange={handleTitleChange}
                      autoComplete="off"
                      placeholder="eg. Summer Collection"
                    />
                  </div>
                  <div style={{ marginTop: "20px", marginBottom: "20px" }}>
                    <TextField
                      label="Description"
                      value={description}
                      onChange={handleDescriptionChange}
                      multiline={7}
                      autoComplete="off"
                    />
                  </div>
                </div>
              </Card>
            )}
          </div>
          <div style={{ marginBottom: "20px" }}>
            <Card>
              <div style={{ marginBottom: "20px" }}>
                <Text variant="headingLg" as="h2" fontWeight="semibold">
                  Products
                </Text>
              </div>
              <div
                style={{
                  display: "flex",
                  flexDirection: "column",
                  // alignItems: "center",
                  justifyContent:
                    selectedproducts.length > 0 ? "flex-start" : "center",
                  height: selectedproducts.length > 0 ? "auto" : "30vh",
                }}
              >
                <div>
                  <InlineStack wrap={true} align="start" gap="400">
                    <div style={{ width: "52%" }}>
                      <Combobox
                        activator={
                          <Combobox.TextField
                            prefix={<Icon source={SearchIcon} />}
                            label="Search Products"
                            labelHidden
                            placeholder="Search Products"
                            autoComplete="off"
                            onFocus={() => {
                              setIsModalOpen(true);
                            }}
                          />
                        }
                      ></Combobox>
                    </div>
                    <div>
                      <Button
                        size="medium"
                        onClick={() => {
                          setIsModalOpen(true);
                        }}
                      >
                        Browse
                      </Button>
                    </div>
                    <div style={{ width: "200px" }}>
                      <Select
                        label="Sort by"
                        labelInline
                        options={sortoptions}
                        onChange={handlesortchange}
                        value={sort}
                      />
                    </div>
                  </InlineStack>
                </div>

                {selectedproducts.length > 0 ? (
                  <></>
                ) : (
                  <div
                    style={{
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      textAlign: "center",
                      height: selectedproducts.length > 0 ? "auto" : "30vh",
                    }}
                  >
                    There are no products in this collection. Search or browse
                    to add products.
                  </div>
                )}
              </div>

              {selectedproducts.map((i, index) => {
                return (
                  <div key={i.product_id + `-outer`} style={{ width: "100%" }}>
                    <div
                      style={{
                        width: "100%",
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                        padding: "10px",
                        margin: "10px 0",
                        gap: "10px",
                        flexWrap: "wrap",
                      }}
                    >
                      <div
                        style={{
                          display: "flex",
                          alignItems: "center",
                          gap: "15px",
                          flex: 1,
                          minWidth: 0,
                        }}
                      >
                        <span>{index + 1}</span>
                        <Thumbnail
                          source={i.product_image_url}
                          alt={i.product_name}
                          size="medium"
                        />
                        <span
                          style={{
                            flex: 1,
                            minWidth: "100px",
                            overflowWrap: "anywhere",
                          }}
                        >
                          {i.product_name}
                        </span>
                      </div>

                      {/* Right side: badge + X icon */}
                      <div
                        style={{
                          display: "flex",
                          alignItems: "center",
                          gap: "10px",
                        }}
                      >
                        <Badge tone="success">Active</Badge>
                        <button
                          style={{
                            background: "none",
                            border: "none",
                            cursor: "pointer",
                          }}
                          onClick={() => removeproduct(i.product_id)}
                        >
                          <Icon source={XIcon} tone="base" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </Card>
          </div>{" "}
        </Layout.Section>
        <Layout.Section variant="oneThird">
          <Card>
            <Text as="h5" variant="headingLg">
              Image
            </Text>
            <div
              style={{
                position: "relative",
                width: "100%",
                height: "250px",
                overflow: "hidden",
                borderRadius: "12px",
              }}
            >
              <img
                src={
                  bannerImage ||
                  "https://cdn.shopify.com/s/files/1/0923/5460/9434/files/no-photo-or-blank-image-icon-loading-images-or-missing-image-mark-image-not-available-or-image-coming-soon-sign-simple-nature-silhouette-in-frame-isolated-illustration-vector.jpg?v=1746776130"
                }
                alt="Collection Banner"
                style={{
                  width: "100%",
                  height: "100%",
                  objectFit: "cover",
                  objectPosition: "center",
                }}
              />

              {/* Title */}
              <div
                style={{
                  position: "absolute",
                  bottom: "0",
                  left: "0",
                  right: "0",
                  background: "rgba(0, 0, 0, 0.5)",
                  color: "white",
                  padding: "12px 16px",
                  fontWeight: "bold",
                  fontSize: "18px",
                }}
              >
                {collectionWithProducts[0]?.collection_name ||
                  "Untitled Collection"}
              </div>

              {/* Centered Button */}
              {selectedTab == 1 || selectedTab == 0 ? (
                <div
                  style={{
                    position: "absolute",
                    top: "50%",
                    left: "50%",
                    transform: "translate(-50%, -50%)",
                  }}
                >
                  <Button onClick={openFileDialog}>Change</Button>
                  <input
                    type="file"
                    ref={fileInputRef}
                    style={{ display: "none" }}
                    accept="image/*"
                    onChange={handleFileChange}
                  />
                </div>
              ) : null}
            </div>

            <SearchModal
              open={IsModalOpen}
              onClose={() => setIsModalOpen(false)}
              products={searchProducts}
              selectedproducts={selectedproducts}
              search={search}
              setSelectedproducts={setSelectedproducts}
              setsearchValue={setsearchValue}
              searchValue={searchValue}
            />
          </Card>
        </Layout.Section>
      </Layout>
    </Page>
  );
}
