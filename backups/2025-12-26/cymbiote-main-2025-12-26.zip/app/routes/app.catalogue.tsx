import { useEffect, useState } from "react";
import type {
  ActionFunctionArgs,
  LoaderFunctionArgs,
  TypedResponse,
} from "@remix-run/node";
import { json, redirect } from "@remix-run/node";
import { useFetcher, useLoaderData, useNavigate } from "@remix-run/react";
import {
  Page,
  Layout,
  Button,
  ButtonGroup,
  ProgressBar,
  Text,
  TextField,
  Icon,
} from "@shopify/polaris";
import { SearchIcon } from "@shopify/polaris-icons";
import { authenticate } from "../shopify.server";
import NewProductsTable from "~/components/products/NewProductsTable";
import { ProductCategory } from "~/types/Products/ProductCategory";
import {
  addCatalogItems,
  fetchPaginatedProducts,
  updateCatalogItems,
} from "~/functions/products";
import { Loader } from "~/components/common/Loader";
import { ShopifyProduct } from "~/types/Products/ShopifyProduct";
import { usePolarisSound } from "~/hooks/useSound";
import { retryOperation } from "~/functions/common";
import usePublishPolling from "~/hooks/usePublishPoll";
import PublishInfoModal from "~/components/modals/PublishInfoModal";

interface LoaderReturn {
  products: any;
  APP_NAME: string;
  brands: any;
  nextCursor: string;
  shopDomain: string;
  productTaxonomy: any;
  shopCurrency: string;
  hasNextPage: boolean;
  dbProducts: DBProduct[];
  search: string | undefined;
}

type ActionResponse = {
  products?: any;
  message: string;
  success: boolean;
  processType: string;
  nextCursor?: string;
  hasNextPage?: boolean;
  previousCursor?: string;
  publishRequestId?: number;
  hasPreviousPage?: boolean;
};

export const action = async ({
  request,
}: ActionFunctionArgs): Promise<TypedResponse<ActionResponse>> => {
  const { admin } = await authenticate.admin(request);

  const formData = await request.formData();
  const productCategories: ProductCategory[] = JSON.parse(
    formData.get("productCategories")?.toString() as string,
  );
  const processType = formData.get("processType")?.toString();
  const url = new URL(request.url);
  const shopDomain = url.searchParams.get("shop");
  const params = new URLSearchParams(url.search);
  const queryString = params.toString();
  const checkSub = await retryOperation(async () => {
    return await prisma.subscriptions.findFirst({
      where: {
        Shops: {
          shop_domain: shopDomain,
        },
        subscription_confirmed: true,
      },
    });
  });

  if (!checkSub) {
    console.log("No subscription found", checkSub);
    return redirect(`/app/subscription?${queryString}`);
  }

  const productIds = productCategories.map((e) => e.productId);

  console.log("processType", processType);

  if (processType === "ADD") {
    try {
      const publishRequestCreate = await retryOperation(async () => {
        return await prisma.product_Publishing_Request.create({
          data: {
            publishing_request_product_count: productCategories.length,
            publishing_request_shop_id: checkSub.subscription_shop_id,
          },
        });
      });
      addCatalogItems(
        shopDomain as string,
        queryString,
        productIds,
        productCategories,
        admin,
      );

      return json(
        {
          success: true,
          message: "success",
          publishRequestId: publishRequestCreate?.publishing_request_id,
          processType: processType as string,
        },
        { status: 201 },
      );
    } catch (error: any) {
      console.error("Add Error products and variants to the database:", error);
      return new Response("Error adding products", { status: 500 });
    }
  } else if (processType === "UPDATE") {
    // this only runs when updating the products variants discounts
    try {
      const updatedItems = await updateCatalogItems(
        shopDomain as string,
        productCategories,
        productIds,
        admin,
      );

      return json(
        {
          success: true,
          message: "success",
          processType: processType as string,
        },
        { status: 201 },
      );
    } catch (error: any) {
      console.error(
        "Update Error adding products and variants to the database:",
        error,
      );
      return new Response("Error adding products", { status: 500 });
    }
  } else if (processType === "FETCH_NEXT" || processType === "FETCH_PREVIOUS") {
    const selected = formData.get("selected")?.toString();
    const paginationCursor = formData.get("cursor")?.toString(); // The cursor to fetch next or previous products

    try {
      const productSearch = formData.get("productSearch")?.toString(); // Get search term from form data

      const {
        hasNextPage,
        hasPreviousPage,
        nextCursor,
        previousCursor,
        products: paginatedProducts,
      } = await fetchPaginatedProducts(
        admin,
        processType === "FETCH_NEXT" ? "next" : "previous",
        paginationCursor,
        selected as string,
        checkSub.subscription_shop_id,
        productSearch,
      );

      let filteredProducts;

      if (selected === "0") {
        filteredProducts = paginatedProducts.filter(
          (product: any) => product.totalInventory > 0,
        );
      } else {
        filteredProducts = paginatedProducts;
      }

      let products = { nodes: filteredProducts };

      // If fetching next, return the next set of products
      return json<ActionResponse>({
        success: true,
        message: "success",
        processType,
        products,
        nextCursor: nextCursor as string,
        previousCursor: previousCursor as string,
        hasNextPage: hasNextPage,
        hasPreviousPage: hasPreviousPage,
      });
    } catch (error: any) {
      console.error("Error fetching paginated products:", error);
      return new Response("Error fetching products", { status: 500 });
    }
  } else {
    try {
      console.log("Delisting products with IDs:", productIds);
      const updatedItems = await retryOperation(async () => {
        return await prisma.products.updateMany({
          where: {
            product_shopify_id: {
              in: productIds,
            },
          },
          data: {
            product_is_active: false,
          },
        });
      });

      return json<ActionResponse>(
        {
          success: true,
          message: "success",
          processType: processType as string,
        },
        { status: 201 },
      );
    } catch (error) {
      console.error("Error in database update:", error);
      return new Response("Error adding products", { status: 500 });
    }
  }
};

export const loader = async ({
  request,
}: LoaderFunctionArgs): Promise<TypedResponse<LoaderReturn>> => {
  const { admin } = await authenticate.admin(request);
  const url = new URL(request.url);
  const shopDomain = url.searchParams.get("shop");
  const searchTerm = url.searchParams.get("searchTerm") || "";
  const productSearchTerm = url.searchParams.get("productSearch") || "";
  const APP_NAME = process.env.APP_NAME || "Cymbiote";

  const taxonomyQuery = `
      {
        taxonomy {
          categories(first: 25 ${searchTerm ? ', search: "' + searchTerm + '"' : ""}) {
            nodes {
              fullName
              isRoot
              id
              ancestorIds
            }
          }
        }
      }`;

  const taxonomyResponse = await admin.graphql(taxonomyQuery);

  try {
    const productTexonomyData = await taxonomyResponse.json();

    const shopPriceList = await retryOperation(async () => {
      return await prisma.shops.findFirst({
        where: {
          shop_domain: shopDomain,
        },
        select: {
          shop_id: true,
          shop_currency: true,
        },
      });
    });

    const dbProducts = await retryOperation(async () => {
      return await prisma.products.findMany({
        where: {
          Shops: {
            shop_domain: shopDomain,
          },
        },
        select: {
          product_shopify_id: true,
          product_is_active: true,
          product_custom_category: true,
          product_brand_id: true,
          product_shop_id: true,
          product_custom_category_id: true,
          product_custom_category_hierarchy: true,
        },
      });
    });

    const brands = await retryOperation(async () => {
      return await prisma.brands.findMany({
        where: {
          brand_status: true,
        },
        orderBy: {
          brand_name: "asc",
        },
      });
    });

    console.log("Feching all products from shopify");

    const {
      hasNextPage,
      nextCursor,
      products: paginatedProducts,
    } = await fetchPaginatedProducts(
      admin,
      "next",
      null,
      dbProducts && dbProducts.length > 0 ? "0" : "1",
      shopPriceList?.shop_id as number,
      productSearchTerm,
    );

    const filteredProducts = paginatedProducts.filter(
      (product: any) => product.totalInventory > 0,
    );

    const products = { nodes: filteredProducts };

    console.log("products======>", products?.nodes?.length);

    return json({
      brands,
      APP_NAME,
      products,
      hasNextPage,
      search: url.search,
      shopDomain: shopDomain || "",
      nextCursor: nextCursor as string,
      dbProducts: dbProducts as unknown as DBProduct[],
      productTaxonomy: productTexonomyData.data,
      shopCurrency: shopPriceList?.shop_currency || "PKR",
    });
  } catch (error: any) {
    console.error("Error fetching products:", error);
    throw new Response(error, { status: 500 });
  }
};

export const Products = () => {
  const {
    search,
    brands,
    products,
    APP_NAME,
    dbProducts,
    nextCursor,
    shopDomain,
    hasNextPage,
    shopCurrency,
    productTaxonomy,
  } = useLoaderData<LoaderReturn>();

  const [filteredProducts, setFilteredProducts] = useState<any>(null);
  const [isPostBack, setIsPostBack] = useState(false);
  const [selectedProductCategories, setSelectedProductCategories] = useState<
    ProductCategory[]
  >([]);
  const [variantDiscountAdded, setVariantDiscountAdded] = useState(false);
  const [selected, setSelected] = useState(0);
  const [loading, setLoading] = useState(false);
  const [productsLoading, setProductsLoading] = useState(false);
  const [newDbProducts, setNewDbProducts] = useState(dbProducts);
  const [goingBulkEdit, setGoingBulkEdit] = useState(false);
  const [loadCategories, setLoadCategories] = useState(false);
  const [productWithCategoriesCount, setProductWithCategoriesCount] =
    useState(0);
  const [nextCursorS, setNextCursor] = useState(nextCursor);
  const [prevCursorS, setPrevCursor] = useState("");
  const [hasPrevPageS, setHasPrevPage] = useState(false);
  const [hasNextPageS, setHasNextPage] = useState(hasNextPage);
  const [autofetchMissingItems, setAutofetchMissingItems] = useState<string[]>(
    [],
  );
  const [publishRequestId, setPublishRequestId] = useState(0);
  const [publishStatus, setPublishStatus] = useState("");
  const [publishedCount, setPublishedCount] = useState(0);
  const [totalCount, setTotalCount] = useState(0);
  const [shouldPoll, setShouldPoll] = useState(false);
  const [displayPublishModal, setDisplayPublishModal] = useState(false);
  const [productSearchTerm, setProductSearchTerm] = useState("");
  const [debouncedProductSearchTerm, setDebouncedProductSearchTerm] =
    useState("");

  const fetcher = useFetcher<ActionResponse>();
  const navigate = useNavigate();
  const { taxonomy } = productTaxonomy;
  const playSuccess = usePolarisSound("success");

  const onPublishComplete = () => {
    console.log("publish completed");
    setSelectedProductCategories([]);
    setTimeout(() => {
      setLoading(false);
      fetchShopifyProducts().then(() => {
        const newSelected = selected === 0 ? 1 : 0;
        setSelected(newSelected);
      });
    }, 1000);
    setShouldPoll(false);
  };

  usePublishPolling(
    search as string,
    publishRequestId.toString(),
    setPublishedCount,
    setTotalCount,
    setPublishStatus,
    shouldPoll,
    onPublishComplete,
  );

  useEffect(() => {
    if (isPostBack) {
      fetchShopifyProducts();
    }
    // Reset auto-selection states when switching tabs
    setLoadCategories(false);
    setAutofetchMissingItems([]);
  }, [selected]);

  // useEffect(() => {
  //   applyFilters(shopifyProducts, newDbProducts);
  // }, [shopifyProducts, newDbProducts]);

  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedProductSearchTerm(productSearchTerm);
    }, 500);

    return () => {
      clearTimeout(handler);
    };
  }, [productSearchTerm]);

  useEffect(() => {
    if (isPostBack) {
      handleSearch();
    }
  }, [debouncedProductSearchTerm]);

  useEffect(() => {
    if (selectedProductCategories.length > 0 && selected === 0) {
      const allHaveDiscountedVariants = selectedProductCategories.every(
        (category) =>
          category.DiscountedVariants && category.DiscountedVariants.length > 0,
      );
      setVariantDiscountAdded(allHaveDiscountedVariants);
    } else {
      setVariantDiscountAdded(false);
    }
    // I did minus 1 because sometimes the last product category is not updated thus remaining n-1
    // this is responsible to hide the progress bar after all categories are loaded
    if (
      productWithCategoriesCount <= selectedProductCategories.length &&
      productWithCategoriesCount > 0 &&
      selectedProductCategories.length > 0
    ) {
      playSuccess();
      setLoadCategories(false);
    }

    if (selected === 1) {
      const missingItems = findMissingItems(
        filteredProducts,
        selectedProductCategories,
      );
      setAutofetchMissingItems(missingItems);
    }
  }, [selectedProductCategories]);

  useEffect(() => {
    if (fetcher.data?.success) {
      if (fetcher.data.processType === "ADD") {
        setPublishRequestId(fetcher.data.publishRequestId || 0);
        setShouldPoll(true);
        setDisplayPublishModal(true);
      } else if (
        fetcher.data.processType === "UPDATE" ||
        fetcher.data.processType === "DELIST"
      ) {
        setSelectedProductCategories([]);
        setTimeout(() => {
          setLoading(false);
          fetchShopifyProducts().then(() => {
            const newSelected = selected === 0 ? 1 : 0;
            setSelected(newSelected);
          });
        }, 1000);
      } else if (
        fetcher.data.processType === "FETCH_NEXT" ||
        fetcher.data.processType === "FETCH_PREVIOUS"
      ) {
        setNextCursor(fetcher.data.nextCursor || "");
        setPrevCursor(fetcher.data.previousCursor || "");
        setHasNextPage(fetcher.data.hasNextPage || false);
        setHasPrevPage(fetcher.data.hasPreviousPage || false);
        // setSelectedProductCategories([]);
        applyFilters(fetcher.data.products, newDbProducts);
        setProductsLoading(false);
      }
    }
  }, [fetcher.data]);

  useEffect(() => {
    setIsPostBack(true);
    applyFilters(products, newDbProducts);
  }, []);

  const fetchShopifyProducts = async () => {
    try {
      setProductsLoading(true);
      const response = await fetch(
        `/api/shopifyproducts?selected=${selected}&shop=${shopDomain}`,
      );
      const result = await response.json();
      applyFilters(result.products, result.dbProducts);
      setNewDbProducts(result.dbProducts);
      setNextCursor(result.nextCursor);
      setHasNextPage(result.hasNextPage);
    } catch (error: any) {
      console.log("Error while fetching shopify products", error.message);
    } finally {
      setProductsLoading(false);
    }
  };

  const filterPublishedProducts = (shopifyData: any, dbData: any[]) => {
    // Filter Shopify products that are active in the database
    const publishedProductIds = shopifyData?.nodes?.filter(
      (product: IShopifyProduct) =>
        dbData.some((dbProduct) => {
          if (
            dbProduct.product_shopify_id === product.id && // Match product by Shopify ID
            dbProduct.product_is_active // Ensure the product is active
          ) {
            // If a match is found, add the custom category to the product
            product.product_custom_category =
              dbProduct.product_custom_category || "";
            product.product_custom_category_id =
              dbProduct.product_custom_category_id || "";
            product.categoryFullname =
              dbProduct.product_custom_category_hierarchy || "";
            product.product_brand_id = dbProduct.product_brand_id;
            return true; // Include this product in the result
          }
          return false; // Exclude this product if no match
        }),
    );
    // console.log("Published Product IDs:", publishedProductIds);
    return publishedProductIds;
  };

  const filterUnPublishedProducts = (shopifyData: any, dbData: any[]) => {
    // Create a Map for O(1) lookup
    const dbMap = new Map(
      dbData.map((dbProduct) => [dbProduct.product_shopify_id, dbProduct]),
    );

    const unpublishedProductIds = shopifyData?.nodes?.filter(
      (product: IShopifyProduct) => {
        const dbMatch = dbMap.get(product.id);

        if (dbMatch) {
          if (dbMatch.product_is_active) {
            return false; // Exclude active ones (they are in Published tab)
          } else {
            // Inactive in DB. Include it and attach brand ID.
            product.product_brand_id = dbMatch.product_brand_id;
            return true;
          }
        }
        // Not in DB. Include it.
        return true;
      },
    );
    // console.log("Unpublished Products:", unpublishedProductIds);
    return unpublishedProductIds;
  };

  const applyFilters = (shopifyData: any, dbData: any[]) => {
    // console.log("applyFilters params", shopifyData, dbData);
    const filtered =
      selected === 0
        ? filterPublishedProducts(shopifyData, dbData)
        : filterUnPublishedProducts(shopifyData, dbData);

    const filteredWithCategoriesCount = filtered?.filter((e: any) => {
      return e.category && e.category.name !== "Uncategorized";
    }).length;

    setProductWithCategoriesCount(
      selected === 1
        ? filteredWithCategoriesCount + productWithCategoriesCount
        : 0,
    );
    // Removed automatic loadCategories trigger
    // Now controlled by manual button click
    // setLoadCategories(
    //   selected === 1 ? (filteredWithCategoriesCount > 0 ? true : false) : false,
    // );
    if (selected === 0) {
      setSelectedProductCategories([]);
    }

    setFilteredProducts(filtered);
  };

  const handleAddToDatabase = () => {
    if (selectedProductCategories.length < 1) {
      shopify.toast.show("Kindly select at least 1 product to publish");
      return;
    }

    setLoading(true);
    const form = new FormData();
    form.append("productCategories", JSON.stringify(selectedProductCategories));
    form.append("processType", "ADD");
    fetcher.submit(form, { method: "POST" });
  };

  const handleDeleteFromDatabase = () => {
    if (selectedProductCategories.length < 1) {
      shopify.toast.show("Kindly select at least 1 product to delist");
      return;
    }

    setLoading(true);
    const form = new FormData();
    form.append("productCategories", JSON.stringify(selectedProductCategories));
    form.append("processType", "DELIST");
    fetcher.submit(form, { method: "POST" });
  };

  const handleUpdateProductsDiscounts = () => {
    setLoading(true);
    const form = new FormData();
    form.append("productCategories", JSON.stringify(selectedProductCategories));
    form.append("processType", "UPDATE");
    fetcher.submit(form, { method: "POST" });
  };

  const handleNextPageProducts = () => {
    setProductsLoading(true);

    const form = new FormData();
    form.append("productCategories", JSON.stringify(selectedProductCategories));
    form.append("processType", "FETCH_NEXT");
    form.append("cursor", nextCursorS);
    form.append("selected", selected.toString());
    if (debouncedProductSearchTerm) {
      form.append("productSearch", debouncedProductSearchTerm);
    }

    fetcher.submit(form, { method: "POST" });
  };

  const handlePrevPageProducts = () => {
    setProductsLoading(true);

    const form = new FormData();
    form.append("productCategories", JSON.stringify(selectedProductCategories));
    form.append("processType", "FETCH_PREVIOUS");
    form.append("cursor", prevCursorS);
    form.append("selected", selected.toString());
    if (debouncedProductSearchTerm) {
      form.append("productSearch", debouncedProductSearchTerm);
    }

    setProductWithCategoriesCount(
      selected === 1 ? productWithCategoriesCount - 50 : 0,
    );

    fetcher.submit(form, { method: "POST" });
  };

  const handleSearch = () => {
    setIsPostBack(true);
    setProductsLoading(true);
    // Reset cursors on new search
    setNextCursor("");
    setPrevCursor("");
    setProductWithCategoriesCount(0);
    setSelectedProductCategories([]);

    // We can use the navigate to update URL params or define a SEARCH action type
    // But since we want to reuse the pagination logic which fetches products...
    // Let's use FETCH_NEXT with empty cursor to get first page, essentially.

    const form = new FormData();
    form.append("productCategories", JSON.stringify([]));
    form.append("selected", selected.toString());
    form.append("processType", "FETCH_NEXT"); // Re-using fetch next with no cursor acts as fetch first page
    form.append("cursor", "");
    if (debouncedProductSearchTerm) {
      form.append("productSearch", debouncedProductSearchTerm);
    }

    // Also update URL to keep state shareable
    const newUrl = new URL(window.location.href);
    if (debouncedProductSearchTerm) {
      newUrl.searchParams.set("productSearch", debouncedProductSearchTerm);
    } else {
      newUrl.searchParams.delete("productSearch");
    }
    window.history.replaceState(null, "", newUrl.toString());

    fetcher.submit(form, { method: "POST" });
  };

  const findMissingItems = (
    mainArray: ShopifyProduct[], // The first array with product details
    secondArray: ProductCategory[], // The second array with productId
  ): string[] => {
    if (!mainArray || !secondArray) {
      return [];
    }

    const missingProducts = mainArray.filter((mainItem) => {
      return !secondArray.some(
        (secondItem) => secondItem.productId === mainItem.id,
      );
    });

    const missingProductIds = missingProducts.map((item) => item.id);
    return missingProductIds;
  };

  const handleAutoSelectCategories = () => {
    if (selected === 1 && filteredProducts) {
      setLoadCategories(true);
      const missingItems = findMissingItems(
        filteredProducts,
        selectedProductCategories,
      );
      setAutofetchMissingItems(missingItems);
    }
  };

  if (!isPostBack) {
    return (
      <Page fullWidth>
        <Loader />
      </Page>
    );
  }

  return (
    <Page
      backAction={{
        content: "Catalogue",
        onAction: () => navigate({ pathname: "/app", search }),
      }}
      title="Catalogue"
      secondaryActions={
        <div
          style={{
            width: "200px",
            height: "auto",
            display: loadCategories ? "flex" : "none",
            flexDirection: "column",
            alignItems: "start",
            gap: "10px",
            position: "fixed",
            top: 10,
            right: "48%",
          }}
        >
          <Text as="p" fontWeight="semibold">
            Loading shopify categories
          </Text>
          <ProgressBar
            progress={
              (selectedProductCategories?.length / productWithCategoriesCount) *
              100
            }
            tone="primary"
          />
        </div>
      }
      primaryAction={
        <div style={{ display: "flex", gap: "10px" }}>
          <ButtonGroup>
            {selected === 0 &&
              filteredProducts &&
              filteredProducts.length > 0 && (
                <Button
                  onClick={() => {
                    if (filteredProducts && filteredProducts.length > 0) {
                      if (
                        selectedProductCategories.length ===
                        filteredProducts.length
                      ) {
                        setSelectedProductCategories([]);
                      } else {
                        const allCategories = filteredProducts.map(
                          (p: IShopifyProduct) => ({
                            productId: p.id,
                            productCategory: p.product_custom_category || "",
                            productCategoryId:
                              p.product_custom_category_id || "",
                            categoryFullname: p.categoryFullname || "",
                            brandId: p.product_brand_id
                              ? p.product_brand_id.toString()
                              : undefined,
                          }),
                        );
                        setSelectedProductCategories(allCategories);
                      }
                    }
                  }}
                >
                  {filteredProducts &&
                  selectedProductCategories.length === filteredProducts.length
                    ? "Deselect All"
                    : "Select All"}
                </Button>
              )}
            {selected === 1 && (
              <Button
                loading={loadCategories}
                disabled={
                  loadCategories ||
                  !filteredProducts?.some(
                    (p: any) =>
                      p.category?.name &&
                      p.category.name !== "Uncategorized" &&
                      !selectedProductCategories.some(
                        (s) => s.productId === p.id,
                      ),
                  )
                }
                onClick={handleAutoSelectCategories}
              >
                Auto-Select Categories
              </Button>
            )}
            <Button
              loading={goingBulkEdit}
              onClick={() => {
                setGoingBulkEdit(true);
                const shopHandle = shopDomain.replace(".myshopify.com", "");
                const appHandle = APP_NAME.toLowerCase().replace(/\s+/g, "-"); // ensure handle format just in case
                const returnTo = encodeURIComponent(
                  `/store/${shopHandle}/apps/${appHandle}/app`,
                );

                const bulkEditUrl = `https://${shopDomain}/admin/bulk/product?resource_name=Product&edit=status%2Cproduct_taxonomy_node_id%2Cvendor%2Cvariants.price%2Cmetafields.app--256725581825--custom_category.cymbiote_product_category&return_to=${returnTo}`;

                if (window.top) {
                  window.open(bulkEditUrl, "_top");
                } else {
                  window.location.href = bulkEditUrl;
                }
              }}
              variant="primary"
            >
              Bulk Edit
            </Button>
            <Button
              disabled={selectedProductCategories.length < 1}
              onClick={
                selected === 0
                  ? variantDiscountAdded
                    ? handleUpdateProductsDiscounts
                    : handleDeleteFromDatabase
                  : handleAddToDatabase
              }
              variant="primary"
              loading={loading}
            >
              {variantDiscountAdded
                ? "Set Product Discount"
                : selected === 0
                  ? variantDiscountAdded
                    ? "Update Discount"
                    : `Delist (${selectedProductCategories.length}) ${selectedProductCategories.length > 1 ? "Products" : "Product"}`
                  : `Publish (${selectedProductCategories.length}) ${selectedProductCategories.length > 1 ? "Products" : "Product"}`}
            </Button>
          </ButtonGroup>
        </div>
      }
      fullWidth
    >
      <Layout>
        <Layout.Section>
          <NewProductsTable
            searchUrl={search as string}
            selected={selected}
            isLoading={productsLoading}
            taxonomy={taxonomy}
            setSelected={setSelected}
            products={filteredProducts}
            shopCurrency={shopCurrency}
            loadCategories={loadCategories}
            hasNextPage={hasNextPageS}
            hasPrevPage={hasPrevPageS}
            autoFetchMissingItems={autofetchMissingItems}
            handlePrevPageClick={handlePrevPageProducts}
            handleNextPageClick={handleNextPageProducts}
            selectedProductCategories={selectedProductCategories}
            setSelectedProductCategories={setSelectedProductCategories}
            brands={brands}
            queryValue={productSearchTerm}
            onQueryChange={setProductSearchTerm}
            onQueryClear={() => setProductSearchTerm("")}
          />
        </Layout.Section>
      </Layout>
      <PublishInfoModal
        message={publishStatus}
        onClose={() => {
          setDisplayPublishModal(false);
        }}
        open={displayPublishModal}
        title="Publish Status"
        isLoading={loading}
      />
      <div style={{ height: 10 }} />
    </Page>
  );
};

export default Products;
