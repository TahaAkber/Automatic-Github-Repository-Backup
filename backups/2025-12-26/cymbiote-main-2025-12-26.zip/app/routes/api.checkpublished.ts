import { ActionFunctionArgs, json } from "@remix-run/node";
import { retryOperation, wait } from "~/functions/common";

export const loader = async ({ request }: ActionFunctionArgs) => {
  try {
    const url = new URL(request.url);
    const publishRequestId = url.searchParams.get("publishRequestId") || "";
    console.log("check publish ran", publishRequestId);

    const publishRequest = await retryOperation(async () => {
      return await prisma.product_Publishing_Request.findFirst({
        where: {
          publishing_request_id: parseInt(publishRequestId, 10),
        },
      });
    });

    const created_date = new Date(publishRequest?.created_at || new Date(0));
    console.log("publishRequest", publishRequest, created_date);

    const publishedItems = await retryOperation(async () => {
      return await prisma.products.findMany({
        where: {
          updated_at: {
            gte: created_date,
          },
          product_shop_id: publishRequest?.publishing_request_shop_id,
        },
      });
    });

    const returnJson = {
      publishedItemsCount: publishedItems?.length || 0,
      publishedTotalCount:
        publishRequest?.publishing_request_product_count || 0,
    };

    console.log("returnJson", returnJson);

    return json(returnJson);
  } catch (error: any) {
    console.error("Category fetch error message", error);
    return new Error("Failed to fetch categories", { cause: error.message });
  }
};
