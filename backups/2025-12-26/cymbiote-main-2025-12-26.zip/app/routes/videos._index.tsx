import { useEffect, useState } from "react";
import type {
  ActionFunctionArgs,
  LoaderFunctionArgs,
  TypedResponse,
} from "@remix-run/node";
import { json } from "@remix-run/node";
import { useFetcher, useLoaderData, useNavigate } from "@remix-run/react";
import {
  Page,
  Layout,
  Card,
  Text,
  Scrollable,
  InlineStack,
  Button,
} from "@shopify/polaris";
import { authenticate } from "../shopify.server";
import { Reels } from "~/components/reelsnstories/Reels";
import { Stories } from "~/components/reelsnstories/Stories";
import { Loader } from "~/components/common/Loader";

interface LoaderReturn {
  search: string;
  ReelsData: any[];
  StoryData: any[];
}
interface ReturnAction {
  result: string;
}

export const action = async ({
  request,
}: ActionFunctionArgs): Promise<TypedResponse<ReturnAction>> => {
  const { admin, redirect } = await authenticate.admin(request);

  const formData = await request.formData();
  // const productIdsString = formData.get("productIds") as string;
  const reelId = formData.get("reelId") as string;
  const storyId = formData.get("StoryId") as string;
  const reUpload = formData.get("reUpload") as string;
  console.log("reels", reelId, storyId, reUpload);
  try {
    const videoId = reelId || storyId;
    console.log("videoId", videoId);

    if (reUpload === "story") {
      const ReelStory = await prisma.reelsNStories.findFirst({
        where: {
          video_url_id: Number(videoId),
        },
      });
      await prisma.videos.update({
        where: { video_id: Number(videoId) },
        data: { updated_at: new Date() },
      });
      await prisma.reelsNStories.update({
        where: { id: Number(ReelStory?.id) },
        data: { updated_at: new Date() },
      });
    }

    if (videoId && reUpload === null) {
      await prisma.reels_Products.deleteMany({
        where: { reel_video_id: Number(videoId) },
      });

      const deleteVideo = await prisma.reelsNStories.findFirst({
        where: {
          video_url_id: Number(videoId),
        },
      });

      if (deleteVideo) {
        await prisma.saved_ReelsNStories.deleteMany({
          where: { saved_video_id: Number(deleteVideo.id) },
        });
      }

      await prisma.reelsNStories.deleteMany({
        where: { video_url_id: Number(videoId) },
      });

      await prisma.videos.delete({
        where: { video_id: Number(videoId) },
      });

      console.log("Reel or Story deleted successfully");
    } else {
      console.log("No reelId or storyId provided");
    }
  } catch (error) {
    console.error("Delete error:", error);
  }

  const url = new URL(request.url);
  const shopDomain = url.searchParams.get("shop");
  const params = new URLSearchParams(url.search);
  const queryString = params.toString();

  return json({ result: "success" });
};

export const loader = async ({
  request,
}: LoaderFunctionArgs): Promise<TypedResponse<LoaderReturn>> => {
  const { admin } = await authenticate.admin(request);
  const url = new URL(request.url);
  const shopDomain = url.searchParams.get("shop");
  const searchTerm = url.searchParams.get("searchTerm") || "";

  try {
    const shop = await prisma.shops.findFirst({
      where: {
        shop_domain: shopDomain,
      },
      include: {
        Products: true,
      },
    });
    const DbReelsData = await prisma.videos.findMany({
      where: {
        video_shop_id: shop?.shop_id,
        ReelsNStories: {
          some: {
            video_type: "REEL",
          },
        },
      },
      include: {
        ReelsNStories: true,
      },
    });

    const videoIds = DbReelsData.map((video: any) => video.video_id);

    const reelsProducts = await prisma.reels_Products.findMany({
      where: {
        reel_video_id: {
          in: videoIds,
        },
      },
      include: {
        Products: true,
      },
    });

    const combinedData = DbReelsData.map((video: any) => {
      const relatedProducts = reelsProducts.filter(
        (product: any) => product.reel_video_id === video.video_id,
      );

      return {
        video,
        products: relatedProducts.map((product: any) => product.Products),
      };
    });

    console.log("Combined Reels Data", combinedData);

    const DbStoryData = await prisma.videos.findMany({
      where: {
        video_shop_id: shop?.shop_id,
        ReelsNStories: {
          some: {
            video_type: "STORY",
          },
        },
      },
      include: {
        ReelsNStories: true,
      },
    });

    const StoryProducts = await prisma.reels_Products.findMany({
      where: {
        reel_video_id: DbStoryData[0]?.video_id,
      },
      include: {
        Products: true,
      },
    });

    const combinedStoryData = DbStoryData.map((video: any) => {
      const relatedStories = StoryProducts.filter(
        (product: any) => product.reel_video_id === video.video_id,
      );

      return {
        video,
        products: relatedStories.map((story: any) => story.Products),
      };
    });

    console.log("Combine Story Data", combinedStoryData);

    return json({
      search: url.search,
      ReelsData: combinedData,
      StoryData: combinedStoryData,
    });
  } catch (error: any) {
    console.error("Error fetching products:", error);
    return json({
      search: url.search,
      ReelsData: [],
      StoryData: [],
    });
  }
};

export const Index = () => {
  const fetcher = useFetcher();
  const { search, ReelsData, StoryData } = useLoaderData<LoaderReturn>();
  const [isPostBack, setIsPostBack] = useState(false);
  const [reels, setReels] = useState([]);
  const [stories, setStories] = useState([]);
  const [isloading, setisloading] = useState(false);
  const [isstoryloading, setisstoryloading] = useState(false);
  const navigate = useNavigate();

  // console.log("selectedProducts", selectedProducts);
  useEffect(() => {
    setIsPostBack(true);
  }, []);

  const deleteReel = async (reelId: string) => {
    const formData = new FormData();
    formData.append("reelId", reelId);
    fetcher.submit(formData, {
      method: "POST",
      encType: "multipart/form-data",
    });

    console.log("Reel id testing", reelId);
  };

  const deleteStory = async (storyId: string) => {
    const formData = new FormData();
    formData.append("StoryId", storyId);
    fetcher.submit(formData, {
      method: "POST",
      encType: "multipart/form-data",
    });

    console.log("Story id testing", storyId);
  };

  const reUploadStory = async (storyId: string) => {
    const formData = new FormData();
    formData.append("StoryId", storyId);
    formData.append("reUpload", "story");
    fetcher.submit(formData, {
      method: "POST",
      encType: "multipart/form-data",
    });

  };

  const handleUploadStory = () => {
    setisstoryloading(true);
    navigate({ pathname: "/videos/uploadstory", search });
  };
  const handleUploadReel = () => {
    setisloading(true);
    navigate({ pathname: "/videos/uploadreel", search });
  };

  if (!isPostBack) {
    return (
      <Page fullWidth>
        <Loader />
      </Page>
    );
  }

  return (
    <Page
      backAction={{
        content: "Reels & Stories",
        onAction: () => navigate({ pathname: "/app", search }),
      }}
      title="Reels & Stories"
      fullWidth
    >
      <Layout>
        <Layout.Section variant="oneHalf">
          <Card>
            <div style={{ paddingBottom: "2%" }}>
              <InlineStack align="space-between" blockAlign="center">
                <Text as="h4" variant="headingMd" fontWeight="bold">
                  Reels
                </Text>
                <Button
                  size="large"
                  onClick={handleUploadReel}
                  loading={isloading}
                >
                  Upload Reel
                </Button>
              </InlineStack>
            </div>
            <Scrollable
              shadow
              style={{
                maxHeight: "calc(100vh - 150px)",
                overflowY: "auto",
              }}
              focusable
            >
              <Reels
                reels={ReelsData}
                deleteReel={deleteReel}
                // ReelsData={ReelsData}
                // ReelProduct={ReelProduct}
              />
            </Scrollable>
          </Card>
        </Layout.Section>
        <Layout.Section variant="oneThird">
          <Card>
            <div style={{ paddingBottom: "2%" }}>
              <InlineStack align="space-between" blockAlign="center">
                <Text as="h3" variant="headingMd" fontWeight="bold">
                  Story
                </Text>
                <Button
                  size="large"
                  onClick={handleUploadStory}
                  loading={isstoryloading}
                >
                  Upload Story
                </Button>
              </InlineStack>
            </div>
            <Scrollable
              shadow
              style={{
                maxHeight: "calc(100vh - 150px)",
                overflowY: "auto",
              }}
              focusable
            >
              {/* STORIES */}
              <Stories
                deleteStory={deleteStory}
                stories={StoryData}
                reUploadStory={reUploadStory}
              />
            </Scrollable>
          </Card>
        </Layout.Section>
      </Layout>
    </Page>
  );
};

export default Index;
