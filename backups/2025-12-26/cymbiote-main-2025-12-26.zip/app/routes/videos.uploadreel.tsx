import {
  ActionFunctionArgs,
  LoaderFunctionArgs,
  TypedResponse,
} from "@remix-run/node";
import { useFetcher, useLoaderData, useNavigate } from "@remix-run/react";
import { Page } from "@shopify/polaris";
import { authenticate } from "../shopify.server";
import { json } from "@remix-run/node";
import { useEffect, useState } from "react";
import Upload from "~/components/reelsnstories/Upload";
import { uploadToShopify } from "~/functions/common";
import { Loader } from "~/components/common/Loader";
import { trimToSeconds } from "~/functions/trimVideo";
import axios from "axios";

interface loaderreturn {
  search: string;
}

export const action = async ({ request }: ActionFunctionArgs) => {
  const { admin } = await authenticate.admin(request);
  const url = new URL(request.url);
  const shopDomain = url.searchParams.get("shop");
  const ApiKey = process.env.ENV_URL;

  if (!admin) {
    throw new Response("Unauthorized", { status: 401 });
  }

  const wait = (ms: number) => new Promise((res) => setTimeout(res, ms));

  async function pollImageUrl(
    admin: any,
    nodeId: string,
    retries = 5,
    delay = 2000,
  ) {
    for (let i = 0; i < retries; i++) {
      const q = `
        {
          nodes(ids: ["${nodeId}"]) {
            id
            ... on MediaImage {
              image { url id }
            }
          }
        }`;
      const r = await admin.graphql(q);
      const data = await r.json();
      const url = data?.data?.nodes?.[0]?.image?.url;
      console.log(`Fetching Uploaded Image URL... Attempt ${i + 1}/${retries}`);
      if (url) return url;
      await wait(delay);
    }
    throw new Error("Image URL not available after retries");
  }

  async function pollVideoSources(
    admin: any,
    nodeId: string,
    retries = 12,
    delay = 5000,
  ) {
    for (let i = 0; i < retries; i++) {
      const q = `
        {
          nodes(ids: ["${nodeId}"]) {
            id
            ... on Video {
              sources { url }
            }
          }
        }`;
      const r = await admin.graphql(q);
      const data = await r.json();
      const sources = data?.data?.nodes?.[0]?.sources;
      console.log(`Fetching Uploaded Video URL... Attempt ${i + 1}/${retries}`);
      if (Array.isArray(sources) && sources.length > 0)
        return sources as Array<{ url: string }>;
      await wait(delay);
    }
    return null;
  }

  let imageSrc: string | null = null;
  let tmpDirForCleanup: string | null = null;

  try {
    const formData = await request.formData();
    const thumbnail = formData.get("thumbnail") as File | null;
    const video = formData.get("video") as File | null;
    const product = formData.get("product") as string;

    if (!thumbnail || !video) {
      return json(
        { success: false, message: "Missing thumbnail or video" },
        { status: 400 },
      );
    }

    try {
      const imageUpload = await uploadToShopify(
        thumbnail,
        admin,
        thumbnail.name,
      );
      if (imageUpload) {
        imageSrc = await pollImageUrl(admin, imageUpload);
      }
    } catch (err) {
      console.error("Failed to upload/poll image:", err);
    }

    const fullUploadId = await uploadToShopify(
      video,
      admin,
      video.name,
      "VIDEO",
    );
    if (!fullUploadId) throw new Error("Original video upload failed");

    const fullSources = await pollVideoSources(admin, fullUploadId);
    if (!fullSources) throw new Error("Original video sources not ready");

    const full_480 = fullSources.find((v) => v.url.includes("480p"))?.url;
    const full_720 = fullSources.find((v) => v.url.includes("720p"))?.url;
    const full_1080 = fullSources.find((v) => v.url.includes("1080p"))?.url;
    const full_best = full_720 ?? full_480 ?? full_1080 ?? fullSources[0]?.url;

    // 3) Make a separate 3-second PREVIEW (trim & upload)
    const { clipped, tmpDir } = await trimToSeconds(video, 3);
    tmpDirForCleanup = tmpDir;

    const previewUploadId = await uploadToShopify(
      clipped,
      admin,
      clipped.name,
      "VIDEO",
    );
    if (!previewUploadId) throw new Error("Preview upload failed");

    const previewSources = await pollVideoSources(admin, previewUploadId);
    if (!previewSources) throw new Error("Preview sources not ready");

    // pick any available (prefer 480p) — this is a true 3s file
    const preview_480 = previewSources.find((v) => v.url.includes("480p"))?.url;
    const preview_url = preview_480 ?? previewSources[0]?.url;

    // 4) Save to DB (full URLs + preview URL)
    const shop = shopDomain
      ? await prisma.shops.findFirst({ where: { shop_domain: shopDomain } })
      : null;
    if (!shop?.shop_id) throw new Error("Shop not found");

    const VideoResponse = await prisma.videos.create({
      data: {
        video_shop_id: shop.shop_id,
        video_url: full_best, // default/main video (full length)
        video_url_480p: full_480,
        video_url_720p: full_720,
        video_url_1080p: full_1080,
        video_thumbnail_url: imageSrc,
        video_url_preview: preview_url,
        updated_at: new Date(),
      },
    });

    const VideoId = VideoResponse.video_id;
    await prisma.reels_Products.create({
      data: {
        reel_video_id: VideoId,
        reel_product_id: JSON.parse(product)[0]?.product_id,
      },
    });

    await prisma.reelsNStories.create({
      data: {
        video_title: JSON.parse(product)[0]?.product_name,
        video_url_id: VideoId,
        video_type: "REEL",
        video_likes_count: 0,
        video_view_count: 0,
        updated_at: new Date(),
      },
    });

    return json({
      success: true,
      message: "Full video uploaded; preview trimmed to 3s",
      urls: {
        full_480,
        full_720,
        full_1080,
        preview_url,
        thumbnail: imageSrc,
      },
    });
  } catch (error: any) {
    console.error("Error uploading reel:", error);
    return json(
      { success: false, message: String(error?.message || error) },
      { status: 500 },
    );
  } finally {
    // cleanup temp preview dir
    try {
      if (tmpDirForCleanup) {
        const fs = await import("node:fs/promises");
        const fssync = await import("node:fs");
        const path = await import("node:path");
        if (fssync.existsSync(tmpDirForCleanup)) {
          const files = await fs.readdir(tmpDirForCleanup);
          await Promise.allSettled(
            files.map((f) =>
              fs.rm(path.join(tmpDirForCleanup!, f), { force: true }),
            ),
          );
          await fs.rmdir(tmpDirForCleanup);
        }
      }
      const ApiTrigger = axios.post(`${ApiKey}/video-worker/start`)
          console.log("Video Worker Triggered", ApiTrigger)
    } catch (e) {
      console.warn("Temp cleanup failed:", e);
    }
  }
};

export const loader = async ({ request }: LoaderFunctionArgs) => {
  const url = new URL(request.url);

  return json({ search: url.search });
};

export default function uploadreel() {
  const fetcher = useFetcher();

  const [isPostBack, setIsPostBack] = useState(false);

  const { search } = useLoaderData<loaderreturn>();
  const navigate = useNavigate();

  useEffect(() => {
    setIsPostBack(true);
  }, []);

  if (!isPostBack) {
    return (
      <Page fullWidth>
        <Loader />
      </Page>
    );
  }
  return (
    <Page
      backAction={{
        content: "Reels & Stories",
        onAction: () => navigate({ pathname: "/videos", search }),
      }}
      title="Reels & Stories"
      fullWidth
    >
      <Upload title="Upload Reel" search={search} />
    </Page>
  );
}
