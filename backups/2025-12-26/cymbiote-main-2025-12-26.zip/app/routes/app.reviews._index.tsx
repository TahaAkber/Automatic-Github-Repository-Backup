import {
  Button,
  ButtonGroup,
  Card,
  Combobox,
  Grid,
  Icon,
  Layout,
  Page,
} from "@shopify/polaris";
import { SearchIcon } from "@shopify/polaris-icons";
import { ArrowUpIcon, ArrowDownIcon } from "@shopify/polaris-icons";
import { ReviewCard } from "~/components/review/ReviewCard";
import Cards from "~/components/review/Card";
import {
  ActionFunctionArgs,
  json,
  LoaderFunctionArgs,
  redirect,
} from "@remix-run/node";
import { useFetcher, useLoaderData, useNavigate } from "@remix-run/react";
import dayjs from "dayjs";
import { useEffect, useState } from "react";
import { Loader } from "~/components/common/Loader";

interface LoaderData {
  search: string;
  orderItems: any[];
}

export const loader = async ({ request }: LoaderFunctionArgs) => {
  const url = new URL(request.url);
  const shopDomain = url.searchParams.get("shop");

  const shop = await prisma.shops.findFirst({
    where: {
      shop_domain: shopDomain,
    },
  });
  const orderItems = await prisma.order_Items.findMany({
    where: {
      Orders: {
        order_shop_id: shop?.shop_id,
      },
    },
    include: {
      Order_Item_Review: {
        where: {
          created_at: {
            gte: new Date("2025-01-01T00:00:00.000Z"),
            lt: new Date("2026-01-01T00:00:00.000Z"),
          },
        },
        include: {
          Review_Comments: true,
          Review_Images: true,
        },
      },
      Orders: {
        include: {
          Users: true,
        },
      },
      Product_Variants: {
        include: {
          Products: true,
        },
      },
    },
  });

  if (!shop) {
    return json({ error: "Shop not found" }, { status: 404 });
  }
  return json({ search: url.search, orderItems: orderItems });
};

export const action = async ({ request }: ActionFunctionArgs) => {
  const url = new URL(request.url);
  const shopDomain = url.searchParams.get("shop");
  const params = new URLSearchParams(url.search);
  const queryString = params.toString();
  const formData = await request.formData();

  const type = formData.get("type");
  const date = formData.get("date");
  const dateuntil = formData.get("dateUntil");
  try {
    const shop = await prisma.shops.findFirst({
      where: {
        shop_domain: shopDomain,
      },
    });

    if (!shop) {
      return json({ error: "Shop not found" }, { status: 404 });
    }

    if (type) {
      const inputYear = date ? parseInt(date as string) : 2025;

      const startDate = new Date(`${inputYear}`);
      const endDate = new Date(`${inputYear + 1}`);

      const orderItems = await prisma.order_Items.findMany({
        where: {
          Orders: {
            order_shop_id: shop?.shop_id,
          },
        },
        include: {
          Order_Item_Review: {
            where: {
              created_at: {
                gte: startDate,
                lt: endDate,
              },
            },
            include: {
              Review_Comments: true,
              Review_Images: true,
            },
          },
          Orders: {
            include: {
              Users: true,
            },
          },
          Product_Variants: {
            include: {
              Products: true,
            },
          },
        },
      });

      return json({ orderItems });
    }

    const orderId = formData.get("order_id") as string;
    const orderItemId = formData.get("order_item_id") as string;
    const redirectUrl = new URL("/app/reviews/reviewdetails", request.url);

    redirectUrl.searchParams.set("order_id", orderId);
    redirectUrl.searchParams.set("order_item_id", orderItemId);

    if (queryString) {
      const queryParams = new URLSearchParams(queryString);
      queryParams.forEach((value, key) => {
        if (key !== "order_id" && key !== "order_item_id") {
          redirectUrl.searchParams.set(key, value);
        }
      });
    }

    return redirect(redirectUrl.toString());
  } catch (error) {
    console.error("Error fetching orders from database:", error);
    throw new Response("Error fetching orders from database", {
      status: 500,
    });
  }
};

export default function Review() {
  const { search, orderItems } = useLoaderData<LoaderData>();
  const fetcher = useFetcher();
  const [isLoading, setIsLoading] = useState(true);
  const navigate = useNavigate();
  const [reviews, setreviews] = useState(orderItems);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedyear, setselectedyear] = useState({
    alias: "This Year",
    period: {
      since: new Date(Date.now()),
      until: "2025-12-31",
    },
  });

  const [currentDate, setCurrentDate] = useState(
    new Date("2025-01-01T00:00:00.000Z"),
  );

  useEffect(() => {
    if (
      fetcher.data &&
      typeof fetcher.data === "object" &&
      fetcher.data !== null &&
      Array.isArray((fetcher.data as { orderItems?: any[] }).orderItems)
    ) {
      setreviews((fetcher.data as { orderItems: any[] }).orderItems);
    }
  }, [fetcher.data]);

  const Positiveweekdays = reviews
    .filter(
      (item) =>
        item.Order_Item_Review &&
        item.Order_Item_Review.length > 0 &&
        item?.Order_Item_Review[0]?.order_item_review_rating > 2.5,
    )
    .map((item) => {
      const isoDate = item?.Order_Item_Review?.[0]?.created_at;
      return dayjs(isoDate).format("dddd");
    });

  const PositiveweekdayCount = {
    Monday: 0,
    Tuesday: 0,
    Wednesday: 0,
    Thursday: 0,
    Friday: 0,
    Saturday: 0,
    Sunday: 0,
  };

  Positiveweekdays.forEach((day) => {
    if (typeof day === "string") {
      const formattedDay = day.charAt(0).toUpperCase() + day.slice(1);
      if (PositiveweekdayCount.hasOwnProperty(formattedDay)) {
        PositiveweekdayCount[
          formattedDay as keyof typeof PositiveweekdayCount
        ]++;
      }
    }
  });

  const Positivegraphvalues = [
    PositiveweekdayCount.Monday,
    PositiveweekdayCount.Tuesday,
    PositiveweekdayCount.Wednesday,
    PositiveweekdayCount.Thursday,
    PositiveweekdayCount.Friday,
    PositiveweekdayCount.Saturday,
    PositiveweekdayCount.Sunday,
  ];

  const Negativeweekdays = reviews
    .filter(
      (item) =>
        item.Order_Item_Review &&
        item.Order_Item_Review.length > 0 &&
        item?.Order_Item_Review[0]?.order_item_review_rating <= 2.5,
    )
    .map((item) => {
      const isoDate = item?.Order_Item_Review[0]?.created_at;
      return dayjs(isoDate).format("dddd");
    });

  const NegativeweekdayCount = {
    Monday: 0,
    Tuesday: 0,
    Wednesday: 0,
    Thursday: 0,
    Friday: 0,
    Saturday: 0,
    Sunday: 0,
  };

  Negativeweekdays.forEach((day) => {
    if (typeof day === "string") {
      const formattedDay = day.charAt(0).toUpperCase() + day.slice(1);
      if (NegativeweekdayCount.hasOwnProperty(formattedDay)) {
        NegativeweekdayCount[
          formattedDay as keyof typeof NegativeweekdayCount
        ]++;
      }
    }
  });

  const Negativegraphvalues = [
    NegativeweekdayCount.Monday,
    NegativeweekdayCount.Tuesday,
    NegativeweekdayCount.Wednesday,
    NegativeweekdayCount.Thursday,
    NegativeweekdayCount.Friday,
    NegativeweekdayCount.Saturday,
    NegativeweekdayCount.Sunday,
  ];

  const totalPositive = Positivegraphvalues.reduce(
    (sum, item) => sum + item,
    0,
  );
  const totalNegative = Negativegraphvalues.reduce(
    (sum, item) => sum + item,
    0,
  );
  const totalReviews = totalPositive + totalNegative;

  const positivePercentage =
    totalReviews > 0 ? ((totalPositive / totalReviews) * 100).toFixed(2) : "0";
  const negativePercentage =
    totalReviews > 0 ? ((totalNegative / totalReviews) * 100).toFixed(2) : "0";

  const HandleSingleCard = (order_id: number, order_item_id: number) => {
    const formdata = new FormData();
    formdata.append("order_id", order_id.toString());
    formdata.append("order_item_id", order_item_id.toString());
    fetcher.submit(formdata, {
      method: "POST",
      encType: "multipart/form-data",
    });
  };

  useEffect(() => {
    setIsLoading(false);
  }, []);

  const searchProductReviews = async () => {
    try {
      const response = await fetch(
        `/api/searchReviews?searchQuery=${searchQuery}&searchTerm=${search}`,
      );
      const data = await response.json();
      setreviews(data);
    } catch (error: any) {
      console.log("error while fetching products", error.message);
    }
  };

  useEffect(() => {
    searchProductReviews();
  }, [searchQuery, search]);

  if (isLoading) {
    return (
      <Page fullWidth>
        <Loader />
      </Page>
    );
  }

  const handleDateFilter = (type: string, date: string, dateUntil: string) => {
    const parsedDate = new Date(date);
    setCurrentDate(parsedDate); // this keeps both cards in sync

    const formdata = new FormData();
    formdata.append("type", type);
    formdata.append("date", date);
    formdata.append("dateUntil", dateUntil);
    fetcher.submit(formdata, {
      method: "POST",
      encType: "multipart/form-data",
    });
  };

  return (
    <Page title="Reviews" fullWidth>
      <Layout>
        <Layout.Section>
          <Grid>
            <Grid.Cell columnSpan={{ xs: 6, sm: 6, md: 6, lg: 6 }}>
              <ReviewCard
                title="Positive Review"
                date={dayjs(currentDate).format("MMMM D, YYYY")}
                handleDateFilter={handleDateFilter}
                ArrowIcon={ArrowUpIcon}
                type="positive"
                rate={totalPositive}
                percentage={Number(positivePercentage)}
                graphvalues={Positivegraphvalues}
                setselectedyear={setselectedyear}
                selectedyear={selectedyear}
              />
            </Grid.Cell>
            <Grid.Cell columnSpan={{ xs: 6, sm: 6, md: 6, lg: 6 }}>
              <ReviewCard
                title="Negative Review"
                date={dayjs(currentDate).format("MMMM D, YYYY")}
                handleDateFilter={handleDateFilter}
                ArrowIcon={ArrowDownIcon}
                type="negative"
                rate={totalNegative}
                percentage={Number(negativePercentage)}
                graphvalues={Negativegraphvalues}
                setselectedyear={setselectedyear}
                selectedyear={selectedyear}
              />
            </Grid.Cell>
          </Grid>
        </Layout.Section>

        <Layout.Section>
          <Grid>
            <Grid.Cell columnSpan={{ xs: 5, sm: 5, md: 6, lg: 11 }}>
              <Combobox
                activator={
                  <Combobox.TextField
                    prefix={<Icon source={SearchIcon} />}
                    label="Search Products"
                    labelHidden
                    placeholder="Search Products"
                    autoComplete="off"
                    value={searchQuery}
                    onChange={(value) => setSearchQuery(value)}
                  />
                }
              />
            </Grid.Cell>
            <Grid.Cell columnSpan={{ sm: 1, md: 3, lg: 1 }}>
              <ButtonGroup>
                <Button icon={SearchIcon} size="large" />
              </ButtonGroup>
            </Grid.Cell>
          </Grid>
        </Layout.Section>

        <Layout.Section>
          <Grid>
            {reviews
              .filter(
                (item) =>
                  item.Order_Item_Review && item.Order_Item_Review.length > 0,
              )
              .map((item) => (
                <Grid.Cell
                  key={item.id}
                  columnSpan={{ xs: 6, sm: 6, md: 4, lg: 3 }}
                >
                  <Card>
                    <div
                      onClick={() => {
                        HandleSingleCard(item.order_id, item.order_item_id);
                      }}
                      style={{
                        cursor: "pointer",
                      }}
                    >
                      <Cards
                        item={item}
                        orders={item.Orders}
                        orderItemReview={item.Order_Item_Review || []}
                        product={item?.Product_Variants?.Products}
                      />
                    </div>
                  </Card>
                </Grid.Cell>
              ))}
          </Grid>
        </Layout.Section>
      </Layout>
    </Page>
  );
}
