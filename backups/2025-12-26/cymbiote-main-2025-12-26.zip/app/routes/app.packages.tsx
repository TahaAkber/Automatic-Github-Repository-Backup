import { useState, useEffect } from "react";
import {
  Page,
  Layout,
  Card,
  Text,
  InlineGrid,
  Frame,
  BlockStack,
  Divider,
} from "@shopify/polaris";
import {
  ActionFunctionArgs,
  json,
  redirect,
  TypedResponse,
} from "@remix-run/node";
import { authenticate } from "~/shopify.server";
import { useActionData, useLoaderData, useSubmit } from "@remix-run/react";
import { PACKAGE } from "~/types/Package";
import SubCard from "~/components/subscription/SubCard";
import SubscriptionConfirmationModal from "~/components/subscription/SubscriptionConfirmationModal";
import {
  createAppSubscription,
  createOneTimeVideoCharge,
} from "~/mutations/appSubscription";
import { getCurrentCurrencyRate } from "~/functions/common";
import { fetchAppInstallation } from "~/queries/App";

export const loader = async ({ request }: any): Promise<TypedResponse<any>> => {
  const APP_URL = process.env.ENV_URL;
  const EXCHANGE_RATE_API_URL = process.env.EXCHANGE_RATE_API_URL;
  const EXCHANGE_RATE_API_KEY = process.env.EXCHANGE_RATE_API_KEY;
  const { admin } = await authenticate.admin(request);
  const url = new URL(request.url);
  const params = new URLSearchParams(url.search);
  const queryString = params.toString();
  const redirectUrl = `/app?${queryString}`;
  const shopDomain = url.searchParams.get("shop");
  const charge_id = url.searchParams.get("charge_id");
  let tileDetails: any = null;
  // console.log("shopDomain subscriptions", shopDomain, url);

  try {
    const packages = await prisma.packages.findMany();

    const subscription = await prisma.subscriptions.findFirst({
      where: {
        Shops: {
          shop_domain: shopDomain,
        },
        subscription_confirmed: true,
        subscription_enabled: true,
      },
      include: {
        Shops: true,
      },
    });

    if (subscription?.Shops.shop_tile_subscribed) {
      tileDetails = await prisma.shop_Tiles.findFirst({
        where: {
          shop_tile_id: subscription.Shops.shop_tile_type,
        },
      });
    }

    const adminSettings = await prisma.admin_Settings.findFirst();
    const reelCharges = adminSettings?.admin_reelNstory_charges || 0;

    console.log("charge_id received", charge_id);

    const video_topup = url.searchParams.get("video_topup");
    const quota = url.searchParams.get("quota");
    const amount = url.searchParams.get("amount");

    if (video_topup === "true" && quota && amount && charge_id) {
      const existingSubscription = await prisma.subscriptions.findFirst({
        where: {
          Shops: {
            shop_domain: shopDomain,
          },
          subscription_confirmed: true,
          subscription_enabled: true,
        },
      });

      if (existingSubscription) {
        // Update subscription quota and extra charges
        await prisma.subscriptions.update({
          where: { subscription_id: existingSubscription.subscription_id },
          data: {
            subscription_videos_quota: {
              increment: parseInt(quota),
            },
            subscription_extra_video_charges: {
              increment: parseFloat(amount),
            },
          },
        });

        // Log transaction
        await prisma.transactions.create({
          data: {
            transaction_amount_usd: parseFloat(amount),
            transaction_amount:
              parseFloat(amount) *
              (await getCurrentCurrencyRate(
                "USD",
                "PKR",
                EXCHANGE_RATE_API_URL,
                EXCHANGE_RATE_API_KEY,
              )), // Approximate conversion if needed, or fetch fresh
            transaction_detail: `One-time purchase: ${quota} Extra Reels/Stories`,
            transaction_shop_id: existingSubscription.subscription_shop_id,
            transaction_subscription_id: existingSubscription.subscription_id,
            transaction_type: "one_time",
            transaction_kind: "top-up",
            transaction_currency: subscription?.Shops.shop_currency,
            created_date: new Date(),
          },
        });

        return redirect(redirectUrl);
      }
    }

    if (charge_id) {
      const existingSubscription = await prisma.subscriptions.findFirst({
        where: {
          Shops: {
            shop_domain: shopDomain,
          },
          subscription_confirmation_id: charge_id,
        },
      });
      console.log(
        "Pending subscription to update:",
        charge_id,
        existingSubscription,
      );

      const { activeSubscriptions } = await fetchAppInstallation(admin);

      if (!activeSubscriptions) {
        console.error("No installed app found");
        return redirect(redirectUrl);
      }

      // const skipSubscriptionId = existingSubscription?.subscription_id;

      const previousSubscriptions = await prisma.subscriptions.findMany({
        where: {
          Shops: {
            shop_domain: shopDomain,
          },
          subscription_confirmation_id: {
            not: charge_id,
          },
          subscription_enabled: true,
          subscription_confirmed: true,
        },
      });

      if (previousSubscriptions.length > 0) {
        await Promise.all(
          previousSubscriptions.map((sub) =>
            prisma.subscriptions.update({
              where: { subscription_id: sub.subscription_id },
              data: {
                subscription_enabled: false,
                subscription_ends_at: new Date(),
              },
            }),
          ),
        );
      }

      if (existingSubscription) {
        const subUpdate = await prisma.subscriptions.update({
          data: {
            subscription_confirmed: true,
            subscription_enabled: true,
            subscription_charge_date: new Date(),
            subscription_ends_at:
              activeSubscriptions[0]?.currentPeriodEnd || new Date(),
          },
          where: {
            subscription_id: existingSubscription.subscription_id,
          },
          select: {
            Shops: {
              select: {
                shop_id: true,
              },
            },
            Packages: true,
          },
        });

        const shop = await prisma.shops.findFirst({
          where: {
            shop_domain: shopDomain,
            shop_id: subUpdate.Shops.shop_id,
          },
        });

        const currencyRate = await getCurrentCurrencyRate(
          "USD",
          shop?.shop_currency || "PKR",
          EXCHANGE_RATE_API_URL,
          EXCHANGE_RATE_API_KEY,
        );

        let package_charges = subUpdate.Packages.package_charges;

        if (shop && shop?.shop_tile_subscribed) {
          const tile = await prisma.shop_Tiles.findFirst({
            where: { shop_tile_id: shop.shop_tile_type },
          });

          if (tile) {
            package_charges += tile.shop_tile_charges;
          }
        }

        if (shop && shop.shop_active_tracking) {
          const adminSettings = await prisma.admin_Settings.findFirst();

          if (adminSettings) {
            package_charges += adminSettings.admin_tracking_sub_charges;
          }
        }

        const subscriptionConvertedAmount = currencyRate * package_charges;

        console.log(
          "package_charges:",
          package_charges,
          subscriptionConvertedAmount,
        );

        await prisma.transactions.create({
          data: {
            transaction_amount_usd: package_charges,
            transaction_amount: subscriptionConvertedAmount,
            transaction_detail:
              `Subscribed ${subUpdate?.Packages.package_name}` +
              `${shop?.shop_tile_subscribed ? ` with tile subscription` : ``}${shop?.shop_active_tracking ? ` and with tracking subscription` : ``}`,
            transaction_shop_id: subUpdate.Shops.shop_id,
            transaction_subscription_id: existingSubscription.subscription_id,
            transaction_type: "subscription",
            transaction_kind: "recurring",
            transaction_currency: shop?.shop_currency || "PKR",
            created_date: new Date(),
          },
        });

        console.log("Subscription charge id updated");

        // Now, register the webhook for inventory level changes
        const inventoryWebhookMutation = `mutation webhookSubscriptionCreate {
          webhookSubscriptionCreate(
            topic: INVENTORY_LEVELS_UPDATE
            webhookSubscription: {callbackUrl: "${APP_URL}/webhook/inventory-update", format: JSON}
          ) {
            userErrors {
              field
              message
            }
            webhookSubscription {
              id
            }
          }
        }`;

        const cancelWebhookMutation = `mutation webhookSubscriptionCreate {
          webhookSubscriptionCreate(
            topic: ORDERS_CANCELLED
            webhookSubscription: {callbackUrl: "${APP_URL}/webhook/cancel-order", format: JSON}
          ) {
            userErrors {
              field
              message
            }
            webhookSubscription {
              id
            }
          }
        }`;

        const fulfillmentCreateWebhookMutation = `mutation webhookSubscriptionCreate {
          webhookSubscriptionCreate(
            topic: FULFILLMENTS_CREATE
            webhookSubscription: {callbackUrl: "${APP_URL}/webhook/capture-fulfillment", format: JSON}
          ) {
            userErrors {
              field
              message
            }
            webhookSubscription {
              id
            }
          }
        }`;

        const createOrderWebhookMutation = `
          mutation webhookSubscriptionCreate {
            webhookSubscriptionCreate(
              topic: ORDERS_CREATE
              webhookSubscription: {callbackUrl: "${APP_URL}/webhook/capture-order", format: JSON}
            ) {
              userErrors {
                field
                message
              }
              webhookSubscription {
                id
              }
            }
          }
        `;

        const fulfillmentUpdateWebhookMutation = `
          mutation webhookSubscriptionCreate {
            webhookSubscriptionCreate(
              topic: FULFILLMENTS_UPDATE
              webhookSubscription: {callbackUrl: "${APP_URL}/webhook/update-fulfillment", format: JSON}
            ) {
              userErrors {
                field
                message
              }
              webhookSubscription {
                id
              }
            }
          }
        `;

        const createCollectionWebhookMutation = `
          mutation webhookSubscriptionCreate {
            webhookSubscriptionCreate(
              topic: COLLECTIONS_CREATE
              webhookSubscription: {callbackUrl: "${APP_URL}/webhook/collection-create", format: JSON}
            ) {
              userErrors {
                field
                message
              }
              webhookSubscription {
                id
              }
            }
          }
        `;

        const updateCollectionWebhookMutation = `
          mutation webhookSubscriptionCreate {
            webhookSubscriptionCreate(
              topic: COLLECTIONS_UPDATE
              webhookSubscription: {callbackUrl: "${APP_URL}/webhook/collection-update", format: JSON}
            ) {
              userErrors {
                field
                message
              }
              webhookSubscription {
                id
              }
            }
          }
        `;

        const deleteCollectionWebhookMutation = `
          mutation webhookSubscriptionCreate {
            webhookSubscriptionCreate(
              topic: COLLECTIONS_DELETE
              webhookSubscription: {callbackUrl: "${APP_URL}/webhook/collection-delete", format: JSON}
            ) {
              userErrors {
                field
                message
              }
              webhookSubscription {
                id
              }
            }
          }
        `;

        const productUpdateWebhookMutation = `
          mutation webhookSubscriptionCreate {
            webhookSubscriptionCreate(
              topic: PRODUCTS_UPDATE
              webhookSubscription: {callbackUrl: "${APP_URL}/webhook/products-update", format: JSON}
            ) {
              userErrors {
                field
                message
              }
              webhookSubscription {
                id
              }
            }
          }
        `;

        let webhookRequest = await admin.graphql(inventoryWebhookMutation);
        const inventoryWebhookResponse = await webhookRequest.json();

        webhookRequest = await admin.graphql(cancelWebhookMutation);
        const orderCancelWebhookResponse = await webhookRequest.json();

        webhookRequest = await admin.graphql(fulfillmentCreateWebhookMutation);
        const fulfillmentCreateWebhookResponse = await webhookRequest.json();

        webhookRequest = await admin.graphql(createOrderWebhookMutation);
        const orderCreateWebhookResponse = await webhookRequest.json();

        webhookRequest = await admin.graphql(productUpdateWebhookMutation);
        const productUpdateWebhookResponse = await webhookRequest.json();

        webhookRequest = await admin.graphql(createCollectionWebhookMutation);
        const createCollectionWebhookResponse = await webhookRequest.json();

        webhookRequest = await admin.graphql(updateCollectionWebhookMutation);
        const updateCollectionWebhookResponse = await webhookRequest.json();

        webhookRequest = await admin.graphql(deleteCollectionWebhookMutation);
        const deleteCollectionWebhookResponse = await webhookRequest.json();

        webhookRequest = await admin.graphql(fulfillmentUpdateWebhookMutation);
        const fulfillmentUpdateWebhookResponse = await webhookRequest.json();

        if (
          inventoryWebhookResponse.data.webhookSubscriptionCreate.userErrors
            .length > 0 &&
          orderCancelWebhookResponse.data.webhookSubscriptionCreate.userErrors
            .length > 0 &&
          fulfillmentCreateWebhookResponse.data.webhookSubscriptionCreate
            .userErrors.length > 0 &&
          orderCreateWebhookResponse.data.webhookSubscriptionCreate.userErrors
            .length > 0 &&
          productUpdateWebhookResponse.data.webhookSubscriptionCreate.userErrors
            .length > 0 &&
          createCollectionWebhookResponse.data.webhookSubscriptionCreate
            .userErrors.length > 0 &&
          updateCollectionWebhookResponse.data.webhookSubscriptionCreate
            .userErrors.length > 0 &&
          deleteCollectionWebhookResponse.data.webhookSubscriptionCreate
            .userErrors.length > 0 &&
          fulfillmentUpdateWebhookResponse.data.webhookSubscriptionCreate
            .userErrors.length > 0
        ) {
          console.error(
            "Error creating webhooks:",
            inventoryWebhookResponse.data.webhookSubscriptionCreate.userErrors,
            orderCancelWebhookResponse.data.webhookSubscriptionCreate
              .userErrors,
            fulfillmentCreateWebhookResponse.data.webhookSubscriptionCreate
              .userErrors,
            orderCreateWebhookResponse.data.webhookSubscriptionCreate
              .userErrors,
            productUpdateWebhookResponse.data.webhookSubscriptionCreate
              .userErrors,
            createCollectionWebhookResponse.data.webhookSubscriptionCreate
              .userErrors,
            updateCollectionWebhookResponse.data.webhookSubscriptionCreate
              .userErrors,
            deleteCollectionWebhookResponse.data.webhookSubscriptionCreate
              .userErrors,
            fulfillmentUpdateWebhookResponse.data.webhookSubscriptionCreate
              .userErrors,
          );
          return redirect(redirectUrl);
        }

        const updateData: Record<string, any> = {};

        if (
          inventoryWebhookResponse.data?.webhookSubscriptionCreate
            ?.webhookSubscription?.id
        ) {
          updateData.shop_inventory_update_webhook_id =
            inventoryWebhookResponse.data.webhookSubscriptionCreate.webhookSubscription.id;
        }

        if (
          orderCancelWebhookResponse.data?.webhookSubscriptionCreate
            ?.webhookSubscription?.id
        ) {
          updateData.shop_order_cancellation_webhook_id =
            orderCancelWebhookResponse.data.webhookSubscriptionCreate.webhookSubscription.id;
        }

        if (
          fulfillmentCreateWebhookResponse.data?.webhookSubscriptionCreate
            ?.webhookSubscription?.id
        ) {
          updateData.shop_fulfillment_create_webhook_id =
            fulfillmentCreateWebhookResponse.data.webhookSubscriptionCreate.webhookSubscription.id;
        }

        if (
          fulfillmentUpdateWebhookResponse.data?.webhookSubscriptionCreate
            ?.webhookSubscription?.id
        ) {
          updateData.shop_fulfillment_update_webhook_id =
            fulfillmentUpdateWebhookResponse.data.webhookSubscriptionCreate.webhookSubscription.id;
        }

        if (
          orderCreateWebhookResponse.data?.webhookSubscriptionCreate
            ?.webhookSubscription?.id
        ) {
          updateData.shop_order_create_webhook_id =
            orderCreateWebhookResponse.data.webhookSubscriptionCreate.webhookSubscription.id;
        }

        if (
          productUpdateWebhookResponse.data?.webhookSubscriptionCreate
            ?.webhookSubscription?.id
        ) {
          updateData.shop_product_update_webhook_id =
            productUpdateWebhookResponse.data.webhookSubscriptionCreate.webhookSubscription.id;
        }
        if (
          createCollectionWebhookResponse.data?.webhookSubscriptionCreate
            ?.webhookSubscription?.id
        ) {
          updateData.shop_collection_create_webhook_id =
            createCollectionWebhookResponse.data.webhookSubscriptionCreate.webhookSubscription.id;
        }
        if (
          updateCollectionWebhookResponse.data?.webhookSubscriptionCreate
            ?.webhookSubscription?.id
        ) {
          updateData.shop_collection_update_webhook_id =
            updateCollectionWebhookResponse.data.webhookSubscriptionCreate.webhookSubscription.id;
        }

        if (
          deleteCollectionWebhookResponse.data?.webhookSubscriptionCreate
            ?.webhookSubscription?.id
        ) {
          updateData.shop_collection_delete_webhook_id =
            deleteCollectionWebhookResponse.data.webhookSubscriptionCreate.webhookSubscription.id;
        }
        // Only perform the update if there is data to update

        if (Object.keys(updateData).length > 0) {
          const updateShop = await prisma.shops.update({
            data: { ...updateData, updated_at: new Date() },
            where: {
              shop_id: subUpdate.Shops.shop_id,
            },
          });

          console.log("Shop updated successfully:", updateShop);
        } else {
          console.log(
            "No valid webhook IDs were returned, skipping shop update.",
          );
        }
      }

      return redirect(redirectUrl);
    }

    // If subscription does not exist or is not active, do nothing and return packages
    return json({
      search: url.search,
      packages,
      subscription,
      tileSubscriptionEnabled:
        subscription?.Shops.shop_tile_subscribed || false,
      tileCharges: tileDetails ? tileDetails.shop_tile_charges : 0,
      reelCharges,
      trackingCharges: adminSettings?.admin_tracking_sub_charges || 0,
    });
  } catch (error) {
    console.error("Error in subscription loader", error);
    throw new Response("Error in subscription loader", {
      status: 500,
    });
  }
};

export const action = async ({ request }: ActionFunctionArgs): Promise<any> => {
  const APP_ON_TEST = process.env.APP_ON_TEST === "true";
  console.log("APP_ON_TEST in action", APP_ON_TEST);
  const { admin } = await authenticate.admin(request);

  const url = new URL(request.url);
  // console.log("Params", url);
  const shopDomain = url.searchParams.get("shop");

  const formData = await request.formData();

  const packageName = formData.get("packageName") as string;
  const packagePrice = formData.get("packagePrice") as string;
  const packageRate = formData.get("packageRate") as string;
  const packageId = formData.get("packageId") as string;
  const alreadySubscribed = formData.get("alreadySubscribed") as string;
  const trialDays = formData.get("trialDays")?.toString();
  // console.log("trialDays", trialDays);

  const extraQuota = formData.get("extraQuota")?.toString();
  const extraCharges = formData.get("extraCharges")?.toString();
  const intent = formData.get("intent")?.toString();

  try {
    if (intent === "top_up") {
      const response = await createOneTimeVideoCharge(
        admin,
        shopDomain as string,
        extraCharges ? parseFloat(extraCharges) : 0,
        extraQuota ? parseInt(extraQuota) : 0,
        APP_ON_TEST,
      );
      return response;
    }

    const shop = await prisma.shops.findFirst({
      where: { shop_domain: shopDomain },
    });

    const subscriptionReponse = await createAppSubscription(
      admin,
      prisma,
      shopDomain as string,
      packageName,
      packagePrice,
      packageRate,
      packageId,
      alreadySubscribed === "true" ? false : true,
      undefined,
      undefined,
      undefined,
      trialDays ? (alreadySubscribed === "true" ? 0 : parseInt(trialDays)) : 0,
      APP_ON_TEST,
      extraQuota ? parseInt(extraQuota) : 0,
      extraCharges ? parseFloat(extraCharges) : 0,
    );
    console.log("subscriptionReponse", subscriptionReponse);
    //email and currency

    // console.log("updatedshop", updatedshop);
    return subscriptionReponse;
    // console.log("didnt stop", subscriptionReponse);
  } catch (error) {
    console.error("Error creating subscription:", error);
    throw new Response("Error creating subscription", {
      status: 500,
    });
  }
};

export default function SubscriptionPage() {
  const {
    packages,
    subscription,
    tileCharges,
    tileSubscriptionEnabled,
    reelCharges,
    trackingCharges,
  } = useLoaderData<any>();
  const submit = useSubmit();
  const actionData = useActionData<typeof action>();
  const [loading, setLoading] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState<PACKAGE | undefined>();

  // State for showing/hiding the modal
  const [active, setActive] = useState(false);

  // Toggle the modal visibility
  const handleModalChange = () => setActive(!active);

  // Function for when the user clicks "Yes" in the modal
  const handleConfirmChangePlan = () => {
    handleSubmit();
    handleModalChange();
  };

  const isTopUp =
    subscription?.subscription_package_id === selectedPlan?.package_id &&
    (selectedPlan?.extraQuota || 0) > 0;

  const handlePlanChange = (value: PACKAGE) => {
    setSelectedPlan(value);
  };

  const handleSubmit = () => {
    if (!selectedPlan) {
      console.log("No plan selected");
    }
    console.log(`Selected Plan formData: ${selectedPlan?.package_id}`);
    const formData = new FormData();

    if (
      selectedPlan?.package_id !== undefined &&
      selectedPlan.package_id !== null
    ) {
      const packagePriceValue = selectedPlan.package_charges.toString();
      formData.append("packageName", selectedPlan.package_name);
      formData.append("packagePrice", packagePriceValue);
      formData.append("packageRate", selectedPlan.package_rate.toString());
      formData.append("packageId", selectedPlan.package_id.toString());
      formData.append("trialDays", selectedPlan.package_trial_days.toString());

      if (isTopUp) {
        formData.append("intent", "top_up");
        formData.append("alreadySubscribed", "true"); // Just in case
      } else {
        formData.append("alreadySubscribed", subscription ? "true" : "false");
      }
      // Append extra quota and charges if available in selectedPlan (logic to be added in SubCard/here)
      // For now, we just pass the base values. The extra values will be handled by SubCard updating selectedPlan or separate state.
      // Actually, SubCard should update the selectedPlan with extra charges/quota or we need a way to pass it back.
      // Let's assume SubCard updates the plan object or we use a separate state for extras.
      // Given the current structure, let's pass reelCharges to SubCard first.

      if (selectedPlan.extraQuota) {
        formData.append("extraQuota", selectedPlan.extraQuota.toString());
      }
      if (selectedPlan.extraCharges) {
        formData.append("extraCharges", selectedPlan.extraCharges.toString());
      }

      submit(formData, { method: "POST" });
      setLoading(true);
    } else {
      console.error("Invalid plan selected");
      return;
    }
  };

  useEffect(() => {
    console.log("actionData changed:", actionData);
    if (actionData?.confirmationUrl) {
      console.log("Redirecting to:", actionData.confirmationUrl);
      window.open(actionData.confirmationUrl, "_top");
    } else {
      console.log("No confirmationUrl in actionData");
    }
  }, [actionData]);

  console.log("Current selected plan:", selectedPlan);

  return (
    <Frame>
      <Page title="Choose Your Subscription Plan">
        <Layout>
          <Layout.Section variant="fullWidth">
            <Card>
              <BlockStack gap="400">
                <Text as="h3" fontWeight="medium" variant="headingMd">
                  Subscription Plans
                </Text>
                <InlineGrid gap={"400"} columns={3}>
                  {packages.length > 0 ? (
                    packages.map((e: PACKAGE, i: number) => {
                      const active =
                        subscription?.subscription_package_id === e.package_id
                          ? true
                          : false;
                      return (
                        <SubCard
                          handleModalChange={handleModalChange}
                          handlePlanChange={handlePlanChange}
                          plan={e}
                          loading={loading}
                          selectedPlan={selectedPlan}
                          planNumber={i + 1}
                          active={active}
                          key={"subcard" + i}
                          reelCharges={reelCharges}
                        />
                      );
                    })
                  ) : (
                    <Card>
                      <Text as="p">No Packages Available</Text>
                    </Card>
                  )}
                </InlineGrid>
              </BlockStack>
            </Card>
          </Layout.Section>

          {/* <Layout.Section>
            <Card>
              <TextContainer>
                <Text as="h3">
                  You selected the <strong>{selectedPlan?.package_name}</strong>{" "}
                  plan.
                </Text>
              </TextContainer>
              <Button onClick={handleModalChange}>Confirm and Subscribe</Button>
            </Card>
          </Layout.Section> */}
        </Layout>

        {/* Modal for confirming plan change */}
        <SubscriptionConfirmationModal
          active={active}
          handleModalChange={handleModalChange}
          handleConfirmChangePlan={handleConfirmChangePlan}
          selectedPlan={selectedPlan}
          tileSubscriptionEnabled={tileSubscriptionEnabled}
          tileCharges={tileCharges}
          trackingEnabled={subscription?.Shops?.shop_active_tracking}
          trackingCharges={trackingCharges}
          isTopUp={isTopUp}
        />
      </Page>
    </Frame>
  );
}
