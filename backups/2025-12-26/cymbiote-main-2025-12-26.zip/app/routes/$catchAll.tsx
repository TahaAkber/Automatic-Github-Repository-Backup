import NotFoundPage from "../components/common/404"; // Your custom 404 page

export default function CatchAllRoute() {
  return <NotFoundPage />;
}
