import {
  Button,
  ButtonGroup,
  Card,
  ChoiceList,
  Combobox,
  Divider,
  Grid,
  Icon,
  Layout,
  Page,
  Text,
  TextField,
} from "@shopify/polaris";
import {
  useFetcher,
  useLoaderData,
  useLocation,
  useNavigate,
  useSubmit,
} from "@remix-run/react";
import { ChatIcon, SearchIcon } from "@shopify/polaris-icons";
import { ReviewCard } from "~/components/review/ReviewCard";
import Cards from "~/components/review/Card";
import StarRating from "~/components/review/StarRating";
import { useCallback, useEffect, useState } from "react";
import { SendIcon } from "@shopify/polaris-icons";
import { authenticate } from "~/shopify.server";
import {
  ActionFunctionArgs,
  json,
  LoaderFunctionArgs,
  TypedResponse,
} from "@remix-run/node";
import { c } from "node_modules/vite/dist/node/types.d-aGj9QkWt";
<Icon source={ChatIcon} tone="base" />;

interface ReviewInfoLoaderReturn {
  search: string;
  orderItems: any[];
  shop: any;
}

export const loader = async ({
  request,
}: LoaderFunctionArgs): Promise<
  TypedResponse<ReviewInfoLoaderReturn | { error: string }>
> => {
  const { admin } = await authenticate.admin(request);

  const url = new URL(request.url);
  const shopDomain = url.searchParams.get("shop");
  const params = new URLSearchParams(url.search);

  const orderId = params.get("order_id");
  const orderItemId = params.get("order_item_id");

  const queryString = params.toString();

  const shop = await prisma.shops.findFirst({
    where: {
      shop_domain: shopDomain,
    },
  });

  if (!shop) {
    return json({ error: "Shop not found" }, { status: 404 });
  }
  const orderItems = await prisma.order_Items.findFirst({
    where: {
      order_id: Number(orderId),
      order_item_id: Number(orderItemId),
    },
    include: {
      Order_Item_Review: {
        include: {
          Review_Comments: true,
          Review_Images: true,
        },
      },
      Orders: {
        include: {
          Users: true,
        },
      },
      Product_Variants: {
        include: {
          Products: true,
        },
      },
    },
  });

  return json({
    search: url.search,
    orderItems: [orderItems],
    shop: shop,
  });
};

export const action = async ({ request }: ActionFunctionArgs) => {
  try {
    const formData = await request.formData();
    const { admin } = await authenticate.admin(request);

    const url = new URL(request.url);
    const shopDomain = url.searchParams.get("shop");
    const params = new URLSearchParams(url.search);
    const orderId = params.get("order_id");
    const orderItemId = params.get("order_item_id");
    const queryString = params.toString();
    const ParentId = formData.get("parentId") as string;
    const Comment = formData.get("comment") as string;
    const ReportType = formData.get("ReportType") as string;
    const report_comment = formData.get("report_comment") as string;

    const order_item_review_comment = formData.get(
      "order_item_review_comment",
    ) as string;

    const shop = await prisma.shops.findFirst({
      where: {
        shop_domain: shopDomain,
      },
    });

    if (!shop) {
      return json({ error: "Shop not found" }, { status: 404 });
    }

    const orderItems = await prisma.order_Items.findFirst({
      where: {
        order_id: Number(orderId),
        order_item_id: Number(orderItemId),
      },
      include: {
        Order_Item_Review: {
          include: {
            Review_Comments: true,
            Review_Images: true,
          },
        },
        Orders: {
          include: {
            Users: true,
          },
        },
        Product_Variants: {
          include: {
            Products: true,
          },
        },
      },
    });

    if (ReportType && !report_comment) {
      const response = await prisma.merchant_Reported_Reviews.create({
        data: {
          reported_review_id:
            orderItems?.Order_Item_Review[0]?.order_item_review_id ?? 0,
          reported_shop_id: shop?.shop_id ?? 0,
          reported_type: ReportType,
        },
      });
      console.log("Reported Type ", response);
    } else if (report_comment && ReportType) {
      const response = await prisma.merchant_Reported_Reviews.create({
        data: {
          reported_review_id:
            orderItems?.Order_Item_Review[0]?.order_item_review_id ?? 0,
          reported_shop_id: shop?.shop_id ?? 0,
          reported_type: ReportType,
          reported_comment: report_comment,
        },
      });
      console.log("Reported Comment ", response);
    }

    if (ParentId && Comment) {
      const response = await prisma.review_Comments.create({
        data: {
          review_id:
            orderItems?.Order_Item_Review[0]?.order_item_review_id ?? 0,
          commenter_type: "shop",
          parent_comment_id: Number(ParentId),
          commenter_id: shop?.shop_id ?? 0,
          comment_text: Comment,
        },
      });
    }
    if (order_item_review_comment) {
      const response = await prisma.review_Comments.create({
        data: {
          review_id:
            orderItems?.Order_Item_Review[0]?.order_item_review_id ?? 0,
          commenter_type: "shop",
          commenter_id: shop?.shop_id ?? 0,
          comment_text: order_item_review_comment,
        },
      });
      console.log("Response", response);
    }
    return json({ success: true, search: url.search });
  } catch (e) {
    console.log("Error in action", e);
  }
};
export default function ReviewDetails() {
  const navigate = useNavigate();
  const fetcher = useFetcher();
  const { search, orderItems, shop } = useLoaderData<ReviewInfoLoaderReturn>();
  const [isreportactive, setisreportactive] = useState(false);
  const [selected, setSelected] = useState<string[]>(["hidden"]);
  const [value, setValue] = useState("");
  const [openReplies, setOpenReplies] = useState<{ [key: string]: boolean }>(
    {},
  );
  const [isSendloading, setisSendloading] = useState(false);
  const [isReportloading, setisReportloading] = useState(false);
  const [selectedParentId, setSelectedParentId] = useState<string | null>(null);
  const [replyText, setReplyText] = useState("");
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);

  const handleReplyChange = (value: string) => setReplyText(value);

  const handleChoiceChange = useCallback((value: string[]) => {
    setSelected(value);
  }, []);

  const handlereport = () => {
    const formdata = new FormData();
    const selectedChoice = choices.find(
      (choice) => choice.value === selected[0],
    );
    console.log("Selected choice label", selectedChoice?.label);
    if (selectedChoice?.label === "Other") {
      formdata.append("ReportType", selectedChoice.label);
      formdata.append("report_comment", value);
    } else {
      if (selectedChoice?.label) {
        formdata.append("ReportType", selectedChoice.label);
      }
    }
    fetcher.submit(formdata, {
      method: "post",
      encType: "multipart/form-data",
    });
    setisReportloading(false);
    setisSendloading(true);
    setValue("");
  };

  const handleChange = useCallback((newValue: string) => {
    setValue(newValue);
  }, []);

  const choices = [
    { label: "Spam of Advertising", value: "1" },
    { label: "Offensive or Abusive Language", value: "2" },
    { label: "Fake or Misleading Review", value: "3" },
    { label: "Harassment or Threats", value: "4" },
    { label: "Privacy Violation", value: "5" },
    { label: "Intellectual Property Infringement", value: "6" },
    { label: "Off-Topic/Irrelevant Content", value: "7" },
    { label: "Other", value: "9" },
  ];

  const ReviewData = orderItems
    .filter(
      (item) => item.Order_Item_Review && item.Order_Item_Review.length > 0,
    )
    .map((item) => ({
      item,
      orders: item.Orders,
      orderItemReview: item.Order_Item_Review || [],
      product: item?.Product_Variants?.Products,
    }));

  const toggleReplies = (parentId: string) => {
    setOpenReplies((prev) => ({
      ...prev,
      [parentId]: !prev[parentId],
    }));
  };

  const handleReplySave = () => {
    const formdata = new FormData();
    if (!selectedParentId) return;
    formdata.append("parentId", selectedParentId);
    formdata.append("comment", replyText);

    fetcher.submit(formdata, {
      method: "post",
      encType: "multipart/form-data",
    });
    console.log("formdata", Object.fromEntries(formdata.entries()));
    console.log("Reply to:", selectedParentId, "Text:", replyText);
    setReplyText("");
    setSelectedParentId(null);
  };

  useEffect(() => {
    console.log("fetcher data", fetcher?.data);
    const data = fetcher?.data as { success?: boolean } | undefined;
    if (data?.success === true) {
      setisSendloading(false);
      navigate({ pathname: "/app/reviews", search });
    }
  }, [fetcher?.data]);
  const handleSave = (value: string) => {
    const formdata = new FormData();
    if (value) {
      formdata.append("order_item_review_comment", value);
    }

    fetcher.submit(formdata, {
      method: "post",
      encType: "multipart/form-data",
    });
    setValue("");
  };

  const parentComments =
    ReviewData[0]?.orderItemReview[0]?.Review_Comments?.filter(
      (c: any) => c.parent_comment_id === null,
    ) || [];

  const allComments = ReviewData[0]?.orderItemReview[0]?.Review_Comments || [];

  return (
    <Page
      title="Review Details"
      fullWidth
      backAction={{
        onAction: () => navigate({ pathname: "/app/reviews", search }),
      }}
    >
      <Layout>
        <Layout.Section variant="fullWidth">
          <Card>
            <div style={{ display: "flex", gap: "20px", position: "relative" }}>
              <div style={{ flex: "0 0 230px" }}>
                <img
                  src={
                    ReviewData[0]?.product?.product_image_url ||
                    "https://cdn.prod.website-files.com/62d84e447b4f9e7263d31e94/6399a4d27711a5ad2c9bf5cd_ben-sweet-2LowviVHZ-E-unsplash-1.jpeg"
                  }
                  width={230}
                  height={180}
                  style={{ borderRadius: 7 }}
                />
                <Text as="h2" variant="headingMd">
                  {ReviewData[0]?.product?.product_name || "N/A"}
                </Text>
                {ReviewData[0]?.orderItemReview.map(
                  (review: any, index: number) => (
                    <div style={{ width: 100, display: "flex" }} key={index}>
                      <StarRating
                        rating={review?.order_item_review_rating ?? 0}
                      />
                    </div>
                  ),
                )}
              </div>

              <div
                style={{
                  borderLeft: "1px solid  #ccc",
                  height: "auto",
                }}
              />

              <div style={{ flex: 1, position: "relative" }}>
                {!isreportactive && (
                  <div style={{ position: "absolute", top: 0, right: 0 }}>
                    <Button
                      onClick={() => setisreportactive(true)}
                      loading={isReportloading}
                    >
                      Report
                    </Button>
                  </div>
                )}
                {isreportactive && (
                  <div style={{ position: "absolute", top: 0, right: 0 }}>
                    <Button
                      onClick={() => {
                        setisreportactive(true),
                          handlereport(),
                          setisSendloading(true);
                      }}
                      loading={isSendloading}
                    >
                      Send
                    </Button>
                  </div>
                )}
                <div
                  style={{
                    display: "flex",
                    gap: 8,
                    borderRadius: 10,
                  }}
                >
                  <img
                    src={
                      ReviewData[0]?.orders?.Users?.user_image_url ||
                      "https://cdn.prod.website-files.com/62d84e447b4f9e7263d31e94/6399a4d27711a5ad2c9bf5cd_ben-sweet-2LowviVHZ-E-unsplash-1.jpeg"
                    }
                    width={50}
                    height={50}
                    style={{
                      borderRadius: 7,
                    }}
                  />
                  <div>
                    <Text as="h2" variant="headingMd">
                      {ReviewData[0]?.orders?.Users?.user_first_name +
                        " " +
                        ReviewData[0]?.orders?.Users?.user_last_name || "N/A"}
                    </Text>
                    <span style={{ color: "#1B223C80", fontSize: "12px" }}>
                      User Since 2025
                    </span>
                  </div>
                </div>
                {ReviewData[0]?.orderItemReview?.map(
                  (review: any, index: number) => (
                    <div key={index} style={{ marginTop: 5 }}>
                      <Text as="p" variant="bodyMd">
                        <div
                          style={{
                            display: "-webkit-box",
                            WebkitLineClamp: 2,
                            WebkitBoxOrient: "vertical",
                            overflow: "hidden",
                            textOverflow: "ellipsis",
                          }}
                        >
                          {review?.order_item_review_comment ||
                            "No comment available"}
                        </div>
                      </Text>
                    </div>
                  ),
                )}
                <div
                  style={{
                    display: "flex",
                    gap: 10,
                    marginTop: 2,
                    justifyContent: "flex-start",
                  }}
                >
                  {ReviewData[0]?.orderItemReview[0]?.Review_Images?.map(
                    (image: any, index: number) => (
                      <div
                        key={image.id || index}
                        style={{
                          border: "1px ",
                          borderRadius: 7,
                          backgroundColor: "#E5E4E2",
                          marginTop: "1%",
                          marginRight: "0.5%",
                          justifyContent: "center",
                          cursor: "pointer",
                          alignItems: "center",
                        }}
                        onClick={() => setPreviewUrl(image.review_image_url)}
                      >
                        <img
                          src={image.review_image_url}
                          width={50}
                          height={40}
                          style={{
                            borderRadius: 5,
                            cursor: "pointer",
                          }}
                          alt={`Image ${index + 1}`}
                        />
                      </div>
                    ),
                  )}
                </div>

                {!isreportactive && (
                  <div>
                    {parentComments.map((parentComment: any, index: number) => {
                      const replies = allComments.filter(
                        (c: any) =>
                          c.parent_comment_id === parentComment.comment_id,
                      );

                      return (
                        <div
                          key={index}
                          style={{ marginBottom: "1rem", marginTop: "1rem" }}
                        >
                          <div
                            style={{
                              display: "flex",
                              gap: 8,
                              alignItems: "center",
                              padding: "8px",
                            }}
                          >
                            <img
                              src={
                                parentComment.commenter_type === "user"
                                  ? ReviewData[0]?.orders?.Users
                                      ?.user_image_url ||
                                    "https://cdn.prod.website-files.com/62d84e447b4f9e7263d31e94/6399a4d27711a5ad2c9bf5cd_ben-sweet-2LowviVHZ-E-unsplash-1.jpeg"
                                  : parentComment.commenter_type === "shop"
                                    ? shop?.shop_logo_url ||
                                      "https://cdn.prod.website-files.com/62d84e447b4f9e7263d31e94/6399a4d27711a5ad2c9bf5cd_ben-sweet-2LowviVHZ-E-unsplash-1.jpeg"
                                    : "https://cdn.prod.website-files.com/62d84e447b4f9e7263d31e94/6399a4d27711a5ad2c9bf5cd_ben-sweet-2LowviVHZ-E-unsplash-1.jpeg"
                              }
                              width={32}
                              height={32}
                              style={{ borderRadius: 50, objectFit: "cover" }}
                              alt="commenter"
                            />
                            <div>
                              <Text
                                as="h3"
                                variant="bodySm"
                                fontWeight="medium"
                              >
                                {parentComment.commenter_type === "user"
                                  ? ReviewData[0]?.orders?.Users
                                      ?.user_first_name +
                                      " " +
                                      ReviewData[0]?.orders?.Users
                                        ?.user_last_name || "User"
                                  : shop?.shop_name || "Shop"}
                              </Text>
                              <div style={{ fontSize: 14 }}>
                                {parentComment.comment_text}
                              </div>

                              <div
                                style={{
                                  display: "flex",
                                  cursor: "pointer",
                                  alignItems: "center",
                                  marginTop: "2%",
                                }}
                                onClick={() => {
                                  if (replies.length > 0) {
                                    toggleReplies(parentComment.comment_id);
                                  } else {
                                    setSelectedParentId(
                                      parentComment.comment_id,
                                    );
                                    toggleReplies(parentComment.comment_id);
                                  }
                                }}
                              >
                                <div
                                  style={{
                                    display: "flex",
                                    justifyContent: "center",
                                    alignItems: "center",
                                    borderRadius: 6,
                                  }}
                                >
                                  <Icon source={ChatIcon} />
                                  <span style={{ fontSize: 12 }}>
                                    {replies.length > 0
                                      ? openReplies[parentComment.comment_id]
                                        ? "Hide Replies"
                                        : `${replies.length} Replies`
                                      : "Reply"}
                                  </span>
                                </div>
                              </div>
                            </div>
                          </div>

                          {openReplies[parentComment.comment_id] && (
                            <div
                              style={{
                                paddingLeft: 50,
                                paddingTop: 8,
                                marginLeft: 30,
                              }}
                            >
                              {replies.map((reply: any, i: number) => (
                                <div
                                  key={i}
                                  style={{
                                    display: "flex",
                                    gap: 8,
                                    marginBottom: 8,
                                  }}
                                >
                                  <img
                                    src={
                                      reply.commenter_type === "shop"
                                        ? shop?.shop_logo_url ||
                                          "https://cdn.prod.website-files.com/62d84e447b4f9e7263d31e94/6399a4d27711a5ad2c9bf5cd_ben-sweet-2LowviVHZ-E-unsplash-1.jpeg"
                                        : "https://cdn.prod.website-files.com/62d84e447b4f9e7263d31e94/6399a4d27711a5ad2c9bf5cd_ben-sweet-2LowviVHZ-E-unsplash-1.jpeg"
                                    }
                                    width={28}
                                    height={28}
                                    style={{
                                      borderRadius: 50,
                                      objectFit: "cover",
                                    }}
                                    alt="reply"
                                  />
                                  <div>
                                    <Text
                                      as="h3"
                                      variant="bodySm"
                                      fontWeight="medium"
                                    >
                                      {reply.commenter_type === "shop"
                                        ? shop?.shop_name
                                        : "User"}
                                    </Text>
                                    <div style={{ fontSize: 13 }}>
                                      {reply.comment_text}
                                    </div>

                                    <button
                                      style={{
                                        background: "transparent",
                                        color: "#007ACE",
                                        border: "none",
                                        padding: 0,
                                        cursor: "pointer",
                                        fontSize: 12,
                                      }}
                                      onClick={() =>
                                        setSelectedParentId(
                                          parentComment.comment_id,
                                        )
                                      }
                                    >
                                      Reply
                                    </button>
                                  </div>
                                </div>
                              ))}

                              {selectedParentId ===
                                parentComment.comment_id && (
                                <TextField
                                  label=""
                                  value={replyText}
                                  onChange={handleReplyChange}
                                  multiline={1}
                                  autoComplete="off"
                                  placeholder="Enter Reply"
                                  suffix={
                                    <div
                                      style={{ cursor: "pointer" }}
                                      onClick={handleReplySave}
                                    >
                                      <Icon source={SendIcon} tone="base" />
                                    </div>
                                  }
                                />
                              )}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}

                {!isreportactive && (
                  <div
                    style={{
                      marginTop:
                        ReviewData[0]?.orderItemReview[0]?.Review_Comments
                          ?.length > 0
                          ? "2%"
                          : "5%",
                      marginBottom: "1%",
                    }}
                  >
                    <TextField
                      label=""
                      value={value}
                      onChange={handleChange}
                      multiline={4}
                      autoComplete="off"
                      placeholder="Write your comment"
                      suffix={
                        <div
                          style={{ cursor: "pointer" }}
                          onClick={() => {
                            handleSave(value);
                          }}
                        >
                          <Icon source={SendIcon} tone="base" />
                        </div>
                      }
                    />
                  </div>
                )}
                {isreportactive && (
                  <div
                    style={{
                      display: "flex",
                      flexDirection: "row",
                      gap: "10px",
                      flexWrap: "wrap",
                      marginTop: "8px",
                      paddingTop: "8px",
                    }}
                  >
                    {choices.map((choice) => (
                      <div key={choice.value} style={{ flex: "0 1 auto" }}>
                        <ChoiceList
                          title=""
                          choices={[choice]}
                          selected={selected}
                          onChange={handleChoiceChange}
                        />
                      </div>
                    ))}
                  </div>
                )}
                {selected[0] == "9" && (
                  <TextField
                    label=""
                    value={value}
                    onChange={handleChange}
                    multiline={4}
                    autoComplete="off"
                    placeholder="Write your comment"
                  />
                )}
              </div>
            </div>
          </Card>
        </Layout.Section>
      </Layout>
      {previewUrl && (
        <div
          onClick={() => setPreviewUrl(null)}
          style={{
            position: "fixed",
            top: 0,
            left: 0,
            width: "100vw",
            height: "100vh",
            backgroundColor: "rgba(0, 0, 0, 0.7)",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            zIndex: 1000,
            cursor: "pointer",
          }}
        >
          <img
            src={previewUrl}
            alt="Preview"
            style={{
              maxWidth: "90%",
              maxHeight: "90%",
              borderRadius: 10,
              boxShadow: "0 0 20px rgba(255,255,255,0.5)",
            }}
          />
        </div>
      )}
    </Page>
  );
}
