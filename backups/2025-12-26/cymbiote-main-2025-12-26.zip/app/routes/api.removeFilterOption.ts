import { ActionFunctionArgs, json } from "@remix-run/node";
import { retryOperation } from "~/functions/common";

export const action = async ({ request }: ActionFunctionArgs) => {
  const url = new URL(request.url);
  try {
    const formData = await request.formData();
    const method = request.method;

    if (method === "POST" && formData.get("filter")) {
      const filter = formData.get("filter")?.toString();
      const shopDomain = formData.get("shopDomain")?.toString();
      const filterOption = formData.get("filterOption")?.toString();

      console.log("formData in API", formData);

      if (!shopDomain) {
        return json({ error: "Missing shop" }, { status: 400 });
      }

      const shop = await retryOperation(async () => {
        return await prisma.shops.findFirst({
          where: {
            shop_domain: shopDomain,
          },
        });
      });

      if (!shop) {
        return json({ error: "Shop not found" }, { status: 404 });
      }

      // Find the filter associated with the given filter value and shop ID
      const existingFilter = await retryOperation(async () => {
        return await prisma.shop_Filters.findFirst({
          where: {
            shop_filter_value: filter,
            shop_filter_shop_id: shop.shop_id,
          },
          select: { shop_filter_id: true },
        });
      });

      // Check if the filter exists before trying to delete its options
      if (!existingFilter) {
        return json(
          { error: "Filter not found for the specified value." },
          { status: 404 },
        );
      }

      // Remove the specific filter option
      const deleteResult = await retryOperation(async () => {
        return await prisma.filter_Options.deleteMany({
          where: {
            filter_option_shop_filter_id: existingFilter.shop_filter_id,
            filter_option_value: filterOption, // This ensures we only delete the specified option
          },
        });
      });

      if (!deleteResult || deleteResult.count === 0) {
        return json(
          { error: "No filter option found to remove." },
          { status: 404 },
        );
      }

      console.log("filter option deleted successfully");

      return json({
        success: true,
        message: `Filter Option "${filterOption}" removed successfully`,
      });
    }
  } catch (error) {
    console.error("Removing filter option unsuccessful:", error);
    return json(
      { error: "Removing filter option unsuccessful" },
      { status: 500 },
    );
  }
};
