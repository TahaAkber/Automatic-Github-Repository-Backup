import { useEffect, useMemo, useState } from "react";
import type {
  ActionFunctionArgs,
  LoaderFunctionArgs,
  TypedResponse,
} from "@remix-run/node";
import { json } from "@remix-run/node";
import { useFetcher, useLoaderData } from "@remix-run/react";
import { Page, Card, BlockStack, Text, InlineStack } from "@shopify/polaris";
import { Loader } from "~/components/common/Loader";
import { AvatarSection } from "~/components/connect/AvatarSection";
import { AuthorizationSection } from "~/components/connect/AuthorizationSection";
import { retryOperation } from "~/functions/common";
import { useRevalidator } from "@remix-run/react";

interface ConnectAccount {
  email: string;
  search: string;
  shop: any;
  APP_URL: any;
}

export const loader = async ({
  request,
}: LoaderFunctionArgs): Promise<TypedResponse<ConnectAccount>> => {
  const url = new URL(request.url);
  const shopDomain = url.searchParams.get("shop_domain");
  const email = url.searchParams.get("email");
  if (!shopDomain) {
    throw new Response("Missing shop domain", { status: 400 });
  }

  try {
    const APP_URL = process.env.APP_URL;
    const shop = await prisma.shops.findFirst({
      where: {
        shop_domain: shopDomain,
      },
    });

    const returnJson = {
      email: email || "",
      search: url.search,
      shop,
      APP_URL,
    };

    console.log("returnJson", returnJson);

    return json(returnJson);
  } catch (error) {
    console.error("Error in loader:", error);
    return json({
      email: "",
      search: "",
      shop: null,
      APP_URL: "",
    });
  }
};

export const action = async ({ request }: ActionFunctionArgs) => {
  // const { admin } = await authenticate.admin(request);
  const formData = await request.formData();
  const email = formData.get("email")?.toString();
  const url = new URL(request.url);
  const shopDomain = url.searchParams.get("shop_domain");

  const shop = await prisma.shops.findFirst({
    where: {
      shop_domain: shopDomain,
    },
  });

  // update shop if email is changed and mark shop as active
  if (!shop) {
    console.error("shop not found");
    return json({
      success: false,
      message: "shop not connected",
    });
  }
  console.log("action called", email, shop.shop_email);

  if (email !== shop.shop_email) {
    await retryOperation(async () => {
      return await prisma.shops.update({
        where: {
          shop_id: shop.shop_id,
        },
        data: {
          shop_is_active: true,
          shop_email: email,
        },
      });
    });
  } else {
    await retryOperation(async () => {
      return await prisma.shops.update({
        where: {
          shop_id: shop.shop_id,
        },
        data: {
          shop_is_active: true,
        },
      });
    });
  }

  return json({
    success: true,
    message: "shop connected successfully",
  });
};

export default function Index() {
  const { shop, email, APP_URL } = useLoaderData<ConnectAccount>();
  const [firstTimeLoad, setFirstTimeLoad] = useState(true);
  const [loading, setLoading] = useState(false);
  const fetcher = useFetcher<{ success: boolean; message: string }>();
  const revalidator = useRevalidator();

  useEffect(() => {
    setFirstTimeLoad(false);
  }, []);

  const openerOrigin = useMemo(() => {
    try {
      return new URL(APP_URL || "").origin;
    } catch {
      return window.location.origin; // dev fallback
    }
  }, [APP_URL]);

  // useEffect(() => {
  //   const data = fetcher.data;
  //   if (data?.success === true || data?.success === false) {
  //     const payload = {
  //       type: "oauth:done",
  //       success: !!data.success,
  //       shopDomain: shop?.shop_domain,
  //       email: email ?? shop?.shop_email,
  //       message: data.message,
  //     };

  //     // 2) postMessage (fallback when opener is same-origin window)
  //     try {
  //       const openerOrigin = (() => {
  //         try {
  //           return new URL(APP_URL || "").origin;
  //         } catch {
  //           return window.location.origin;
  //         }
  //       })();
  //       console.log(
  //         "[popup] sending via postMessage to",
  //         openerOrigin,
  //         payload,
  //       );
  //       window.opener?.postMessage(payload, openerOrigin);
  //     } catch (err) {
  //       console.warn("[popup] postMessage failed", err);
  //     }

  //     // Close after signaling
  //     window.close();

  //     if (!data.success) {
  //       setLoading(false);
  //       console.error("[popup] error updating shop status");
  //     }
  //   }
  // }, [fetcher.data, APP_URL, shop?.shop_domain, email]);

  useEffect(() => {
    console.log("fetcher.data", fetcher.data);
    if (fetcher.data?.success === true) {
      // tell the opener we’re done (success)
      window.opener?.postMessage(
        {
          type: "oauth:done",
          success: true,
          shopDomain: shop?.shop_domain,
          email: email ?? shop?.shop_email,
          message: fetcher.data.message,
        },
        openerOrigin,
      );
      window.close();
    } else if (fetcher.data?.success === false) {
      // notify failure too (optional)
      window.opener?.postMessage(
        {
          type: "oauth:done",
          success: false,
          shopDomain: shop?.shop_domain,
          email: email ?? shop?.shop_email,
          message: fetcher.data.message,
        },
        openerOrigin,
      );
      setLoading(false);
      console.error("error updating shop status");
    }
  }, [fetcher.data, openerOrigin, shop?.shop_domain, email, setLoading]);

  const connectCurrentEmail = () => {
    setLoading(true);
    const form = new FormData();
    form.append("email", email);
    fetcher.submit(form, { method: "POST" });
  };

  if (firstTimeLoad) {
    return (
      <Page fullWidth>
        <Loader />
      </Page>
    );
  }

  return (
    <Page fullWidth>
      <Card>
        <BlockStack align="center" gap={{ xs: "600" }}>
          <AvatarSection
            shop_logo_url={shop.shop_logo_url}
            shop_name={shop.shop_name}
          />
          <InlineStack align="center">
            <Text as="p" fontWeight="semibold" variant="headingLg">
              Authorize with Cercle
            </Text>
          </InlineStack>
          <AuthorizationSection
            loading={loading}
            shop_name={shop?.shop_name}
            authorizeEmail={connectCurrentEmail}
            shop_email={email || shop.shop_email}
            shop_icon_image={shop?.shop_logo_url}
          />
        </BlockStack>
      </Card>
    </Page>
  );
}
