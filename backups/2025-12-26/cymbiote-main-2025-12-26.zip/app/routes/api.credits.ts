import { ActionFunctionArgs, json } from "@remix-run/node";
import { subDays } from "date-fns";
import { retryOperation } from "~/functions/common";

export const loader = async ({ request }: ActionFunctionArgs) => {
  try {
    const url = new URL(request.url);

    const shopId = url.searchParams.get("shopId") || "";
    const billingDate = url.searchParams.get("billingDate") || "";

    console.log("shopId", shopId, "billingDate", billingDate);

    if (!shopId || !billingDate) {
      return json(
        { message: "Missing required parameters: shopId or billingDate" },
        { status: 400 },
      );
    }

    // Convert billingDate to a Date object
    const billingDateObj = new Date(billingDate);
    // Calculate the start date (30 days before billing date)
    const startDate = subDays(billingDateObj, 30);

    // Fetch credits from the last 30 days
    const thisMonthCredits = await retryOperation(async () => {
      return await prisma.merchant_Credits.findMany({
        where: {
          credit_shop_id: parseInt(shopId),
          created_at: {
            gte: startDate, // Greater than or equal to (30 days ago)
            lte: billingDateObj, // Less than or equal to billing date
          },
        },
      });
    });
    // Sum total credits
    const totalCredits = (thisMonthCredits ?? []).reduce(
      (acc: number, credit: any) => acc + parseFloat(credit.credit_amount), // Adjust field name if necessary
      0,
    );

    console.log("Total Credits in Last 30 Days:", totalCredits);

    return json({ totalCredits });
  } catch (error) {
    console.error("Credits fetch error message", error);
    return json({ message: "Failed to fetch credits" }, { status: 500 });
  }
};
