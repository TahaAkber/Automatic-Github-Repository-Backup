import {
  ActionFunctionArgs,
  json,
  redirect,
  TypedResponse,
} from "@remix-run/node";
import { useActionData, useLoaderData, useSubmit } from "@remix-run/react";
import {
  Page,
  TextField,
  ChoiceList,
  Button,
  Card,
  Layout,
  Form,
  Text,
} from "@shopify/polaris";
import { useCallback, useState } from "react";
import { authenticate } from "~/shopify.server";

export const loader = async ({ request }: any): Promise<TypedResponse<any>> => {
  const { admin } = await authenticate.admin(request);
  const url = new URL(request.url);
  const params = new URLSearchParams(url.search);
  const shopDomain = url.searchParams.get("shop");
  const queryString = params.toString();
  const redirectUrl = `/app?${queryString}`;
  const charge_id = url.searchParams.get("charge_id");
  console.log("shopDomain subscriptions", shopDomain, url);

  try {
    // Fetch available review
    const review = await prisma.delisting_Reviews.findFirst({
      where: {
        Shops: {
          shop_domain: shopDomain,
        },
        review_is_active: true,
      },
    });

    // If subscription does not exist or is not active, do nothing and return packages
    return json({
      search: url.search,
      reviewExists: review?.review_id !== undefined,
    });
  } catch (error) {
    console.error("Error getting delisted review loader", error);
    throw new Response("Error getting delisted review loader", {
      status: 500,
    });
  }
};

export default function CancellationReview() {
  const actionData = useActionData<any>();
  const { search, reviewExists } = useLoaderData<any>();

  const [reason, setReason] = useState("");
  const [additionalComments, setAdditionalComments] = useState("");
  const [conditions, setConditions] = useState<string[]>([]);
  const submit = useSubmit();

  const handleReasonChange = (value: string) => setReason(value);
  const handleCommentsChange = (value: string) => setAdditionalComments(value);
  const handleConditionsChange = (value: any) => setConditions(value);

  const handleSubmit = useCallback(() => {
    if (!reason) {
      alert("Reason is required.");
      return;
    }

    const formData = new FormData();
    formData.append("reason", reason);
    formData.append("additionalComments", additionalComments);
    formData.append("conditions", conditions.join(","));

    submit(formData, { method: "POST" });

    // Clear form
    setReason("");
    setAdditionalComments("");
    setConditions([]);
  }, [reason, additionalComments, conditions, submit]);

  return (
    <Page
      title="Order Cancellation Reason"
      subtitle="It appears that a significant number of orders from your account are being canceled. Kindly provide the reasons for these cancellations to assist us in evaluating your delisting status."
    >
      <Layout>
        <Layout.Section>
          <Card>
            <Form onSubmit={handleSubmit}>
              {/* Reason for Cancellation */}
              <TextField
                label="Reason for Cancellation"
                value={reason}
                onChange={handleReasonChange}
                placeholder="Provide the main reason for cancellation"
                helpText="This helps us understand the issues faced with order fulfillment."
                autoComplete="false"
              />

              {/* Additional Comments */}
              <TextField
                label="Additional Comments (optional)"
                value={additionalComments}
                onChange={handleCommentsChange}
                multiline={4}
                placeholder="Any additional information about the cancellation."
                autoComplete="false"
              />

              {/* Conditions and Future Commitment */}
              <ChoiceList
                title="Conditions for Relisting"
                choices={[
                  {
                    label:
                      "I have resolved the issues causing order cancellations.",
                    value: "resolved_issues",
                  },
                  {
                    label:
                      "I commit to improved fulfillment for future orders.",
                    value: "future_commitment",
                  },
                  {
                    label:
                      "I have implemented new processes to avoid cancellations.",
                    value: "new_processes",
                  },
                ]}
                selected={conditions}
                onChange={handleConditionsChange}
                allowMultiple
              />

              <br />
              <Button variant="primary" submit>
                Submit for Review
              </Button>
            </Form>
          </Card>

          {actionData?.error && (
            <Text as="p" tone="critical">
              {actionData.error}
            </Text>
          )}

          {reviewExists && (
            <Text as="p" tone="success">
              A response has been submitted.
            </Text>
          )}
        </Layout.Section>
      </Layout>
    </Page>
  );
}

// Loader and Action functions (Remix API)

export const action = async ({ request }: ActionFunctionArgs) => {
  console.log("Cancellation Review Action Triggered");
  const url = new URL(request.url);
  const shopDomain = url.searchParams.get("shop");
  const formData = await request.formData();

  const reason = formData.get("reason")?.toString();
  const additionalComments = formData.get("additionalComments")?.toString();
  const conditions = formData.get("conditions")?.toString().split(","); // Parse conditions as an array

  console.log("conditions", conditions);

  if (!reason) {
    return { error: "Please provide a reason for the cancellation." };
  }

  try {
    // Fetch the shop based on the provided shopDomain
    const shop = await prisma.shops.findFirst({
      where: {
        shop_domain: shopDomain,
      },
    });

    if (!shop) {
      return {
        error: "Shop not found. Please ensure the shop domain is correct.",
      };
    }

    // Create a new review record in the database
    await prisma.delisting_Reviews.create({
      data: {
        review_reason: reason,
        review_commit_check: conditions?.includes("future_commitment") || false,
        review_process_update_check:
          conditions?.includes("processUpdateCheck") || false,
        review_resolve_check: conditions?.includes("resolved_issues") || false,
        review_extra_details: additionalComments || null,
        review_shop_id: shop.shop_id,
      },
    });

    return { success: true };
  } catch (error) {
    console.error("Error submitting cancellation review:", error);
    return { error: "Failed to submit your response. Please try again later." };
  }
};
