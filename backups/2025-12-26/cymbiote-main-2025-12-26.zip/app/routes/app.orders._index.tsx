import {
  ActionFunctionArgs,
  json,
  LoaderFunctionArgs,
  redirect,
  TypedResponse,
} from "@remix-run/node";
import {
  useFetcher,
  useLoaderData,
  useLocation,
  useNavigate,
  useSubmit,
} from "@remix-run/react";
import { Button, Card, Page, Text } from "@shopify/polaris";
import { useEffect, useState } from "react";
import { Loader } from "~/components/common/Loader";
import OrderCards from "~/components/orders/OrderCards";
import { OrderTable } from "~/components/orders/OrderTable";
import { transformOrders } from "~/functions/order";
import { OrderLoaderReturn } from "~/types/OrderLoaderReturn";

export const loader = async ({
  request,
}: LoaderFunctionArgs): Promise<TypedResponse<OrderLoaderReturn>> => {
  const url = new URL(request.url);
  const shopDomain = url.searchParams.get("shop");

  try {
    const shop = await prisma.shops.findFirst({
      where: {
        shop_domain: shopDomain,
      },
    });
    // Fetch orders from Prisma where order_channel is "cercle"
    const orders = await prisma.orders.findMany({
      where: {
        order_channel: { in: ["cercle", "cymbiote", "cercleDev"] },
        order_shop_id: shop?.shop_id,
      },
      include: {
        Users: true,
        Transactions: true,
        Order_Items: true,
        Tracking: true,
      },
    });
    const shippedOrders = await prisma.orders.findMany({
      where: {
        order_channel: { in: ["cercle", "cymbiote", "cercleDev"] },
        order_shop_id: shop?.shop_id,
        order_fulfillment_status: "fulfilled",
      },
    });

    return json({
      shop: shop,
      shippedOrders: shippedOrders,
      upcommingOrders: orders,
      search: url.search,
      shopDomain: shopDomain || "",
    });
  } catch (error) {
    console.error("Error fetching orders from database:", error);
    throw new Response("Error fetching orders from database", {
      status: 500,
    });
  }
};

export const action = async ({ request }: ActionFunctionArgs) => {
  // const { admin } = await authenticate.admin(request);
  console.log("ACTION TRIGGERED");

  const url = new URL(request.url);
  const params = new URLSearchParams(url.search);
  const queryString = params.toString();
  const shopDomain = url.searchParams.get("shop");

  // Load session using the shop domain

  console.log("shop", shopDomain);

  const shop = await prisma.shops.findFirst({
    where: {
      shop_domain: shopDomain,
    },
  });
  if (!shop) {
    return json(
      {
        error: "shop not found",
      },
      { status: 404 },
    );
  }

  const formData = await request.formData();

  const orderId = formData.get("orderId") as string;
  console.log("orderId", orderId);

  const updateSessions = await prisma.shops.update({
    data: {
      shop_selectedOrder: orderId,
      updated_at: new Date(),
    },
    where: {
      shop_id: shop?.shop_id,
    },
  });

  const redirectUrl = `/app/orders/orderdetails?${queryString}`;
  return redirect(redirectUrl);
};
const itemsPerPage = 10;
export default function Orders() {
  const fetcher = useFetcher();
  const { state } = useLocation();
  const [sortSelected, setSortSelected] = useState(["order asc"]);
  const [selected, setSelected] = useState(state?.viewType ? 4 : 0);

  const navigate = useNavigate();
  const submit = useSubmit();
  const { shippedOrders, upcommingOrders, search, shopDomain, shop } =
    useLoaderData<OrderLoaderReturn>();
  const [isPostBack, setIsPostBack] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [isloading, setisloading] = useState(false);
  const [itemStrings, setItemStrings] = useState([
    "All",
    "Unpaid",
    "Open",
    "Closed",
    "Cancelled",
    // 'Local pickup',
  ]);
  // console.log("upcommingOrders", upcommingOrders);
  // console.log("Shipped Orders", shippedOrders);
  const [filteredOrders, setFilteredOrders] = useState(upcommingOrders);
  const [queryValue, setQueryValue] = useState("");

  useEffect(() => {
    setIsPostBack(true);
  }, []);

  const selectOrder = (selected: string) => {
    const formData = new FormData();
    formData.append("orderId", selected);
    console.log("testing", selected);
    fetcher.submit(formData, { method: "POST" });
  };

  const totalPages = Math.ceil(filteredOrders.length / itemsPerPage);

  const handlePagination = (newPage: any) => {
    if (newPage < 1 || newPage > totalPages) return;
    setCurrentPage(newPage);
  };

  const getOrders = async (orderFilter: string, sorting?: string) => {
    // console.log("Fetching orders with filter:", orderFilter);
    const formData = new FormData();
    formData.append("orderFilter", orderFilter);
    formData.append("shopDomain", shopDomain);
    if (sorting) {
      formData.append("Sorting", JSON.stringify(sortSelected[0]));
    }
    try {
      const ordersResponse = await fetch(
        `/api/orders?${search}&querySearch=${queryValue}`,
        {
          method: "POST",
          body: formData,
          headers: {
            Accept: "application/json",
          },
        },
      );

      if (!ordersResponse.ok) {
        throw new Error(`HTTP error! Status: ${ordersResponse.status}`);
      }

      const responseData = await ordersResponse.json();

      if (responseData?.data) {
        setFilteredOrders(responseData.data);
        setCurrentPage(1);

        console.log("Filtered Orders:", responseData.data);
      }
    } catch (error) {
      console.error("Error fetching filtered orders:", error);
    }
  };

  useEffect(() => {
    const currentFilter = itemStrings[selected] || "All";
    const sortValue = sortSelected[0] || "";
    getOrders(currentFilter, sortValue);
  }, [selected, sortSelected, queryValue]);

  if (!isPostBack) {
    return (
      <Page fullWidth>
        <Loader />
      </Page>
    );
  }

  const handletranscations = () => {
    setisloading(true);
    navigate({ pathname: "/app/subscriptions", search });
  };
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;

  const currentOrders = filteredOrders.slice(startIndex, endIndex);

  return (
    <Page
      backAction={{
        content: "Orders",
        onAction: () => navigate({ pathname: "/app", search }),
      }}
      title="Orders"
      primaryAction={{
        content: "Transactions",
        onAction: handletranscations,
        loading: isloading,
      }}
      fullWidth
    >
      <OrderCards
        upcommingOrders={upcommingOrders}
        shippedOrders={shippedOrders}
      />
      <OrderTable
        orders={transformOrders(currentOrders)}
        selectOrder={selectOrder}
        getOrders={getOrders}
        viewType={state?.viewType}
        shop={shop}
        setQueryValue={setQueryValue}
        queryValue={queryValue}
        setSortSelected={setSortSelected}
        sortSelected={sortSelected}
        setSelected={setSelected}
        selected={selected}
        setItemStrings={setItemStrings}
        itemStrings={itemStrings}
      />
      <div
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          margin: "10px 0",
        }}
      >
        {/* <Text as="p">
          {`Showing ${(currentPage - 1) * itemsPerPage + 1} - ${Math.min(
            currentPage * itemsPerPage,
            upcommingOrders.length,
          )} of ${upcommingOrders.length} Orders`}
        </Text> */}
      </div>
      <div
        style={{
          marginTop: "20px",
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <Button
          disabled={currentPage <= 1}
          onClick={() => handlePagination(currentPage - 1)}
        >
          Previous
        </Button>
        <Text as="p">{`Page ${totalPages > 0 ? currentPage : 0} of ${totalPages}`}</Text>
        <Button
          disabled={currentPage >= totalPages}
          onClick={() => handlePagination(currentPage + 1)}
        >
          Next
        </Button>
      </div>
    </Page>
  );
}
