import { Prisma } from "@prisma/client";
import { json, LoaderFunctionArgs, TypedResponse } from "@remix-run/node";
import { useLoaderData, useNavigate } from "@remix-run/react";
import {
  Badge,
  BlockStack,
  Card,
  Image,
  InlineStack,
  Layout,
  List,
  Page,
  ResourceItem,
  ResourceList,
  Spinner,
  Text,
  TextContainer,
} from "@shopify/polaris";
import dayjs from "dayjs";
import { useEffect, useState } from "react";
import { retryOperation } from "~/functions/common";
import { authenticate } from "~/shopify.server";
import { OrderInfoLoaderReturn } from "~/types/OrderInfoLoaderReturn";

export const loader = async ({
  request,
}: LoaderFunctionArgs): Promise<
  TypedResponse<OrderInfoLoaderReturn | { error: string }>
> => {
  const { admin } = await authenticate.admin(request);
  const url = new URL(request.url);
  const shopDomain = url.searchParams.get("shop");

  // Load session using the shop domain
  console.log("orderDetails session", shopDomain);

  const shop = await prisma.shops.findFirst({
    where: {
      shop_domain: shopDomain,
    },
  });

  const cymbioteOrder = await prisma.orders.findFirst({
    where: {
      order_id: shop?.shop_selectedOrder
        ? parseInt(shop.shop_selectedOrder, 10)
        : undefined,
    },
    include: {
      Order_Items: {
        take: 10,
        include: {
          Product_Variants: true,
        },
      },
      Transactions: true,
      Users: true,
      Shops: true,
    },
  });
  const discountCode = await prisma.vouchers.findFirst({
    where: {
      ...(cymbioteOrder?.order_user_id != null && {
        voucher_user_id: cymbioteOrder?.order_user_id,
        voucher_order_id: cymbioteOrder?.order_id,
      }),
      voucher_shop_id: shop?.shop_id,
    },
  });
  console.log("discountCode", discountCode);
  let newDiscountCode;
  if (discountCode == null) {
    newDiscountCode = await prisma.cart_Discount_Codes.findFirst({});
  }
  if (!shop) {
    return json({ error: "Shop not found" }, { status: 404 });
  }

  try {
    // Fetch shop details from Shopify
    const shopDetails = await admin.rest.resources.Shop.all({
      session: admin.rest.session,
    });

    if (shopDetails.data.length < 1) {
      return json({
        order: null,
        search: "",
        discountCode: null,
      });
    }

    // console.log("shopDetails", shopDetails.data[0]);

    const shopShopifyId = shopDetails.data[0].id; // Assuming 'id' is the Shopify shop ID

    // Check if the shop already exists in the database
    let existingShop = await prisma.shops.findFirst({
      where: {
        shop_shopify_id: shopShopifyId + "",
      },
    });

    const existingSession = await retryOperation(async () => {
      return await prisma.session.findFirst({
        where: {
          shop: shopDetails.data[0].domain ? shopDetails.data[0].domain : "",
        },
      });
    });

    // If the shop doesn't exist, create a new entry
    if (!existingShop) {
      existingShop = await retryOperation(async () => {
        return (await prisma.shops.create({
          data: {
            shop_name: shopDetails.data[0].name + "",
            shop_description: shopDetails.data[0].description || null,
            shop_logo_url: shopDetails.data[0].image?.src || null,
            shop_shopify_id: shopShopifyId + "",
            shop_access_token: existingSession?.accessToken,
            shop_domain: shopDetails.data[0].domain
              ? shopDetails.data[0].domain
              : "",
          },
        })) as any;
      });
    }
    console.log("orders", cymbioteOrder);

    // Get the product count from the database
    // const productCount = await prisma.products.count();

    // const cymbioteOrders = await admin.graphql(cymbioteOrdersQuery);

    // const fetchedOrders = await cymbioteOrders.json();

    return json({
      order: cymbioteOrder ? cymbioteOrder : {},
      search: url.search,
      discountCode: discountCode,
    });
  } catch (error) {
    console.error("Error fetching shop order details", error);
    throw new Response("Error fetching shop order details", {
      status: 500,
    });
  }
};

export default function OrderDetailsPage() {
  const navigate = useNavigate();
  const [orderDetails, setOrderDetails] = useState<any>(null);
  const { order, search, discountCode } =
    useLoaderData<OrderInfoLoaderReturn>();
  console.log("Order Detail", order);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadOrderDetails = async () => {
      const data = await fetchOrderDetails();
      setOrderDetails(data);
      setLoading(false);
    };
    loadOrderDetails();
  }, []);

  if (loading) {
    return (
      <Page title="Order Details">
        <Spinner accessibilityLabel="Loading order details" size="large" />
      </Page>
    );
  }

  console.log("orders testing", order);
  const {
    order_title,
    created_at,
    order_total_amount,
    order_fulfillment_status,
    Users,
    Order_Items,
    order_payment_status,
    shops,
    order_charge_rate,
    Transactions,
  } = order;
  const currency = shops?.shop_currency || "PKR";

  const date = dayjs(created_at).format("MMM D [at] h:mmA");
  return (
    <Page
      title={`Order ${order_title}`}
      backAction={{
        content: "Back",
        onAction: () => navigate(-1),
      }}
    >
      <Layout>
        {/* Order Information */}
        <Layout.Section variant="oneHalf">
          <Card>
            <div style={{ display: "flex", justifyContent: "space-between" }}>
              <div>
                <Text as="h5" fontWeight="semibold">
                  Order Info
                </Text>
                <TextContainer>
                  <Text as="p">Order Number: {order_title}</Text>
                  <Text as="p" fontWeight="semibold">
                    Created At:{" "}
                  </Text>{" "}
                  {date}
                  <Text as="p" fontWeight="semibold">
                    Total:{" "}
                  </Text>{" "}
                  {order_total_amount.toLocaleString("en-PK")} {currency}
                  {discountCode && (
                    <div>
                      <Text as="p" fontWeight="semibold">
                        Discount Code:{" "}
                      </Text>
                      <Text as="p" fontWeight="regular">
                        {" "}
                        {discountCode.voucher_code
                          ? discountCode.voucher_code +
                            ":" +
                            " " +
                            discountCode.voucher_value
                          : JSON.stringify(discountCode)}
                      </Text>
                    </div>
                  )}
                  <InlineStack gap={"100"}>
                    <Badge
                      tone={
                        order_payment_status === "paid" ? "success" : "warning"
                      }
                    >
                      {order_payment_status
                        ? order_payment_status
                        : "Payment Pending"}
                    </Badge>
                    <Badge
                      progress={
                        order_fulfillment_status === "fulfilled"
                          ? "complete"
                          : "incomplete"
                      }
                    >
                      {order_fulfillment_status
                        ? order_fulfillment_status
                        : "unfulfilled"}
                    </Badge>
                  </InlineStack>
                </TextContainer>{" "}
              </div>
              <div>
                <Text as="h5" fontWeight="semibold">
                  Cercle Info
                </Text>
                <Text as="p">Cercle Comission Rate: {order_charge_rate}%</Text>
                <div style={{ marginTop: 15 }}>
                  <TextContainer>
                    <Text as="p" fontWeight="semibold">
                      Cercle Commission
                    </Text>
                    {order_charge_rate
                      ? (
                          order_total_amount *
                          (order_charge_rate / 100)
                        ).toFixed(2)
                      : 0.0}
                  </TextContainer>
                </div>
                <div style={{ marginTop: 15 }}>
                  <span>
                    <Text as="p" fontWeight="semibold">
                      Cercle Transaction Status
                    </Text>
                    <Badge
                      tone={
                        Transactions[0]?.transaction_amount > 0
                          ? "success"
                          : "warning"
                      }
                    >
                      {Transactions[0]?.transaction_amount > 0
                        ? "Completed"
                        : "Pending"}
                    </Badge>
                  </span>
                </div>
              </div>
            </div>
          </Card>
        </Layout.Section>

        <Layout.Section variant="oneHalf">
          {Users ? (
            <Card>
              <Text as="h5">Customer Info</Text>
              <TextContainer>
                <Text as="p" fontWeight="semibold">
                  Name:{" "}
                </Text>{" "}
                {Users.user_name ? Users.user_name : "not available"}
                <Text as="p" fontWeight="semibold">
                  Email:{" "}
                </Text>{" "}
                {Users.user_email ? Users.user_email : "not available"}
              </TextContainer>
            </Card>
          ) : (
            <Card>
              <Text as="p" fontWeight="medium">
                No information about customer available in this order
              </Text>
            </Card>
          )}
        </Layout.Section>

        <Layout.Section>
          <Card>
            <Text as="h3" variant="headingXs">
              Order Items
            </Text>
            <ResourceList
              resourceName={{ singular: "lineItem", plural: "lineItems" }}
              items={Order_Items}
              renderItem={(item) => {
                const {
                  id,
                  title,
                  quantity,
                  variantTitle,
                  originalUnitPriceSet,
                  image,
                  order_item_price,
                  Product_Variants,
                  order_item_quantity,
                  order_payment_status,
                } = item;
                return (
                  <ResourceItem
                    id={id}
                    onClick={() => {}}
                    accessibilityLabel={`View details for ${title}`}
                  >
                    <BlockStack>
                      <InlineStack gap={"100"}>
                        <BlockStack>
                          <Image
                            alt="image"
                            source={
                              Product_Variants.variant_image_url
                                ? Product_Variants.variant_image_url
                                : "https://cdn.shopify.com/s/files/1/0923/5460/9434/files/no-photo-or-blank-image-icon-loading-images-or-missing-image-mark-image-not-available-or-image-coming-soon-sign-simple-nature-silhouette-in-frame-isolated-illustration-vector.jpg?v=1746776130"
                            }
                            height={40}
                            width={40}
                            style={{ borderRadius: 5 }}
                          />
                        </BlockStack>
                        <Text as="h3" fontWeight="semibold">
                          {title}
                        </Text>
                        <p>{Product_Variants.variant_name}</p>
                        <p>
                          Qty: {order_item_quantity} <b>x</b>
                        </p>
                        <p>{order_item_price.toLocaleString("en-PK")}</p>=
                        <Text as="p" fontWeight="semibold">
                          {(
                            order_item_quantity * parseFloat(order_item_price)
                          ).toLocaleString(
                            "en-PK", // or "en-US"
                          )}{" "}
                          {currency}
                        </Text>
                      </InlineStack>
                    </BlockStack>
                  </ResourceItem>
                );
              }}
            />
          </Card>
        </Layout.Section>

        <Layout.Section>
          <Card>
            <Text as="p" fontWeight="semibold">
              Fulfillment Info
            </Text>
            <List type="bullet">
              <List.Item>
                Status:{" "}
                <Badge
                  progress={
                    order_fulfillment_status === "fulfilled"
                      ? "complete"
                      : "incomplete"
                  }
                >
                  {order_fulfillment_status
                    ? order_fulfillment_status
                    : "unfulfilled"}
                </Badge>
              </List.Item>
              {/* Add more fulfillment details if necessary */}
            </List>
          </Card>
        </Layout.Section>
      </Layout>
      <div style={{ height: 10 }} />
    </Page>
  );
}

const fetchOrderDetails = async () => {
  return {
    id: "1020",
    orderNumber: "#1020",
    createdAt: "Jul 20 at 4:34pm",
    total: "$969.44",
    financialStatus: "Paid",
    fulfillmentStatus: "Unfulfilled",
    customer: {
      name: "Jaydon Stanton",
      email: "jaydon@example.com",
    },
    lineItems: [
      {
        id: "1",
        title: "Blue T-Shirt",
        quantity: 2,
        variantTitle: "Size: M",
        price: "$20.00",
      },
      {
        id: "2",
        title: "Red Trousers",
        quantity: 1,
        variantTitle: "Size: L",
        price: "$40.00",
      },
    ],
  };
};
