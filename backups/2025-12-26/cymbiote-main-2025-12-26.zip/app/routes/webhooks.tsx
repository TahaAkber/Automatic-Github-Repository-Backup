import type { ActionFunctionArgs } from "@remix-run/node";
import { authenticate } from "../shopify.server";
import db from "../db.server";
import { deleteMetafieldDefinition } from "~/mutations/createMetafield";
import { deleteMetaobjectDefinition } from "~/mutations/metaobject";

export const action = async ({ request }: ActionFunctionArgs) => {
  console.log("tried to run webhook handler");
  const APP_NAME = process.env.APP_NAME;
  const { topic, shop, session, admin } = await authenticate.webhook(request);

  if (!admin) {
    // The admin context isn't returned if the webhook fired after a shop was uninstalled.
    throw new Response();
  }

  // The topics handled here should be declared in the shopify.app.toml.
  // More info: https://shopify.dev/docs/apps/build/cli-for-apps/app-configuration
  switch (topic) {
    case "APP_UNINSTALLED":
      console.log("App uninstalled");
      const categoryMetafieldKey = `${APP_NAME?.toLowerCase()}_product_category`;
      const categoryMetafieldNamespace = "$app:custom_category";
      const variantDiscountMetafieldKey = "cercle_discount";
      const variantDiscountMetafieldNamespace = "$app:custom_discount";
      if (session) {
        const currentShop = await prisma.shops.findFirst({
          where: { shop_domain: session.shop },
        });
        if (currentShop?.shop_category_metafield_id) {
          await deleteMetafieldDefinition(
            currentShop.shop_category_metafield_id,
            true,
            {
              key: categoryMetafieldKey,
              namespace: categoryMetafieldNamespace,
              ownerType: "PRODUCT",
            },
            admin,
          );
        }
        if (currentShop?.shop_variant_discount_metafield_id) {
          await deleteMetafieldDefinition(
            currentShop.shop_variant_discount_metafield_id,
            true,
            {
              key: variantDiscountMetafieldKey,
              namespace: variantDiscountMetafieldNamespace,
              ownerType: "PRODUCTVARIANT",
            },
            admin,
          );
        }
        if (currentShop?.shop_category_metaobject_id) {
          await deleteMetaobjectDefinition(
            admin,
            currentShop.shop_category_metaobject_id,
          );
        }
        await db.shops.update({
          data: {
            shop_category_metafield_id: "",
            shop_variant_discount_metafield_id: "",
          },
          where: {
            shop_id: currentShop?.shop_id,
          },
        });
        await db.session.deleteMany({ where: { shop } });
      }
      break;
    case "CUSTOMERS_DATA_REQUEST":
      console.log("No customer data available to fetch");
      break;
    case "CUSTOMERS_REDACT":
      console.log("No customer data available to delete");
      break;
    case "SHOP_REDACT":
      console.log("Deleting shop data");
      break;
    default:
      throw new Response("Unhandled webhook topic", { status: 404 });
  }

  throw new Response();
};
