import { json, LoaderFunctionArgs, TypedResponse } from "@remix-run/node";
import { retryOperation } from "~/functions/common";

interface LoaderReturn {
  shop: any;
  storeResponse: boolean;
  result: string;
  status: number;
}
export const loader = async ({
  request,
}: LoaderFunctionArgs): Promise<TypedResponse<LoaderReturn>> => {
  const url = new URL(request.url);
  const searchTerm = url.searchParams.get("searchTerm") || "";
  const shopDomain = url.searchParams.get("shop");
  let shop;
  try {
    shop = await retryOperation(async () => {
      return await prisma.shops.findFirst({
        where: {
          shop_domain: shopDomain,
        },
      });
    });
  } catch (error) {
    console.log("There was an error", error);
  }
  return json<LoaderReturn>({
    shop: shop,
    storeResponse: shop?.shop_is_active || false,
    result: "success",
    status: 200,
  });
};
