import { ActionFunctionArgs, json } from "@remix-run/node";
import { fetchGoogleTaxonomy, retryOperation, wait } from "~/functions/common";
import axios from "axios";
import {
  createMetafieldDefinition,
  createMetafieldDefinitionForVariants,
} from "~/mutations/createMetafield";
import { createMetaobjectDefinition } from "~/mutations/metaobject";
import { createMetaobjectEntry } from "~/mutations/createMetaobjectEntry";
import { authenticate } from "~/shopify.server";
import dotenv from "dotenv";
dotenv.config();

export const loader = async ({ request }: ActionFunctionArgs) => {
  const url = new URL(request.url);
  let metaobjectKey = "";
  const shopDomain = url.searchParams.get("shop");
  console.log("createMetafield hit", shopDomain);
  try {
    const { admin } = await authenticate.admin(request);

    if (!shopDomain) {
      return json({ result: "shop domain not available" });
    }

    const shop = await retryOperation(async () => {
      return await prisma.shops.findFirst({
        where: {
          shop_domain: shopDomain,
        },
        include: {
          Subscriptions: true,
        },
      });
    });

    if (shop) {
      if (shop.Subscriptions.length === 0) {
        console.log("subscription not found");
        return json({ result: "Subscriptions not found" });
      }
    }

    if (
      shop?.shop_category_metafield_id &&
      shop?.shop_category_metaobject_id &&
      shop?.shop_variant_discount_metafield_id
    ) {
      console.log("metafield exists");
      return json({ result: "metafield already exists" });
    }

    // Step 1: Create Metaobject Definition if it doesn't exist
    const metaobjectResponse = await retryOperation(async () => {
      return await createMetaobjectDefinition(admin);
    });
    console.log("metaobjectResponse", metaobjectResponse);

    if (metaobjectResponse.id) {
      metaobjectKey = metaobjectResponse.type;
      console.log("metaobjectKey", metaobjectKey);
      const metafieldResponse = await retryOperation(async () => {
        return await createMetafieldDefinition(admin, metaobjectResponse.id);
      });

      await retryOperation(async () => {
        return createMetafieldDefinitionForVariants(admin, shop?.shop_id || 2);
      });

      await retryOperation(async () => {
        return await prisma.shops.update({
          where: {
            shop_id: shop?.shop_id,
          },
          data: {
            shop_category_metafield_id: metafieldResponse.id,
            shop_category_metaobject_id: metaobjectResponse.id,
            updated_at: new Date(),
          },
        });
      });
    }

    if (metaobjectResponse.metaobjectsCount === 5595) {
      return json({ result: "success" });
    }

    console.log("now entering enteries");

    // POST Request Example: Send data to another API using axios
    const postData = {
      shopDomain: shopDomain,
      metaobjectKey: metaobjectKey,
    };

    try {
      const response = await axios.post(
        `${process.env.ENV_URL}/metafield/createMetaObject`,
        postData,
        {
          headers: {
            "Content-Type": "application/json",
            // Add any other headers you need
          },
        },
      );
      console.log("Post response:", response.data);
    } catch (error: any) {
      console.error("Error sending POST request:", error.message);
      return json({ result: "error", message: "Error sending data" });
    }

    return json({ result: "success" });
  } catch (error: any) {
    console.error("Error processing taxonomy:", error);
    return json({ result: "error", message: error.message });
  }
};
