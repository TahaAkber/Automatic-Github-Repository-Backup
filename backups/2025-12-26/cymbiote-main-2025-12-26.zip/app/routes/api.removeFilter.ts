import { ActionFunctionArgs, json } from "@remix-run/node";
import { retryOperation } from "~/functions/common";

export const action = async ({ request }: ActionFunctionArgs) => {
  const url = new URL(request.url);
  try {
    const formData = await request.formData();
    const method = request.method;

    if (method === "POST" && formData.get("removeFilter")) {
      const filterToRemove = formData.get("removeFilter")?.toString();
      const shopDomain = formData.get("shopDomain")?.toString();

      console.log("formData in API", formData);

      if (!shopDomain) {
        return json({ error: "Missing shop" }, { status: 400 });
      }

      const shop = await retryOperation(async () => {
        return await prisma.shops.findFirst({
          where: {
            shop_domain: shopDomain,
          },
        });
      });

      if (!shop) {
        return json({ error: "Shop not found" }, { status: 404 });
      }

      // Remove corresponding filter options
      await retryOperation(async () => {
        return await prisma.filter_Options.deleteMany({
          where: {
            filter_option_shop_filter_id: {
              in: await prisma.shop_Filters
                .findMany({
                  where: {
                    shop_filter_value: filterToRemove,
                    shop_filter_shop_id: shop.shop_id,
                  },
                  select: { shop_filter_id: true },
                })
                .then((filters) => filters.map((f) => f.shop_filter_id)),
            },
          },
        });
      });

      // Remove the filter from the database
      await retryOperation(async () => {
        return await prisma.shop_Filters.deleteMany({
          where: {
            shop_filter_shop_id: shop.shop_id,
            shop_filter_value: filterToRemove,
          },
        });
      });

      return json({
        success: true,
        message: `Filter "${filterToRemove}" removed successfully`,
      });
    }

    // The rest of your existing code handling saves
    // ...
  } catch (error) {
    console.error("Removing filter unsuccessful:", error);
    return json({ error: "Removing filter unsuccessful" }, { status: 500 });
  }
};
