import { useState, useCallback } from "react";
import {
  Page,
  Layout,
  Text,
  Card,
  BlockStack,
  Button,
  ProgressBar,
  List,
  Icon,
  Badge,
  Box,
  InlineStack,
  MediaCard,
  VideoThumbnail,
} from "@shopify/polaris";
import { CheckCircleIcon, StopCircleIcon } from "@shopify/polaris-icons";

// Mock Data for the store context
const SHOP_NAME = "Outfitters";

export default function OnboardingPage() {
  // --- STATE MANAGEMENT ---
  const [completedSteps, setCompletedSteps] = useState<number[]>([]);
  const [expandedStep, setExpandedStep] = useState<number>(1); // Start with step 1 open

  // --- CONFIGURATION ---
  const steps = [
    {
      id: 1,
      title: "Set the Logo",
      content:
        "Upload your brand logo to make the store yours. Ideally 512x512px.",
      action: "Upload Logo",
      optional: false,
    },
    {
      id: 2,
      title: "Select a Subscription",
      content:
        "Choose a plan that fits your business needs to unlock all features.",
      action: "View Plans",
      optional: false,
    },
    {
      id: 3,
      title: "Publish your products",
      content: "Select which products you want visible on our sales channel.",
      action: "Manage Products",
      optional: false,
    },
    {
      id: 4,
      title: "Create or Onboard Collections",
      content: "Organize your items into collections for better navigation.",
      action: "Sync Collections",
      optional: false,
    },
    {
      id: 5,
      title: "Customize Your Store",
      content: "Adjust colors, fonts, and layout settings to match your brand.",
      action: "Open Editor",
      optional: false,
    },
    {
      id: 6,
      title: "Set Reels or Stories",
      content: "Engage customers with short-form video content.",
      action: "Add Media",
      optional: true, // This one is optional
    },
  ];

  // --- LOGIC ---
  const handleMarkDone = (id: number) => {
    if (!completedSteps.includes(id)) {
      setCompletedSteps([...completedSteps, id]);
    }
    // Auto-expand the next step if available
    if (id < steps.length) {
      setExpandedStep(id + 1);
    } else {
      setExpandedStep(0); // Close all if finished
    }
  };

  const toggleStep = (id: number) => {
    setExpandedStep(expandedStep === id ? 0 : id);
  };

  // Calculate Progress
  const progress = Math.round((completedSteps.length / steps.length) * 100);

  return (
    <Page fullWidth>
      <BlockStack gap="500">
        {/* HEADER SECTION */}
        <Box paddingBlockEnd="400">
          <BlockStack gap="200">
            <Text variant="headingXl" as="h1">
              Welcome to Cercle, {SHOP_NAME}!
            </Text>
            <Text variant="bodyLg" as="p" tone="subdued">
              Let's get your store set up for success. Complete the checklist
              below to go live.
            </Text>
          </BlockStack>
        </Box>

        {/* PROGRESS BAR */}
        <Card>
          <BlockStack gap="200">
            <InlineStack align="space-between">
              <Text variant="headingSm" as="h3">
                Setup Progress
              </Text>
              <Text variant="bodySm" as="span" tone="subdued">
                {progress}% Completed
              </Text>
            </InlineStack>
            <ProgressBar progress={progress} tone="primary" size="small" />
          </BlockStack>
        </Card>

        {/* MAIN LAYOUT: LEFT (Checklist) & RIGHT (Video) */}
        <Layout>
          {/* LEFT SIDE: CHECKLIST */}
          <Layout.Section variant="oneThird">
            <Card padding="0">
              {steps.map((step, index) => {
                const isDone = completedSteps.includes(step.id);
                const isOpen = expandedStep === step.id;

                return (
                  <Box
                    key={step.id}
                    padding="400"
                    borderBlockEndWidth={index < steps.length - 1 ? "025" : "0"}
                    borderColor="border"
                  >
                    <BlockStack gap="400">
                      {/* Step Header (Clickable) */}
                      <div
                        onClick={() => toggleStep(step.id)}
                        style={{
                          cursor: "pointer",
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "space-between",
                        }}
                      >
                        <InlineStack gap="300" align="start">
                          <Icon
                            source={isDone ? CheckCircleIcon : StopCircleIcon}
                            tone={isDone ? "success" : "base"}
                          />
                          <Text
                            variant="headingMd"
                            as="h6"
                            textDecorationLine={
                              isDone ? "line-through" : undefined
                            }
                            tone={isDone ? "subdued" : "base"}
                          >
                            {step.title}
                          </Text>
                          {step.optional && <Badge tone="info">Optional</Badge>}
                        </InlineStack>
                      </div>

                      {/* Step Details (Visible only if open) */}
                      {isOpen && !isDone && (
                        <Box paddingInlineStart="800">
                          <BlockStack gap="400">
                            <Text variant="bodyMd" as="p">
                              {step.content}
                            </Text>
                            <InlineStack gap="300">
                              <Button
                                variant="primary"
                                onClick={() => handleMarkDone(step.id)}
                              >
                                Done
                              </Button>
                              <Button variant="plain" url="#">
                                {step.action}
                              </Button>
                            </InlineStack>
                          </BlockStack>
                        </Box>
                      )}

                      {/* Completed State Message */}
                      {isOpen && isDone && (
                        <Box paddingInlineStart="800">
                          <Text tone="success" as="span">
                            Step completed!
                          </Text>
                        </Box>
                      )}
                    </BlockStack>
                  </Box>
                );
              })}
            </Card>
          </Layout.Section>

          {/* RIGHT SIDE: VIDEO & HELP */}
          <Layout.Section>
            <BlockStack gap="500">
              {/* Youtube Embed Card */}
              <Card>
                <BlockStack gap="300">
                  <Text variant="headingMd" as="h2">
                    Watch the Tutorial
                  </Text>
                  <Box
                    background="bg-surface-secondary"
                    minHeight="200px"
                    borderRadius="200"
                    overflowX="hidden"
                    overflowY="hidden"
                  >
                    {/* Placeholder for YouTube Video */}
                    <VideoThumbnail
                      videoLength={80}
                      thumbnailUrl="https://img.youtube.com/vi/dQw4w9WgXcQ/sddefault.jpg" // Replace with your video ID
                      onClick={() => console.log("Play video modal")}
                    />
                  </Box>
                  <Text variant="bodySm" as="p" tone="subdued">
                    Learn how to maximize your sales using our layout features.
                  </Text>
                </BlockStack>
              </Card>

              {/* Support Card */}
              <Card>
                <BlockStack gap="200">
                  <Text variant="headingSm" as="h3">
                    Need Help?
                  </Text>
                  <List>
                    <List.Item>Read Documentation</List.Item>
                    <List.Item>Contact Support</List.Item>
                  </List>
                </BlockStack>
              </Card>
            </BlockStack>
          </Layout.Section>
        </Layout>
      </BlockStack>
    </Page>
  );
}
