import { LoaderFunctionArgs, json } from "@remix-run/node";
import { retryOperation } from "~/functions/common";

export const loader = async ({ request }: LoaderFunctionArgs) => {
  try {
    const url = new URL(request.url);
    const searchquery = url.searchParams.get("searchQuery");
    const shopDomain = url.searchParams.get("shop");
    const searchterm = url.searchParams.get("searchTerm");

    const shop = await retryOperation(async () => {
      return await prisma.shops.findFirst({
        where: {
          shop_domain: shopDomain,
        },
      });
    });

    if (!shop) {
      return json({ error: "Shop not found" }, { status: 404 });
    }

    const products = await retryOperation(async () => {
      return await prisma.products.findMany({
        where: {
          product_shop_id: shop.shop_id,
          product_is_active: true,
          product_name: {
            contains: searchquery ?? "",
          },
        },
      });
    });
    return products;
  } catch (error) {
    console.error("Product fetch error:", error);
    return json({ activeProducts: [] }, { status: 500 });
  }
};
