import { json, LoaderFunctionArgs, TypedResponse } from "@remix-run/node";
import { retryOperation } from "~/functions/common";
import { fetchPaginatedProducts } from "~/functions/products";
import { authenticate } from "~/shopify.server";

export const loader = async ({
  request,
}: LoaderFunctionArgs): Promise<TypedResponse> => {
  console.log("API CALLED");
  const { admin } = await authenticate.admin(request);
  const url = new URL(request.url);
  const shopDomain = url.searchParams.get("shop");
  const selected = url.searchParams.get("selected") || "";

  try {
    // if (!shopPriceList?.shop_pricelist_id) {
    //   const priceListInput: PriceListInput = {
    //     parent: {
    //       settings: {
    //         compareAtMode: "ADJUSTED",
    //       },
    //       adjustment: {
    //         value: 0,
    //         type: "PERCENTAGE_DECREASE",
    //       },
    //     },
    //     name: "Cercle Custom PriceList",
    //     currency: shopPriceList?.shop_currency || "PKR",
    //   };

    //   const priceList = await createPriceList(admin, priceListInput);

    //   await prisma.shops.update({
    //     where: {
    //       shop_id: shopPriceList?.shop_id,
    //     },
    //     data: {
    //       shop_pricelist_id: priceList.id,
    //       updated_at: new Date(),
    //     },
    //   });
    // }

    const dbProducts = await retryOperation(async () => {
      return await prisma.products.findMany({
        where: {
          Shops: {
            shop_domain: shopDomain,
          },
        },
        select: {
          product_shopify_id: true,
          product_is_active: true,
          product_custom_category: true,
          product_brand_id: true,
          product_shop_id: true,
          product_custom_category_id: true,
          product_custom_category_hierarchy: true,
        },
      });
    });

    const {
      products: allShopifyProducts,
      hasNextPage,
      nextCursor,
    } = await fetchPaginatedProducts(
      admin,
      "next",
      null,
      selected,
      dbProducts && dbProducts.length > 0 ? dbProducts[0].product_shop_id : 0,
    );

    // Filter products based on total inventory greater than 0
    const filteredProducts = allShopifyProducts.filter(
      (product: any) => product.totalInventory > 0,
    );

    const products = { nodes: filteredProducts };

    return json({
      products: products,
      dbProducts,
      hasNextPage,
      nextCursor,
    });
  } catch (error: any) {
    console.error("Error fetching products:", error);
    throw new Response(error, { status: 500 });
  }
};
