import { ActionFunctionArgs, json } from "@remix-run/node";
import { getVariantImages } from "~/queries/variantImages";
import { authenticate } from "~/shopify.server";

export const action = async ({ request }: ActionFunctionArgs) => {
  console.log("variant images called");
  const { admin } = await authenticate.admin(request);

  try {
    const formData = await request.formData();
    const { method } = request;

    if (method === "POST" && formData.get("variantIds")) {
      const variantIds = formData.get("variantIds")?.toString().split(",");
      const shopDomain = formData.get("shopDomain")?.toString();

      if (!shopDomain) {
        return json({ error: "Missing shop" }, { status: 400 });
      }

      const variantsImages = await getVariantImages(
        admin,
        variantIds as string[],
      );

      return json({
        success: 200,
        message: "Images fetched successfully",
        data: variantsImages, // ✅ Send all collected data
      });
    }

    return json({ error: "Invalid request" }, { status: 400 });
  } catch (error) {
    console.error("Fetching Variant Images unsuccessful:", error);
    return json(
      { error: "Fetching Variant Images unsuccessful" },
      { status: 500 },
    );
  }
};
