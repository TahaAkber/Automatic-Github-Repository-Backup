import {
  json,
  LoaderFunctionArgs,
  TypedResponse,
  ActionFunctionArgs,
} from "@remix-run/node";
import { useFetcher, useLoaderData, useNavigate } from "@remix-run/react";
import { Button, Page } from "@shopify/polaris";
import { useEffect, useState } from "react";
import { Collection } from "~/components/collection/CollectionModal";
import CreateCollection from "~/components/collection/CreateCollection";
import { FilterProductGroup } from "~/components/collection/FilterCollection";
import { TrendingProductGroup } from "~/components/collection/TrendingCollection";
import { Loader } from "~/components/common/Loader";
import { uploadToShopify } from "~/functions/common";
import { createCollection } from "~/mutations/createCollection";
import { CollectionsQuery } from "~/queries/Collections";
import { authenticate } from "~/shopify.server";

interface FetcherData {
  success?: boolean;
  [key: string]: any;
}

export interface InsertCollectionLoaderReturn {
  search: string | undefined;
  Collections: any[];
  trendingCollections: any[];
  existingCollections: any[];
}

export const loader = async ({
  request,
}: LoaderFunctionArgs): Promise<
  TypedResponse<InsertCollectionLoaderReturn>
> => {
  const { admin } = await authenticate.admin(request);

  const url = new URL(request.url);
  const shopDomain = url.searchParams.get("shop");
  const collectionsResponse = await CollectionsQuery(admin);

  const Collections = collectionsResponse?.data?.collections?.nodes;

  if (!collectionsResponse?.data?.collections?.nodes) {
    throw new Error("Invalid collections response");
  }
  const shop = await prisma.shops.findFirst({
    where: { shop_domain: shopDomain },
    include: { Products: true },
  });

  const trendingCollections = await prisma.trending_Collections.findMany({});

  const ExistingDBcollections = await prisma.collections.findMany({
    where: {
      collection_shop_id: shop?.shop_id,
    },
  });

  return json({
    existingCollections: ExistingDBcollections,
    search: url.search,
    Collections: Collections,
    trendingCollections: trendingCollections,
  });
};

export const action = async ({ request }: ActionFunctionArgs) => {
  const { admin } = await authenticate.admin(request);
  if (!admin) {
    console.error("Authentication failed");
    return json({ error: "Authentication failed" }, { status: 401 });
  }
  const url = new URL(request.url);
  const shopDomain = url.searchParams.get("shop");
  const params = new URLSearchParams(url.search);
  try {
    const formData = await request.formData();
    const title = formData.get("title")?.toString();
    const description = formData.get("descriptionHtml")?.toString();
    const collection = formData.get("Collection")?.toString();
    const ProductIds = formData.get("ProductIds")?.toString().split(",");
    const filteredGroupsString = formData.get("FilteredGroups");
    const File = formData.get("File") as File | null;
    const collectedtype = formData.get("Collection_Type")?.toString();
    const trending_banner_url = formData.get("trendingimgsrc")?.toString();

    const shop = await prisma.shops.findFirst({
      where: {
        shop_domain: shopDomain,
      },
    });

    let imageSrc: string | null = null; // Declare outside the block
    if (
      filteredGroupsString &&
      typeof filteredGroupsString === "string" &&
      filteredGroupsString.length > 0
    ) {
      const filteredGroups = JSON.parse(filteredGroupsString);

      // Assuming you have an array of multiple collections
      const collections = filteredGroups.map((group: any) => {
        const productIds = group.products
          .map((product: any) => product.product_shopify_id)
          .filter(
            (productId: any) =>
              productId && productId.startsWith("gid://shopify/Product/"),
          );
        const input: any = {
          title: group.title,
          descriptionHtml: description || "",
          handle: `${collection}-${group.title?.replace(/\s+/g, "-")}`,
          products: productIds,
          // Extract product IDs from each group
          image: imageSrc ? { src: imageSrc } : null,
        };

        return input;
      });

      // Loop through each collection and create them
      for (const collectionInput of collections) {
        const response = await createCollection(admin, collectionInput);
        const responseBody = await response.json();

        if (!responseBody.success) {
          console.error("Collection creation failed:", responseBody);
          continue; // Skip to the next collection if creation fails
        }

        const collectionData = responseBody.result;

        const newCollection = await prisma.collections.create({
          data: {
            collection_type_id: parseInt(collectedtype as string),
            collection_shop_id: shop?.shop_id as number,
            collection_name: collectionData?.title,
            collection_shopify_id: collectionData?.id,
            collection_product_count: collectionData?.products?.nodes?.length,
            collection_condition: collectionData?.descriptionHtml,
            collection_banner_url: imageSrc,
            created_at: new Date(),
          },
        });

        const productNodes = collectionData?.products?.nodes || [];

        if (productNodes.length > 0) {
          // Step 1: Get array of Shopify GIDs
          const shopifyIds = productNodes.map((product: any) => product.id);

          // Step 2: Fetch all products from DB that match any of those GIDs
          const dbProducts = await prisma.products.findMany({
            where: {
              product_shopify_id: {
                in: shopifyIds,
              },
            },
          });

          // Step 3: Create a Set of valid IDs to filter only existing products
          const validproductid = new Set(
            dbProducts.map((p: any) => p.product_id),
          );

          // Step 3: Insert those matched products into collection_Products
          const insertPromises = dbProducts.map((product: any) =>
            prisma.collection_Products.create({
              data: {
                collection_product_name: product.product_name, // or product.product_name
                collection_id: newCollection.collection_id,
                collection_local_product_id: product.product_id, // or product.product_shopify_id if needed
              },
            }),
          );

          if (insertPromises.length > 0) {
            await Promise.all(insertPromises);
            console.log(
              `Inserted ${insertPromises.length} products into collection.`,
            );
          } else {
            console.warn("No matching products to insert.");
          }
        } else {
          console.warn("No productNodes found in collection.");
        }
      }
    } else if (parseInt(collectedtype as string) === 2) {
      const trendingCollectionJson = formData.get(
        "TrendingProductGroup",
      ) as string;
      const trendingCollection: TrendingProductGroup[] = JSON.parse(
        trendingCollectionJson,
      );
      console.log("trendingCollection", trendingCollection);

      const input: any[] = trendingCollection.map(
        (group: TrendingProductGroup) => {
          const productIds = group.products
            .map((product: any) => product.product_shopify_id)
            .filter(
              (productId: any) =>
                productId && productId.startsWith("gid://shopify/Product/"),
            );
          const input: any = {
            title: group.collection_type,
            descriptionHtml: group.collection_description || "",
            handle: `${collection}-${group.collection_type?.replace(/\s+/g, "-")}`,
            products: productIds,
            image: group.collection_banner_url
              ? { src: group.collection_banner_url }
              : null,
          };

          return input;
        },
      );

      input.forEach(async (collectionInput) => {
        const response = await createCollection(admin, collectionInput);
        const responseBody = await response.json();

        console.log("Response of Mutation trending:", responseBody.result);

        if (!responseBody.success) {
          console.error("Collection creation failed:", responseBody);
        }
        const collectionData = responseBody.result;

        const newCollection = await prisma.collections.create({
          data: {
            collection_type_id: parseInt(collectedtype as string),
            collection_shop_id: shop?.shop_id as number,
            collection_name: collectionData?.title,
            collection_shopify_id: collectionData?.id,
            collection_product_count: collectionData?.products?.nodes?.length,
            collection_condition: collectionData?.descriptionHtml,
            collection_banner_url: collectionData?.image?.url,
            created_at: new Date(),
          },
        });
        const productNodes = collectionData?.products?.nodes || [];

        if (productNodes.length > 0) {
          // Step 1: Get array of Shopify GIDs
          const shopifyIds = productNodes.map((product: any) => product.id);

          // Step 2: Fetch all products from DB that match any of those GIDs
          const dbProducts = await prisma.products.findMany({
            where: {
              product_shopify_id: {
                in: shopifyIds,
              },
            },
          });

          // Step 3: Create a Set of valid IDs to filter only existing products
          const validproductid = new Set(
            dbProducts.map((p: any) => p.product_id),
          );

          // Step 3: Insert those matched products into collection_Products
          const insertPromises = dbProducts.map((product: any) =>
            prisma.collection_Products.create({
              data: {
                collection_product_name: product.product_name, // or product.product_name
                collection_id: newCollection.collection_id,
                collection_local_product_id: product.product_id, // or product.product_shopify_id if needed
              },
            }),
          );

          if (insertPromises.length > 0) {
            await Promise.all(insertPromises);
            console.log(
              `Inserted ${insertPromises.length} products into collection.`,
            );
          } else {
            console.warn("No matching products to insert.");
          }
        } else {
          console.warn("No productNodes found in collection.");
        }
      });
    } else {
      if (File) {
        try {
          const imageUpload = await uploadToShopify(File, admin, File.name);
          console.log("Image Upload Response:", imageUpload);

          if (imageUpload) {
            const nodeId: string = imageUpload;

            const wait = (ms: number) =>
              new Promise((res) => setTimeout(res, ms));

            const getUploadedImageUrl = async (retries = 5, delay = 2000) => {
              for (let i = 0; i < retries; i++) {
                console.log(
                  `Fetching Uploaded Image URL... Attempt ${i + 1}/${retries}`,
                );

                const fileNodeQuery = `
            {
              nodes(ids: ["${nodeId}"]) {
                id
                ... on MediaImage {
                  image {
                    url
                    id
                  }
                }
              }
            }`;

                try {
                  const fileNodeResponse = await admin.graphql(fileNodeQuery);
                  const parsedNodeData = await fileNodeResponse.json();
                  const fetchedImageSrc =
                    parsedNodeData?.data?.nodes?.[0]?.image?.url;

                  if (fetchedImageSrc) {
                    return fetchedImageSrc;
                  }

                  console.log(
                    `Image URL not available yet, retrying in ${delay / 1000} seconds...`,
                  );
                  await wait(delay);
                } catch (error) {
                  console.error("Error fetching image URL:", error);
                }
              }
              throw new Error(
                "Image URL not available after multiple retries.",
              );
            };

            imageSrc = await getUploadedImageUrl(); // Assign value to the outer variable
            console.log("Uploaded Image URL:", imageSrc);
          }
        } catch (imageError) {
          console.error("Failed to upload image:", imageError);
        }
      }

      const input: any = {
        title,
        descriptionHtml: description,
        handle: `${collection}-${title?.replace(/\s+/g, "-")}`,
        products: ProductIds,
        image: imageSrc
          ? { src: imageSrc }
          : trending_banner_url
            ? { src: trending_banner_url }
            : null,
      };

      const response = await createCollection(admin, input);
      const responseBody = await response.json();

      if (!responseBody.success) {
        console.error("Collection creation failed:", responseBody);
      }
      const collectionData = responseBody.result;
      const shop = await prisma.shops.findFirst({
        where: {
          shop_domain: shopDomain,
        },
      });
      const Dbcollection = await prisma.collections.findMany({
        where: {
          collection_shop_id: shop?.shop_id,
        },
      });
      const newCollection = await prisma.collections.create({
        data: {
          collection_type_id: parseInt(collectedtype as string),
          collection_shop_id: shop?.shop_id as number,
          collection_name: collectionData?.title,
          collection_shopify_id: collectionData?.id,
          collection_product_count: collectionData?.products?.nodes?.length,
          collection_condition: collectionData?.descriptionHtml,
          collection_banner_url: imageSrc,
          created_at: new Date(),
        },
      });

      const productNodes = collectionData?.products?.nodes || [];

      if (productNodes.length > 0) {
        // Step 1: Get array of Shopify GIDs
        const shopifyIds = productNodes.map((product: any) => product.id);

        // Step 2: Fetch all products from DB that match any of those GIDs
        const dbProducts = await prisma.products.findMany({
          where: {
            product_shopify_id: {
              in: shopifyIds,
            },
          },
        });

        console.log("Matched DB products:", dbProducts);

        // Step 3: Create a Set of valid IDs to filter only existing products
        const validproductid = new Set(
          dbProducts.map((p: any) => p.product_id),
        );

        // Step 3: Insert those matched products into collection_Products
        const insertPromises = dbProducts.map((product: any) =>
          prisma.collection_Products.create({
            data: {
              collection_product_name: product.product_name, // or product.product_name
              collection_id: newCollection.collection_id,
              collection_local_product_id: product.product_id, // or product.product_shopify_id if needed
            },
          }),
        );

        if (insertPromises.length > 0) {
          await Promise.all(insertPromises);
          console.log(
            `Inserted ${insertPromises.length} products into collection.`,
          );
        } else {
          console.warn("No matching products to insert.");
        }
      } else {
        console.warn("No productNodes found in collection.");
      }
    }
    return json({ success: true });
  } catch (e) {
    console.error("Error creating collection:", e);
    return json({ success: false });
  }
};

export default function InsertCollection() {
  const navigate = useNavigate();
  const fetcher = useFetcher<FetcherData>();
  const { search, Collections, trendingCollections, existingCollections } =
    useLoaderData<InsertCollectionLoaderReturn>();
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [Collection, setCollection] = useState("custom");
  const [isLoading, setIsLoading] = useState(true);
  const [selectedproducts, setSelectedproducts] = useState<any[]>([]);
  const [files, setFiles] = useState<File[]>([]);
  const [selectchoices, setselectchoices] = useState<number[]>([1]);
  const [customCategory, setCustomCategory] = useState<any[]>([]);
  const [selectedCollections, setSelectedCollections] = useState<
    Collection[] | null
  >([]);
  const [mergedData, setMergedData] = useState<any[]>([]);
  const [isbuttonloading, setIsButtonLoading] = useState(false);
  const [FilteredProductsGroup, setFilteredProductsGroup] = useState<
    FilterProductGroup[]
  >([]);

  const [TrendingProductsGroup, setTrendingProductsGroup] = useState<
    TrendingProductGroup[]
  >([]);

  useEffect(() => {
    if (selectedCollections && selectedproducts.length > 0) {
      const merged = selectedproducts.map((product) => {
        return {
          ...product,
          collections: selectedCollections,
        };
      });
      setMergedData(merged);
    }
  }, [selectedCollections, selectedproducts]);

  useEffect(() => {
    if (fetcher.data) {
      setIsButtonLoading(false);
    }
  }, [fetcher.data]);

  useEffect(() => {
    setIsLoading(false);
  }, []);

  const handleSave = async () => {
    const formData = new FormData();

    if (mergedData.length > 0) {
      mergedData.forEach((data) => {
        if (data.collections && data.collections.length > 0) {
          data.collections.forEach((collection: any) => {
            formData.append("title", collection.trending_name);
            formData.append(
              "descriptionHtml",
              collection?.trending_description
                ? collection.trending_description
                : "",
            );
            formData.append("trendingimgsrc", collection?.trending_banner_url);
          });
        }
      });
    }

    formData.append("Collection", Collection);

    const ProductIds = selectedproducts.map(
      (product) => product.product_shopify_id,
    );
    formData.append("title", title);
    formData.append("descriptionHtml", description);
    formData.append(`ProductIds`, ProductIds.join(","));
    if (files && files.length > 0) {
      formData.append("File", files[0]);
    } else {
      console.log("No file selected");
    }

    formData.append("Collection_Type", selectchoices[0].toString());

    if (selectchoices[0].toString() === "2") {
      formData.append(
        "TrendingProductGroup",
        JSON.stringify(TrendingProductsGroup),
      );
    }

    if (FilteredProductsGroup.length > 0) {
      formData.append("FilteredGroups", JSON.stringify(FilteredProductsGroup));
    }
    console.log("formdata", Object.fromEntries(formData.entries()));

    fetcher.submit(formData, {
      method: "POST",
      encType: "multipart/form-data",
    });

    setSelectedproducts([]);
    // setTitle("");
    // setDescription("");
    setFilteredProductsGroup([]);
    setMergedData([]);
    // setSelectedCollections([]);
    setIsButtonLoading(true);
  };

  useEffect(() => {
    if (fetcher?.data?.success === true) {
      const choice = selectchoices[0]?.toString();

      if (choice === "1") {
        navigate(`/app/collection?${search}`, {
          relative: "path",
          state: { some: "0" },
        });
      } else if (choice === "2") {
        navigate(`/app/collection?${search}`, {
          relative: "path",
          state: { some: "1" },
        });
      } else if (choice === "3") {
        navigate(`/app/collection?${search}`, {
          relative: "path",
          state: { some: "2" },
        });
      }
    }
  }, [fetcher?.data, selectchoices]);

  if (isLoading) {
    return (
      <Page fullWidth>
        <Loader />
      </Page>
    );
  }

  console.log("trendingCollections", trendingCollections);
  console.log("selectedCollections", selectedCollections);
  console.log("selectchoices", selectchoices);
  return (
    <Page
      backAction={{
        content: "Back to Collections",
        onAction: () => navigate({ pathname: "/app/collection", search }),
      }}
      title="Create Collection"
      fullWidth
      primaryAction={
        <Button
          variant="primary"
          onClick={handleSave}
          loading={isbuttonloading}
        >
          Save
        </Button>
      }
    >
      <CreateCollection
        Title={title}
        files={files}
        setTitle={setTitle}
        setFiles={setFiles}
        Collection={Collection}
        mergedData={mergedData}
        Description={description}
        Collections={Collections}
        selectchoices={selectchoices}
        existingCollections={existingCollections}
        setCollection={setCollection}
        setDescription={setDescription}
        customCategory={customCategory}
        setselectchoices={setselectchoices}
        selectedproducts={selectedproducts}
        setCustomCategory={setCustomCategory}
        setSelectedproducts={setSelectedproducts}
        trendingCollections={trendingCollections}
        FilteredProductsGroup={FilteredProductsGroup}
        TrendingProductsGroup={TrendingProductsGroup}
        setSelectedCollections={setSelectedCollections}
        setFilteredProductsGroup={setFilteredProductsGroup}
        setTrendingProductsGroup={setTrendingProductsGroup}
        selectedCollections={selectedCollections as Collection[]}
        search={search}
      />
    </Page>
  );
}
