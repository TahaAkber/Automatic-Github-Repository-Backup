import {
  ActionFunctionArgs,
  json,
  LoaderFunctionArgs,
  TypedResponse,
} from "@remix-run/node";
import { useFetcher, useLoaderData } from "@remix-run/react";
import { Page, Layout, Text, Divider } from "@shopify/polaris";
import Accountsection from "~/components/accounts/Accountsection";
import { useState, useCallback, useMemo, useEffect, useRef } from "react";
import { useNavigate } from "@remix-run/react";

interface AccountsLoader {
  search: string;
  shop: any;
  APP_URL: any;
}

export const loader = async ({
  request,
}: LoaderFunctionArgs): Promise<TypedResponse<AccountsLoader>> => {
  const url = new URL(request.url);
  const shopDomain = url.searchParams.get("shop");

  if (!shopDomain) {
    throw new Response("Missing shop domain", { status: 400 });
  }

  try {
    // const { admin } = await authenticate.admin(request);
    const APP_URL = process.env.APP_URL;
    const shop = await prisma.shops.findFirst({
      where: {
        shop_domain: shopDomain,
      },
    });
    return json({
      search: url.search,
      shop,
      APP_URL,
    });
  } catch (error) {
    console.error("Error in loader:", error);
    return json({
      search: "",
      shop: [],
      APP_URL: "",
    });
  }
};

export const action = async ({ request }: ActionFunctionArgs) => {
  // const { admin } = await authenticate.admin(request);
  const formData = await request.formData();
  const shopDomain = formData.get("shop_domain")?.toString();

  const shop = await prisma.shops.findFirst({
    where: {
      shop_domain: shopDomain,
    },
  });

  if (!shop) {
    return json({ success: false, message: "Shop not found" }, { status: 400 });
  }

  await prisma.shops.update({
    where: {
      shop_id: shop.shop_id,
    },
    data: {
      shop_is_active: false,
    },
  });

  return json({
    success: true,
    message: "Shop disconnected successfully",
  });
};

export default function () {
  const [authStatus, setAuthStatus] = useState<"idle" | "success" | "error">(
    "idle",
  );
  const popupRef = useRef<Window | null>(null);
  const { search, shop, APP_URL } = useLoaderData<AccountsLoader>();
  const fetcher = useFetcher();

  const [newEmail, setNewEmail] = useState("");
  const [newEmailError, setNewEmailError] = useState<string | undefined>();
  const navigate = useNavigate();
  const isValidEmail = useCallback((v: string) => {
    if (!v) return false;
    // simple, safe email check
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
  }, []);

  const isNewEmailValid = useMemo(() => {
    if (!newEmail) return true; // empty allowed; we’ll use existingAccountEmail / no email
    return isValidEmail(newEmail);
  }, [newEmail, isValidEmail]);

  const appOrigin = useMemo(() => {
    try {
      return new URL(APP_URL || "").origin;
    } catch {
      return window.location.origin;
    }
  }, [APP_URL]);

  // Builds search string adding/updating the "email" param if provided

  const buildSearch = useCallback((email?: string, shopDomain?: string) => {
    const usp = new URLSearchParams();
    if (shopDomain) usp.set("shop_domain", shopDomain);
    if (email) usp.set("email", email);

    const qs = usp.toString();
    return qs ? `?${qs}` : "";
  }, []);

  const handleAuthorize = useCallback(
    (email?: string) => {
      if (email && !isValidEmail(email)) {
        setNewEmailError("Enter a valid email");
        return;
      }
      setNewEmailError(undefined);
      const url = `${APP_URL}/connect${buildSearch(email, shop.shop_domain)}`;

      const w = 600,
        h = 560;
      const left = window.screenX + (window.outerWidth - w) / 2;
      const top = window.screenY + (window.outerHeight - h) / 2;

      const win = window.open(
        url,
        "authPopup",
        `width=${w},height=${h},left=${left},top=${top},scrollbars=yes,resizable=no,menubar=no,toolbar=no,location=no,status=no`,
      );
      popupRef.current = win || null;
      win?.focus();
    },
    [APP_URL, buildSearch, isValidEmail, shop?.shop_domain],
  );

  // postMessage listener (fallback / non-embedded)
  useEffect(() => {
    function onMessage(e: MessageEvent) {
      // console.log("[parent] postMessage from", e.origin, e.data);
      if (e.data?.type !== "oauth:done") return;

      // strict origin check — but safe in dev when APP_URL is unset
      if (e.origin !== appOrigin) {
        console.warn(
          "[parent] ignored message from unexpected origin",
          e.origin,
          "expected",
          appOrigin,
          "data",
          e.data,
        );
        return;
      }

      setAuthStatus(e.data.success ? "success" : "error");
      try {
        popupRef.current?.close();
      } catch {}
      popupRef.current = null;
    }
    window.addEventListener("message", onMessage);
    return () => window.removeEventListener("message", onMessage);
  }, [appOrigin]);

  useEffect(() => {
    if (authStatus === "success") {
      // console.log("first load", shop.shop_first_load);
      setTimeout(() => {
        if (shop.shop_first_load) {
          navigate(`/selectcategory${search}`, { replace: true });
        } else {
          navigate(`/app${search}`, { replace: true });
        }
      }, 2000);
    }
    // console.log("authStatus", authStatus);
  }, [authStatus]);

  const handleDisconnectAccount = async () => {
    const form = new FormData();
    form.append("shop_domain", shop?.shop_domain);
    fetcher.submit(form, { method: "POST" });
  };

  return (
    <Page title="Accounts" fullWidth>
      <Layout>
        <Layout.Section>
          <div style={{ flexDirection: "column", display: "flex", gap: 30 }}>
            <div style={{ marginLeft: "15px" }}>
              <div
                style={{ flexDirection: "column", display: "flex", gap: "5px" }}
              >
                <Text variant="headingMd" as="p">
                  Welcome to Cercle Market Place
                </Text>
                <Text variant="bodyMd" as="p" tone="disabled">
                  Lets Get You To Setup so you can sell your products on cercle
                </Text>
                <Divider borderWidth="050" borderColor="border-disabled" />
              </div>
            </div>
            <div>
              <div style={{ marginLeft: "15px" }}>
                <div
                  style={{
                    flexDirection: "column",
                    display: "flex",
                    gap: "5px",
                  }}
                >
                  <Text variant="headingMd" as="p">
                    Stay Connected With Cercle
                  </Text>
                  <Text variant="bodyMd" as="p" tone="disabled">
                    Connect your cercle exprience accross platforms. Follow us
                    on Facebook and Instagram for the latest Updates. product
                    Highlights, and community stories. Subscribe via Mailchimp
                    to recieve personalized newsletters, exclusive offers and
                    early access to new Arrivals-Delivered straight to your
                    inbox.
                  </Text>
                </div>
              </div>
            </div>
          </div>
        </Layout.Section>

        <Layout.Section variant="fullWidth">
          <Layout.Section variant="fullWidth">
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
              }}
            >
              <Accountsection
                shop={shop}
                App="Cercle"
                search={search}
                newEmail={newEmail}
                setNewEmail={setNewEmail}
                isValidEmail={isValidEmail}
                newEmailError={newEmailError}
                isNewEmailValid={isNewEmailValid}
                handleAuthorize={handleAuthorize}
                setNewEmailError={setNewEmailError}
                existingAccountEmail={shop.shop_email}
                handleAccountDisconnect={handleDisconnectAccount}
                termsUrl="https://cymbiote.com/terms-conditions/"
                connected={authStatus === "success" || shop?.shop_is_active}
              />
            </div>
          </Layout.Section>
        </Layout.Section>
      </Layout>
    </Page>
  );
}
