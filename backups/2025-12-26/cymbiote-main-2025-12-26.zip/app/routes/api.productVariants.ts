import { ActionFunctionArgs, json } from "@remix-run/node";
import { authenticate } from "~/shopify.server"; // Assuming you use this to get `admin`

export const loader = async ({ request }: ActionFunctionArgs) => {
  try {
    const url = new URL(request.url);
    const productId = url.searchParams.get("productId") || "";
    const { admin } = await authenticate.admin(request);

    const query = `
      query getProductVariants($id: ID!) {
        product(id: $id) {
          variants(first: 100) {
            nodes {
              id
              title
              price
              inventoryQuantity
              inventoryItem {
                id
              }
            }
          }
        }
      }
    `;

    const variables = {
      id: productId,
    };

    const response = await admin.graphql(query, { variables });
    const jsonData = await response.json();

    const shopifyVariants = jsonData.data.product?.variants.nodes || [];

    const formattedVariants = shopifyVariants.map((variant: any, index: number) => ({
      variant_shopify_id: variant.id,
      variant_price: parseFloat(variant.price),
      variant_discounted_price: 0,
      variant_quantity: variant.inventoryQuantity,
      variant_color: null,
      variant_temp_id: index,
      variant_name: variant.title,
      variant_inventory_id: variant.inventoryItem?.id || null,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    }));

    return json({
      productVariants: formattedVariants,
    });
  } catch (error) {
    console.error("Error fetching product variants from Shopify:", error);
    throw new Error("Error fetching product variants");
  }
};
