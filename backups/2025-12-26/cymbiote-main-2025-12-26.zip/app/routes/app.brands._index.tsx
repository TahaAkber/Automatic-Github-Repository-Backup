import { useEffect, useMemo, useState } from "react";
import type {
  ActionFunctionArgs,
  LoaderFunctionArgs,
  TypedResponse,
} from "@remix-run/node";
import { json } from "@remix-run/node";
import { useFetcher, useLoaderData, useNavigate } from "@remix-run/react";
import {
  FormLayout,
  InlineStack,
  Layout,
  Page,
  Text,
  TextField,
} from "@shopify/polaris";
import { authenticate } from "../shopify.server";
import { Loader } from "~/components/common/Loader";
import DropZoneExample from "~/components/collection/DropZone";
import BrandLogo from "~/components/brands/BrandLogo";
import BrandForm from "~/components/brands/BrandForm";
import { uploadToShopify } from "~/functions/common";

interface LoaderReturn {
  result: string;
  searchTerm: string;
}
interface ReturnAction {
  result: string;
}
type FormData = {
  name: string;
  website: string;
  description: string;
};

export const action = async ({
  request,
}: ActionFunctionArgs): Promise<TypedResponse<ReturnAction>> => {
  const { admin, redirect } = await authenticate.admin(request);

  const formData = await request.formData();
  const url = new URL(request.url);
  const shopDomain = url.searchParams.get("shop");

  const BrandName = formData.get("BrandName") as string;
  const Brandwebsite = formData.get("BrandWebsite") as string;
  const Branddescription = formData.get("BrandDescription") as string;
  const brandLogoFile = formData.get("BrandLogo") as File | null;

  console.log("Brand Name ", BrandName);
  console.log("Brand website ", Brandwebsite);
  console.log("Brand description ", Branddescription);
  console.log("Brand logo new ", brandLogoFile);
  let imageSrc: string | null = null;

  if (brandLogoFile) {
    try {
      const imageUpload = await uploadToShopify(
        brandLogoFile,
        admin,
        brandLogoFile.name,
      );
      console.log("Image Upload Response:", imageUpload);

      if (imageUpload) {
        const nodeId: string = imageUpload;

        const wait = (ms: number) => new Promise((res) => setTimeout(res, ms));

        const getUploadedImageUrl = async (retries = 5, delay = 2000) => {
          for (let i = 0; i < retries; i++) {
            console.log(
              `Fetching Uploaded Image URL... Attempt ${i + 1}/${retries}`,
            );

            const fileNodeQuery = `
                  {
                    nodes(ids: ["${nodeId}"]) {
                      id
                      ... on MediaImage {
                        image {
                          url
                          id
                        }
                      }
                    }
                  }`;

            try {
              const fileNodeResponse = await admin.graphql(fileNodeQuery);
              const parsedNodeData = await fileNodeResponse.json();
              const fetchedImageSrc =
                parsedNodeData?.data?.nodes?.[0]?.image?.url;
              console.log("Fetched Image URL:", parsedNodeData?.data?.nodes);
              if (fetchedImageSrc) {
                return fetchedImageSrc;
              }

              console.log(
                `Image URL not available yet, retrying in ${delay / 1000} seconds...`,
              );
              await wait(delay);
            } catch (error) {
              console.error("Error fetching image URL:", error);
            }
          }
          throw new Error("Image URL not available after multiple retries.");
        };

        imageSrc = await getUploadedImageUrl(); // Assign value to the outer variable
        console.log("Uploaded Image URL:", imageSrc);
      }
    } catch (imageError) {
      console.error("Failed to upload image:", imageError);
    }
  }
  try {
    const brand = await prisma.brands.create({
      data: {
        brand_name: BrandName,
        brand_website_url: Brandwebsite,
        brand_logo_url: imageSrc,
      },
    });
    const shop = await prisma.shops.findFirst({
      where: {
        shop_domain: shopDomain,
      },
    });

    if (!shop) {
      throw new Error("Shop not found for the given shop domain.");
    }

    await prisma.brand_Approvals.create({
      data: {
        brand_approval_brand_id: brand?.brand_id,
        brand_approval_shop_id: shop.shop_id,
        brand_approval_description: Branddescription,
        brand_approval_is_approved: false,
      },
    });
  } catch (error) {
    console.log("Error creating brand:", error);
    return json({ result: "error" });
  }

  return json({ result: "success" });
};

export const loader = async ({
  request,
}: LoaderFunctionArgs): Promise<TypedResponse<LoaderReturn>> => {
  const { admin } = await authenticate.admin(request);
  const url = new URL(request.url);
  const shopDomain = url.searchParams.get("shop");
  const searchTerm = url.searchParams.get("searchTerm") || "";
  return json({ result: "success", searchTerm });
};

export const Index = () => {
  const fetcher = useFetcher();
  const [loading, setLoading] = useState(false);
  const { searchTerm } = useLoaderData<LoaderReturn>();
  const [isPostBack, setIsPostBack] = useState(false);
  const [formData, setFormData] = useState<FormData>({
    name: "",
    website: "",
    description: "",
  });

  // Lift logo state here and pass to children if needed later (submit, etc.)
  const [logoFiles, setLogoFiles] = useState<File[]>([]);
  const logoPreview = useMemo(
    () => (logoFiles[0] ? URL.createObjectURL(logoFiles[0]) : null),
    [logoFiles],
  );

  const handleSave = () => {
    setLoading(true);
    const form = new FormData();
    form.append("BrandName", formData.name);
    form.append("BrandWebsite", formData.website);
    form.append("BrandDescription", formData.description);

    form.append("BrandLogo", logoFiles[0]);

    fetcher.submit(form, { method: "POST", encType: "multipart/form-data" });
  };
  const handleCancel = () => {
    console.log("handle cancel click");
    setFormData({ name: "", website: "", description: "" });
    setLogoFiles([]);
  };
  const removeLogo = () => setLogoFiles([]);
  const navigate = useNavigate();

  // console.log("selectedProducts", selectedProducts);
  useEffect(() => {
    setIsPostBack(true);
  }, []);

  useEffect(() => {
    const r = (fetcher.data as { result?: string } | undefined)?.result;
    if (r === "success") {
      setLoading(false);
      setFormData({ name: "", website: "", description: "" });
      setLogoFiles([]);
    }
  }, [fetcher.data]);

  if (!isPostBack) {
    return (
      <Page fullWidth>
        <Loader />
      </Page>
    );
  }

  return (
    <Page
      backAction={{
        content: "Brands",
        onAction: () =>
          navigate({
            pathname: "/app",
            search: `?searchTerm=${encodeURIComponent(searchTerm)}`,
          }),
      }}
      title="Brands"
      primaryAction={{
        content: "Save",
        onAction: () => handleSave(),
        loading: loading,
        disabled: !(
          formData.name &&
          formData.website &&
          formData.description &&
          logoFiles.length > 0
        ),
      }}
      secondaryActions={[{ content: "Cancel", onAction: () => handleCancel() }]}
      fullWidth
    >
      <Text variant="headingLg" as="h3">
        Register Your Brand
      </Text>
      <BrandLogo
        logoPreview={logoPreview}
        removeLogo={removeLogo}
        logoFiles={logoFiles}
        setLogoFiles={setLogoFiles}
        setFormData={setFormData}
        formData={formData}
      />
    </Page>
  );
};

export default Index;
