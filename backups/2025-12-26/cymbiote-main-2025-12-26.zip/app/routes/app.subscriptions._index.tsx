import {
  ActionFunctionArgs,
  json,
  LoaderFunctionArgs,
  redirect,
  TypedResponse,
} from "@remix-run/node";
import { useLoaderData, useNavigate } from "@remix-run/react";
import {
  BlockStack,
  Box,
  Card,
  InlineStack,
  Layout,
  Page,
  Text,
} from "@shopify/polaris";
import { useEffect, useState } from "react";
import { Loader } from "~/components/common/Loader";
import {
  fetchAllTransactions,
  fetchFilteredTransactions,
} from "~/functions/transaction";
import { authenticate } from "~/shopify.server";
import { TransectionsLoaderReturn } from "~/types/TrasectionsLoaderReturn";
import {
  fetchAllAppSubscriptions,
  fetchAppInstallation,
  syncSubsEfficient,
} from "~/queries/App";
import { getCycleDates } from "~/functions/app";
import { BillingPanel } from "~/components/transactions/BillingPanel";

// type ActionResponse = {
//   success: boolean;
//   message: string;
//   transactions: any[];
//   totalTransactions: number;
//   itemsPerPage: number;
//   currentPage: number;
//   search: string;
// };

export const loader = async ({
  request,
}: LoaderFunctionArgs): Promise<TypedResponse<TransectionsLoaderReturn>> => {
  const { admin } = await authenticate.admin(request);
  const url = new URL(request.url);
  const shopDomain = url.searchParams.get("shop");
  const page = Number(url.searchParams.get("page")) || 1;
  const itemsPerPage = 10; // Number of items per page
  const skip = (page - 1) * itemsPerPage;

  // Load session using the shop domain
  const shop = await prisma.shops.findFirst({
    where: {
      shop_domain: shopDomain,
    },
  });
  console.log("shop_id inside loader", shop?.shop_id);

  try {
    const appInstalledData = await fetchAppInstallation(admin);

    console.log("appInstalledData", appInstalledData);

    const billingCycle = getCycleDates(
      appInstalledData?.activeSubscriptions[0],
    );

    const allTransactions = await fetchAllAppSubscriptions(admin);

    // console.log("allTransactions", allTransactions);

    if (allTransactions && allTransactions.allSubscriptions) {
      await syncSubsEfficient(
        allTransactions.allSubscriptions,
        shop?.shop_id as number,
      );
    }

    // Fetch total count of transactions
    const totalSubscriptions = await prisma.subscriptions.count({
      where: {
        subscription_shop_id: shop?.shop_id,
      },
    });

    const shopSubscriptions = await prisma.subscriptions.findMany({
      where: {
        subscription_shop_id: shop?.shop_id,
        subscription_confirmed: true,
      },
      include: {
        Transactions: true,
        Packages: true,
        Shops: true,
      },
      orderBy: {
        subscription_charge_date: "desc",
      },
    });

    return json({
      subscriptions: shopSubscriptions as any,
      totalSubscriptions,
      itemsPerPage,
      currentPage: page,
      search: url.search,
      billingCycle,
    });
  } catch (error) {
    console.error("Error getting transactions:", error);
    throw new Response("Error getting transactions", {
      status: 500,
    });
  }
};

export const action = async ({ request }: ActionFunctionArgs) => {
  console.log("transaction action called");
  // const { admin } = await authenticate.admin(request);
  const url = new URL(request.url);
  const params = new URLSearchParams(url.search);
  const queryString = params.toString();
  const shopDomain = url.searchParams.get("shop");
  const page = 1;
  const itemsPerPage = 10; // Number of items per page

  // Load session using the shop domain
  const shop = await prisma.shops.findFirst({
    where: {
      shop_domain: shopDomain,
    },
  });

  if (!shop) {
    return json(
      {
        error: "shop not found",
      },
      { status: 404 },
    );
  }

  const formData = await request.formData();
  const actionType = formData.get("actionType") as string;

  if (actionType === "filterTransactions") {
    const startDate = new Date(formData.get("startDate") as string);
    const endDate = new Date(formData.get("endDate") as string);
    const currentDatetime = new Date();

    // Check if the dates match today's date
    const isToday =
      startDate.toDateString() === currentDatetime.toDateString() &&
      endDate.toDateString() === currentDatetime.toDateString();

    if (isToday) {
      // Reset filter if dates match today's date
      const totalTransactions = await prisma.transactions.count({
        where: {
          transaction_shop_id: shop?.shop_id,
        },
      });

      const transactionsWithOrders = await fetchAllTransactions(
        shop?.shop_id,
        page,
        itemsPerPage,
      );

      return json({
        transactions: transactionsWithOrders || [],
        totalTransactions,
        itemsPerPage,
        currentPage: page,
        search: url.search,
        message: "All Transactions fetched",
        success: true,
      });
    } else {
      // Fetch filtered transactions based on the selected date range
      const transactionsWithOrders = await fetchFilteredTransactions(
        shop?.shop_id,
        startDate,
        endDate,
      );

      return json({
        transactions: transactionsWithOrders || [],
        totalTransactions: transactionsWithOrders.length,
        itemsPerPage, // Assuming a fixed number of items per page
        currentPage: 1, // Reset to first page after filtering
        search: url.search,
        message: "Transactions filtered successfully",
        success: true,
      });
    }
  } else {
    const orderId = formData.get("orderId") as string;
    const updateSessions = await prisma.shops.update({
      data: {
        shop_selectedOrder: orderId,
        updated_at: new Date(),
      },
      where: {
        shop_id: shop?.shop_id,
      },
    });

    const redirectUrl = `/app/orders/orderdetails?${queryString}`;
    return redirect(redirectUrl);
  }
};

export default function Transactions() {
  const navigate = useNavigate();
  const { search, subscriptions } = useLoaderData<TransectionsLoaderReturn>();
  const [isPostBack, setIsPostBack] = useState(false);

  useEffect(() => {
    setIsPostBack(true);
  }, []);

  if (!isPostBack) {
    return (
      <Page fullWidth>
        <Loader />
      </Page>
    );
  }

  return (
    <Page
      backAction={{
        content: "Transactions",
        onAction: () => navigate({ pathname: "/app", search }),
      }}
      title="Transactions"
      fullWidth
    >
      <Layout>
        <Layout.Section variant="oneThird">
          <Card padding={"0"}>
            <Box padding="300">
              <BlockStack gap="400">
                <InlineStack align="space-between" blockAlign="center">
                  <Text as="h2" variant="headingMd" fontWeight="semibold">
                    Cercle Transaction Breakdown
                  </Text>

                  {/* optional icon spot */}
                  {/* <Icon source={IconsIcon} /> */}
                </InlineStack>
                {subscriptions.length !== 0 &&
                  subscriptions.map((subs, index) => {
                    const startdate = new Date(
                      subs.subscription_created_at,
                    ).toLocaleDateString("en-GB");

                    const enddate = new Date(
                      subs.subscription_ends_at,
                    ).toLocaleDateString("en-GB");

                    const useagetransactions = subs.Transactions?.filter(
                      (tr: any) =>
                        tr.transaction_type.toLowerCase() === "usage",
                    );

                    const creditsAmount = subs.Transactions?.reduce(
                      (acc: number, tr: any) => {
                        if (tr.transaction_type.toLowerCase() === "credit") {
                          return acc + (Number(tr.transaction_amount_usd) || 0);
                        }
                        return acc;
                      },
                      0,
                    );

                    const useageTrasactionAmount = subs.Transactions?.reduce(
                      (acc: number, tr: any) => {
                        if (tr.transaction_type.toLowerCase() === "usage") {
                          return acc + (Number(tr.transaction_amount_usd) || 0);
                        }
                        return acc;
                      },
                      0,
                    );

                    const tileSubscriptionOn =
                      subs.subscription_tile_charges > 0;

                    return (
                      <BillingPanel
                        subscriptionId={subs.subscription_id}
                        subscriptionDesc={subs.Packages.package_description}
                        periodLabel={startdate + " - " + enddate}
                        usageCount={useagetransactions.length || 0}
                        creditAmount={creditsAmount.toFixed(2) || "0.00"}
                        tileSubscription={tileSubscriptionOn}
                        trackingEnabled={subs.subscription_tracking_active}
                        defaultOpen={index === 0}
                        subscriptionName={
                          subs.Packages.package_name || "Plan Name"
                        }
                        usageAmount={
                          useageTrasactionAmount.toFixed(2) || "0.00"
                        }
                        subscriptionCharges={
                          subs.subscription_package_charges?.toFixed(2) ||
                          "0.00"
                        }
                        usageRateLabel={
                          subs.Packages.package_rate + "% of order is charged"
                        }
                        tileCharges={
                          subs?.subscription_tile_charges?.toFixed(2) || "0.00"
                        }
                        trackingCharges={
                          subs?.subscription_tracking_charges?.toFixed(2) ||
                          "0.00"
                        }
                      />
                    );
                  })}
              </BlockStack>
            </Box>
          </Card>
        </Layout.Section>

        <Layout.Section>{/* other content */}</Layout.Section>
      </Layout>
    </Page>
  );
}
