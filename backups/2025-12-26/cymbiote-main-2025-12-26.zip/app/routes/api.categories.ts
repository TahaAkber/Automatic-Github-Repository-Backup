import { ActionFunctionArgs, json } from "@remix-run/node";
import axios from "axios";
import { retryOperation } from "~/functions/common";

const API_VERSION = process.env.SHOPIFY_API_VERSION || "2025-07";

export const loader = async ({ request }: ActionFunctionArgs) => {
  try {
    const url = new URL(request.url);
    const searchTerm = url.searchParams.get("searchTerm") || "";
    const shopDomain = url.searchParams.get("shop") || "";

    // const { admin } = await authenticate.admin(request);

    const shop = await retryOperation(async () => {
      return await prisma.shops.findFirst({
        where: {
          shop_domain: shopDomain,
        },
      });
    });

    const { shop_access_token } = shop || {};

    // Build the GraphQL query for Shopify
    const query = `
      {
        taxonomy {
          categories(first: 25 ${searchTerm ? ', search: "' + searchTerm + '"' : ""}) {
            nodes {
              name
              fullName
              isRoot
              id
              ancestorIds
            }
          }
        }
      }`;

    // Make the API request to Shopify's GraphQL endpoint
    const apiUrl = `https://${shopDomain}/admin/api/${API_VERSION}/graphql.json`;
    const response = await axios.post(
      apiUrl,
      { query },
      {
        headers: {
          "X-Shopify-Access-Token": shop_access_token || "",
          "Content-Type": "application/json",
        },
      },
    );

    // Extract categories data
    const productCategories = response.data?.data;

    // Return the categories in the same format as the `getProductTaxonomyUsingName` function
    return json({
      productCategories, // Return the categories as the loader result
    });
  } catch (error: any) {
    console.error("Category fetch error message", error.message);
    return new Response("Failed to fetch categories", { status: 500 });
  }
};
