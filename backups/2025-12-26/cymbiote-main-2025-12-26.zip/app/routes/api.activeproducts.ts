import { LoaderFunctionArgs, json } from "@remix-run/node";
import { retryOperation } from "~/functions/common";

export const loader = async ({ request }: LoaderFunctionArgs) => {
  try {
    const url = new URL(request.url);
    const shopDomain = url.searchParams.get("shop");
    console.log("Shop domain: " + shopDomain);
    console.log("url: " + url);

    const shop = await retryOperation(async () => {
      return await prisma.shops.findFirst({
        where: {
          shop_domain: shopDomain,
        },
        include: {
          Products: true,
        },
      });
    });

    const activeProducts = shop?.Products.filter(
      (product) => product.product_is_active,
    );

    return json(activeProducts);
  } catch (error) {
    console.error("Product fetch error:", error);
    return json({ activeProducts: [] }, { status: 500 });
  }
};
