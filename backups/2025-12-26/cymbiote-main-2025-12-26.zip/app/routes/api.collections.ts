import { json, LoaderFunctionArgs, TypedResponse } from "@remix-run/node";
import { retryOperation } from "~/functions/common";
import { CollectionsQuery } from "~/queries/Collections";
import { authenticate } from "~/shopify.server";
import { CollectionLoader } from "~/types/CollectionLoader";

export const loader = async ({
  request,
}: LoaderFunctionArgs): Promise<TypedResponse<CollectionLoader>> => {
  const url = new URL(request.url);
  const shopDomain = url.searchParams.get("shop");

  if (!shopDomain) {
    throw new Response("Missing shop domain", { status: 400 });
  }

  try {
    const { admin } = await authenticate.admin(request);

    const collectionsResponse = await CollectionsQuery(admin);

    if (!collectionsResponse?.data?.collections?.nodes) {
      throw new Error("Invalid collections response");
    }
    const shop = await retryOperation(async () => {
      return await prisma.shops.findFirst({
        where: {
          shop_domain: shopDomain,
        },
      });
    });

    const filterCollection = await retryOperation(async () => {
      return await prisma.collections.findMany({
        where: {
          collection_shop_id: shop?.shop_id,
          collection_type_id: 3,
        },
        include: {
          Collection_Types: true,
        },
      });
    });

    const trendingCollection = await retryOperation(async () => {
      return await prisma.collections.findMany({
        where: {
          collection_shop_id: shop?.shop_id,
          collection_type_id: 2,
        },
        include: {
          Collection_Types: true,
        },
      });
    });

    const simpleCollection = await retryOperation(async () => {
      return await prisma.collections.findMany({
        where: {
          collection_shop_id: shop?.shop_id,
          collection_type_id: 1,
        },
        include: {
          Collection_Types: true,
        },
      });
    });

    const shopifyCollections =
      collectionsResponse?.data?.collections?.nodes || [];
    const shopifyCollectionIds =
      collectionsResponse?.data?.collections?.nodes.map((node: any) => node.id);

    const filterTrendingAndSimpleIds = new Set([
      ...(filterCollection ?? []).map((c: any) => c.collection_shopify_id),
      ...(trendingCollection ?? []).map((c: any) => c.collection_shopify_id),
      ...(simpleCollection ?? []).map((c: any) => c.collection_shopify_id),
    ]);

    const filteredShopifyCollections = shopifyCollections.filter(
      (collection: any) => !filterTrendingAndSimpleIds.has(collection.id),
    );

    return json({
      search: url.search,
      collections: simpleCollection || [],
      filterCollection: filterCollection || [],
      trendingCollection: trendingCollection || [],
      shopifyCollections: filteredShopifyCollections || [],
    });
  } catch (error) {
    console.error("Error in loader:", error);
    return json(
      {
        search: "",
        collections: [],
        filterCollection: [],
        trendingCollection: [],
        shopifyCollections: [],
        error: "Failed to load data",
      },
      { status: 500 },
    );
  }
};
