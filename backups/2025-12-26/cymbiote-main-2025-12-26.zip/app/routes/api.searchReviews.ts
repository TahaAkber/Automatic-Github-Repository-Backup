import { LoaderFunctionArgs, json } from "@remix-run/node";

export const loader = async ({ request }: LoaderFunctionArgs) => {
  try {
    const url = new URL(request.url);
    const shopDomain = url.searchParams.get("shop");
    const searchquery = url.searchParams.get("searchQuery");
    const searchterm = url.searchParams.get("searchTerm");
   
    const shop = await prisma.shops.findFirst({
      where: {
        shop_domain: shopDomain,
      },
    });

    const orderItems = await prisma.order_Items.findMany({
      where: {
        Orders: {
          order_shop_id: shop?.shop_id,
        },
        Product_Variants: {
          Products: {
            product_name: {
              contains: searchquery ?? "",
            },
          },
        },
        Order_Item_Review: {
          some: {},
        },
      },
      include: {
        Order_Item_Review: {
          include: {
            Review_Comments: true,
            Review_Images: true,
          },
        },
        Orders: {
          include: {
            Users: true,
          },
        },
        Product_Variants: {
          include: {
            Products: true,
          },
        },
      },
    });

    return json(orderItems);
  } catch (error) {
    console.error("Product fetch error:", error);
    return json({ activeProducts: [] }, { status: 500 });
  }
};
