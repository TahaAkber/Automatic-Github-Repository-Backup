import React from "react";

export const PaddedDiv: React.FC<{ children: React.ReactNode }> = ({
  children,
}) => {
  return <div style={{ padding: "5px 20px" }}>{children}</div>;
};
