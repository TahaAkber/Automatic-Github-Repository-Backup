import { Button, DatePicker, Icon, Text } from "@shopify/polaris";
import React, { useCallback, useState, useRef, useEffect, FC } from "react";
import { CalendarIcon, SelectIcon } from "@shopify/polaris-icons";
import { getMonthName } from "~/functions/common";

interface Props {
  month: number;
  year: number;
  setDate: (date: { month: number; year: number }) => void;
  selectedDates: any;
  setSelectedDates: (dates: any) => void;
  borderColor?: string;
  minDate?: Date;
  maxDate?: Date;
}

export const CalendarButton: FC<Props> = ({
  month,
  year,
  setDate,
  selectedDates,
  setSelectedDates,
  borderColor = "#fff",
  minDate,
  maxDate,
}) => {
  const [openDatePicker, setOpenDatePicker] = useState(false);
  const datePickerRef = useRef<HTMLDivElement>(null);

  const handleMonthChange = useCallback(
    (month: number, year: number) => setDate({ month, year }),
    [],
  );

  // Handle clicks outside the date picker
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        datePickerRef.current &&
        !datePickerRef.current.contains(event.target as Node)
      ) {
        setOpenDatePicker(false);
      }
    };

    if (openDatePicker) {
      document.addEventListener("mousedown", handleClickOutside);
    }

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [openDatePicker]);

  return (
    <div style={{ position: "relative" }} ref={datePickerRef}>
      <div
        style={{
          backgroundColor: "#fff",
          width: "150px",
          display: "flex",
          justifyContent: "space-evenly",
          alignItems: "center",
          height: "31px",
          borderRadius: "8px",
          cursor: "pointer",
          borderColor,
          borderStyle: "solid",
          borderWidth: 0.5,
        }}
        onClick={() => setOpenDatePicker(true)}
      >
        <Icon source={CalendarIcon} />
        <Text as="p">
          {getMonthName(month)} {year}
        </Text>
        <Icon source={SelectIcon} accessibilityLabel="Toggle Date Picker" />
      </div>

      {openDatePicker && (
        <div
          ref={datePickerRef}
          style={{
            width: 300,
            marginTop: 20,
            position: "absolute",
            right: 0,
            backgroundColor: "#fff",
            padding: 20,
            borderRadius: 15,
            boxShadow: "0px 4px 6px rgba(0,0,0,0.1)",
            zIndex: 1000,
          }}
        >
          <DatePicker
            month={month}
            year={year}
            onChange={setSelectedDates}
            onMonthChange={handleMonthChange}
            selected={selectedDates}
            multiMonth={false}
            dayAccessibilityLabelPrefix="choose"
            allowRange
            disableDatesBefore={minDate}
            disableDatesAfter={maxDate}
          />
        </div>
      )}
    </div>
  );
};
