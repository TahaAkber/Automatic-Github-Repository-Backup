function timeAgo(timestamp: any) {
  const timestampDate = timestamp ? new Date(timestamp) : null;
  const now = new Date();
  console.log("timeAgo", timestampDate);

  if (!timestampDate) return "";

  const diffInMs = now.getTime() - timestampDate.getTime();
  const minutesAgo = Math.floor(diffInMs / (1000 * 60));
  const hoursAgo = Math.floor(minutesAgo / 60);

  if (hoursAgo >= 24) {
    const daysAgo = Math.floor(hoursAgo / 24);
    return `${daysAgo} day${daysAgo > 1 ? "s" : ""} ago`;
  }

  if (hoursAgo >= 1) {
    return `${hoursAgo} hour${hoursAgo > 1 ? "s" : ""} ago`;
  }

  return `${minutesAgo} minute${minutesAgo !== 1 ? "s" : ""} ago`;
}

export default timeAgo;
