import { BlockStack, Divider, Layout } from "@shopify/polaris";
import React from "react";

export const CustomDivider: React.FC = () => {
  return (
    <Layout.Section>
      <BlockStack>
        <Divider borderColor="border-hover" />
      </BlockStack>
    </Layout.Section>
  );
};
