import { Spinner } from "@shopify/polaris";
import React from "react";

export const Loader: React.FC = () => {
  return (
    <div
      style={{
        display: "flex",
        justifyContent: "center",
        padding: "20px",
        height: "90vh",
        alignItems: "center",
      }}
    >
      <Spinner accessibilityLabel="Spinner example" size="large" />
    </div>
  );
};
