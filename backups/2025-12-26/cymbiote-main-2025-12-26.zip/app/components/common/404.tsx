import { Links, Meta, Scripts, useRouteError } from "@remix-run/react";
import { Page } from "@shopify/polaris";

export default function NotFoundPage() {
  const error = useRouteError();
  console.error("page error", error);
  return (
    <Page fullWidth>
      <h1>Page Not Found</h1>
      <p>Sorry, the page you're looking for does not exist.</p>
      <a href="/">Go back to Home</a>
    </Page>
  );
}
