import React, { useMemo, useState } from "react";
import { Layout, Text, InlineStack, Button } from "@shopify/polaris";
import DropZoneExample from "../collection/DropZone";
import BrandForm from "./BrandForm";
export type FormData = {
  name: string;
  website: string;
  description: string;
};
interface Brands {
  logoPreview: string | null;
  removeLogo: any;
  logoFiles: File[];
  setLogoFiles: (value: File[]) => void;
  setFormData: (value: FormData | ((prev: FormData) => FormData)) => void;
  formData: any;
}

const BrandLogo = ({
  logoPreview,
  removeLogo,
  logoFiles,
  setLogoFiles,
  setFormData,
  formData,
}: Brands) => {
  return (
    <Layout>
      {/* Left: form (wider) */}
      <Layout.Section>
        <div style={{ width: "100%" }}>
          <BrandForm setFormData={setFormData} formData={formData} />
        </div>
      </Layout.Section>

      {/* Right: logo upload/preview (narrow) */}
      <Layout.Section variant="oneThird">
        <div style={{ display: "flex", justifyContent: "flex-end" }}>
          <div
            style={{
              width: "100%",
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
            }}
          >
            {logoPreview ? (
              <>
                <InlineStack align="center">
                  <img
                    src={logoPreview}
                    alt="Brand logo preview"
                    style={{
                      width: 300,
                      height: 230,
                      borderRadius: 10,
                      margin: "0.6rem auto",
                      objectFit: "contain",
                    }}
                  />
                </InlineStack>
                <div style={{ marginTop: 8 }}>
                  <Button tone="critical" variant="plain" onClick={removeLogo}>
                    Remove logo
                  </Button>
                </div>
              </>
            ) : (
              <div style={{ width: 300 }}>
                <Text as="p" variant="headingXs">
                  Add Brand logo
                </Text>
                <div style={{ marginTop: 10, height: "300px" }}>
                  <DropZoneExample
                    files={logoFiles}
                    setFiles={(files: File[]) => setLogoFiles(files)}
                  />
                </div>
              </div>
            )}
          </div>
        </div>
      </Layout.Section>
    </Layout>
  );
};

export default BrandLogo;
