import React, { useMemo, useState } from "react";
import { FormLayout, TextField } from "@shopify/polaris";

export type FormData = {
  name: string;
  website: string;
  description: string;
};

interface BrandFormProps {
  setFormData: (value: FormData | ((prev: FormData) => FormData)) => void;
  formData: FormData;
}

// Regex/rules
const BRAND_NAME_REGEX = /^[\p{L}\p{M}0-9 &().,'-]{2,100}$/u;

function isValidBrandName(v: string) {
  const val = v.trim();
  return BRAND_NAME_REGEX.test(val);
}

function isValidWebsite(v: string) {
  const val = v.trim();
  try {
    const u = new URL(val.startsWith("http") ? val : `https://${val}`);
    return (
      ["http:", "https:"].includes(u.protocol) && !!u.hostname.includes(".")
    );
  } catch {
    return false;
  }
}

const BrandForm = ({ setFormData, formData }: BrandFormProps) => {
  const [nameError, setNameError] = useState<string | undefined>();
  const [siteError, setSiteError] = useState<string | undefined>();
  const [descError, setDescError] = useState<string | undefined>();

  const descCount = useMemo(
    () => formData.description.trim().length,
    [formData.description],
  );

  return (
    <div style={{ width: "100%" }}>
      <FormLayout>
        <FormLayout.Group>
          <TextField
            type="text"
            label="Brand Name"
            value={formData.name}
            onChange={(value) => {
              setFormData((s) => ({ ...s, name: value }));
              if (nameError) setNameError(undefined);
            }}
            onBlur={() => {
              if (!formData.name.trim())
                setNameError("Brand name is required.");
              else if (!isValidBrandName(formData.name))
                setNameError(
                  "2–100 chars. Letters, numbers, spaces, &, ( ), comma, apostrophe, hyphen, dot.",
                );
            }}
            maxLength={100}
            autoComplete="on"
            error={nameError}
            helpText="e.g., PriceOye, Acme Inc."
          />

          <TextField
            type="text"
            label="Website"
            value={formData.website}
            onChange={(value) => {
              setFormData((s) => ({ ...s, website: value }));
              if (siteError) setSiteError(undefined);
            }}
            onBlur={() => {
              if (!formData.website.trim())
                setSiteError("Website is required.");
              else if (!isValidWebsite(formData.website))
                setSiteError("Enter a valid URL (e.g., https://example.com).");
            }}
            autoComplete="off"
            error={siteError}
            helpText="Include domain only or full URL; http/https accepted."
          />
        </FormLayout.Group>

        <TextField
          type="text"
          label="Your Requirement Description (Why do you need this brand here)?"
          value={formData.description}
          onChange={(value) => {
            setFormData((s) => ({ ...s, description: value }));
            if (descError) setDescError(undefined);
          }}
          onBlur={() => {
            if (!formData.description.trim())
              setDescError("Please add a short reason.");
          }}
          maxLength={1000}
          autoComplete="off"
          multiline={8}
          error={descError}
          helpText={`${descCount}/1000`}
        />
      </FormLayout>
    </div>
  );
};

export default BrandForm;
