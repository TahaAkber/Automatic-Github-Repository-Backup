import React, { useCallback, useEffect, useState } from "react";
import { Card, Grid, Text, Button, Icon } from "@shopify/polaris";
import {
  UploadIcon,
  ProductIcon,
  ImageWithTextOverlayIcon,
  DeleteIcon,
} from "@shopify/polaris-icons";
import ProductsModal from "./ProductsModal";
import { PlayIcon } from "@shopify/polaris-icons";
import { useFetcher, useNavigate } from "@remix-run/react";
import { EditIcon } from "@shopify/polaris-icons";
import {
  AlertDiamondIcon
} from '@shopify/polaris-icons';

interface UploadProps {
  title: string;
  search: string;
}

export default function Upload({ title, search }: UploadProps) {
  const fetcher = useFetcher<any>();
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  const [searchValue, setsearchValue] = useState("");
  const [video, setVideo] = useState<File | null>(null);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [thumbnail, setThumbnail] = useState<File | null>(null);
  const [thumbnailUrl, setThumbnailUrl] = useState<string | null>(null);
  const [products, setProducts] = useState<any[]>([]);
  const [selectedProducts, setSelectedProducts] = useState<any[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const handleVideoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (files && files[0]?.type.startsWith("video")) {
      const file = files[0];
      const fileSizeMB = file.size / (1024 * 1024);

      if (fileSizeMB > 30) {
        // limit to 30 MB
        shopify.toast.show("Video must be under 30 MB.");
        return;
      }

      console.log("File size:", fileSizeMB.toFixed(2), "MB");

      const videoEl = document.createElement("video");
      videoEl.preload = "metadata";
      videoEl.src = URL.createObjectURL(file);

      videoEl.onloadedmetadata = () => {
        const width = videoEl.videoWidth;
        const height = videoEl.videoHeight;
        const duration = videoEl.duration;

        if (width > height) {
          shopify.toast.show("Video must be portrait orientation.");
          return;
        }

        if (duration > 30) {
          shopify.toast.show("Video must be 30 seconds or less in duration.");
          return;
        }

        setVideo(file);
        const url = URL.createObjectURL(file);
        setVideoUrl(url);

        // Seek to 1 second for thumbnail
        videoEl.currentTime = 1;
      };

      videoEl.onseeked = () => {
        const width = videoEl.videoWidth;
        const height = videoEl.videoHeight;
        const canvas = document.createElement("canvas");
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext("2d");
        if (ctx) ctx.drawImage(videoEl, 0, 0, width, height);
        canvas.toBlob((blob) => {
          if (blob) {
            const thumbFile = new File([blob], `${file.name}-thumbnail.png`, {
              type: "image/png",
            });
            setThumbnail(thumbFile);
            // const thumbUrl = URL.createObjectURL(blob);
            // setThumbnailUrl(thumbUrl);
          }
        }, "image/png");
      };
    }
  };

  const deleteUpload = () => {
    setVideo(null);
    setVideoUrl(null);
    setThumbnail(null);
    setThumbnailUrl(null);
    setSelectedProducts([]);
  };

  const domain = window.location.search;

  const searchProduct = async () => {
    try {
      const response = await fetch(
        `/api/searchProducts?searchQuery=${searchValue}&searchTerm=${search}`,
      );

      if (!response.ok) {
        const text = await response.text();
        console.warn("Non-200 response:", response.status, text);
        return;
      }

      const data = await response.json();
      setProducts(data || []);
    } catch (error) {
      console.log("Error fetching products", error);
    }
  };

  const uploadButton = async (retryCount = 0) => {
    const formData = new FormData();
    if (thumbnail) formData.append("thumbnail", thumbnail);
    if (video) formData.append("video", video);
    formData.append("product", JSON.stringify(selectedProducts));

    try {
      fetcher.submit(formData, {
        method: "POST",
        encType: "multipart/form-data",
      });
    } catch (error: any) {
      // Retry if connection reset or aborted
      if (
        retryCount < 2 &&
        (error.code === "ECONNRESET" || error.message?.includes("aborted"))
      ) {
        console.warn(`Upload failed, retrying... (${retryCount + 1}/2)`);
        setTimeout(() => uploadButton(retryCount + 1), 2000);
      } else {
        console.error("Upload failed after retries:", error);
        shopify.toast.show("Upload failed. Please try again.", {
          duration: 3000,
        });
        setIsLoading(false);
      }
    }
  };

  useEffect(() => {
    if (fetcher.data?.success) {
      navigate({ pathname: "/videos", search });

      setTimeout(() => {
        deleteUpload();
        setIsLoading(false);
      }, 5000);
    } else {
      setIsLoading(false);
      if (fetcher.data) {
        shopify.toast.show("Upload was unsuccessful", { duration: 2000 });
      }
    }
  }, [fetcher.data]);

  useEffect(() => {
    searchProduct();
  }, [searchValue, domain, isModalOpen]);

  const handleThumbnailUpload = (
    event: React.ChangeEvent<HTMLInputElement>,
  ) => {
    const files = event.target.files;
    if (!files || !files[0]) return;

    const imageFile = files[0];

    // Only allow image types
    if (!imageFile.type.startsWith("image/")) {
      shopify.toast.show("Please upload a valid image file.", {
        duration: 3000,
      });
      event.target.value = "";
      return;
    }

    const img = new Image();
    const url = URL.createObjectURL(imageFile);

    img.onload = () => {
      const { width, height } = img;

      // ✅ Portrait check
      if (height <= width) {
        shopify.toast.show("Thumbnail must be portrait (vertical).", {
          duration: 3000,
        });
        event.target.value = "";
        URL.revokeObjectURL(url);
        return;
      }

      // ✅ Minimum resolution check: 1080 × 1350
      if (width < 500 || height < 700) {
        shopify.toast.show(
          "Thumbnail resolution too low. Minimum is 500 x 700.",
          { duration: 3000 },
        );
        event.target.value = "";
        URL.revokeObjectURL(url);
        return;
      }

      setThumbnail(imageFile);
      setThumbnailUrl(url);
    };

    img.onerror = () => {
      shopify.toast.show("Could not read image. Please try again.", {
        duration: 3000,
      });
      event.target.value = "";
      URL.revokeObjectURL(url);
    };

    img.src = url;
  };

  return (
    <div>
      <Card>
        <Text as="h2" variant="headingMd">
          {title}
        </Text>
        <div style={{ height: 30 }} />
        <div>
          <div style={{ display: "flex", justifyContent: "space-between" }}>
            <div
              style={{
                height: "100%",
                width: "100%",
              }}
            >
              <Grid>
                <Grid.Cell columnSpan={{ xs: 6, sm: 3, md: 3, lg: 3, xl: 3 }}>
                  {videoUrl ? (
                    <div>
                      <div
                        style={{
                          width: "100%",
                          height: "100%",
                          display: "flex",
                          flexDirection:
                            window.innerWidth < 768 ? "column" : "row",
                          alignItems: "self-start",
                          gap: "0.2rem",
                          cursor: "pointer",
                        }}
                        onClick={() =>
                          document.getElementById("file-upload-video")?.click()
                        }
                      >
                        <div style={{ position: "relative" }}>
                          <video
                            key={video?.name}
                            style={{
                              width: "70px",
                              height: "90px",
                              borderRadius: 10,
                              objectFit: "cover",
                            }}
                          >
                            <source
                              src={videoUrl}
                              type={video?.type || "video/mp4"}
                            />
                          </video>
                          <div
                            style={{
                              position: "absolute",
                              top: "50%",
                              left: "50%",
                              transform: "translate(-50%, -50%)",
                              backgroundColor: "rgba(0, 0, 0, 0.4)",
                              borderRadius: "50%",
                              padding: "4px",
                              display: "flex",
                              justifyContent: "center",
                              alignItems: "self-start",
                            }}
                          >
                            <Icon source={PlayIcon} tone="emphasis" />
                          </div>
                        </div>
                        <div style={{ marginLeft: "8px" }}>
                          <Text as="p">
                            {selectedProducts[0]?.product_name}
                          </Text>
                        </div>
                      </div>
                      <div style={{ marginTop: "0.5rem" }}>
                        <Button
                          icon={EditIcon}
                          onClick={() =>
                            document
                              .getElementById("file-upload-video")
                              ?.click()
                          }
                        >
                          Change
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <>
                      <Button
                        fullWidth
                        icon={UploadIcon}
                        onClick={() =>
                          document.getElementById("file-upload-video")?.click()
                        }
                        size="large"
                      >
                        {title}
                      </Button>
                    </>
                  )}
                </Grid.Cell>

                <Grid.Cell columnSpan={{ xs: 6, sm: 3, md: 3, lg: 3, xl: 3 }}>
                  {selectedProducts.length > 0 ? (
                    <div>
                      <div
                        style={{
                          width: "100%",
                          height: "100%",
                          display: "flex",
                          flexDirection:
                            window.innerWidth < 768 ? "column" : "row",
                          alignItems: "self-start",
                          gap: "0.2rem",
                          cursor: "pointer",
                        }}
                        onClick={() => setIsModalOpen(true)}
                      >
                        <img
                          src={selectedProducts[0]?.product_image_url}
                          style={{
                            width: "70px",
                            height: "90px",
                            borderRadius: 10,
                            objectFit: "cover",
                          }}
                        />
                        <Text as="p">{selectedProducts[0]?.product_name}</Text>
                      </div>
                      <div style={{ marginTop: "0.5rem" }}>
                        <Button
                          onClick={() => setIsModalOpen(true)}
                          icon={EditIcon}
                        >
                          Change
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <Button
                      fullWidth
                      icon={ProductIcon}
                      onClick={() => setIsModalOpen(true)}
                      size="large"
                    >
                      Tag Product
                    </Button>
                  )}
                </Grid.Cell>

                <Grid.Cell columnSpan={{ xs: 6, sm: 3, md: 2, lg: 3, xl: 3 }}>
                  {thumbnailUrl ? (
                    <div>
                      <div
                        style={{
                          width: "100%",
                          height: "100%",
                          display: "flex",
                          flexDirection:
                            window.innerWidth < 768 ? "column" : "row",
                          alignItems: "self-start",
                          gap: "0.2rem",
                          cursor: "pointer",
                        }}
                        onClick={() =>
                          document
                            .getElementById("file-upload-thumbnail")
                            ?.click()
                        }
                      >
                        <img
                          src={thumbnailUrl}
                          style={{
                            width: "70px",
                            height: "90px",
                            borderRadius: 10,
                            objectFit: "cover",
                          }}
                        />
                        <Text as="p">Custom Thumbnail</Text>
                      </div>
                      <div style={{ marginTop: "0.5rem" }}>
                        <Button
                          onClick={() =>
                            document
                              .getElementById("file-upload-thumbnail")
                              ?.click()
                          }
                          icon={EditIcon}
                        >
                          Change
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <Button
                      fullWidth
                      icon={ImageWithTextOverlayIcon}
                      onClick={() =>
                        document
                          .getElementById("file-upload-thumbnail")
                          ?.click()
                      }
                      size="large"
                    >
                      Thumbnail
                    </Button>
                  )}
                </Grid.Cell>
              </Grid>
            </div>
            {videoUrl && selectedProducts ? (
              <div>
                <Button
                  icon={DeleteIcon}
                  size="large"
                  onClick={deleteUpload}
                  fullWidth
                ></Button>
              </div>
            ) : (
              <></>
            )}
          </div>
          <div
            style={{
              display: "flex",
              justifyContent: "flex-end",
              marginTop: "1rem",
            }}
          >
            {videoUrl && selectedProducts.length > 0 ? (
              <Button
                size="large"
                onClick={() => {
                  uploadButton();
                  setIsLoading(true);
                }}
                loading={isLoading}
              >
                Upload
              </Button>
            ) : null}
          </div>
        </div>

        <div style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
          <AlertDiamondIcon height={25} width={25} />
          <Text as="p">Video must be less than 30 seconds in duration and 30 MB in size</Text>
        </div>
      </Card>
      <div style={{ border: "none" }}>
        <ProductsModal
          open={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          products={products}
          selectedproducts={selectedProducts}
          setSelectedproducts={setSelectedProducts}
          setsearchValue={setsearchValue}
          searchValue={searchValue}
        />
      </div>
      <input
        type="file"
        id="file-upload-thumbnail"
        hidden
        accept="image/*"
        onChange={handleThumbnailUpload}
      />
      <input
        type="file"
        id="file-upload-video"
        hidden
        onChange={handleVideoUpload}
        accept="video/*"
      />
    </div>
  );
}
