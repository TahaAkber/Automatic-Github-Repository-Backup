import { useNavigate } from "@remix-run/react";
import {
  BlockStack,
  Button,
  Text,
  Divider,
  Grid,
  Modal,
  VideoThumbnail,
  Box,
  Icon,
} from "@shopify/polaris";
import { DeleteIcon } from "@shopify/polaris-icons";

import React, { useState } from "react";
import ConfirmationModal from "../modals/ConfirmationModal";
import { PlayIcon, UploadIcon } from "@shopify/polaris-icons";

import timeAgo from "../common/TimeStampForReels";
interface StoryProps {
  stories: any[];
  deleteStory: (id: string) => void;
  reUploadStory: (id: string) => void;
}

export const Stories: React.FC<StoryProps> = ({
  deleteStory,
  stories,
  reUploadStory,
}) => {
  const [activeStory, setActiveStory] = useState<any | null>(null);
  const [activedelete, setactivedelete] = useState<null | any>(null);
  const [isReuploadModalOpen, setIsReuploadModalOpen] = useState(false);
  const [isdeletemodal, setisdeletemodal] = useState(false);
  const [isLoading, setisloading] = useState(false);

  const handleOpenModal = (story: any) => setActiveStory(story);
  const handleCloseModal = () => setActiveStory(null);

  const handleModalYesClicked = () => {
    setisloading(true);
    deleteStory(activedelete?.video?.video_id || "0");
    setisdeletemodal(false);
    setactivedelete(null);
    setisloading(false);
    console.log("testing", activedelete?.video?.video_id || "0");
  };

  const handleStoryReUpload = () => {
    setisloading(true);
    reUploadStory(activedelete?.video?.video_id || "0");
    setIsReuploadModalOpen(false);
    setisloading(false);
  };

  return (
    <BlockStack>
      {stories.map((story, index) => (
        <BlockStack key={story.video_id || index}>
          <div style={{ height: 20 }} />
          <Grid>
            {/* <Grid.Cell columnSpan={{ xs: 2, sm: 3, md: 3 }}>
              <VideoThumbnail
                thumbnailUrl={
                  story.video?.video_thumbnail_url ||
                  "https://thumbs.dreamstime.com/b/portrait-young-woman-standing-23878158.jpg"
                }
                onClick={() => handleOpenModal(story)}
                videoLength={0}
                accessibilityLabel="Story Thumbnail"
              />
            </Grid.Cell> */}

            <Grid.Cell columnSpan={{ xs: 2, sm: 3, md: 3 }}>
              <div
                onClick={() => handleOpenModal(story)}
                style={{
                  position: "relative",
                  cursor: "pointer",
                  width: "100%",
                  height: "0",
                  paddingBottom: "56.25%", // 16:9 aspect ratio
                  borderRadius: "8px",
                  overflow: "hidden",
                }}
              >
                <img
                  src={
                    story.video?.video_thumbnail_url ||
                    "https://thumbs.dreamstime.com/b/portrait-young-woman-standing-23878158.jpg"
                  }
                  alt="Story Thumbnail"
                  style={{
                    position: "absolute",
                    top: 0,
                    left: 0,
                    width: "100%",
                    height: "100%",
                    objectFit: "cover",
                  }}
                />

                <div
                  style={{
                    position: "absolute",
                    top: "50%",
                    left: "50%",
                    transform: "translate(-50%, -50%)",
                    background: "rgba(33, 43, 54, 0.8)",
                    borderRadius: "50%",
                    padding: "8px",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <Icon source={PlayIcon} tone="emphasis" />
                </div>
              </div>
            </Grid.Cell>

            <Grid.Cell columnSpan={{ xs: 1, sm: 3, md: 4, lg: 3 }}>
              <Box>
                <Text as="p">
                  {story.video?.ReelsNStories[0]?.video_title || "No title"}
                </Text>
                <Text as="p" variant="bodyXs" tone="disabled">
                  {`${timeAgo(story.video?.updated_at)}` || "No date"}
                </Text>
              </Box>
            </Grid.Cell>

            <Grid.Cell columnSpan={{ xs: 1, sm: 2, md: 2 }}>
              <Box>
                <div className="videoview">
                  <Button disabled size="micro">
                    {story.video?.ReelsNStories[0]?.video_view_count || 0} Views
                  </Button>
                </div>
              </Box>
            </Grid.Cell>

            <Grid.Cell columnSpan={{ xs: 1, sm: 2, md: 2 }}>
              <Box>
                <div className="videoview">
                  <Button disabled size="micro">
                    {story.video?.ReelsNStories[0]?.video_likes_count || 0}{" "}
                    Likes
                  </Button>
                </div>
              </Box>
            </Grid.Cell>

            <Grid.Cell columnSpan={{ xs: 1, sm: 1, md: 1 }}>
              <Box paddingBlock={"200"}>
                <Button
                  icon={UploadIcon}
                  accessibilityLabel="Re-Upload Story"
                  variant="monochromePlain"
                  fullWidth
                  onClick={() => {
                    setactivedelete(story);
                    setIsReuploadModalOpen(true);
                    console.log("modal", isReuploadModalOpen);
                  }}
                />
              </Box>
              <Box paddingBlock={"200"}>
                <Button
                  icon={DeleteIcon}
                  accessibilityLabel="Delete Story"
                  variant="monochromePlain"
                  fullWidth
                  onClick={() => {
                    setactivedelete(story);
                    setisdeletemodal(true);
                  }}
                />
              </Box>
            </Grid.Cell>
          </Grid>
          <div style={{ height: 10 }} />
          <Divider borderColor="border" />
        </BlockStack>
      ))}
      {(activedelete || isReuploadModalOpen) && (
        <ConfirmationModal
          open={isdeletemodal || isReuploadModalOpen}
          onClose={() => {
            setisdeletemodal(false);
            setIsReuploadModalOpen(false);
          }}
          title={
            isReuploadModalOpen === true ? "Re-upload Story" : "Delete Story"
          }
          message={
            isReuploadModalOpen === true
              ? "Re-upload Story"
              : "Are you sure you want to delete Story reel?"
          }
          confirmLabel="Yes"
          cancelLabel="No"
          onConfirm={
            isReuploadModalOpen ? handleStoryReUpload : handleModalYesClicked
          }
          isLoading={isLoading}
        />
      )}
      {activeStory && (
        <Modal open onClose={handleCloseModal} title={null}>
          <div
            style={{
              position: "relative",
              paddingTop: "70%",
              background: "black",
            }}
          >
            <video
              controls
              autoPlay={true}
              style={{
                position: "absolute",
                top: 0,
                left: 0,
                width: "100%",
                height: "100%",
                objectFit: "contain",
                borderRadius: "0px",
                backgroundColor: "black",
              }}
              src={activeStory.video?.video_url}
            />
          </div>
        </Modal>
      )}
    </BlockStack>
  );
};
