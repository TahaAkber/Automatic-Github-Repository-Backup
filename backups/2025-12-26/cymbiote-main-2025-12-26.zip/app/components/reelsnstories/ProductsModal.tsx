import {
  Modal,
  Frame,
  Checkbox,
  Thumbnail,
  InlineStack,
  Combobox,
  Icon,
  Button,
} from "@shopify/polaris";
import { SearchIcon } from "@shopify/polaris-icons";
import { useEffect, useState } from "react";
import { Spinner } from "@shopify/polaris";

export interface Product {
  product_id: number;
  product_name: string;
  product_image_url: string;
}

interface Modelstate {
  open: boolean;
  onClose: any;
  products: Product[];
  setSelectedproducts: (products: Product[]) => void;
  selectedproducts: Product[];
  setsearchValue(value: string): void;
  searchValue: string;
}

export default function ProductsModal({
  open,
  onClose,
  products: initialProducts,
  setSelectedproducts,
  setsearchValue,
  searchValue,
  selectedproducts,
}: Modelstate) {
  const [selectedItem, setSelectedItem] = useState<Product | null>(null);
  const [filteredProducts, setFilteredProducts] = useState<Product[]>([]);

  const handleSearchChange = (value: string) => {
    setsearchValue(value);

    setFilteredProducts(
      initialProducts.filter((product) =>
        product.product_name.toLowerCase().includes(value.toLowerCase()),
      ),
    );
  };

  const handleCheckboxChange = (product: Product) => {
    setSelectedItem((prev) =>
      prev?.product_id === product.product_id ? null : product,
    );
  };

  useEffect(() => {
    setSelectedItem(selectedproducts[0] || null);
  }, [selectedproducts, open]);

  const handleDoneClick = () => {
    setSelectedproducts(selectedItem ? [selectedItem] : []);
    onClose();
  };

  useEffect(() => {
    if (initialProducts.length > 0) {
      setFilteredProducts(initialProducts);
    }
  }, [initialProducts]);

  return (
    <div style={{ height: "0" }}>
      <Frame>
        <Modal open={open} title="Edit Products" onClose={onClose}>
          <div style={{ width: "94%", margin: "3%" }}>
            <Combobox
              activator={
                <Combobox.TextField
                  prefix={<Icon source={SearchIcon} />}
                  label="Search Products"
                  labelHidden
                  placeholder="Search Products"
                  autoComplete="off"
                  value={searchValue}
                  onChange={handleSearchChange}
                />
              }
            />
          </div>

          <div
            style={{ maxHeight: "300px", overflowY: "auto", padding: "0 16px" }}
          >
            {filteredProducts.length === 0 ? (
              <Spinner accessibilityLabel="Spinner" size="small"  />
            ) : (
              filteredProducts.map((product) => (
                <Modal.Section key={product.product_id + `-inner`}>
                  <Checkbox
                    label={
                      <InlineStack
                        align="center"
                        gap={{ xs: "300", md: "300", lg: "400", xl: "500" }}
                      >
                        <Thumbnail
                          source={product.product_image_url}
                          alt={product.product_name}
                          size="small"
                        />
                        <span style={{ display: "flex", alignItems: "center" }}>
                          {product.product_name}
                        </span>
                      </InlineStack>
                    }
                    checked={selectedItem?.product_id === product.product_id}
                    onChange={() => handleCheckboxChange(product)}
                  />
                </Modal.Section>
              ))
            )}
          </div>

          <div
            style={{
              position: "sticky",
              bottom: 0,
              background: "white",
              padding: "16px",
              boxShadow: "0 -2px 10px rgba(0,0,0,0.1)",
              display: "flex",
              justifyContent: "flex-end",
              gap: 10,
            }}
          >
            <Button variant="secondary" onClick={onClose}>
              Cancel
            </Button>
            <Button variant="primary" onClick={handleDoneClick}>
              Done
            </Button>
          </div>
        </Modal>
      </Frame>
    </div>
  );
}
