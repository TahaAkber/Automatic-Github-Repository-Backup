import { useNavigate } from "@remix-run/react";
import {
  BlockStack,
  Box,
  Button,
  Divider,
  Grid,
  InlineStack,
  Text,
  Thumbnail,
  VideoThumbnail,
  Modal,
  Icon,
} from "@shopify/polaris";
import React, { useEffect, useState } from "react";
import { DeleteIcon, PlayIcon } from "@shopify/polaris-icons";
import { ReelNStory } from "~/types/ReelNStory";
import ConfirmationModal from "../modals/ConfirmationModal";
import timeAgo from "../common/TimeStampForReels";

interface ReelsProps {
  reels: ReelNStory[];
  deleteReel: (id: string) => void;
}

export const Reels: React.FC<ReelsProps> = ({
  reels,
  deleteReel,
}: ReelsProps) => {
  const navigate = useNavigate();

  const [activeReel, setActiveReel] = useState<null | ReelNStory>(null);
  const [activedelete, setactivedelete] = useState<null | ReelNStory>(null);
  const [isdeletemodal, setisdeletemodal] = useState(false);
  const handleOpenModal = (reel: ReelNStory) => setActiveReel(reel);
  const [isLoading, setisloading] = useState(false);
  const handleCloseModal = () => setActiveReel(null);
  const handleModalYesClicked = () => {
    setisloading(true);

    deleteReel(activedelete?.video?.video_id || "0");
    setisdeletemodal(false);
    setactivedelete(null);
    setisloading(false);
  };

  const timestamp = reels[0]?.video?.ReelsNStories[0]?.created_at;
  useEffect(() => {
    console.log("Reels Data:", reels);
  }, []);

  return (
    <BlockStack>
      {reels.map((reel, index) => (
        <BlockStack key={reel.video_id || index}>
          <div style={{ height: 15 }} />
          <Grid>
            {/* <Grid.Cell columnSpan={{ xs: 6, md: 2 }}>
              <VideoThumbnail
                thumbnailUrl={
                  reel.video?.video_thumbnail_url ||
                  "https://thumbs.dreamstime.com/b/portrait-young-woman-standing-23878158.jpg"
                }
                onClick={() => handleOpenModal(reel)}
                videoLength={0}
                accessibilityLabel="Reel Thumbnail"
              />
            </Grid.Cell> */}
            <Grid.Cell columnSpan={{ xs: 6, md: 2 }}>
              <div
                onClick={() => handleOpenModal(reel)}
                style={{
                  position: "relative",
                  cursor: "pointer",
                  width: "100%",
                  height: "0",
                  paddingBottom: "56.25%", // 16:9 aspect ratio
                  borderRadius: "8px",
                  overflow: "hidden",
                }}
              >
                <img
                  src={
                    reel.video?.video_thumbnail_url ||
                    "https://thumbs.dreamstime.com/b/portrait-young-woman-standing-23878158.jpg"
                  }
                  alt="Story Thumbnail"
                  style={{
                    position: "absolute",
                    top: 0,
                    left: 0,
                    width: "100%",
                    height: "100%",
                    objectFit: "cover",
                  }}
                />

                <div
                  style={{
                    position: "absolute",
                    top: "50%",
                    left: "50%",
                    transform: "translate(-50%, -50%)",
                    background: "rgba(33, 43, 54, 0.8)",
                    borderRadius: "50%",
                    padding: "8px",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <Icon source={PlayIcon} tone="emphasis" />
                </div>
              </div>
            </Grid.Cell>
            <Grid.Cell columnSpan={{ xs: 6, md: 2 }}>
              <Box paddingBlock={"100"}>
                <Text as="p">
                  {reel.video?.ReelsNStories[0]?.video_title || "No title"}
                </Text>
                <Text as="p" variant="bodyXs" tone="disabled">
                  {`${timeAgo(reel.video?.updated_at)}` || "No Date"}
                </Text>
              </Box>
            </Grid.Cell>

            <Grid.Cell columnSpan={{ xs: 6, md: 2 }}>
              <Box paddingBlock="150">
                <div className="videoview">
                  <Button disabled size="micro">
                    {`${reel.video?.ReelsNStories[0]?.video_view_count || 0} Views`}
                  </Button>
                </div>
              </Box>
            </Grid.Cell>

            <Grid.Cell columnSpan={{ xs: 6, md: 2 }}>
              <Box paddingBlock="150">
                <div className="videoview">
                  <Button disabled size="micro">
                    {reel.video?.ReelsNStories[0]?.video_likes_count || 0}{" "}
                    Favorites
                  </Button>
                </div>
              </Box>
            </Grid.Cell>

            <Grid.Cell columnSpan={{ xs: 3, md: 1 }}>
              <Thumbnail
                source={
                  reel.products?.[0]?.product_image_url ||
                  "https://cdn.shopify.com/s/files/1/0595/2379/2944/files/Frame_6.png?v=1744058109"
                }
                alt="Reel Product Thumbnail"
                size="large"
                transparent
              />
            </Grid.Cell>

            <Grid.Cell columnSpan={{ xs: 6, md: 2 }}>
              <Box>
                <Text as="p">
                  {reel.products?.[0]?.product_name || "No Product"}
                </Text>
                <Text as="p" variant="bodyXs" tone="disabled">
                  Tag Product
                </Text>
              </Box>
            </Grid.Cell>

            <Grid.Cell columnSpan={{ xs: 3, md: 1 }}>
              <Box paddingBlock={"150"}>
                <Button
                  icon={DeleteIcon}
                  accessibilityLabel="Delete Reel"
                  variant="monochromePlain"
                  fullWidth
                  size="large"
                  onClick={() => {
                    setactivedelete(reel);
                    setisdeletemodal(true);
                  }}
                />
              </Box>
            </Grid.Cell>
          </Grid>
          <div style={{ height: 8 }} />
          <Divider borderColor="border" />
        </BlockStack>
      ))}
      {activedelete && (
        <ConfirmationModal
          open={isdeletemodal}
          onClose={() => setisdeletemodal(false)}
          title="Delete Reel"
          message={`Are you sure you want to delete this reel?`}
          confirmLabel="Yes"
          cancelLabel="No"
          onConfirm={handleModalYesClicked}
          isLoading={isLoading}
        />
      )}
      {activeReel && (
        <Modal open={!!activeReel} onClose={handleCloseModal} title={null}>
          <div
            style={{
              position: "relative",
              paddingTop: "70%",
              background: "black", // background to match video for full immersion
            }}
          >
            <video
              controls
              autoPlay
              style={{
                position: "absolute",
                top: 0,
                left: 0,
                width: "100%",
                height: "100%",
                objectFit: "contain",
                borderRadius: "0px", // or 12px if you want soft corners
                backgroundColor: "black",
              }}
              src={activeReel.video?.video_url}
            />
          </div>
        </Modal>
      )}
    </BlockStack>
  );
};
