import { Button, Card, Grid, Icon, Text } from "@shopify/polaris";
import { ArrowUpIcon, ArrowDownIcon } from "@shopify/polaris-icons";
import DateList from "./DateList";
import ReviewChart from "./ReviewChart";
import { useEffect, useState } from "react";
import dayjs from "dayjs";

interface ReviewCardProps {
  title: string;
  date: string;
  rate: number;
  percentage: number;
  graphvalues: any[];
  type: string;
  ArrowIcon: any;
  selectedyear: any;
  setselectedyear: (value: any) => void;
  handleDateFilter: (type: string, date: string, dateUntil: string) => void;
}

export function ReviewCard({
  title,
  date,
  rate,
  percentage,
  graphvalues,
  ArrowIcon,
  type,
  selectedyear,
  setselectedyear,
  handleDateFilter,
}: ReviewCardProps) {
  return (
    <Card>
      <Grid>
        <Grid.Cell columnSpan={{ xs: 6, sm: 6, md: 6, lg: 8 }}>
          <Text as="h2" variant="headingLg">
            {title}
          </Text>
          <Text as="p">{date}</Text>
        </Grid.Cell>

        <Grid.Cell columnSpan={{ xs: 6, sm: 6, md: 4, lg: 4 }}>
          <div
            style={{
              display: "flex",
              justifyContent: "flex-end",
              height: "100%",
            }}
          >
            <DateList
              handleDateFilter={handleDateFilter}
              type={type}
              setselectedyear={setselectedyear}
              selectedyear={selectedyear}
            />
          </div>
        </Grid.Cell>

        <Grid.Cell columnSpan={{ xs: 6, sm: 6, md: 4, lg: 3 }}>
          <div style={{ marginTop: 16, paddingTop: 16 }}>
            <Text as="h2" variant="headingLg">
              {rate}
            </Text>
            <div
              style={{
                border: "1px solid red",
                borderRadius: 20,
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                gap: 4,
                padding: "4px 8px",
                width: "fit-content",
                marginTop: 8,
                backgroundColor: "#E5E4E2",
              }}
            >
              <Icon source={ArrowIcon} tone="critical" />
              <Text as="p" tone="critical" variant="bodyMd">
                {percentage}%
              </Text>
            </div>
          </div>
        </Grid.Cell>

        <Grid.Cell columnSpan={{ xs: 6, sm: 6, md: 6, lg: 9 }}>
          <ReviewChart graphvalues={graphvalues} />
        </Grid.Cell>
      </Grid>
    </Card>
  );
}
