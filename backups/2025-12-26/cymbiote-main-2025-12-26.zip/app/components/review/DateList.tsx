import {
  Button,
  Card,
  Grid,
  OptionList,
  Popover,
  Text,
} from "@shopify/polaris";
import { useEffect, useState } from "react";
import dayjs from "dayjs";

import { CalendarIcon } from "@shopify/polaris-icons";
import { disable } from "@shopify/app-bridge/actions/LeaveConfirmation";
interface handledate {
  handleDateFilter: (type: string, date: string, dateuntil: string) => void;
  type: string;
  selectedyear: any;
  setselectedyear: (value: any) => void;
}
export default function DateList({
  handleDateFilter,
  type,
  setselectedyear,
  selectedyear,
}: handledate) {
  const [popoverActive, setPopoverActive] = useState(false);
  const currentYear = dayjs().year();
  const thisYearStart = dayjs(`${currentYear}-01-01`).format("YYYY-MM-DD");
  const thisYearEnd = dayjs(`${currentYear}-12-31`).format("YYYY-MM-DD");

  const previousYear = currentYear - 1;
  const previousYearStart = dayjs(`${previousYear}-01-01`).format("YYYY-MM-DD");
  const previousYearEnd = dayjs(`${previousYear}-12-31`).format("YYYY-MM-DD");
  const ranges = [
    {
      title: "This Year",
      alias: "This Year",
      period: {
        since: thisYearStart,
        until: thisYearEnd,
      },
      disabled: false,
    },
    {
      title: "Previous Year",
      alias: "Previous Year",
      period: {
        since: previousYearStart,
        until: previousYearEnd,
      },
      disabled: false,
    },
  ];
  const [selected, setSelected] = useState(ranges[0]);

  useEffect(() => {
    setselectedyear(selected);
  }, [selected]);

  console.log("selected Year", selectedyear.alias);

  return (
    <Popover
      autofocusTarget="none"
      preferredAlignment="left"
      preferInputActivator={false}
      preferredPosition="below"
      onClose={() => setPopoverActive(false)}
      activator={
        <Button
          onClick={() => setPopoverActive(!popoverActive)}
          icon={CalendarIcon}
        >
          {selectedyear.title ? selectedyear.title : selected.title}
        </Button>
      }
      active={popoverActive}
    >
      <OptionList
        options={ranges.map((range) => ({
          value: range.alias,
          label: range.title,
          disabled: range.disabled || false,
        }))}
        selected={[selected.alias]}
        onChange={(value) => {
          const selectedOption = ranges.find(
            (range) => range.alias === value[0],
          );
          if (selectedOption && !selectedOption.disabled) {
            setSelected(selectedOption);
            handleDateFilter(
              type,
              selectedOption.period.since,
              selected.period.until,
            );
          }
          setPopoverActive(false);
        }}
      />
    </Popover>
  );
}
