import { Icon } from "@shopify/polaris";
import { StarFilledIcon, StarIcon } from "@shopify/polaris-icons";

export default function StarRating({ rating }: { rating: number }) {
  const totalStars = 5;
  const stars = [];

  for (let i = 1; i <= totalStars; i++) {
    stars.push(
      <Icon
        key={i}
        source={i <= rating ? StarFilledIcon : StarIcon}
        tone="emphasis"
      />,
    );
  }

  return <div style={{ display: "flex" }}>{stars}</div>;
}
