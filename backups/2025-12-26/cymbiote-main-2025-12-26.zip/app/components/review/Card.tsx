import { Button, ButtonGroup, Card, Text } from "@shopify/polaris";
import { useEffect } from "react";
import { ReviewCard } from "~/components/review/ReviewCard";
import StarRating from "./StarRating";

interface User {
  user_name: string;
  user_image_url?: string;
}

interface Order {
  Users?: User;
  product_Variants?: {
    product?: Product;
  };
}

interface OrderItemReview {
  order_item_review_comment?: string;
  order_item_review_rating?: number;
}

interface Product {
  product_name: string;
  product_image_url?: string;
}

interface CardsProps {
  item: any;
  orders?: Order;
  orderItemReview: OrderItemReview[];
  product?: Product;
}

export default function Cards({
  item,
  orders,
  orderItemReview,
  product,
}: CardsProps) {
  return (
    <Card>
      <div
        style={{
          display: "flex",
          gap: 8,
          alignItems: "center",
          justifyContent: "flex-start",
          backgroundColor: "#F0F0F0",
          padding: 12,
          borderRadius: 10,
        }}
      >
        <img
          src={
            orders?.Users?.user_image_url ||
            "https://cdn.prod.website-files.com/62d84e447b4f9e7263d31e94/6399a4d27711a5ad2c9bf5cd_ben-sweet-2LowviVHZ-E-unsplash-1.jpeg"
          }
          width={40}
          height={40}
          style={{
            borderRadius: 5,
          }}
        />
        <div>
          <Text as="h2" variant="headingMd">
            {orders?.Users?.user_name}
          </Text>
          <span style={{ color: "#1B223C80", fontSize: "12px" }}>
            User Since 2025
          </span>
        </div>
      </div>

      {orderItemReview.map((review, index) => (
        <div
          key={index}
          style={{
            marginTop: 10,
            color: "#1B223C80",
            minHeight: 50,
            maxHeight: 50,
          }}
        >
          <Text as="p" variant="bodyMd">
            <div
              style={{
                display: "-webkit-box",
                WebkitLineClamp: 2,
                WebkitBoxOrient: "vertical",
                overflow: "hidden",
                textOverflow: "ellipsis",
              }}
            >
              {review?.order_item_review_comment || "No comment available"}
            </div>
          </Text>
        </div>
      ))}

      <div
        style={{
          display: "flex",
          gap: 8,
          alignItems: "center",
          marginTop: 10,
        }}
      >
        <img
          src={
            product?.product_image_url ||
            "https://images.ctfassets.net/hrltx12pl8hq/3Z1N8LpxtXNQhBD5EnIg8X/975e2497dc598bb64fde390592ae1133/spring-images-min.jpg"
          }
          width={40}
          height={40}
          style={{
            borderRadius: 5,
          }}
        />
        <Text as="h2" variant="headingMd">
          <div
            title={product?.product_name}
            style={{
              display: "-webkit-box",
              WebkitLineClamp: 1,
              WebkitBoxOrient: "vertical",
              overflow: "hidden",
              textOverflow: "ellipsis",
              maxWidth: "220px", // adjust as needed for layout
            }}
          >
            {product?.product_name || "Unnamed Product"}
          </div>
        </Text>
      </div>

      <div style={{ marginTop: 12 }}>
        <ButtonGroup fullWidth>
          <Button>Public Comment</Button>
          <Button>Direct Message</Button>
        </ButtonGroup>
      </div>
    </Card>
  );
}
