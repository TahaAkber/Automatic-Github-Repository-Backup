import { Card, Text } from "@shopify/polaris";
import { useEffect } from "react";
import {
  BarChart,
  Bar,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
} from "recharts";

interface ReviewChartProps {
  graphvalues: { name: string; value: number; line: number }[];
}

export default function ReviewChart({ graphvalues }: ReviewChartProps) {
  useEffect(() => {
  }, [graphvalues]);

  const data = [
    { name: "Mon", value: graphvalues[0], line: 30 },
    { name: "Tue", value: graphvalues[1], line: 40 },
    { name: "Wed", value: graphvalues[2], line: 38 },
    { name: "Thu", value: graphvalues[3], line: 32 },
    { name: "Fri", value: graphvalues[4], line: 25 },
    { name: "Sat", value: graphvalues[5], line: 30 },
    { name: "Sun", value: graphvalues[6], line: 36 },
  ];

  return (
    <>
      <div style={{ height: 150 }}>
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} barSize={20}>
            <XAxis dataKey="name" />
            <Tooltip />
            <Bar dataKey="value" fill="#6C4AB6" radius={[12, 12, 0, 0]} />
            <Line
              dataKey="line"
              stroke="#00C2FF"
              strokeWidth={3}
              dot={{ r: 5 }}
            />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </>
  );
}
