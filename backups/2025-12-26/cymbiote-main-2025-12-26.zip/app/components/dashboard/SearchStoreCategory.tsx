import React, { useCallback, useState, useMemo, useEffect } from "react";
import { Autocomplete, LegacyStack, Tag } from "@shopify/polaris";

interface Props {
  initialCategoryItems: any[];
  selectedOptions: {
    value: string;
    id: string;
  }[];
  setSelectedOptions: React.Dispatch<
    React.SetStateAction<
      {
        value: string;
        id: string;
      }[]
    >
  >;
  allowTyping?: boolean;
  height?: string;
  width?: number;
  allowMultiSelect: boolean;
  removeASelectedCategory: (category: string, id: string) => void;
  currentShopCategory?: any;
}

interface OPTION {
  value: string;
  label: string;
}

export const SearchStoreCategory = React.memo<Props>(
  ({
    initialCategoryItems,
    selectedOptions,
    setSelectedOptions,
    allowMultiSelect,
    removeASelectedCategory,
    allowTyping = true,
    height = "auto",
    width = 160,
    currentShopCategory,
  }) => {
    const [isLoading, setIsLoading] = useState(false);
    const [inputValue, setInputValue] = useState("");
    const [options, setOptions] = useState<OPTION[]>(
      initialCategoryItems.map((category) => ({
        value: category.id,
        label: category.fullName,
      })),
    );

    const fetchCategories = useCallback(async (searchTerm: string) => {
      setIsLoading(true);
      try {
        const response = await fetch(
          `/api/categories?searchTerm=${searchTerm}`,
        );
        const data = await response.json();
        console.log("API response Categories", data);
        const categoryItems =
          data?.productCategories.taxonomy.categories.nodes.map(
            (category: any) => ({
              label: category.name,
              value: category.id,
            }),
          );
        setOptions(categoryItems);
      } catch (error) {
        console.error("Error fetching product categories:", error);
      } finally {
        setIsLoading(false);
      }
    }, []);

    useEffect(() => {
      if (
        currentShopCategory &&
        currentShopCategory.length > 0 &&
        initialCategoryItems?.length > 0
      ) {
        // Map the array of currentShopCategory to selectedOptions format
        const mappedCategories = currentShopCategory
          .map((shopCat: any) => {
            const match = initialCategoryItems.find(
              (item) =>
                item.id === shopCat.category_id ||
                item.fullName === shopCat.category_name,
            );

            return match
              ? {
                  id: match.id,
                  value: match.fullName,
                }
              : null;
          })
          .filter(Boolean);

        // Only update if there are mapped categories and current selection is different
        if (mappedCategories.length > 0) {
          const currentIds = selectedOptions.map((opt) => opt.id).sort();
          const newIds = mappedCategories.map((cat: any) => cat.id).sort();

          // Only update if the selection has actually changed
          if (JSON.stringify(currentIds) !== JSON.stringify(newIds)) {
            setSelectedOptions(mappedCategories);
          }
        }
      }
    }, [currentShopCategory, initialCategoryItems]);
    const updateText = useCallback(
      async (value: string) => {
        setInputValue(value);

        if (value === "") {
          setOptions(
            initialCategoryItems.map((category) => ({
              value: category.id,
              label: category.fullName,
            })),
          );
          return;
        }

        await fetchCategories(value);
      },
      [initialCategoryItems, fetchCategories],
    );

    const removeTag = useCallback(
      (tag: { id: string; value: string }) => () => {
        console.log("removeTag", tag);
        const newOptions = selectedOptions.filter(
          (option) => option.id !== tag.id,
        );
        setSelectedOptions(newOptions);
        removeASelectedCategory(tag.value, tag.id);
      },
      [selectedOptions, setSelectedOptions, removeASelectedCategory],
    );

    const verticalContentMarkup = useMemo(
      () =>
        selectedOptions.length > 0 ? (
          <LegacyStack spacing="extraTight" alignment="center">
            {selectedOptions.map((option) => {
              let tagLabel = option.value;
              tagLabel = titleCase(tagLabel);
              return (
                <Tag key={`option-${option.id}`} onRemove={removeTag(option)}>
                  {tagLabel}
                </Tag>
              );
            })}
          </LegacyStack>
        ) : null,
      [selectedOptions, removeTag],
    );

    const updateSelection = useCallback(
      (selected: string[]) => {
        if (allowMultiSelect) {
          // For multi-select, update based on what's currently selected
          const newFormattedSelections = selected
            .map((selectedId) =>
              options.find((item) => item.value === selectedId),
            )
            .filter(Boolean)
            .map((item: any) => ({
              id: item.value,
              value: item.label,
            }));

          setSelectedOptions(newFormattedSelections);
        } else {
          // For single select
          const newlySelectedItems = selected
            .map((selectedId) =>
              options.find((item) => item.value === selectedId),
            )
            .filter(Boolean) as OPTION[];

          const newFormattedSelections = newlySelectedItems.map((item) => ({
            id: item.value,
            value: item.label,
          }));

          setSelectedOptions(newFormattedSelections);
        }
      },
      [options, setSelectedOptions, allowMultiSelect],
    );
    const textField = (
      <Autocomplete.TextField
        onChange={updateText}
        label=""
        readOnly={!allowTyping}
        value={inputValue}
        placeholder="Search"
        autoComplete="off"
        verticalContent={verticalContentMarkup}
      />
    );

    return (
      <div style={{ height: height, width: width }}>
        <Autocomplete
          options={options}
          preferredPosition="mostSpace"
          selected={selectedOptions.map((option) => option.id)}
          onSelect={updateSelection}
          listTitle="Suggested Categories"
          loading={isLoading}
          textField={textField}
          allowMultiple={allowMultiSelect}
        />
      </div>
    );
  },
);

function titleCase(string: string) {
  return string
    .toLowerCase()
    .split(" ")
    .map((word) => word.replace(word[0], word[0].toUpperCase()))
    .join(" ");
}
