export const RightMostStrightLine: React.FC<{ height: number }> = ({
  height,
}) => {
  // console.log("height", height);
  return (
    <div
      style={{
        width: 5,
        backgroundColor: "#000",
        height,
        borderRadius: 15,
      }}
    />
  );
};
