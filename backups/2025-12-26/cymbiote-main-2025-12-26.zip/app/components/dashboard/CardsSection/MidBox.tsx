import { Text } from "@shopify/polaris";
import * as React from "react";

export const MidBox: React.FC<{
  subject: string;
  value: string;
  boxWidth: number;
}> = ({ subject, value, boxWidth }) => {
  return (
    <div
      style={{
        width: "100%",
        padding: 10,
        display: "flex",
        flexDirection: "column",
        justifyContent: "space-between",
      }}
    >
      <Text
        as="p"
        fontWeight="bold"
        variant={boxWidth > 150 ? "headingLg" : "headingMd"}
      >
        {value}
      </Text>
      <Text
        as="p"
        fontWeight="medium"
        variant={
          boxWidth > 250
            ? "headingLg"
            : boxWidth > 150
              ? "headingSm"
              : "headingSm"
        }
      >
        {subject}
      </Text>
    </div>
  );
};
