import { BlockStack, Card, Grid, InlineStack } from "@shopify/polaris";
import React, { useEffect, useState } from "react";
import { RightMostStrightLine } from "./RightMostStrightLine";
import { MidBox } from "./MidBox";

interface Props {
  totalOrders: number;
  cancelledOrders: number;
  publishedProducts: number;
  totalSale: number;
  shopCurrency?: string;
}

export const CardsSection: React.FC<Props> = ({
  cancelledOrders,
  publishedProducts,
  totalOrders,
  totalSale,
  shopCurrency,
}) => {
  const [boxWidth, setBoxWidth] = useState(window.innerWidth / 4 - 110);
  const [boxLineHeight, setBoxLineHeight] = useState(
    boxWidth > 250 ? 100 : 100,
  );

  // Function to update width
  const updateWidth = () => {
    const boxWidth = window.innerWidth / 4 - 100;
    // console.log("boxWidth", boxWidth);
    setBoxWidth(boxWidth);
    setBoxLineHeight(boxWidth > 250 ? 100 : 100);
  };

  // Listen to window resize
  useEffect(() => {
    window.addEventListener("resize", updateWidth);

    // Cleanup listener on unmount
    return () => {
      window.removeEventListener("resize", updateWidth);
    };
  }, []);

  // console.log("boxWidth", boxWidth);
  return (
    <BlockStack inlineAlign="stretch" role="group">
      <Grid columns={{ xs: 1, sm: 2, md: 2, lg: 4 }}>
        <Grid.Cell>
          <Card padding={"600"}>
            <div style={{ display: "flex" }}>
              <RightMostStrightLine height={boxLineHeight} />
              <MidBox
                value={totalOrders.toLocaleString()}
                subject="Total Orders"
                boxWidth={boxWidth}
              />
              <div>
                <img src="/images/dashboard/orderscard.png" alt="order" />
              </div>
            </div>
          </Card>
        </Grid.Cell>
        <Grid.Cell>
          <Card padding={"600"}>
            <div style={{ display: "flex" }}>
              <RightMostStrightLine height={boxLineHeight} />
              <MidBox
                value={cancelledOrders.toLocaleString()}
                subject="Cancelled Orders"
                boxWidth={boxWidth}
              />
              <div>
                <img src="/images/dashboard/cancelcard.png" alt="cancel" />
              </div>
            </div>
          </Card>
        </Grid.Cell>
        <Grid.Cell>
          <Card padding={"600"}>
            <div style={{ display: "flex" }}>
              <RightMostStrightLine height={boxLineHeight} />
              <MidBox
                value={publishedProducts.toLocaleString()}
                subject="Published Products"
                boxWidth={boxWidth}
              />
              <div>
                <img src="/images/dashboard/publishcard.png" alt="products" />
              </div>
            </div>
          </Card>
        </Grid.Cell>
        <Grid.Cell>
          <Card padding={"600"}>
            <div style={{ display: "flex" }}>
              <RightMostStrightLine height={boxLineHeight} />
              <MidBox
                value={`${totalSale.toLocaleString("en-PK", { maximumFractionDigits: 0 })} ${shopCurrency}`}
                subject="Total Sale"
                boxWidth={boxWidth}
              />
              <div>
                <img src="/images/dashboard/salescard.png" alt="sales" />
              </div>
            </div>
          </Card>
        </Grid.Cell>
      </Grid>
    </BlockStack>
  );
};
