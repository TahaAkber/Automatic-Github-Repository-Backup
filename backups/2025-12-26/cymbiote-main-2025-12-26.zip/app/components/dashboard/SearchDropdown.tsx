import React, { useCallback, useState, useMemo, useEffect } from "react";
import { Autocomplete, LegacyStack, Tag } from "@shopify/polaris";

interface Props {
  initialCategoryItems: any[];
  selectedOptions: {
    value: string;
    id: string;
  }[];
  setSelectedOptions: React.Dispatch<
    React.SetStateAction<
      {
        value: string;
        id: string;
      }[]
    >
  >;
  allowTyping?: boolean;
  height?: string;
  width?: number;
  allowMultiSelect: boolean;
  removeASelectedCategory: (category: string, id: string) => void;
  currentShopCategory?: any;
}

interface OPTION {
  value: string;
  label: string;
}

export const SearchDropdown = React.memo<Props>(
  ({
    initialCategoryItems,
    selectedOptions,
    setSelectedOptions,
    allowMultiSelect,
    removeASelectedCategory,
    allowTyping = true,
    height = "auto",
    width = 160,
    currentShopCategory,
  }) => {
    const [isLoading, setIsLoading] = useState(false);
    const [inputValue, setInputValue] = useState("");
    const [options, setOptions] = useState<OPTION[]>(
      initialCategoryItems.map((category) => ({
        value: category.id,
        label: category.fullName,
      })),
    );

    const fetchCategories = useCallback(async (searchTerm: string) => {
      setIsLoading(true);
      try {
        const response = await fetch(
          `/api/categories?searchTerm=${searchTerm}`,
        );
        const data = await response.json();
        console.log("API response Categories", data);
        const categoryItems =
          data?.productCategories.taxonomy.categories.nodes.map(
            (category: any) => ({
              label: category.name,
              value: category.id,
            }),
          );
        setOptions(categoryItems);
      } catch (error) {
        console.error("Error fetching product categories:", error);
      } finally {
        setIsLoading(false);
      }
    }, []);
    useEffect(() => {
      if (
        currentShopCategory &&
        selectedOptions.length === 0 &&
        initialCategoryItems?.length > 0
      ) {
        const match = initialCategoryItems.find(
          (item) =>
            item.fullName === currentShopCategory.category_name ||
            item.id === currentShopCategory.id,
        );

        if (match) {
          setSelectedOptions([
            {
              id: match.id,
              value: match.fullName,
            },
          ]);
        }
      }
    }, [
      currentShopCategory,
      initialCategoryItems,
      selectedOptions,
      setSelectedOptions,
    ]);
    const updateText = useCallback(
      async (value: string) => {
        setInputValue(value);

        if (value === "") {
          setOptions(
            initialCategoryItems.map((category) => ({
              value: category.id,
              label: category.fullName,
            })),
          );
          return;
        }

        // Fetch new categories based on the search input
        await fetchCategories(value);
      },
      [initialCategoryItems, fetchCategories],
    );

    const removeTag = useCallback(
      (tag: { id: string; value: string }) => () => {
        console.log("removeTag", tag);
        const newOptions = selectedOptions.filter(
          (option) => option.value !== tag.value,
        );
        setSelectedOptions(newOptions);
        removeASelectedCategory(tag.value, tag.id);
      },
      [selectedOptions, setSelectedOptions, removeASelectedCategory],
    );

    const verticalContentMarkup = useMemo(
      () =>
        selectedOptions.length > 0 ? (
          <LegacyStack spacing="extraTight" alignment="center">
            {selectedOptions.map((option: any) => {
              let tagLabel = option.value;
              tagLabel = titleCase(tagLabel);
              return (
                <Tag key={`option${option}`} onRemove={removeTag(option)}>
                  {tagLabel}
                </Tag>
              );
            })}
          </LegacyStack>
        ) : null,
      [selectedOptions, removeTag],
    );

    const updateSelection = useCallback(
      (selected: string[]) => {
        // const selectedText = selected.map((selectedItem) => {
        //   const matchedOption = options.find((option) =>
        //     option.value.match(selectedItem),
        //   );
        //   return matchedOption && matchedOption.label;
        // });
        const selectedItem = options.find((item) => item.value === selected[0]);
        console.log("updateSelection", selected);
        setSelectedOptions(
          selectedItem
            ? [
                {
                  id: selectedItem.value,
                  value: selectedItem.label,
                },
              ]
            : [
                {
                  id: "",
                  value: "",
                },
              ],
        );
      },
      [options, setSelectedOptions],
    );

    const textField = (
      <Autocomplete.TextField
        onChange={updateText}
        label=""
        readOnly={!allowTyping}
        value={inputValue}
        // prefix={<Icon source={SearchIcon} />}
        placeholder="Search"
        autoComplete="off"
        verticalContent={verticalContentMarkup}
      />
    );

    return (
      <div style={{ height: height, width: width }}>
        <Autocomplete
          options={options}
          preferredPosition="mostSpace"
          selected={selectedOptions.map((option) => option.value)}
          onSelect={updateSelection}
          listTitle="Suggested Categories"
          loading={isLoading}
          textField={textField}
          allowMultiple={allowMultiSelect}
        />
      </div>
    );
  },
);

function titleCase(string: string) {
  console.log("titleCase", string);
  return string
    .toLowerCase()
    .split(" ")
    .map((word) => word.replace(word[0], word[0].toUpperCase()))
    .join("");
}
