import React, { useCallback, useState, useMemo, useEffect } from "react";
import { SearchIcon } from "@shopify/polaris-icons";
import {
  Autocomplete,
  BlockStack,
  Icon,
  InlineStack,
  LegacyStack,
  Tag,
  TextField,
} from "@shopify/polaris";

interface Props {
  height?: string;
  searchUrl: string;
  selectedOptions: {
    value: string;
    id: string;
  }[];
  shopifyCategory: string;
  loadCategories: boolean;
  allowMultiSelect: boolean;
  initialCategoryItems: any[];
  setSelectedOptions: React.Dispatch<
    React.SetStateAction<
      {
        value: string;
        id: string;
        categoryFullname: string;
      }[]
    >
  >;
}

interface OPTION {
  value: string;
  label: string;
  categoryFullname: string;
}

const fetchProductTaxonomies = async (
  searchUrl: string,
  searchTerm: string,
) => {
  try {
    const encodedSearchTerm = encodeURIComponent(searchTerm); // Encode searchTerm
    const response = await fetch(
      `/api/categories${searchUrl}&searchTerm=${encodedSearchTerm}`,
    );
    const data = await response.json();

    return data;
  } catch (error: any) {
    console.log("failed to fetch categories", error.message);
    return {};
  }
};

export const CatalogSearchDropdown = React.memo<Props>(
  ({
    searchUrl,
    selectedOptions,
    shopifyCategory,
    loadCategories,
    setSelectedOptions,
    initialCategoryItems,
  }) => {
    const [isLoading, setIsLoading] = useState(false);
    const [inputValue, setInputValue] = useState(shopifyCategory);
    const [options, setOptions] = useState<OPTION[]>(
      initialCategoryItems.map((category) => ({
        value: category.id,
        label: category.fullName,
        categoryFullname: category.fullName,
      })),
    );

    const fetchCategories = useCallback(async (searchTerm: string) => {
      setIsLoading(true);
      try {
        const data = await fetchProductTaxonomies(searchUrl, searchTerm);
        const categoryItems =
          data?.productCategories.taxonomy.categories.nodes.map(
            (category: any) => ({
              label: category.name,
              value: category.id,
              categoryFullname: category.fullName,
            }),
          );
        setOptions(categoryItems);
      } catch (error) {
        console.error("Error fetching product categories:", error);
      } finally {
        setIsLoading(false);
      }
    }, []);

    const updateText = useCallback(
      async (value: string) => {
        setInputValue(value);

        if (value === "") {
          setOptions(
            initialCategoryItems.map((category) => ({
              value: category.id,
              label: category.fullName,
              categoryFullname: category.fullName,
            })),
          );
          return;
        }

        // Fetch new categories based on the search input
        await fetchCategories(value);
      },
      [initialCategoryItems, fetchCategories],
    );

    const updateSelection = useCallback(
      (selected: string[]) => {
        const selectedItem = options.find((item) => item.value === selected[0]);
        setSelectedOptions(
          selectedItem
            ? [
                {
                  id: selectedItem.value,
                  value: selectedItem.label,
                  categoryFullname: selectedItem.categoryFullname,
                },
              ]
            : [
                {
                  id: "",
                  value: "",
                  categoryFullname: "",
                },
              ],
        );

        setInputValue(selectedItem?.label as string);
      },
      [options, setSelectedOptions],
    );

    useEffect(() => {
      const selectCurrentCategory = async () => {
        const data = await fetchProductTaxonomies(searchUrl, inputValue);

        const category = data?.productCategories.taxonomy.categories.nodes.find(
          (category: any) =>
            category.name.toLowerCase() === inputValue.toLowerCase(),
        );

        if (category) {
          setSelectedOptions([
            {
              id: category.id,
              value: category.name,
              categoryFullname: category.fullName,
            },
          ]);
        }
      };

      // console.log("inputValue", inputValue, loadCategories);
      if (inputValue !== "" && loadCategories) {
        selectCurrentCategory();
      }
    }, [loadCategories, inputValue, searchUrl]);

    const textField = (
      <Autocomplete.TextField
        onChange={updateText}
        label=""
        value={inputValue}
        placeholder="Search"
        autoComplete="off"
      />
    );

    const selectedCategories: string[] = selectedOptions.map((e: any) => e.id);

    return (
      <Autocomplete
        options={options}
        selected={selectedCategories}
        onSelect={updateSelection}
        listTitle="Suggested Categories"
        loading={isLoading}
        textField={textField}
        allowMultiple={false}
      />
    );
  },
);

// function titleCase(string: string) {
//   // console.log("titleCase", string);
//   return string
//     .toLowerCase()
//     .split(" ")
//     .map((word) => word.replace(word[0], word[0].toUpperCase()))
//     .join("");
// }
