import {
  Badge,
  BlockStack,
  Card,
  Divider,
  InlineStack,
  Text,
} from "@shopify/polaris";
import { Tone } from "@shopify/polaris/build/ts/src/components/Badge";
import React from "react";
import { PaddedDiv } from "~/components/common/PaddedDiv";
import { useNavigate } from "@remix-run/react";

interface TrendingCollectionProps {
  trendingCollections: any[];
  search: any;
}

export const TrendingCollection: React.FC<TrendingCollectionProps> = ({
  trendingCollections,
  search,
}) => {
  const navigate = useNavigate();
  return (
    <Card padding="0">
      <div
        style={{
          // paddingTop: trendingCollections.length === 0 ? "25px" : "10px",
          // paddingBottom: trendingCollections.length === 0 ? "25px" : "10px",

          height: 185,
        }}
      >
        <div style={{ padding: "20px 20px 10px 20px" }}>
          <Text as="h2" fontWeight="semibold" variant="headingMd">
            Trending collections
          </Text>
        </div>
        <BlockStack>
          <PaddedDiv
            children={
              <InlineStack blockAlign="center" align="space-between">
                <Text as="p" tone="disabled" variant="bodySm" truncate>
                  Active collections
                </Text>
                <Text as="p" tone="disabled" variant="bodySm" truncate>
                  Products
                </Text>
              </InlineStack>
            }
          />
          <Divider />
          {trendingCollections.length === 0 && (
            <div style={{ padding: "20px", textAlign: "center" }}>
              <Text as="p" tone="disabled">
                No collection found
              </Text>
            </div>
          )}
          {trendingCollections?.map(
            (collection, index) =>
              index < 2 && (
                <div key={collection.collection_name || index}>
                  <PaddedDiv
                    children={
                      <InlineStack blockAlign="center" align="space-between">
                        <Badge size="small" tone={collection.tone as Tone}>
                          {collection.collection_name}
                        </Badge>{" "}
                        <Text as="p" variant="bodySm">
                          {collection.Collection_Products?.length || 0}
                        </Text>
                      </InlineStack>
                    }
                  />
                  <Divider />
                </div>
              ),
          )}
          {trendingCollections.length > 2 && (
            <PaddedDiv>
              <span
                onClick={() =>
                  navigate({ pathname: "/app/collection", search })
                }
                style={{
                  color: "#5c6ac4",
                  cursor: "pointer",
                  textDecoration: "underline",
                }}
              >
                <Text as="p">See more...</Text>
              </span>
            </PaddedDiv>
          )}
        </BlockStack>
      </div>
    </Card>
  );
};
