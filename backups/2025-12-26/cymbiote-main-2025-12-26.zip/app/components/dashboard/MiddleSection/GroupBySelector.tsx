import { Select, Text } from "@shopify/polaris";
import React, { useCallback, useState, FC } from "react";

interface Props {
  onChange: (value: string) => void;
}

export const GroupBySelector: FC<Props> = ({ onChange }) => {
  const [selected, setSelected] = useState("month");

  const handleSelectChange = useCallback((value: string) => {
    setSelected(value);
    onChange(value);
  }, []);

  const options = [
    { label: "Day", value: "day" },
    { label: "Week", value: "week" },
    { label: "Month", value: "month" },
  ];

  return (
    <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
      <Text as="span" variant="bodyMd">
        Group by
      </Text>
      <Select
        label=""
        options={options}
        onChange={handleSelectChange}
        value={selected}
      />
    </div>
  );
};
