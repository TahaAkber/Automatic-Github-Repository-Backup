import { BlockStack, Card, Divider, InlineStack, Text } from "@shopify/polaris";
import React, { useState } from "react";
import { PaddedDiv } from "~/components/common/PaddedDiv";

interface Props {
  productCounts: {
    product_id: number;
    product_name: string;
    count: number;
  }[];
}

export const ActiveUsers: React.FC<Props> = ({ productCounts }) => {
  const [expanded, setExpanded] = useState(false);
  const sortedProducts = [...productCounts].sort((a, b) => b.count - a.count);
  const sum = sortedProducts.reduce((a, b) => a + b.count, 0);

  return (
    <Card padding="0">
      <div
        style={{
          // paddingTop: productCounts.length === 0 ? "25px" : "0px",
          // paddingBottom: productCounts.length === 0 ? "25px" : "0px",
          height: 225,
        }}
      >
        <div style={{ padding: "20px 20px 10px 20px" }}>
          <Text as="h2" fontWeight="semibold" variant={"headingMd"}>
            Total Sold Products
          </Text>
          <div
            style={{
              width: "100%",
              backgroundColor: "#B192E8",
              height: 40,
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              color: "#fff",
              marginTop: 5,
            }}
          >
            <Text as="p" variant="headingLg" tone="inherit" fontWeight="medium">
              {sum}
            </Text>
          </div>
        </div>

        <BlockStack>
          <PaddedDiv>
            <InlineStack blockAlign="center" align="space-between">
              <Text as="p" tone="disabled">
                Best Selling
              </Text>
              <Text as="p" tone="disabled">
                Quantity
              </Text>
            </InlineStack>
          </PaddedDiv>
          <Divider />

          <div
            style={
              expanded
                ? {
                    maxHeight: "62px",
                    overflowY: "auto",
                  }
                : undefined
            }
          >
            {(expanded ? sortedProducts : sortedProducts.slice(0, 2)).map(
              (page) => (
                <div key={page.product_id} style={{ cursor: "pointer" }}>
                  <PaddedDiv>
                    <InlineStack blockAlign="center" align="space-between">
                      <div
                        style={{
                          maxWidth: "180px",
                          overflow: "hidden",
                          textOverflow: "ellipsis",
                          whiteSpace: "nowrap",
                        }}
                        title={page.product_name}
                      >
                        <Text as="p">{page.product_name}</Text>
                      </div>
                      <Text as="p" variant="bodySm">
                        {page.count}
                      </Text>
                    </InlineStack>
                  </PaddedDiv>
                  <Divider />
                </div>
              ),
            )}
          </div>
          {productCounts.length > 2 && (
            <PaddedDiv>
              <span
                onClick={() => setExpanded(!expanded)}
                style={{
                  color: "#5c6ac4",
                  cursor: "pointer",
                  textDecoration: "underline",
                }}
              >
                <Text as="p">{expanded ? "Show less..." : "See more..."}</Text>
              </span>
            </PaddedDiv>
          )}
          {productCounts.length === 0 && (
            <div style={{ padding: "12px", textAlign: "center" }}>
              <Text as="p" tone="disabled">
                No sold products found
              </Text>
            </div>
          )}
        </BlockStack>
      </div>
    </Card>
  );
};
