import { Select, Icon } from "@shopify/polaris";
import React, { useCallback, useState, FC } from "react";
import { CalendarIcon } from "@shopify/polaris-icons";

interface Props {
  startYear: number; // Define earliest year to show
  selectYear: (year: number) => void;
}

export const YearButton: FC<Props> = ({ startYear, selectYear }) => {
  const currentYear = new Date().getFullYear();
  const [selected, setSelected] = useState(currentYear.toString());

  const handleSelectChange = useCallback((value: string) => {
    setSelected(value);
    selectYear(parseInt(value));
  }, []);

  // Generate year options dynamically
  const options = [];

  // Add permitted past years based on `startYear`
  for (let year = startYear; year <= currentYear; year++) {
    options.push({
      label: year === currentYear ? "Current Year" : year.toString(),
      value: year.toString(),
      prefix: <Icon source={CalendarIcon} />,
    });
  }

  // Add future years dynamically
  for (let year = currentYear + 1; year <= currentYear + 5; year++) {
    options.push({
      label: year.toString(),
      value: year.toString(),
      prefix: <Icon source={CalendarIcon} />,
    });
  }

  return (
    <div style={{ position: "relative" }}>
      <Select
        label=""
        options={options}
        onChange={handleSelectChange}
        value={selected}
      />
    </div>
  );
};
