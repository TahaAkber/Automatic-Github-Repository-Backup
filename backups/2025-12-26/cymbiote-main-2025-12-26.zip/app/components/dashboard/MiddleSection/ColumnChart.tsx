import { Card, InlineStack, Text } from "@shopify/polaris";
import React, { useState } from "react";
import { YearButton } from "./YearButton";
import { CalendarButton } from "~/components/common/CalendarButton";
import {
  Bar,
  BarChart,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import { GroupBySelector } from "./GroupBySelector";
import dayjs from "dayjs";

export const ColumnChart = ({ fetchedCircleOrders }: any) => {
  const getMonthlyOrderData = (orders: any[]) => {
    const monthNames = {
      0: "Jan",
      1: "Feb",
      2: "Mar",
      3: "Apr",
      4: "May",
      5: "June",
      6: "July",
      7: "Aug",
      8: "Sept",
      9: "Oct",
      10: "Nov",
      11: "Dec",
    };

    const monthlyTotals: Record<string, number> = {
      Jan: 0,
      Feb: 0,
      Mar: 0,
      Apr: 0,
      May: 0,
      June: 0,
      July: 0,
      Aug: 0,
      Sept: 0,
      Oct: 0,
      Nov: 0,
      Dec: 0,
    };

    orders.forEach((item: any) => {
      const date = dayjs(item.order_date);
      const month = monthNames[
        date.month() as keyof typeof monthNames
      ] as keyof typeof monthlyTotals;
      const amount = parseFloat(item.order_total_amount) || 0;

      if (monthlyTotals[month] !== undefined) {
        monthlyTotals[month] += amount;
      }
    });

    const monthlyGraphData = Object.entries(monthlyTotals).map(
      ([name, pkr]) => ({
        name,
        pkr,
      }),
    );

    return monthlyGraphData;
  };
  const getDynamicMargin = (data: any[]) => {
    // Longest label length for XAxis
    const maxLabelLength = Math.max(...data.map((d) => d.name?.length || 0));

    // Maximum Y-axis value
    const maxValue = Math.max(...data.map((d) => d.pkr || 0));

    // Add margin based on length/value
    const leftMargin = maxValue > 100000 ? 60 : 40; // adjust for big numbers
    const bottomMargin = maxLabelLength > 5 ? 40 : 20;

    return { top: 20, right: 20, left: leftMargin, bottom: bottomMargin };
  };

  const monthlyChartData = getMonthlyOrderData(fetchedCircleOrders);
  // console.log("================", monthlyChartData);
  const [{ month, year }, setDate] = useState({
    month: new Date().getMonth(),
    year: new Date().getFullYear(),
  });

  const [selectedYear, SetSelectedYear] = useState(new Date().getFullYear());
  const [selectedDates, setSelectedDates] = useState({
    start: new Date(),
    end: new Date(),
  });

  const margin = getDynamicMargin(monthlyChartData);
  return (
    <Card>
      <InlineStack blockAlign="stretch" align="space-between">
        <InlineStack align="start" blockAlign="center" gap={"200"}>
          <Text as="p">Date Range</Text>
          <YearButton selectYear={SetSelectedYear} startYear={2025} />
          <CalendarButton
            month={month}
            selectedDates={selectedDates}
            setDate={setDate}
            setSelectedDates={setSelectedDates}
            year={year}
            borderColor={"#8A8A8A"}
          />
        </InlineStack>
        <div style={{ margin: 31 }}>
          <GroupBySelector
            onChange={(value) => console.log("Selected:", value)}
          />
        </div>
      </InlineStack>
      <ResponsiveContainer width="100%" height={295}>
        <BarChart data={monthlyChartData} margin={margin}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="name" />
          <YAxis unit={"-pkr"} style={{ color: "yellow" }} />
          <Tooltip />
          <Bar dataKey="pkr" fill="#FFD333" />
        </BarChart>
      </ResponsiveContainer>
    </Card>
  );
};
