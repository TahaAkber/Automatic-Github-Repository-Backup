import React, { useEffect, useState } from "react";
import { TrendingCollection } from "./TrendingCollection";
import { ActiveUsers } from "./ActiveUsers";
import { ColumnChart } from "./ColumnChart";
import { BlockStack, Grid } from "@shopify/polaris";

export interface MiddleSectionProps {
  fetchedCircleOrders: any[];
  trendingCollections: any[];
  productCounts: {
    product_id: number;
    product_name: string;
    count: number;
  }[];
  search: any;
}

export const MiddleSection: React.FC<MiddleSectionProps> = ({
  fetchedCircleOrders,
  trendingCollections,
  productCounts,
  search,
}) => {
  const [boxWidth, setBoxWidth] = useState(
    typeof window !== "undefined" ? window.innerWidth / 4 - 100 : 0,
  );
  const [boxLineHeight, setBoxLineHeight] = useState(100);

  // Function to update width
  const updateWidth = () => {
    const boxWidth = window.innerWidth / 4 - 100;
    console.log("boxWidth", boxWidth);
    setBoxWidth(boxWidth);
    setBoxLineHeight(boxWidth > 250 ? 100 : 70);
  };

  // Listen to window resize
  useEffect(() => {
    window.addEventListener("resize", updateWidth);

    // Cleanup listener on unmount
    return () => {
      window.removeEventListener("resize", updateWidth);
    };
  }, []);

  // if (typeof window !== "undefined") {
  //   console.log("window.innerWidth", window.innerWidth);
  // }
  return (
    <BlockStack align="space-between">
      <Grid columns={{ xs: 1, sm: 3, md: 3, lg: 8 }}>
        <Grid.Cell columnSpan={{ xs: 6, md: 4, lg: 2 }}>
          <BlockStack gap="300">
            <TrendingCollection
              trendingCollections={trendingCollections}
              search={search}
            />
            <ActiveUsers productCounts={productCounts} />
          </BlockStack>
        </Grid.Cell>
        <Grid.Cell columnSpan={{ xs: 6, sm: 6, md: 4, lg: 6 }}>
          <ColumnChart fetchedCircleOrders={fetchedCircleOrders} />
        </Grid.Cell>
      </Grid>
    </BlockStack>
  );
};
