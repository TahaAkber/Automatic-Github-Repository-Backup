import { Button, InlineStack } from "@shopify/polaris";
import { SearchIcon, CheckCircleIcon } from "@shopify/polaris-icons";
import React from "react";
import { BigAvatar } from "./BigAvatar";

export const AvatarSection: React.FC<{
  shop_logo_url?: string;
  shop_name: string;
}> = ({ shop_name, shop_logo_url }) => {
  return (
    <InlineStack align="center" blockAlign="center" gap={{ sm: "100" }}>
      <BigAvatar src="\images\common\cerle_logo_1200.png" />

      <div style={{ border: 1, borderStyle: "dashed", height: 1, width: 30 }} />
      <Button
        icon={CheckCircleIcon}
        size="medium"
        variant="plain"
        tone="success"
      />
      <div style={{ border: 1, borderStyle: "dashed", height: 1, width: 30 }} />

      <BigAvatar src={shop_logo_url || ""} storeName={shop_name} />
    </InlineStack>
  );
};
