import { Avatar, Text } from "@shopify/polaris";
import React from "react";
import { getInitials } from "~/functions/common";

export const BigAvatar: React.FC<{
  src: string;
  storeName?: string;
  height?: string;
  width?: string;
}> = ({ src, storeName, width = 90, height = 90 }) => {
  console.log("BigAvatar src", src);
  return (
    <div
      style={{
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        borderRadius: 50,
        border: "1px solid #ddd",
        // padding: 0,
        overflow: "hidden",
      }}
    >
      {src !== "" ? (
        <img
          style={{ padding: 6 }}
          src={src ?? "/images/common/cerle_logo_1200.png"}
          alt="Cercle Logo"
          width={width}
          height={height}
        />
      ) : (
        <div
          style={{
            padding: 6,
            width,
            height,
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            backgroundColor: "#f4f6f8",
          }}
        >
          <Text as="p" fontWeight="medium" variant="headingLg">
            {getInitials(storeName ?? "Cercle")}
          </Text>
        </div>
      )}
    </div>
  );
};
