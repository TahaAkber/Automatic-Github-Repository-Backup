import {
  BlockStack,
  Box,
  Button,
  ButtonGroup,
  Card,
  Divider,
  Icon,
  InlineStack,
  Text,
} from "@shopify/polaris";
import React from "react";
import {
  OrderIcon,
  ProductFilledIcon,
  EmailIcon,
} from "@shopify/polaris-icons";
import { BigAvatar } from "./BigAvatar";

interface Props {
  loading: boolean;
  shop_name: string;
  shop_email: string;
  shop_icon_image: string;
  authorizeEmail: () => void;
}

export const AuthorizationSection: React.FC<Props> = ({
  loading,
  shop_name,
  shop_email,
  authorizeEmail,
  shop_icon_image,
}) => {
  return (
    <InlineStack align="center">
      <Card>
        <Box minWidth="400px">
          <BlockStack gap={{ xs: "300" }}>
            <InlineStack gap={{ xs: "300" }} align="start">
              <BlockStack>
                <BigAvatar
                  src={shop_icon_image ?? `./images/common/cerle_logo_1200.png`}
                  height="40"
                  width="40"
                />
              </BlockStack>
              <BlockStack>
                <Text as="p" fontWeight="bold" variant="bodyMd">
                  {shop_name ?? "Shop Name"}
                </Text>
                <Text as="p" variant="bodyXs" tone="disabled">
                  Want to access your cercle account
                </Text>
              </BlockStack>
            </InlineStack>

            <div style={{ height: 10 }} />

            <InlineStack gap={{ xs: "300" }} align="start">
              <BlockStack>
                <Icon source={ProductFilledIcon} tone="primary" />
              </BlockStack>
              <BlockStack>
                <Text as="p" fontWeight="bold" variant="bodyMd">
                  Shopify Products
                </Text>
                <Text as="p" variant="bodyXs" tone="disabled">
                  Full Access
                </Text>
              </BlockStack>
            </InlineStack>

            <InlineStack gap={{ xs: "300" }} align="start">
              <BlockStack>
                <Icon source={OrderIcon} tone="primary" />
              </BlockStack>
              <BlockStack>
                <Text as="p" fontWeight="bold" variant="bodyMd">
                  Shopify Orders
                </Text>
                <Text as="p" variant="bodyXs" tone="disabled">
                  Full Access
                </Text>
              </BlockStack>
            </InlineStack>

            <Divider borderWidth="050" borderColor="border-hover" />

            <Text as="p" fontWeight="semibold" variant="bodySm">
              Organization Access
            </Text>

            <InlineStack align="start" blockAlign="center" gap={{ xs: "100" }}>
              <Box>
                <Icon source={EmailIcon} tone="primary" />
              </Box>
              <Text as="p" variant="bodyXs" tone="disabled">
                {shop_email ?? "info@email.com"}
              </Text>
            </InlineStack>

            <ButtonGroup fullWidth>
              <Button size="medium" onClick={() => window.close()}>
                Cancel
              </Button>
              <Button
                variant="primary"
                size="medium"
                loading={loading}
                onClick={authorizeEmail}
              >
                Authorize with cercle
              </Button>
            </ButtonGroup>
          </BlockStack>
        </Box>
      </Card>
    </InlineStack>
  );
};
