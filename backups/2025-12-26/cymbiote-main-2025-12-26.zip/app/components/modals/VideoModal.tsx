import { Modal, TextContainer } from "@shopify/polaris";

// Define the props for the modal component
interface VideoModal {
  open: boolean;
  onClose: () => void;
  title: string;
  message: string;
  confirmLabel?: string;
  cancelLabel?: string;
  //   onConfirm: () => void;
}

/**
 * Reusable ConfirmationModal component for displaying confirmation dialogs.
 */
const VideoModal: React.FC<VideoModal> = ({
  open,
  onClose,
  title,
  message,
  confirmLabel = "Close",
}) => {
  return (
    <Modal
      open={open}
      onClose={onClose}
      title={title}
      primaryAction={{
        content: confirmLabel,
        onAction: onClose,
      }}
    >
      <Modal.Section>
        <TextContainer>
          <p dangerouslySetInnerHTML={{ __html: message }} />
        </TextContainer>
      </Modal.Section>
    </Modal>
  );
};

export default VideoModal;
