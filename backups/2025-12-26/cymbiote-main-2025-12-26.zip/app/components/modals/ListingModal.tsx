import React, { useState, useEffect } from "react";
import { Modal, TextContainer, TextField } from "@shopify/polaris";

interface ConfirmationModalProps {
  open: boolean;
  onClose: () => void;
  title: string;
  message: string;
  onConfirm: () => void;
  storeName?: string;
  confirmLabel?: string;
  cancelLabel?: string;
}

const ListingModal: React.FC<ConfirmationModalProps> = ({
  open,
  onClose,
  title,
  message,
  onConfirm,
  storeName = "",
  confirmLabel = "Confirm",
  cancelLabel = "Cancel",
}) => {
  const [inputName, setInputName] = useState("");
  const [error, setError] = useState<string | undefined>(undefined);

  useEffect(() => {
    if (!open) {
      setInputName("");
      setError(undefined);
    }
  }, [open]);

  const handleChange = (value: string) => {
    setInputName(value);
    if (storeName && value.trim() !== storeName.trim()) {
      setError("Store name does not match.");
    } else {
      setError(undefined);
    }
  };

  const isConfirmDisabled = !storeName || inputName.trim() !== storeName.trim();

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={title}
      primaryAction={{
        content: confirmLabel,
        onAction: onConfirm,
        disabled: isConfirmDisabled,
      }}
      secondaryActions={[
        {
          content: cancelLabel,
          onAction: onClose,
          disabled: false,
        },
      ]}
    >
      <Modal.Section>
        <TextContainer>
          <p>{message}</p>
          <TextField
            label={`Please type your store name (${storeName}) to confirm `}
            value={inputName}
            onChange={handleChange}
            error={error}
            autoComplete="off"
            disabled={!storeName}
          />
        </TextContainer>
      </Modal.Section>
    </Modal>
  );
};

export default ListingModal;
