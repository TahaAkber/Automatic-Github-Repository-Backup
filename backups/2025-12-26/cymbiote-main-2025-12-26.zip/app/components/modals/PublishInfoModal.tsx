import { Modal, Spinner, TextContainer } from "@shopify/polaris";

// Define the props for the modal component
interface ConfirmationModalProps {
  open: boolean;
  onClose: () => void;
  title: string;
  message: string;
  confirmLabel?: string;
  cancelLabel?: string;
  isLoading?: boolean;
}

/**
 * Reusable ConfirmationModal component for displaying confirmation dialogs.
 */
const PublishInfoModal: React.FC<ConfirmationModalProps> = ({
  open,
  onClose,
  title,
  message,
  isLoading,
}) => {
  return (
    <Modal
      open={open}
      onClose={onClose}
      title={title}
      secondaryActions={[
        {
          content: "Okay",
          onAction: onClose,
        },
      ]}
    >
      <Modal.Section>
        {isLoading && <Spinner size="small" />}
        <TextContainer>
          <p dangerouslySetInnerHTML={{ __html: message }} />
        </TextContainer>
      </Modal.Section>
    </Modal>
  );
};

export default PublishInfoModal;
