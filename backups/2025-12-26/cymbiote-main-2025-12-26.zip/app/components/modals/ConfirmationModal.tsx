import { Modal, TextContainer } from "@shopify/polaris";

// Define the props for the modal component
interface ConfirmationModalProps {
  open: boolean;
  onClose: () => void;
  title: string;
  message: string;
  confirmLabel?: string;
  cancelLabel?: string;
  onConfirm: () => void;
  isLoading?: boolean;
}

/**
 * Reusable ConfirmationModal component for displaying confirmation dialogs.
 */
const ConfirmationModal: React.FC<ConfirmationModalProps> = ({
  open,
  onClose,
  title,
  message,
  confirmLabel = "Yes",
  cancelLabel = "No",
  onConfirm,
  isLoading,
}) => {
  return (
    <Modal
      open={open}
      onClose={onClose}
      title={title}
      primaryAction={{
        content: confirmLabel,
        onAction: onConfirm,
        loading: isLoading,
      }}
      secondaryActions={[
        {
          content: cancelLabel,
          onAction: onClose,
        },
      ]}
    >
      <Modal.Section>
        <TextContainer>
          <p dangerouslySetInnerHTML={{ __html: message }} />
        </TextContainer>
      </Modal.Section>
    </Modal>
  );
};

export default ConfirmationModal;
