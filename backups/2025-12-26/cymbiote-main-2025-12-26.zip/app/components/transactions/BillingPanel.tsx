import {
  BlockStack,
  Box,
  Button,
  Collapsible,
  Divider,
  Icon,
  InlineGrid,
  InlineStack,
  Text,
  Card,
  Link,
} from "@shopify/polaris";
import { useMemo, useState } from "react";
import { ChevronDownIcon, ChevronUpIcon } from "@shopify/polaris-icons";

// --- One billing period panel
export function BillingPanel({
  usageCount,
  tileCharges,
  periodLabel,
  creditAmount,
  subscriptionId,
  trackingEnabled,
  trackingCharges,
  tileSubscription,
  subscriptionDesc,
  subscriptionName,
  subscriptionCharges,
  defaultOpen = true,
  usageRateLabel = "3% per order charged",
  reelLabel = "10 extra reels purchased",
  usageAmount = "0.00",
  reelAmount = "0.00",
  reelsPurchased = false,
}: {
  reelLabel?: string;
  reelAmount?: string;
  periodLabel: string;
  usageAmount?: string;
  tileCharges?: string;
  creditAmount?: string;
  defaultOpen?: boolean;
  subscriptionId: number;
  usageRateLabel?: string;
  trackingCharges?: string;
  reelsPurchased?: boolean;
  subscriptionName: string;
  subscriptionDesc: string;
  trackingEnabled?: boolean;
  tileSubscription?: boolean;
  usageCount: number | string;
  subscriptionCharges: string;
}) {
  const [open, setOpen] = useState(defaultOpen);
  const total = useMemo(() => {
    const a = Number(usageAmount) || 0;
    const b = Number(reelAmount) || 0;
    const c = Number(subscriptionCharges) || 0;
    const d = (tileSubscription && Number(tileCharges)) || 0;
    const e = Number(trackingCharges) || 0;
    const f = Number(creditAmount) || 0;
    return (a + b + c + d + e - f).toFixed(2);
  }, [
    usageAmount,
    reelAmount,
    subscriptionCharges,
    tileCharges,
    tileSubscription,
  ]);

  const url = new URL(window.location.href);

  return (
    <Box
      padding="300"
      borderWidth="025"
      borderColor="border"
      background="bg-surface"
      shadow="100"
      borderRadius="0"
    >
      {/* Header */}
      <Card background="bg" roundedAbove={"none"}>
        <InlineStack align="space-between" blockAlign="center">
          <Text as="h3" variant="headingSm" fontWeight="semibold">
            Billing ({periodLabel})
          </Text>
          <Button
            variant="plain"
            onClick={() => setOpen((v) => !v)}
            icon={
              <Icon
                source={open ? ChevronUpIcon : ChevronDownIcon}
                tone="base"
              />
            }
            accessibilityLabel={open ? "Collapse" : "Expand"}
          />
        </InlineStack>
      </Card>

      {/* Body */}
      <Collapsible
        id="body"
        open={open}
        transition={{ duration: "200ms", timingFunction: "ease" }}
      >
        <BlockStack gap="300">
          <Divider />
          <Row
            label={
              <Text as="span" variant="bodyMd" fontWeight="semibold" truncate>
                Subscription Fees ({subscriptionName || "Plan Name"})
              </Text>
            }
            sublabel={subscriptionDesc || "Monthly subscription charges"}
            amount={subscriptionCharges || "0.00"}
          />
          <Divider />
          <Row
            label={
              (usageCount as number) > 0 ? (
                <Link
                  url={`/app/subscription/transactions/${subscriptionId}${url.search}`}
                >
                  Usage Transactions ({usageCount})
                </Link>
              ) : (
                <Text as="span" variant="bodyMd" fontWeight="semibold" truncate>
                  Usage Transactions ({usageCount})
                </Text>
              )
            }
            sublabel={usageRateLabel}
            amount={usageAmount}
          />
          {tileSubscription && <Divider />}
          {tileSubscription && (
            <Row label={"Tile Subscription"} amount={tileCharges as string} />
          )}
          {reelsPurchased && <Divider />}
          {reelsPurchased && <Row label={reelLabel} amount={reelAmount} />}
          {trackingEnabled && <Divider />}
          {trackingEnabled && (
            <Row
              label={"Tracking Charges"}
              amount={trackingCharges as string}
            />
          )}
          {creditAmount && <Divider />}
          {creditAmount && <Row label={"Credits"} amount={creditAmount} />}
          <Divider />
          <InlineGrid columns={2}>
            <Text as="p" fontWeight="semibold">
              Total:
            </Text>
            <Text alignment="end" as="p" fontWeight="semibold">
              ${total}
            </Text>
          </InlineGrid>
        </BlockStack>
      </Collapsible>
    </Box>
  );
}

function Row({
  label,
  sublabel,
  amount,
}: {
  label: React.ReactNode;
  sublabel?: string;
  amount: string;
}) {
  return (
    <InlineGrid columns={{ sm: 2 }} gap="200">
      <BlockStack gap="050">
        <Text as="p" fontWeight="semibold" variant="bodyMd">
          {label}
        </Text>
        {sublabel ? (
          <Text as="p" tone="subdued" variant="bodySm">
            {sublabel}
          </Text>
        ) : null}
      </BlockStack>
      <Text as="p" alignment="end" variant="bodyMd">
        ${label === "Credits" ? `-${amount}` : amount}
      </Text>
    </InlineGrid>
  );
}
