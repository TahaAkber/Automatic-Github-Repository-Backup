import { ActionList, Button, Popover } from "@shopify/polaris";
import React, { useCallback, useState } from "react";

export const ActionListComp: React.FC<{
  active: boolean;
  setActive: any;
  handleBillingCycleClick: () => void;
}> = ({ active, setActive, handleBillingCycleClick }) => {
  const toggleActive = useCallback(
    () => setActive((active: any) => !active),
    [],
  );

  const activator = (
    <Button onClick={toggleActive} disclosure>
      Want to see older billings?
    </Button>
  );
  return (
    <div>
      <Popover
        active={active}
        activator={activator}
        autofocusTarget="first-node"
        onClose={toggleActive}
      >
        <ActionList
          actionRole="menuitem"
          items={[
            {
              content: "Import file",
              onAction: handleBillingCycleClick,
            },
            {
              content: "Export file",
              onAction: handleBillingCycleClick,
            },
          ]}
        />
      </Popover>
    </div>
  );
};
