import {
  AccountConnection,
  Link,
  Modal,
  Text,
  Button,
  Box,
  InlineStack,
  Divider,
  Toast,
  Frame,
  TextField,
  BlockStack,
} from "@shopify/polaris";
import { useState, useCallback, useEffect } from "react";
import { useNavigate } from "@remix-run/react";

type Props = {
  shop: any; // shop object
  App: string; // App display name, e.g., "Cercle"
  search: string; // e.g., "?shop=my-shop.myshopify.com"
  newEmail: string;
  userName?: string;
  termsUrl?: string; // optional terms URL
  newEmailError: any;
  connected?: boolean; // initial connected state
  handleAuthorize: any;
  isNewEmailValid: any;
  existingAccountEmail?: string; // optional detected email
  handleAccountDisconnect: () => void;
  setNewEmail: (value: string) => void;
  isValidEmail: (value: string) => any;
  setNewEmailError: (value: any) => void;
};

export default function Accountsection({
  App,
  shop,
  search,
  newEmail,
  userName,
  setNewEmail,
  isValidEmail,
  newEmailError,
  isNewEmailValid,
  handleAuthorize,
  setNewEmailError,
  existingAccountEmail,
  handleAccountDisconnect,
  connected: connectedState,
  termsUrl = "/legal/terms",
}: Props) {
  const [connected, setConnected] = useState(connectedState || false);
  const [showConnectModal, setShowConnectModal] = useState(false);
  const [showDisconnectModal, setShowDisconnectModal] = useState(false);
  const [showToast, setShowToast] = useState<string | null>(null);

  const accountName = connected ? existingAccountEmail?.replace(".", " ") : "";

  useEffect(() => {
    handleModalCancel();
    setConnected(connectedState || false);
  }, [connectedState]);

  // --- Actions ---
  const handleOpen = useCallback(() => {
    if (connected) setShowDisconnectModal(true);
    else setShowConnectModal(true);
  }, [connected]);

  const handleDisconnect = useCallback(async () => {
    // TODO: Call your backend to unlink the account before flipping state.
    setConnected(false);
    setShowDisconnectModal(false);
    handleAccountDisconnect();
    setShowToast("Disconnected from app.");
  }, []);

  const handleModalCancel = useCallback(() => {
    setShowConnectModal(false);
    setShowDisconnectModal(false);
    setNewEmailError(undefined);
  }, []);

  // --- Static UI strings ---
  const buttonText = connected ? "Disconnect" : "Connect";
  const details = connected
    ? `Account connected(${existingAccountEmail})`
    : "No account connected";

  const connectTerms = (
    <p>
      By clicking <strong>Connect</strong>, you agree to accept {App} App’s{" "}
      <Link url={termsUrl} target="_blank">
        terms and conditions
      </Link>
      . You’ll pay a commission on sales made through {App} App.
    </p>
  );

  const disconnectTerms = (
    <p>
      By clicking <strong>Disconnect</strong>, you agree to remove your store
      from {App} App and stop sales processing through {App} App. Commissions
      will no longer apply.
    </p>
  );

  const terms = connected ? disconnectTerms : connectTerms;

  return (
    <BlockStack>
      <AccountConnection
        accountName={accountName}
        connected={connected}
        title={App}
        action={{ content: buttonText, onAction: handleOpen }}
        details={details}
        termsOfService={terms}
      />

      {/* Connect modal */}
      <Modal
        open={showConnectModal}
        onClose={handleModalCancel}
        title="Connect your account"
        // primaryAction={{
        //   content: "Authorize",
        //   onAction: () => handleAuthorize(existingAccountEmail),
        // }}
        secondaryActions={[{ content: "Cancel", onAction: handleModalCancel }]}
      >
        <Modal.Section>
          <Box paddingBlockStart="200">
            <Text as="p" variant="bodyMd">
              You’re about to connect your store to {App} App.
            </Text>
          </Box>

          <Box paddingBlockStart="400" paddingBlockEnd="200">
            <Divider />
          </Box>

          {/* Existing account */}
          <InlineStack align="space-between" blockAlign="center">
            <Box>
              <Text as="h3" variant="bodyMd" fontWeight="semibold">
                Existing account
              </Text>
              <Text as="p" variant="bodySm" tone="subdued">
                {existingAccountEmail || "No saved email"}
              </Text>
            </Box>
            <Button
              onClick={() => handleAuthorize(newEmail || existingAccountEmail)}
              tone="critical"
              disabled={newEmail.toString() !== "" ? true : false}
            >
              Authorize
            </Button>
          </InlineStack>

          <Box paddingBlockStart="400" paddingBlockEnd="200">
            <Divider />
          </Box>

          {/* New account */}
          <InlineStack align="space-between" blockAlign="center" gap="400">
            <Box maxWidth="60%">
              <Text as="h3" variant="bodyMd" fontWeight="semibold">
                Or connect a new account
              </Text>
              <TextField
                label="Email address"
                labelHidden
                value={newEmail}
                placeholder="Enter your email"
                onChange={(v) => {
                  setNewEmail(v);
                  if (v && !isValidEmail(v))
                    setNewEmailError("Enter a valid email");
                  else setNewEmailError(undefined);
                }}
                autoComplete="email"
                error={newEmailError}
              />
            </Box>
            <Button
              onClick={() => handleAuthorize(newEmail || undefined)}
              tone="critical"
              disabled={!isNewEmailValid || newEmail.toString() === ""}
            >
              Authorize
            </Button>
          </InlineStack>

          <Box paddingBlockStart="400">
            <Text as="p" variant="bodySm" tone="subdued">
              By continuing, you accept {App} App’s{" "}
              <Link url={termsUrl} target="_blank">
                terms and conditions
              </Link>
              .
            </Text>
          </Box>
        </Modal.Section>
      </Modal>

      {/* Disconnect confirm modal */}
      <Modal
        open={showDisconnectModal}
        onClose={handleModalCancel}
        title="Disconnect from app?"
        primaryAction={{ content: "Disconnect", onAction: handleDisconnect }}
        secondaryActions={[{ content: "Cancel", onAction: handleModalCancel }]}
      >
        <Modal.Section>
          <Text as="p" variant="bodyMd">
            Your store will be disconnected from {App} App. No further sales
            will be processed and commissions will no longer apply. Existing
            orders remain unaffected.
          </Text>
        </Modal.Section>
      </Modal>

      {showToast && (
        <Frame>
          <Toast
            content={showToast}
            onDismiss={() => setShowToast(null)}
            duration={3000}
          />
        </Frame>
      )}
    </BlockStack>
  );
}
