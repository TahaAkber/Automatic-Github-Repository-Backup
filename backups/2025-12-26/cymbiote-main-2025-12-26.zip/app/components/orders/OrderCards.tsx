import React, { useEffect, useState } from "react";
import { InlineGrid, ProgressBar, Text, Icon } from "@shopify/polaris";
import {
  StatusActiveIcon,
  DeliveryIcon,
  ViewIcon,
} from "@shopify/polaris-icons";

export default function OrderCards({
  upcommingOrders,
  shippedOrders,
}: {
  upcommingOrders: any[];
  shippedOrders: any[];
}) {
  const trackingDetails = upcommingOrders.flatMap(
    (order) =>
      order.Tracking?.map((tracking: any) => ({
        status: tracking.tracking_status,
        details: tracking,
      })) || [],
  );

  const trackingCounts: any = {
    IN_PROGRESS: 0,
    DELIVERED: 0,
    OUT_FOR_DELIVERY: 0,
    IN_TRANSIT: 0,
    FAILURE: 0,
  };

  trackingDetails.forEach(({ status }) => {
    if (trackingCounts.hasOwnProperty(status)) {
      trackingCounts[status] += 1;
    }
  });
  console.log(trackingDetails);
  console.log("Total Tracking Status Count:", trackingDetails.length);
  console.log("In Progress Orders:", trackingCounts["IN_PROGRESS"]);
  console.log("FAILURE Orders:", trackingCounts["FAILURE"]);
  console.log("IN_TRANSIT Orders:", trackingCounts["IN_TRANSIT"]);
  console.log("OUT_FOR_DELIVERY Orders:", trackingCounts["OUT_FOR_DELIVERY"]);
  console.log("Delivered Orders:", trackingCounts["DELIVERED"]);

  const placeholderData = [
    {
      value: trackingCounts["IN_PROGRESS"],
      status: "In Progress",
      color: "#2e7dc0",
      icon: "https://cdn.shopify.com/s/files/1/0595/2379/2944/files/in-progress-svgrepo-com_1.svg?v=1742542229",
    },
    {
      value: shippedOrders.length,
      status: "Shipped",
      color: "#fcb913",
      icon: "https://cdn.shopify.com/s/files/1/0595/2379/2944/files/Layer_1_2.svg?v=1742542643",
      Textcolor: "black",
    },
    {
      value: trackingCounts["IN_TRANSIT"],
      status: "In Transit",
      color: "#f67f21",
      icon: "https://cdn.shopify.com/s/files/1/0595/2379/2944/files/shipped-truck-svgrepo-com_1.svg?v=1742542569",
    },
    {
      value: trackingCounts["DELIVERED"],
      status: "Delivered",
      color: "#23b577",
      icon: "https://cdn.shopify.com/s/files/1/0595/2379/2944/files/Layer_1_1.svg?v=1742542542",
    },
    {
      value: trackingCounts["FAILURE"],
      status: "Cancelled",
      color: "#ed1f23",
      icon: "https://cdn.shopify.com/s/files/1/0595/2379/2944/files/Layer_1.svg?v=1742542497",
    },
  ];

  return (
    <SpacingBackground>
      <InlineGrid
        gap={{ md: "100", lg: "050", xl: "0" }}
        columns={{ sm: 2, md: 3, lg: 5, xl: 5 }}
      >
        {placeholderData.map((data, index) => (
          <Placeholder
            key={index}
            height={{ default: 80, sm: 90, md: 100 }} 
            width="90%"
            value={data.value}
            status={data.status}
            backgroundColor={data.color}
            icon={data.icon}
            textcolor={data.Textcolor}
          />
        ))}
      </InlineGrid>
    </SpacingBackground>
  );
}

const SpacingBackground = ({
  children,
  width = "100%",
}: {
  children: React.ReactNode;
  width?: string;
}) => {
  return (
    <div
      style={{
        width,
        height: "auto",
      }}
    >
      {children}
    </div>
  );
};

const Placeholder = ({
  height = "auto",
  width = "auto",
  value,
  status,
  backgroundColor,
  icon,
  textcolor,
}: any) => {
  return (
    <div
      style={{
        borderRadius: 10,
        background: backgroundColor,
        height: height ?? undefined,
        width: width ?? undefined,
        margin: "10px",
        padding: "15px",
      }}
    >
      <div
        style={{
          height: "100%",
          width: "100%",
          display: "flex",
          flexDirection: "row",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <div
          style={{
            display: "flex",
            flexDirection: "row",
            height: "100%",
            width: "90%",
          }}
        >
          <div
            style={{
              display: "flex",
              border: `2px solid ${textcolor ?? "white"}`,
              height: "100%",
              flexDirection: "column",
              borderRadius: "15px",
              alignItems: "flex-start",
            }}
          ></div>
          <div
            style={{
              display: "flex",
              flexDirection: "column",
              alignItems: "flex-start",
              color: textcolor ?? "white",

              gap: 10,
              marginLeft: "10%",
              //justifyContent: "Space-between is much more cleaner than center"
              justifyContent: "center",
            }}
          >
            <Text variant="headingLg" as="strong">
              {value}
            </Text>
            <Text as="legend">{status}</Text>
          </div>
        </div>
        <div
          style={{
            height: "100%",
            flexDirection: "column",
            alignItems: "flex-start",
          }}
        >
          <img src={icon} alt="Description of image" />
        </div>
      </div>
    </div>
  );
};
