import { useNavigate } from "@remix-run/react";
import {
  Badge,
  ChoiceList,
  IndexFilters,
  IndexFiltersProps,
  IndexTable,
  RangeSlider,
  TabProps,
  Text,
  TextField,
  useIndexResourceState,
  useSetIndexFiltersMode,
} from "@shopify/polaris";
import React, { useCallback, useEffect, useState } from "react";
import { disambiguateLabel, isEmpty } from "~/functions/common";

interface Props {
  orders: any[];
  selectOrder: (selected: string) => void;
  getOrders: (orderFilter: string) => void;
  viewType: string;
  setQueryValue: (value: string) => void;
  shop: any;
  queryValue: string;
  setSortSelected: (value: any[]) => void;
  sortSelected: any[];
  setSelected: (value: any) => void;
  selected: any;
  setItemStrings: (value: any[]) => void;
  itemStrings: any[];
}
export default function parseLocalizedNumber(value: string): number {
  return parseFloat(value.replace(/,/g, ""));
}
export const OrderTable: React.FC<Props> = ({
  orders,
  selectOrder,
  getOrders,
  viewType,
  setQueryValue,
  setSortSelected,
  sortSelected,
  queryValue,
  setSelected,
  selected,
  setItemStrings,
  itemStrings,
  shop,
}) => {
  const navigate = useNavigate();
  const { mode, setMode } = useSetIndexFiltersMode();
  const [accountStatus, setAccountStatus] = useState<string[] | undefined>(
    undefined,
  );
  const [moneySpent, setMoneySpent] = useState<[number, number] | undefined>(
    undefined,
  );
  const [taggedWith, setTaggedWith] = useState("");
  const sleep = (ms: number) =>
    new Promise((resolve) => setTimeout(resolve, ms));

  // const [selected, setSelected] = useState(viewType ? 4 : 0);
  const onCreateNewView = async (value: string) => {
    await sleep(500);
    setItemStrings([...itemStrings, value]);
    setSelected(itemStrings.length);
    return true;
  };

  const handleAccountStatusRemove = useCallback(
    () => setAccountStatus(undefined),
    [],
  );
  const handleMoneySpentRemove = useCallback(
    () => setMoneySpent(undefined),
    [],
  );
  const handleTaggedWithRemove = useCallback(() => setTaggedWith(""), []);

  // const deleteView = (index: number) => {
  //   const newItemStrings = [...itemStrings];
  //   newItemStrings.splice(index, 1);
  //   setItemStrings(newItemStrings);
  //   setSelected(0);
  // };

  // useEffect(() => {
  //   // if (itemStrings[selected] !== "All")
  //   {
  //     void getOrders(itemStrings[selected]);
  //   }
  // }, [selected]);

  const sortOptions: IndexFiltersProps["sortOptions"] = [
    { label: "Order", value: "order asc", directionLabel: "Ascending" },
    { label: "Order", value: "order desc", directionLabel: "Descending" },
    { label: "Customer", value: "customer asc", directionLabel: "A-Z" },
    { label: "Customer", value: "customer desc", directionLabel: "Z-A" },
    { label: "Date", value: "date asc", directionLabel: "A-Z" },
    { label: "Date", value: "date desc", directionLabel: "Z-A" },
  ];
  const shopCurrency = shop?.shop_currency || "PKR";
  const resourceName = {
    singular: "order",
    plural: "orders",
  };

  const onHandleCancel = () => {};

  const onHandleSave = async () => {
    await sleep(1);
    return true;
  };

  const primaryAction: IndexFiltersProps["primaryAction"] =
    selected === 0
      ? {
          type: "save-as",
          onAction: onCreateNewView,
          disabled: false,
          loading: false,
        }
      : {
          type: "save",
          onAction: onHandleSave,
          disabled: false,
          loading: false,
        };

  const handleFiltersQueryChange = useCallback(
    (value: string) => setQueryValue(value),
    [],
  );
  const handleAccountStatusChange = useCallback(
    (value: string[]) => setAccountStatus(value),
    [],
  );
  const handleMoneySpentChange = useCallback(
    (value: [number, number]) => setMoneySpent(value),
    [],
  );
  const handleTaggedWithChange = useCallback(
    (value: string) => setTaggedWith(value),
    [],
  );

  const handleQueryValueRemove = useCallback(() => setQueryValue(""), []);

  const { selectedResources, allResourcesSelected, handleSelectionChange } =
    useIndexResourceState(orders, {
      resourceIDResolver: (item) => item.order_id,
    });

  const handleFiltersClearAll = useCallback(() => {
    handleAccountStatusRemove();
    handleMoneySpentRemove();
    handleTaggedWithRemove();
    handleQueryValueRemove();
  }, [
    handleAccountStatusRemove,
    handleMoneySpentRemove,
    handleQueryValueRemove,
    handleTaggedWithRemove,
  ]);
  useEffect(() => {}, [selected]);
  const filters = [
    {
      key: "accountStatus",
      label: "Account status",
      filter: (
        <ChoiceList
          title="Account status"
          titleHidden
          choices={[
            { label: "Enabled", value: "enabled" },
            { label: "Not invited", value: "not invited" },
            { label: "Invited", value: "invited" },
            { label: "Declined", value: "declined" },
          ]}
          selected={accountStatus || []}
          onChange={handleAccountStatusChange}
          allowMultiple
        />
      ),
      shortcut: true,
    },
    {
      key: "taggedWith",
      label: "Tagged with",
      filter: (
        <TextField
          label="Tagged with"
          value={taggedWith}
          onChange={handleTaggedWithChange}
          autoComplete="off"
          labelHidden
        />
      ),
      shortcut: true,
    },
    {
      key: "moneySpent",
      label: "Money spent",
      filter: (
        <RangeSlider
          label="Money spent is between"
          labelHidden
          value={moneySpent || [0, 500]}
          prefix="$"
          output
          min={0}
          max={2000}
          step={1}
          onChange={handleMoneySpentChange}
        />
      ),
    },
  ];

  const tabs: TabProps[] = itemStrings.map((item, index) => ({
    content: item,
    id: `${item}-${index}`,
    index,
    isLocked: false, // Ensure selection works
    onAction: () => handleSelect(index), // Ensure selection changes
  }));
  const handleSelect = (index: number) => {
    console.log("Selected Tab:", index); // Debugging
    setSelected(index);
    selectedResources.length = 0;
  };
  // const duplicateView = async (name: string) => {
  //   setItemStrings([...itemStrings, name]);
  //   setSelected(itemStrings.length);
  //   await sleep(1);
  //   return true;
  // };

  const rowMarkup = orders.map(
    (
      {
        id,
        order_id,
        order,
        date,
        customer,
        total,
        paymentStatus,
        fulfillmentStatus,
        totalTransectionAmt,
        orderRate,
      },
      index,
    ) => (
      <IndexTable.Row
        id={order_id}
        key={order_id}
        selected={selectedResources.includes(order_id)}
        position={index}
        onClick={() => {
          selectOrder(order_id);
        }}
      >
        <IndexTable.Cell>
          <Text variant="bodyMd" fontWeight="bold" as="span">
            {order}
          </Text>
        </IndexTable.Cell>
        <IndexTable.Cell>{date}</IndexTable.Cell>
        <IndexTable.Cell>{customer}</IndexTable.Cell>
        <IndexTable.Cell>
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
            }}
          >
            <span>{total}</span>
          </div>
        </IndexTable.Cell>
        <IndexTable.Cell>{paymentStatus}</IndexTable.Cell>
        <IndexTable.Cell>{fulfillmentStatus}</IndexTable.Cell>
        {/* if order has transaction then cercle transaction is completed */}
        <IndexTable.Cell>
          <Badge tone={totalTransectionAmt != 0 ? "success" : "warning"}>
            {totalTransectionAmt != 0 ? "Completed" : "Pending"}
          </Badge>
        </IndexTable.Cell>
        <IndexTable.Cell>{orderRate}%</IndexTable.Cell>
        <IndexTable.Cell>
          <div
            style={{
              display: "flex",
              width: "90px",
              justifyContent: "space-between",
            }}
          >
            <span>
              {orderRate
                ? Number(
                    (
                      parseLocalizedNumber(
                        typeof total === "string"
                          ? total.split(" ")[1] || total
                          : total,
                      ) *
                      (orderRate / 100)
                    ).toFixed(2),
                  ).toLocaleString()
                : "0"}
            </span>
          </div>
        </IndexTable.Cell>
        <IndexTable.Cell>{shopCurrency}</IndexTable.Cell>
      </IndexTable.Row>
    ),
  );

  const appliedFilters: IndexFiltersProps["appliedFilters"] = [];
  if (accountStatus && !isEmpty(accountStatus)) {
    const key = "accountStatus";
    appliedFilters.push({
      key,
      label: disambiguateLabel(key, accountStatus),
      onRemove: handleAccountStatusRemove,
    });
  }
  if (moneySpent) {
    const key = "moneySpent";
    appliedFilters.push({
      key,
      label: disambiguateLabel(key, moneySpent),
      onRemove: handleMoneySpentRemove,
    });
  }
  if (!isEmpty(taggedWith)) {
    const key = "taggedWith";
    appliedFilters.push({
      key,
      label: disambiguateLabel(key, taggedWith),
      onRemove: handleTaggedWithRemove,
    });
  }
  return (
    <div>
      <IndexFilters
        sortOptions={sortOptions}
        sortSelected={sortSelected}
        queryValue={queryValue}
        queryPlaceholder="Search Customers..."
        onQueryChange={handleFiltersQueryChange}
        onQueryClear={() => setQueryValue("")}
        onSort={setSortSelected}
        primaryAction={primaryAction}
        cancelAction={{
          onAction: onHandleCancel,
          disabled: false,
          loading: false,
        }}
        tabs={tabs}
        selected={selected}
        onSelect={setSelected}
        canCreateNewView={false}
        // onCreateNewView={onCreateNewView}
        filters={[]}
        appliedFilters={appliedFilters}
        onClearAll={handleFiltersClearAll}
        mode={mode}
        setMode={setMode}
      />
      <IndexTable
        resourceName={resourceName}
        itemCount={orders.length}
        selectedItemsCount={
          allResourcesSelected ? "All" : selectedResources.length
        }
        selectable={false}
        onSelectionChange={handleSelectionChange}
        headings={[
          { title: "Order" },
          { title: "Date" },
          { title: "Customer" },
          { title: "Total" },
          { title: "Payment status" },
          { title: "Fulfillment status" },
          { title: "Cercle transaction status" },
          { title: "Cercle comission rate" },
          { title: "Cercle comission" },
          { title: "Currency" },
        ]}
      >
        {rowMarkup}
      </IndexTable>
    </div>
  );
};
