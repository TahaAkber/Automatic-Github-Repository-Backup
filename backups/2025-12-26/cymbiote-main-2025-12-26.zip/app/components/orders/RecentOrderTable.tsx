import { useNavigate } from "@remix-run/react";
import {
  Bleed,
  Card,
  ChoiceList,
  IndexFilters,
  IndexFiltersProps,
  IndexTable,
  InlineGrid,
  Layout,
  RangeSlider,
  TabProps,
  Text,
  TextField,
  useIndexResourceState,
  useSetIndexFiltersMode,
} from "@shopify/polaris";
import React, { useCallback, useEffect, useState } from "react";
import { disambiguateLabel, isEmpty } from "~/functions/common";
import parseLocalizedNumber from "./OrderTable";

interface Props {
  orders: any[];
  selectOrder?: (selected: string) => void;
  getOrders?: (orderFilter: string) => void;
  viewType: string;
  shopCurrency: any;
}

export const RecentOrderTable: React.FC<Props> = ({
  orders,
  selectOrder,
  getOrders,
  viewType,
  shopCurrency,
}) => {
  const [sortSelected, setSortSelected] = useState(["order asc"]);
  const { mode, setMode } = useSetIndexFiltersMode();
  const [accountStatus, setAccountStatus] = useState<string[] | undefined>(
    undefined,
  );
  const [moneySpent, setMoneySpent] = useState<[number, number] | undefined>(
    undefined,
  );
  const [taggedWith, setTaggedWith] = useState("");
  const [queryValue, setQueryValue] = useState("");
  const sleep = (ms: number) =>
    new Promise((resolve) => setTimeout(resolve, ms));
  const [itemStrings, setItemStrings] = useState([
    "All",
    "Unpaid",
    "Open",
    "Closed",
    "Cancelled",
    // 'Local pickup',
  ]);

  const [selected, setSelected] = useState(viewType ? 4 : 0);
  const onCreateNewView = async (value: string) => {
    await sleep(500);
    setItemStrings([...itemStrings, value]);
    setSelected(itemStrings.length);
    return true;
  };

  const handleAccountStatusRemove = useCallback(
    () => setAccountStatus(undefined),
    [],
  );
  const handleMoneySpentRemove = useCallback(
    () => setMoneySpent(undefined),
    [],
  );
  const handleTaggedWithRemove = useCallback(() => setTaggedWith(""), []);

  useEffect(() => {
    if (getOrders) {
      void getOrders(itemStrings[selected]);
    }
  }, [selected]);

  const sortOptions: IndexFiltersProps["sortOptions"] = [
    { label: "Order", value: "order asc", directionLabel: "Ascending" },
    { label: "Order", value: "order desc", directionLabel: "Descending" },
    { label: "Customer", value: "customer asc", directionLabel: "A-Z" },
    { label: "Customer", value: "customer desc", directionLabel: "Z-A" },
    { label: "Date", value: "date asc", directionLabel: "A-Z" },
    { label: "Date", value: "date desc", directionLabel: "Z-A" },
    { label: "Total", value: "total asc", directionLabel: "Ascending" },
    { label: "Total", value: "total desc", directionLabel: "Descending" },
  ];

  const resourceName = {
    singular: "order",
    plural: "orders",
  };

  const onHandleCancel = () => {};

  const onHandleSave = async () => {
    await sleep(1);
    return true;
  };

  const primaryAction: IndexFiltersProps["primaryAction"] =
    selected === 0
      ? {
          type: "save-as",
          onAction: onCreateNewView,
          disabled: false,
          loading: false,
        }
      : {
          type: "save",
          onAction: onHandleSave,
          disabled: false,
          loading: false,
        };

  const handleFiltersQueryChange = useCallback(
    (value: string) => setQueryValue(value),
    [],
  );
  const handleAccountStatusChange = useCallback(
    (value: string[]) => setAccountStatus(value),
    [],
  );
  const handleMoneySpentChange = useCallback(
    (value: [number, number]) => setMoneySpent(value),
    [],
  );
  const handleTaggedWithChange = useCallback(
    (value: string) => setTaggedWith(value),
    [],
  );

  const handleQueryValueRemove = useCallback(() => setQueryValue(""), []);

  const { selectedResources, allResourcesSelected, handleSelectionChange } =
    useIndexResourceState(orders);

  const handleFiltersClearAll = useCallback(() => {
    handleAccountStatusRemove();
    handleMoneySpentRemove();
    handleTaggedWithRemove();
    handleQueryValueRemove();
  }, [
    handleAccountStatusRemove,
    handleMoneySpentRemove,
    handleQueryValueRemove,
    handleTaggedWithRemove,
  ]);

  const filters = [
    {
      key: "accountStatus",
      label: "Account status",
      filter: (
        <ChoiceList
          title="Account status"
          titleHidden
          choices={[
            { label: "Enabled", value: "enabled" },
            { label: "Not invited", value: "not invited" },
            { label: "Invited", value: "invited" },
            { label: "Declined", value: "declined" },
          ]}
          selected={accountStatus || []}
          onChange={handleAccountStatusChange}
          allowMultiple
        />
      ),
      shortcut: true,
    },
    {
      key: "taggedWith",
      label: "Tagged with",
      filter: (
        <TextField
          label="Tagged with"
          value={taggedWith}
          onChange={handleTaggedWithChange}
          autoComplete="off"
          labelHidden
        />
      ),
      shortcut: true,
    },
    {
      key: "moneySpent",
      label: "Money spent",
      filter: (
        <RangeSlider
          label="Money spent is between"
          labelHidden
          value={moneySpent || [0, 500]}
          prefix="$"
          output
          min={0}
          max={2000}
          step={1}
          onChange={handleMoneySpentChange}
        />
      ),
    },
  ];

  const tabs: TabProps[] = itemStrings.map((item, index) => ({
    content: item,
    index,
    onAction: () => {},
    id: `${item}-${index}`,
    isLocked: index === 0,
    actions: index === 0 ? [] : [],
  }));

  const rowMarkup = orders.map(
    (
      {
        id,
        date,
        order,
        total,
        customer,
        orderRate,
        paymentStatus,
        fulfillmentStatus,
        order_delivery_status,
        totalTransectionAmt,
        displayFinancialStatus,
        totalQuantity,
      },
      index,
    ) => (
      <IndexTable.Row
        id={id}
        key={id}
        position={index}
        // Remove this line:
        // selected={selectedResources.includes(id)}
        onClick={() => {
          if (selectOrder) {
            selectOrder(id);
          }
        }}
      >
        <IndexTable.Cell>
          <Text variant="bodyMd" fontWeight="bold" as="span">
            {order}
          </Text>
        </IndexTable.Cell>
        <IndexTable.Cell>{date}</IndexTable.Cell>
        <IndexTable.Cell>{customer}</IndexTable.Cell>
        <IndexTable.Cell>
          {" "}
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
            }}
          >
            <span>{total}</span>
          </div>
        </IndexTable.Cell>
        <IndexTable.Cell>{paymentStatus}</IndexTable.Cell>
        <IndexTable.Cell>{fulfillmentStatus}</IndexTable.Cell>
        <IndexTable.Cell>{totalQuantity}</IndexTable.Cell>
        <IndexTable.Cell>{order_delivery_status}</IndexTable.Cell>
        <IndexTable.Cell>
          <div
            style={{
              display: "flex",
              width: "80px",
              justifyContent: "space-between",
            }}
          >
            <span>
              {orderRate
                ? Number(
                    (
                      parseLocalizedNumber(
                        typeof total === "string"
                          ? total.split(" ")[1] || total
                          : total,
                      ) *
                      (orderRate / 100)
                    ).toFixed(2),
                  ).toLocaleString()
                : "0"}{" "}
            </span>
          </div>
        </IndexTable.Cell>
        <IndexTable.Cell>{shopCurrency}</IndexTable.Cell>
      </IndexTable.Row>
    ),
  );

  const appliedFilters: IndexFiltersProps["appliedFilters"] = [];
  if (accountStatus && !isEmpty(accountStatus)) {
    const key = "accountStatus";
    appliedFilters.push({
      key,
      label: disambiguateLabel(key, accountStatus),
      onRemove: handleAccountStatusRemove,
    });
  }
  if (moneySpent) {
    const key = "moneySpent";
    appliedFilters.push({
      key,
      label: disambiguateLabel(key, moneySpent),
      onRemove: handleMoneySpentRemove,
    });
  }
  if (!isEmpty(taggedWith)) {
    const key = "taggedWith";
    appliedFilters.push({
      key,
      label: disambiguateLabel(key, taggedWith),
      onRemove: handleTaggedWithRemove,
    });
  }

  return (
    <Card padding={"0"}>
      <div style={{ padding: 20 }}>
        <Text as="p" fontWeight="semibold" variant="headingLg">
          Recent Orders
        </Text>
      </div>
      <Layout sectioned></Layout>
      <IndexTable
        resourceName={resourceName}
        selectable={false}
        itemCount={orders.length}
        headings={[
          { title: "Order" },
          { title: "Date" },
          { title: "Customer" },
          { title: "Total" },
          { title: "Payment status" },
          { title: "Fulfillment status" },
          { title: "Items" },
          { title: "Delivery Status" },
          { title: "Cercle comission" },
          { title: "Currency" },
        ]}
      >
        {rowMarkup}
      </IndexTable>
    </Card>
  );
};
