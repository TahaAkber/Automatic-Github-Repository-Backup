import React from "react";
import { useDrag } from "react-dnd";

interface Props {
  products: any[];
  simplecollection: any[];
  fontColor: string;
  storeColor: string;
  isScrolled: boolean;
}

export const ProductCards: React.FC<Props> = ({
  products,
  fontColor,
  simplecollection,
  storeColor,
  isScrolled,
}) => {
  const [{ opacity }, dragRef] = useDrag(
    () => ({
      type: "dropable",
      item: { text: "productCards" },
      collect: (monitor) => ({
        opacity: monitor.isDragging() ? 0.5 : 1,
      }),
    }),
    [],
  );

  return (
    <>
      {simplecollection.length > 0 ? (
        <div ref={dragRef} style={{ opacity }}>
          <div style={{ marginLeft: 16, marginTop: 8 }}>
            <span
              style={{
                fontSize: "1.25rem",
                fontWeight: "bold",
                display: "block",
                marginBottom: "10px",
                color: "#000",
              }}
            >
              Collections
            </span>
          </div>
          <div className="productCards">
            <div className="productCardRow">
              {simplecollection.map((product: any, index: number) => (
                <div
                  className="productCard"
                  key={index}
                  style={{
                    width: "120px",
                    height: "auto",
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "center",
                    borderRadius: "15px",
                  }}
                >
                  <img
                    src={
                      product.collection_banner_url ??
                      "https://cdn.shopify.com/s/files/1/0923/5460/9434/files/no-photo-or-blank-image-icon-loading-images-or-missing-image-mark-image-not-available-or-image-coming-soon-sign-simple-nature-silhouette-in-frame-isolated-illustration-vector.jpg?v=1746776130"
                    }
                    alt={product.collection_name}
                    style={{
                      width: "100%",
                      height: "100px",
                      objectFit: "cover",
                      borderRadius: "8px",
                    }}
                  />
                  <div style={{ marginTop: "6px", textAlign: "start" }}>
                    <p
                      style={{
                        color: fontColor,
                        whiteSpace: "nowrap",
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                        fontSize: "12px",
                      }}
                    >
                      {product.collection_name}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      ) : (
        <div></div>
      )}
    </>
  );
};
