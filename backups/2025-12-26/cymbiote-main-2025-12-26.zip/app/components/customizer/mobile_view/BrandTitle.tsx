import { Text, Thumbnail } from "@shopify/polaris";
import React from "react";

interface Props {
  displayOption: string;
  headerText: string;
  logo: File;
  logoImage: any;
}

export const BrandTitle: React.FC<Props> = ({
  displayOption,
  headerText,
  logo,
  logoImage,
}) => {
  return (
    <div className="brandTitle">
      {displayOption === "text" ? (
        <span
          style={{
            fontWeight: "bold",
            fontSize: headerText.length > 14 ? 24 : 40,
            color: "white",
            marginBottom: 25,
          }}
        >
          {headerText}
        </span>
      ) : logo || logoImage ? (
        <img
          width={100}
          height={100}
          src={logo ? URL.createObjectURL(logo) : logoImage ? logoImage : null}
          alt="Logo"
          style={{ borderRadius: 15 }}
        />
      ) : null}
    </div>
  );
};
