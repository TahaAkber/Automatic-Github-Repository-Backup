import { Button, Icon, Text, Thumbnail } from "@shopify/polaris";
import React from "react";
import StarRating from "~/components/review/StarRating";
import { NotificationIcon } from "@shopify/polaris-icons";
import { SearchIcon } from "@shopify/polaris-icons";
import { StarFilledIcon } from "@shopify/polaris-icons";
interface Props {
  displayOption: string;
  headerText: string;
  logo: File;
  logoImage: any;
  shoprating: string;
  ReviewSum: string;
}

export const Title: React.FC<Props> = ({
  displayOption,
  headerText,
  logo,
  logoImage,
  shoprating,
  ReviewSum,
}) => {
  return (
    <div className="Title">
      <div style={{ margin: 0, justifyContent: "space-between" }}>
        <img
          src={
            logoImage ||
            "https://cdn.shopify.com/s/files/1/0923/5460/9434/files/no-photo-or-blank-image-icon-loading-images-or-missing-image-mark-image-not-available-or-image-coming-soon-sign-simple-nature-silhouette-in-frame-isolated-illustration-vector.jpg?v=1746776130"
          }
          alt="image"
          width={80}
          height={80}
          style={{
            borderRadius: "50%",
            border: "2px solid #fff",
            marginBottom: "5px",
          }}
        />
        <div style={{ marginLeft: 3, color: "black" }}>
          <Text as="h6" fontWeight="bold">
            {headerText}
          </Text>
          <div style={{ display: "flex", width: 70 }} className="starIcon">
            <Text as="p">{parseFloat(shoprating).toFixed(1) || 0}</Text>

            <Icon source={StarFilledIcon} tone="success" />
            <Text as="p">{`(${ReviewSum})`}</Text>
          </div>
        </div>
      </div>
    </div>
  );
};
