// import React from "react";
// import { useDrop, DropTargetMonitor, DragSourceMonitor } from "react-dnd";
// import Banner from "./Banner";
// import { ProductFilters } from "./ProductFilters";
// import { ProductCards } from "./ProductCards";
// import { ProductItemsList } from "./ProductItemsList";

// interface DropZoneDnDProps {
//   banner: File;
//   bannerUrl: any;
//   bannerType: string;
//   filters: any[];
//   products: any[];
//   sequence: string[];
//   onDrop: (draggedItemName: any, targetIndex: number) => void;
// }

// interface DragItem {
//   type: string;
//   name: string;
// }

// // Mapping component names to their respective components
// const componentsMap: Record<string, React.FC<any>> = {
//   banner: (props) => <Banner {...props} />,
//   filters: (props) => <ProductFilters {...props} />,
//   productCards: (props) => <ProductCards {...props} />,
//   productItemsList: (props) => <ProductItemsList {...props} />,
// };

// export const DropZoneDnD: React.FC<DropZoneDnDProps> = ({
//   banner,
//   bannerUrl,
//   bannerType,
//   filters,
//   products,
//   sequence,
//   onDrop,
// }) => {
//   return (
//     <div>
//       {sequence.map((itemName, index) => {
//         const Component = componentsMap[itemName];

//         // Define the drop behavior for each independent drop zone
//         const [{ isOver }, dropRef] = useDrop<
//           DragItem,
//           void,
//           { isOver: boolean }
//         >({
//           accept: "dropable",
//           drop: (draggedItem: any) => onDrop(draggedItem.text, index),
//           collect: (monitor: DropTargetMonitor) => ({
//             isOver: monitor.isOver(),
//           }),
//         });

//         return (
//           <div key={itemName} ref={dropRef}>
//             <Component
//               banner={banner}
//               bannerType={bannerType}
//               bannerUrl={bannerUrl}
//               filters={filters}
//               products={products}
//             />
//           </div>
//         );
//       })}
//     </div>
//   );
// };

// export default DropZoneDnD;
import React from "react";
import { useDrop, DropTargetMonitor } from "react-dnd";
import { ProductFilters } from "./ProductFilters";
import { ProductCards } from "./ProductCards";
import { ProductItemsList } from "./ProductItemsList";
import { ProductVideos } from "./ProductVideos";
interface DropZoneDnDProps {
  filters: any[]; // Filters to pass
  products: any[]; // Products to pass
  sequence: string[]; // Sequence of components to render
  fontColor: string; // Font color to apply
  filtercollections: any[];
  simplecollection: any[];
  videos: any[];
  onDrop: (draggedItemName: any, targetIndex: number) => void; // Drop handling function
  storeColor: string;
  isScrolled: boolean;
  shopCurrency: string;
}

interface DragItem {
  type: string;
  name: string;
}

// Updated componentsMap that passes all relevant props, including fontColor
const componentsMap: Record<string, React.FC<any>> = {
  filters: (props) => <ProductFilters {...props} />,
  productCards: (props) => <ProductCards {...props} />,
  productItemsList: (props) => <ProductItemsList {...props} />,
  productVideos: (props) => <ProductVideos {...props} />,
};

export const DropZoneDnD: React.FC<DropZoneDnDProps> = ({
  filters,
  products,
  sequence,
  fontColor,
  filtercollections,
  simplecollection,
  videos,
  onDrop,
  storeColor,
  shopCurrency,
  isScrolled,
}) => {
  console.log("testing font color ", fontColor);
  return (
    <div>
      {sequence.map((itemName, index) => {
        const Component = componentsMap[itemName];

        // Ensure that the component exists in componentsMap before rendering
        if (!Component) {
          return null; // Skip rendering if the component doesn't exist
        }

        // Define the drop behavior for each independent drop zone
        const [{ isOver }, dropRef] = useDrop<
          DragItem,
          void,
          { isOver: boolean }
        >({
          accept: "dropable",
          drop: (draggedItem: any) => onDrop(draggedItem.text, index),
          collect: (monitor: DropTargetMonitor) => ({
            isOver: monitor.isOver(),
          }),
        });

        return (
          <div key={itemName} ref={dropRef}>
            {/* Pass all the necessary props including fontColor */}
            <Component
              filters={filters}
              products={products}
              fontColor={fontColor} // Passing fontColor to the component
              filtercollections={filtercollections}
              videos={videos}
              simplecollection={simplecollection}
              storeColor={storeColor}
              isScrolled={isScrolled}
              shopCurrency={shopCurrency}
            />
          </div>
        );
      })}
    </div>
  );
};

export default DropZoneDnD;
