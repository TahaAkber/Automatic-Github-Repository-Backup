import { Icon, Text, Thumbnail } from "@shopify/polaris";
import React from "react";
import { useDrag } from "react-dnd";
import { HeartIcon } from "@shopify/polaris-icons";
interface Props {
  products: any[];
  fontColor: string;
  shopCurrency: string;
}

export const ProductItemsList: React.FC<Props> = ({
  products,
  fontColor,
  shopCurrency,
}) => {
  const [{ opacity }, dragRef] = useDrag(
    () => ({
      type: "dropable",
      item: { text: "productItemsList" },
      collect: (monitor) => ({
        opacity: monitor.isDragging() ? 0.5 : 1,
      }),
    }),
    [],
  );
  return (
    <div
      className={"productItemCards"}
      ref={dragRef}
      style={{
        opacity,
        display: "flex",
        flexDirection: "row",
        flexWrap: "wrap",
        justifyContent: "space-between",
      }}
    >
      {products.map((product: any, index: number) => (
        <div
          className={"productItemCard"}
          key={index}
          style={{
            borderRadius: "10px",

            overflow: "hidden",
            padding: "12px",
            backgroundColor: "#fff",
            width: "130px",
            boxShadow: "5px 4px 8px rgba(0, 0, 0, 0.1)",
          }}
        >
          <div
            style={{
              position: "relative",
              width: "100%",
              height: "100%",
              overflow: "hidden",
              borderRadius: "10px",
            }}
          >
            <img
              src={
                product.product_image_url ||
                "https://cdn.shopify.com/s/files/1/0923/5460/9434/files/no-photo-or-blank-image-icon-loading-images-or-missing-image-mark-image-not-available-or-image-coming-soon-sign-simple-nature-silhouette-in-frame-isolated-illustration-vector.jpg?v=1746776130"
              }
              alt={product.product_name}
              style={{ width: "100%", height: "100%", objectFit: "cover" }}
            />
            <div
              style={{
                position: "absolute",
                bottom: 0,
                right: 0,
                borderRadius: "50%",
                padding: "8px",
                cursor: "pointer",
              }}
            >
              <Icon source={HeartIcon} tone="base" />
            </div>
          </div>
          <div
            style={{
              color: fontColor,
              // alignItems: "center",
              // justifyContent: "center",
            }}
          >
            <span
              style={{
                fontWeight: "bold",
                display: "block",
                color: fontColor,
                whiteSpace: "wrap",
                overflow: "hidden",
                textOverflow: "ellipsis",
                textAlign: "start",
                fontSize: "10px",
              }}
            >
              {product.product_name}
            </span>
            <div
              style={{
                display: "flex",
                justifyContent: "flex-start",
                // alignItems: "center",
              }}
            >
              <span style={{ fontWeight: "bold", fontSize: "10px" }}>
                {(product.Product_Variants[0]?.variant_price * 0.7).toFixed(2)}{" "}
                {shopCurrency}
              </span>
              <span
                style={{ textDecoration: "line-through", fontSize: "10px" }}
              >
                {product.Product_Variants[0]?.variant_price} {shopCurrency}
              </span>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};
