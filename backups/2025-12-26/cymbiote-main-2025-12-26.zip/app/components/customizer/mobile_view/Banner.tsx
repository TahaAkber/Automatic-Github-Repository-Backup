import React, { useState } from "react";

const Banner: React.FC<{
  banner: File;
  bannerUrl: any;
  bannerType: string;
}> = ({ banner, bannerUrl, bannerType }) => {
  const [initialType, _] = useState(bannerType);

  const bannerValue = banner
    ? URL.createObjectURL(banner)
    : bannerUrl
      ? bannerUrl
      : "https://cdn.shopify.com/s/files/1/0595/2379/2944/files/img_not_found_cercle.jpg?v=1757333158";

  console.log("banner type value", bannerType, banner, bannerUrl, bannerValue);

  return (
    <div className={"bannerArea"}>
      {/* {(banner || bannerUrl) && bannerType === "image" ? ( */}
      <img
        alt=""
        width="100%"
        style={{
          objectFit: "cover",
          height: "200px", // Increased height for the video
        }}
        src={bannerValue}
      />
      {/* ) : (
        <video
          key={bannerUrl}
          controls={false}
          autoPlay
          muted
          loop
          width="100%"
          style={{
            objectFit: "cover",
            height: "200px", // Increased height for the video
          }}
        >
          <source src={bannerUrl || "/demovideo.mp4"} type="video/mp4" />
          Your browser does not support the video tag.
        </video>
      )} */}
    </div>
  );
};

export default Banner;
