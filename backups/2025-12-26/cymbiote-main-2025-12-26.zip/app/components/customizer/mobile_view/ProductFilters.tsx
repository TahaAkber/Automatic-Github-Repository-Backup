import { InlineStack, Tag } from "@shopify/polaris";
import React from "react";
import { useDrag } from "react-dnd";

interface Props {
  filters: any[];
  filtercollections: any[];
}

export const ProductFilters: React.FC<Props> = ({
  filters,
  filtercollections,
}) => {
  const [{ opacity }, dragRef] = useDrag(
    () => ({
      type: "dropable",
      item: { text: "filters" },
      collect: (monitor) => ({
        opacity: monitor.isDragging() ? 0.5 : 1,
      }),
    }),
    [],
  );

  return (
    <div
      className={"productFilters"}
      ref={dragRef}
      style={{ opacity, position: "relative" }}
    >
      <div
        className={"productCardRow"}
        style={{
          display: "flex", // Use flexbox to arrange tags horizontally
          flexDirection: "row", // Ensure items are in a row
          overflowX: "auto", // Enable horizontal scrolling
          gap: "8px", // Space between tags
          padding: "8px 0", // Optional padding for better spacing
          maxWidth: "100%", // Ensure it takes full width
          marginLeft: "5px",
        }}
      >
        {filtercollections.map((e: any, i: number) => {
          return (
            <Tag size="large" key={"tag-internal-" + i}>
              {e.collection_name}
            </Tag>
          );
        })}
      </div>
      <style>{`
        .productCardRow::-webkit-scrollbar {
          height: 1px; /* Adjust the height of the scrollbar */

        }

        .productCardRow::-webkit-scrollbar-thumb {
          background-color: #888; /* Darker color for the scrollbar thumb */
          border-radius: 4px; /* Rounded edges */

        }

        .productCardRow::-webkit-scrollbar-thumb:hover {
          background-color: #555; /* Darker color when hovering */

        }

        .productCardRow::-webkit-scrollbar-track {
          background: #gray; /* Lighter track color */
            box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.3);
        }
      `}</style>
    </div>
  );
};
