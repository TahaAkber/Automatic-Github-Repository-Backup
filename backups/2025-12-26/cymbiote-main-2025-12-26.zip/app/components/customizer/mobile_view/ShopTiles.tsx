import React from "react";

interface ShopTilesProps {
  shopTileId: string;
}

const SHOPTILE1 =
  "https://cdn.shopify.com/s/files/1/0667/2711/6852/files/frame_png.png?v=1747132051";
const SHOPTILE2 =
  "https://cdn.shopify.com/s/files/1/0667/2711/6852/files/BasicTile2.jpg?v=1746190709";
const SHOPTILE3 = "/images/tiles/basic3.png";
const SHOPTILE4 =
  "https://cdn.shopify.com/s/files/1/0667/2711/6852/files/VideoTile1.jpg?v=1746183998";
const SHOPTILE5 = "/images/tiles/modern2.png";
const SHOPTILE6 = "/images/tiles/modern3.png";
const SHOPTILE7 =
  "https://cdn.shopify.com/s/files/1/0667/2711/6852/files/VideoTile1.jpg?v=1746183998";
const SHOPTILE8 = "/images/tiles/video2.svg";
const SHOPTILE9 = "/images/tiles/video3.svg";

export const ShopTiles: React.FC<ShopTilesProps> = ({ shopTileId }) => {
  return (
    <div>
      {shopTileId === "1" && (
        <img src={SHOPTILE1} alt="Shop Tile" className={"tile"} />
      )}
      {shopTileId === "2" && (
        <img src={SHOPTILE2} alt="Shop Tile" className={"tile"} />
      )}
      {shopTileId === "3" && (
        <img src={SHOPTILE3} alt="Shop Tile" className={"tile"} />
      )}
      {shopTileId === "4" && (
        <img src={SHOPTILE4} alt="Shop Tile" className={"tile"} />
      )}
      {shopTileId === "5" && (
        <img src={SHOPTILE5} alt="Shop Tile" className={"tile"} />
      )}
      {shopTileId === "6" && (
        <img src={SHOPTILE6} alt="Shop Tile" className={"tile"} />
      )}
      {shopTileId === "7" && (
        <img src={SHOPTILE7} alt="Shop Tile" className={"tile"} />
      )}
      {shopTileId === "8" && (
        <img src={SHOPTILE8} alt="Shop Tile" className={"tile"} />
      )}
      {shopTileId === "9" && (
        <img src={SHOPTILE9} alt="Shop Tile" className={"tile"} />
      )}
      {shopTileId === "10" && (
        <img src={SHOPTILE9} alt="Shop Tile" className={"tile"} />
      )}
    </div>
  );
};
