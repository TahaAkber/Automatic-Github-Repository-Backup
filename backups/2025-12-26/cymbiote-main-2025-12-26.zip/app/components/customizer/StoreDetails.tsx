import { BlockStack, Card, Text, TextField } from "@shopify/polaris";
import React from "react";

interface ShopDetails {
  email: any;
  phoneNumber: any;
  address: any;
  instagram: any;
  facebook: any;
  twitter: any;
  privacyPolicy: any;
  returnPolicy: any;
}

export const StoreDetails: React.FC<{
  email: string;
  phoneNumber: string;
  address: string;
  instagram: string;
  facebook: string;
  twitter: string;
  privacyPolicy: string;
  returnPolicy: string;
  shopDetails?: ShopDetails;
  setShopDetails?: React.Dispatch<React.SetStateAction<ShopDetails>>;
}> = ({
  address,
  email,
  facebook,
  instagram,
  phoneNumber,
  twitter,
  privacyPolicy,
  returnPolicy,
  setShopDetails,
  shopDetails,
}) => {
  return (
    <Card>
      <BlockStack gap={{ xs: "100" }}>
        <BlockStack gap={{ xs: "100" }}>
          <Text as="p" fontWeight="bold">
            Store Details
          </Text>
          <TextField
            label={"Email"}
            value={shopDetails?.email || ""}
            placeholder={email}
            autoComplete="true"
            onChange={(value) =>
              setShopDetails?.({
                ...(shopDetails as ShopDetails),
                email: value,
              })
            }
          ></TextField>
          <TextField
            label={"Phone Number"}
            value={shopDetails?.phoneNumber || ""}
            placeholder={phoneNumber}
            autoComplete="true"
            onChange={(value) =>
              setShopDetails?.({
                ...(shopDetails as ShopDetails),
                phoneNumber: value,
              })
            }
          ></TextField>
          <TextField
            label={"Privacy Policy Url"}
            value={shopDetails?.privacyPolicy || ""}
            placeholder={privacyPolicy}
            autoComplete="true"
            onChange={(value) =>
              setShopDetails?.({
                ...(shopDetails as ShopDetails),
                privacyPolicy: value,
              })
            }
          ></TextField>
          <TextField
            label={"Return Policy Url"}
            value={shopDetails?.returnPolicy || ""}
            placeholder={returnPolicy}
            autoComplete="true"
            onChange={(value) =>
              setShopDetails?.({
                ...(shopDetails as ShopDetails),
                returnPolicy: value,
              })
            }
          ></TextField>
          <TextField
            label={"Business Address"}
            value={shopDetails?.address || ""}
            placeholder={address}
            autoComplete="true"
            onChange={(value) =>
              setShopDetails?.({
                ...(shopDetails as ShopDetails),
                address: value,
              })
            }
          ></TextField>
        </BlockStack>

        <BlockStack gap={{ xs: "100" }}>
          <Text as="p" fontWeight="bold">
            Social Links
          </Text>
          <TextField
            label={"Instagram Url"}
            value={shopDetails?.instagram || ""}
            placeholder={instagram}
            autoComplete="true"
            onChange={(value) =>
              setShopDetails?.({
                ...(shopDetails as ShopDetails),
                instagram: value,
              })
            }
          ></TextField>
          <TextField
            label={"Facebook Url"}
            value={shopDetails?.facebook || ""}
            placeholder={facebook}
            autoComplete="true"
            onChange={(value) =>
              setShopDetails?.({
                ...(shopDetails as ShopDetails),
                facebook: value,
              })
            }
          ></TextField>
          <TextField
            label={"Twitter Url"}
            value={shopDetails?.twitter || ""}
            placeholder={twitter}
            autoComplete="true"
            onChange={(value) =>
              setShopDetails?.({
                ...(shopDetails as ShopDetails),
                twitter: value,
              })
            }
          ></TextField>
        </BlockStack>
      </BlockStack>
    </Card>
  );
};
