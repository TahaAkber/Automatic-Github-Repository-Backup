import { LegacyStack, Tag, Autocomplete } from "@shopify/polaris";
import { useState, useCallback, useMemo } from "react";
import { SearchIcon, PlusCircleIcon } from "@shopify/polaris-icons";
import { useNavigate } from "@remix-run/react";

interface DropdownProps {
  search: string;
  selectedOptions: string[];
  setSelectedOptions: (options: string[]) => void;
  collections: {
    value: string;
    label: string;
  }[];
}

export default function CollectionDropdown({
  collections,
  selectedOptions,
  setSelectedOptions,
  search,
}: DropdownProps) {
  console.log("CollectionDropdown", selectedOptions);
  const navigate = useNavigate();
  const deselectedOptions = useMemo(() => [...collections], []);
  const [inputValue, setInputValue] = useState("");
  const [options, setOptions] = useState(deselectedOptions);

  const updateText = useCallback(
    (value: string) => {
      setInputValue(value);

      if (value === "") {
        setOptions(deselectedOptions);
        return;
      }

      const filterRegex = new RegExp(value, "i");
      const resultOptions = deselectedOptions.filter((option) =>
        option.label.match(filterRegex),
      );

      setOptions(resultOptions);
    },
    [deselectedOptions],
  );

  const removeTag = useCallback(
    (tag: string) => () => {
      const options = [...selectedOptions];
      options.splice(options.indexOf(tag), 1);
      setSelectedOptions(options);
    },
    [selectedOptions],
  );

  const verticalContentMarkup =
    selectedOptions.length > 0 ? (
      <LegacyStack spacing="extraTight" alignment="center">
        {selectedOptions.map((option) => {
          let tagLabel = "";
          tagLabel = option.replace("_", " ");
          tagLabel = titleCase(tagLabel);
          return (
            <Tag key={`option${option}`} onRemove={removeTag(option)}>
              {tagLabel}
            </Tag>
          );
        })}
      </LegacyStack>
    ) : null;

  const textField = (
    <Autocomplete.TextField
      onChange={updateText}
      label=""
      value={inputValue}
      placeholder="Best selling, Under 100, etc.."
      verticalContent={verticalContentMarkup}
      autoComplete="off"
    />
  );

  return (
    <div>
      <Autocomplete
        allowMultiple
        options={options}
        selected={selectedOptions}
        textField={textField}
        onSelect={setSelectedOptions}
        listTitle="Your Suggested Collections"
        actionBefore={{
          accessibilityLabel: "Action label",
          content: "Want to create a new collection?",
          // ellipsis: true,
          helpText: "Create New",
          icon: PlusCircleIcon,
          onAction: () => {
            navigate({ pathname: "/app/collection", search });
          },
        }}
      />
    </div>
  );

  function titleCase(string: string) {
    console.log("string", string);
    return string
      .toLowerCase()
      .split(" ")
      .map((word) => word.replace(word[0], word[0].toUpperCase()))
      .join("");
  }
}
