import { Badge, Image, IndexTable, Tag, Text } from "@shopify/polaris";
import React, { useEffect, useState } from "react";
import { SearchDropdown } from "../dashboard/SearchDropdown";

interface Props {
  id: string;
  title: string;
  images: any;
  description: string;
  category: any;
  product_custom_category: string;
  mode: string;
  selectedProductCategories?: string[];
  setSelectedProductCategories?: (selectedProductCategories: string[]) => void;
  selectedProductCategoriesIds?: string[];
  setSelectedProductCategoriesIds?: (
    selectedProductCategoriesIds: string[],
  ) => void;
  index: number;
  selectedResources: string[];
  taxonomy: {
    categories?: any;
  };
}

export const RowMarkup: React.FC<Props> = ({
  category,
  description,
  id,
  images,
  product_custom_category,
  title,
  mode,
  selectedProductCategories,
  setSelectedProductCategories,
  selectedProductCategoriesIds,
  setSelectedProductCategoriesIds,
  index,
  selectedResources,
  taxonomy,
}) => {
  const [selectedCategories, setSelectedCategories] = useState<
    {
      value: string;
      id: string;
    }[]
  >([]);

  useEffect(() => {
    const selectedCatCount = selectedCategories.length;
    console.log("selectedCategories", selectedCategories);
    if (selectedCatCount > 0) {
      const tempProdCats = updateProductCategory(
        selectedProductCategories ? selectedProductCategories : [],
        id + "|" + selectedCategories[selectedCatCount - 1].value,
      );
      const tempProdCatIds = updateProductCategory(
        selectedProductCategoriesIds ? selectedProductCategoriesIds : [],
        id + "|" + selectedCategories[selectedCatCount - 1].id,
      );
      if (setSelectedProductCategories && setSelectedProductCategoriesIds) {
        console.log("tempProd", tempProdCats, tempProdCatIds);
        const updatedCategories = [...tempProdCats]; // Create a new array reference
        const updatedCategoriesIds = [...tempProdCatIds]; // Create a new array reference
        setSelectedProductCategories(updatedCategories);
        setSelectedProductCategoriesIds(updatedCategoriesIds);
      }
    }
  }, [selectedCategories]);

  //function created to remove only 1 item inside the selectedProductCategories instead of removing all similar items
  const removeASelectedCategory = (category: string, id: string) => {
    console.log("removeASelectedCategory", category, id);
    let productRemoved = false;
    let productRemovedId = false;
    const newOptions = selectedProductCategories?.filter((option) => {
      // Check if the category matches and it hasn't been removed yet
      if (option.split("|")[1] === category && !productRemoved) {
        productRemoved = true; // Mark the first match as removed
        return false; // Skip this item (remove it)
      }
      return true; // Keep all other items
    });
    const newOptionsIds = selectedProductCategoriesIds?.filter((option) => {
      // Check if the category matches and it hasn't been removed yet
      if (option.split("|")[1] === id && !productRemovedId) {
        productRemovedId = true; // Mark the first match as removed
        return false; // Skip this item (remove it)
      }
      return true; // Keep all other items
    });

    console.log("newOptions", selectedProductCategories, newOptions);
    console.log("newOptionsIds", selectedProductCategoriesIds, newOptionsIds);

    if (setSelectedProductCategories && newOptions) {
      setSelectedProductCategories([...newOptions]); // Update state with the filtered array
    }
    if (setSelectedProductCategoriesIds && newOptionsIds) {
      setSelectedProductCategoriesIds([...newOptionsIds]); // Update state with the filtered array
    }
  };

  return (
    <IndexTable.Row
      id={id}
      key={id}
      selected={selectedResources.includes(id)}
      position={index}
    >
      <IndexTable.Cell>
        <Text variant="bodyMd" truncate fontWeight="bold" as="p">
          {title}
        </Text>
      </IndexTable.Cell>
      <IndexTable.Cell>
        <p
          dangerouslySetInnerHTML={{
            __html: description ? description : "No description available",
          }}
        ></p>
      </IndexTable.Cell>
      <IndexTable.Cell>
        <Tag disabled={mode === "published" ? true : false}>
          {category ? category.name : "Not available"}
        </Tag>
      </IndexTable.Cell>
      <IndexTable.Cell>
        <div
          style={{
            display: "flex",
            justifyContent: "start",
            alignItems: "center",
          }}
        >
          {mode !== "published" ? (
            <SearchDropdown
              initialCategoryItems={
                taxonomy?.categories ? taxonomy?.categories.nodes : []
              }
              selectedOptions={selectedCategories}
              setSelectedOptions={setSelectedCategories}
              height={"auto"}
              allowMultiSelect={false}
              removeASelectedCategory={removeASelectedCategory}
            />
          ) : (
            <Badge tone="success" progress="partiallyComplete" size="large">
              {product_custom_category
                ? product_custom_category
                : "Not available"}
            </Badge>
          )}
        </div>
      </IndexTable.Cell>
      <IndexTable.Cell as="td">
        <Image
          source={
            images.nodes.length > 0
              ? images.nodes[0]?.url
              : "https://upload.wikimedia.org/wikipedia/commons/thumb/a/ac/No_image_available.svg/300px-No_image_available.svg.png"
          }
          height={100}
          alt={images.length ?? images[0]?.alt}
        />
      </IndexTable.Cell>
      {/* <IndexTable.Cell>{paymentStatus}</IndexTable.Cell>
          <IndexTable.Cell>{fulfillmentStatus}</IndexTable.Cell> */}
    </IndexTable.Row>
  );
};

function updateProductCategory(
  productArray: string[],
  newProductCategory: string,
) {
  const [newProductId, _] = newProductCategory.split("|");

  const existingIndex = productArray.findIndex((product) => {
    const [productId] = product.split("|");
    return productId === newProductId;
  });

  if (existingIndex !== -1) {
    productArray[existingIndex] = newProductCategory;
  } else {
    productArray.push(newProductCategory);
  }

  return productArray;
}
