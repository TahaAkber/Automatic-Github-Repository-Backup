import { FC, useEffect } from "react";
import {
  IndexTable,
  useIndexResourceState,
  Card,
  IndexFilters,
  useSetIndexFiltersMode,
  TabProps,
} from "@shopify/polaris";
import { NewRowMarkup } from "./NewRowMarkup";
import { ProductCategory } from "~/types/Products/ProductCategory";
import { Loader } from "../common/Loader";

interface Props {
  products: any[];
  selected: number;
  taxonomy: {
    categories?: any;
  };
  searchUrl: string;
  isLoading: boolean;
  nextCursor?: string;
  shopCurrency: string;
  hasNextPage?: boolean;
  hasPrevPage?: boolean;
  previousCursor?: string;
  loadCategories: boolean;
  autoFetchMissingItems: string[];
  handleNextPageClick: () => void;
  handlePrevPageClick: () => void;
  handleDeleteFromDatabase?: () => void;
  setSelected?: (selected: number) => void;
  selectedProductCategories?: ProductCategory[];
  setSelectedProductCategories?: (
    selectedProductCategories: ProductCategory[],
  ) => void;
  brands: any[];
  queryValue: string;
  onQueryChange: (query: string) => void;
  onQueryClear: () => void;
}

const resourceName = {
  singular: "product",
  plural: "Products",
};

const NewProductsTable: FC<Props> = ({
  products,
  taxonomy,
  selected,
  isLoading,
  searchUrl,
  setSelected,
  hasNextPage,
  hasPrevPage,
  shopCurrency,
  loadCategories,
  handleNextPageClick,
  handlePrevPageClick,
  autoFetchMissingItems,
  selectedProductCategories,
  setSelectedProductCategories,
  brands,
  queryValue,
  onQueryChange,
  onQueryClear,
}) => {
  const itemStrings = ["Published", "Unpublished"];
  const { mode: modeM, setMode } = useSetIndexFiltersMode();
  const { selectedResources, allResourcesSelected, handleSelectionChange } =
    useIndexResourceState(products);

  const newRowMarkup = products?.map((product, index) => {
    const {
      id,
      title,
      images,
      category,
      description,
      product_custom_category,
      product_brand_id,
    } = product ?? {};

    return (
      <NewRowMarkup
        id={id}
        index={index}
        title={title}
        images={images}
        key={id + index}
        searchUrl={searchUrl}
        selected={selected}
        taxonomy={taxonomy}
        category={category}
        description={description}
        shopCurrency={shopCurrency}
        loadCategories={loadCategories}
        autoFetchMissingItems={autoFetchMissingItems}
        product_custom_category={product_custom_category}
        selectedProductCategories={selectedProductCategories}
        setSelectedProductCategories={setSelectedProductCategories}
        brands={brands}
        product_brand_id={product_brand_id}
      />
    );
  });

  useEffect(() => {
    // console.log("for all active", products);
    const allActive = products?.every((product) => product.product_is_active);
    const anyActive = products?.some((product) => product.product_is_active);

    if (allActive) {
      setSelected && setSelected(1);
    } else if (anyActive) {
      setSelected && setSelected(1);
    } else {
      setSelected && setSelected(0);
    }
  }, []);

  const tabs: TabProps[] = itemStrings.map((item, index) => ({
    content: item,
    index,
    onAction: () => {},
    id: `${item}-${index}`,
    isLocked: index === 0,
    actions: index === 0 ? [] : [],
  }));

  return (
    <Card padding={"0"}>
      {isLoading ? (
        <Loader />
      ) : (
        <div>
          <IndexFilters
            cancelAction={{
              onAction: onQueryClear,
              disabled: false,
              loading: false,
            }}
            queryValue={queryValue}
            // onCreateNewView={onCreateNewView}
            filters={[]}
            mode={modeM}
            onClearAll={() => {}}
            onQueryChange={onQueryChange}
            onQueryClear={onQueryClear}
            selected={selected}
            onSelect={setSelected}
            setMode={setMode}
            tabs={tabs}
            canCreateNewView={false}
          />
          <IndexTable
            resourceName={resourceName}
            itemCount={products?.length ? products.length : 0}
            selectedItemsCount={
              allResourcesSelected ? "All" : selectedResources.length
            }
            selectable={false}
            onSelectionChange={handleSelectionChange}
            headings={[
              { title: "", alignment: "center" },
              { title: "Products" },
              { title: "Status" },
              { title: "Shopify Category" },
              { title: "Cercle Category*" },
              { title: "Product Brand" },
              { title: "Cercle Discount" },
            ]}
            pagination={{
              hasNext: hasNextPage || false,
              hasPrevious: hasPrevPage || false,
              onNext: handleNextPageClick,
              onPrevious: handlePrevPageClick,
              accessibilityLabels: {
                next: "Next page",
                previous: "Previous page",
              },
            }}
          >
            {newRowMarkup}
          </IndexTable>
        </div>
      )}
    </Card>
  );
};

export default NewProductsTable;
