import {
  Avatar,
  Badge,
  Button,
  IndexTable,
  InlineStack,
  Tag,
  Text,
  Checkbox,
  Icon,
  Listbox,
  Combobox,
  Box,
  Modal,
} from "@shopify/polaris";
import React, { useCallback, useEffect, useMemo, useState } from "react";
import { useNavigate } from "@remix-run/react";
import { XCircleIcon } from "@shopify/polaris-icons";
import { CatalogSearchDropdown } from "../dashboard/CatalogSearchDropdown";
import { ProductCategory } from "~/types/Products/ProductCategory";
import { PriceListVariantsModal } from "./PriceListVariantsModal";
import { SearchIcon } from "@shopify/polaris-icons";

interface Props {
  id: string;
  title: string;
  images: any;
  category: any;
  index: number;
  selected: number;
  searchUrl: string;
  taxonomy: {
    categories?: any;
  };
  description: string;
  shopCurrency: string;
  loadCategories: boolean;
  autoFetchMissingItems: string[];
  product_custom_category: string;
  selectedProductCategories?: ProductCategory[];
  setSelectedProductCategories?: (
    selectedProductCategories: ProductCategory[],
  ) => void;
  brands: any[];
  product_brand_id?: number;
}

interface DropdownOptionType {
  id: string;
  value: string;
  categoryFullname: string;
}

export const NewRowMarkup: React.FC<Props> = ({
  id,
  index,
  title,
  brands,
  images,
  selected,
  category,
  taxonomy,
  searchUrl,
  shopCurrency,
  loadCategories,
  product_brand_id,
  autoFetchMissingItems,
  product_custom_category,
  selectedProductCategories,
  setSelectedProductCategories,
}) => {
  const [selectedCategories, setSelectedCategories] = useState<
    DropdownOptionType[]
  >([]);
  const [variantsLoad, setVariantsLoad] = useState(false);
  const [rowSelected, setRowSelected] = useState(false);
  const [variantsModalOpen, setVariantsModalOpen] = useState(false);
  const [productVariants, setProductVariants] = useState<any[]>([]);
  const [selectedVariants, setSelectedVariants] = useState<any[]>([]);
  const deselectedBrands = useMemo(
    () =>
      brands.map((b) => ({
        value: b.brand_id.toString(),
        label: b.brand_name,
      })),
    [brands],
  );
  const [selectedBrand, setSelectedBrand] = useState<string | undefined>();
  const [inputBrandValue, setInputBrandValue] = useState("");
  const [brandOptions, setBrandOptions] = useState(deselectedBrands);
  const [showBrandRedirectModal, setShowBrandRedirectModal] = useState(false);
  const navigate = useNavigate();
  useEffect(() => {
    if (product_brand_id && brands.length > 0) {
      const brand = brands.find((b) => b.brand_id === product_brand_id);
      if (brand) {
        setSelectedBrand(brand.brand_id.toString());
        setInputBrandValue(brand.brand_name);
      }
    }
  }, [product_brand_id, brands]);

  const escapeSpecialRegExCharacters = useCallback(
    (value: string) => value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"),
    [],
  );

  const updateBrandText = useCallback(
    (value: string) => {
      setInputBrandValue(value);

      if (value === "") {
        setBrandOptions(deselectedBrands);
        return;
      }

      const filterRegex = new RegExp(escapeSpecialRegExCharacters(value), "i");
      const resultOptions = deselectedBrands.filter((option) =>
        option.label.match(filterRegex),
      );
      setBrandOptions(resultOptions);
    },
    [deselectedBrands, escapeSpecialRegExCharacters],
  );

  const updateBrandSelection = useCallback(
    (selected: string) => {
      const matchedOption = brandOptions.find((option) => {
        return option.value.match(selected);
      });

      if (matchedOption?.label === "Other") {
        setShowBrandRedirectModal(true);
      }

      setSelectedBrand(selected);
      setInputBrandValue((matchedOption && matchedOption.label) || "");

      if (setSelectedProductCategories && selectedProductCategories) {
        const updatedCategories = (
          selectedProductCategories as ProductCategory[]
        ).map((item) => {
          if (item.productId === id) {
            return { ...item, brandId: selected };
          }
          return item;
        });
        setSelectedProductCategories(updatedCategories);
      }
    },
    [brandOptions, selectedProductCategories, setSelectedProductCategories, id],
  );

  useEffect(() => {
    if (selectedCategories[0]?.value !== undefined) {
      handleSelection(true);
    }
    // console.log("selectedCategories", selectedCategories);
  }, [selectedCategories]);

  useEffect(() => {
    if (
      selected === 1 &&
      rowSelected &&
      autoFetchMissingItems.find((item) => item === id)
    ) {
      handleSelection(true);
    }
  }, [autoFetchMissingItems]);

  useEffect(() => {
    setRowSelected(false);
  }, [selected]);

  useEffect(() => {
    if (selected === 0 && selectedProductCategories) {
      const isSelected = selectedProductCategories.some(
        (item) => item.productId === id,
      );
      setRowSelected(isSelected);
    }
  }, [selectedProductCategories, id, selected]);

  const handleRemoveBrand = () => {
    setSelectedBrand(undefined);
    setInputBrandValue("");
    if (setSelectedProductCategories) {
      const updatedCategories = (
        selectedProductCategories as ProductCategory[]
      ).map((item) => {
        if (item.productId === id) {
          const { brandId, ...rest } = item;
          return rest;
        }
        return item;
      });
      setSelectedProductCategories(updatedCategories);
    }
  };

  const optionsBrandMarkup =
    brandOptions.length > 0
      ? brandOptions.map((option) => {
          const { label, value } = option;

          return (
            <Listbox.Option
              key={`${value}`}
              value={value}
              selected={selectedBrand === value}
              accessibilityLabel={label}
            >
              {label}
            </Listbox.Option>
          );
        })
      : null;

  const handleSelection = (checked: boolean) => {
    if (checked && selectedCategories.length < 1 && selected !== 0) {
      shopify.toast.show("Kindly select a category to publish product");
    } else {
      setRowSelected(checked);
      if (setSelectedProductCategories) {
        if (checked) {
          const alreadyExists = (
            selectedProductCategories as ProductCategory[]
          ).some(
            (item: ProductCategory) =>
              item.productId === id &&
              item.productCategory === selectedCategories[0]?.value,
          );
          if (!alreadyExists) {
            setSelectedProductCategories([
              ...(selectedProductCategories as ProductCategory[]),
              {
                productId: id,
                productCategory: selectedCategories[0]?.value,
                productCategoryId: selectedCategories[0]?.id,
                categoryFullname: selectedCategories[0]?.categoryFullname,
                brandId: selectedBrand,
                DiscountedVariants: selectedVariants.map((v) => ({
                  discounted_price: v.variant_discounted_price,
                  variant_shopify_id: v.variant_shopify_id,
                })),
              },
            ]);
          }
        } else {
          const filter1 = (
            selectedProductCategories as ProductCategory[]
          ).filter((item: ProductCategory) => item.productId !== id);
          // console.log("filtered", filter1);
          setSelectedProductCategories(filter1);
        }
      }
    }
  };

  const updateDiscountedVariants = (
    upcommingVariant: any,
    checked: boolean,
  ) => {
    if (checked) {
      const updatedVariants = [...selectedVariants, upcommingVariant];

      setSelectedVariants(updatedVariants);
    } else {
      const filteredVariant = selectedVariants.filter(
        (variant: any) =>
          variant.variant_shopify_id !== upcommingVariant.variant_shopify_id,
      );

      setSelectedVariants(filteredVariant);
    }
  };

  const removeASelectedCategory = () => {
    setRowSelected(false);
    setSelectedCategories([]);
    if (setSelectedProductCategories) {
      const filter1 = (selectedProductCategories as ProductCategory[]).filter(
        (item: ProductCategory) => item.productId !== id,
      );
      // console.log("filtered", filter1);
      setSelectedProductCategories(filter1);
    }
  };

  const handleVariantModalOpen = async () => {
    setVariantsLoad(true);
    const response = await fetch(`/api/productVariants?productId=${id}`);
    const data = await response.json();

    const processedVariants =
      data.productVariants.length > 1
        ? data.productVariants.filter(
            (variant: any) => variant.variant_name !== "Default Title",
          )
        : data.productVariants;

    const variantIds: string[] = processedVariants.map(
      (variant: any) => variant.variant_shopify_id,
    );

    if (variantIds.length !== productVariants.length) {
      const formData = new FormData();
      formData.append("variantIds", variantIds.join(","));
      formData.append("shopDomain", "shopify.myshopify.com");

      const variantsImage = await fetch(`/api/variantImages`, {
        method: "POST",
        body: formData,
      });

      const variantsImageData = await variantsImage.json();

      const variantsWithImages = processedVariants.map((variant: any) => {
        const variantImage = variantsImageData.data.find(
          (image: any) => image.variantId === variant.variant_shopify_id,
        );
        return {
          ...variant,
          variant_image: variantImage?.imageUrl || null,
        };
      });

      setProductVariants(variantsWithImages);
    }

    setVariantsModalOpen(true);
    setVariantsLoad(false);
  };

  return (
    <div className={"mineClass"}>
      <IndexTable.Row
        id={id}
        key={id}
        selected={rowSelected}
        position={index}
        rowType="data"
      >
        {/* Checkbox for selection */}
        <IndexTable.Cell as="td" className="choiceColumn">
          <Checkbox label checked={rowSelected} onChange={handleSelection} />
        </IndexTable.Cell>

        <IndexTable.Cell as="td">
          <InlineStack blockAlign="center" gap={"300"}>
            <Avatar
              source={
                images.nodes.length > 0
                  ? images.nodes[0]?.url
                  : "https://upload.wikimedia.org/wikipedia/commons/thumb/a/ac/No_image_available.svg/300px-No_image_available.svg.png"
              }
              size="xl"
            />
            <Text variant="bodyMd" truncate fontWeight="regular" as="span">
              {title}
            </Text>
          </InlineStack>
        </IndexTable.Cell>

        <IndexTable.Cell as="td">
          <Badge>{product_custom_category ? "Listed" : "Delist"}</Badge>
        </IndexTable.Cell>

        <IndexTable.Cell as="td">
          <Tag disabled={selected === 0}>
            {category ? category.name : "Not available"}
          </Tag>
        </IndexTable.Cell>

        <IndexTable.Cell as="td">
          <div
            style={{
              display: "flex",
              justifyContent: "start",
              alignItems: "center",
            }}
          >
            {selected === 1 ? (
              selectedCategories.length < 1 ? (
                <div style={{ width: 160 }}>
                  <CatalogSearchDropdown
                    searchUrl={searchUrl}
                    allowMultiSelect={false}
                    selectedOptions={selectedCategories}
                    setSelectedOptions={setSelectedCategories}
                    initialCategoryItems={
                      taxonomy?.categories ? taxonomy?.categories.nodes : []
                    }
                    loadCategories={loadCategories}
                    shopifyCategory={
                      category && selected === 1 && !product_custom_category
                        ? category.name !== "Uncategorized"
                          ? category.name
                          : ""
                        : ""
                    }
                  />
                </div>
              ) : (
                <div
                  style={{
                    display: "flex",
                    backgroundColor: "#CDFEE1",
                    justifyContent: "center",
                    alignItems: "center",
                    borderRadius: 10,
                    paddingRight: 5,
                  }}
                >
                  <Badge tone="success" size="medium">
                    {selectedCategories[0]?.value}
                  </Badge>
                  <Button
                    icon={XCircleIcon}
                    variant="plain"
                    onClick={removeASelectedCategory}
                  />
                </div>
              )
            ) : (
              <Badge tone="success" progress="partiallyComplete" size="medium">
                {product_custom_category
                  ? product_custom_category
                  : "Not available"}
              </Badge>
            )}
          </div>
        </IndexTable.Cell>

        <IndexTable.Cell as="td">
          <Box width="200px">
            {selected === 1 ? (
              selectedBrand ? (
                <Box
                  borderRadius="100"
                  paddingInlineEnd={"050"}
                  background="bg-fill-success-secondary"
                  width="fit-content"
                >
                  <InlineStack>
                    <Badge tone="success" size="medium">
                      {inputBrandValue}
                    </Badge>
                    <Button
                      icon={XCircleIcon}
                      variant="plain"
                      onClick={handleRemoveBrand}
                    />
                  </InlineStack>
                </Box>
              ) : (
                <Combobox
                  activator={
                    <Combobox.TextField
                      prefix={<Icon source={SearchIcon} />}
                      onChange={updateBrandText}
                      label="Search Brand"
                      labelHidden
                      value={inputBrandValue}
                      placeholder="Search Brand"
                      autoComplete="off"
                    />
                  }
                >
                  {brandOptions.length > 0 ? (
                    <Listbox onSelect={updateBrandSelection}>
                      {optionsBrandMarkup}
                    </Listbox>
                  ) : null}
                </Combobox>
              )
            ) : (
              <Badge
                tone="attention-strong"
                progress="partiallyComplete"
                size="medium"
              >
                {product_brand_id
                  ? brands.find((b) => b.brand_id === product_brand_id)
                      ?.brand_name || "Not Available"
                  : "Not Available"}
              </Badge>
            )}
          </Box>
        </IndexTable.Cell>

        <IndexTable.Cell as="td">
          <PriceListVariantsModal
            open={variantsModalOpen}
            variantsLoad={variantsLoad}
            shopCurrency={shopCurrency}
            parentChecked={rowSelected}
            setOpen={handleVariantModalOpen}
            productVariants={productVariants}
            setProductVariants={setProductVariants}
            setClose={() => setVariantsModalOpen(false)}
            updateDiscountedVariants={updateDiscountedVariants}
          />
          <Modal
            open={showBrandRedirectModal}
            onClose={() => setShowBrandRedirectModal(false)}
            title="Register New Brand"
            primaryAction={{
              content: "Yes",
              onAction: () => navigate("/app/brands"),
            }}
            secondaryActions={[
              {
                content: "No",
                onAction: () => setShowBrandRedirectModal(false),
              },
            ]}
          >
            <Modal.Section>
              <Text as="p">
                Do you want to leave this page and register your brand?
              </Text>
            </Modal.Section>
          </Modal>
        </IndexTable.Cell>
      </IndexTable.Row>
    </div>
  );
};
