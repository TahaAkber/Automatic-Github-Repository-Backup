import { FC, useEffect, useState } from "react";
import {
  IndexTable,
  useIndexResourceState,
  Button,
  Card,
  ButtonGroup,
} from "@shopify/polaris";
import { RowMarkup } from "./RowMarkup";

interface Props {
  resourceName: {
    singular: string;
    plural: string;
  };
  products: any[];
  taxonomy: {
    categories?: any;
  };
  selectedProducts: string[];
  setSelectedProducts: (selectedProducts: string[]) => void;
  handleAddToDatabase?: () => void;
  handleDeleteFromDatabase?: () => void;
  mode?: string;
  shopDomain: string;
  selectedProductCategories?: string[];
  setSelectedProductCategories?: (selectedProductCategories: string[]) => void;
  selectedProductCategoriesIds?: string[];
  setSelectedProductCategoriesIds?: (
    selectedProductCategoriesIds: string[],
  ) => void;
}

const ProductsTable: FC<Props> = ({
  resourceName,
  products,
  taxonomy,
  setSelectedProducts,
  handleAddToDatabase,
  selectedProductCategories,
  setSelectedProductCategories,
  selectedProductCategoriesIds,
  setSelectedProductCategoriesIds,
  selectedProducts,
  shopDomain,
  mode = "unpublished",
}) => {
  console.log("ProductsTable Products", products);
  const { selectedResources, allResourcesSelected, handleSelectionChange } =
    useIndexResourceState(products);

  useEffect(() => {
    console.log("selectedResources", selectedResources, selectedProducts);
    // if (selectedResources.length > 0)
    {
      setSelectedProducts(selectedResources);
    }
  }, [selectedResources]);

  const rowMarkup = products?.map((product, index) => {
    const {
      id,
      title,
      images,
      description,
      category,
      product_custom_category,
    } = product ?? {};

    return (
      <RowMarkup
        category={category}
        description={description}
        id={id}
        images={images}
        index={index}
        mode={mode}
        product_custom_category={product_custom_category}
        selectedResources={selectedResources}
        selectedProductCategories={selectedProductCategories}
        setSelectedProductCategories={setSelectedProductCategories}
        selectedProductCategoriesIds={selectedProductCategoriesIds}
        setSelectedProductCategoriesIds={setSelectedProductCategoriesIds}
        taxonomy={taxonomy}
        title={title}
        key={index + "markup"}
      />
    );
  });

  return (
    <Card padding={"0"}>
      <div
        style={{
          width: "100%",
          display: "flex",
          padding: 10,
          justifyContent: "end",
          alignItems: "end",
        }}
      >
        {mode !== "published" ? (
          <ButtonGroup>
            <Button
              onClick={() => {
                if (window.top) {
                  window.top.location.href = `https://${shopDomain}/admin/bulk/product?resource_name=Product&edit=status%2Cproduct_taxonomy_node_id%2Cvendor%2Cvariants.price%2Cmetafields.custom.cercle_product_category&return_to=%2Fstore%2Fquickstart-653ed797%2Fapps%2Fcymbiote%2Fapp`;
                }
              }}
            >
              Bulk Edit
            </Button>
            <Button
              disabled={selectedResources.length < 1}
              onClick={handleAddToDatabase}
            >
              Add Selected Items
            </Button>
          </ButtonGroup>
        ) : (
          <></>
        )}
      </div>
      <IndexTable
        resourceName={resourceName}
        itemCount={products?.length ? products.length : 0}
        // selectable={mode !== "published"}
        selectedItemsCount={
          allResourcesSelected ? "All" : selectedResources.length
        }
        pagination={{
          label: "1",
          hasPrevious: false,
          hasNext: false,
        }}
        onSelectionChange={handleSelectionChange}
        headings={[
          { title: "Title" },
          { title: "Description" },
          { title: "Shopify Category" },
          { title: "Cercle Category" },
          { title: "Image" },
        ]}
      >
        {rowMarkup}
      </IndexTable>
    </Card>
  );
};

export default ProductsTable;
