import {
  Modal,
  Combobox,
  Icon,
  Listbox,
  Button,
  Text,
  Box,
} from "@shopify/polaris";
import { SearchIcon } from "@shopify/polaris-icons";
import { useCallback, useEffect, useState } from "react";
import { VariantRow } from "./VariantRow";

interface ModelProps {
  open: boolean;
  setOpen: () => void;
  setClose: () => void;
  shopCurrency: string;
  variantsLoad: boolean;
  parentChecked: boolean;
  productVariants: any[];
  setProductVariants: (variants: any[]) => void;
  updateDiscountedVariants: (variant: any, checked: boolean) => void;
}
export function PriceListVariantsModal({
  open,
  setOpen,
  setClose,
  shopCurrency,
  variantsLoad,
  parentChecked,
  productVariants,
  setProductVariants,
  updateDiscountedVariants,
}: ModelProps) {
  const [inputValue, setInputValue] = useState("");
  const [options, setOptions] = useState([]);

  const updateText = (value: any) => {
    setInputValue(value);
  };

  const updateSelection = (selected: any) => {
    console.log("Selected:", selected);
  };

  return (
    <Modal
      open={open}
      title="Edit Products"
      onClose={() => setClose()}
      activator={
        <Button
          disabled={parentChecked}
          variant="plain"
          onClick={() => setOpen()}
          loading={variantsLoad}
        >
          Select Variants
        </Button>
      }
    >
      {/* Search Box */}
      <div style={{ width: "94%", margin: "3%" }}>
        <Combobox
          activator={
            <Combobox.TextField
              prefix={<Icon source={SearchIcon} />}
              onChange={updateText}
              label="Search Products"
              labelHidden
              value={inputValue}
              placeholder="Search Products"
              autoComplete="off"
            />
          }
        >
          {options.length > 0 ? (
            <Listbox onSelect={updateSelection}>
              {options.map((option, index) => (
                <Listbox.Option key={index} value={option}>
                  {option}
                </Listbox.Option>
              ))}
            </Listbox>
          ) : null}
        </Combobox>
      </div>

      <div
        style={{
          maxHeight: "300px",
          overflowY: "auto",
          padding: "0px 20px",
        }}
      >
        <Text as="p">Only entertain variants with discounting values</Text>
      </div>

      <div
        style={{
          maxHeight: "300px",
          overflowY: "auto",
          padding: "0 5px",
          marginBottom: 16,
        }}
      >
        <Modal.Section>
          {productVariants.map((variant, index) => (
            <VariantRow
              key={variant.variant_temp_id}
              variant={variant}
              shopCurrency={shopCurrency}
              onCheckChange={(checked: boolean, discount: number) => {
                console.log("onCheckChange checked", checked);
                console.log("discount price", discount);
                const updatedVariant = {
                  ...variant,
                  variant_discounted_price: discount,
                };

                const updatedVariants = productVariants.map((v) => {
                  if (v.variant_temp_id === variant.variant_temp_id) {
                    return updatedVariant;
                  }
                  return v;
                });

                setProductVariants(updatedVariants);

                updateDiscountedVariants(updatedVariant, checked);
              }}
              onDiscountChange={(id: number, discount: string) => {
                // Empty for now
              }}
            />
          ))}
        </Modal.Section>
      </div>

      <div
        style={{
          position: "sticky",
          bottom: 0,
          background: "white",
          padding: "16px",
          boxShadow: "0 -2px 10px rgba(0,0,0,0.1)",
          display: "flex",
          justifyContent: "flex-end",
          gap: 10,
        }}
      >
        <Button onClick={() => setClose()}>Cancel</Button>
        <Button onClick={() => setClose()} variant="primary">
          Done
        </Button>
      </div>
    </Modal>
  );
}
