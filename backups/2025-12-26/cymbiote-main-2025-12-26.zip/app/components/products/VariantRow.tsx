import { Checkbox, Grid, Text, TextField, Thumbnail } from "@shopify/polaris";
import { useState } from "react";

export const VariantRow = ({
  variant,
  onCheckChange,
  shopCurrency,
  onDiscountChange,
}: any) => {
  const [discount, setDiscount] = useState(variant.variant_discounted_price);
  const [checked, setChecked] = useState(
    variant?.variant_discounted_price === 0 ? false : true,
  );

  const handleCheck = (value: boolean) => {
    const discountNumber = parseFloat(discount);
    const priceNumber = parseFloat(variant.variant_price);

    if (value && !discount) {
      shopify.toast.show("Please enter a discounted price before selecting.");
      return;
    }

    if (value && discountNumber >= priceNumber) {
      shopify.toast.show(
        "Discounted price must be less than the original price.",
      );
      return;
    }

    if (value) {
      onCheckChange(value, discount);
    } else {
      setDiscount(0);
      onCheckChange(value, 0);
    }
    setChecked(!checked);
  };

  const handleDiscountChange = (value: string) => {
    setDiscount(parseFloat(value));
    onDiscountChange(variant.variant_id, parseFloat(value));
  };

  return (
    <Checkbox
      checked={checked}
      onChange={handleCheck}
      label={
        <Grid>
          <Grid.Cell columnSpan={{ sm: 2 }}>
            <Thumbnail
              source={variant.variant_image}
              alt={variant.variant_name}
              size="medium"
            />
          </Grid.Cell>

          <Grid.Cell columnSpan={{ sm: 3 }}>
            <div
              style={{
                display: "flex",
                alignItems: "center",
                height: "100%",
              }}
            >
              <Text as="p" alignment="center">
                {variant.variant_name}
              </Text>
            </div>
          </Grid.Cell>

          <Grid.Cell columnSpan={{ sm: 3 }}>
            <div
              style={{
                display: "flex",
                alignItems: "center",
                height: "100%",
              }}
            >
              <Text as="p" alignment="center">
                {`${variant.variant_price} ${shopCurrency}`}
              </Text>
            </div>
          </Grid.Cell>

          <Grid.Cell columnSpan={{ sm: 4 }}>
            <div
              className="varientRowField"
              style={{
                display: "flex",
                alignItems: "center",
                height: "100%",
              }}
            >
              <TextField
                label=""
                type="number"
                autoComplete="false"
                placeholder="Discounted Price"
                value={discount ? discount : ""}
                onChange={handleDiscountChange}
                disabled={checked}
                prefix={shopCurrency}
              />
            </div>
          </Grid.Cell>
        </Grid>
      }
    />
  );
};
