import {
  Button,
  Card,
  Icon,
  Text,
  BlockStack,
  InlineStack,
  Box,
  Divider,
} from "@shopify/polaris";
import React from "react";
import { PACKAGE } from "~/types/Package";
import { CheckCircleIcon } from "@shopify/polaris-icons";

interface PROPS {
  plan: PACKAGE;
  active: boolean;
  loading: boolean;
  planNumber: number;
  selectedPlan?: PACKAGE;
  handleModalChange: () => void;
  handlePlanChange: (planName: PACKAGE) => void;
  reelCharges: number;
}

const SubCard: React.FC<PROPS> = ({
  plan,
  active,
  loading,
  planNumber,
  selectedPlan,
  handlePlanChange,
  handleModalChange,
  reelCharges,
}) => {
  const [extraVideos, setExtraVideos] = React.useState(0);

  React.useEffect(() => {
    // Sync extra videos to selected plan if this card is the selected one OR if we just changed the extras
    // We check if the calculated extraQuota matches the current state to avoid redundant updates
    // But we also need to make sure we don't overwrite if another card is selected?
    // Actually, if we change extraVideos, we imply selection of this card.

    if (extraVideos > 0 || selectedPlan?.package_id === plan.package_id) {
      // Construct the updated plan object
      const updatedPlan = {
        ...plan, // Use base plan to ensure we have all fields
        extraQuota: extraVideos,
        extraCharges: (extraVideos / 5) * reelCharges,
      };

      // Only trigger update if it's different from what's currently selected
      // or if this card is not yet selected (implicit selection on interaction)
      if (
        selectedPlan?.package_id !== plan.package_id ||
        selectedPlan?.extraQuota !== extraVideos
      ) {
        handlePlanChange(updatedPlan);
      }
    }
  }, [extraVideos, reelCharges]);

  const handleAddVideo = () => {
    setExtraVideos((prev) => prev + 5);
  };

  const handleRemoveVideo = () => {
    if (extraVideos >= 5) {
      setExtraVideos((prev) => prev - 5);
    }
  };

  const totalCharges = plan.package_charges + (extraVideos / 5) * reelCharges;

  return (
    <div
      onClick={() =>
        handlePlanChange({
          ...plan,
          extraQuota: extraVideos,
          extraCharges: (extraVideos / 5) * reelCharges,
        })
      }
      className={`card-container ${active ? "active-card" : ""}`}
    >
      <Card>
        <Box position="relative" minHeight="350px">
          {active && (
            <Box position="absolute" width="280px" background="bg-fill-brand" />
          )}
          <BlockStack gap="400">
            <Box position="relative">
              <img
                src={
                  active
                    ? "/images/dashboard/packageactiveicon.png"
                    : "/images/dashboard/packageicon.png"
                }
                alt={active ? "Active package" : "Package"}
              />
            </Box>

            <BlockStack gap="200">
              <Text variant="heading2xl" fontWeight="medium" as="h3">
                {plan.package_name}
              </Text>

              <Text
                variant="bodySm"
                fontWeight="regular"
                as="p"
                tone={active ? "subdued" : "disabled"}
              >
                {plan.package_description}
              </Text>

              <InlineStack gap="200" align="start" blockAlign="center">
                <Text variant="heading2xl" fontWeight="medium" as="h3">
                  ${totalCharges === 0 ? "Free" : totalCharges}
                </Text>
                <Text
                  variant="bodySm"
                  fontWeight="regular"
                  as="span"
                  tone={active ? "subdued" : "disabled"}
                >
                  per month
                </Text>
              </InlineStack>
            </BlockStack>

            <BlockStack gap="200">
              <InlineStack gap="100" direction={"row"} wrap>
                <Box>
                  <Icon source={CheckCircleIcon} />
                </Box>
                <Box width="90%">
                  <Text as="span">{plan.package_description}</Text>
                </Box>
              </InlineStack>

              {plan.package_order_limit && (
                <InlineStack gap="100" align="start">
                  <Box>
                    <Icon source={CheckCircleIcon} />
                  </Box>
                  <Text as="span">
                    {plan.package_order_limit} orders per month
                  </Text>
                </InlineStack>
              )}

              {plan.package_video_count ? (
                <InlineStack gap="100" align="start">
                  <Box>
                    <Icon source={CheckCircleIcon} />
                  </Box>
                  <Text alignment="start" as="span">
                    {plan.package_video_count} reels or stories per month
                  </Text>
                </InlineStack>
              ) : (
                <InlineStack gap="100" align="start">
                  <Box>
                    <Icon source={CheckCircleIcon} />
                  </Box>
                  <Text alignment="start" as="span">
                    No reels or stories per month
                  </Text>
                </InlineStack>
              )}

              <InlineStack gap="100" align="start">
                <Box>
                  <Icon source={CheckCircleIcon} />
                </Box>
                <Text alignment="start" as="span">
                  {plan.package_rate}% transaction charge per order
                </Text>
              </InlineStack>
            </BlockStack>

            <Divider />

            <BlockStack gap="200">
              <Text
                alignment="start"
                as="p"
                variant="bodySm"
                fontWeight="medium"
              >
                Extra Reels/Stories
              </Text>

              <InlineStack align="space-between" blockAlign="center">
                <Box>
                  <Button
                    size="micro"
                    onClick={handleRemoveVideo}
                    disabled={extraVideos === 0}
                  >
                    -
                  </Button>
                </Box>

                <Text as="span" fontWeight="bold">
                  {extraVideos} (+${(extraVideos / 5) * reelCharges})
                </Text>

                <Box>
                  <Button size="micro" onClick={handleAddVideo}>
                    +
                  </Button>
                </Box>
              </InlineStack>

              <Text as="p" variant="bodyXs" tone="subdued" alignment="center">
                Total Quota: {(plan.package_video_count || 0) + extraVideos}
              </Text>
            </BlockStack>
          </BlockStack>
        </Box>

        <Box paddingBlockStart={"400"}>
          <Button
            disabled={(active && extraVideos === 0) || loading}
            onClick={handleModalChange}
            loading={loading && selectedPlan?.package_id === plan.package_id}
            fullWidth
          >
            {active ? (extraVideos > 0 ? "Top Up" : "Subscribed") : "Buy Now"}
          </Button>
        </Box>
      </Card>
    </div>
  );
};

export default SubCard;
