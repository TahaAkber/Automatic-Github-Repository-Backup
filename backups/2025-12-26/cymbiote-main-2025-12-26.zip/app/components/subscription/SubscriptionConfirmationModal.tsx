import React from "react";
import {
  Modal,
  Text,
  BlockStack,
  InlineStack,
  Box,
  Divider,
} from "@shopify/polaris";
import { PACKAGE } from "~/types/Package";

interface SubscriptionConfirmationModalProps {
  active: boolean;
  handleModalChange: () => void;
  handleConfirmChangePlan: () => void;
  selectedPlan?: PACKAGE;
  tileSubscriptionEnabled: boolean;
  tileCharges: number;
  trackingEnabled: boolean;
  trackingCharges: number;
  isTopUp?: boolean;
}

const SubscriptionConfirmationModal: React.FC<
  SubscriptionConfirmationModalProps
> = ({
  active,
  handleModalChange,
  handleConfirmChangePlan,
  selectedPlan,
  tileSubscriptionEnabled,
  tileCharges,
  trackingEnabled,
  trackingCharges,
  isTopUp = false,
}) => {
  return (
    <Modal
      open={active}
      onClose={handleModalChange}
      title={isTopUp ? "Confirm One-Time Top-Up" : "Confirm Plan Change"}
      primaryAction={{
        content: "Yes",
        onAction: handleConfirmChangePlan,
      }}
      secondaryActions={[
        {
          content: "No",
          onAction: handleModalChange,
        },
      ]}
    >
      <Modal.Section>
        <BlockStack gap="400">
          <Text as="p" variant="bodyMd">
            {isTopUp ? (
              <>
                You are about to add extra reels/stories to your current plan{" "}
                <Text as="span" fontWeight="bold">
                  {selectedPlan?.package_name}
                </Text>
                .
              </>
            ) : (
              <>
                You are about to change your subscription plan to{" "}
                <Text as="span" fontWeight="bold">
                  {selectedPlan?.package_name}
                </Text>
                .
              </>
            )}
          </Text>

          <Box
            padding="400"
            background="bg-surface-secondary"
            borderRadius="200"
          >
            <BlockStack gap="200">
              <Text as="h4" variant="headingSm" fontWeight="bold">
                Charges Breakdown:
              </Text>
              <BlockStack gap="100">
                {!isTopUp && (
                  <InlineStack align="space-between">
                    <Text as="span" variant="bodyMd">
                      Base Plan Charges:
                    </Text>
                    <Text as="span" variant="bodyMd">
                      ${selectedPlan?.package_charges || 0}
                    </Text>
                  </InlineStack>
                )}

                {(selectedPlan?.extraCharges || 0) > 0 && (
                  <InlineStack align="space-between">
                    <Text as="span" variant="bodyMd">
                      {isTopUp
                        ? "One-Time Extra Reels/Stories Charge"
                        : `Extra Reels/Stories (${selectedPlan?.extraQuota})`}
                      :
                    </Text>
                    <Text as="span" variant="bodyMd">
                      +${selectedPlan?.extraCharges}
                    </Text>
                  </InlineStack>
                )}

                {!isTopUp && tileSubscriptionEnabled && (
                  <InlineStack align="space-between">
                    <Text as="span" variant="bodyMd">
                      Video Tile Subscription:
                    </Text>
                    <Text as="span" variant="bodyMd">
                      +${tileCharges}
                    </Text>
                  </InlineStack>
                )}

                {!isTopUp && trackingEnabled && (
                  <InlineStack align="space-between">
                    <Text as="span" variant="bodyMd">
                      Tracking Subscription:
                    </Text>
                    <Text as="span" variant="bodyMd">
                      +${trackingCharges}
                    </Text>
                  </InlineStack>
                )}
              </BlockStack>

              <Divider />

              <InlineStack align="space-between">
                <Text as="span" variant="bodyMd" fontWeight="bold">
                  {isTopUp
                    ? "Total One-Time Charge:"
                    : "Total Recurring Monthly Charge:"}
                </Text>
                <Text as="span" variant="bodyMd" fontWeight="bold">
                  $
                  {isTopUp
                    ? (selectedPlan?.extraCharges || 0).toFixed(2)
                    : (
                        (selectedPlan?.package_charges || 0) +
                        (selectedPlan?.extraCharges || 0) +
                        (tileSubscriptionEnabled ? tileCharges : 0) +
                        (trackingEnabled ? trackingCharges : 0)
                      ).toFixed(2)}
                </Text>
              </InlineStack>
            </BlockStack>
          </Box>

          <BlockStack gap="200">
            <Text as="p" variant="bodyMd" tone="subdued">
              {isTopUp
                ? "This is a one-time charge and will be billed immediately."
                : "Please note that any usage-related charges will be updated immediately, and your subscription charges will be charged from the next billing cycle."}
            </Text>
            <Text as="p" variant="bodyMd">
              Would you like to proceed?
            </Text>
          </BlockStack>
        </BlockStack>
      </Modal.Section>
    </Modal>
  );
};

export default SubscriptionConfirmationModal;
