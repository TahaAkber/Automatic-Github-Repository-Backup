import {
  BlockStack,
  Button,
  Card,
  InlineStack,
  Layout,
  Text,
} from "@shopify/polaris";
import React from "react";

export const AboutCercle: React.FC = () => {
  return (
    <Layout.Section variant="fullWidth">
      <Layout>
        <Layout.Section variant="oneThird">
          <Text as="h4" fontWeight="bold">
            About Cercle
          </Text>
          <BlockStack role="menu">
            <div style={{ marginTop: 5 }}>
              <Text as="p" fontWeight="regular">
                Cercle is a powerful e-commerce platform designed to empower
                businesses of all sizes. With an intuitive interface,
                customizable features, and robust tools, Cercle helps merchants
                build, manage, and scale their online stores effortlessly.
                Whether you’re just starting or looking to grow, Cercle provides
                everything you need to create a seamless shopping experience for
                your customers.
              </Text>
            </div>
          </BlockStack>
        </Layout.Section>
        <Layout.Section variant="oneHalf">
          <Card roundedAbove="lg">
            <InlineStack align="space-between" blockAlign="center">
              <Text as="p" fontWeight="semibold">
                About Cercle
              </Text>
              <Button
                variant="monochromePlain"
                target="_blank"
                url="https://cymbiote.com/"
              >
                Want more information
              </Button>
            </InlineStack>
          </Card>
        </Layout.Section>
      </Layout>
    </Layout.Section>
  );
};
