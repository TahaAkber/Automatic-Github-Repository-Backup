import {
  BlockStack,
  Button,
  Card,
  InlineStack,
  Layout,
  Text,
} from "@shopify/polaris";
import React from "react";

export const TrackingNotifications: React.FC = () => {
  return (
    <Layout.Section variant="fullWidth">
      <Layout>
        <Layout.Section variant="oneThird">
          <Text as="h4" fontWeight="bold">
            Order Tracking Notifications
          </Text>
          <BlockStack role="menu">
            <div style={{ marginTop: 5 }}>
              <Text as="p" fontWeight="regular">
                Get real-time updates on the progress of your orders. This
                feature keeps you informed at every step — from the moment your
                order is confirmed to its final delivery — so you can track your
                orders with ease and confidence.
              </Text>
            </div>
          </BlockStack>
        </Layout.Section>
        <Layout.Section variant="oneHalf">
          <Card roundedAbove="lg">
            <InlineStack align="space-between" blockAlign="center">
              <Text as="p" fontWeight="semibold">
                Order Tracking Notifications
              </Text>
              <Button>Subscribe</Button>
            </InlineStack>
          </Card>
        </Layout.Section>
      </Layout>
    </Layout.Section>
  );
};
