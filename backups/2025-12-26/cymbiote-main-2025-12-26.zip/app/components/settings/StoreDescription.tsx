import { BlockStack, Card, Layout, Text, TextField } from "@shopify/polaris";
import React, { useEffect } from "react";
import { SearchDropdown } from "../dashboard/SearchDropdown";

interface Props {
  description: string;
  handleDescriptionChange: (value: string) => void;
}

export const StoreDescription: React.FC<Props> = ({
  description,
  handleDescriptionChange,
}) => {
  return (
    <Layout.Section variant="fullWidth">
      <Layout>
        <Layout.Section variant="oneThird">
          <Text as="h4" fontWeight="bold">
            Store Description
          </Text>
          <BlockStack role="menu">
            <div style={{ marginTop: 5 }}>
              <Text as="p" fontWeight="regular">
                Effortlessly showcase your store's identity by crafting a
                compelling description. A well-written store description helps
                customers understand your brand, products, and values at a
                glance.
              </Text>
              <Text as="p">
                Write a description that highlights what makes your store
                unique, enhances trust, and encourages shoppers to explore
                further. This will improve customer engagement and contribute to
                a memorable shopping experience.
              </Text>
            </div>
          </BlockStack>
        </Layout.Section>
        <Layout.Section variant="oneHalf">
          <Card roundedAbove="lg">
            <BlockStack align="space-between">
              <Text as="p" fontWeight="semibold">
                Store Description
              </Text>
              <div style={{ width: "100%", marginTop: 10, marginBottom: 0 }}>
                <TextField
                  label=""
                  value={description}
                  onChange={handleDescriptionChange}
                  multiline={4}
                  autoComplete="off"
                />
              </div>
            </BlockStack>
          </Card>
        </Layout.Section>
      </Layout>
    </Layout.Section>
  );
};
