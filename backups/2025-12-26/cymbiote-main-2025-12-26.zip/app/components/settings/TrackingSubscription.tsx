import {
  BlockStack,
  Button,
  Card,
  Icon,
  InlineStack,
  Layout,
  Text,
} from "@shopify/polaris";
import React from "react";
import { ClockIcon } from "@shopify/polaris-icons";

interface MyInterface {
  handleSubscription: () => void;
  loadingSubscription: boolean;
  remainingTrialDays: number;
  subscriptionId: string | any;
  trackingCharges: string;
}

export function TrackingSubscription({
  handleSubscription,
  loadingSubscription,
  subscriptionId,
  remainingTrialDays,
  trackingCharges,
}: MyInterface) {
  return (
    <Layout.Section variant="fullWidth">
      <Layout>
        <Layout.Section variant="oneThird">
          <Text as="h4" fontWeight="bold">
            Order Tracking & Trial Status
          </Text>
          <BlockStack role="menu">
            <div style={{ marginTop: 5 }}>
              <Text as="p" fontWeight="regular">
                Track your orders in real-time and monitor their progress
                effortlessly through the tracking feature. Alongside order
                updates, your dashboard displays a trial period counter — so
                you’ll always know how many days are left in your free trial.
              </Text>
              <Text as="p">
                Once your trial expires, the system will notify you and display
                a "Start Subscription" button, allowing you to upgrade
                seamlessly and continue enjoying uninterrupted order tracking.
              </Text>
            </div>
          </BlockStack>
        </Layout.Section>
        <Layout.Section variant="oneHalf">
          <Card roundedAbove="lg">
            <InlineStack align="space-between" blockAlign="center">
              <Text as="p" fontWeight="semibold">
                Order Tracking & Trial Status
              </Text>
              <Button
                onClick={handleSubscription}
                loading={loadingSubscription}
                // disabled={subscriptionId !== null}
              >
                {subscriptionId !== null
                  ? "Remove Subscription"
                  : "Start Subscription"}
              </Button>
            </InlineStack>
            <InlineStack gap={{ sm: "050" }} wrap={false}>
              {subscriptionId === null ? (
                <>
                  <div>
                    <Icon
                      accessibilityLabel="b"
                      source={ClockIcon}
                      key={"clock-icon"}
                      tone="subdued"
                    />
                  </div>
                  <div
                    style={{
                      display: "flex",
                      flexDirection: "column",
                      color: "#736D6D",
                    }}
                  >
                    <Text as="p">
                      {remainingTrialDays} days left for your trial
                    </Text>
                    <div style={{ fontSize: 12, color: "black" }}>
                      <span>
                        Subscribe now for just
                        <span style={{ fontWeight: "bold", marginInline: 5 }}>
                          ${trackingCharges}
                        </span>
                        to access the full service.
                      </span>
                    </div>
                  </div>
                </>
              ) : null}
            </InlineStack>
          </Card>
        </Layout.Section>
      </Layout>
    </Layout.Section>
  );
}
