// import { BlockStack, Card, Layout, Text } from "@shopify/polaris";
// import React, { useEffect, useRef } from "react";
// import { SearchDropdown } from "../dashboard/SearchDropdown";
// import { SearchStoreCategory } from "../dashboard/SearchStoreCategory";

// interface Props {
//   changedCategory: (category: string, id: string) => void;
//   selectedCategories: any[];
//   removeCategory: (category: string, id: string) => void;
//   setSelectedCategories: (param: any) => void;
//   shopCategories: any[];
//   currentShopCategory: any;
//   isPostBack: boolean;
//   setShowSaveBar: (value: boolean) => void;
// }

// export const StoreCategory: React.FC<Props> = ({
//   changedCategory,
//   selectedCategories,
//   removeCategory,
//   setSelectedCategories,
//   shopCategories,
//   currentShopCategory,
//   isPostBack,
//   setShowSaveBar,
// }) => {
//   console.log("shopCategories", shopCategories);
//   console.log("currentShopCategory", currentShopCategory);
//   console.log("selectedCategories", selectedCategories);

//   useEffect(() => {
//     if (
//       currentShopCategory &&
//       currentShopCategory.length > 0 &&
//       shopCategories.length > 0
//     ) {
//       // Map currentShopCategory array to the format expected by selectedOptions
//       const mappedCurrentCategories = currentShopCategory
//         .map((currentCat: any) => {
//           // Find matching category in shopCategories
//           const matchingShopCategory = shopCategories.find(
//             (shopCat) =>
//               shopCat.id === currentCat.category_id ||
//               shopCat.fullName === currentCat.category_name,
//           );

//           return matchingShopCategory
//             ? {
//                 id: matchingShopCategory.id,
//                 value: matchingShopCategory.fullName,
//               }
//             : null;
//         })
//         .filter(Boolean); // Remove null values

//       setSelectedCategories(mappedCurrentCategories);
//     }
//   }, [currentShopCategory, shopCategories]);

//   return (
//     <Layout.Section variant="fullWidth">
//       <Layout>
//         <Layout.Section variant="oneThird">
//           <Text as="h4" fontWeight="bold">
//             Store Category
//           </Text>
//           <BlockStack role="menu">
//             <div style={{ marginTop: 5 }}>
//               <Text as="p" fontWeight="regular">
//                 Easily explore and manage your products by organizing them into
//                 clear and structured categories. Categories help customers
//                 quickly find what they’re looking for and ensure your store
//                 stays neat and well-organized.
//               </Text>
//               <Text as="p">
//                 Assign products to relevant categories to improve visibility,
//                 enhance customer experience, and simplify browsing.
//               </Text>
//             </div>
//           </BlockStack>
//         </Layout.Section>
//         <Layout.Section variant="oneHalf">
//           <Card roundedAbove="lg">
//             <BlockStack align="space-between">
//               <Text as="p" fontWeight="semibold">
//                 Store Category
//               </Text>
//               <div style={{ width: 250, marginTop: 10, marginBottom: 0 }}>
//                 <SearchStoreCategory
//                   width={250}
//                   allowTyping={true}
//                   allowMultiSelect={true}
//                   selectedOptions={selectedCategories}
//                   removeASelectedCategory={removeCategory}
//                   setSelectedOptions={(newSelection: any) => {
//                     setSelectedCategories(newSelection);

//                     if (selectedCategories.length > 0) {
//                       setShowSaveBar(true);
//                     } else {
//                       setShowSaveBar(false);
//                     }
//                   }}
//                   initialCategoryItems={
//                     shopCategories.length ? shopCategories : []
//                   }
//                   currentShopCategory={currentShopCategory}
//                 />
//               </div>
//             </BlockStack>
//           </Card>
//         </Layout.Section>
//       </Layout>
//     </Layout.Section>
//   );
// };



import { BlockStack, Card, Layout, Text } from "@shopify/polaris";
import React, { useEffect } from "react";
import { SearchStoreCategory } from "../dashboard/SearchStoreCategory";

interface Props {
  changedCategory: (category: string, id: string) => void;
  selectedCategories: any[];
  removeCategory: (category: string, id: string) => void;
  setSelectedCategories: (param: any) => void;
  shopCategories: any[];
  currentShopCategory: any;
  isPostBack: boolean;
  setShowSaveBar: (value: boolean) => void;
}

export const StoreCategory: React.FC<Props> = ({
  changedCategory,
  selectedCategories,
  removeCategory,
  setSelectedCategories,
  shopCategories,
  currentShopCategory,
  isPostBack,
  setShowSaveBar,
}) => {
  console.log("shopCategories", shopCategories);
  console.log("currentShopCategory", currentShopCategory);
  console.log("selectedCategories", selectedCategories);

  // helper to compare categories
  const areCategoriesEqual = (selected: any[], current: any[]) => {
    if (!current || current.length === 0) return selected.length === 0;
    if (selected.length !== current.length) return false;

    return selected.every((sel) =>
      current.some(
        (cur) => cur.category_id === sel.id || cur.category_name === sel.value,
      ),
    );
  };

  useEffect(() => {
    if (
      currentShopCategory &&
      currentShopCategory.length > 0 &&
      shopCategories.length > 0
    ) {
      // map current shop categories to selected format
      const mappedCurrentCategories = currentShopCategory
        .map((currentCat: any) => {
          const matchingShopCategory = shopCategories.find(
            (shopCat) =>
              shopCat.id === currentCat.category_id ||
              shopCat.fullName === currentCat.category_name,
          );

          return matchingShopCategory
            ? {
                id: matchingShopCategory.id,
                value: matchingShopCategory.fullName,
              }
            : null;
        })
        .filter(Boolean);

      setSelectedCategories(mappedCurrentCategories);
    }
  }, [currentShopCategory, shopCategories]);

  return (
    <Layout.Section variant="fullWidth">
      <Layout>
        <Layout.Section variant="oneThird">
          <Text as="h4" fontWeight="bold">
            Store Category
          </Text>
          <BlockStack role="menu">
            <div style={{ marginTop: 5 }}>
              <Text as="p" fontWeight="regular">
                Easily explore and manage your products by organizing them into
                clear and structured categories. Categories help customers
                quickly find what they’re looking for and ensure your store
                stays neat and well-organized.
              </Text>
              <Text as="p">
                Assign products to relevant categories to improve visibility,
                enhance customer experience, and simplify browsing.
              </Text>
            </div>
          </BlockStack>
        </Layout.Section>
        <Layout.Section variant="oneHalf">
          <Card roundedAbove="lg">
            <BlockStack align="space-between">
              <Text as="p" fontWeight="semibold">
                Store Category
              </Text>
              <div style={{ width: 250, marginTop: 10, marginBottom: 0 }}>
                <SearchStoreCategory
                  width={250}
                  allowTyping={true}
                  allowMultiSelect={true}
                  selectedOptions={selectedCategories}
                  removeASelectedCategory={removeCategory}
                  setSelectedOptions={(newSelection: any) => {
                    setSelectedCategories(newSelection);

                    const hasChanges = !areCategoriesEqual(
                      newSelection,
                      currentShopCategory,
                    );
                    setShowSaveBar(hasChanges);
                  }}
                  initialCategoryItems={
                    shopCategories.length ? shopCategories : []
                  }
                  currentShopCategory={currentShopCategory}
                />
              </div>
            </BlockStack>
          </Card>
        </Layout.Section>
      </Layout>
    </Layout.Section>
  );
};
