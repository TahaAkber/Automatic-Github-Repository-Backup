import { useState, useCallback } from "react";
import { Card, DropZone, Thumbnail, BlockStack, Text } from "@shopify/polaris";

interface IconUploadProps {
  onIconChange: (file: File) => void;
  iconFile?: File;
  setIconFile: (iconFile: File) => void;
  iconUrl?: string;
  setIconUrl: (iconUrl: string) => void;
}

const IconUpload = ({
  onIconChange,
  iconFile,
  setIconFile,
  iconUrl,
  setIconUrl
}: IconUploadProps) => {

  const handleDropZoneDrop = useCallback(
    (_dropFiles: File[], acceptedFiles: File[], _rejectedFiles: File[]) => {
      const file = acceptedFiles[0];
      console.log("image file", file);
      setIconFile(file);
      onIconChange(file); // Notify the parent component of the change
      const reader = new FileReader();
      reader.onload = () => {
        setIconUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    },
    [onIconChange],
  );

  return (
    <Card>
      <Text as="p" fontWeight="semibold">
        Drop or Upload Icon
      </Text>
      <DropZone onDrop={handleDropZoneDrop}>
        {iconUrl ? (
          <BlockStack>
            <Thumbnail source={iconUrl} alt="Shop Icon" size="small" />
            <div>
              <Text as="p" fontWeight="bold">
                {iconFile?.name}
              </Text>
            </div>
          </BlockStack>
        ) : (
          <DropZone.FileUpload />
        )}
      </DropZone>
    </Card>
  );
};

export default IconUpload;
