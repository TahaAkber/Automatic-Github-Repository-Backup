import {
  BlockStack,
  Button,
  Card,
  InlineStack,
  Layout,
  Text,
} from "@shopify/polaris";
import React, { useEffect, useState } from "react";
import ListingModal from "../modals/ListingModal";
interface Store {
  listingStore: (value: string) => void;
  searchTerm: string;
  setdelistbuttonloading: (value: boolean) => void;
  delistbuttonloading: boolean;
}

const fetchCurrentStore = async (searchTerm: string) => {
  const response = await fetch(`/api/store?searchTerm=${searchTerm}`);
  const data = await response.json();
  return data;
};

export const DelistStore: React.FC<Store> = ({
  listingStore,
  searchTerm,
  setdelistbuttonloading,
  delistbuttonloading,
}) => {
  const [store, setStore] = useState<any>({});
  const [delist, setdelist] = useState(false);
  const [enlist, setenlist] = useState(false);

  const handleDelist = () => {
    setdelist(false);
    listingStore("delist");
    setdelistbuttonloading(true);
  };

  const handleEnlist = () => {
    setenlist(false);
    listingStore("enlist");
    setdelistbuttonloading(true);
  };

  useEffect(() => {
    async function fetchData() {
      const data = await fetchCurrentStore(searchTerm);
      setStore(data);
    }

    fetchData();
  }, [listingStore, searchTerm]);

  return (
    <Layout.Section variant="fullWidth">
      <Layout>
        <Layout.Section variant="oneThird">
          <Text as="h4" fontWeight="bold">
            Disconnect My Store
          </Text>
          <BlockStack role="menu">
            <div style={{ marginTop: 5 }}>
              <Text as="p" fontWeight="regular">
                Choosing this option will temporarily remove your store from
                being visible on our app store. Once delisted, customers will no
                longer be able to view or place orders from your store until you
                choose to relist it.eat and well-organized.
              </Text>
              <Text as="p">
                You can relist your store at any time to restore its visibility.
              </Text>
            </div>
          </BlockStack>
        </Layout.Section>
        <Layout.Section variant="oneHalf">
          <Card roundedAbove="lg">
            <InlineStack align="space-between" blockAlign="center">
              {store?.storeResponse == true ? (
                <>
                  <Text as="p" fontWeight="semibold">
                    Delist My Store
                  </Text>
                  <Button
                    onClick={() => {
                      setdelist(true);
                    }}
                    loading={delistbuttonloading}
                  >
                    Disconnect Store
                  </Button>
                </>
              ) : (
                <>
                  <Text as="p" fontWeight="semibold">
                    Enlist My Store
                  </Text>
                  <Button
                    onClick={() => {
                      setenlist(true);
                    }}
                    loading={delistbuttonloading}
                    variant="primary"
                  >
                    Enlist Store
                  </Button>
                </>
              )}
            </InlineStack>
          </Card>
          <ListingModal
            open={delist}
            onClose={() => setdelist(false)}
            title="Confirm Delist"
            message="Are you sure you want to delist your store?"
            onConfirm={handleDelist}
            storeName={store?.shop?.shop_name}
          />

          <ListingModal
            open={enlist}
            onClose={() => setenlist(false)}
            title="Confirm Enlist"
            message="Are you sure you want to enlist your store?"
            onConfirm={handleEnlist}
            storeName={store?.shop?.shop_name}
          />
        </Layout.Section>
      </Layout>
    </Layout.Section>
  );
};
