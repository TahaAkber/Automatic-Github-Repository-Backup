import {
  BlockStack,
  Button,
  Card,
  InlineStack,
  Layout,
  Text,
} from "@shopify/polaris";
import React from "react";

interface Props {
  fetchCredits: (param1: number, param2: Date) => void;
  loadingCredits: boolean;
  availableCredits: number;
  shopId: number;
  billingDate: string;
}

export const ShopCredits: React.FC<Props> = ({
  fetchCredits,
  loadingCredits,
  availableCredits,
  shopId,
  billingDate,
}) => {
  return (
    <Layout.Section variant="fullWidth">
      <Layout>
        <Layout.Section variant="oneThird">
          <Text as="h4" fontWeight="bold">
            Shop Credits
          </Text>
          <BlockStack role="menu">
            <div style={{ marginTop: 5 }}>
              <Text as="p" fontWeight="regular">
                Easily track your available shop credits under the label "This
                Month's Credit." These credits will be automatically deducted
                from your upcoming subscription bill, helping you save on future
                payments.
              </Text>
              <Text as="p">
                <b>Note:</b> Shop credits cannot exceed the total subscription
                charges and will be adjusted during your next billing cycle.
              </Text>
            </div>
          </BlockStack>
        </Layout.Section>
        <Layout.Section variant="oneHalf">
          <Card roundedAbove="lg">
            <InlineStack align="space-between" blockAlign="center">
              <Text as="p" fontWeight="semibold">
                Shop Credits
              </Text>
              <InlineStack
                gap={{
                  xs: "200",
                }}
              >
                <Text as="p" tone="text-inverse-secondary">
                  Available Credits
                </Text>
                <Button
                  variant="primary"
                  onClick={() => fetchCredits(shopId, new Date(billingDate))}
                  loading={loadingCredits}
                >
                  {availableCredits !== null
                    ? `USD ${availableCredits}`
                    : "No credits found"}
                </Button>
              </InlineStack>
            </InlineStack>
          </Card>
        </Layout.Section>
      </Layout>
    </Layout.Section>
  );
};
