import { useCallback, useState } from "react";
import {
  Card,
  Grid,
  Button,
  Select,
  Text,
  Icon,
  Badge,
  DataTable,
  Combobox,
  TextField,
  LegacyStack,
  RadioButton,
  Link,
  InlineStack,
  Thumbnail,
  ChoiceList,
} from "@shopify/polaris";
import {
  SearchIcon,
  PlusIcon,
  DiscountIcon,
  XIcon,
} from "@shopify/polaris-icons";
import { Product } from "./SearchModal";
import { Collection } from "./CollectionModal";
import SmartCollection from "./Smartcollection";

export interface Simple {
  handleChange: (value: any) => void;
  handleTitleChange: (value: any) => void;
  handleDescriptionChange: (value: any) => void;
  removeproduct: (value: any) => void;
  handleRadioChange: (value: any) => void;
  setCustomCategory: (value: Product[]) => void;
  setIsModalOpen: (value: boolean) => void;
  Title: string;
  Description: string;
  selectedproducts: Product[];
  value: string;
  customCategory: Product[];
  selected: any | boolean;
}
export default function SimpleCollection({
  handleChange,
  handleTitleChange,
  setIsModalOpen,
  handleDescriptionChange,
  removeproduct,
  handleRadioChange,
  setCustomCategory,
  Title,
  Description,
  selectedproducts,
  value,

  customCategory,
  selected,
}: Simple) {
  const Conditions = [
    { label: "All Condition", value: "All Condition" },
    { label: "Any Condition", value: "Any Condition" },
  ];
  const [sort, setsort] = useState("Best Selling");
  const sortoptions = [{ label: "Best Selling", value: "Best Selling" }];

  const handlesortchange = useCallback((value: string) => setsort(value), []);

  return (
    <div>
      <div style={{ marginBottom: "20px" }}>
        <Card>
          <div>
            <div style={{ marginTop: "20px", marginBottom: "20px" }}>
              <TextField
                label="Title"
                value={Title}
                onChange={handleTitleChange}
                autoComplete="off"
                placeholder="eg. Summer Collection"
              />
            </div>
            <div style={{ marginTop: "20px", marginBottom: "20px" }}>
              <TextField
                label="Description"
                value={Description}
                onChange={handleDescriptionChange}
                multiline={7}
                autoComplete="off"
              />
            </div>
          </div>
        </Card>
      </div>
      <div style={{ marginBottom: "20px" }}>
        <Card>
          <LegacyStack vertical>
            <RadioButton
              label="Manual"
              helpText={
                <Text as="span">
                  Add products to this collection one by one. Learn more about{" "}
                  <Link url="https://help.shopify.com/manual" external>
                    Manual
                  </Link>
                  .
                </Text>
              }
              checked={value === "Manual"}
              id="Manual"
              onChange={handleRadioChange}
            />
            <RadioButton
              label="Smart Collection"
              disabled
              helpText={
                <Text as="span">
                  Existing and future products that match the conditions you set
                  will automatically be added to this collection. Learn more
                  about{" "}
                  <Link url="https://help.shopify.com/SmartCollection" external>
                    Smart Collection
                  </Link>
                  .
                </Text>
              }
              id="Smart Collection"
              checked={value === "Smart Collection"}
              onChange={handleRadioChange}
            />
          </LegacyStack>
        </Card>
      </div>
      <div style={{ marginBottom: "20px" }}>
        {value === "Smart Collection" ? (
          <>
            <Card>
              <div style={{ marginBottom: "20px" }}>
                <Text variant="headingLg" as="h2" fontWeight="semibold">
                  Conditions
                </Text>
              </div>
              <InlineStack
                blockAlign="center"
                gap={{
                  xs: "100",
                  sm: "200",
                  md: "300",
                  lg: "400",
                  xl: "500",
                }}
              >
                <Text as="p" variant="headingSm">
                  Products Must Match.
                </Text>
                {Conditions.map((choice: any) => (
                  <div className="radio-button" key={choice.value}>
                    <ChoiceList
                      title=""
                      choices={[choice]}
                      selected={selected}
                      onChange={(selected) => handleChange(selected)}
                    />
                  </div>
                ))}
              </InlineStack>
              <SmartCollection
                setCustomCategory={setCustomCategory}
                customCategory={customCategory}
              />
            </Card>
          </>
        ) : (
          <Card>
            <div style={{ marginBottom: "20px" }}>
              <Text variant="headingLg" as="h2" fontWeight="semibold">
                Products
              </Text>
            </div>
            <div
              style={{
                display: "flex",
                flexDirection: "column",
                // alignItems: "center",
                justifyContent:
                  selectedproducts.length > 0 ? "flex-start" : "center",
                height: selectedproducts.length > 0 ? "auto" : "30vh",
              }}
            >
              <div>
                {/* <Grid columns={{ xs: 1, sm: 8, md: 12, xl: 14 }}>
                  <Grid.Cell columnSpan={{ sm: 4, md: 6, xl: 8 }}>
                    <div style={{ width: "100%" }}>
                      <Combobox
                        activator={
                          <Combobox.TextField
                            prefix={<Icon source={SearchIcon} />}
                            label="Search Products"
                            labelHidden
                            placeholder="Search Products"
                            autoComplete="off"
                            onFocus={() => {
                              setIsModalOpen(true);
                            }}
                          />
                        }
                      ></Combobox>
                    </div>
                  </Grid.Cell>

                  <Grid.Cell>
                    <Button
                      size="large"
                      onClick={() => {
                        setIsModalOpen(true);
                      }}
                    >
                      Browse
                    </Button>
                  </Grid.Cell>
                  <Grid.Cell columnSpan={{ sm: 2, md: 4, xl: 4 }}>
                    <Select
                      label="Sort by"
                      labelInline
                      options={sortoptions}
                      onChange={handlesortchange}
                      value={sort}
                    />
                  </Grid.Cell>
                </Grid> */}

                <InlineStack wrap={true} align="start" gap="400">
                  <div style={{ width: "52%" }}>
                    <Combobox
                      activator={
                        <Combobox.TextField
                          prefix={<Icon source={SearchIcon} />}
                          label="Search Products"
                          labelHidden
                          placeholder="Search Products"
                          autoComplete="off"
                          onFocus={() => {
                            setIsModalOpen(true);
                          }}
                        />
                      }
                    ></Combobox>
                  </div>
                  <div>
                    <Button
                      size="medium"
                      onClick={() => {
                        setIsModalOpen(true);
                      }}
                    >
                      Browse
                    </Button>
                  </div>
                  <div style={{ width: "200px" }}>
                    <Select
                      label="Sort by"
                      labelInline
                      options={sortoptions}
                      onChange={handlesortchange}
                      value={sort}
                    />
                  </div>
                </InlineStack>
              </div>

              {selectedproducts.length > 0 ? (
                <></>
              ) : (
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    textAlign: "center",
                    height: selectedproducts.length > 0 ? "auto" : "30vh",
                  }}
                >
                  There are no products in this collection. Search or browse to
                  add products.
                </div>
              )}
            </div>

            {/* {selectedproducts.map((i, index) => {
              return (
                <Grid columns={{ xs: 6, sm: 9 }} key={i.product_id + `-outer`}>
                  <Grid.Cell columnSpan={{ xs: 6, sm: 6, md: 5 }}>
                    <div
                      key={i.product_id}
                      style={{
                        display: "flex",
                        alignItems: "center",
                        gap: "15px",
                        margin: "10px",
                        flexWrap: "wrap",
                      }}
                    >
                      <span>{index + 1}</span>
                      <Thumbnail
                        source={i.product_image_url}
                        alt={i.product_name}
                        size="medium"
                      />
                      <span style={{ flex: 1, minWidth: "100px" }}>
                        {i.product_name}
                      </span>
                    </div>
                  </Grid.Cell>

                  <Grid.Cell columnSpan={{ xs: 6, sm: 3, md: 3 }}>
                    <div
                      style={{
                        margin: "10px",
                        padding: "10px",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "flex-start",
                        gap: "10px",
                        flexWrap: "wrap",
                      }}
                    >
                      <Badge tone="success">Active</Badge>
                      <button
                        style={{
                          background: "none",
                          border: "none",
                          cursor: "pointer",
                        }}
                        onClick={() => removeproduct(i.product_id)}
                      >
                        <Icon source={XIcon} tone="base" />
                      </button>
                    </div>
                  </Grid.Cell>
                </Grid>
              );
            })} */}

            {selectedproducts.map((i, index) => {
              return (
                <div key={i.product_id + `-outer`} style={{ width: "100%" }}>
                  <div
                    style={{
                      width: "100%",
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "center",
                      padding: "10px",
                      margin: "10px 0",
                      gap: "10px",
                      flexWrap: "wrap",
                    }}
                  >
                    <div
                      style={{
                        display: "flex",
                        alignItems: "center",
                        gap: "15px",
                        flex: 1,
                        minWidth: 0,
                      }}
                    >
                      <span>{index + 1}</span>
                      <Thumbnail
                        source={i.product_image_url}
                        alt={i.product_name}
                        size="medium"
                      />
                      <span
                        style={{
                          flex: 1,
                          minWidth: "100px",
                          overflowWrap: "anywhere",
                        }}
                      >
                        {i.product_name}
                      </span>
                    </div>

                    {/* Right side: badge + X icon */}
                    <div
                      style={{
                        display: "flex",
                        alignItems: "center",
                        gap: "10px",
                      }}
                    >
                      <Badge tone="success">Active</Badge>
                      <button
                        style={{
                          background: "none",
                          border: "none",
                          cursor: "pointer",
                        }}
                        onClick={() => removeproduct(i.product_id)}
                      >
                        <Icon source={XIcon} tone="base" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </Card>
        )}
      </div>
    </div>
  );
}
