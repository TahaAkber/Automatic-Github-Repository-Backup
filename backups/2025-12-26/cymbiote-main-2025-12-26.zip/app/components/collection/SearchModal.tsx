import {
  Modal,
  Frame,
  Checkbox,
  Thumbnail,
  InlineStack,
  Combobox,
  Icon,
  Button,
} from "@shopify/polaris";
import { SearchIcon } from "@shopify/polaris-icons";
import { useEffect, useState } from "react";

export interface Product {
  product_id: number;
  product_name: string;
  product_image_url: string;
  product_rating: number;
}
interface Modelstate {
  open: boolean;
  onClose: any;
  search: any;
  products: any[];
  setSelectedproducts: (products: Product[]) => void;
  selectedproducts: Product[];
  setsearchValue: (value: any) => void;
  searchValue: any;
}
export default function SearchModal({
  open,
  onClose,
  products: initialProducts,
  setSelectedproducts,
  setsearchValue,
  searchValue,
  selectedproducts,
  search,
}: Modelstate) {
  const [selectedItems, setSelectedItems] = useState<Product[]>([]);
  const handleCheckboxChange = (product: Product) => {
    setSelectedItems((prev) => {
      const isSelected = prev.some(
        (item) => item.product_id === product.product_id,
      );
      return isSelected
        ? prev.filter((item) => item.product_id !== product.product_id)
        : [...prev, product];
    });
  };

  useEffect(() => {
    setSelectedItems(selectedproducts);
  }, [selectedproducts, open]);

  const handleDoneClick = () => {
    setSelectedproducts([...selectedItems]);
    onClose();
    setsearchValue("");
  };

  return (
    <div style={{ height: "0" }}>
      <>
        <Modal
          open={open}
          title="Edit Products"
          onClose={() => {
            onClose();
            setsearchValue("");
          }}
        >
          <div style={{ width: "94%", margin: "3%" }}>
            <Combobox
              activator={
                <Combobox.TextField
                  prefix={<Icon source={SearchIcon} />}
                  label="Search Products"
                  labelHidden
                  placeholder="Search Products"
                  autoComplete="off"
                  value={searchValue}
                  onChange={(value) => setsearchValue(value)}
                />
              }
            ></Combobox>
          </div>

          <div
            style={{ maxHeight: "300px", overflowY: "auto", padding: "0 16px" }}
          >
            {initialProducts.map((product) => (
              <Modal.Section key={product.product_id + `-inner`}>
                <Checkbox
                  label={
                    <InlineStack
                      align="center"
                      gap={{ xs: "300", md: "300", lg: "400", xl: "500" }}
                    >
                      <Thumbnail
                        source={product.product_image_url}
                        alt={product.product_name}
                        size="small"
                      />
                      <span style={{ display: "flex", alignItems: "center" }}>
                        {product.product_name}
                      </span>
                    </InlineStack>
                  }
                  checked={selectedItems.some(
                    (item) => item.product_id === product.product_id,
                  )}
                  onChange={() => handleCheckboxChange(product)}
                />
              </Modal.Section>
            ))}
          </div>

          <div
            style={{
              position: "sticky",
              bottom: 0,
              background: "white",
              padding: "16px",
              boxShadow: "0 -2px 10px rgba(0,0,0,0.1)",
              display: "flex",
              justifyContent: "flex-end",
              gap: 10,
            }}
          >
            <Button
              variant="secondary"
              onClick={() => {
                onClose();
                setsearchValue("");
              }}
            >
              Cancel
            </Button>
            <Button variant="primary" onClick={handleDoneClick}>
              Done
            </Button>
          </div>
        </Modal>
      </>
    </div>
  );
}
