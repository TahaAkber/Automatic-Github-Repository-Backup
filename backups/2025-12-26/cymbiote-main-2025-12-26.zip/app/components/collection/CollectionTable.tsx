import {
  IndexTable,
  IndexFilters,
  useSetIndexFiltersMode,
  Text,
  ChoiceList,
  Badge,
  useBreakpoints,
  Card,
  InlineStack,
  useIndexResourceState,
} from "@shopify/polaris";
import type { IndexFiltersProps, TabProps } from "@shopify/polaris";
import { useState, useCallback, useEffect } from "react";
import ValidImageAvatar from "../Avatar/ValidImageAvatar";
import ConfirmationModal from "../modals/ConfirmationModal";
import {
  createValidatedSelectionHandler,
  isShopifyCollection,
} from "~/functions/collection";

interface CollectionTableProps {
  collections: any[];
  filterCollection: any[];
  trendingCollection: any[];
  setCurrentTabSelections: (value: string[]) => void;
  currentTabSelections: string[];
  resetSelections: boolean;
  shopifyCollections: any[];
  setResetSelections: (value: boolean) => void;
  setSelected: (value: any) => void;
  selected: any;
  setActivePublish: (value: boolean) => void;
  activePublish: boolean;
  handleConfirmPublish: (value: any) => void;
  isPublishing: boolean;
  setSelectedCollectionType: (value: string[]) => void;
  selectedCollectionType: string[];
}

function CollectionTable({
  collections,
  filterCollection,
  trendingCollection,
  setCurrentTabSelections,
  setResetSelections,
  resetSelections,
  setSelected,
  shopifyCollections,
  selected,
  currentTabSelections,
  setActivePublish,
  activePublish,
  handleConfirmPublish,
  isPublishing,
  setSelectedCollectionType,
  selectedCollectionType,
}: CollectionTableProps) {
  const [sortSelected, setSortSelected] = useState(["order asc"]);
  const { mode, setMode } = useSetIndexFiltersMode();
  const sleep = (ms: number) =>
    new Promise((resolve) => setTimeout(resolve, ms));
  const [itemStrings, setItemStrings] = useState([
    "Simple Collection",
    "Trending Collection",
    "Filter Collection",
    "Shopify Collection",
  ]);

  const tabs: TabProps[] = itemStrings.map((item, index) => ({
    content: item,
    id: `${item}-${index}`,
    index,
    isLocked: false,
    onAction: () => handleSelect(index),
  }));

  const {
    selectedResources: simpleSelected,
    allResourcesSelected: simpleAllSelected,
    handleSelectionChange: simpleHandleChangeOriginal,
  } = useIndexResourceState(collections, {
    resourceIDResolver: (item) => item.collection_shopify_id,
  });

  const {
    selectedResources: filterSelected,
    allResourcesSelected: filterAllSelected,
    handleSelectionChange: filterHandleChangeOriginal,
  } = useIndexResourceState(filterCollection, {
    resourceIDResolver: (item) => item.collection_shopify_id,
  });
  const simpleHandleChange = createValidatedSelectionHandler(
    simpleHandleChangeOriginal,
    0,
    collections,
    filterCollection,
    simpleSelected,
    filterSelected,
  );

  const {
    selectedResources: trendingSelected,
    allResourcesSelected: trendingAllSelected,
    handleSelectionChange: trendingHandleChange,
  } = useIndexResourceState(trendingCollection, {
    resourceIDResolver: (item) => item.collection_shopify_id,
  });

  const filterHandleChange = createValidatedSelectionHandler(
    filterHandleChangeOriginal,
    2,
    collections,
    filterCollection,
    simpleSelected,
    filterSelected,
  );

  const {
    selectedResources: shopifySelected,
    allResourcesSelected: shopifyAllSelected,
    handleSelectionChange: shopifyHandleChange,
  } = useIndexResourceState(shopifyCollections, {
    resourceIDResolver: (item) => item.id,
  });

  const currentSelectedResources =
    selected === 0
      ? simpleSelected
      : selected === 1
        ? trendingSelected
        : selected === 2
          ? filterSelected
          : shopifySelected;

  const currentAllSelected =
    selected === 0
      ? simpleAllSelected
      : selected === 1
        ? trendingAllSelected
        : selected === 2
          ? filterAllSelected
          : shopifyAllSelected;

  useEffect(() => {
    setCurrentTabSelections(currentSelectedResources);
  }, [
    selected,
    simpleSelected,
    trendingSelected,
    filterSelected,
    shopifySelected,
  ]);

  useEffect(() => {
    if (resetSelections) {
      currentSelectedResources.length = 0;
      setResetSelections(false);
    }
  }, [resetSelections]);

  const currentHandleChange =
    selected === 0
      ? simpleHandleChange
      : selected === 1
        ? trendingHandleChange
        : selected === 2
          ? filterHandleChange
          : shopifyHandleChange;

  // Check selected collections type
  const areAllSelectedShopify = currentTabSelections.every((id) =>
    isShopifyCollection(id, selected, collections, filterCollection),
  );

  const sortOptions: IndexFiltersProps["sortOptions"] = [
    { label: "Order", value: "order asc", directionLabel: "Ascending" },
    { label: "Order", value: "order desc", directionLabel: "Descending" },
    { label: "Customer", value: "customer asc", directionLabel: "A-Z" },
    { label: "Customer", value: "customer desc", directionLabel: "Z-A" },
    { label: "Date", value: "date asc", directionLabel: "A-Z" },
    { label: "Date", value: "date desc", directionLabel: "Z-A" },
    { label: "Total", value: "total asc", directionLabel: "Ascending" },
    { label: "Total", value: "total desc", directionLabel: "Descending" },
  ];

  const onHandleCancel = () => {};
  const onHandleClose = () => {
    setActivePublish(false);
  };

  const onHandleSave = async () => {
    await sleep(1);
    return true;
  };

  const handleSelect = (index: number) => {
    setSelected(index);
  };

  const primaryAction: IndexFiltersProps["primaryAction"] = {
    type: "save",
    onAction: onHandleSave,
    disabled: false,
    loading: false,
  };

  const [queryValue, setQueryValue] = useState("");

  const handleFiltersQueryChange = useCallback(
    (value: string) => setQueryValue(value),
    [],
  );

  const handleQueryValueRemove = useCallback(() => setQueryValue(""), []);
  const handleFiltersClearAll = useCallback(() => {
    handleQueryValueRemove();
  }, [handleQueryValueRemove]);

  const filters = [
    {
      key: "simpleCollection",
      label: "Simple Collection",
      filter: (
        <ChoiceList
          title="Simple Collection"
          titleHidden
          choices={[{ label: "Simple Collection", value: "simple" }]}
          selected={selectedCollectionType || []}
          onChange={(value) => setSelectedCollectionType(value)}
          allowMultiple
        />
      ),
      shortcut: true,
    },
    {
      key: "trendingCollection",
      label: "Trending Collection",
      filter: (
        <ChoiceList
          title="Trending Collection"
          titleHidden
          choices={[{ label: "Trending Collection", value: "trending" }]}
          selected={selectedCollectionType || []}
          onChange={(value) => setSelectedCollectionType(value)}
          allowMultiple
        />
      ),
      shortcut: true,
    },
    {
      key: "filterCollection",
      label: "Filter Collection",
      filter: (
        <ChoiceList
          title="Filter Collection"
          titleHidden
          choices={[{ label: "Filter Collection", value: "filter" }]}
          onChange={(value) => setSelectedCollectionType(value)}
          selected={selectedCollectionType || []}
          allowMultiple
        />
      ),
      shortcut: true,
    },
    {
      key: "Shopify Collection",
      label: "Shopify Collection",
      filter: (
        <ChoiceList
          title="Shopify Collection"
          titleHidden
          choices={[{ label: "Shopify Collection", value: "shopify" }]}
          onChange={(value) => setSelectedCollectionType(value)}
          selected={selectedCollectionType || []}
          allowMultiple
        />
      ),
      shortcut: true,
    },
  ];

  const appliedFilters: IndexFiltersProps["appliedFilters"] = [];
  const resourceName = {
    singular: "collection",
    plural: "collections",
  };

  const rowMarkup = (
    selected === 2
      ? filterCollection
      : selected === 0
        ? collections
        : selected === 1
          ? trendingCollection
          : selected === 3
            ? shopifyCollections
            : []
  ).map(
    (
      {
        id,
        collection_shopify_id,
        product_shopify_category,
        title,
        description,
        productsCount,
        image,
        types,
        collection_name,
        collection_product_count,
        collection_condition,
        collection_banner_url,
        collection_is_shopify,
      },
      index,
    ) => {
      const finalId = selected === 3 ? id : collection_shopify_id;

      return (
        <IndexTable.Row
          id={finalId}
          position={index}
          key={finalId}
          selected={currentSelectedResources.includes(finalId)}
        >
          <IndexTable.Cell>
            <div style={{ padding: "10px 0" }}>
              <InlineStack
                wrap={false}
                gap={{ xs: "050", sm: "100", md: "200", lg: "300", xl: "400" }}
              >
                <ValidImageAvatar
                  url={image?.url ? image?.url : collection_banner_url}
                  fallbackUrl="https://cdn.shopify.com/s/files/1/0923/5460/9434/files/no-photo-or-blank-image-icon-loading-images-or-missing-image-mark-image-not-available-or-image-coming-soon-sign-simple-nature-silhouette-in-frame-isolated-illustration-vector.jpg?v=1746776130"
                />
                <div style={{ display: "flex", alignItems: "center" }}>
                  <Text variant="bodyMd" fontWeight="medium" as="span">
                    {collection_name ? collection_name : title}
                  </Text>
                </div>
              </InlineStack>
            </div>
          </IndexTable.Cell>

          <IndexTable.Cell>
            <div style={{ padding: "10px 0" }}>
              {selected === 2 ? (
                <Badge tone="success">
                  {collection_is_shopify === true
                    ? "Shopify Collection"
                    : "Filter Collection"}
                </Badge>
              ) : selected === 1 ? (
                <Badge tone="success">Trending Collection</Badge>
              ) : selected === 0 ? (
                <Badge tone="success">
                  {collection_is_shopify === true
                    ? "Shopify Collection"
                    : "Simple Collection"}
                </Badge>
              ) : (
                <Badge tone="info">UnPublished</Badge>
              )}
            </div>
          </IndexTable.Cell>
          <IndexTable.Cell>
            <div style={{ padding: "10px 0" }}>
              {selected !== 3
                ? (collection_product_count ?? 0)
                : (productsCount?.count ?? 0)}
            </div>
          </IndexTable.Cell>

          <IndexTable.Cell>
            <div
              style={{
                padding: "10px 0",
                display: "flex",
              }}
            >
              {selected !== 3 ? collection_condition : description}
            </div>
          </IndexTable.Cell>
        </IndexTable.Row>
      );
    },
  );

  return (
    <Card padding={"0"}>
      <IndexFilters
        sortOptions={sortOptions}
        sortSelected={sortSelected}
        queryValue={queryValue}
        queryPlaceholder="Searching in all"
        onQueryChange={handleFiltersQueryChange}
        onQueryClear={() => setQueryValue("")}
        onSort={setSortSelected}
        primaryAction={primaryAction}
        cancelAction={{
          onAction: onHandleCancel,
          disabled: false,
          loading: false,
        }}
        selected={selected}
        onSelect={handleSelect}
        tabs={tabs}
        canCreateNewView={false}
        filters={filters}
        appliedFilters={appliedFilters}
        onClearAll={handleFiltersClearAll}
        mode={mode}
        setMode={setMode}
      />
      <IndexTable
        condensed={useBreakpoints().smDown}
        resourceName={resourceName}
        itemCount={
          selected === 0
            ? collections.length
            : selected === 1
              ? trendingCollection.length
              : selected === 2
                ? filterCollection.length
                : shopifyCollections.length
        }
        selectedItemsCount={
          currentAllSelected ? "All" : currentSelectedResources.length
        }
        onSelectionChange={currentHandleChange}
        headings={[
          { title: "Title" },
          { title: selected === 3 ? "Collection Status" : "Collection Type" },
          { title: "Products" },
          { title: "Collection Condition" },
        ]}
      >
        {rowMarkup}
      </IndexTable>
      <ConfirmationModal
        open={activePublish}
        onClose={onHandleClose}
        title="Are You Sure You Want To Publish Your Collection?"
        message="Publishing this collection will add it to both the Simple and Filter collections."
        confirmLabel="Yes, Publish"
        cancelLabel="No, Cancel"
        onConfirm={() => handleConfirmPublish(currentTabSelections)}
        isLoading={isPublishing}
      />
    </Card>
  );
}
export default CollectionTable;
