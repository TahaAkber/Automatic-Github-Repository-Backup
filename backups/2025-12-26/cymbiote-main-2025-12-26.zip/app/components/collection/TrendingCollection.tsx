import { useEffect, useState } from "react";
import {
  Card,
  Grid,
  Button,
  Select,
  Text,
  Icon,
  Badge,
  DataTable,
  Combobox,
  Toast,
  Frame,
  InlineStack,
} from "@shopify/polaris";
import { SearchIcon, PlusIcon, DiscountIcon } from "@shopify/polaris-icons";
import { Product } from "./SearchModal";
import { Collection } from "./CollectionModal";
import { DeleteIcon } from "@shopify/polaris-icons";

export interface TrendingProductGroup {
  products: any[];
  collection_type: string;
  collection_banner_url: string;
  collection_description: string;
}

export interface Trending {
  setIsModalOpen: any | boolean;
  setIsCollectionModalOpen: any | boolean;
  selectedproducts: Product[];
  selectedCollections: Collection[];
  setTrendingProductsGroup: (value: TrendingProductGroup[]) => void;
  setSelectedCollections: (value: Collection[]) => void;
  setSelectedproducts: (value: Product[]) => void;
  setSelectedRow: (value: number) => void;
  TrendingProductsGroup: TrendingProductGroup[];
  selectedRow: number;
  removeproduct: (id: number) => void;
}

export default function TrendingCollection({
  setIsModalOpen,
  setIsCollectionModalOpen,
  selectedproducts,
  selectedCollections,
  setSelectedCollections,
  setSelectedproducts,
  setSelectedRow,
  setTrendingProductsGroup,
  TrendingProductsGroup,
  selectedRow,
  removeproduct,
}: Trending) {
  const [collections, setCollections] = useState([{ id: 1 }]);
  const [toastActive, setToastActive] = useState(false);
  const [transactionType, setTransactionType] = useState("remove");

  useEffect(() => {
    if (
      selectedproducts.length === 0 ||
      selectedCollections.length === 0 ||
      transactionType === "remove"
    ) {
      setTransactionType("add");
      return;
    }

    const newGroup: TrendingProductGroup = {
      products: [...selectedproducts],
      collection_type:
        selectedCollections[selectedCollections.length - 1]?.trending_name,
      collection_banner_url:
        selectedCollections[selectedCollections.length - 1]
          ?.trending_banner_url,
      collection_description:
        selectedCollections[selectedCollections.length - 1]
          .trending_description,
    };

    const existingGroupIndex = TrendingProductsGroup.findIndex(
      (group) => group.collection_type === newGroup.collection_type,
    );

    console.log("newGroup", newGroup);
    console.log("existingGroupIndex", existingGroupIndex);

    let updatedGroups;

    if (existingGroupIndex !== -1) {
      updatedGroups = [...TrendingProductsGroup];
      updatedGroups[selectedRow].products = newGroup.products;
    } else {
      updatedGroups = [...TrendingProductsGroup, newGroup];
    }

    setTrendingProductsGroup(updatedGroups);
  }, [selectedproducts, selectedCollections]);

  const handleRemoveRow = (indexToRemove: number) => {
    setTransactionType("remove");
    // 1. Remove row from the visible collections (UI rows)
    if (collections.length > 1) {
      const updatedCollectionRows = collections.filter(
        (_, index) => index !== indexToRemove,
      );
      setCollections(updatedCollectionRows);
    }

    // 2. Remove the selected collection at that index
    const updatedSelectedCollections = [...selectedCollections];
    updatedSelectedCollections.splice(indexToRemove, 1);
    setSelectedCollections(updatedSelectedCollections);

    // 3. Remove the product group at that index
    const updatedGroups = [...TrendingProductsGroup];
    updatedGroups.splice(indexToRemove, 1);
    setTrendingProductsGroup(updatedGroups);

    // 4. If the selected row was this one, reset selected products
    if (selectedRow === indexToRemove) {
      setSelectedproducts([]);
    }

    console.log(
      `Removed row ${indexToRemove}, along with collection and products.`,
    );
  };

  const addCollection = () => {
    setTransactionType("add");
    const newRow = {
      id: Date.now(),
      selectedCollection: null,
      selectedProducts: [],
    };

    setCollections([...collections, newRow]);
  };

  const handleProductFocus = (index: number) => {
    const hasCollectionSelected = selectedCollections[index]?.trending_name;

    if (!hasCollectionSelected) {
      setToastActive(true);
      setTimeout(() => setToastActive(false), 3000);
    } else {
      setIsModalOpen(true);
    }
  };

  return (
    <>
      <Card>
        {collections.map((collection, index) => {
          return (
            <InlineStack key={collection.id} gap="400">
              <div style={{ width: "40%", marginTop: "3%" }}>
                <Combobox
                  activator={
                    <Combobox.TextField
                      label="Select Collection"
                      labelHidden
                      placeholder={
                        selectedCollections[index]?.trending_name
                          ? `Selected ${selectedCollections[index]?.trending_name}`
                          : "Select Collections"
                      }
                      autoComplete="off"
                      onFocus={() => {
                        setIsCollectionModalOpen(true);
                      }}
                    />
                  }
                />
              </div>

              <div style={{ width: "40%", marginTop: "3%" }}>
                <Combobox
                  activator={
                    <Combobox.TextField
                      prefix={<Icon source={SearchIcon} />}
                      label="Search Products"
                      labelHidden
                      placeholder={
                        TrendingProductsGroup[index]
                          ? `${TrendingProductsGroup[index]?.products?.length || 0} Product(s) selected`
                          : "Select Products"
                      }
                      autoComplete="off"
                      onFocus={() => {
                        handleProductFocus(index);
                        setSelectedRow(index);
                      }}
                    />
                  }
                />
              </div>

              {TrendingProductsGroup.length > 0 && (
                <div
                  style={{
                    height: "100%",
                    marginTop: "4%",
                  }}
                >
                  <Button
                    icon={DeleteIcon}
                    variant="monochromePlain"
                    size="large"
                    onClick={() => handleRemoveRow(index)}
                  ></Button>
                </div>
              )}
            </InlineStack>
          );
        })}

        <div style={{ marginTop: "2%" }}>
          <Button
            icon={PlusIcon}
            size="large"
            variant="primary"
            onClick={addCollection}
          >
            Add More Collection
          </Button>
        </div>
      </Card>

      {toastActive && (
        <Frame>
          <Toast
            content="Please select a collection first."
            onDismiss={() => setToastActive(false)}
          />
        </Frame>
      )}

      {TrendingProductsGroup.length > 0 && (
        <div style={{ marginTop: "2%" }}>
          <Card>
            <DataTable
              columnContentTypes={["text", "text", "text", "text", "text"]}
              headings={[
                "Products",
                "Actual Price",
                "Discount Price",
                "Collection",
                "Status",
              ]}
              rows={TrendingProductsGroup.flatMap((group, groupIndex) =>
                group.products.map((product, productIndex) => [
                  <div
                    style={{
                      display: "flex",
                      alignItems: "center",
                      gap: "10px",
                    }}
                    key={`${groupIndex}-${productIndex}`}
                  >
                    <span>{productIndex + 1}</span>
                    <img
                      src={product.product_image_url}
                      alt={product.product_name}
                      style={{
                        width: "50px",
                        height: "50px",
                        objectFit: "contain",
                        borderRadius: "5px",
                      }}
                    />
                    <span>{product.product_name}</span>
                  </div>,
                  <div style={{ marginTop: "1rem" }}>N/A</div>,
                  <div style={{ marginTop: "1rem" }}>N/A</div>,
                  <div
                    style={{
                      display: "flex",
                      alignItems: "center",
                      gap: "10px",
                      marginTop: "1rem",
                    }}
                  >
                    {group.collection_type}
                  </div>,
                  <div
                    style={{
                      display: "flex",
                      alignItems: "center",
                      gap: "0.7rem",
                      marginTop: "1rem",
                    }}
                  >
                    <Badge size="medium" tone="success">
                      Active
                    </Badge>

                    {selectedproducts.length > 1 && (
                      <Button
                        icon={DeleteIcon}
                        size="micro"
                        onClick={() => {
                          removeproduct(product.product_id);
                        }}
                      />
                    )}
                  </div>,
                ]),
              )}
            />
          </Card>
        </div>
      )}
    </>
  );
}
