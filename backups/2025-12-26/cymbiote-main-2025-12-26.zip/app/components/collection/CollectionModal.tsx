import {
  Modal,
  Frame,
  Checkbox,
  Thumbnail,
  InlineStack,
  Combobox,
  Icon,
  Button,
} from "@shopify/polaris";
import { SearchIcon } from "@shopify/polaris-icons";
import { useEffect, useState } from "react";

export interface Collection {
  collection_id: number;
  collection_name: string;
  image: string;
  collection_shopify_id: any;
  collection_image: any;
  trending_id: any;
  trending_banner_url: string;
  trending_name: string;
  trending_description: string;
}

interface Modelstate {
  open: boolean;
  onClose: any;
  collection: any[];
  setselectedcollections: (products: Collection[]) => void;
  selectedcollections: Collection[];
  mergedData: any[];
  existingCollections: any[];
  TrendingProductsGroup: any[];
}

export default function CollectionModal({
  open,
  onClose,
  mergedData,
  existingCollections,
  selectedcollections,
  TrendingProductsGroup,
  setselectedcollections,
  collection: initialProducts,
}: Modelstate) {
  const [selectedItem, setSelectedItem] = useState<Collection | null>(null);

  const existingTrending = existingCollections.filter(
    (e) => e.collection_type_id === 2,
  );
  console.log("existingTrending", existingTrending);

  // useEffect(() => {
  //   setSelectedItem(
  //     Array.isArray(selectedcollections) && selectedcollections.length > 0
  //       ? selectedcollections[0]
  //       : null,
  //   );
  // }, [selectedcollections, TrendingProductsGroup]);

  const handleCheckboxChange = (collection: Collection) => {
    if (selectedItem?.collection_id === collection?.trending_id) {
      setSelectedItem(null);
    } else {
      setSelectedItem(collection);
    }
  };

  const handleDoneClick = () => {
    if (selectedItem) {
      setselectedcollections([...selectedcollections, selectedItem]);
    } else {
      setselectedcollections([]);
    }
    setSelectedItem(null);
    onClose();
  };

  return (
    <div style={{ height: "0" }}>
      <Frame>
        <Modal open={open} title="Select Collection" onClose={onClose}>
          <div style={{ width: "94%", margin: "3%" }}>
            <Combobox
              activator={
                <Combobox.TextField
                  prefix={<Icon source={SearchIcon} />}
                  label="Select Collection"
                  labelHidden
                  placeholder="Select Collection"
                  autoComplete="off"
                />
              }
            />
          </div>

          <div
            style={{ maxHeight: "300px", overflowY: "auto", padding: "0 16px" }}
          >
            {initialProducts.map((collection) => {
              const collectionProductsExist = TrendingProductsGroup.some(
                (group) =>
                  group.products.length > 0 &&
                  group.collection_type === collection.trending_name,
              );

              return (
                <Modal.Section key={collection?.trending_id + `-inner`}>
                  <Checkbox
                    label={
                      <InlineStack
                        align="center"
                        gap={{ xs: "300", md: "300", lg: "400", xl: "500" }}
                      >
                        <Thumbnail
                          source={collection?.trending_banner_url}
                          alt={collection?.trending_name}
                          size="small"
                        />
                        <span style={{ display: "flex", alignItems: "center" }}>
                          {collection?.trending_name}
                        </span>
                      </InlineStack>
                    }
                    checked={
                      selectedItem?.trending_id === collection?.trending_id
                    }
                    onChange={() => handleCheckboxChange(collection)}
                    disabled={
                      collectionProductsExist ||
                      existingTrending.findIndex(
                        (e) => e.collection_name === collection?.trending_name,
                      ) > -1
                    }
                  />
                </Modal.Section>
              );
            })}
          </div>

          <div
            style={{
              position: "sticky",
              bottom: 0,
              background: "white",
              padding: "16px",
              boxShadow: "0 -2px 10px rgba(0,0,0,0.1)",
              display: "flex",
              justifyContent: "flex-end",
              gap: 10,
            }}
          >
            <Button onClick={onClose}>Cancel</Button>
            <Button
              variant="primary"
              onClick={handleDoneClick}
              disabled={!selectedItem}
            >
              Done
            </Button>
          </div>
        </Modal>
      </Frame>
    </div>
  );
}
