import { useCallback, useState, useMemo } from "react";
import {
  Grid,
  Select,
  Listbox,
  Popover,
  OptionList,
  Autocomplete,
  Modal,
  Frame,
  Checkbox,
  Thumbnail,
  InlineStack,
  Combobox,
  Icon,
  Button,
} from "@shopify/polaris";
import { SearchIcon, PlusIcon, DeleteIcon } from "@shopify/polaris-icons";
import SearchModal, { Product } from "./SearchModal";
import PopOver from "./Popover";
import SearchProductCategory from "./SearchProductCategory";

export interface SmartCollection {
  setCustomCategory: (value: any[]) => void;
  customCategory: any[];
}
export default function SmartCollection({
  setCustomCategory,
  customCategory,
}: SmartCollection) {
  const [collections, setCollections] = useState([{ id: 1 }]);

  const addCollection = () => {
    setCollections([...collections, { id: Date.now() }]); 
  };
  const [selectedproducts, setSelectedproducts] = useState<any[]>([]);

  const removecollection = (id: number) => {
    setCollections((prevCollections) =>
      prevCollections.filter((collection) => collection.id !== id),
    );
  };
  const TagValues = {
    id: 1,
    title: "Product Fields",
    options: [
      { value: "Vendor", label: "Vendor" },
      { value: "Type", label: "Type" },
      { value: "Category", label: "Category" },
      { value: "Price", label: "Price" },
      { value: "Weight", label: "Weight" },
      { value: "Tags", label: "Tags" },
    ],
  };
  const Conditions = {
    id: 2,
    options: [
      { value: "is equal to", label: "is equal to" },
      { value: "is not equal to", label: "is not equal to" },
      { value: "starts with", label: "ends with" },
      { value: "contains", label: "contains" },
      { value: "does not contain", label: "does not contain" },
    ],
  };

  const getDeselectedOptions = () => {
    return customCategory.map((value) => ({
      value,
      label: value.charAt(0).toUpperCase() + value.slice(1),
    }));
  };

  const deselectedOptions = getDeselectedOptions();
  const [isModalOpen, setIsModalOpen] = useState(false);

  const [selectedOptions, setSelectedOptions] = useState<string[]>([]);
  const [inputValue, setInputValue] = useState("");
  const [options, setOptions] = useState(deselectedOptions);

  const updateText = useCallback(
    (value: string) => {
      setInputValue(value);

      if (value === "") {
        setOptions(deselectedOptions);
        return;
      }

      const filterRegex = new RegExp(value, "i");
      const resultOptions = deselectedOptions.filter((option) =>
        option.label.match(filterRegex),
      );
      setOptions(resultOptions);
    },
    [deselectedOptions],
  );

  const updateSelection = useCallback(
    (selected: string[]) => {
      const selectedValue = selected.map((selectedItem) => {
        const matchedOption = options.find((option) => {
          return option.value.match(selectedItem);
        });
        return matchedOption && matchedOption.label;
      });

      setSelectedOptions(selected);
      setInputValue(selectedValue[0] || "");
    },
    [options],
  );

  const textField = (
    <Autocomplete.TextField
      onChange={updateText}
      label=""
      value={inputValue}
      autoComplete="off"
    />
  );
  return (
    <div style={{ margin: "10px" }}>
      {collections.map((collection) => (
        <div key={collection.id}>
          <Grid columns={{ xs: 6, sm: 10, md: 14, lg: 14, xl: 18 }}>
            <Grid.Cell columnSpan={{ xs: 2, sm: 3, md: 4, lg: 4, xl: 5 }}>
              <div style={{ height: "10px", width: "100%" }}>
                <PopOver TagValues={TagValues} />
              </div>
            </Grid.Cell>
            <Grid.Cell columnSpan={{ xs: 2, sm: 3, md: 4, lg: 4, xl: 5 }}>
              <PopOver TagValues={Conditions} />
            </Grid.Cell>
            <Grid.Cell columnSpan={{ xs: 1, sm: 2, md: 3, lg: 3, xl: 4 }}>
              <div style={{ width: "100%" }}>
                <Combobox
                  activator={
                    <Combobox.TextField
                      onChange={updateText}
                      label="Product Categories"
                      labelHidden
                      value={inputValue}
                      placeholder="Product Categories"
                      autoComplete="off"
                      onFocus={() => {
                        setIsModalOpen(true);
                      }}
                    />
                  }
                ></Combobox>
              </div>
            </Grid.Cell>
            <Grid.Cell columnSpan={{ xs: 1, sm: 2, md: 3, lg: 3, xl: 2 }}>
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  height: "50%",
                  cursor: "pointer",
                  transform: "scale(1.5)",
                }}
                onClick={() => removecollection(collection.id)}
              >
                <Icon source={DeleteIcon} tone="base" />
              </div>
            </Grid.Cell>
          </Grid>
        </div>
      ))}
      <Button
        icon={PlusIcon}
        size="large"
        variant="primary"
        onClick={addCollection}
      >
        Add Another Condition
      </Button>
      <SearchProductCategory
        open={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        products={customCategory}
        setSelectedproducts={setSelectedproducts}
        selectedproducts={selectedproducts}
      />
    </div>
  );
}
