import { useEffect, useState } from "react";
import {
  Card,
  Grid,
  Button,
  Select,
  Text,
  Icon,
  Badge,
  DataTable,
} from "@shopify/polaris";
import { MinusIcon, PlusIcon, XIcon } from "@shopify/polaris-icons";
import { Product } from "./SearchModal";
import { DeleteIcon } from "@shopify/polaris-icons";

export interface FilterProductGroup {
  title: string;
  products: any[];
  sort: string;
}

export interface Filter {
  setIsModalOpen: (value: boolean) => void;
  selectedproducts: any[];
  setSelectedproducts: (products: Product[]) => void;
  setFilteredProductsGroup: (value: FilterProductGroup[]) => void;
  FilteredProductsGroup: FilterProductGroup[];
}

export default function FilterCollection({
  setIsModalOpen,
  selectedproducts,
  setSelectedproducts,
  setFilteredProductsGroup,
  FilteredProductsGroup,
}: Filter) {
  const [filterRows, setFilterRows] = useState<
    { title: string; products: Product[]; sort: string }[]
  >([{ title: "", products: [], sort: "" }]);
  const [activeRowIndex, setActiveRowIndex] = useState<number | null>(null);

  const sortOptions = [
    { label: "Top Rated", value: "Top Rated" },
    { label: "Worst Rated", value: "Worst Rated" },
  ];

  const handleChangeTitle = (value: string, index: number) => {
    const updatedFilterRows = [...filterRows];
    updatedFilterRows[index].title = value;
    setFilterRows(updatedFilterRows);

    if (FilteredProductsGroup[index]) {
      const updatedGroups = [...FilteredProductsGroup];
      updatedGroups[index].title = value;
      setFilteredProductsGroup(updatedGroups);
    }
  };

  const handleSortChange = (value: string, index: number) => {
    const updated = [...filterRows];
    updated[index].sort = value;

    // Also re-sort existing products in that row
    const rowProducts = [...updated[index].products];

    if (value === "Best Selling") {
      rowProducts.sort((a, b) => b.product_rating - a.product_rating);
    } else if (value === "Worst Selling") {
      rowProducts.sort((a, b) => a.product_rating - b.product_rating);
    }

    updated[index].products = rowProducts;
    setFilterRows(updated);

    // If already saved, also update FilteredProductsGroup
    if (FilteredProductsGroup[index]) {
      const updatedGroups = [...FilteredProductsGroup];
      updatedGroups[index].products = rowProducts;
      updatedGroups[index].sort = value;
      setFilteredProductsGroup(updatedGroups);
    }
  };

  const handleSaveRow = (index: number) => {
    const row = filterRows[index];

    if (!row.title || row.products.length === 0) return;

    const newGroup: FilterProductGroup = {
      title: row.title,
      products: row.products,
      sort: row.sort,
    };

    const updatedGroups = [...FilteredProductsGroup];

    if (updatedGroups[index]) {
      updatedGroups[index] = newGroup;
    } else {
      updatedGroups.push(newGroup);
    }

    setFilteredProductsGroup(updatedGroups);

    const updatedRows = [...filterRows];
    setFilterRows(updatedRows);
  };

  const handleOpenModal = (index: number) => {
    const row = filterRows[index];
    if (!row.title) {
      shopify.toast.show("Please Enter a Title First");
      return;
    }

    setActiveRowIndex(index);
    setIsModalOpen(true);
  };

  useEffect(() => {
    if (selectedproducts.length > 0 && activeRowIndex !== null) {
      assignSelectedProductsToRow();
      setTimeout(() => {
        handleSaveRow(activeRowIndex);
      }, 100);
    }
  }, [selectedproducts]);

  const assignSelectedProductsToRow = () => {
    if (activeRowIndex === null) return;

    const updated = [...filterRows];
    const row = updated[activeRowIndex];

    let sortedProducts = [...selectedproducts];

    if (row.sort === "Best Selling") {
      sortedProducts.sort((a, b) => b.product_rating - a.product_rating); // high to low
    } else if (row.sort === "Worst Selling") {
      sortedProducts.sort((a, b) => a.product_rating - b.product_rating); // low to high
    }

    // assign sorted products to the row
    updated[activeRowIndex].products = sortedProducts;
    setFilterRows(updated);
    // setSelectedproducts([]);
  };

  const addNewRow = () => {
    if (filterRows.length <= 3) {
      setFilterRows([...filterRows, { title: "", products: [], sort: "" }]);
    }
  };

  const handleRemoveRow = (indexToRemove: number) => {
    const targetIndex =
      indexToRemove !== undefined ? indexToRemove : activeRowIndex || 0;

    // if (targetIndex < 0 || targetIndex >= filterRows.length) {
    //   return;
    // }

    if (filterRows.length === 1) {
      const updatedRows = [...filterRows];
      updatedRows[0] = { title: "", products: [], sort: "" };
      setFilterRows(updatedRows);

      setFilteredProductsGroup([]);

      setActiveRowIndex(indexToRemove - 1);
    } else {
      const updatedRows = [...filterRows];
      updatedRows.splice(targetIndex, 1);
      setFilterRows(updatedRows);

      const updatedGroups = [...FilteredProductsGroup];
      if (updatedGroups[targetIndex]) {
        updatedGroups.splice(targetIndex, 1);
        setFilteredProductsGroup(updatedGroups);
      }
      if (activeRowIndex === targetIndex) {
        setActiveRowIndex(indexToRemove - 1);
      } else if (activeRowIndex !== null && activeRowIndex > targetIndex) {
        setActiveRowIndex(activeRowIndex - 1);
      }
    }
  };

  const handleRemove = (groupIndex: number, productId: number) => {
    const updatedGroups = [...FilteredProductsGroup];
    const updatedRows = [...filterRows];

    updatedGroups[groupIndex] = {
      ...updatedGroups[groupIndex],
      products: updatedGroups[groupIndex].products.filter(
        (product) => product.product_id !== productId,
      ),
    };

    updatedRows[groupIndex] = {
      ...updatedRows[groupIndex],
      products: updatedRows[groupIndex].products.filter(
        (product) => product.product_id !== productId,
      ),
    };

    const nonEmptyGroups = updatedGroups.filter(
      (group) => group.products.length > 0,
    );
    const nonEmptyRows = updatedRows.filter(
      (row) => row.products.length > 0 || row.title || row.sort,
    );

    setFilteredProductsGroup(nonEmptyGroups);
    setFilterRows(nonEmptyRows);
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "20px" }}>
      <Card>
        <div
          style={{
            marginBottom: "2%",
            display: "flex",
            justifyContent: "space-between",
          }}
        >
          <Text as="legend" variant="headingMd">
            Add Filters
          </Text>
        </div>

        {filterRows.map((row, index) => (
          <Grid key={index} columns={{ xs: 1, sm: 2, md: 4, lg: 6, xl: 8 }}>
            <Grid.Cell columnSpan={{ xs: 1, sm: 2, md: 2, lg: 2, xl: 2 }}>
              <input
                type="text"
                placeholder="Enter Filter Title"
                value={row.title}
                onChange={(e) => handleChangeTitle(e.target.value, index)}
                style={{
                  width: "100%",
                  padding: "8px",
                  borderRadius: "4px",
                  border: "1px solid #ccc",
                  marginTop: "10px",
                  marginBottom: "8px",
                }}
              />
            </Grid.Cell>

            <Grid.Cell columnSpan={{ xs: 1, sm: 2, md: 2, lg: 2, xl: 2 }}>
              <input
                type="text"
                placeholder={
                  row.products.length > 0
                    ? `${row.products.length} item(s) selected`
                    : "Add Products"
                }
                style={{
                  width: "100%",
                  padding: "8px",
                  borderRadius: "4px",
                  border: "1px solid #ccc",
                  marginTop: "10px",
                  marginBottom: "8px",
                }}
                onFocus={() => handleOpenModal(index)}
                readOnly
              />
            </Grid.Cell>

            <Grid.Cell columnSpan={{ xs: 2 }}>
              <div
                style={{
                  marginTop: "10px",
                  marginBottom: "8px",
                  display: "flex",
                  alignItems: "center",
                  gap: "10px",
                }}
              >
                <Select
                  label="Sort by"
                  labelInline
                  options={sortOptions}
                  onChange={(val) => handleSortChange(val, index)}
                  value={row.sort}
                />
                <span
                  onClick={() => handleRemoveRow(index)}
                  style={{ cursor: "pointer" }}
                >
                  <Icon source={DeleteIcon} tone="base" />
                </span>
              </div>
            </Grid.Cell>
          </Grid>
        ))}

        <div style={{ marginTop: "10px" }}>
          <div style={{ display: "flex", gap: "10px" }}>
            <Button
              onClick={() => addNewRow()}
              icon={PlusIcon}
              variant="primary"
            >
              Add Another Filter
            </Button>
          </div>
        </div>
      </Card>

      {FilteredProductsGroup.map((group, index) => (
        <Card key={index}>
          <Text variant="headingMd" as="h3" alignment="start">
            {group.title}
          </Text>
          <DataTable
            columnContentTypes={["text", "numeric", "numeric", "text", "text"]}
            headings={[]}
            rows={group.products.map((product) => [
              <div
                style={{ display: "flex", alignItems: "center", gap: "10px" }}
              >
                <span>{product.product_id}</span>
                <img
                  src={product.product_image_url}
                  alt={product.product_name}
                  style={{
                    width: "50px",
                    height: "50px",
                    objectFit: "contain",
                    borderRadius: "5px",
                  }}
                />
                <span>{product.product_name}</span>
              </div>,

              <div>
                <Badge tone="success">Active</Badge>
                <button
                  style={{
                    background: "none",
                    border: "none",
                    cursor: "pointer",
                  }}
                  onClick={() => handleRemove(index, product.product_id)}
                >
                  <Icon source={XIcon} tone="base" />
                </button>
              </div>,
            ])}
          />
        </Card>
      ))}
    </div>
  );
}
