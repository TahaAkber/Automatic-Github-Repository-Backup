import { Modal, Frame, Checkbox, InlineStack, Button } from "@shopify/polaris";
import { useEffect, useState } from "react";

interface Product {
  id: number;
  product_name: string;
}

interface ModelState {
  open: boolean;
  onClose: () => void;
  products: string[];
  setSelectedproducts: (products: Product[]) => void;
  selectedproducts: Product[];
}

export default function SearchProductCategory({
  open,
  onClose,
  products: productNames,
  setSelectedproducts,
  selectedproducts,
}: ModelState) {
  const [selectedItems, setSelectedItems] = useState<Product[]>([]);
  const [productcategoryWithIds, setProductCategoryWithIds] = useState<
    Product[]
  >([]);

  useEffect(() => {
    const updatedProducts = productNames.map((name, index) => ({
      id: index,
      product_name: name,
    }));
    setProductCategoryWithIds(updatedProducts);
  }, [productNames]);

  useEffect(() => {
    if (open) {
      setSelectedItems(selectedproducts);
    }
    console.log("open selected products", selectedItems);
  }, [selectedproducts, open]);

  const handleCheckboxChange = (product: Product) => {
    setSelectedItems((prev) => {
      const isSelected = prev.some((item) => item.id === product.id);
      return isSelected
        ? prev.filter((item) => item.id !== product.id)
        : [...prev, product];
    });
  };

  const handleDoneClick = () => {
    setSelectedproducts([...selectedItems]);
    onClose();
  };

  return (
    <div style={{ height: "0" }}>
      <Frame>
        <Modal open={open} title="Search Category" onClose={onClose}>
          <div
            style={{ maxHeight: "300px", overflowY: "auto", padding: "0 16px" }}
          >
            {productcategoryWithIds.map((product) => (
              <Modal.Section key={product.id}>
                <Checkbox
                  label={
                    <InlineStack align="center" gap="200">
                      <span>{product.product_name}</span>
                    </InlineStack>
                  }
                  checked={selectedItems.some((item) => item.id === product.id)}
                  onChange={() => handleCheckboxChange(product)}
                />
              </Modal.Section>
            ))}
          </div>

          <div
            style={{
              position: "sticky",
              bottom: 0,
              background: "white",
              padding: "16px",
              boxShadow: "0 -2px 10px rgba(0,0,0,0.1)",
              display: "flex",
              justifyContent: "flex-end",
              gap: 10,
            }}
          >
            <Button variant="secondary" onClick={onClose}>
              Cancel
            </Button>
            <Button variant="primary" onClick={handleDoneClick}>
              Done
            </Button>
          </div>
        </Modal>
      </Frame>
    </div>
  );
}
