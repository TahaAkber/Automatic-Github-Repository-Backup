import { useCallback, useState } from "react";
import {
  Button,
  Grid,
  Select,
  Icon,
  Combobox,
  Listbox,
  Popover,
  OptionList,
} from "@shopify/polaris";
import { SearchIcon, PlusIcon, DeleteIcon } from "@shopify/polaris-icons";
import SearchModal from "./SearchModal";

export default function PopOver({ TagValues }: { TagValues: any }) {
  const [selected, setSelected] = useState<string[]>([]);
  const [popoverActive, setPopoverActive] = useState(false);

  const togglePopoverActive = useCallback(
    () => setPopoverActive((popoverActive) => !popoverActive),
    [],
  );
  const activator = (
    <div style={{ width: "100%", height: "50px" }}>
      <Button
        onClick={togglePopoverActive}
        textAlign="start"
        disclosure
        fullWidth
      >
        {selected}
      </Button>
    </div>
  );
  return (
    <Popover
      active={popoverActive}
      activator={activator}
      onClose={togglePopoverActive}
    >
      <div style={{ width: "100%", padding: "10px" }}>
        <Combobox
          activator={
            <Combobox.TextField
              prefix={<Icon source={SearchIcon} />}
              label="Select Products"
              labelHidden
              placeholder="Search Products"
              autoComplete="off"
            />
          }
        />
      </div>
      <div
        style={{
          maxHeight: "150px",
          overflowY: "auto",
          width: "100%",
          padding: "0 10px",
        }}
      >
        <OptionList
          title={TagValues.title}
          onChange={setSelected}
          options={TagValues.options}
          selected={selected}
        />
      </div>
    </Popover>
  );
}
