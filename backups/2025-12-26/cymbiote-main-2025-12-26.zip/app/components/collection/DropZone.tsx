import { DropZone, LegacyStack, Button } from "@shopify/polaris";
import { useState, useCallback } from "react";

interface Dropzone {
  files: File[];
  setFiles: (files: File[]) => void;
}

export default function DropZoneExample({ setFiles, files }: Dropzone) {
  const handleDropZoneDrop = useCallback(
    (_dropFiles: File[], acceptedFiles: File[], _rejectedFiles: File[]) => {
      if (acceptedFiles.length > 0) {
        setFiles([acceptedFiles[0]]);
      }
    },
    [setFiles],
  );

  const validImageTypes = [
    "image/gif",
    "image/jpeg",
    "image/png",
    "image/webp",
    "image/heic",
  ];

  const fileUpload = !files.length && (
    <DropZone.FileUpload actionHint="Or drop an Image to Upload" />
  );

  const uploadedFiles = files.length > 0 && (
    <div style={{ margin: "3px" }}>
      <LegacyStack vertical>
        {files.map((file, index) => (
          <div
            key={index}
            style={{
              position: "relative",
              width: "100%",
              height: 200,
              overflow: "hidden",
              borderRadius: 8,
            }}
          >
            <img
              alt={file.name}
              src={
                validImageTypes.includes(file.type)
                  ? window.URL.createObjectURL(file)
                  : ""
              }
              style={{ width: "100%", height: "100%", objectFit: "cover" }}
            />
            <div
              style={{
                position: "absolute",
                top: "50%",
                left: "50%",
                transform: "translate(-50%, -50%)",
                padding: "4px 12px",
              }}
            >
              <Button size="slim" onClick={() => setFiles([])}>
                Change
              </Button>
            </div>
          </div>
        ))}
      </LegacyStack>
    </div>
  );

  return (
    <DropZone onDrop={handleDropZoneDrop} variableHeight>
      {uploadedFiles}
      {fileUpload}
    </DropZone>
  );
}
