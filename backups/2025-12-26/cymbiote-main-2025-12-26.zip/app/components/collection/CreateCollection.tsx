import {
  Page,
  Layout,
  Card,
  Text,
  ChoiceList,
  InlineStack,
} from "@shopify/polaris";
import { useCallback, useEffect, useState } from "react";
import DropZoneExample from "./DropZone";
import SearchModal, { Product } from "./SearchModal";
import CollectionModal, { Collection } from "./CollectionModal";
import FilterCollection, { FilterProductGroup } from "./FilterCollection";
import TrendingCollection, { TrendingProductGroup } from "./TrendingCollection";
import SimpleCollection from "./SimpleCollection";
import { useLocation } from "react-router-dom";

export interface CreateCollection {
  setTitle: (value: string) => void;
  setDescription: (value: string) => void;
  setCollection: (Value: string) => void;
  setSelectedproducts: (products: Product[]) => void;
  setFiles: (value: File[]) => void;
  setselectchoices: (value: number[]) => void;
  setCustomCategory: (value: Product[]) => void;
  setSelectedCollections: (value: Collection[]) => void;
  setFilteredProductsGroup: (value: FilterProductGroup[]) => void;
  setTrendingProductsGroup: (value: TrendingProductGroup[]) => void;

  Title: string;
  Description: string;
  Collection: string;
  selectedproducts: Product[];
  files: File[];
  selectchoices: number[];
  customCategory: Product[];
  selectedCollections: Collection[];
  Collections: any[];
  trendingCollections: any[];
  existingCollections: any[];
  FilteredProductsGroup: FilterProductGroup[];
  TrendingProductsGroup: TrendingProductGroup[];
  mergedData: any[];
  search: any;
}

function CreateCollection({
  files,
  Title,
  setTitle,
  setFiles,
  mergedData,
  Collections,
  Description,
  selectchoices,
  setCollection,
  customCategory,
  setDescription,
  setselectchoices,
  selectedproducts,
  setCustomCategory,
  existingCollections,
  selectedCollections,
  setSelectedproducts,
  trendingCollections,
  FilteredProductsGroup,
  TrendingProductsGroup,
  setSelectedCollections,
  setFilteredProductsGroup,
  setTrendingProductsGroup,
  search,
}: CreateCollection) {
  const domain = window.location.search;
  const location = useLocation();
  const [value, setValue] = useState("Manual");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [products, setProducts] = useState([]);
  const [IsCollectionModalOpen, setIsCollectionModalOpen] = useState(false);
  const [selected, setSelected] = useState<string[]>([""]);
  const [selectedRow, setSelectedRow] = useState(0);
  const [searchValue, setsearchValue] = useState("");
  const [modalSelectedItems, setModalSelectedItems] = useState<Product[]>([]);

  const existingTrending = existingCollections.filter(
    (e) => e.collection_type_id === 2,
  );
  const { some } = location.state || {};
  const choices = [
    { label: "Simple Collection", value: "1" },
    { label: "Trending Collection", value: "2" },
    { label: "Filter Collection", value: "3" },
  ];

  // Map the filtered collections into the required format
  const CollectionImageChoice: any[] = trendingCollections.map(
    (collection) => ({
      label: collection.trending_name,
      value: collection.trending_id.toString(),
    }),
  );

  const handleRadioChange = useCallback(
    (_: boolean, newValue?: string) => {
      const updatedValue = newValue || "Manual";
      setValue(updatedValue);

      setCollection(updatedValue === "Smart Collection" ? "smart" : "custom");
    },
    [setCollection],
  );

  const handleSelectChange = useCallback(
    (selected: string[], _name: string) => {
      const numericValues = selected.map(Number);
      setselectchoices(numericValues);
    },
    [],
  );
  const handleChange = useCallback(
    (selected: string[]) => setSelected(selected),
    [],
  );

  const handleTitleChange = useCallback(
    (newValue: string) => setTitle(newValue),
    [setTitle],
  );

  const handleDescriptionChange = useCallback(
    (newValue: string) => setDescription(newValue),
    [setDescription],
  );

  const fetchProduct = useCallback(async () => {
    try {
      const response = await fetch(`/api/activeproducts${domain}`);
      const data = await response.json();

      setProducts(data || []);
    } catch (error) {
      console.error("Product fetch error:", error);
    }
  }, [domain]);

  const searchProduct = async () => {
    try {
      const response = await fetch(
        `/api/searchProducts?searchQuery=${searchValue}&searchTerm=${search}`,
      );

      if (!response.ok) {
        const text = await response.text();
        console.warn("Non-200 response:", response.status, text);
        return;
      }

      const data = await response.json();
      setProducts(data || []);
    } catch (error) {
      console.log("Error fetching products", error);
    }
  };

  const removeproduct = (id: number) => {
    setModalSelectedItems(
      modalSelectedItems.filter((product) => product.product_id !== id),
    );
  };

  useEffect(() => {
    setSelectedproducts(modalSelectedItems);
  }, [modalSelectedItems]);

  useEffect(() => {
    if (searchValue.trim() === "") {
      fetchProduct();
    } else {
      searchProduct();
    }
  }, [fetchProduct, searchValue]);

  useEffect(() => {
    if (some) {
      if (some === 0) {
        setselectchoices([1]);
      }
      if (some === 1) {
        setselectchoices([2]);
      }
      if (some === 2) {
        setselectchoices([3]);
      }
    }
  }, [some]);

  return (
    <Page fullWidth>
      <Layout>
        <Layout.Section>
          <div style={{ marginBottom: "20px" }}>
            <Card>
              <div style={{ marginBottom: "20px" }}>
                <Text variant="headingLg" as="h2" fontWeight="semibold">
                  Select Collection Type
                </Text>
              </div>
              <InlineStack
                gap={{ xs: "200", sm: "200", md: "300", lg: "400", xl: "500" }}
              >
                {choices.map((choice) => (
                  <div className="radio-button">
                    <Card
                      key={choice.value}
                      padding={"0"}
                      roundedAbove={undefined}
                    >
                      <ChoiceList
                        title=""
                        choices={[choice]}
                        selected={selectchoices.map(String)}
                        onChange={handleSelectChange}
                      />
                    </Card>
                  </div>
                ))}
              </InlineStack>
            </Card>
          </div>

          {selectchoices[0] === 1 ? (
            <SimpleCollection
              handleChange={handleChange}
              handleTitleChange={handleTitleChange}
              handleDescriptionChange={handleDescriptionChange}
              removeproduct={removeproduct}
              handleRadioChange={handleRadioChange}
              setCustomCategory={setCustomCategory}
              setIsModalOpen={setIsModalOpen}
              Title={Title}
              Description={Description}
              selectedproducts={modalSelectedItems}
              value={value}
              customCategory={customCategory}
              selected={selected}
            />
          ) : selectchoices[0] === 2 ? (
            <TrendingCollection
              setIsModalOpen={setIsModalOpen}
              setIsCollectionModalOpen={setIsCollectionModalOpen}
              setSelectedCollections={setSelectedCollections}
              setSelectedproducts={setModalSelectedItems}
              selectedproducts={modalSelectedItems}
              selectedCollections={selectedCollections}
              setTrendingProductsGroup={setTrendingProductsGroup}
              TrendingProductsGroup={TrendingProductsGroup}
              setSelectedRow={setSelectedRow}
              selectedRow={selectedRow}
              removeproduct={removeproduct}
            />
          ) : selectchoices[0] === 3 ? (
            <FilterCollection
              setIsModalOpen={setIsModalOpen}
              selectedproducts={modalSelectedItems}
              setSelectedproducts={setModalSelectedItems}
              setFilteredProductsGroup={setFilteredProductsGroup}
              FilteredProductsGroup={FilteredProductsGroup}
            />
          ) : (
            <></>
          )}
        </Layout.Section>
        <Layout.Section variant="oneThird">
          {(selectchoices[0] === 2 || selectchoices[0] === 1) && (
            <Card>
              <Text variant="headingLg" as="h3" fontWeight="semibold">
                Image
              </Text>
              {selectchoices[0] === 1 ? (
                <div style={{ marginTop: "20px" }}>
                  <DropZoneExample setFiles={setFiles} files={files} />
                </div>
              ) : (
                <div
                  style={{
                    marginTop: "20px",
                    padding: "10px",
                  }}
                >
                  <div
                    style={{
                      display: "flex",
                      flexDirection: "row",
                      alignItems: "center",
                      padding: "20px",
                      gap: "20px",
                      flexWrap: "wrap",
                    }}
                  >
                    <img
                      alt="Collection Image"
                      src={
                        selectedCollections.length > 0 &&
                        selectedCollections[TrendingProductsGroup.length - 1]
                          ?.trending_banner_url
                          ? selectedCollections[
                              TrendingProductsGroup.length - 1
                            ]?.trending_banner_url
                          : "https://cdn.shopify.com/s/files/1/0923/5460/9434/files/dummy-post-square-1-1.jpg?v=1744023232"
                      }
                      style={{
                        borderRadius: "10%",
                        width: "180px",
                        height: "150px",
                        objectFit: "cover",
                        maxWidth: "100%",
                      }}
                    />

                    <div
                      style={{
                        flex: 1,
                        display: "flex",
                        flexDirection: "column",
                        gap: "8px",
                      }}
                    >
                      <Text as="h3" variant="headingLg">
                        View Collection Image
                      </Text>

                      {CollectionImageChoice.length > 0 ? (
                        CollectionImageChoice.map((choice, index) => {
                          return (
                            <div className="radio-button" key={choice.value}>
                              <ChoiceList
                                title=""
                                choices={[choice]}
                                selected={
                                  TrendingProductsGroup.filter(
                                    (e) => e.collection_type === choice.label,
                                  ).length > 0
                                    ? [choice.value]
                                    : []
                                }
                                onChange={(newSelected) => {
                                  const selectedId = newSelected[0];
                                  const selectedCollection =
                                    trendingCollections.find(
                                      (col) =>
                                        col.trending_id.toString() ===
                                        selectedId,
                                    );

                                  if (selectedCollection) {
                                    setSelectedCollections([
                                      selectedCollection,
                                    ]);
                                  }
                                }}
                                disabled={
                                  existingTrending.findIndex(
                                    (e) =>
                                      e.collection_name ===
                                      trendingCollections[index]?.trending_name,
                                  ) > -1
                                }
                              />
                            </div>
                          );
                        })
                      ) : (
                        <Text variant="bodyMd" as="h3" fontWeight="semibold">
                          No Trending Collections Available
                        </Text>
                      )}
                    </div>
                  </div>
                </div>
              )}
            </Card>
          )}
        </Layout.Section>
        <SearchModal
          open={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          products={products}
          selectedproducts={modalSelectedItems}
          setSelectedproducts={setModalSelectedItems}
          search={search}
          setsearchValue={setsearchValue}
          searchValue={searchValue}
        />

        <CollectionModal
          mergedData={mergedData}
          open={IsCollectionModalOpen}
          collection={trendingCollections}
          selectedcollections={selectedCollections}
          existingCollections={existingCollections}
          TrendingProductsGroup={TrendingProductsGroup}
          onClose={() => setIsCollectionModalOpen(false)}
          setselectedcollections={setSelectedCollections}
        />
      </Layout>
    </Page>
  );
}

export default CreateCollection;
