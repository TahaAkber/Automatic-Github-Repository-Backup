import { useEffect, useState } from "react";
import axios from "axios";
import { Avatar } from "@shopify/polaris";
interface ValidImageAvatarProps {
  url?: string;
  fallbackUrl: string;
}
const ValidImageAvatar: React.FC<ValidImageAvatarProps> = ({
  url,
  fallbackUrl,
}) => {
  const [valid, setValid] = useState<boolean | null>(null);

  async function isValidImageUrl(url: string): Promise<boolean> {
    if (!url) return false;
    try {
      const response = await axios.head(url);
      if (response.status !== 200) return false;
      const contentType = response.headers["content-type"] || "";
      return contentType.startsWith("image/");
    } catch {
      return false;
    }
  }

  useEffect(() => {
    let isMounted = true;
    if (!url) {
      setValid(false);
      return;
    }
    (async () => {
      const result = await isValidImageUrl(url);
      if (isMounted) setValid(result);
    })();
    return () => {
      isMounted = false;
    };
  }, [url]);

  if (valid === null) {
    // loading state - show fallback or placeholder
    return <Avatar source={fallbackUrl} />;
  }

  return <Avatar source={valid ? url : fallbackUrl} />;
};

export default ValidImageAvatar;
