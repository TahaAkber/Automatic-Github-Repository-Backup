import { json } from "@remix-run/node";
import { retryOperation } from "~/functions/common";

export const createCollection = async (admin: any, input: any) => {
  try {
    const mutationQuery = `mutation CollectionCreate($input: CollectionInput!) {
      collectionCreate(input: $input) {
        collection {
          id
          title
          descriptionHtml
          updatedAt
          handle
          image {
            id
            height
            width
            url
          }
          products(first: 100) {
            nodes {
              id
              featuredImage {
                id
                height
                width
                url
              }
            }
          }
        }
        userErrors {
          field
          message
        }
      }
    }
  `;
    const variables = {
      input,
    };

    console.log("collection variables", variables);
    const createcollection = await admin.graphql(mutationQuery, {
      variables,
    });
    const parsedData = await createcollection.json();

    console.log(
      "New Collection Response",
      parsedData?.data?.collectionCreate?.collection,
    );
    return json({
      result: parsedData?.data?.collectionCreate?.collection,
      success: true,
    });
  } catch (e: any) {
    return json({
      success: false,
      result: e.message,
    });
  }
};
export const removeCollection = async (admin: any, rawShopifyIds: string) => {
  try {
    const shopifyIds = rawShopifyIds.split(",").map((id) => id.trim());

    console.log("✅ Processed Shopify IDs:", shopifyIds);

    if (!shopifyIds.length) {
      console.error("❌ No valid Shopify IDs found!");
      return;
    }

    const removequery = `mutation collectionDelete($input: CollectionDeleteInput!) {
      collectionDelete(input: $input) {
        deletedCollectionId
        shop {
          id
          name
        }
        userErrors {
          field
          message
        }
      }
    }`;

    const deletionPromises = shopifyIds.map(async (id) => {
      const variables = { input: { id } };

      try {
        const response = await admin.graphql(removequery, { variables });

        if (response.errors) {
          console.error("GraphQL Error:", response.errors);
        }
        if (response.data?.collectionDelete?.userErrors?.length > 0) {
          console.error(
            "Shopify User Errors:",
            response.data.collectionDelete.userErrors,
          );
        }

        return response;
      } catch (error) {
        console.error("API Fetch Error for", id, ":", error);
      }
    });

    const results = await Promise.all(deletionPromises);
    return results;
  } catch (e) {
    console.error("Error deleting collections:", e);
  }
};

export const addShopifyCollectiontoDatabase = async (
  admin: any,
  rawShopifyIds: string,
  shop: any,
) => {
  try {
    // Parse the Shopify IDs (assuming it's a comma-separated string)
    const shopifyIds = rawShopifyIds.split(",").map((id) => id.trim());

    const shopifyCollections = `
    query GetCollection($id: ID!) {
      collection(id: $id) {
      id
      title
      handle
      descriptionHtml
      updatedAt
      description
      products(first: 100) {
        nodes {
          id
        }
      }
      productsCount {
        count
      }
      sortOrder
      image {
        url
        height
        width
      }
     }
    }
    `;
    const collectionPromises = shopifyIds.map(async (id: string) => {
      const variables = { id };
      try {
        // Fetch collection details from Shopify using GraphQL
        const response = await admin.graphql(shopifyCollections, { variables });

        if (response.errors) {
          console.error("GraphQL Error:", response.errors);
          return;
        }

        const collectionData = await response.json();

        const { title, image, description, productsCount, products } =
          collectionData?.data?.collection;
        const imageSrc = image?.url || "";

        const createSimpleCollection = await retryOperation(async () => {
          return await prisma.collections.create({
            data: {
              collection_shop_id: shop?.shop_id as number,
              collection_type_id: 1,
              collection_name: title,
              collection_shopify_id: id,
              collection_condition: description ?? "",
              collection_is_shopify: true,
              collection_banner_url: imageSrc ?? null,
              collection_product_count: productsCount?.count,
              created_at: new Date(),
            },
          });
        });

        const createFilterCollection = await retryOperation(async () => {
          return await prisma.collections.create({
            data: {
              collection_shop_id: shop?.shop_id as number,
              collection_type_id: 3,
              collection_name: title,
              collection_shopify_id: id,
              collection_condition: description ?? "",
              collection_is_shopify: true,
              collection_banner_url: imageSrc ?? null,
              collection_product_count: productsCount?.count,
              created_at: new Date(),
            },
          });
        });

        if (products.nodes.length > 0) {
          const shopifyIds = products.nodes.map((product: any) => product.id);

          const dbProducts = await retryOperation(async () => {
            return await prisma.products.findMany({
              where: {
                product_shopify_id: {
                  in: shopifyIds,
                },
              },
            });
          });
          const validproductid = new Set(
            dbProducts?.map((p: any) => p.product_id),
          );

          // Only proceed if collection_id is defined
          if (
            typeof createSimpleCollection?.collection_id !== "number" ||
            typeof createFilterCollection?.collection_id !== "number"
          ) {
            throw new Error(
              "Collection ID is undefined for one of the collections.",
            );
          }

          const insertPromisesForSimpleCollection = dbProducts?.map(
            (product: any) =>
              prisma.collection_Products.create({
                data: {
                  collection_product_name: product.product_name,
                  collection_id: createSimpleCollection.collection_id,
                  collection_local_product_id: product.product_id,
                },
              }),
          );

          const insertPromisesForFilterCollection = dbProducts?.map(
            (product: any) =>
              prisma.collection_Products.create({
                data: {
                  collection_product_name: product.product_name,
                  collection_id: createFilterCollection.collection_id,
                  collection_local_product_id: product.product_id,
                },
              }),
          );

          const allInsertPromises = [
            ...(insertPromisesForSimpleCollection ?? []),
            ...(insertPromisesForFilterCollection ?? []),
          ];

          if (allInsertPromises.length > 0) {
            await Promise.all(allInsertPromises);
            console.log(
              `Inserted ${allInsertPromises.length} products into both collections.`,
            );
          } else {
            console.warn("No matching products to insert.");
          }
        } else {
          console.warn("No productNodes found in collection.");
        }
      } catch (error: any) {
        console.error(
          "Error fetching collection data for Shopify ID:",
          id,
          error,
        );
      }
    });

    const results = await Promise.all(collectionPromises);
    return results;
  } catch (error: any) {
    console.error("Error adding collection", error);
  }
};
