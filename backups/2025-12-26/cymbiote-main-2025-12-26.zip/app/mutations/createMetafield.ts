import { AdminApiContext } from "@shopify/shopify-app-remix/server";
import { fetchExistingMetafield } from "~/queries/metafields";

const APP_NAME = process.env.APP_NAME;

export async function createMetafieldDefinition(
  admin: any,
  metaobjectId: string,
) {
  console.log("creating custom_category metafield", metaobjectId);
  try {
    const metafieldKey = `${APP_NAME?.toLowerCase()}_product_category`;
    const metafieldNamespace = "$app:custom_category";
    const metafieldName = `${APP_NAME} Product Category`;
    const mutation = `
    mutation {
      metafieldDefinitionCreate(
        definition: {
          name: "${metafieldName}", 
          namespace: "${metafieldNamespace}", 
          key: "${metafieldKey}", 
          description: "Assigns a product taxonomy category", 
          ownerType: PRODUCT, 
          type: "metaobject_reference", 
          validations: {
            name: "metaobject_definition_id", 
            value: "${metaobjectId}"
          }, 
          capabilities: {
            smartCollectionCondition: {
              enabled: true
            }, 
            adminFilterable: {
              enabled: true
            }
          }, 
          access: {
            admin: MERCHANT_READ_WRITE, 
            storefront: NONE
          }, 
          pin: true
        }
      ) {
        createdDefinition {
          id
          name
          namespace
          key
          type {
            category
            name
          }
          ownerType
          validations {
            name
            type
            value
          }
        }
        userErrors {
          field
          message
        }
      }
    }
  `;

    const response = await admin.graphql(mutation);
    const result = await response.json();

    if (result.data.metafieldDefinitionCreate.userErrors.length) {
      console.log(
        "error in creating metafield",
        result.data.metafieldDefinitionCreate,
      );
      const error = result.data.metafieldDefinitionCreate.userErrors[0];
      if (error.message.includes("Key is in use for Product metafields")) {
        // If the key already exists, fetch the existing metafield definition
        console.log(
          "Metafield definition already exists. Fetching the existing one...",
        );

        const existingMetafield = await fetchExistingMetafield(
          "PRODUCT",
          metafieldName,
          admin,
        );

        if (existingMetafield) {
          return existingMetafield;
        }
      }
    }
    console.log("Cercle Product Category Metafield Created");
    return result.data.metafieldDefinitionCreate?.createdDefinition || {};
  } catch (error: any) {
    throw new Error("Error creating metafield definition: " + error.message);
  }
}

export const createMetafieldDefinitionForVariants = async (
  admin: any,
  shop_id: number,
) => {
  const query = `
    mutation CreateMetafieldDefinition($definition: MetafieldDefinitionInput!) {
      metafieldDefinitionCreate(definition: $definition) {
        createdDefinition {
          id
          name
        }
        userErrors {
          field
          message
          code
        }
      }
    }
  `;

  const variables = {
    definition: {
      name: "Cercle Discount", // Name of the metafield
      namespace: "$app:custom_discount", // Namespace with $app (or any specific namespace)
      key: "cercle_discount", // The key of the metafield
      description: "A discount applied to the product variant.", // Description
      type: "single_line_text_field", // Type of the metafield (single line text)
      ownerType: "PRODUCTVARIANT", // Applies to product variants
      access: {
        admin: "MERCHANT_READ_WRITE", // Access level for the admin
      },
      pin: true, // Pinning the metafield, making it non-deletable by the merchant
    },
  };

  try {
    const response = await admin.graphql(query, {
      variables,
    });
    const result = await response.json();

    const { userErrors, createdDefinition } =
      result.data.metafieldDefinitionCreate;

    if (userErrors.length) {
      // Handle any errors returned by the GraphQL mutation
      if (
        userErrors[0].message.includes(
          "Key is in use for ProductVariant metafields",
        )
      ) {
        // If the key already exists, fetch the existing metafield definition
        console.log(
          "Metafield definition already exists. Fetching the existing one...",
        );

        const existingMetafield = await fetchExistingMetafield(
          "PRODUCTVARIANT",
          variables.definition.name,
          admin,
        );
        console.log("variant discount existingMetafield", existingMetafield);

        if (existingMetafield) {
          console.log("Updating existing variant discount metafield id");
          await prisma.shops.update({
            where: {
              shop_id: shop_id,
            },
            data: {
              shop_variant_discount_metafield_id: existingMetafield.id, // Save the metafield ID to the shop record
            },
          });
          return existingMetafield;
        }
      }
      console.error(
        "Error creating variants discount metafield definition:",
        userErrors,
      );
    }

    console.log("variant discount createdDefinition", createdDefinition);

    await prisma.shops.update({
      where: {
        shop_id: shop_id,
      },
      data: {
        shop_variant_discount_metafield_id: createdDefinition.id, // Save the metafield ID to the shop record
      },
    });

    console.log("Metafield(Cercle Discount) definition created successfully:");
    return createdDefinition;
  } catch (error: any) {
    console.error("Error in createMetafieldDefinitionForVariants:", error);
    throw new Error(
      `Failed to create(Cercle Discount) metafield: ${error.message}`,
    );
  }
};

export const deleteMetafieldDefinition = async (
  id: string,
  deleteAllAssociatedMetafields: boolean,
  metaNamespace: {
    ownerType: string;
    namespace: string;
    key: string;
  },
  admin: AdminApiContext,
) => {
  const deleteMutation = `
    mutation DeleteMetafieldDefinition(
      $id: ID!,
      $deleteAllAssociatedMetafields: Boolean!,
      $metaNamespace: MetafieldDefinitionIdentifierInput
    ) {
      metafieldDefinitionDelete(
        id: $id,
        deleteAllAssociatedMetafields: $deleteAllAssociatedMetafields,
        identifier: $metaNamespace
      ) {
        deletedDefinitionId
        userErrors {
          field
          message
          code
        }
      }
    }
  `;

  const variables = {
    id,
    deleteAllAssociatedMetafields,
    metaNamespace,
  };

  const deleteResponse = await admin.graphql(deleteMutation, { variables });
  const result = await deleteResponse.json();

  const userErrors = result?.data?.metafieldDefinitionDelete?.userErrors || [];

  if (userErrors.length > 0) {
    console.error("User errors:", userErrors);
    return { success: false, errors: userErrors };
  }

  console.log(
    "Deleted metafield definition:",
    result?.data?.metafieldDefinitionDelete?.deletedDefinitionId,
  );
  return {
    success: true,
    deletedDefinitionId:
      result?.data?.metafieldDefinitionDelete?.deletedDefinitionId,
  };
};
