export async function createMetaobjectEntry(
  admin: any,
  categoryName: string,
  categoryPath: string,
  metaobjectKey: string,
) {
  const mutation = `
      mutation {
        metaobjectCreate(
          metaobject: {
            type: "${metaobjectKey}",
            fields: [
              { key: "category_name", value: "${categoryName}" },
              { key: "category_path", value: "${categoryPath}" }
            ]
          }
        ) {
          metaobject {
            id
            fields {
              key
              value
            }
          }
          userErrors {
            field
            message
          }
        }
      }
    `;

  const response = await admin.graphql(mutation);
  const result = await response.json();

  // Check if there are any user errors returned from the GraphQL response
  if (result.data.metaobjectCreate.userErrors.length) {
    console.error(
      `Error creating metaobject entry for ${categoryName}:`,
      result.data.metaobjectCreate.userErrors,
    );
  } else {
    console.log(`Metaobject entry created successfully for ${categoryName}`);
  }
}
