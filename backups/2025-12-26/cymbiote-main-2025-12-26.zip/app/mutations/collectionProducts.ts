import { json } from "@remix-run/node";
import { retryOperation } from "~/functions/common";

export const removeProducts = async (
  admin: any,
  collectionId: string,
  collectionWithProducts: any,
) => {
  try {
    // Step 1: Query all product IDs in the collection
    const query = `
        query GetCollectionProducts($id: ID!) {
          collection(id: $id) {
            products(first: 100) {
              nodes {
                id
              }
            }
          }
        }
      `;

    const fetchResponse = await admin.graphql(query, {
      variables: { id: collectionId },
    });

    const data = await fetchResponse.json();
    const existingProductIds =
      data?.data?.collection?.products?.nodes?.map((node: any) => node.id) ||
      [];

    console.log("Existing product IDs to remove:", existingProductIds);

    // Step 2: Remove all products if any exist
    if (existingProductIds.length > 0) {
      const mutationQuery = `
          mutation RemoveFromCollection($id: ID!, $productIds: [ID!]!) {
            collectionRemoveProducts(id: $id, productIds: $productIds) {
              job {
                done
                id
              }
              userErrors {
                field
                message
              }
            }
          }
        `;

      const removeResponse = await admin.graphql(mutationQuery, {
        variables: {
          id: collectionId,
          productIds: existingProductIds,
        },
      });

      const removed = await removeResponse.json();
      console.log("Remove Products Response:", removed);

      await retryOperation(async () => {
        return await prisma.collection_Products.deleteMany({
          where: {
            collection_id: collectionWithProducts?.collection_id,
          },
        });
      });

      return removed;
    } else {
      console.log("No products to remove.");
      return { message: "Collection already empty." };
    }
  } catch (error: any) {
    console.error("Error in removeProducts:", error.message);
    return {
      success: false,
      result: error.message,
    };
  }
};

export const addProducts = async (
  admin: any,
  input: {
    id: string;
    productIds: string[];
    title: string;
    description: string;
    imageSrc: string;
  },
  parsedProducts: any[],
  collectionWithProducts: any,
) => {
  try {
    const updateMutation = `
     mutation collectionUpdate($input: CollectionInput!) {
      collectionUpdate(input: $input) {
        collection {
          id
          title
          descriptionHtml
          image {
            url
            altText
          }
        }
        userErrors {
          field
          message
        }
      }
    }
  `;

    const updateVariables = {
      input: {
        id: input.id,
        title: input.title,
        descriptionHtml: input.description, 

        image: input.imageSrc
          ? {
              src: input.imageSrc, 
              altText: "Image", 
            }
          : undefined, 
      },
    };

    const updateResponse = await admin.graphql(updateMutation, {
      variables: updateVariables,
    });

    const updateJson = await updateResponse.json();
    console.log("Shopify Title/Description Update Response:", updateJson);

    if (updateJson?.data?.collectionUpdate?.userErrors?.length > 0) {
      console.warn(
        "Shopify collection update userErrors:",
        updateJson.data.collectionUpdate.userErrors,
      );
    }

    const mutationQuery = `mutation collectionAddProducts($id: ID!, $productIds: [ID!]!) {
      collectionAddProducts(id: $id, productIds: $productIds) {
        collection {
          id
          title
          products(first: 10) {
            nodes {
              id
              title
            }
          }
        }
        userErrors {
          field
          message
        }
      }
    }`;

    const variables = {
      id: input.id,
      productIds: input.productIds,
    };
    console.log("collection variables", variables);

    const addProducts = await admin.graphql(mutationQuery, { variables });
    const products = await addProducts.json();

    console.log("New Collection Response", products?.data);

    const { count } = await prisma.collection_Products.createMany({
      data: parsedProducts.map((product: any) => ({
        collection_product_name: product.product_name,
        collection_id: collectionWithProducts?.collection_id,
        collection_local_product_id: product.product_id,
      })),
    });

    console.log("productCount", count);

    await retryOperation(async () => {
      return await prisma.collections.update({
        where: {
          collection_id: collectionWithProducts?.collection_id,
        },
        data: {
          collection_product_count: count,
        },
      });
    });

    return products;
  } catch (error: any) {
    return json({
      success: false,
      result: error.message,
    });
  }
};
