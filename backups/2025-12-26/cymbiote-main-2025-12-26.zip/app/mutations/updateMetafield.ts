// Function to update the metafield with the discount value
export const setDiscountValueInMetafield = async (
  variantShopifyId: string,
  discountValue: string | number,
  admin: any,
) => {
  const mutation = `
    mutation MetafieldsSet {
        metafieldsSet(
            metafields: [
                {
                    ownerId: "${variantShopifyId}", 
                    namespace: "$app:custom_discount", 
                    key: "cercle_discount", 
                    value: "${discountValue}", 
                    type: "single_line_text_field"
                }
            ]
        ) {
            metafields {
                key
                namespace
                value
                createdAt
                updatedAt
            }
            userErrors {
                field
                message
                code
            }
        }
    }
  `;

  try {
    const response = await admin.graphql(mutation);
    const result = await response.json();

    // Log response data and check if the metafield was updated
    const { metafields } = result.data.metafieldsSet;

    console.log("Metafield Updated:", metafields);
    console.log("data:", variantShopifyId, discountValue);
    return metafields;
  } catch (error: any) {
    console.error("Error updating metafield with discount value:", error);
    throw new Error(
      `Failed to update metafield for variant ${variantShopifyId}`,
    );
  }
};
