import { Prisma, PrismaClient } from "@prisma/client";
import { DefaultArgs } from "@prisma/client/runtime/library";
import { json } from "@remix-run/node";
import { AdminApiContext } from "@shopify/shopify-app-remix/server";

export const createAppSubscription = async (
  admin: any,
  prisma: PrismaClient<Prisma.PrismaClientOptions, never, DefaultArgs>,
  shopDomain: string,
  packageName: string,
  packagePrice: string,
  packageRate: string,
  packageId: string,
  firstTime: boolean = true,
  tileType: string = "",
  tileId?: string,
  trackingEnabled?: boolean,
  trialDays: number = 0,
  testPayment: boolean = true,
  extraQuota: number = 0,
  extraCharges: number = 0,
): Promise<any> => {
  try {
    const shop = await prisma.shops.findFirst({
      where: { shop_domain: shopDomain },
    });

    const mutationQuery = `#graphql
      mutation AppSubscriptionCreate(
        $name: String!,
        $lineItems: [AppSubscriptionLineItemInput!]!,
        $returnUrl: URL!,
        $test: Boolean,
        $trialDays: Int,
        $replaceBehavior: AppSubscriptionReplacementBehavior
      ) {
        appSubscriptionCreate(
          name: $name,
          returnUrl: $returnUrl,
          lineItems: $lineItems,
          test: $test,
          trialDays: $trialDays,
          replacementBehavior: $replaceBehavior
        ) {
          appSubscription {
            id
            currentPeriodEnd
            lineItems { id plan { pricingDetails { __typename } } }
            name
            returnUrl
            status
            test
            trialDays
            createdAt
          }
          confirmationUrl
          userErrors { field message }
        }
      }`;

    // --- 1️⃣ Fetch app title ---
    const appInfo = await admin.graphql(
      `query { currentAppInstallation { app { title } } }`,
    );
    const infoJson = await appInfo.json();
    const appTitle =
      infoJson.data?.currentAppInstallation?.app?.title || "cymbiote";

    let returnUrl = `https://${shopDomain}/admin/apps/${appTitle.toLowerCase()}/app/packages`;
    if (tileType) {
      returnUrl = `https://${shopDomain}/admin/apps/${appTitle.toLowerCase()}/customizer?tileTypeId=${encodeURIComponent(
        tileId as string,
      )}&redirectAgain=true`;
    }
    if (trackingEnabled !== undefined) {
      returnUrl = `https://${shopDomain}/admin/apps/${appTitle.toLowerCase()}/settings?subscription=${trackingEnabled ? "start" : "remove"}`;
    }

    if (!shop) {
      throw new Error(`Shop not found for domain: ${shopDomain}`);
    }

    console.log(
      "value of the value",
      parseInt(tileId as string),
      shop.shop_tile_type,
    );

    const shop_tile_id =
      parseInt(tileId as string) || (shop?.shop_tile_type as number) || 0;

    // --- 2️⃣ Prepare prices ---
    const trackingCharges = await prisma.admin_Settings.findFirst();
    const tileChargesEntry = await prisma.shop_Tiles.findFirst({
      where: {
        shop_tile_id,
      },
    });
    const tileCharges = tileChargesEntry?.shop_tile_charges || 0;
    const basePrice = parseFloat(packagePrice) || 0;
    const totalRecurringPrice =
      basePrice +
      extraCharges +
      (trackingEnabled
        ? (trackingCharges?.admin_tracking_sub_charges as number)
        : shop.shop_active_tracking && trackingEnabled !== false
          ? (trackingCharges?.admin_tracking_sub_charges as number)
          : 0) +
      (tileCharges || 0);

    console.log(
      "Combined recurring price (USD):",
      totalRecurringPrice,
      basePrice,
      trackingCharges?.admin_tracking_sub_charges,
      tileCharges,
    );

    const lineItems = [
      {
        plan: {
          appUsagePricingDetails: {
            cappedAmount: { amount: "5000.00", currencyCode: "USD" },
            terms: `We charge a ${packageRate}% fee on every order placed through our sales channel.`,
          },
        },
      },
      {
        plan: {
          appRecurringPricingDetails: {
            price: {
              amount: totalRecurringPrice.toFixed(2),
              currencyCode: "USD",
            },
            interval: "EVERY_30_DAYS",
          },
        },
      },
    ];

    const variables = {
      name: packageName,
      returnUrl,
      lineItems,
      test: testPayment,
      trialDays,
      replaceBehavior: firstTime
        ? "APPLY_IMMEDIATELY"
        : "APPLY_ON_NEXT_BILLING_CYCLE",
    };

    console.log("🧾 Subscription variables:", variables);

    // --- 3️⃣ Send mutation ---
    const res = await admin.graphql(mutationQuery, { variables });
    const data = await res.json();

    if (!data?.data?.appSubscriptionCreate) {
      throw new Error("Invalid response from Shopify API");
    }

    const createRes = data.data.appSubscriptionCreate;
    if (createRes.userErrors?.length) {
      console.error("❌ Shopify errors:", createRes.userErrors);
      throw new Error(
        createRes.userErrors.map((e: any) => e.message).join(", "),
      );
    }

    const sub = createRes.appSubscription;
    const { lineItems: lines, currentPeriodEnd } = sub;
    const fullId = sub.id;
    const extractedId = fullId.match(/\d+$/)?.[0] || null;

    // --- 4️⃣ Prisma database handling ---
    try {
      if (!shop) {
        console.warn(`⚠️ Shop not found for domain: ${shopDomain}`);
        return { confirmationUrl: createRes.confirmationUrl };
      }

      const packageDetails = await prisma.packages.findUnique({
        where: { package_id: parseInt(packageId) },
      });

      const newSub = await prisma.subscriptions.create({
        data: {
          subscription_confirmed: false,
          subscription_enabled: false,
          subscription_confirmation_id: extractedId,
          subscription_package_charges: basePrice,
          subscription_tile_charges: tileCharges,
          subscription_tracking_active:
            (trackingEnabled as boolean) || shop.shop_active_tracking,
          subscription_tracking_charges:
            (trackingEnabled as boolean) || shop.shop_active_tracking
              ? (trackingCharges?.admin_tracking_sub_charges as number)
              : 0,
          subscription_videos_quota:
            (packageDetails?.package_video_count || 0) + extraQuota,
          subscription_ends_at: currentPeriodEnd || new Date(),
          subscription_appRecurringPricingDetails_id: lines[0]?.id || "",
          subscription_appUsagePricingDetails_id:
            lines.length > 1 ? lines[1].id : lines[0].id,
          subscription_url: createRes.confirmationUrl,
          subscription_extra_video_charges: extraCharges,
          Packages: { connect: { package_id: parseInt(packageId) } },
          Shops: { connect: { shop_id: shop.shop_id } },
          Shop_Tiles: {
            connect: { shop_tile_id: shop_tile_id },
          },
        },
      });

      console.log("✅ New subscription created:", newSub);
    } catch (dbError) {
      console.error("⚠️ Prisma DB Error:", dbError);
      // Don't throw here — return confirmation URL anyway
    }

    // --- 5️⃣ Return confirmation URL for Shopify redirect ---
    return { confirmationUrl: createRes.confirmationUrl };
  } catch (error: any) {
    console.error("🚨 Error in createAppSubscription:", error.message || error);
    return {
      error: true,
      message: error.message || "Unknown error while creating subscription",
    };
  }
};

export const createTrackingSubscription = async (
  admin: AdminApiContext,
  shopDomain: string,
  subCharges: number,
  testPayment: boolean = true,
) => {
  const mutationQuery = `#graphql
    mutation AppPurchaseOneTimeCreate($name: String!, $price: MoneyInput!, $returnUrl: URL!, $test: Boolean) {
      appPurchaseOneTimeCreate(
        name: $name
        returnUrl: $returnUrl
        price: $price
        test: $test
      ) {
        userErrors {
          field
          message
        }
        appPurchaseOneTime {
          createdAt
          id
          name
          status
          price{
            amount
            currencyCode
          }
        }
        confirmationUrl
      }
    }
  `;

  const query = `
      query {
        currentAppInstallation {
          app {
            title
          }
        }
      }
    `;

  try {
    const appInstallationResponse = await admin.graphql(query);
    const result = await appInstallationResponse.json();

    const appTitle =
      result.data?.currentAppInstallation?.app?.title || "cymbiote";

    const url = `http://${shopDomain}/admin/apps/${appTitle.toLowerCase()}/settings`;
    const variables = {
      name: appTitle + " Tracking Subscription ",
      returnUrl: url,
      price: {
        amount: subCharges,
        currencyCode: "USD",
      },
      test: true,
    };

    const response = await admin.graphql(mutationQuery, {
      variables,
    });

    const subscriptionResponse = await response.json();

    console.log("Tracking subscription", variables, subscriptionResponse.data);

    if (subscriptionResponse.data) {
      const appPurchaseOneTimeCreate =
        subscriptionResponse.data?.appPurchaseOneTimeCreate;

      if (appPurchaseOneTimeCreate) {
        if (
          subscriptionResponse.data.appPurchaseOneTimeCreate.userErrors.length >
          0
        ) {
          console.log(
            "subscriptionResponse.data.appPurchaseOneTimeCreate.userErrors",
            subscriptionResponse.data.appPurchaseOneTimeCreate.userErrors,
          );
          return new Response("Error creating subscription", {
            status: 500,
            statusText:
              subscriptionResponse.data.appSubscriptionCreate.userErrors[0].toString(),
          });
        }
        return {
          ...appPurchaseOneTimeCreate.appPurchaseOneTime,
          confirmationUrl: appPurchaseOneTimeCreate.confirmationUrl,
        };
      }
    }
  } catch (error) {
    throw new Error("Error creating new one time subscription");
  }
};

export const ShopResourceFeedbackCreate = async (
  admin: AdminApiContext,
  input: any,
) => {
  const query = `mutation ShopResourceFeedbackCreate($input: ResourceFeedbackCreateInput!) {
    shopResourceFeedbackCreate(input: $input) {
      feedback {
        messages {
          message
        }
        feedbackGeneratedAt
        state
      }
      userErrors {
        field
        message
      }
    }
  }`;

  const variables = {
    input,
  };
  const response = await admin.graphql(query, {
    variables,
  });
  const shopResourceFeedbackCreateResponse = await response.json();
  return shopResourceFeedbackCreateResponse.data;
};

export const createOneTimeVideoCharge = async (
  admin: AdminApiContext,
  shopDomain: string,
  amount: number,
  quota: number,
  testPayment: boolean = true,
) => {
  const mutationQuery = `#graphql
    mutation AppPurchaseOneTimeCreate($name: String!, $price: MoneyInput!, $returnUrl: URL!, $test: Boolean) {
      appPurchaseOneTimeCreate(
        name: $name
        returnUrl: $returnUrl
        price: $price
        test: $test
      ) {
        userErrors {
          field
          message
        }
        appPurchaseOneTime {
          createdAt
          id
          name
          status
          price{
            amount
            currencyCode
          }
        }
        confirmationUrl
      }
    }
  `;

  const query = `
      query {
        currentAppInstallation {
          app {
            title
          }
        }
      }
    `;

  try {
    const appInstallationResponse = await admin.graphql(query);
    const result = await appInstallationResponse.json();

    const appTitle =
      result.data?.currentAppInstallation?.app?.title || "cymbiote";

    const url = `https://${shopDomain}/admin/apps/${appTitle.toLowerCase()}/app/packages?video_topup=true&quota=${quota}&amount=${amount}`;

    const variables = {
      name: `${quota} Extra Reels/Stories`,
      returnUrl: url,
      price: {
        amount: amount,
        currencyCode: "USD",
      },
      test: testPayment,
    };

    const response = await admin.graphql(mutationQuery, {
      variables,
    });

    const subscriptionResponse = await response.json();

    console.log(
      "Video top-up subscription",
      variables,
      subscriptionResponse.data,
    );

    if (subscriptionResponse.data) {
      const appPurchaseOneTimeCreate =
        subscriptionResponse.data?.appPurchaseOneTimeCreate;

      if (appPurchaseOneTimeCreate) {
        if (appPurchaseOneTimeCreate.userErrors.length > 0) {
          console.log(
            "appPurchaseOneTimeCreate.userErrors",
            appPurchaseOneTimeCreate.userErrors,
          );
          return {
            error: true,
            message: appPurchaseOneTimeCreate.userErrors
              .map((e: any) => e.message)
              .join(", "),
          };
        }
        return {
          ...appPurchaseOneTimeCreate.appPurchaseOneTime,
          confirmationUrl: appPurchaseOneTimeCreate.confirmationUrl,
        };
      }
    }
    return { error: true, message: "Failed to create one-time charge" };
  } catch (error: any) {
    console.error("Error creating one-time video charge:", error);
    return { error: true, message: error.message || "Unknown error" };
  }
};
