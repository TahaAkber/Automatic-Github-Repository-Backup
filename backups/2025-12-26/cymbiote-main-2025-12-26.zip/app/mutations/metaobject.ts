import { AdminApiContext } from "@shopify/shopify-app-remix/server";

const APP_NAME = process.env.APP_NAME;

export async function createMetaobjectDefinition(
  admin: AdminApiContext,
  level = 0,
) {
  const type = `$app:${APP_NAME?.toLowerCase()}_taxonomies`; // Type of the metaobject definition
  const name = `${APP_NAME?.toUpperCase()} Taxonomies`;
  const createMutation = `
    mutation {
      metaobjectDefinitionCreate(
        definition: {
          type: "${type}"
          name: "${name}"
          displayNameKey: "category_name"
          fieldDefinitions: [
            { name: "Category Name", key: "category_name", type: "single_line_text_field" }
            { name: "Category Path", key: "category_path", type: "single_line_text_field" }
          ]
          access: {
            admin: MERCHANT_READ
            storefront: NONE
          }
        }
      ) {
        metaobjectDefinition {
          id
          type
          displayNameKey
          name
        }
        userErrors {
          field
          message
        }
      }
    }
  `;

  try {
    // Attempt to create the metaobject definition
    const response = await admin.graphql(createMutation);
    const result = await response.json();

    // If there are user errors, handle the case where the definition already exists
    if (result.data.metaobjectDefinitionCreate.userErrors.length) {
      const error = result.data.metaobjectDefinitionCreate.userErrors[0];

      if (error.message === "Type has already been taken") {
        // If the type already exists, fetch the list of metaobject definitions
        console.log(
          "Metaobject definition already exists. Fetching the existing one...",
        );

        const fetchQuery = `
          query {
            metaobjectDefinitions(first: 250) {
              edges {
                node {
                  id
                  type
                  metaobjectsCount
                  displayNameKey
                  name
                }
              }
            }
          }
        `;

        const fetchResponse = await admin.graphql(fetchQuery);
        const fetchResult = await fetchResponse.json();

        // Filter the fetched metaobjects by name

        console.log(
          "metaobjectDefinitions",
          fetchResult.data.metaobjectDefinitions.edges,
        );

        console.log("metaobject name", name);

        const existingMetaobject =
          fetchResult.data.metaobjectDefinitions.edges.find(
            (edge: any) => edge.node.name.toLowerCase() === name.toLowerCase(),
          );

        if (existingMetaobject) {
          console.log(
            "Found existing Cercle Taxonomies metaobject definition:",
          );
          if (existingMetaobject.node.metaobjectsCount !== 5595) {
            console.log("found issue in current metaobject count");
            const deleteMetaobject = await deleteMetaobjectDefinition(
              admin,
              existingMetaobject.node.id,
            );

            if (deleteMetaobject && level === 0) {
              console.log("recreating metaobject definition");
              return await createMetaobjectDefinition(admin, 1); // proving level 1 to stop recursion
            }
          }
          return existingMetaobject.node; // Return the found metaobject definition
        } else {
          throw new Error(
            "Metaobject definition 'Cercle Taxonomies' not found.",
          );
        }
      }
      // If error is not "Type has already been taken", throw error
      else {
        throw new Error(error.message);
      }
    }

    // If no errors, return the created metaobject definition
    console.log(
      "Metaobject(Cercle Taxonomies) definition created successfully:",
    );
    return result.data.metaobjectDefinitionCreate.metaobjectDefinition;
  } catch (error: any) {
    console.error(
      "Error handling metaobject(Cercle Taxonomies) creation:",
      error.message,
    );
    throw new Error(
      "Error metaobject(Cercle Taxonomies) creation: " + error.message,
    );
  }
}

export async function deleteMetaobjectDefinition(
  admin: AdminApiContext,
  metaobjectDefinitionId: string,
): Promise<boolean> {
  console.log("deleting metaobject definition");
  const mutation = `
    mutation {
      metaobjectDefinitionDelete(id: "${metaobjectDefinitionId}") {
        deletedId
        userErrors {
          field
          message
        }
      }
    }
  `;

  try {
    const response = await admin.graphql(mutation);
    const responseJson = await response.json();

    const result = responseJson.data.metaobjectDefinitionDelete;

    if (result.userErrors.length > 0) {
      console.error("Error deleting metaobject definition:", result.userErrors);
      return false;
    } else {
      console.log("Metaobject definition deleted successfully");
      return true;
    }
  } catch (error: any) {
    console.error("Error in deleting metaobject definition:", error.message);
    throw new Error("Failed to delete metaobject definition");
  }
}
