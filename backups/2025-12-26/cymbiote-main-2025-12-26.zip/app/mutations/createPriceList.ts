import { AdminApiContext } from "@shopify/shopify-app-remix/server";
import { PriceListInput } from "~/types/PriceList/PriceListInput";

export const createPriceList = async (
  admin: AdminApiContext,
  input: PriceListInput,
): Promise<any> => {
  const priceListMutation = `
      mutation PriceListCreate($input: PriceListCreateInput!) {
        priceListCreate(input: $input) {
          userErrors {
            field
            message
          }
          priceList {
            id
            name
            currency
            parent {
              adjustment {
                type
                value
              }
            }
          }
        }
      }
    `;

  const responsePriceListCreate = await admin.graphql(priceListMutation, {
    variables: {
      input,
    },
  });

  const result = await responsePriceListCreate.json();

  if (result.data.priceListCreate.userErrors.length > 0) {
    throw new Error(
      result.data.priceListCreate.userErrors.map(
        (error: { field: string; message: string }) =>
          `${error.field}: ${error.message}`,
      ),
    );
  }

  return result.data.priceListCreate.priceList;
};
