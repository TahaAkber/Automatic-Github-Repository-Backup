import { PriceListAddItemInput } from "~/types/PriceList/PriceListAddItemInput";

export const createPriceListFixedPricesAdd = async (
  admin: any,
  variants: any,
  priceListId: string,
  currencyCode: string,
): Promise<any> => {
  const mutation = `
        mutation priceListFixedPricesAdd($priceListId: ID!, $prices: [PriceListPriceInput!]!) {
            priceListFixedPricesAdd(priceListId: $priceListId, prices: $prices) {
                prices {
                    compareAtPrice {
                        amount
                        currencyCode
                    }
                    price {
                        amount
                        currencyCode
                    }
                }
                userErrors {
                    field
                    code
                    message
                }
            }
        }
    `;

  const variables: PriceListAddItemInput = {
    priceListId,
    prices: variants.map((variant: any) => ({
      variantId: variant.id,
      price: {
        amount: variant.price,
        currencyCode,
      },
    })),
  };

  const addPriceListItemsResponse = await admin.graphql(mutation, variables);

  const responseJson = await addPriceListItemsResponse.json();

  if (responseJson.data.priceListFixedPricesAdd.userErrors.length > 0) {
    throw new Error(
      JSON.stringify(responseJson.data.priceListFixedPricesAdd.userErrors),
    );
  }

  return responseJson.data.priceListFixedPricesAdd.prices;
};
