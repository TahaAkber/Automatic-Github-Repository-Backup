export interface OrderInfoLoaderReturn {
  order: any;
  search: string;
  discountCode: any;
}
