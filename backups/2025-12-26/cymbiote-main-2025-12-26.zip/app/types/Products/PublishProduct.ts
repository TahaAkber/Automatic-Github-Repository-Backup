import { PublishVariant } from "./PublishVariant";

export interface PublishProduct {
  product_name: string;
  product_shopify_category: string;
  product_custom_category: string;
  product_custom_category_id: string;
  product_shopify_id: string;
  product_shop_id: number;
  product_description: string;
  product_image_url: string;
  product_variants: PublishVariant[];
}
