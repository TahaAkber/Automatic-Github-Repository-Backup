export type ShopifyProduct = {
  id: string;
  title: string;
  description: string;
  status: string;
  productType: string;
  tags: string[];
  totalInventory: number;
  category: {
    name: string;
  };
  images: {
    nodes: Array<{ url: string }>;
  };
  variants: {
    nodes: Array<{
      title: string;
      price: string;
      image: { url: string | null; id: string };
      id: string;
      selectedOptions: Array<{ name: string; value: string }>;
    }>;
  };
  metafields: {
    nodes: Array<{ key: string; value: string }>;
  };
};