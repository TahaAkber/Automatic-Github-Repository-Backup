export interface ProductCategory {
  productId: string;
  productCategory: string;
  productCategoryId: string;
  categoryFullname: string;
  brandId?: string;
  DiscountedVariants?: DiscountedVariant[];
}

interface DiscountedVariant {
  variant_shopify_id: string;
  discounted_price: string;
}
