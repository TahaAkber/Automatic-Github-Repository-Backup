export interface Image {
  nodes: { url: string }[];
}
