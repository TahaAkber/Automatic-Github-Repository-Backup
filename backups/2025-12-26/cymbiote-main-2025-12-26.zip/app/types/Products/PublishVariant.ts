export interface PublishVariant {
  variant_name: string;
  variant_shopify_id: string;
  variant_price: number;
  variant_quantity: number;
  variant_inventory_id: string;
}
