export interface Variant {
  title: string;
  price: string;
  image: string;
  id: string;
  inventoryQuantity: number;
  option1: string | undefined;
  inventoryItem?: {
    id: string;
  };
}
