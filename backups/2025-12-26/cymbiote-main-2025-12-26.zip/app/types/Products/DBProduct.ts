interface DBProduct {
    product_id: number;
    product_name: string;
    product_shopify_category: string;
    product_custom_category: string | null;
    product_shopify_id: string;
    product_shop_id: number;
    product_description: string | null;
    product_image_url: string | null;
    product_is_active: boolean;
  }