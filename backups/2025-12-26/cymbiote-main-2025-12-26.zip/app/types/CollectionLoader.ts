export interface CollectionLoader {
  search: string | undefined;
  collections: any[];
  filterCollection: any[];
  trendingCollection: any[];
  // collectionfilters: any[];
  shopifyCollections: any[];
}

export interface CollectionAction {
  success: boolean;
  // shopify_id: any[] | null;
}

export interface EditCollectionLoader {
  success: number | string;
  collectionWithProducts: any[];
  products: any[];
  search: string;
  type: any;
}

export interface EditCollectionAction {
  success: number | string;
}
