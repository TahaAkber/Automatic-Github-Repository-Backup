export interface PriceListInput {
  parent: Parent;
  name: string;
  currency: string;
}

interface Parent {
  settings: {
    compareAtMode: string;
  };
  adjustment: {
    value: number;
    type: string;
  };
}
