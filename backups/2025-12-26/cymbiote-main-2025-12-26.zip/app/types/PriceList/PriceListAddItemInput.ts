export interface PriceListAddItemInput {
  priceListId: string;
  prices: Prices[];
}

interface Prices {
  compareAtPrice?: {
    amount: string;
    currencyCode: string;
  };
  price: {
    amount: string;
    currencyCode: string;
  };
  variantId: string;
}
