interface IShopifyProduct {
  admin_graphql_api_id: string;
  body_html: string;
  created_at: string; // ISO 8601 format
  handle: string;
  id: string;
  product_custom_category: string;
  product_custom_category_id?: string;
  categoryFullname?: string;
  product_brand_id: number;
  image: {
    id: number;
    position: number;
    product_id: number;
    src: string;
    alt?: string; // Assuming alt text is optional
  };
  images: Array<{
    id: number;
    position: number;
    product_id: number;
    src: string;
    alt?: string;
  }>;
  options: Array<{
    id: number;
    product_id: number;
    name: string;
    position: number;
    values: string[];
  }>;
  product_type: string;
  published_at: string; // ISO 8601 format
  published_scope: string;
  status: string;
  tags: string;
  template_suffix: string;
  title: string;
  updated_at: string; // ISO 8601 format
  variants: Array<{
    id: number;
    product_id: number;
    title: string;
    option1: string;
    option2?: string;
    option3?: string;
    sku: string;
    requires_shipping: boolean;
    taxable: boolean;
    featured_image?: {
      id: number;
      product_id: number;
      position: number;
      src: string;
      alt?: string;
    };
    available: boolean;
    price: string; // Assuming price is a string to accommodate currency formatting
    grams: number;
    compare_at_price?: string;
    position: number;
    product_exists: boolean;
    created_at: string; // ISO 8601 format
    updated_at: string; // ISO 8601 format
    admin_graphql_api_id: string;
  }>;
  vendor: string;
}
