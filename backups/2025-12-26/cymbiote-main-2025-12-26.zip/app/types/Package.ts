export interface PACKAGE {
  package_id: number;
  package_name: string;
  package_charges: number;
  package_rate: number;
  package_order_limit: number;
  package_limit_exceed_charges: number;
  package_trial_days: number;
  package_description: string;
  package_video_count?: number;
  extraQuota?: number;
  extraCharges?: number;
}
