export interface SubscriptionLoaderReturn {
  transactions: any[];
  totalTransactions: number;
  itemsPerPage: number;
  currentPage: number;
  search: string;
  billingCycle: {
    start: Date | null;
    end: Date | null;
  };
}
