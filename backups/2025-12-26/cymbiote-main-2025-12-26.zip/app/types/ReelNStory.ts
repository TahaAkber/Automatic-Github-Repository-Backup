// import { Product } from "~/components/collection/SearchModal";

export interface ReelNStory {
  video_id: string;
  video_shop_id: string;
  productId: string;
  video_url: string;
  video_url_720p: string;
  video_url_1080p: string;
  thumbnailUrl: string;
  products: any[];
  video: any;
  reelsProductData: any[];
  ReelsNStories: any[];
  viewCount: number;
  likesCount: number;
  createdAt: string;
  updatedAt: string;
}
