import { Prisma } from "@prisma/client";

export interface TransectionsLoaderReturn {
  search: string | undefined;
  subscriptions: any[];
  totalSubscriptions: number;
  itemsPerPage: number;
  currentPage: number;
  billingCycle: {
    start: Date | null;
    end: Date | null;
  } | null;
}

export type Transaction = {
  transaction_amount: number;
  transaction_amount_usd: number;
  transaction_date: string;
  transaction_detail: string;
  transaction_id: number;
  transaction_order_id: number;
  transaction_shop_id: number;
  transaction_type: string;
  created_date: Date;
  Orders: {
    order_id: number;
    order_date: string;
    order_delivery_address: string;
    order_fulfillment_status: string;
    order_total_amount: number;
    order_charge_rate: number;
    order_shopify_id: number;
  };
};