export interface OrderLoaderReturn {
  shippedOrders: any;
  upcommingOrders: any;
  search: string | undefined;
  shopDomain: string;
  shop: any;
}
