declare module "*.css";
