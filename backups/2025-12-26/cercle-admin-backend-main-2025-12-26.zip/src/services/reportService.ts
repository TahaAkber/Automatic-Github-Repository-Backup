
import { Request } from "express";
import { getAllReportModel, deleteReportModel, updateReportStatusModel } from "../models/reportModel";

export const getAllReportsService = async (req: Request, page: number, limit: number, search: string, typeFilter?: string, statusFilter?: string) => {
  const user = req.user;

  if (!user) {
    throw new Error("Unauthorized");
  }

  const {data, pagination} = await getAllReportModel(page, limit, search, typeFilter, statusFilter);
  return {data, pagination};
};

export const deleteReportService = async (req: Request, reportId: number) => {
  const user = req.user;

  if (!user) {
    throw new Error("Unauthorized");
  }

  const result = await deleteReportModel(reportId);
  return result;
};

export const updateReportStatusService = async (
  req: Request,
  reportId: number,
  status: string,
  decisionData?: {
    decision_description: string;
    decision_result: string;
  }
) => {
  const user = req.user;

  if (!user) {
    throw new Error("Unauthorized");
  }

  const result = await updateReportStatusModel(reportId, status, user.id, decisionData);
  return result;
};
