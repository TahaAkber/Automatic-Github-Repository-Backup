import { Request } from "express";
import {
  getAllMerchantsFromDb,
  getBrandsModel,
  getRequestedBrandsModel,
  getMerchantDetailsFromDb,
  getMerchantProductsModel,
  getMerchantsDropdown,
  updateBrandRequest,
  updateMerchantStatusInDb,
  getTilesModel,
  updateTilesModel,updateBrandsModel
} from "../models/merchantModel";

export const updateBrandsService = async (req: Request, brand_id: number,brand_name:string, brand_need_desc: string, brand_logo_url: string) => { 
  try {
    const user = req.user;

    if (!user) {
      return {
        status: 401,
        message: "Unauthorized",
      };
    }
    const result = await updateBrandsModel(
      brand_id,
      brand_name,
      brand_need_desc,
      brand_logo_url
    );
    return result;
  } catch (error: any) {
    console.log("Error in updateBrandsService", error);
    throw new Error("Error updating brands: " + error.message);
  }
}





export const getAllMerchantService = async (
  req: Request,
  page: number,
  limit: number,
  searchKeyword?: string,
  shop_is_active?: string,
  shop_delisted?: string
) => {
  try {
    const user = req.user;

    if (!user) {
      return {
        status: 401,
        message: "Unauthorized",
        totalPages: 0,
        totalCount: 0,
      };
    }

    const merchantsData = await getAllMerchantsFromDb(
      page,
      limit,
      searchKeyword,
      shop_is_active,
      shop_delisted
    );

    return merchantsData;
  } catch (error: any) {
    throw new Error("Error fetching merchants: " + error.message);
  }
};

export const getMerchantDetailService = async (req: Request, id: number) => {
  try {
    const user = req.user;

    if (!user) {
      return {
        status: 401,
        message: "Unauthorized",
        totalPages: 0,
        totalCount: 0,
        data: [],
      };
    }

    const response = await getMerchantDetailsFromDb(id);
    return response;
  } catch (error: any) {
    console.error("Error in Service:", error.message);
    throw new Error("Error fetching merchants: " + error.message);
  }
};

export const getShopProductsService = async (
  req: Request,
  shopId: number,
  page: number,
  limit: number,
  searchKeyword?: string,
  isActive?: boolean
) => {
  try {
    const user = req.user;

    if (!user) {
      return {
        status: 401,
        message: "Unauthorized",
        totalPages: 0,
        totalCount: 0,
      };
    }
    const result = await getMerchantProductsModel(
      shopId,
      page,
      limit,
      searchKeyword,
      isActive
    );
    return result;
  } catch (error: any) {
    console.log("Error in product merchant Service", error);
    throw new Error("Error fetching merchant products : " + error.message);
  }
};

export const merchantIsEnableService = async (
  req: Request,
  id: number,
  isEnable: boolean
) => {
  try {
    const user = req.user;

    if (!user) {
      return {
        status: 401,
        message: "Unauthorized",
      };
    }

    // Logic to enable/disable the merchant
    const result = await updateMerchantStatusInDb(id, isEnable);
    return result;
  } catch (error: any) {
    console.error("Error in Service:", error.message);
    throw new Error("Error enabling merchant: " + error.message);
  }
};

export const getMerchantDropdownService = async (
  req: Request,
  page: number,
  limit: number,
  searchKeyword?: string
) => {
  try {
    const user = req.user;

    if (!user) {
      return {
        status: 401,
        message: "Unauthorized",
        totalPages: 0,
        totalCount: 0,
      };
    }

    const merchantsData = await getMerchantsDropdown(
      page,
      limit,
      searchKeyword
    );

    return merchantsData;
  } catch (error: any) {
    throw new Error("Error fetching merchants: " + error.message);
  }
};

export const getAllBrandService = async (
  req: Request,
  page: number,
  limit: number,
  searchKeyword?: string
) => {
  try {
    const user = req.user;

    if (!user) {
      return {
        status: 401,
        message: "Unauthorized",
        totalPages: 0,
        totalCount: 0,
      };
    }
    const Brands = await getBrandsModel(page, limit, searchKeyword);
    return Brands;
  } catch (error: any) {
    console.log("Error in getAllBrandsSerice", error);
    throw new Error("Error fetching brands: " + error.message);
  }
};

export const approveBrandRequestService = async (
  req: Request,
  brand_id: number,
  brand_status_is_approved: boolean,
  user_id: any,
  brand_note?: string,
  brand_approval_is_approved?: boolean
) => {
  try {
    const user = req.user;

    if (!user) {
      return {
        status: 401,
        message: "Unauthorized",
        totalPages: 0,
        totalCount: 0,
      };
    }
    const result = await updateBrandRequest(
      brand_id,
      brand_status_is_approved,
      user_id,
      brand_note,
      brand_approval_is_approved
    );
    return result;
  } catch (error: any) {
    console.log("Error in approveBrandRequestService", error);
    throw new Error("Error approving brand request: " + error.message);
  }
};

export const getRequestedBrandsService = async (
  page: number,
  req: Request,
  limit: number,
  searchKeyword?: string
) => {
  try {
    const user = req.user;

    if (!user) {
      return {
        status: 401,
        message: "Unauthorized",
        totalPages: 0,
        totalCount: 0,
      };
    }
    const getBrandsRequest = await getRequestedBrandsModel(
      page,
      limit,
      searchKeyword
    );
    return getBrandsRequest;
  } catch (error: any) {
    console.log("Error in getBrandsRequestNotificationService", error);
    throw new Error(
      "Error fetching brands request notification: " + error.message
    );
  }
};

export const getTilesService = async (req: Request) => {
  try {
    const result = await getTilesModel();
    return result;
  } catch (error: any) {
    console.log("Error in getTilesService", error);
    throw new Error("Error fetching tiles: " + error.message);
  }
};

export const updateTilesService = async (
  req: Request,
  shop_tile_id: number,
  shop_tile_charges: number,
  shop_tile_name: string
) => {
  try {
    if (!req.user) {
      return {
        status: 401,
        message: "Unauthorized",
      };
    }
    const result = await updateTilesModel(
      shop_tile_id,
      shop_tile_charges,
      shop_tile_name
    );
    return result;
  } catch (error: any) {
    console.log("Error in updateTilesService", error);
    throw new Error("Error updating tiles: " + error.message);
  }
};
