import { performGlobalSearch } from "../models/globalSearchModel";

export const globalSearchService = async (
  req: any,
  query: string,
  page: number,
  pageSize: number
) => {
  try {
    const user = req.user;

    if (!user) {
      return {
        status: 401,
        message: "Unauthorized",
        totalPages: 0,
        totalCount: 0,
      };
    }

      const searchResults = await performGlobalSearch(query, page, pageSize);
      return searchResults
  } catch (error) {
    console.log(error);
    throw new Error("Global Search Not Found");
  }
};
