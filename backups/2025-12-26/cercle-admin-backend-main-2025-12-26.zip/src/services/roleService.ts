import { updateUser } from "../models/adminUserModel";
import { GetUserRoles } from "../models/roleModel";
import { Request } from "express";
export const roleService = async () => {
  const roles = await GetUserRoles();
  return roles;
};

export const updateUserRole = async (id: any, body: any, req: Request) => {
  try {
    const user = req.user;

    if (!user) {
      return {
        status: 401,
        message: "Unauthorized",
        totalPages: 0,
        totalCount: 0,
      };
    }

    const updatedUser = await updateUser(id, body);
    return updatedUser;
  } catch (error: any) {
    console.error("Error in updating user role:", error.message);
  }
};
