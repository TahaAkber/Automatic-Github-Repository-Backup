import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import {
  createAdminUser,
  getAdminByEmail,
  sendPasswordResetEmail,
  tokenCompareFromDb,
  updateOtpToken,
  updatePassword,
  updatePasswordAndOnboard,
} from "../models/authModel";
import {
  Admin_Users,
  ChangePasswordBody,
  LoginRequestBody,
  RegisterAdminBody,
} from "../types/authType";
import crypto from "crypto";

const JWT_SECRET = process.env.JWT_SECRET || "default_secret";
const SESSION_EXPIRY = process.env.SESSION_EXPIRY || "1h"; // 1 hour session expiry

export const loginAdmin = async (credentials: LoginRequestBody) => {
  const { email, password } = credentials;
  const admin = await getAdminByEmail(email);

  if (!admin) {
    throw new Error("Admin not found");
  }

  const isPasswordValid = await bcrypt.compare(
    password,
    admin.admin_user_password
  );
  if (!isPasswordValid) {
    throw new Error("Invalid password");
  }
  const token = jwt.sign(
    {
      id: admin.admin_user_id,
      email: admin.admin_user_email,
      username: admin.admin_user_name,
      onboarded: admin.admin_user_onboarded,
      roles: admin.admin_user_roles,
    },
    JWT_SECRET,
    {
      expiresIn: SESSION_EXPIRY as any,
    }
  );

  return {
    token,
    expiresIn: SESSION_EXPIRY,
  };
};

export const registerAdmin = async (body: RegisterAdminBody) => {
  const tempPassword = Math.random().toString(36).slice(-8); // random 8-char temp password
  const hashedPassword = await bcrypt.hash(tempPassword, 10);

  await createAdminUser(body.username, body.email, hashedPassword, body.roles);

  return { tempPassword, email: body.email };
};

export const changePasswordFirstTime = async (body: ChangePasswordBody) => {
  const admin = await getAdminByEmail(body.email);
  if (!admin) throw new Error("Admin not found");

  const isValid = await bcrypt.compare(
    body.oldPassword,
    admin.admin_user_password
  );
  if (!isValid) throw new Error("Old password incorrect");

  const newHashed = await bcrypt.hash(body.newPassword, 10);
  await updatePassword(body.email, newHashed);

  const updatedAdmin = await getAdminByEmail(body.email);
  return generateLoginResponse(updatedAdmin as Admin_Users);
};

const generateLoginResponse = (admin: Admin_Users) => {
  const token = jwt.sign(
    {
      id: admin.admin_user_id,
      email: admin.admin_user_email,
      username: admin.admin_user_name,
      roles: admin.admin_user_roles,
      onboarded: admin.admin_user_onboarded,
    },
    JWT_SECRET,
    { expiresIn: SESSION_EXPIRY as any }
  );

  return {
    token,
    expiresIn: SESSION_EXPIRY,
  };
};

export const resetFirstPassword = async (body: ChangePasswordBody) => {
  const admin = await getAdminByEmail(body.email);

  if (!admin) throw new Error("Admin not found");

  if (!body.otpToken) {
    const isValid = await bcrypt.compare(
      body.oldPassword,
      admin.admin_user_password
    );
    if (!isValid) throw new Error("Old password incorrect");
  } else if (body.otpToken) {
    const tokenCompare = await tokenCompareFromDb(body.email, body.otpToken);
    if (!tokenCompare) {
      throw new Error("Invalid or expired OTP token");
    }
  }

  const newHashed = await bcrypt.hash(body.newPassword, 10);
  await updatePasswordAndOnboard(body.email, newHashed);

  const updatedAdmin = await getAdminByEmail(body.email);
  return generateLoginResponse(updatedAdmin!);
};

export const forgotPasswordService = async (email: string) => {
  const admin = await getAdminByEmail(email);
  if (!admin) throw new Error("Admin not found");

  const OtpToken = crypto.randomInt(10000000, 100000000).toString();

  await updateOtpToken(email, OtpToken);

  const expiry = new Date();
  expiry.setHours(expiry.getHours() + 1); // 1 hour expiry

  const result = await sendPasswordResetEmail(
    email,
    OtpToken,
    admin.admin_user_name
  );

  return result;
};
