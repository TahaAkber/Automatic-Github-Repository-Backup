import { Request } from "express";

import {
  createTrendingCollectionModel,
  deleteTrendingCollectionModel,
  getAllCollectionFromDb,
  getCollectionByIdModel,
  updateTrendingCollectionModel,
  updateTrendingStatus,
} from "../models/collectionModel";

export const getCollections = async (
  req: Request,
  page: number,
  limit: number
) => {
  try {
    const user = req.user;

    if (!user) {
      return {
        status: 401,
        message: "Unauthorized",
        totalPages: 0,
        totalCount: 0,
      };
    }

    const collections = await getAllCollectionFromDb(page, limit);

    return collections;
  } catch (error: any) {
    throw new Error("Error fetching collections: " + error.message);
  }
};

export const updateTrendingStatusService = async (
  req: Request,
  trending_id: number,
  is_active: boolean
) => {
  const user = req.user;

  if (!user) {
    return {
      status: 401,
      message: "Unauthorized",
    };
  }
  const updateStatus = await updateTrendingStatus(is_active, trending_id);
  return updateStatus;
};
export const getCollectionByIdService = async (
  req: Request,
  collection_id: number
) => {
  const user = req.user;

  if (!user) {
    return {
      status: 401,
      message: "Unauthorized",
    };
  }
  const collections = await getCollectionByIdModel(collection_id);
  return collections;
};

export const updateTrendingCollectionService = async (
  req: Request,
  collection_id: number,
  collection_Description: string,
  collection_image_url: string
) => {
  const user = req.user;

  if (!user) {
    return {
      status: 401,
      message: "Unauthorized",
    };
  }
  const collections = await updateTrendingCollectionModel(
    collection_id,
    collection_Description,
    collection_image_url
  );
  return collections;
};

export const createTrendingCollectionService = async (
  req: Request,
  collection_Description: string,
  collection_Title: string,
  collection_image_url: string,
  end_Date: string
) => {
  const user = req.user;

  if (!user) {
    return {
      status: 401,
      message: "Unauthorized",
    };
  }

  const createCollection = await createTrendingCollectionModel(
    collection_Description,
    collection_Title,
    collection_image_url,
    end_Date
  );
  return createCollection;
};

export const deleteTrendingCollectionService = async (
  req: Request,
  trending_id: number
) => {
  const user = req.user;

  if (!user) {
    return {
      status: 401,
      message: "Unauthorized",
    };
  }

  const createCollection = await deleteTrendingCollectionModel(trending_id);
  return createCollection;
};
