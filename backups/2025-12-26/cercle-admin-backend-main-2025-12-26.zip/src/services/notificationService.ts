import { Request } from "express";
import {
  createInAppNotificationInDB,
  deleteInAppNotificationFromDB,
  getAllInAppNotificationsFromDB,
  getScheduledAppNotificationsFromDB,
  setNotificationActiveToggle,
} from "../models/notificationModel";

export const getAllInAppNotificationService = async (
  req: Request,
  page: number,
  limit: number
) => {
  try {
    const user = req.user;

    if (!user) {
      return {
        status: 401,
        message: "Unauthorized",
        totalPages: 0,
        totalCount: 0,
      };
    }
    const productsData = await getAllInAppNotificationsFromDB(page, limit);

    return productsData;
  } catch (error: any) {
    throw new Error("Error fetching Products: " + error.message);
  }
};

export const deleteInAppNotificationService = async (
  req: Request,
  id: number
) => {
  try {
    const user = req.user;

    if (!user) {
      return {
        status: 401,
        message: "Unauthorized",
      };
    }

    const deleteResult = await deleteInAppNotificationFromDB(id);

    return {
      status: deleteResult.success ? 200 : 404,
      message: deleteResult.message,
    };
  } catch (error: any) {
    throw new Error("Error deleting notification: " + error.message);
  }
};

export const createInAppNotificationService = async (req: Request) => {
  try {
    const user = req.user;
    if (!user) return { status: 401, message: "Unauthorized" };

    const {
      app_notification_title,
      app_notification_body,
      app_notification_read,
      app_notification_device_token,
      app_notification_type,
      app_notification_screen_name,
      app_notifcation_schedule_type,
      app_notification_shop_id,
      app_notification_starts_at,
      app_notification_ends_at,
      app_notification_image_url,
      app_notification_product_ids, // ⬅️ accept multiple products
      // app_notification_time_slot,
    } = req.body;

    // basic validation
    if (!app_notification_title || !app_notification_body) {
      return { status: 400, message: "Title and body are required" };
    }

    // call DB insert function
    const result = await createInAppNotificationInDB({
      app_notification_user_id: null, // system notification
      app_notification_title,
      app_notification_body,
      app_notification_type,
      app_notification_screen_name,
      app_notifcation_schedule_type,
      app_notification_shop_id,
      app_notification_starts_at,
      app_notification_ends_at,
      app_notification_image_url: app_notification_image_url || undefined,
      app_notification_product_ids: Array.isArray(app_notification_product_ids)
        ? app_notification_product_ids
        : [], // ensure it's an array
    });

    return { status: 201, ...result };
  } catch (error: any) {
    throw new Error("Error creating notification: " + error.message);
  }
};

export const getScheduledAppNotificationService = async (
  req: Request,
  page: number,
  limit: number
) => {
  try {
    const user = req.user;

    if (!user) {
      return {
        status: 401,
        message: "Unauthorized",
        totalPages: 0,
        totalCount: 0,
      };
    }
    const productsData = await getScheduledAppNotificationsFromDB(page, limit);

    return productsData;
  } catch (error: any) {
    throw new Error("Error fetching Products: " + error.message);
  }
};

export async function setNotificationActiveToggleService(
  id: number,
  active: boolean
) {
  const updated = await setNotificationActiveToggle(id, active);
  if (!updated) throw new Error("Notification not found");
  return {
    id: updated.app_notification_id,
    active: updated.app_notification_active,
  };
}
