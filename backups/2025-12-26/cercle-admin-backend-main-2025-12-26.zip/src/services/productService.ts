import { Request } from "express";
import {
  getAllProductFromDb,
  getProductDropdown,
  getProductReviewModel,
} from "../models/productModel";

export const getAllProductService = async (
  req: Request,
  page: number,
  limit: number,
  search?: string
) => {
  try {
    const user = req.user;

    if (!user) {
      return {
        status: 401,
        message: "Unauthorized",
        totalPages: 0,
        totalCount: 0,
      };
    }
    const productsData = await getAllProductFromDb(page, limit, search);

    return productsData;
  } catch (error: any) {
    throw new Error("Error fetching Products: " + error.message);
  }
};

export const getProductReviewsService = async (
  req: Request,
  page: number,
  limit: number,
  search?: string
) => {
  try {
    const user = req.user;

    if (!user) {
      return {
        status: 401,
        message: "Unauthorized",
        totalPages: 0,

        totalCount: 0,
      };
    }
    const Reviews = await getProductReviewModel(page, limit, search);
    return Reviews;
  } catch (error: any) {
    throw new Error("Error fetching Product Reviews: " + error.message);
  }
};

export const getProductDropdownService = async (
  req: Request,
  page: number,
  limit: number,
  search?: string
) => {
  try {
    const user = req.user;

    if (!user) {
      return {
        status: 401,
        message: "Unauthorized",
        totalPages: 0,
        totalCount: 0,
      };
    }
    const productsData = await getProductDropdown(page, limit, search);

    return productsData;
  } catch (error: any) {
    throw new Error("Error fetching Products: " + error.message);
  }
};
