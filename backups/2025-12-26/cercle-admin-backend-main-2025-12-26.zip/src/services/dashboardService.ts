import { Request, Response } from "express";
import { getDashboardProductsModel, getDashboardShopPricesModel, getDashboardTransactionsModel, getHighestSellerModel } from "../models/dashboardModel";
export const getDashboardTransactionsService = async (req: Request) => {
  try {
    const user = req.user;

    if (!user) {
      return {
        status: 401,
        message: "Unauthorized",
        totalPages: 0,
        totalCount: 0,
      };
    }

    const transactions = await getDashboardTransactionsModel();
    return transactions;
  } catch (error: any) {
    throw new Error("Error fetching collections: " + error.message);
  }
};

export const getDashboardProductsService= async(req:Request) => {
  try {
    const user = req.user;

    if (!user) {
      return {
        status: 401,
        message: "Unauthorized",
        totalPages: 0,
        totalCount: 0,
      };
    }
    const shopProducts = await getDashboardProductsModel();
    return shopProducts;
  } catch (error: any) {
    throw new Error("Error fetching collections: " + error.message);
  }
}

export const getDashboardShopPriceService = async (req: Request) => {
  try {
    const user = req.user;

    if (!user) {
      return {
        status: 401,
        message: "Unauthorized",
        totalPages: 0,
        totalCount: 0,
      };
    }
    const shopProducts = await getDashboardShopPricesModel();
    return shopProducts;
  } catch (error: any) {
    throw new Error("Error fetching collections: " + error.message);
  }
};


export const getHighestSellerService = async (req: Request) => {
  try {
    const user = req.user;

    if (!user) {
      return {
        status: 401,
        message: "Unauthorized",
        totalPages: 0,
        totalCount: 0,
      };
    }
    const shopProducts = await getHighestSellerModel();
    return shopProducts;
  } catch (error: any) {
    throw new Error("Error fetching collections: " + error.message);
  }
};