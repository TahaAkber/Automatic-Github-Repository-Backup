import { Request } from "express";
import {
  deleteUserById,
  getAllUsersFromDb,
  updateUserStatus,
} from "../models/adminUserModel";

export const getAllUserService = async (
  req: Request,
  page: number,
  limit: number
) => {
  try {
    const user = req.user;

    if (!user) {
      return {
        status: 401,
        message: "Unauthorized",
        totalPages: 0,
        totalCount: 0,
      };
    }

    const merchantsData = await getAllUsersFromDb(page, limit);

    return merchantsData;
  } catch (error: any) {
    throw new Error("Error fetching merchants: " + error.message);
  }
};

export const updateUserService = async (
  req: Request,
  id: any,
  status: boolean
) => {
  try {
    const user = req.user;

    if (!user) {
      return {
        status: 401,
        message: "Unauthorized",
        totalPages: 0,
        totalCount: 0,
      };
    }

    const userdata = await updateUserStatus(id, status);

    return userdata;
  } catch (error: any) {
    throw new Error("Error updating user: " + error.message);
  }
};

export const deleteUserService = async (req: Request, id: any) => {
  try {
    const user = req.user;

    if (!user) {
      return {
        status: 401,
        message: "Unauthorized",
        totalPages: 0,
        totalCount: 0,
      };
    }

    const userdata = await deleteUserById(id);

    return userdata;
  } catch (error: any) {
    throw new Error("Error deleting user: " + error.message);
  }
};
