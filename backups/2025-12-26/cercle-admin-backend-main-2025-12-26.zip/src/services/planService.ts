import { Request } from "express";
import {
  createPlansinDb,
  deletePlanInDb,
  getPlansFromDB,
  updatePlansInDb,
} from "../models/planModel";
export const plansService = async (
  req: Request,
  page: number,
  limit: number
) => {
  try {
    const user = req.user;

    if (!user) {
      return {
        status: 401,
        message: "Unauthorized",
        totalPages: 0,
        totalCount: 0,
      };
    }

    const plansData = await getPlansFromDB(page, limit);

    return plansData;
  } catch (error: any) {
    throw new Error("Error fetching plans: " + error.message);
  }
};

export const createPlanService = async (req: Request, data: any) => {
  try {
    const user = req.user;
    if (!user) {
      return {
        status: 401,
        message: "Unauthorized",
        totalPages: 0,
        totalCount: 0,
      };
    }
    console.log("databody", data);
    const Reponse = await createPlansinDb(data);
    return Reponse;
  } catch (error: any) {
    throw new Error("Error Creating Plans: " + error.message);
  }
};

export const updatePlanService = async (
  req: Request,
  data: any,
  id: number
) => {
  try {
    const user = req.user;
    if (!user) {
      return {
        status: 401,
        message: "Unauthorized",
      };
    }
    const response = await updatePlansInDb(data, id);
    return response;
  } catch (error: any) {
    throw new Error("Error Updating Plans: " + error.message);
  }
};

export const deletePlanService = async (req: Request, planId: number) => {
  try {
    const user = req.user;
    if (!user) {
      return {
        status: 401,
        message: "Unauthorized",
      };
    }
    const response = await deletePlanInDb(planId);

    return response;
  } catch (error: any) {
    throw new Error("Error Deleting Plans: " + error.message);
  }
};
