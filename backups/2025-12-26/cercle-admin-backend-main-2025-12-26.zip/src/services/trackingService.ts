import {
  getAdminChargesFromDb,
  getTrackingDetailsFromDb,
  updateAdminCharges,
} from "../models/trackingModel";
import { Request } from "express";
export const getTrackingDetailsByTrackingId = async (trackingId: number) => {
  try {
    const response = await getTrackingDetailsFromDb(trackingId);
    return response;
  } catch (error: any) {
    console.error("Error in Service:", error.message);
    throw new Error("Error fetching tracking details: " + error.message);
  }
};

export const getAdminChargesService = async (req: Request) => {
  try {
    const user = req.user;

    if (!user) {
      return {
        status: 401,
        message: "Unauthorized",
      };
    }
    const result = await getAdminChargesFromDb();
    return result;
  } catch (error: any) {
    console.error("Error in Service:", error.message);
    throw new Error("Error fetching tracking charges: " + error.message);
  }
};

export const updateAdminChargesService = async (
  req: Request,
  id: Number,
  tracking_charges: Number,
  reelNstory_charges:Number
) => {
  try {
    const user = req.user;

    if (!user) {
      return {
        status: 401,
        message: "Unauthorized",
      };
    }
    const result = await updateAdminCharges(Number(id), Number(tracking_charges), Number(reelNstory_charges));
    return result;
  } catch (error: any) {
    console.error("Error in Service:", error.message);
    throw new Error("Error fetching Admin charges: " + error.message);
  }
};
