import { Request } from "express";
import {
  getAllOrdersFromDB,
  getCancelledOrders,
  getItemsByOrderId,
  getOrderDetailsFromDB,
} from "../models/orderModel";

export const getAllOrderService = async (
  req: Request,
  page: number,
  limit: number,
  shopName?: string,
  status?: string
) => {
  try {
    const user = req.user; // Access the user data decoded from the token

    if (!user) {
      return {
        status: 401,
        message: "Unauthorized",
        totalPages: 0,
        totalCount: 0,
      };
    }

    // Get orders and pagination information
    const ordersData = await getAllOrdersFromDB(page, limit, shopName, status);

    return ordersData;
  } catch (error: any) {
    throw new Error("Error fetching orders: " + error.message);
  }
};
export const getCancelOrderService = async (
  req: Request,
  page: number,
  limit: number,
  search?: string,
  order_cancelled_by?: string
) => {
  try {
    const user = req.user; // Access the user data decoded from the token 

    if (!user) {
      return {
        status: 401,
        message: "Unauthorized",
        totalPages: 0,
        totalCount: 0,
      };
    }
    const ordersData = await getCancelledOrders(page, limit, search, order_cancelled_by);
    return ordersData;
  } catch (error: any) {
    throw new Error("Error fetching orders: " + error.message);
  }
};
export const getOrderDetailService = async (req: Request, id: number) => {
  try {
    const user = req.user;
    if (!user) {
      return {
        status: 401,
        message: "Unauthorized",
        totalPages: 0,
        totalCount: 0,
      };
    }
    const orderdetail = await getOrderDetailsFromDB(id);
    return orderdetail;
  } catch (error: any) {
    throw new Error("Error fetching Order deialts" + error.message);
  }
};

export const getItemsByOrderIdService = async (req: Request, id: number) => {
  try {
    const user = req.user;
    if (!user) {
      return {
        status: 401,
        message: "Unauthorized",
      };
    }
    const orderitems = await getItemsByOrderId(id);
    return orderitems;
  } catch (error: any) {
    throw new Error("Error fetching Order deialts" + error.message);
  }
};
