const getBaseStyles = () => `
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
    * { margin:0; padding:0; box-sizing:border-box; }
    body {
      font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Arial, sans-serif;
      background-color:#f5f5f5;
      padding:20px;
      line-height:1.6;
    }
    .email-container{
      max-width:680px; margin:0 auto; background:#fff; border-radius:12px;
      overflow:hidden; box-shadow:0 2px 8px rgba(0,0,0,.08);
    }
    .email-header{ background:#fff; padding:30px 40px 20px; border-bottom:1px solid #e5e5e5; }
    .logo img{ height:100px; width:auto; display:block; }
    .email-body{ padding:40px; }
    .title{ font-size:28px; font-weight:700; color:#1a1a1a; margin-bottom:8px; }
    .subtitle{ font-size:16px; color:#666; margin-bottom:30px; }
    .greeting{ font-size:18px; font-weight:600; color:#1a1a1a; margin-bottom:16px; }
    .message{ font-size:15px; color:#4a4a4a; margin-bottom:20px; }
    .email-footer{ background:#f8f9fa; padding:30px 40px; text-align:center; border-top:1px solid #e5e5e5; }
    .footer-text{ font-size:13px; color:#999; line-height:1.6; }

    /* OTP specific */
    .otpBox{
      background:#ffffff; border:1px solid #e5e7eb; border-radius:12px;
      padding:18px; text-align:center; margin:18px 0;
    }
    .otp{
      font-size:30px; letter-spacing:6px; font-weight:800; color:#111827;
    }
    .hint{ font-size:13px; color:#6b7280; margin-top:6px; }
    .warning{
      background:#fff3cd; border-left:4px solid #ffc107;
      padding:12px 14px; border-radius:8px; margin:18px 0;
    }
    .warning ul{ margin:8px 0 0 18px; }
    .warning li{ margin:4px 0; }

    @media only screen and (max-width:600px){
      body{ padding:10px; }
      .email-header,.email-body,.email-footer{ padding:20px; }
      .title{ font-size:24px; }
      .otp{ font-size:24px; letter-spacing:4px; }
    }
  </style>
`;

export const generatePasswordResetOtpEmail = (params: {
  userName: string;
  otp: string;
  expiryMinutes: string;
}) => {
  const { userName, otp, expiryMinutes } = params;

  return `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Password Reset OTP</title>
  ${getBaseStyles()}
</head>
<body>
  <div class="email-container">
    <!-- Header -->
    <div class="email-header">
      <div class="logo">
        <img src="https://cdn.shopify.com/s/files/1/0595/2379/2944/files/logo_1200.png?v=1747130432" alt="Cercle" />
      </div>
    </div>

    <!-- Body -->
    <div class="email-body">
      <h1 class="title">Password Reset OTP</h1>
      <p class="subtitle">Use this code to reset your Cercle Admin password</p>

      <p class="greeting">Hi ${userName || "there"},</p>

      <p class="message">
        We received a request to reset your password for your <b>Cercle Admin</b> account.
        Please use the OTP below to continue:
      </p>

      <div class="otpBox">
        <div class="otp">${otp}</div>
        <div class="hint">This OTP expires in ${expiryMinutes} minutes</div>
      </div>

      <div class="warning">
        <strong>⚠️ Important:</strong>
        <ul>
          <li>Do not share this OTP with anyone</li>
          <li>This OTP can only be used once</li>
          <li>If you didn’t request this, please ignore this email</li>
        </ul>
      </div>
    </div>

    <!-- Footer -->
    <div class="email-footer">
      <p class="footer-text">
        This is an automated message from Cercle. Please do not reply to this email.
      </p>
      <p class="footer-text" style="margin-top:6px;">
        &copy; ${new Date().getFullYear()} Cercle Admin. All rights reserved.
      </p>
    </div>
  </div>
</body>
</html>
  `;
};
