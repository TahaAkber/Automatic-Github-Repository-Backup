import nodemailer from "nodemailer";

// const auth = {
//   user: process.env.EMAIL_USER,
//   pass: process.env.EMAIL_PASS,
// };

const transporter = nodemailer.createTransport({
  host: "mail.cymbiote.com",
  port: 465,
  secure: true,
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
});

interface EmailOptions {
  to: string;
  subject: string;
  html: string;
  text?: string;
}

export const sendEmail = async (options: EmailOptions): Promise<void> => {
  try {
    const mailOptions = {
      from: process.env.EMAIL_USER || "support@cymbiote.com",
      to: options.to,
      subject: options.subject,
      html: options.html,
      text: options.text || options.html.replace(/<[^>]*>/g, ""), // Strip HTML for text version
    };

    const info = await transporter.sendMail(mailOptions);
    console.log("Email sent successfully:", info.messageId);
  } catch (error: any) {
    console.error("Error sending email:", error.message);
  }
};
