import { getTargetUsers, markAsSent } from "./getTargetedUsers";
import { sendFCMNotification } from "./notificationTrigger";
import { getPendingNotifications } from "./pendingNotification";

export async function processNotifications() {
  console.log("🚀 Checking pending notifications...");
  const pending = await getPendingNotifications();
  if (pending.length === 0) {
    console.log("✅ No pending notifications.");
    return;
  }
  console.log(`🔔 Found ${pending.length} pending notifications.`);
  for (const n of pending) {
    const users = await getTargetUsers(n);

    console.log(
      `📢 Notification ${n.app_notification_id} (${n.app_notifcation_schedule_type}) → ${users.length} users`
    );

    if (users.length > 0) {
      const deviceTokens = users.map((u) => u.device_token);

      const messageData = {
        app_notification_id: n.app_notification_id,
        title: n.app_notification_title,
        body: n.app_notification_body,
        image: n.app_notification_image_url,
        screenName: n.app_notification_screen_name,
        type: n.app_notification_type,
        productIds: n.app_notification_product_ids || [], // ✅ array
        payload: n.app_notification_payload,
      };

      try {
        const result = await sendFCMNotification(deviceTokens, messageData);
        console.log(messageData, "data which is sent");
        console.log(
          `✅ Sent notification ${n.app_notification_id} → Success: ${result?.successCount}, Failed: ${result?.failureCount}`
        );

        await markAsSent(messageData, result);
      } catch (err) {
        console.error(
          `❌ Failed to send notification ${n.app_notification_id}:`,
          err
        );
      }
    } else {
      console.log(
        `⚠️ No target users found for notification ${n.app_notification_id}`
      );

      await markAsSent(n, { successCount: 0, failureCount: 0 });
    }
  }
}
