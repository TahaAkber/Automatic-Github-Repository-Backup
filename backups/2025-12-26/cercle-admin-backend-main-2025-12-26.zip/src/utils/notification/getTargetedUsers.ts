import { poolPromise } from "../../config/db";

export async function getTargetUsers(notification: any) {
  const pool = await poolPromise;

  switch (notification.app_notification_type) {
    case "broadcast":
      return (
        await pool.request().query(`
          SELECT 
            t.notification_user_id AS user_id,
            t.notification_token AS device_token
          FROM User_Notification_Tokens t
          JOIN Notification_Settings s 
            ON s.notification_setting_user_id = t.notification_user_id
          WHERE t.notification_token IS NOT NULL
            AND s.notification_setting_offers_n_updates = 1
        `)
      ).recordset;

    case "store_following":
      return (
        await pool
          .request()
          .input("shopId", notification.app_notification_shop_id).query(`
            SELECT 
              t.notification_user_id AS user_id,
              t.notification_token AS device_token
            FROM User_Following uf
            JOIN User_Notification_Tokens t 
              ON uf.following_user_id = t.notification_user_id
            JOIN Notification_Settings s 
              ON s.notification_setting_user_id = t.notification_user_id
            WHERE uf.following_shop_id = @shopId
              AND t.notification_token IS NOT NULL
              AND s.notification_setting_offers_n_updates = 1
          `)
      ).recordset;

    case "product_wishlist": {
      let productIds: number[] =
        notification.app_notification_product_ids || [];

      if (!productIds || productIds.length === 0) {
        const productResult = await pool
          .request()
          .input("notifId", notification.app_notification_id).query(`
        SELECT product_id 
        FROM App_Notification_Products 
        WHERE app_notification_id = @notifId
      `);

        productIds = productResult.recordset.map((r: any) => r.product_id);
      }

      if (productIds.length === 0) return [];

      const placeholders = productIds.map((_, i) => `@p${i}`).join(",");
      const request = pool.request();

      productIds.forEach((id, i) => {
        request.input(`p${i}`, id);
      });

      return (
        await request.query(`
      SELECT DISTINCT
        t.notification_user_id AS user_id,
        t.notification_token AS device_token
      FROM User_Wishlist w
      JOIN User_Notification_Tokens t 
        ON w.wishlist_user_id = t.notification_user_id
      JOIN Notification_Settings s 
        ON s.notification_setting_user_id = t.notification_user_id
      WHERE w.wishlist_product_id IN (${placeholders})
        AND t.notification_token IS NOT NULL
        AND (s.notification_setting_pricedrop = 1 OR s.notification_setting_stock_available = 1)
    `)
      ).recordset;
    }

    case "send_all":
      return (
        await pool.request().query(`
          SELECT 
            t.notification_user_id AS user_id,
            t.notification_token AS device_token
          FROM User_Notification_Tokens t
          WHERE t.notification_token IS NOT NULL
        `)
      ).recordset;

    default:
      return [];
  }
}

export async function markAsSent(notification: any, result: any) {
  const pool = await poolPromise;

  if (notification.app_notification_id) {
    await pool.request().input("id", notification.app_notification_id).query(`
        UPDATE App_Notifications
        SET app_notification_last_sent_at = GETUTCDATE()
        WHERE app_notification_id = @id
      `);
    const insertResult = await pool
      .request()
      .input("title", notification.title || notification.app_notification_title)
      .input("body", notification.body || notification.app_notification_body)
      .input(
        "screenName",
        notification.screenName ||
          notification.app_notification_screen_name ||
          null
      )
      .input(
        "imageUrl",
        notification.image || notification.app_notification_image_url || null
      )
      .input("payload", JSON.stringify(notification.payload || {})).query(`
        INSERT INTO App_Notifications (
          app_notification_title,
          app_notification_body,
          app_notification_screen_name,
          app_notification_image_url,
          app_notification_payload,
          app_notification_last_sent_at,
          app_notification_active,
          created_at
        )
        OUTPUT INSERTED.app_notification_id
        VALUES (
          @title, @body, @screenName, @imageUrl, @payload,
          GETUTCDATE(), 1, GETUTCDATE()
        )
      `);

    const newNotificationId = insertResult.recordset[0].app_notification_id;

    if (notification.productIds && notification.productIds.length > 0) {
      const request = pool.request();
      notification.productIds.forEach((id: number, i: number) => {
        request.input(`p${i}`, id);
      });

      const values = notification.productIds
        .map((_: any, i: any) => `(@newId, @p${i})`)
        .join(",");

      await request.input("newId", newNotificationId).query(`
          INSERT INTO App_Notification_Products (notification_id, product_id)
          VALUES ${values}
        `);
    }
  }
}
