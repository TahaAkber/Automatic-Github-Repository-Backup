import { poolPromise } from "../../config/db";

export async function getPendingNotifications() {
  const pool = await poolPromise;

  const result = await pool.request().query(`
    SELECT *
    FROM App_Notifications
    WHERE app_notification_active = 1
      AND app_notification_starts_at <= GETUTCDATE()
      AND (app_notification_ends_at IS NULL OR app_notification_ends_at >= GETUTCDATE())
      AND (
          -- once
          (app_notifcation_schedule_type = 'once'
           AND app_notification_read = 0
           AND app_notification_last_sent_at IS NULL)

          OR
          -- daily
          (app_notifcation_schedule_type = 'daily'
           AND (app_notification_last_sent_at IS NULL 
                OR CAST(app_notification_last_sent_at AS DATE) < CAST(GETUTCDATE() AS DATE)))

          OR
          -- weekly
          (app_notifcation_schedule_type = 'weekly'
           AND DATEPART(WEEKDAY, GETUTCDATE()) = DATEPART(WEEKDAY, app_notification_starts_at)
           AND (app_notification_last_sent_at IS NULL 
                OR DATEDIFF(WEEK, app_notification_last_sent_at, GETUTCDATE()) >= 1))

          OR
          -- monthly
          (app_notifcation_schedule_type = 'monthly'
           AND DATEPART(DAY, GETUTCDATE()) = DATEPART(DAY, app_notification_starts_at)
           AND (app_notification_last_sent_at IS NULL 
                OR DATEDIFF(MONTH, app_notification_last_sent_at, GETUTCDATE()) >= 1))
      )
  `);

  return result.recordset;
}
