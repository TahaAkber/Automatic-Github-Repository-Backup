import admin from "../../firebase/firebase";

export const sendFCMNotification = async (
  deviceTokens: string[] | string | null,
  MessageData: any
) => {
  const notification = {
    title: MessageData.title,
    body: MessageData.body,
    image: MessageData?.image || null,
  };

  const dataPayload = {
    screenName: MessageData.screenName || "",
    orderId: MessageData.orderId || "",
    productId: MessageData.productId || "",
    variantId: MessageData.variantId || "",
    notificationImageUrl: MessageData.notificationImageUrl || "",
    payload: JSON.stringify(MessageData.payload || {}),
  };

  try {
    let responseSummary;

    // 🔹 Broadcast to topic
    if (MessageData.type === "all") {
      const topicMessage = {
        topic: "all",
        notification,
        data: dataPayload,
      };
      const response = await admin.messaging().send(topicMessage);
      responseSummary = {
        successCount: 1,
        failureCount: 0,
        responses: [{ status: "fulfilled", value: response }],
      };
    }

    if (Array.isArray(deviceTokens)) {
      const responses = await Promise.allSettled(
        deviceTokens.map((token) =>
          admin.messaging().send({
            token,
            notification,
            data: dataPayload,
          })
        )
      );

      const success = responses.filter((r) => r.status === "fulfilled");
      const failed = responses.filter((r) => r.status === "rejected");

      responseSummary = {
        successCount: success.length,
        failureCount: failed.length,
        responses,
      };
    }

    return (
      responseSummary || { successCount: 0, failureCount: 0, responses: [] }
    );
  } catch (err: any) {
    console.error("FCM send error:", err);
    throw err;
  }
};
