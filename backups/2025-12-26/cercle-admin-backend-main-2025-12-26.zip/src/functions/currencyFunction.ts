import axios from "axios";
import dotenv from "dotenv";
dotenv.config();
export const getCurrentCurrencyRate = async (
  currency: string,
  convertingCurrency: string
): Promise<number> => {
  const CURRENCY_RATES_API = `${process.env.EXCHANGE_RATE_API_URL}/${process.env.EXCHANGE_RATE_API_KEY}/latest/${currency}`;
  console.log(`Fetching currency rates from: ${CURRENCY_RATES_API}`);
  let currentUSDRate = 0;

  try {
    const currentRates = await axios.get(CURRENCY_RATES_API);

    if (
      currentRates.status === 200 &&
      currentRates.data?.conversion_rates?.[convertingCurrency]
    ) {
      currentUSDRate = parseFloat(
        currentRates.data.conversion_rates[convertingCurrency]
      );

      console.log(
        `Current ${currency} to ${convertingCurrency} rate:`,
        currentUSDRate
      );
    } else {
      console.warn("Conversion rate not found in response");
    }
  } catch (error) {
    console.error("Failed to fetch currency rates:", error);
  }

  return currentUSDRate;
};

// assumes getCurrentCurrencyRate(currency, convertingCurrency) is available

type CurrencyTotal = { currency: string; total: number | string };

const roundTo = (n: number, d = 2) =>
  Math.round((n + Number.EPSILON) * 10 ** d) / 10 ** d;

export async function sumInPKRWithLiveRates(currencyTotals: CurrencyTotal[]) {
  // Normalize and dedupe currencies
  const uniqueCurrencies = Array.from(
    new Set(
      currencyTotals
        .map((c) => (c.currency || "UNKNOWN").toUpperCase())
        .filter((c) => c && c !== "UNKNOWN")
    )
  );

  // Fetch live rates to PKR (skip PKR itself)
  const fetches = uniqueCurrencies
    .filter((c) => c !== "PKR")
    .map(async (cur) => {
      try {
        const rate = await getCurrentCurrencyRate(cur, "PKR"); // <- your function
        return [cur, Number(rate) || 0] as const;
      } catch {
        return [cur, 0] as const;
      }
    });

  const entries = await Promise.all(fetches);
  const ratesToPKR: Record<string, number> = Object.fromEntries(entries);
  ratesToPKR.PKR = 1; // identity

  // Build breakdown + total
  const missingRates = new Set<string>();
  const breakdownPKR = currencyTotals.map(({ currency, total }) => {
    const cur = (currency || "UNKNOWN").toUpperCase();
    const amount =
      typeof total === "string" ? parseFloat(total) : Number(total);
    const rate = ratesToPKR[cur];

    if (!rate || !isFinite(rate)) {
      if (cur !== "PKR") missingRates.add(cur);
      return { currency: cur, total: amount, pkr: 0 };
    }
    const pkr = amount * rate;
    return { currency: cur, total: amount, pkr: roundTo(pkr) };
  });

  const totalPKR = roundTo(
    breakdownPKR.reduce((s, r) => s + (isFinite(r.pkr) ? r.pkr : 0), 0)
  );

  return {
    totalPKR,
    breakdownPKR,
    unknownCurrencies: Array.from(missingRates),
    ratesToPKR,
  };
}
