// Types
type CurrencyTotal = { currency: string; total: number };

// 1) Build currency totals from orderAmountResult rows
export const buildCurrencyTotals = (
  rows: Array<{ shop_currency?: string; total_amount?: number }>
): CurrencyTotal[] => {
  const totalsByCurrency: Record<string, number> = rows.reduce((acc, r) => {
    const curr = String(r.shop_currency || "UNKNOWN").toUpperCase();
    const raw = Number(r.total_amount ?? 0);
    const amt = Number.isFinite(raw) ? raw : 0;
    acc[curr] = (acc[curr] || 0) + amt;
    return acc;
  }, {} as Record<string, number>);

  return Object.entries(totalsByCurrency).map(([currency, total]) => ({
    currency,
    total,
  }));
};

// 2) Convert totals → PKR with robust fallback (keeps your shape)
export const convertTotalsToPKR = async (
  currencyTotals: CurrencyTotal[],
  sumInPKRWithLiveRates: (totals: CurrencyTotal[]) => Promise<{
    totalPKR: number;
    breakdownPKR:
      | Record<string, number>
      | Array<{ currency: string; pkr: number }>;
    unknownCurrencies: string[];
    ratesToPKR: Record<string, number>;
  }>
): Promise<{
  totalPKR: number;
  breakdownPKR: Record<string, number>;
  unknownCurrencies: string[];
  ratesToPKR: Record<string, number | string>;
}> => {
  let totalPKR = 0;
  let breakdownPKR: Record<string, number> = {};
  let unknownCurrencies: string[] = [];
  let ratesToPKR: Record<string, number | string> = {};

  try {
    const res = await sumInPKRWithLiveRates(currencyTotals);
    totalPKR = Number(res.totalPKR ?? 0);
    // normalize breakdown (array or object)
    breakdownPKR = Array.isArray(res.breakdownPKR)
      ? res.breakdownPKR.reduce<Record<string, number>>(
          (acc, curr) => (
            (acc[curr.currency.toUpperCase()] = Number(curr.pkr) || 0), acc
          ),
          {}
        )
      : Object.fromEntries(
          Object.entries(res.breakdownPKR || {}).map(([k, v]) => [
            k.toUpperCase(),
            Number(v) || 0,
          ])
        );

    unknownCurrencies = res.unknownCurrencies || [];
    ratesToPKR = res.ratesToPKR || {};

    if (!Number.isFinite(totalPKR)) totalPKR = 0;
    for (const k of Object.keys(breakdownPKR)) {
      if (!Number.isFinite(breakdownPKR[k])) breakdownPKR[k] = 0;
    }
  } catch (err: any) {
    // Fallback: PKR only
    const pkrRow = currencyTotals.find(
      (c) => (c.currency || "").toUpperCase() === "PKR"
    );
    const safePKR = Number.isFinite(Number(pkrRow?.total))
      ? Number(pkrRow?.total)
      : 0;

    totalPKR = safePKR;
    breakdownPKR = { PKR: safePKR };
    unknownCurrencies = currencyTotals
      .map((c) => (c.currency || "").toUpperCase())
      .filter((cur) => cur && cur !== "PKR");
    ratesToPKR = {
      PKR: 1,
      __conversion_error: String(err?.message || err || "conversion_failed"),
    };
  }

  return { totalPKR, breakdownPKR, unknownCurrencies, ratesToPKR };
};

// 3) Build net revenue by currency from cercleRevenueCurResult rows
export const buildNetRevenueByCurrency = (
  revRows: Array<{
    shop_currency?: string;
    subscription_total?: number;
    usage_total?: number;
    credit_total?: number;
  }>
): CurrencyTotal[] => {
  return revRows.map((r) => {
    const curr = String(r.shop_currency || "UNKNOWN").toUpperCase();
    const sub = Number.isFinite(Number(r.subscription_total))
      ? Number(r.subscription_total)
      : 0;
    const use = Number.isFinite(Number(r.usage_total))
      ? Number(r.usage_total)
      : 0;
    const cre = Number.isFinite(Number(r.credit_total))
      ? Number(r.credit_total)
      : 0;
    return { currency: curr, total: sub + use - cre };
  });
};

// 4) Convert net revenue → PKR with fallback (returns single number)
export const convertNetRevenueToPKR = async (
  netByCurrency: CurrencyTotal[],
  sumInPKRWithLiveRates: (
    totals: CurrencyTotal[]
  ) => Promise<{ totalPKR: number }>
): Promise<number> => {
  try {
    const res = await sumInPKRWithLiveRates(netByCurrency);
    const total = Number(res.totalPKR ?? 0);
    return Number.isFinite(total) ? total : 0;
  } catch {
    // Fallback: only PKR nets
    return netByCurrency
      .filter((x) => x.currency === "PKR")
      .reduce(
        (s, x) => s + (Number.isFinite(Number(x.total)) ? Number(x.total) : 0),
        0
      );
  }
};
