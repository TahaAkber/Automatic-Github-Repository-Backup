type Order = {
  shop_id: string | number;
  product_id: string | number;
  product_name?: string;
  shop_logo_url: string | any;
  shop_name: string;
  order_total_amount: number;
};

type ProductStat = {
  product_id: string | number;
  product_name?: string;
  total_sold: number;
  total_sales_amount: number;
};

type ShopStat = {
  shop_id: string | number;
  shop_logo_url: string | any;
  total_sales: number;
  total_sales_amount: number;
  shop_name: string;
  products: Record<string, ProductStat>;
};

export const getShopProductStats = (orders: Order[]) => {
  const shopStats: Record<string, ShopStat> = {};

  for (const order of orders) {
    const {
      shop_id,
      product_id,
      product_name,
      shop_name,
      shop_logo_url,
      order_total_amount,
    } = order;
    const shopKey = String(shop_id);
    const productKey = String(product_id);

    if (!shopStats[shopKey]) {
      shopStats[shopKey] = {
        shop_id,
        shop_name,
        shop_logo_url,
        total_sales: 0,
        total_sales_amount: 0,
        products: {},
      };
    }

    shopStats[shopKey].total_sales += 1;
    shopStats[shopKey].total_sales_amount += order_total_amount;

    if (!shopStats[shopKey].products[productKey]) {
      shopStats[shopKey].products[productKey] = {
        product_id,
        product_name,
        total_sold: 0,
        total_sales_amount: 0,
      };
    }
    shopStats[shopKey].products[productKey].total_sold += 1;
  }

  const result = Object.values(shopStats).map((shop) => {
    const sortedProducts = Object.values(shop.products)
      .sort((a, b) => b.total_sold - a.total_sold)
      .slice(0, 3);

    return {
      shop_id: shop.shop_id,
      shop_logo_url: shop.shop_logo_url,
      shop_name: shop.shop_name,
      total_sales: shop.total_sales,
      total_sales_amount: shop.total_sales_amount,
      top_products: sortedProducts,
    };
  });

  result.sort((a, b) => b.total_sales_amount - a.total_sales_amount);

  return result;
};
