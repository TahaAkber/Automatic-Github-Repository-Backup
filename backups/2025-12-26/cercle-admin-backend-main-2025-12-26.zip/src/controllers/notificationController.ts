import { Request, Response } from "express";
import {
  createInAppNotificationService,
  deleteInAppNotificationService,
  getAllInAppNotificationService,
  getScheduledAppNotificationService,
  setNotificationActiveToggleService,
} from "../services/notificationService";
import {
  getNotificationCount,
  getScheduledNotificationCount,
} from "../models/notificationModel";

export const getAllInAppNotification = async (req: Request, res: Response) => {
  try {
    const { page = 1, limit = 10 } = req.query; // Default page 1, limit 10
    const notificationCount = await getNotificationCount(limit as number);
    const result = await getAllInAppNotificationService(
      req,
      page as number,
      limit as number
    ); // Pass pagination to the service
    res.status(200).json({
      status: 200,
      message: "success",
      ...result,
      pagination: {
        currentPage: page,
        totalPages: notificationCount.totalPages,
        totalCount: notificationCount.totalCount,
      },
    });
  } catch (error: any) {
    res.status(400).json({
      status: 400,
      message: error.message || "Failed to fetch products",
    });
  }
};
export const deleteInAppNotification = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;

    if (!id) {
      return res.status(400).json({
        status: 400,
        message: "Notification ID is required",
      });
    }

    const result = await deleteInAppNotificationService(req, Number(id));

    return res.status(result.status).json({
      status: result.status,
      message: result.message,
    });
  } catch (error: any) {
    return res.status(400).json({
      status: 400,
      message: error.message || "Failed to delete notification",
    });
  }
};

export const createInAppNotification = async (req: Request, res: Response) => {
  try {
    const result = await createInAppNotificationService(req);
    return res.status(result.status).json(result);
  } catch (error: any) {
    return res.status(400).json({
      status: 400,
      message: error.message || "Failed to create notification",
    });
  }
};

export const getScheduledAppNotification = async (
  req: Request,
  res: Response
) => {
  try {
    const { page = 1, limit = 10 } = req.query;
    const notificationCount = await getScheduledNotificationCount(
      limit as number
    );
    const result = await getScheduledAppNotificationService(
      req,
      page as number,
      limit as number
    ); // Pass pagination to the service
    res.status(200).json({
      status: 200,
      message: "success",
      ...result,
      pagination: {
        currentPage: page,
        totalPages: notificationCount.totalPages,
        totalCount: notificationCount.totalCount,
      },
    });
  } catch (error: any) {
    res.status(400).json({
      status: 400,
      message: error.message || "Failed to fetch products",
    });
  }
};

export async function setNotificationActiveToggleController(
  req: Request,
  res: Response
) {
  try {
    const { id } = req.params;
    const { active } = req.body;

    if (active === undefined) {
      return res
        .status(400)
        .json({ message: "Missing 'active' field in body" });
    }

    const updated = await setNotificationActiveToggleService(
      Number(id),
      Boolean(active)
    );

    res.json({
      message: `Notification ${
        updated.active ? "activated" : "deactivated"
      } successfully`,
      ...updated,
    });
  } catch (err: any) {
    res.status(400).json({ message: err.message });
  }
}
