import { Request, Response } from "express";
import {
  approveBrandRequestService,
  getAllBrandService,
  getAllMerchantService,
  getRequestedBrandsService,
  getMerchantDetailService,
  getMerchantDropdownService,
  getShopProductsService,
  merchantIsEnableService,
  getTilesService,
  updateTilesService,updateBrandsService
} from "../services/merchantService";
import {
  getBrandCount,
  getBrandRequestCount,
  getProductsCount,
} from "../models/merchantModel";

export const getAllMerchants = async (req: Request, res: Response) => {
  try {
    const {
      page = 1,
      limit = 10,
      searchKeyword = "",
      shop_is_active,
      shop_delisted,
    } = req.query;

    const result = await getAllMerchantService(
      req,
      Number(page),
      Number(limit),
      searchKeyword.toString(),
      shop_is_active?.toString(),
      shop_delisted?.toString()
    );

    res.status(200).json({
      status: 200,
      message: "success",
      merchants: result,
      pagination: {
        currentPage: Number(page),
        totalPages: result.totalPages,
        totalCount: result.totalCount,
      },
    });
  } catch (error: any) {
    res.status(400).json({
      status: 400,
      message: error.message || "Failed to fetch merchants",
    });
  }
};

export const getMerchantDetails = async (req: Request, res: Response) => {
  try {
    const { page = 1, limit = 10, id } = req.query;

    // const { id } = req.params;

    const merchantData = await getMerchantDetailService(req, Number(id));

    res.status(200).json({
      status: 200,
      message: "success",
      ...merchantData,
    });
  } catch (error: any) {
    console.error("Error in Controller:", error.message);
    res.status(400).json({
      status: 400,
      message: error.message || "Failed to fetch merchant details",
    });
  }
};

export const getMerchantProducts = async (req: Request, res: Response) => {
  try {
    const { page, limit, shopId, searchKeyword, isActive } = req.query;

    const countQuery = await getProductsCount(
      Number(shopId),
      Number(page),
      Number(limit),
      searchKeyword?.toString(),
      isActive ? isActive?.toString() === "true" : undefined
    );
    const merchantData = await getShopProductsService(
      req,
      Number(shopId),
      Number(page),
      Number(limit),
      searchKeyword?.toString(),
      isActive ? isActive?.toString() === "true" : undefined
    );
    res.status(200).json({
      status: 200,
      message: "success",
      ...merchantData,
      pagination: {
        currentPage: Number(page),
        totalPages: countQuery.totalPages,
        totalCount: countQuery.totalCount,
      },
    });
  } catch (error: any) {
    console.error("Error in Controller:", error.message);
    res.status(400).json({
      status: 400,
      message: error.message || "Failed to fetch merchant details",
    });
  }
};

export const merchantIsEnable = async (req: Request, res: Response) => {
  try {
    const { id, isEnable } = req.body;

    const result = await merchantIsEnableService(req, Number(id), isEnable);

    res.status(200).json({
      status: 200,
      message: "Shop is successfully updated.",
    });
  } catch (error: any) {
    console.error("Error in Controller:", error.message);
    res.status(400).json({
      status: 400,
      message: error.message || "Failed to check merchant status",
    });
  }
};

export const getMerchantsDropdownList = async (req: Request, res: Response) => {
  try {
    const { page = 1, limit = 10, searchKeyword = "" } = req.query;

    const result = await getMerchantDropdownService(
      req,
      Number(page),
      Number(limit),
      searchKeyword.toString()
    );

    res.status(200).json({
      status: 200,
      message: "success",
      ...result,
      pagination: {
        currentPage: Number(page),
        totalPages: result.totalPages,
        totalCount: result.totalCount,
      },
    });
  } catch (error: any) {
    res.status(400).json({
      status: 400,
      message: error.message || "Failed to fetch merchants",
    });
  }
};

export const getAllBrands = async (req: Request, res: Response) => {
  try {
    const { page = 1, limit = 10, searchKeyword = "" } = req.query;
    const brandCount = await getBrandCount(
      Number(limit),
      searchKeyword as string
    );
    const result = await getAllBrandService(
      req,
      Number(page),
      Number(limit),
      searchKeyword as string
    );

    res.status(200).json({
      status: 200,
      message: "success",
      brands: result,
      pagination: {
        currentPage: Number(page),
        totalPages: brandCount.totalPages,
        totalCount: brandCount.totalCount,
      },
    });
  } catch (error: any) {
    res.status(400).json({
      status: 400,
      message: error.message || "Failed to fetch brands",
    });
  }
};

export const approveBrandsRequest = async (req: Request, res: Response) => {
  try {
    const {
      brand_id,
      brand_status_is_approved,
      brand_note,
      brand_approval_is_approved,
      user_id,
    } = req.body;

    console.log("req body", req.body);

    const result = await approveBrandRequestService(
      req,
      Number(brand_id),
      brand_status_is_approved,
      user_id,
      brand_note,
      brand_approval_is_approved
    );

    res.status(200).json({
      status: 200,
      message: "Brand request is successfully updated.",
      result,
    });
  } catch (error: any) {
    res.status(400).json({
      status: 400,
      message: error.message || "Failed to approve brand request",
    });
  }
};

export const getRequestedBrands = async (req: Request, res: Response) => {
  try {
    const {
      page = 1,
      limit = 10,
      onlyCount = false,
      searchKeyword = "",
    } = req.query;

    if (onlyCount === "true") {
      const RequestCount = await getBrandRequestCount(
        Number(limit),
        Number(page)
      );
      res.status(200).json({
        status: 200,
        message: "success",
        pagination: {
          currentPage: Number(page),
          totalPages: RequestCount.totalPages,
          totalCount: RequestCount.totalCount,
        },
      });
    } else {
      const RequestCount = await getBrandRequestCount(
        Number(limit),
        Number(page)
      );
      const result = await getRequestedBrandsService(
        Number(page),
        req,
        Number(limit),
        searchKeyword as string
      );
      res.status(200).json({
        status: 200,
        message: "success",
        brands_requests: result,
        pagination: {
          currentPage: Number(page),
          totalPages: RequestCount.totalPages,
          totalCount: RequestCount.totalCount,
        },
      });
    }
  } catch (error: any) {
    res.status(400).json({
      status: 400,
      message: error.message || "Failed to fetch brand requests",
    });
  }
};

export const getTiles = async (req: Request, res: Response) => {
  try {
    const result = await getTilesService(req);
    res.status(200).json({
      status: 200,
      message: "success",
      tiles: result,
    });
  } catch (error: any) {
    res.status(400).json({
      status: 400,
      message: error.message || "Failed to fetch tiles",
    });
  }
};

export const updateTiles = async (req: Request, res: Response) => {
  try {
    const { shop_tile_id, shop_tile_charges, shop_tile_name } = req.body;

    const result = await updateTilesService(
      req,
      Number(shop_tile_id),
      Number(shop_tile_charges),
      shop_tile_name as string
    );
    res.status(200).json({
      status: 200,
      message: "success",
      tiles: result,
    });
  } catch (error: any) {
    res.status(400).json({
      status: 400,
      message: error.message || "Failed to delete Tiles",
    });
  }
};


export const updateBrands = async (req: Request, res: Response) => {
  try {
    const { brand_id,brand_name,  brand_need_desc, brand_logo_url} = req.body;

    const result = await updateBrandsService(
      req,
      Number(brand_id),
      brand_name,
      brand_need_desc,
      brand_logo_url
    );
    res.status(200).json({
      status: 200,
      message: "success",
      brands: result,
    });
  } catch (error: any) {
    res.status(400).json({
      status: 400,
      message: error.message || "Failed to update brands",
    });
  }
};