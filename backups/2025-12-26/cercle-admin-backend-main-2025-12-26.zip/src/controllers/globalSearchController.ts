import { Request, Response } from "express";
import { globalSearchService } from "../services/globalSearchService";
import { countGlobalSearchResults } from "../models/globalSearchModel";

export const globalSearch = async (req: Request, res: Response) => {
  try {
    const { query, page, limit } = req.query;
    const pageNumber = Number(page) || 1; // default page = 1
    const pageSize = Number(limit) || 10; // default pageSize = 10
    const count = await countGlobalSearchResults(query as string, pageSize);
    const result = await globalSearchService(
      req,
      query as string,
      pageNumber,
      pageSize
    );

    res.status(200).json({
      status: 200,
      result,
      pagination: {
        currentPage: Number(page),
        totalPages: count.totalPages,
        totalCount: count.totalCount,
      },
      message: "success",
    });
  } catch (error) {
    res.status(400).json({ message: "Global Search Not Found" });
  }
};
