import { Request, Response } from "express";
import {
  changePasswordFirstTime,
  forgotPasswordService,
  loginAdmin,
  registerAdmin,
  resetFirstPassword,
} from "../services/authService";
import { LoginRequestBody } from "../types/authType";

export const login = async (req: Request, res: Response) => {
  try {
    const credentials: LoginRequestBody = req.body;
    const result = await loginAdmin(credentials);
    res.status(200).json({
      status: 200,
      message: "Login successful",
      ...result,
    });
  } catch (error: any) {
    res
      .status(200)
      .json({ status: 400, message: error.message || "Login failed" });
  }
};

export const register = async (req: Request, res: Response) => {
  try {
    const result = await registerAdmin(req.body);
    res.status(201).json({
      status: 200,
      message: "Admin registered successfully",
      tempPassword: result.tempPassword,
      email: result.email,
    });
  } catch (error: any) {
    res.status(200).json({ status: 400, message: error.message });
  }
};

export const resetFirstPasswordController = async (
  req: Request,
  res: Response
) => {
  try {
    const result = await resetFirstPassword(req.body);
    res.status(200).json({
      status: 200,
      message: "Password reset successfully",
      data: result,
    });
  } catch (error: any) {
    res.status(200).json({ status: 400, message: error.message });
  }
};

export const forgotPassword = async (req: Request, res: Response) => {
  try {
    const { email } = req.body;

    const result = await forgotPasswordService(email);
    res.status(200).json({
      status: 200,
      result: result,
      message: "Email Has been successfully sent",
    });
  } catch {
    res.status(200).json({
      status: 400,
      message: "Failed to process forgot password request",
    });
  }
};
