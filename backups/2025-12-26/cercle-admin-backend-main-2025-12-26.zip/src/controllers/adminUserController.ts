import { Request, Response } from "express";
import {
  deleteUserService,
  getAllUserService,
  updateUserService,
} from "../services/adminUserService";
import { getAllUserCount } from "../models/adminUserModel";

export const getAllUsers = async (req: Request, res: Response) => {
  try {
    const { page = 1, limit = 10 } = req.query; // Default page 1, limit 10
    const userCount = await getAllUserCount(limit as number);
    const result = await getAllUserService(
      req,
      page as number,
      limit as number
    ); // Pass pagination to the service
    res.status(200).json({
      status: 200,
      message: "success",
      ...result,
      pagination: {
        currentPage: page,
        totalPages: userCount.totalPages,
        totalCount: userCount.totalCount,
      },
    });
  } catch (error: any) {
    res.status(400).json({
      status: 400,
      message: error.message || "Failed to fetch Users",
    });
  }
};
export const updateUser = async (req: Request, res: Response) => {
  try {
    const { id } = req.query;
    const { status } = req.body;

    const userData = await updateUserService(req, id, status);
    res.status(200).json({
      status: 200,
      message: "success",
      userData,
    });
  } catch (error: any) {
    res.status(400).json({
      status: 400,
      message: error.message || "Failed to update user",
    });
  }
};

export const deleteUser = async (req: Request, res: Response) => {
  try {
    const { id } = req.query;
    const userData = await deleteUserService(req, id);
    res.status(200).json({
      status: 200,
      message: "success",
      userData,
    });
  } catch (error: any) {
    res.status(400).json({
      status: 400,
      message: error.message || "Failed to delete user",
    });
  }
};
