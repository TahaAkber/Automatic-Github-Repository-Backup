import { Request, Response } from "express";
import {
  getAdminChargesService,
  getTrackingDetailsByTrackingId,
  updateAdminChargesService,
} from "../services/trackingService";
export const getTrackingDetails = async (req: Request, res: Response) => {
  try {
    const { trackingId } = req.query;
    const result = await getTrackingDetailsByTrackingId(Number(trackingId));
    res.status(200).json({
      status: 200,
      message: "success",
      ...result,
    });
  } catch (error: any) {
    res.status(400).json({
      status: 400,
      message: error.message || "Failed to get tracking details",
    });
  }
};

export const getAdminCharges = async (req: Request, res: Response) => {
  try {
    const result = await getAdminChargesService(req);

    res.status(200).json({
      status: 200,
      message: "success",
      result,
    });
  } catch (error: any) {
    res.status(400).json({
      status: 400,
      message: error.message || "Failed to get tracking details",
    });
  }
};

export const updateCharges = async (req: Request, res: Response) => {
  try {
    const { id, tracking_charges, reelNstory_charges } = req.body;
    const result = await updateAdminChargesService(
      req,
      Number(id),
      Number(tracking_charges),
      Number(reelNstory_charges),
    );
    res.status(200).json({
      status: 200,
      message: "Admin Charges Updated Successfully",
      result,
    });
  } catch (error: any) {
    res.status(400).json({
      status: 400,
      message: error.message || "Failed to update Admin charges",
    });
  }
};
