import { Request, Response } from "express";
import { getDashboardProductsService, getDashboardShopPriceService, getDashboardTransactionsService, getHighestSellerService } from "../services/dashboardService";

export const getDashboardTransactions = async (req: Request, res: Response) => {
  try {
    const result = await getDashboardTransactionsService(req);
    res.status(200).json({
      status: 200,
      message: "success",
      result,
    });
  } catch (error: any) {
    res.status(200).json({ status: 400, message: error.message });
  }
};



export const getDashboardShopProducts = async (req: Request, res: Response) => {
  try {
    const result = await getDashboardProductsService(req);
    res.status(200).json({
      status: 200,
      message: "success",
      result,
    });
  } catch (error: any) {
    res.status(200).json({ status: 400, message: error.message });
  }
};

export const getDashboardShopPrices = async (req: Request, res: Response) => {
  try {
     const result = await getDashboardShopPriceService(req);
     res.status(200).json({
       status: 200,
       message: "success",
       result,
     });
  } catch (error: any) {
    res.status(200).json({ status: 400, message: error.message });
  }
}

export const getDashboardBestSeller= async(req: Request, res: Response) => {
  try {
    const result = await getHighestSellerService(req);
    res.status(200).json({
      status: 200,
      message: "success",
      result,
    });
  } catch (error: any) {
    res.status(200).json({ status: 400, message: error.message });
  }
}