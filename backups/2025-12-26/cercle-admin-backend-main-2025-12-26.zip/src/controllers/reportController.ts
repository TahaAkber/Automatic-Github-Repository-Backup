import { Request, Response } from "express";
import { getAllReportsService, deleteReportService, updateReportStatusService } from "../services/reportService";

export const getAllReports = async(req: Request, res: Response) => {
    try {
        const { page = 1, limit = 10, search = "" ,typeFilter = "", statusFilter = ""} = req.query;
        const {data, pagination} = await getAllReportsService(req, page as number, limit as number, search as string,typeFilter as string, statusFilter as string);
        res.status(200).json({
            status: 200,
            message: "success",
            reports: data,
            pagination: {
                currentPage: page,
                totalPages: pagination.totalPages,
                totalCount: pagination.totalCount,
            },
        });
    } catch (error: any) {
        const statusCode = error.message === "Unauthorized" ? 401 : 400;
        res.status(statusCode).json({
            status: statusCode,
            message: error.message || "Failed to fetch reports",
        });
    }
}

export const deleteReport = async(req: Request, res: Response) => {
    try {
        const { id } = req.params;
        const reportId = parseInt(id);

        if (isNaN(reportId)) {
            res.status(400).json({
                status: 400,
                message: "Invalid report ID",
            });
            return;
        }

        const result = await deleteReportService(req, reportId);
        res.status(200).json({
            status: 200,
            message: result.message,
        });
    } catch (error: any) {
        const statusCode = error.message === "Unauthorized" ? 401 : error.message === "Report not found" ? 404 : 400;
        res.status(statusCode).json({
            status: statusCode,
            message: error.message || "Failed to delete report",
        });
    }
}

export const    updateReportStatus = async(req: Request, res: Response) => {
    try {
        const { id } = req.params;
        const { status, decision_description, decision_result } = req.body;
        const reportId = parseInt(id);

        if (isNaN(reportId)) {
            res.status(400).json({
                status: 400,
                message: "Invalid report ID",
            });
            return;
        }

        if (!status) {
            res.status(400).json({
                status: 400,
                message: "Status is required",
            });
            return;
        }

        if ((status === 'resolved' || status === 'rejected')) {
            if (!decision_description || !decision_result) {
                res.status(400).json({
                    status: 400,
                    message: "decision_description and decision_result are required for resolved/rejected status",
                });
                return;
            }
        }

        const decisionData = (status === 'resolved' || status === 'rejected')
            ? { decision_description, decision_result }
            : undefined;

        const result = await updateReportStatusService(req, reportId, status, decisionData);
        res.status(200).json({
            status: 200,
            message: result.message,
            decisionId: result.decisionId,
        });
    } catch (error: any) {
        const statusCode =
            error.message === "Unauthorized" ? 401 :
            error.message === "Report not found" ? 404 :
            error.message.includes("Invalid status") ? 400 :
            400;
        res.status(statusCode).json({
            status: statusCode,
            message: error.message || "Failed to update report status",
        });
    }
}