import { Request, Response, NextFunction } from "express";
import { roleService, updateUserRole } from "../services/roleService";
export const getRoles = async (
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const result = await roleService();
    if (result) {
      res.status(201).json({
        status: 200,
        result,
      });
    }
  } catch (error) {
    res.status(200).json({ status: 400, error });
  }
};

export const updateRole = async (req: Request, res: Response) => {
  try {
    const { id } = req.query;
    const body = req.body;

    const updateroles = await updateUserRole(id, body, req);
    if (updateroles) {
      res.status(200).json({
        status: 200,
        updateroles,
      });
    }
  } catch (error) {
    res.status(400).json({ status: 400, error });
  }
};
