import { Request, Response } from "express";
import {
  deletePlanService,
  plansService,
  updatePlanService,
  createPlanService,
} from "../services/planService";

export const getPlans = async (req: Request, res: Response) => {
  try {
    const { page = 1, limit = 10 } = req.query;
    const plans = await plansService(req, page as number, limit as number);
    res.status(200).json({
      status: 200,
      message: "success",
      ...plans,
      pagination: {
        currentPage: page,
        totalPages: plans.totalPages,
        totalCount: plans.totalCount,
      },
    });
  } catch (error: any) {
    res.status(400).json({
      status: 400,
      message: error.message || "Failed to fetch plans",
    });
  }
};

export const createPlans = async (req: Request, res: Response) => {
  try {
    const data = req.body;
    const result = await createPlanService(req, data);
    res.status(200).json({
      status: 200,
      result,
      message: "Successfully Created Plans",
    });
  } catch (error: any) {
    res.status(400).json({
      status: 400,
      message: error.message || "Failed to Create Plans",
    });
  }
};

export const updatePlans = async (req: Request, res: Response) => {
  try {
    const id = parseInt(req.params.id);
    const data = req.body;
    const result = await updatePlanService(req, data, id);
    res.status(200).json({
      status: 200,
      result,
      message: "Successfully Updated Plans",
    });
  } catch (error: any) {
    res.status(400).json({
      status: 400,
      message: error.message || "Failed to Update Plans",
    });
  }
};

export const deletePlans = async (req: Request, res: Response) => {
  try {
    const planId = parseInt(req.params.planId);
    const result = await deletePlanService(req, planId);
    res.status(200).json({
      status: 200,
      result,
      message: "Success",
    });
  } catch (error: any) {
    res.status(400).json({
      status: 400,
      message: error.message || "Failed to Update Plans",
    });
  }
};
