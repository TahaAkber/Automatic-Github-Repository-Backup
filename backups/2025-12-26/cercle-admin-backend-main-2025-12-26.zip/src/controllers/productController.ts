import { Request, Response } from "express";
import {
  getAllProductService,
  getProductDropdownService,
  getProductReviewsService,
} from "../services/productService";
import {
  getProductsReviewsCount,
  getTotalProductsCount,
} from "../models/productModel";

export const getAllProducts = async (req: Request, res: Response) => {
  try {
    const { page = 1, limit = 10, search = "" } = req.query; // Default page 1, limit 10

    const Count = await getTotalProductsCount(
      limit as number,
      search as string
    );

    const result = await getAllProductService(
      req,
      page as number,
      limit as number,
      search as string
    ); // Pass pagination to the service
    res.status(200).json({
      status: 200,
      message: "success",
      ...result,
      pagination: {
        currentPage: page,
        totalPages: Count.totalPages,
        totalCount: Count.totalCount,
      },
    });
  } catch (error: any) {
    res.status(400).json({
      status: 400,
      message: error.message || "Failed to fetch products",
    });
  }
};
export const getProductsDropdownList = async (req: Request, res: Response) => {
  try {
    const { page = 1, limit = 10, search = "" } = req.query; // Default page 1, limit 10

    const Count = await getTotalProductsCount(
      limit as number,
      search as string
    );

    const result = await getProductDropdownService(
      req,
      page as number,
      limit as number,
      search as string
    );
    res.status(200).json({
      status: 200,
      message: "success",
      ...result,
      pagination: {
        currentPage: page,
        totalPages: Count.totalPages,
        totalCount: Count.totalCount,
      },
    });
  } catch (error: any) {
    res.status(400).json({
      status: 400,
      message: error.message || "Failed to fetch products",
    });
  }
};

export const getProductReviews = async (req: Request, res: Response) => {
  try {
    const { page = 1, limit = 10, search = "" } = req.query; // Default page 1, limit 10

    const ReviewCount = await getProductsReviewsCount(
      page as number,

      limit as number,
      search as string
    );
    const result = await getProductReviewsService(
      req,
      page as number,
      limit as number,
      search as string
    );
    res.status(200).json({
      status: 200,
      message: "success",
      reviews:result,
      pagination: {
        currentPage: page,
        totalPages: ReviewCount.totalPages,
        totalCount: ReviewCount.totalCount,
      },
    });
  } catch (error: any) {
    res.status(400).json({
      status: 400,
      message: error.message || "Failed to fetch product Reviews",
    });
  }
};
