import { Request, Response } from "express";
import {
  getAllOrderService,
  getCancelOrderService,
  getItemsByOrderIdService,
  getOrderDetailService,
} from "../services/orderService";
import { getCancelOrderCount, getOrderCount } from "../models/orderModel";

export const getAllOrders = async (req: Request, res: Response) => {
  try {
    const { page = 1, limit = 10, shopName, fulfilementstatus } = req.query; // Default page 1, limit 10
    const orderCount = await getOrderCount(
      limit as number,
      shopName as string,
      fulfilementstatus as string
    );
    const result = await getAllOrderService(
      req,
      page as number,
      limit as number,
      shopName as string,
      fulfilementstatus as string
    ); // Pass pagination to the service
    res.status(200).json({
      status: 200,
      message: "success",
      orders: result,
      pagination: {
        currentPage: page,
        totalPages: orderCount.totalPages,
        totalCount: orderCount.totalCount,
      },
    });
  } catch (error: any) {
    res.status(400).json({
      status: 400,
      message: error.message || "Failed to fetch orders",
    });
  }
};

export const getOrderDetail = async (req: Request, res: Response) => {
  try {
    const id = req.params.id;
    const orderdetail = await getOrderDetailService(req, parseInt(id));
    res.status(200).json({
      status: 200,
      message: "success",
      ...orderdetail,
    });
  } catch (error: any) {
    res.status(400).json({
      status: 400,
      message: error.message || "Failed to get order details",
    });
  }
};

export const getOrderItems = async (req: Request, res: Response) => {
  try {
    const id = req.params.id;
    const orderItems = await getItemsByOrderIdService(req, parseInt(id));
    res.status(200).json({
      status: 200,
      message: "success",
      ...orderItems,
    });
  } catch (error: any) {
    res.status(400).json({
      status: 400,
      message: error.message || "Failed to get order Items",
    });
  }
};

export const getCancelOrders = async (req: Request, res: Response) => {
  try {
    const { page = 1, limit = 10, search = "", order_cancelled_by } = req.query;
    const orderCount = await getCancelOrderCount(
      page as number,
      limit as number,
      search as string,
      order_cancelled_by as string
    );

    const result = await getCancelOrderService(
      req,
      page as number,
      limit as number,
      search as string,
      order_cancelled_by as string
    );
    res.status(200).json({
      status: 200,
      message: "success",
      cancelOrders: result,
      pagination: {
        currentPage: page,
        totalPages: orderCount.totalPages,
        totalCount: orderCount.totalCount,
      },
    });
  } catch (error: any) {
    res.status(400).json({
      status: 400,
      message: error.message || "Failed to get cancel orders",
    });
  }
};
