import { Request, Response } from "express";
import {
  createTrendingCollectionService,
  deleteTrendingCollectionService,
  getCollectionByIdService,
  getCollections,
  updateTrendingCollectionService,
  updateTrendingStatusService,
} from "../services/collectionService";
import { getTotalCollectionsCount } from "../models/collectionModel";

export const getAllCollections = async (req: Request, res: Response) => {
  try {
    const { page = 1, limit = 10 } = req.query; // Default page 1, limit 10
    const count = await getTotalCollectionsCount(limit as number);
    const result = await getCollections(req, page as number, limit as number);
    res.status(200).json({
      status: 200,
      message: "success",
      ...result,
      pagination: {
        currentPage: page,
        totalPages: count.totalPages,
        totalCount: count.totalCount,
      },
    });
  } catch (error: any) {
    res.status(400).json({
      status: 400,
      message: error.message || "Failed to fetch collections",
    });
  }
};

export const createTrendingCollection = async (req: Request, res: Response) => {
  const {
    collection_Description,
    collection_Title,
    collection_image_url,
    end_Date,
  } = req.body;
  console.log("payload of data", req.body);
  try {
    const result = await createTrendingCollectionService(
      req,
      collection_Description,
      collection_Title,
      collection_image_url,
      end_Date
    );
    res.status(200).json({
      status: 200,
      message: "success",
      result,
    });
  } catch (error: any) {
    res.status(400).json({
      status: 400,
      message: error.message || "Failed to fetch collections",
    });
  }
};

export const deleteTrendingCollecton = async (req: Request, res: Response) => {
  const { trending_id } = req.query;
  try {
    const result = await deleteTrendingCollectionService(
      req,
      Number(trending_id)
    );
    res.status(200).json({
      status: 200,
      message: "Trending Collection deleted successfully",
      result,
    });
  } catch (error: any) {
    res.status(400).json({
      status: 400,
      message: error.message || "Failed to fetch collections",
    });
  }
};

export const updateTrendingCollectionStatus = async (
  req: Request,
  res: Response
) => {
  const { trending_id, is_active } = req.body;
  try {
    const result = await updateTrendingStatusService(
      req,
      Number(trending_id),
      is_active
    );
    res.status(200).json({
      status: 200,
      message: "Trending Collection status updated successfully",
      result,
    });
  } catch (error: any) {
    res.status(400).json({
      status: 400,
      message: error.message || "Failed to fetch collections",
    });
  }
};
export const getCollecionById = async (req: Request, res: Response) => {
  const { collection_id } = req.params;
  try {
    const result = await getCollectionByIdService(req, Number(collection_id));
    res.status(200).json({
      status: 200,
      message: "success",
      ...result,
    });
  } catch (error: any) {
    res.status(400).json({
      status: 400,
      message: error.message || "Failed to fetch collections",
    });
  }
};

export const updateTrendingCollection = async (req: Request, res: Response) => {
  const { collection_id, collection_Description, collection_image_url } =
    req.body;
  try {
    const result = await updateTrendingCollectionService(
      req,
      collection_id,
      String(collection_Description),
      collection_image_url
    );
    res.status(200).json({
      status: 200,
      message: "Trending Collection updated successfully",
      result,
    });
  } catch (error: any) {
    res.status(400).json({
      status: 400,
      message: error.message || "Failed to fetch collections",
    });
  }
};
