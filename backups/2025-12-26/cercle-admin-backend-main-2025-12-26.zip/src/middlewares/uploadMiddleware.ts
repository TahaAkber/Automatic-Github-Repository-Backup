import multer from "multer";
import path from "path";
import fs from "fs";

// Allowed file types for images and videos
const allowedMimeTypes = [
  "image/png",
  "image/jpeg",
  "image/jpg",
  "image/gif",
  "image/webp",
  "video/mp4",
  "video/quicktime",
  "video/x-msvideo",
  "video/x-ms-wmv",
  "video/mpeg",
  "video/webm",
];

// Multer Storage Configuration
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    try {
      let baseUploadDir = "src/uploads"; // Base uploads folder
      let folderPath = baseUploadDir; // Default path

      console.log("req params", req.query);

      // Determine folder structure from request body/params
      if (req.query.userId) {
        folderPath = path.join(
          baseUploadDir,
          "users",
          req.query?.userId as string,
          "profile"
        );
      } else if (req.query.reviewId) {
        folderPath = path.join(
          baseUploadDir,
          "users",
          "reviews",
          req.query?.reviewId as string
        );
      }

      // Ensure the directory exists before saving the file
      if (!fs.existsSync(folderPath)) {
        fs.mkdirSync(folderPath, { recursive: true }); // Create folders recursively
      }

      cb(null, folderPath);
    } catch (error) {
      cb(error as any, "");
    }
  },

  filename: (req, file, cb) => {
    const uniqueSuffix = `${Date.now()}-${Math.round(Math.random() * 1e9)}`;
    cb(null, uniqueSuffix + path.extname(file.originalname)); // Unique filename
  },
});

// File Filter Function
const fileFilter = (
  req: any,
  file: Express.Multer.File,
  cb: multer.FileFilterCallback
) => {
  if (allowedMimeTypes.includes(file.mimetype)) {
    cb(null, true);
  } else {
    cb(new Error("Invalid file type. Only images and videos are allowed."));
  }
};

// Multer Upload Middleware
export const upload = multer({ storage, fileFilter });
