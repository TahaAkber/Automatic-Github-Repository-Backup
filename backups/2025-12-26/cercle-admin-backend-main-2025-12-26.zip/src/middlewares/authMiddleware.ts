import { Request, Response, NextFunction } from "express";
import jwt from "jsonwebtoken";

// Create a middleware to validate JWT token
export const validateToken = (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  const token = req.headers.authorization?.split(" ")[1]; // Get the token from 'Bearer <token>'

  if (!token) {
    return res
      .status(401)
      .json({ message: "Access denied. No token provided." });
  }

  try {
    // Verify the token using the secret
    const decoded = jwt.verify(
      token,
      process.env.JWT_SECRET || "default_secret"
    ) as { id: number; email: string; username: string; roles: string[] };

    // Attach the decoded data to the request object for further use
    req.user = decoded; // `user` will hold decoded token details

    // Pass control to the next middleware or route handler
    next();
  } catch (error: any) {
    // Token is invalid or expired
    console.error("Token verification failed:", error.message);
    return res.status(401).json({ message: "Invalid or expired token." });
  }
};
