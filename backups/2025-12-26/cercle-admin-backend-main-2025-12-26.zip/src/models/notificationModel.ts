import { poolPromise } from "../config/db";
import sql from "mssql";

export const getAllInAppNotificationsFromDB = async (
  page: number,
  limit: number
) => {
  const offset = (page - 1) * limit;

  const query = `
    SELECT 
        [app_notification_id],
        [app_notification_user_id],
        [app_notification_title],
        [app_notification_read],
        [app_notification_body],
        [app_notification_device_token],
        [app_notification_type],
        [app_notification_screen_name],
        [app_notifcation_schedule_type],
        [app_notification_time_slot],
        [app_notification_image_url], 
        [app_notification_active],
        [created_at]
    FROM [cymbiote].[dbo].[App_Notifications]
    WHERE [app_notifcation_schedule_type] IS NULL -- ✅ fetch only non-scheduled
    ORDER BY [created_at] DESC
    OFFSET @offset ROWS
    FETCH NEXT @limit ROWS ONLY;
  `;

  try {
    const pool = await poolPromise;

    const notifications = await pool
      .request()
      .input("offset", sql.Int, offset)
      .input("limit", sql.Int, limit)
      .query(query);

    return {
      notifications: notifications.recordset,
    };
  } catch (error: any) {
    throw new Error("Error fetching notifications: " + error.message);
  }
};

export const getNotificationCount = async (limit: number) => {
  const countQuery = `SELECT COUNT(*) AS totalCount FROM [cymbiote].[dbo].[App_Notifications]     WHERE [app_notifcation_schedule_type] IS NULL`;
  const pool = await poolPromise;

  try {
    const countResult = await pool.request().query(countQuery);
    const totalCount = countResult.recordset[0].totalCount;
    const totalPages = Math.ceil(totalCount / limit);
    return { totalCount, totalPages };
  } catch (error: any) {
    throw new Error("Error fetching notification count: " + error.message);
  }
};
export const getScheduledNotificationCount = async (limit: number) => {
  const countQuery = `SELECT COUNT(*) AS totalCount FROM [cymbiote].[dbo].[App_Notifications]     WHERE [app_notifcation_schedule_type] IS NOT NULL`;
  const pool = await poolPromise;

  try {
    const countResult = await pool.request().query(countQuery);
    const totalCount = countResult.recordset[0].totalCount;
    const totalPages = Math.ceil(totalCount / limit);
    return { totalCount, totalPages };
  } catch (error: any) {
    throw new Error("Error fetching notification count: " + error.message);
  }
};

export const deleteInAppNotificationFromDB = async (id: number) => {
  const query = `
    DELETE FROM [cymbiote].[dbo].[App_Notifications]
    WHERE [app_notification_id] = @id
  `;

  try {
    const pool = await poolPromise;
    const result = await pool.request().input("id", sql.Int, id).query(query);

    return {
      success: result.rowsAffected[0] > 0,
      message:
        result.rowsAffected[0] > 0
          ? "Notification deleted successfully"
          : "Notification not found",
    };
  } catch (error: any) {
    throw new Error("Error deleting notification: " + error.message);
  }
};

const asDateOrNull = (v?: Date | string | null) => {
  if (!v) return null;
  const d = v instanceof Date ? v : new Date(v);
  return isNaN(d.getTime()) ? null : d;
};

export const createInAppNotificationInDB = async (data: {
  app_notification_user_id: number | null;
  app_notification_title: string;
  app_notification_body: string;
  app_notification_type?: string | null;
  app_notification_screen_name?: string | null;
  app_notifcation_schedule_type?: string | null;
  app_notification_shop_id?: number | null;
  app_notification_product_ids?: number[]; // multiple products
  app_notification_starts_at?: Date | string | null;
  app_notification_ends_at?: Date | string | null;
  app_notification_image_url?: string | null;
}) => {
  const query = `
    INSERT INTO [cymbiote].[dbo].[App_Notifications]
    (
      [app_notification_user_id],
      [app_notification_title],
      [app_notification_body],
      [app_notification_type],
      [app_notification_screen_name],
      [app_notifcation_schedule_type],
      [app_notification_image_url],
      [app_notification_shop_id],
      [app_notification_starts_at],
      [app_notification_ends_at],
      [created_at]
    )
    VALUES
    (
      @userId,
      @title,
      @body,
      @type,
      @screenName,
      @scheduleType,
      @imageUrl,
      @shopId,
      @startsAt,
      @endsAt,
      GETDATE()
    );
    SELECT SCOPE_IDENTITY() AS insertedId;
  `;

  try {
    const pool = await poolPromise;

    const result = await pool
      .request()
      .input("userId", sql.Int, data.app_notification_user_id ?? null)
      .input("title", sql.NVarChar, data.app_notification_title)
      .input("body", sql.NVarChar, data.app_notification_body)
      .input("type", sql.NVarChar, data.app_notification_type ?? null)
      .input(
        "screenName",
        sql.NVarChar,
        data.app_notification_screen_name ?? null
      )
      .input(
        "scheduleType",
        sql.NVarChar,
        data.app_notifcation_schedule_type ?? null
      )
      .input("imageUrl", sql.NVarChar, data.app_notification_image_url ?? null)
      .input("shopId", sql.Int, data.app_notification_shop_id ?? null)
      .input("startsAt", sql.DateTime, data.app_notification_starts_at ?? null)
      .input("endsAt", sql.DateTime, data.app_notification_ends_at ?? null)
      .query(query);

    const insertedId = result.recordset[0].insertedId;

    // insert multiple products into mapping table
    if (Array.isArray(data.app_notification_product_ids)) {
      for (const productId of data.app_notification_product_ids) {
        await pool
          .request()
          .input("notificationId", sql.Int, insertedId)
          .input("productId", sql.Int, productId).query(`
            INSERT INTO App_Notification_Products (app_notification_id, product_id)
            VALUES (@notificationId, @productId)
          `);
      }
    }

    return {
      success: true,
      message: "Notification created successfully",
      id: insertedId,
    };
  } catch (error: any) {
    throw new Error("Error creating notification: " + error.message);
  }
};

export const getScheduledAppNotificationsFromDB = async (
  page: number,
  limit: number
) => {
  const offset = (page - 1) * limit;

  const query = `
    SELECT 
        [app_notification_id],
        [app_notification_user_id],
        [app_notification_title],
        [app_notification_read],
        [app_notification_body],
        [app_notification_device_token],
        [app_notification_type],
        [app_notification_screen_name],
        [app_notifcation_schedule_type],
        [app_notification_starts_at],
        [app_notification_ends_at],
        [app_notification_time_slot],
        [app_notification_image_url], 
        [app_notification_active],
        [created_at]
    FROM [cymbiote].[dbo].[App_Notifications]
    WHERE [app_notifcation_schedule_type] IS NOT NULL 
    ORDER BY [created_at] DESC
    OFFSET @offset ROWS
    FETCH NEXT @limit ROWS ONLY;
  `;

  try {
    const pool = await poolPromise;

    const notificationsResult = await pool
      .request()
      .input("offset", sql.Int, offset)
      .input("limit", sql.Int, limit)
      .query(query);

    const now = new Date();

    // ✅ Add status based on start/end time
    const notificationsWithStatus = notificationsResult.recordset.map((n) => {
      const startsAt = n.app_notification_starts_at
        ? new Date(n.app_notification_starts_at)
        : null;
      const endsAt = n.app_notification_ends_at
        ? new Date(n.app_notification_ends_at)
        : null;

      let status = "pending"; // default

      if (startsAt && startsAt > now) {
        status = "pending";
      } else if (endsAt && endsAt < now) {
        status = "ended";
      } else if (startsAt && startsAt <= now && (!endsAt || endsAt >= now)) {
        status = "ongoing";
      }

      return {
        ...n,
        status, // ✅ add status field to each notification
      };
    });

    return {
      notifications: notificationsWithStatus,
    };
  } catch (error: any) {
    throw new Error("Error fetching notifications: " + error.message);
  }
};

export async function setNotificationActiveToggle(id: number, active: boolean) {
  const pool = await poolPromise;
  const result = await pool
    .request()
    .input("id", sql.Int, id)
    .input("active", sql.Bit, active).query(`
      UPDATE App_Notifications
      SET app_notification_active = @active
      OUTPUT INSERTED.app_notification_id, INSERTED.app_notification_active
      WHERE app_notification_id = @id
    `);

  return result.recordset[0];
}
