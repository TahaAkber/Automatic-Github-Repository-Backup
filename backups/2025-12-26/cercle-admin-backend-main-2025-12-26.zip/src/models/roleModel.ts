import { poolPromise } from "../config/db";

export const GetUserRoles = async (): Promise<any[]> => {
  try {
    const pool = await poolPromise;

    const result = await pool.request().query("SELECT * FROM Admin_Roles");

    if (result.recordset.length > 0) {
      return result.recordset;
    } else {
      return [];
    }
  } catch (error) {
    console.error("Error fetching roles:", error);
    throw error;
  }
};
