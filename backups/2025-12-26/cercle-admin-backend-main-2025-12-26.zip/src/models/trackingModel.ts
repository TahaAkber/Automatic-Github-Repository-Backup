import { poolPromise } from "../config/db";

export const getTrackingDetailsFromDb = async (trackingId: number) => {
  try {
    const pool = await poolPromise;

    // Query 1: Get all Tracking_Order_Items rows with the given trackingId
    const trackingOrderItemResult = await pool
      .request()
      .input("trackingId", trackingId).query(`
        SELECT * 
        FROM Tracking_Order_Items
        WHERE tracking_id = @trackingId
      `);

    if (trackingOrderItemResult.recordset.length === 0) {
      return { message: "Tracking order item not found" };
    }

    const trackingOrderItems = trackingOrderItemResult.recordset;

    // Query 2: Get the main Tracking row
    const trackingResult = await pool.request().input("trackingId", trackingId)
      .query(`
        SELECT * 
        FROM Tracking 
        WHERE id = @trackingId
      `);

    const tracking = trackingResult.recordset[0];

    // Query 3: Get the associated Order from tracking_order_id
    const orderResult = await pool
      .request()
      .input("orderId", tracking.tracking_order_id).query(`
        SELECT * 
        FROM Orders 
        WHERE order_id = @orderId
      `);

    return {
      trackingOrderItems,
      tracking: tracking || null,
      order: orderResult.recordset[0] || null,
    };
  } catch (error) {
    console.error("Error getting tracking details:", error);
    throw error;
  }
};

export const getAdminChargesFromDb = async () => {
  try {
    const pool = await poolPromise;
    const result = await pool.request().query(`
      SELECT * 
      FROM [Admin_Settings] 
    `);
    return result.recordset[0];
  } catch (error) {
    console.error("Error getting tracking charges:", error);
    throw error;
  }
};

export const updateAdminCharges = async (
  id: number, 
  tracking_charges: number, 
  reelNstory_charges:number
) => {
  try {
    const pool = await poolPromise;
    
    const request = pool.request().input("id", id);
    const updates: string[] = [];

    // Check for valid numbers (not undefined, null, or NaN)
    if (tracking_charges !== undefined && tracking_charges !== null && !isNaN(tracking_charges)) {
      updates.push("admin_tracking_sub_charges = @tracking_charges");
      request.input("tracking_charges", tracking_charges);
    }

    if (reelNstory_charges !== undefined && reelNstory_charges !== null && !isNaN(reelNstory_charges)) {
      updates.push("admin_reelNstory_charges = @reelNstory_charges");
      request.input("reelNstory_charges", reelNstory_charges);
    }


    if (updates.length === 0) {
       return null; 
    }

    const query = `
      UPDATE Admin_Settings 
      SET ${updates.join(", ")}
      WHERE admin_setting_id = @id
    `;

    const result = await request.query(query);
    return result.recordset;
  } catch (error) {
    console.error("Error updating admin charges:", error);
    throw error;
  }
};
