import { poolPromise } from "../config/db";
import sql from "mssql";

export const getPlansFromDB = async (page: number, limit: number) => {
  const offset = (page - 1) * limit; // Calculate the offset for the query

  const query = `
   SELECT 
  p.*
  FROM Packages p
ORDER BY p.package_id DESC
OFFSET @offset ROWS
FETCH NEXT @limit ROWS ONLY;

  `;

  const countQuery = `SELECT COUNT(*) AS totalCount FROM Packages`;

  try {
    const pool = await poolPromise;

    const plansResult = await pool
      .request()
      .input("offset", sql.Int, offset)
      .input("limit", sql.Int, limit)
      .query(query);

    const countResult = await pool.request().query(countQuery);
    const totalCount = countResult.recordset[0].totalCount;
    const totalPages = Math.ceil(totalCount / limit);

    return {
      plansResult: plansResult.recordset,
      totalCount,
      totalPages,
    };
  } catch (error: any) {
    throw new Error("Error fetching Plans: " + error.message);
  }
};

type Package = {
  package_name: string;
  package_rate: number;
  package_description: string;
  package_order_limit: number;
  package_limit_exceed_charges: number;
  package_trial_days: number;
  package_charges: number;
  package_video_count: number;
};

export const createPlansinDb = async (data: Package) => {
  const {
    package_name,
    package_rate,
    package_description,
    package_order_limit,
    package_limit_exceed_charges,
    package_trial_days,
    package_charges,
  } = data;

  const query = `
    INSERT INTO Packages 
    (package_name, package_charges, package_rate, package_order_limit, 
     package_limit_exceed_charges, package_trial_days, package_description)
    VALUES 
    (@package_name, @package_charges, @package_rate, @package_order_limit, 
     @package_limit_exceed_charges, @package_trial_days, @package_description)
  `;

  const pool = await poolPromise;

  try {
    await pool
      .request()
      .input("package_name", package_name)
      .input("package_charges", package_charges)
      .input("package_rate", package_rate)
      .input("package_order_limit", package_order_limit)
      .input("package_limit_exceed_charges", package_limit_exceed_charges)
      .input("package_trial_days", package_trial_days)
      .input("package_description", package_description)
      .query(query);

    const result = await pool
      .request()
      .input("package_name", package_name)
      .query(`SELECT * FROM Packages WHERE package_name = @package_name`);

    const newPlans = result.recordset[0];
    return newPlans;
  } catch (error) {
    console.error("Error creating plans:", error);
    throw new Error("Database operation failed.");
  }
};

export const updatePlansInDb = async (data: Package, id: number) => {
  const pool = await poolPromise;

  const fields: string[] = [];
  const request = pool.request();

  Object.entries(data).forEach(([key, value]) => {
    if (value !== undefined && value !== null) {
      fields.push(`${key} = @${key}`);
      request.input(key, value);
    }
  });

  if (fields.length === 0) {
    throw new Error("No valid fields provided to update.");
  }

  const query = `
    UPDATE Packages
    SET ${fields.join(", ")}
    WHERE package_id = @id
  `;

  try {
    await request.input("id", id).query(query);

    const result = await pool
      .request()
      .input("id", id)
      .query(`SELECT * FROM Packages WHERE package_id = @id`);

    return result.recordset[0];
  } catch (error) {
    console.error("Error updating plan:", error);
    throw new Error("Database operation failed.");
  }
};

export const deletePlanInDb = async (planId: number) => {
  const pool = await poolPromise;

  try {
    const checkQuery = `SELECT COUNT(*) AS planExists FROM Packages WHERE package_id = @planId`;
    const checkResult = await pool
      .request()
      .input("planId", planId)
      .query(checkQuery);

    const planExists = checkResult.recordset[0].planExists;

    if (planExists > 0) {
      const deleteQuery = `DELETE FROM Packages WHERE package_id = @planId`;
      const deleteResult = await pool
        .request()
        .input("planId", planId)
        .query(deleteQuery);

      return deleteResult;
    } else {
      return {
        message: `Plan with package_id ${planId} does not exist. DB call`,
      };
    }
  } catch (error) {
    console.error("Error deleting plan: ", error);
    throw new Error("Error deleting plan");
  }
};
