import { poolPromise } from "../config/db";

export const performGlobalSearch = async (
  query: string,
  page: number,
  pageSize: number
) => {
  const pool = await poolPromise;
  let offset = (page - 1) * pageSize;
  const Searchquery = `
    SELECT 
    source, id, title, image_url, description
    FROM (
    SELECT 'Shops' AS source, 
			1 AS sort_order,	
           shop_id AS id,
		   shop_logo_url AS image_url,
           shop_name AS title, 
           CAST(shop_description AS NVARCHAR(MAX)) AS description
    FROM Shops
    WHERE shop_name LIKE '%' + @searchText + '%'
    
    UNION ALL
    
    SELECT 'Products' AS source, 
			2 AS sort_order,	
           product_id AS id, 
		   product_image_url AS image_url,
           product_name AS title, 
           CAST(product_description AS NVARCHAR(MAX)) AS description
    FROM Products
    WHERE product_name LIKE '%' + @searchText + '%' 
       OR product_description LIKE '%' + @searchText + '%'
    
    UNION ALL
    
    SELECT 'Users' AS source,
			3 AS sort_order,	
           admin_user_id AS id,
		   NULL AS image_url,
           admin_user_name AS title,
           CAST(admin_user_email AS NVARCHAR(MAX)) AS description
    FROM Admin_Users 
    WHERE admin_user_name LIKE '%' + @searchText + '%' OR admin_user_email LIKE '%'+ @searchText + '%'
    ) AS GlobalSearch
    ORDER BY sort_order, id  
    OFFSET @offset ROWS
    FETCH NEXT @pageSize ROWS ONLY;
`;
  try {
    const searchResult = await pool
      .request()
      .input("searchText", query)
      .input("offset", offset)
      .input("pageSize", pageSize)
      .query(Searchquery);

    return searchResult.recordset;
  } catch (error: any) {
    throw new Error("Error fetching search " + error.message);
  }
};

export const countGlobalSearchResults = async (
  query: string,
  pageSize: number
) => {
  const pool = await poolPromise;
  const countQuery = `WITH GlobalSearch AS (
    SELECT 'Shops' AS source, shop_id AS id
    FROM Shops WHERE shop_name LIKE '%' + @searchText + '%'
    UNION ALL
    SELECT 'Products', product_id
    FROM Products WHERE product_name LIKE '%' + @searchText + '%'
                     OR product_description LIKE '%' + @searchText + '%'
    UNION ALL
    SELECT 'Admin User', admin_user_id
    FROM Admin_Users WHERE admin_user_name LIKE '%' + @searchText + '%'
                 OR admin_user_email LIKE '%' + @searchText + '%'
    )
    SELECT 
    COUNT(*) AS total_count,
    CEILING(COUNT(*) * 1.0 / @pageSize) AS total_pages
    FROM GlobalSearch;`;

  try {
    const countResult = await pool
      .request()
      .input("searchText", query)
      .input("pageSize", pageSize)
      .query(countQuery);

    const totalCount = countResult.recordset[0].total_count;
    const totalPages = Math.ceil(totalCount / pageSize);

    return {
      totalCount,
      totalPages,
    };
  } catch (error: any) {
    throw new Error("Error counting search results: " + error.message);
  }
};
