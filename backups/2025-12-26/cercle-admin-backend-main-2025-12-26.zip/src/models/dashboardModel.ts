import { poolPromise } from "../config/db";
import dotenv from "dotenv";
import { sumInPKRWithLiveRates } from "../functions/currencyFunction";
import { getShopProductStats } from "../functions/shopProductsRank";
import {
  buildCurrencyTotals,
  buildNetRevenueByCurrency,
  convertNetRevenueToPKR,
  convertTotalsToPKR,
} from "../functions/currencyBuilder";

dotenv.config();

export const getDashboardTransactionsModel = async () => {
  const productCountQuery = `SELECT COUNT(*) AS product_count FROM Products;`;
  const userCountQuery = `SELECT COUNT(*) AS user_count FROM Users;`;
  const adminCountQuery = `SELECT COUNT(*) AS admin_count FROM Admin_Users;`;
  const shopCountQuery = `SELECT COUNT(*) AS shop_count FROM Shops;`;
  const CercleRevenueByCurrency = `
    SELECT
      UPPER(ISNULL(s.shop_currency, 'UNKNOWN')) AS shop_currency,
      SUM(CASE WHEN UPPER(t.transaction_type) = 'SUBSCRIPTION' THEN t.transaction_amount ELSE 0 END) AS subscription_total,
      SUM(CASE WHEN UPPER(t.transaction_type) = 'USAGE'        THEN t.transaction_amount ELSE 0 END) AS usage_total,
      SUM(CASE WHEN UPPER(t.transaction_type) = 'CREDIT'       THEN t.transaction_amount ELSE 0 END) AS credit_total
    FROM Transactions t
    LEFT JOIN Shops s ON s.shop_id = t.transaction_shop_id
    GROUP BY UPPER(ISNULL(s.shop_currency, 'UNKNOWN'));
  `;

  const orderAmountQuery = `
    SELECT 
      s.shop_id,
      UPPER(ISNULL(s.shop_currency, 'UNKNOWN')) AS shop_currency,
      SUM(o.order_total_amount) AS total_amount
    FROM Shops s
    JOIN Orders o ON s.shop_id = o.order_shop_id
    WHERE o.order_fulfillment_status = 'fulfilled'
      AND o.order_channel = @channel
    GROUP BY s.shop_id, UPPER(ISNULL(s.shop_currency, 'UNKNOWN'));
  `;

  try {
    const pool = await poolPromise;

    const [
      cercleRevenueCurResult,
      userCountresult,
      productCountresult,
      adminUserCount,
      shopCountResult,
      orderAmountresult,
    ] = await Promise.all([
      pool.request().query(CercleRevenueByCurrency),
      pool.request().query(userCountQuery),
      pool.request().query(productCountQuery),
      pool.request().query(adminCountQuery),
      pool.request().query(shopCountQuery),
      pool
        .request()
        .input("channel", process.env.APP_NAME || "CERCLE")
        .query(orderAmountQuery),
    ]);

    const orderRows = orderAmountresult?.recordset || [];

    const currencyTotals = buildCurrencyTotals(orderRows);

    const { totalPKR, breakdownPKR, unknownCurrencies, ratesToPKR } =
      await convertTotalsToPKR(currencyTotals, sumInPKRWithLiveRates);

    const revRows = cercleRevenueCurResult?.recordset || [];
    const netByCurrency = buildNetRevenueByCurrency(revRows);
    const cercleRevenuePKR = await convertNetRevenueToPKR(
      netByCurrency,
      sumInPKRWithLiveRates
    );

    const adminCount = Number(adminUserCount?.recordset?.[0]?.admin_count ?? 0);
    const shopCount = Number(shopCountResult?.recordset?.[0]?.shop_count ?? 0);
    const userCount = Number(userCountresult?.recordset?.[0]?.user_count ?? 0);
    const productCount = Number(
      productCountresult?.recordset?.[0]?.product_count ?? 0
    );
    return {
      cercleRevenue: cercleRevenuePKR,
      userCount,
      productCount,
      adminCount,
      shopCount,
      orderAmountPKR: totalPKR,
      orderCurrencyBreakdown: {
        currencyTotals,
        breakdownPKR,
        unknownCurrencies,
        ratesToPKR,
      },
    };
  } catch (error: any) {
    console.error("Error while fetching Transactions:", error?.message);
    throw error;
  }
};

export const getDashboardProductsModel = async () => {
  try {
    const pool = await poolPromise;

    const itemsQuery = `
      SELECT 
        oi.order_item_variant_id,
        o.order_id,
        o.order_total_amount,
        s.shop_currency,
        p.product_name,
        p.product_image_url,
        p.product_id,
        s.shop_id,
        s.shop_name,
        s.shop_logo_url
      FROM Orders o
      JOIN Order_Items oi
        ON oi.order_id = o.order_id
      JOIN Product_Variants pv
        ON pv.variant_id = oi.order_item_variant_id
      JOIN Products p
        ON p.product_id = pv.variant_product_id
      JOIN Shops s
        ON s.shop_id = p.product_shop_id
      WHERE
        o.order_fulfillment_status = 'fulfilled'
        AND o.order_channel = @channel
        AND o.order_date >= DATEADD(DAY, -30, GETDATE());
    `;

    const orderAmountQuery = `
      SELECT 
        s.shop_id,
        UPPER(ISNULL(s.shop_currency, 'UNKNOWN')) AS shop_currency,
        SUM(o.order_total_amount) AS total_amount
      FROM Shops s
      JOIN Orders o ON s.shop_id = o.order_shop_id
      WHERE
        o.order_fulfillment_status = 'fulfilled'
        AND o.order_channel = @channel
        AND o.order_date >= DATEADD(DAY, -30, GETDATE())
      GROUP BY s.shop_id, UPPER(ISNULL(s.shop_currency, 'UNKNOWN'));
    `;

    const [itemsRes, orderAmountRes] = await Promise.all([
      pool
        .request()
        .input("channel", process.env.APP_NAME || "CERCLE")
        .query(itemsQuery),
      pool
        .request()
        .input("channel", process.env.APP_NAME || "CERCLE")
        .query(orderAmountQuery),
    ]);

    const ordersRaw = itemsRes?.recordset || [];

    const orderRows = orderAmountRes?.recordset || [];
    const currencyTotals = buildCurrencyTotals(orderRows);

    const { totalPKR, ratesToPKR } = await convertTotalsToPKR(
      currencyTotals,
      sumInPKRWithLiveRates
    );

    const numericRate = (cur: string): number => {
      const key = (cur || "UNKNOWN").toUpperCase();
      const r = (ratesToPKR as any)?.[key];
      if (typeof r === "number" && Number.isFinite(r)) return r;
      if (key === "PKR") return 1;
      return 0;
    };

    const ordersConverted = ordersRaw.map((o: any) => {
      const rate = numericRate(o.shop_currency);
      const rawAmt = Number(o.order_total_amount ?? 0);
      const pkrAmt = Number.isFinite(rawAmt) ? rawAmt * rate : 0;
      return {
        ...o,
        order_total_amount: pkrAmt,
      };
    });

    const rankedShops = getShopProductStats(ordersConverted);

    return {
      totalAmountInPKR: totalPKR,
      ratesToPKR,
      rankedShops,
    };
  } catch (error: any) {
    console.error("Error while fetching Products:", error?.message);
    throw error;
  }
};

export const getDashboardShopPricesModel = async () => {
  const pool = await poolPromise;

  const query = `
  SELECT 
  TOP(7)
    s.shop_id,
    s.shop_currency,
    s.shop_name,
    SUM(o.order_total_amount) AS total_amount
  FROM Shops s
  JOIN Orders o ON s.shop_id = o.order_shop_id
  WHERE 
    o.order_fulfillment_status = 'fulfilled'
    AND o.order_channel = @channel
    AND o.order_date >= DATEADD(DAY, -7, GETDATE())
    AND o.order_date < GETDATE()
  GROUP BY s.shop_id, s.shop_currency, s.shop_name
  ORDER BY SUM(o.order_total_amount) DESC;
  `;

  try {
    const result = await pool
      .request()
      .input("channel", process.env.APP_NAME || "CERCLE")
      .query(query);

    const shopOrderPrices =
      (result?.recordset as Array<{
        shop_id: number | string;
        shop_currency?: string;
        total_amount?: number;
      }>) || [];

    const currencyTotals = buildCurrencyTotals(
      shopOrderPrices.map((r) => ({
        shop_currency: r.shop_currency,
        total_amount: r.total_amount,
      }))
    );

    const { totalPKR, breakdownPKR, unknownCurrencies, ratesToPKR } =
      await convertTotalsToPKR(currencyTotals, sumInPKRWithLiveRates);

    const numericRate = (cur?: string): number => {
      const key = String(cur || "UNKNOWN").toUpperCase();
      const r = (ratesToPKR as any)?.[key];
      if (typeof r === "number" && Number.isFinite(r)) return r;
      if (key === "PKR") return 1;
      return 0;
    };

    const shopsWithPKR = shopOrderPrices.map((row) => {
      const rate = numericRate(row.shop_currency);
      const raw = Number(row.total_amount ?? 0);
      const total_amount_pkr = Number.isFinite(raw) ? raw * rate : 0;
      return {
        ...row,
        total_amount_pkr,
      };
    });
    return {
      currencyDetails: {
        totalAmountInPKR: totalPKR,
        breakdownPKR,
        unknownCurrencies,
        ratesToPKR,
      },
      shops: shopsWithPKR,
    };
  } catch (error: any) {
    console.error("Error while fetching Transactions:", error?.message);
    throw error;
  }
};

export const getHighestSellerModel = async () => {
  const pool = await poolPromise;

  const query = `
    DECLARE @monthStart DATE = DATEFROMPARTS(YEAR(GETDATE()), MONTH(GETDATE()), 1);

    SELECT TOP (1)
      s.shop_id,
      s.shop_name,
      UPPER(ISNULL(s.shop_currency, 'UNKNOWN')) AS shop_currency,
      COUNT(DISTINCT o.order_id)                AS order_count,
      SUM(ISNULL(o.order_total_amount, 0))      AS total_amount
    FROM Shops s
    JOIN Orders o
      ON s.shop_id = o.order_shop_id
    WHERE
      UPPER(LTRIM(RTRIM(o.order_fulfillment_status))) = 'FULFILLED'
      AND UPPER(LTRIM(RTRIM(o.order_channel))) = UPPER(@channel)
      AND o.order_date >= @monthStart
      AND o.order_date <  GETDATE()
    GROUP BY
      s.shop_id, s.shop_name, UPPER(ISNULL(s.shop_currency, 'UNKNOWN'))
    ORDER BY
      order_count DESC,
      total_amount DESC;
  `;

  // Stable fallback so frontend never breaks
  const FALLBACK = {
    shop_id: "—",
    shop_name: "No Top Seller",
    shop_currency: "PKR",
    order_count: 0,
    total_amount: 0,
    total_amount_pkr: 0,
    ratesToPKR: { PKR: 1 } as Record<string, number | string>,
  };

  try {
    const result = await pool
      .request()
      .input("channel", process.env.APP_NAME || "cymbiote")
      .query(query);

    const top =
      (result?.recordset?.[0] as
        | {
            shop_id: number | string;
            shop_name: string;
            shop_currency?: string;
            order_count: number;
            total_amount: number;
          }
        | undefined) || null;

    if (!top) return FALLBACK;

    // Build a single-currency total for conversion
    const currencyTotals = buildCurrencyTotals([
      {
        shop_currency: top.shop_currency,
        total_amount: top.total_amount,
      },
    ]);

    // Try conversion, fall back to PKR-only
    let totalPKR = 0;
    let ratesToPKR: Record<string, number | string> = { PKR: 1 };
    try {
      const res = await convertTotalsToPKR(
        currencyTotals,
        sumInPKRWithLiveRates
      );
      totalPKR = Number(res.totalPKR ?? 0) || 0;
      ratesToPKR = res.ratesToPKR || { PKR: 1 };
    } catch {
      // keep defaults
    }

    return {
      shop_id: top.shop_id,
      shop_name: top.shop_name ?? String(top.shop_id),
      shop_currency: (top.shop_currency ?? "UNKNOWN").toUpperCase(),
      order_count: Number(top.order_count) || 0,
      total_amount: Number(top.total_amount) || 0,
      total_amount_pkr: totalPKR,
      ratesToPKR,
    };
  } catch (error: any) {
    console.error("Error while fetching Highest Seller:", error?.message);
    return FALLBACK;
  }
};
