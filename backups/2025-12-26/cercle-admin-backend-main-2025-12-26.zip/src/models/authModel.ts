import { poolPromise } from "../config/db";
import sql from "mssql";
import { Admin_Users } from "../types/authType";
import { sendEmail } from "../utils/emailServices/EmailService";
import { generatePasswordResetOtpEmail } from "../utils/emailServices/EmailTemplate";

export const getAdminByEmail = async (
  email: string
): Promise<Admin_Users | null> => {
  try {
    const pool = await poolPromise;
    const query = `SELECT admin_user_id, admin_user_email, admin_user_name, admin_user_password, admin_user_onboarded
     FROM Admin_Users WHERE admin_user_email = @email`;
    const result = await pool
      .request()
      .input("email", sql.VarChar, email)
      .query(query);

    if (!result.recordset.length) return null;
    const user: Admin_Users = result.recordset[0];

    const rolesResult = await pool
      .request()
      .input("userId", sql.Int, user.admin_user_id).query(`
          SELECT r.admin_role_name,a.*
          FROM Admin_Role_Assign a 
          JOIN Admin_Roles r ON a.role_assigned_id = r.admin_role_id
          WHERE a.role_assign_user_id = @userId
        `);

    user.admin_user_roles = rolesResult.recordset;
    return user;
  } catch (error: any) {
    console.error("Error fetching admin:", error.message);
    throw error;
  }
};

export const createAdminUser = async (
  name: string,
  email: string,
  hashedPassword: string,
  roles: any[]
) => {
  const pool = await poolPromise;
  const transaction = new sql.Transaction(pool);

  try {
    await transaction.begin();
    const existingEmailCheck = await pool
      .request()
      .input("email", sql.NVarChar(50), email).query(`
      SELECT COUNT(*) AS emailCount
      FROM Admin_Users
      WHERE admin_user_email = @email
      `);

    if (existingEmailCheck.recordset[0].emailCount > 0) {
      throw new Error("Email already exists");
    }

    const request = new sql.Request(transaction);

    const userResult = await request
      .input("name", sql.NVarChar(50), name)
      .input("email", sql.NVarChar(50), email)
      .input("password", sql.NVarChar(200), hashedPassword).query(`
        INSERT INTO Admin_Users (admin_user_name, admin_user_email, admin_user_password, created_at, updated_at)
        OUTPUT INSERTED.admin_user_id
        VALUES (@name, @email, @password, GETDATE(), GETDATE())
      `);

    const userId = userResult.recordset[0].admin_user_id;

    for (let i = 0; i < roles.length; i++) {
      const { roleId, read, write } = roles[i];
      console.log("read write roles", roles[i]);

      const paramUserId = `userId_${i}`;
      const paramRoleId = `roleId_${i}`;
      const paramRead = `read_${i}`;
      const paramWrite = `write_${i}`;

      await request
        .input(paramUserId, sql.Int, userId)
        .input(paramRoleId, sql.Int, roleId)
        .input(paramRead, sql.Bit, read)
        .input(paramWrite, sql.Bit, write).query(`
      INSERT INTO Admin_Role_Assign (
        role_assign_user_id, 
        role_assigned_id,
        role_assigned_read,
        role_assigned_write,
        created_at
      )
      VALUES (
        @${paramUserId}, 
        @${paramRoleId}, 
        @${paramRead}, 
        @${paramWrite}, 
        GETDATE()
      )
    `);
    }

    await transaction.commit();
    return userId;
  } catch (err: any) {
    await transaction.rollback();
    throw new Error("Error creating admin user: " + err.message);
  }
};

export const updatePassword = async (email: string, hashedPassword: string) => {
  const pool = await poolPromise;
  await pool
    .request()
    .input("email", sql.VarChar, email)
    .input("password", sql.NVarChar(200), hashedPassword).query(`
      UPDATE Admin_Users
      SET admin_user_password = @password, updated_at = GETDATE()
      WHERE admin_user_email = @email
    `);
};

export const updatePasswordAndOnboard = async (
  email: string,
  hashedPassword: string
) => {
  const pool = await poolPromise;
  await pool
    .request()
    .input("email", sql.VarChar, email)
    .input("password", sql.NVarChar(200), hashedPassword).query(`
      UPDATE Admin_Users
      SET admin_user_password = @password, admin_user_onboarded = 1, admin_user_isactive = 1, updated_at = GETDATE()
      WHERE admin_user_email = @email
    `);
};

export const tokenCompareFromDb = async (email: string, otpToken: string) => {
  const pool = await poolPromise;
  const result = await pool
    .request()
    .input("email", email)
    .input("otpToken", otpToken).query(`
      SELECT admin_password_otp
      FROM Admin_Users
      WHERE admin_user_email = @email
    `);
  if (result.recordset.length === 0) return false;
  const dbToken = result.recordset[0].admin_password_otp;
  const normalizedDbToken = dbToken.trim();
  const normalizedOtpToken = otpToken.trim();

  return normalizedDbToken === normalizedOtpToken;
};

export const sendPasswordResetEmail = async (
  email: string,
  OtpToken: string,
  userName: string
): Promise<void> => {
  const expiryMinutes = String(process.env.RESET_TOKEN_EXPIRY_MINUTES || "15");

  const html = generatePasswordResetOtpEmail({
    userName,
    otp: OtpToken,
    expiryMinutes,
  });

  await sendEmail({
    to: email,
    subject: "Password Reset OTP - Cercle Admin",
    html,
  });
};

export const updateOtpToken = async (email: string, OtpToken: string) => {
  try {
    const updatedToken = await poolPromise;
    const queryResult = await updatedToken
      .request()
      .input("admin_password_otp", OtpToken)
      .input("email", email).query(`
      UPDATE Admin_Users
      SET admin_password_otp = @admin_password_otp, updated_at = GETDATE()
      WHERE admin_user_email = @email
    `);
    return { result: "OTP token created successfully" };
  } catch (error: any) {
    console.log("Error updating OTP token:", error.message);
  }
};
