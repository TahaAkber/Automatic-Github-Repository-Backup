import { poolPromise } from "../config/db";

import sql from "mssql";

export const getAllReportModel = async (
  page: number,
  limit: number,
  search: string,
  typeFilter?: string, // 'shop' | 'product' | 'reel' | 'story' | 'all'
  statusFilter?: string // 'pending' | 'resolved' | ...
) => {
  try {
    const pool = await poolPromise;

    const offset = (page - 1) * limit;

    const request = pool.request();

    request.input("page", sql.Int, page);
    request.input("pageSize", sql.Int, limit);
    request.input("offset", sql.Int, offset);

    // Use %search% pattern; if you want strict "no filter" when empty,
    // handle that BEFORE adding the %...% wrapper.
    request.input("search", sql.NVarChar, `%${search || ""}%`);
    request.input("typeFilter", sql.VarChar, typeFilter || null);
    request.input("statusFilter", sql.VarChar, statusFilter || null);

    const countQuery = `
      SELECT COUNT(*) AS totalCount
      FROM Reports r
      LEFT JOIN Users u 
          ON u.user_id = r.reported_by_user_id
      LEFT JOIN ReelsNStories rs
          ON rs.id = r.reported_reference_id
          AND r.reported_type IN ('reel', 'story')
      LEFT JOIN Videos v
          ON v.video_id = rs.video_url_id
          AND r.reported_type IN ('reel', 'story')
      LEFT JOIN Products p
          ON p.product_id = r.reported_reference_id
          AND r.reported_type = 'product'
      LEFT JOIN Shops shop
          ON 
              (
                  shop.shop_id = r.reported_reference_id
                  AND r.reported_type = 'shop'
              )
              OR
              (
                  shop.shop_id = p.product_shop_id
                  AND r.reported_type = 'product'
              )
              OR
              (
                  shop.shop_id = v.video_shop_id
                  AND r.reported_type IN ('reel', 'story')
              )
      WHERE 
          r.reported_type IN ('reel', 'story', 'product', 'shop')
          -- TYPE FILTER
          AND (
              @typeFilter IS NULL
              OR @typeFilter = ''
              OR @typeFilter = 'all'
              OR (@typeFilter = 'shop'    AND r.reported_type = 'shop')
              OR (@typeFilter = 'product' AND r.reported_type = 'product')
              OR (@typeFilter = 'reel'    AND r.reported_type = 'reel')
              OR (@typeFilter = 'story'   AND r.reported_type = 'story')
          )
          -- STATUS FILTER
          AND (
              @statusFilter IS NULL
              OR @statusFilter = ''
              OR r.reported_status = @statusFilter
          )
          -- SEARCH FILTER
          AND (
              u.user_first_name LIKE @search
              OR u.user_last_name  LIKE @search
              OR u.user_email      LIKE @search
              OR p.product_name    LIKE @search
              OR r.reported_reason_main       LIKE @search
              OR r.reported_reason_sub        LIKE @search
              OR r.reported_reason_other_text LIKE @search
              OR r.reported_status            LIKE @search
          );
    `;

    const CountResult = await request.query(countQuery);
    const totalCount = CountResult.recordset[0].totalCount;
    const totalPages = Math.ceil(totalCount / limit);

    const query = `
     SELECT 
    r.*,

    rs.id AS reel_id,
    rs.video_url_id AS reel_video_id,
    v.video_url AS reel_video_url,
    v.video_id,
    v.video_shop_id,

    p.product_id,
    p.product_name,
    p.product_description,
    p.product_image_url,

    COALESCE(s_shop.shop_id, s_prod.shop_id, s_vid.shop_id) AS shop_id,
    COALESCE(s_shop.shop_name, s_prod.shop_name, s_vid.shop_name) AS shop_name,
    COALESCE(s_shop.shop_email, s_prod.shop_email, s_vid.shop_email) AS shop_email,
    COALESCE(s_shop.shop_address, s_prod.shop_address, s_vid.shop_address) AS shop_address,
    COALESCE(s_shop.shop_logo_url, s_prod.shop_logo_url, s_vid.shop_logo_url) AS shop_logo_url,

    u.user_first_name,
    u.user_last_name,
    u.user_email

    FROM Reports r
    LEFT JOIN Users u 
    ON u.user_id = r.reported_by_user_id

    LEFT JOIN ReelsNStories rs
    ON rs.id = r.reported_reference_id
    AND r.reported_type IN ('reel', 'story')

    LEFT JOIN Videos v
    ON v.video_id = rs.video_url_id
    AND r.reported_type IN ('reel', 'story')

    LEFT JOIN Reels_Products rp
    ON rp.reel_video_id = v.video_id
    AND r.reported_type IN ('reel', 'story')

    LEFT JOIN Products p
    ON (
          r.reported_type = 'product'
          AND p.product_id = r.reported_reference_id
       )
    OR (
          r.reported_type IN ('reel', 'story')
          AND p.product_id = rp.reel_product_id
       )

    LEFT JOIN Shops s_shop
    ON s_shop.shop_id = r.reported_reference_id
    AND r.reported_type = 'shop'

    LEFT JOIN Shops s_prod
    ON s_prod.shop_id = p.product_shop_id
    AND r.reported_type IN ('product', 'reel', 'story')  -- product or reel/story product mapping

    LEFT JOIN Shops s_vid
    ON s_vid.shop_id = v.video_shop_id
    AND r.reported_type IN ('reel', 'story')
    WHERE 
          r.reported_type IN ('reel', 'story', 'product', 'shop')
          AND (
              @typeFilter IS NULL
              OR @typeFilter = ''
              OR @typeFilter = 'all'
              OR (@typeFilter = 'shop'    AND r.reported_type = 'shop')
              OR (@typeFilter = 'product' AND r.reported_type = 'product')
              OR (@typeFilter = 'reel'    AND r.reported_type = 'reel')
              OR (@typeFilter = 'story'   AND r.reported_type = 'story')
          )
          AND (
              @statusFilter IS NULL
              OR @statusFilter = ''
              OR r.reported_status = @statusFilter
          )
          AND (
              u.user_first_name LIKE @search
              OR u.user_last_name  LIKE @search
              OR u.user_email      LIKE @search
              OR p.product_name    LIKE @search
              OR r.reported_reason_main       LIKE @search
              OR r.reported_reason_sub        LIKE @search
              OR r.reported_reason_other_text LIKE @search
              OR r.reported_status            LIKE @search
          )

      ORDER BY r.created_at DESC
      OFFSET @offset ROWS
      FETCH NEXT @pageSize ROWS ONLY;
    `;

    const result = await request.query(query);

    return {
      data: result.recordset,
      pagination: {
        currentPage: page,
        totalPages,
        totalCount,
      },
    };
  } catch (error) {
    console.error("Error fetching reports:", error);
    throw error;
  }
};

export const deleteReportModel = async (reportId: number) => {
  try {
    const pool = await poolPromise;
    const request = pool.request();

    request.input("reportId", sql.Int, reportId);

    const query = `
      DELETE FROM Reports
      WHERE report_id = @reportId;
    `;

    const result = await request.query(query);

    if (result.rowsAffected[0] === 0) {
      throw new Error("Report not found");
    }

    return { success: true, message: "Report deleted successfully" };
  } catch (error) {
    console.error("Error deleting report:", error);
    throw error;
  }
};

export const updateReportStatusModel = async (
  reportId: number,
  status: string,
  adminId: number,
  decisionData?: {
    decision_description: string;
    decision_result: string;
  }
) => {
  try {
    const pool = await poolPromise;

    const validStatuses = ["pending", "in_review", "resolved", "rejected"];
    if (!validStatuses.includes(status)) {
      throw new Error(
        `Invalid status. Must be one of: ${validStatuses.join(", ")}`
      );
    }

    const checkRequest = pool.request();
    checkRequest.input("reportId", sql.Int, reportId);
    const checkQuery = `SELECT report_id FROM Reports WHERE report_id = @reportId`;
    const checkResult = await checkRequest.query(checkQuery);

    if (checkResult.recordset.length === 0) {
      throw new Error("Report not found");
    }

    let decisionId = null;
    if ((status === "resolved" || status === "rejected") && decisionData) {
      const decisionRequest = pool.request();
      decisionRequest.input(
        "decision_description",
        sql.NVarChar,
        decisionData.decision_description
      );
      decisionRequest.input(
        "decision_result",
        sql.NVarChar,
        decisionData.decision_result
      );
      decisionRequest.input("decision_admin_id", sql.Int, adminId);

      const decisionQuery = `
        INSERT INTO Reports_Decisions (decision_description, decision_result, decision_admin_id, created_at, updated_at)
        OUTPUT INSERTED.decision_id
        VALUES (@decision_description, @decision_result, @decision_admin_id, GETDATE(), GETDATE());
      `;

      const decisionResult = await decisionRequest.query(decisionQuery);
      decisionId = decisionResult.recordset[0].decision_id;
    }

    // Update report status
    const updateRequest = pool.request();
    updateRequest.input("reportId", sql.Int, reportId);
    updateRequest.input("status", sql.VarChar, status);
    updateRequest.input("decisionId", sql.Int, decisionId);

    const updateQuery = `
      UPDATE Reports
      SET reported_status = @status,
          reported_decision_id = ${
            decisionId ? "@decisionId" : "reported_decision_id"
          },
          updated_at = GETDATE()
      WHERE report_id = @reportId;
    `;

    await updateRequest.query(updateQuery);

    return {
      success: true,
      message: "Report status updated successfully",
      decisionId: decisionId,
    };
  } catch (error) {
    console.error("Error updating report status:", error);
    throw error;
  }
};
