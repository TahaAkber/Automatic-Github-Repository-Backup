import { poolPromise } from "../config/db";
import sql from "mssql";
import { ProductDropdowns } from "../types/productType";

export const getAllProductFromDb = async (
  page: number,
  limit: number,
  search?: string
) => {
  const offset = (page - 1) * limit; // Calculate the offset for the query

  const whereClauses: string[] = [];
  const inputs: { key: string; value: any }[] = [];

  if (search && search.trim()) {
    whereClauses.push(
      `p.product_name LIKE '%' + @search + '%' OR p.product_description LIKE '%' + @search + '%'`
    );
    inputs.push({ key: "search", value: search.trim() });
  }

  inputs.push({ key: "offset", value: offset });
  inputs.push({ key: "limit", value: limit });

  const whereSQL = whereClauses.length
    ? `WHERE ${whereClauses.join(" AND ")}`
    : "";

  const query = `
  SELECT 
    p.*,
    v.variant_price
  FROM Products p
  OUTER APPLY (
    SELECT TOP 1 pv.variant_price
    FROM Product_Variants pv
    WHERE pv.variant_product_id = p.product_id
    ORDER BY pv.variant_id
  ) v
  ${whereSQL}             
  ORDER BY p.product_id DESC
  OFFSET @offset ROWS
  FETCH NEXT @limit ROWS ONLY;
`;

  try {
    const pool = await poolPromise;

    const Products = await pool
      .request()
      .input("offset", sql.Int, offset)
      .input("limit", sql.Int, limit)
      .input("search", search)
      .query(query);

    return {
      Products: Products.recordset,
    };
  } catch (error: any) {
    throw new Error("Error fetching Products: " + error.message);
  }
};

export const getProductsReviewsCount = async (
  page: number,
  limit: number,
  search?: string
) => {
  // Build WHERE clause (optional search)
  const whereParts: string[] = [];
  if (search && search.trim()) {
    whereParts.push(
      `(p.product_name LIKE '%' + @search + '%' OR p.product_description LIKE '%' + @search + '%')`
    );
  }
  const whereSQL = whereParts.length ? `WHERE ${whereParts.join(" AND ")}` : "";

  // COUNT query
  const countQuery = `
  select COUNT(*) as totalCount from Order_Item_Review otr JOIN Order_Items ot on otr.order_item_id=ot.order_item_id JOIN Product_Variants pv on ot.order_item_variant_id = pv.variant_id JOIN Products p on pv.variant_product_id= p.product_id ${whereSQL}`;

  try {
    const pool = await poolPromise;
    const req = pool.request();

    if (search && search.trim()) {
      req.input("search", sql.NVarChar(255), search.trim());
    }

    const countResult = await req.query(countQuery);
    const totalCount: number = countResult.recordset[0]?.totalCount ?? 0;
    const totalPages = Math.ceil(totalCount / Math.max(1, limit));

    return {
      totalCount,
      totalPages,
    };
  } catch (error: any) {
    throw new Error("Error fetching Product Reviews Count: " + error.message);
  }
};

export const getProductReviewModel = async (
  page: number,
  limit: number,
  search?: string
) => {
  const offset = (page - 1) * limit; // Calculate the offset for the query
  const whereClauses: string[] = [];
  const inputs: { key: string; value: any }[] = [];

  if (search && search.trim()) {
    whereClauses.push(
      `p.product_name LIKE '%' + @search + '%' OR p.product_description LIKE '%' + @search + '%'`
    );
    inputs.push({ key: "search", value: search.trim() });
  }

  inputs.push({ key: "offset", value: offset });
  inputs.push({ key: "limit", value: limit });

  const whereSQL = whereClauses.length
    ? `WHERE ${whereClauses.join(" AND ")}`
    : "";

  const query = `
select otr.order_item_review_comment,pv.variant_image_url,p.product_name,s.shop_logo_url, s.shop_name, u.user_name, otr.created_at, otr.updated_at from Order_Item_Review otr 
JOIN Order_Items oi on otr.order_item_id=oi.order_item_id 
JOIN Product_Variants pv on oi.order_item_variant_id = pv.variant_id 
JOIN Products p on pv.variant_product_id= p.product_id 
JOIN Shops s on s.shop_id = p.product_shop_id 
JOIN Orders o on o.order_id = oi.order_id 
JOIN users u on u.user_id = o.order_user_id
${whereSQL} ORDER BY otr.order_item_review_id DESC OFFSET @offset ROWS FETCH NEXT @limit ROWS ONLY;
`;

  try {
    const pool = await poolPromise;
    const Reviews = await pool
      .request()
      .input("offset", sql.Int, offset)
      .input("limit", sql.Int, limit)
      .input("search", search)
      .query(query);
    return Reviews.recordset;
  } catch (error: any) {
    throw new Error("Error fetching Product Reviews: " + error.message);
  }
};

export const getTotalProductsCount = async (limit: number, search?: string) => {
  try {
    const pool = await poolPromise;

    // Build WHERE clause dynamically
    let whereSQL = "";
    if (search && search.trim()) {
      whereSQL =
        "WHERE p.product_name LIKE '%' + @search + '%' OR p.product_description LIKE '%' + @search + '%';";
    }

    const countQuery = `
      SELECT COUNT(*) AS totalCount
      FROM Products p
      ${whereSQL};
    `;

    const request = pool.request();

    if (search && search.trim()) {
      request.input("search", sql.NVarChar, search.trim());
    }

    const countResult = await request.query(countQuery);

    const totalCount = countResult.recordset[0]?.totalCount ?? 0;
    const totalPages = Math.ceil(totalCount / limit);

    return {
      totalCount,
      totalPages,
    };
  } catch (error: any) {
    throw new Error("Error fetching total product count: " + error.message);
  }
};

export const getProductDropdown = async (
  page: number,
  limit: number,
  search?: string
): Promise<{ products: ProductDropdowns[] }> => {
  const offset = (page - 1) * limit;
  const searchTerm = (search ?? "").trim();

  const query = `
    SELECT
  p.product_id,
  p.product_name,
  p.product_image_url
FROM dbo.Products AS p
WHERE (@search = '' 
       OR p.product_name LIKE '%' + @search + '%')
ORDER BY p.product_id DESC
OFFSET @offset ROWS FETCH NEXT @limit ROWS ONLY;`;

  try {
    const pool = await poolPromise;
    const result = await pool
      .request()
      .input("search", sql.NVarChar, searchTerm)
      .input("offset", sql.Int, offset)
      .input("limit", sql.Int, limit)
      .query<ProductDropdowns>(query);

    return { products: result.recordset };
  } catch (error: any) {
    throw new Error("Error fetching Products: " + error.message);
  }
};
