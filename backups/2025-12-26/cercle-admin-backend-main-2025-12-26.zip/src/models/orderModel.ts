import { poolPromise } from "../config/db";
import sql from "mssql";

export const getAllOrdersFromDB = async (
  page: number,
  limit: number,
  shopName?: string,
  status?: string
) => {
  const offset = (page - 1) * limit;

  const query = `
    WITH FirstTransaction AS (
      SELECT *,
             ROW_NUMBER() OVER (PARTITION BY transaction_order_id ORDER BY transaction_id ASC) AS rn
      FROM Transactions
    ),
    PrioritizedTracking AS (
      SELECT 
        id,
        tracking_order_id,
        tracking_status,
        ROW_NUMBER() OVER (
          PARTITION BY tracking_order_id
          ORDER BY 
            CASE 
              WHEN tracking_status NOT IN ('delivered', 'completed') THEN 0 
              ELSE 1 
            END,
            id DESC
        ) AS rn
      FROM Tracking
    )
    SELECT 
      o.order_id,
      o.order_date,
      o.order_total_amount,
      o.order_delivery_address,
      o.order_user_id,
      o.order_shop_id,
      o.order_fulfillment_status,
      o.order_payment_status,
      o.order_channel,
      o.order_shopify_id,
      o.order_cancel_reason,
      o.order_cancelled_by,
      o.order_cancelled_at,
      o.order_delivery_status,
      o.order_charge_rate,
      o.order_total_discount_amount,
      o.order_title,
      o.order_shipping,
      o.order_tax,
      o.order_tax_rate,
      o.created_at,
      o.updated_at,
      u.user_name,
      u.user_email,
      s.shop_name,
      s.shop_logo_url,
      s.shop_currency,
      ft.transaction_amount,
      pt.tracking_status,
      pt.id AS tracking_id,
      (
        SELECT COUNT(*) 
        FROM Order_Items oi 
        WHERE oi.order_id = o.order_id
      ) AS item_count
    FROM Orders o
    LEFT JOIN Users u ON o.order_user_id = u.user_id
    LEFT JOIN Shops s ON o.order_shop_id = s.shop_id
    LEFT JOIN FirstTransaction ft ON o.order_id = ft.transaction_order_id AND ft.rn = 1
    LEFT JOIN PrioritizedTracking pt ON o.order_id = pt.tracking_order_id AND pt.rn = 1
    WHERE 
      (@shopName IS NULL OR s.shop_name LIKE '%' + @shopName + '%') AND
      (@status IS NULL OR o.order_fulfillment_status = @status) AND (o.order_channel IS NULL OR o.order_channel = 'Cercle' OR o.order_channel = 'cercleDev' OR o.order_channel = 'Cymbiote')
    ORDER BY o.order_id DESC
    OFFSET @offset ROWS
    FETCH NEXT @limit ROWS ONLY;
  `;

  try {
    const pool = await poolPromise;

    const ordersResult = await pool
      .request()
      .input("offset", sql.Int, offset)
      .input("limit", sql.Int, limit)
      .input("shopName", sql.NVarChar, shopName || null)
      .input("status", sql.NVarChar, status || null)
      .query(query);

    return {
      orders: ordersResult.recordset, // Contains only the exact object structure you want
    };
  } catch (error: any) {
    throw new Error("Error fetching orders: " + error.message);
  }
};

export const getOrderCount = async (
  limit: number,
  shopName?: string,
  status?: string
) => {
  const countQuery = `
SELECT COUNT(DISTINCT o.order_id) AS totalCount
    FROM Orders o
    LEFT JOIN Shops s ON o.order_shop_id = s.shop_id
    WHERE 
      (@shopName IS NULL OR s.shop_name LIKE '%' + @shopName + '%') AND
      (@status IS NULL OR o.order_fulfillment_status = @status) AND
      (o.order_channel IS NULL OR o.order_channel = 'Cercle' OR o.order_channel = 'cercleDev' OR o.order_channel = 'Cymbiote') SELECT COUNT(DISTINCT o.order_id) AS totalCount
    FROM Orders o
    LEFT JOIN Shops s ON o.order_shop_id = s.shop_id
    WHERE 
      (@shopName IS NULL OR s.shop_name LIKE '%' + @shopName + '%') AND
      (@status IS NULL OR o.order_fulfillment_status = @status) AND
      (o.order_channel IS NULL OR o.order_channel = 'Cercle' OR o.order_channel = 'cercleDev' OR o.order_channel = 'Cymbiote')
  `;
  const pool = await poolPromise;
  try {
    const countResult = await pool
      .request()
      .input("shopName", sql.NVarChar, shopName || null)
      .input("status", sql.NVarChar, status || null)
      .query(countQuery);

    const totalCount = countResult.recordset[0].totalCount;
    const totalPages = Math.ceil(totalCount / limit);
    return { totalCount, totalPages };
  } catch (error: any) {
    throw new Error("Error fetching order count: " + error.message);
  }
};
export const getCancelOrderCount = async (
  page: number,
  limit: number,
  search?: string,
  order_cancelled_by?: string
) => {
  const safeLimit = Math.max(1, Number(limit) || 1);

  let query = `
    SELECT COUNT(*) AS total
    FROM Orders o JOIN Shops s on s.shop_id = o.order_shop_id
    WHERE o.order_cancelled_by IS NOT NULL
    AND o.order_channel IN ('Cercle', 'cercleDev', 'Cymbiote')
  `;

  if (order_cancelled_by) {
    query += ` AND o.order_cancelled_by = '${order_cancelled_by}'`;
  }

  if (search) {
    query += ` AND (s.shop_name LIKE '%${search}%')`;
  }

  try {
    const pool = await poolPromise;
    const result = await pool.request().query(query);

    const totalCount = result.recordset?.[0]?.total ?? 0;
    const totalPages = Math.ceil(totalCount / safeLimit);

    return { totalCount, totalPages };
  } catch (err) {
    throw err;
  }
};

export const getCancelledOrders = async (
  page: number,
  limit: number,
  search?: string,
  order_cancelled_by?: string
) => {
  const offset = (page - 1) * limit;

  let query = `
    SELECT o.order_title,o.order_id,o.order_cancelled_by,o.order_date,o.order_cancelled_staff_notes,s.shop_name, s.shop_logo_url
    FROM Orders o JOIN Shops s on s.shop_id = o.order_shop_id
    WHERE o.order_cancelled_by IS NOT NULL
    AND o.order_channel IN ('Cercle', 'cercleDev', 'Cymbiote')
  `;
  if (order_cancelled_by) {
    query += ` AND order_cancelled_by = '${order_cancelled_by}'`;
  }

  if (search) {
    query += ` AND (s.shop_name LIKE '%${search}%')`;
  }

  query += `
    ORDER BY order_id DESC
    OFFSET ${offset} ROWS
    FETCH NEXT ${limit} ROWS ONLY
  `;

  try {
    const pool = await poolPromise;
    const result = await pool.request().query(query);
    return result.recordset;
  } catch (err) {
    throw err;
  }
};

export const getOrderDetailsFromDB = async (id: number) => {
  const pool = await poolPromise;

  try {
    // 1. Fetch order and user info
    const orderQuery = `
     SELECT *
      FROM Orders o
      INNER JOIN Users u ON o.order_user_id = u.user_id
	    JOIN Shops s ON o.order_shop_id = s.shop_id
      WHERE o.order_id = @id
    `;
    const orderResult = await pool.request().input("id", id).query(orderQuery);
    const orderDetail = orderResult.recordset[0];

    // 2. Fetch order items
    const orderItemsQuery = `
      SELECT * 
      FROM Order_Items 
      WHERE order_id = @id
    `;
    const orderItemsResult = await pool
      .request()
      .input("id", id)
      .query(orderItemsQuery);
    const orderItems = orderItemsResult.recordset;

    // 3. For each item, fetch the count of Tracking_Order_Items
    const trackingCounts = await Promise.all(
      orderItems.map(async (item: any) => {
        const countQuery = `
          SELECT tracking_id, tracking_order_item_id, COUNT(*) AS count
          FROM Tracking_Order_Items
          WHERE tracking_order_item_id = @itemId
          GROUP BY tracking_id, tracking_order_item_id
        `;
        const countResult = await pool
          .request()
          .input("itemId", item.order_item_id)
          .query(countQuery);

        return {
          ...item,
          tracking_item_count: countResult.recordset,
        };
      })
    );

    return {
      orderdetail: orderDetail,
      orderItems: trackingCounts,
    };
  } catch (error: any) {
    throw new Error("Error fetching order details: " + error.message);
  }
};

export const getItemsByOrderId = async (id: number) => {
  const orderItemsQuery = `
    SELECT 
      o.*, 
      pv.variant_id, 
      pv.variant_price, 
      p.product_id, 
      p.product_name, 
      p.product_image_url
    FROM Order_items o
    JOIN product_variants pv ON pv.variant_id = o.order_item_variant_id
    JOIN Products p ON pv.variant_product_id = p.product_id
    WHERE o.order_id = @id
    ORDER BY o.order_id DESC;
  `;

  try {
    const pool = await poolPromise;

    // Fetch order items
    const orderItemsResult = await pool
      .request()
      .input("id", id)
      .query(orderItemsQuery);
    const orderItems = orderItemsResult.recordset;

    if (orderItems.length === 0) {
      return { orderItems: [] };
    }

    // Extract all order_item_ids
    const itemIds = orderItems.map((item) => item.order_item_id);

    // Dynamically build the tracking query using IN clause
    const trackingQuery = `
      SELECT tracking_id, tracking_order_item_id, COUNT(*) AS count
      FROM Tracking_Order_Items
      WHERE tracking_order_item_id IN (${itemIds.join(",")})
      GROUP BY tracking_id, tracking_order_item_id;
    `;

    // Fetch tracking info
    const trackingResult = await pool.query(trackingQuery);
    const trackingData = trackingResult.recordset;

    // Merge tracking data into order items
    const itemsWithTracking = orderItems.map((item) => {
      const trackingItems = trackingData.filter(
        (t) => t.tracking_order_item_id === item.order_item_id
      );
      return {
        ...item,
        tracking_items: trackingItems,
      };
    });

    return {
      orderItems: itemsWithTracking,
    };
  } catch (error: any) {
    throw new Error("Error fetching order Details: " + error.message);
  }
};
