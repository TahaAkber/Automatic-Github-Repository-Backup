import { poolPromise } from "../config/db";
import sql from "mssql";
import { MerchantDropdown } from "../types/merchantType";
import dotenv from "dotenv";

dotenv.config();
interface Product {
  product_id: number;
  product_name: string;
  product_image_url: string;
  product_description: string;
  variant_price: number | null;
}

export const getAllMerchantsFromDb = async (
  page: number,
  limit: number,
  searchKeyword?: string,
  shop_is_active?: string,
  shop_delisted?: string
) => {
  const offset = (page - 1) * limit;

  let whereClauses: string[] = [];
  let inputs: { key: string; type: any; value: any }[] = [];

  if (searchKeyword) {
    whereClauses.push(`s.shop_name LIKE '%' + @search + '%'`);
    inputs.push({ key: "search", type: sql.VarChar, value: searchKeyword });
  }

  if (shop_is_active !== undefined) {
    whereClauses.push("s.shop_is_active = @isActive");
    inputs.push({
      key: "isActive",
      type: sql.Bit,
      value: shop_is_active === "true",
    });
  }

  if (shop_delisted !== undefined) {
    whereClauses.push("s.shop_delisted = @isDelisted");
    inputs.push({
      key: "isDelisted",
      type: sql.Bit,
      value: shop_delisted === "true",
    });
  }

  const whereClause = whereClauses.length
    ? `WHERE ${whereClauses.join(" AND ")}`
    : "";

  const query = `
    SELECT s.*
    FROM Shops s
    ${whereClause}
    ORDER BY s.shop_id DESC
    OFFSET @offset ROWS
    FETCH NEXT @limit ROWS ONLY;
  `;

  const countQuery = `
    SELECT COUNT(*) AS totalCount
    FROM Shops s
    ${whereClause};
  `;

  try {
    const pool = await poolPromise;
    const request = pool.request();

    // Inputs
    inputs.forEach(({ key, type, value }) => request.input(key, type, value));
    request.input("offset", sql.Int, offset);
    request.input("limit", sql.Int, limit);

    const merchantResult = await request.query(query);

    const countRequest = pool.request();
    inputs.forEach(({ key, type, value }) =>
      countRequest.input(key, type, value)
    );
    const countResult = await countRequest.query(countQuery);

    const totalCount = countResult.recordset[0].totalCount;
    const totalPages = Math.ceil(totalCount / limit);

    return {
      merchants: merchantResult.recordset,
      totalCount,
      totalPages,
    };
  } catch (error: any) {
    throw new Error("Error fetching Merchant: " + error.message);
  }
};

export const getMerchantDetailsFromDb = async (id: number) => {
  const channel = process.env.APP_NAME ?? ""; // keep empty if not set
  // Shop details
  const shopQuery = `
    SELECT 
      st.shop_tile_name,
      st.shop_tile_charges,
      st.shop_tile_type,
      p.package_name,
      p.package_charges,
      p.package_description,
      s.shop_id,
      s.shop_name,
      s.shop_logo_url,
      s.shop_description,
      s.shop_color,
      s.shop_email,
      s.shop_address,
      s.shop_number,
      s.shop_currency,
      s.shop_credits,
      s.shop_tile_subscribed,
      s.shop_tile_type
    FROM Shops s 
    JOIN Shop_Tiles st on s.shop_tile_type = st.shop_tile_id 
    JOIN Subscriptions sb on sb.subscription_shop_id = s.shop_id
    JOIN Packages p on p.package_id = sb.subscription_package_id
    WHERE s.shop_id = @id AND sb.subscription_enabled = 'True' AND sb.subscription_confirmed = 'True'
  `;

  // Orders used for totals (fulfilled only, same channel)
  const fulfilledOrdersQuery = `
    SELECT 
      order_total_amount,
      order_charge_rate
    FROM Orders
    WHERE order_shop_id = @id
      AND order_fulfillment_status = 'fulfilled'
      AND (@channel = '' OR order_channel = @channel)
  `;

  // Status counts (same shop + same channel for consistency)
  const ordersCountQuery = `
    SELECT 
      COUNT(*) AS total_orders,
      SUM(CASE WHEN order_fulfillment_status = 'fulfilled' THEN 1 ELSE 0 END) AS fulfilled_orders,
      SUM(CASE WHEN order_fulfillment_status = 'restocked' THEN 1 ELSE 0 END) AS restocked_orders,
      SUM(CASE 
            WHEN (order_fulfillment_status = 'unfulfilled' OR order_fulfillment_status IS NULL)
                 AND order_cancelled_by IS NULL 
          THEN 1 ELSE 0 END) AS unfulfilled_orders,
      SUM(CASE 
            WHEN order_fulfillment_status IS NULL AND order_cancelled_by IS NOT NULL 
          THEN 1 ELSE 0 END) AS cancelled_orders,
      SUM(CASE WHEN order_fulfillment_status = 'pending' THEN 1 ELSE 0 END) AS pending_orders,
      SUM(CASE WHEN order_fulfillment_status = 'partial' THEN 1 ELSE 0 END) AS partially_fulfilled_orders
    FROM Orders
    WHERE order_shop_id = @id
      AND (@channel = '' OR order_channel = @channel)
  `;

  // Product count for the shop
  const productCountQuery = `
    SELECT COUNT(DISTINCT p.product_id) AS totalCount
    FROM Products p
    INNER JOIN Shops s ON p.product_shop_id = s.shop_id
    WHERE s.shop_id = @id
  `;

  try {
    const pool = await poolPromise;

    // Shop details
    const shopRes = await pool.request().input("id", id).query(shopQuery);

    const shopRow = shopRes.recordset?.[0] ?? null;

    const formattedShop = shopRow
      ? {
          shop_id: shopRow.shop_id,
          shop_name: shopRow.shop_name,
          shop_logo_url: shopRow.shop_logo_url,
          shop_description: shopRow.shop_description ?? null,
          shop_color: shopRow.shop_color ?? null,
          shop_email: shopRow.shop_email ?? null,
          shop_address: shopRow.shop_address ?? null,
          shop_number: shopRow.shop_number ?? null,
          shop_currency: shopRow.shop_currency ?? null,
          shop_credits: Number(shopRow.shop_credits ?? 0),
          shop_tile_name: shopRow.shop_tile_name ?? null,
          shop_tile_subscribed: shopRow.shop_tile_subscribed ?? null,
          shop_tile_type: shopRow.shop_tile_type ?? null,
          shop_tile_charges: shopRow.shop_tile_charges ?? null,
          package_name: shopRow.package_name ?? null,
          package_charges: shopRow.package_charges ?? null,
          package_description: shopRow.package_description ?? null,
        }
      : {
          shop_id: null,
          shop_name: null,
          shop_logo_url: null,
          shop_description: null,
          shop_color: null,
          shop_email: null,
          shop_address: null,
          shop_number: null,
          shop_currency: null,
          shop_credits: 0,
          shop_tile_name: null,
          shop_tile_subscribed: null,
          shop_tile_type: null,
          shop_tile_charges: null,
          package_name: null,
          package_charges: null,
          package_description: null,
        };

    // Counts
    const [productCountRes, ordersCountRes, fulfilledOrdersRes] =
      await Promise.all([
        pool.request().input("id", id).query(productCountQuery),
        pool
          .request()
          .input("id", id)
          .input("channel", channel)
          .query(ordersCountQuery),
        pool
          .request()
          .input("id", id)
          .input("channel", channel)
          .query(fulfilledOrdersQuery),
      ]);

    // Totals from fulfilled orders
    const totals = (fulfilledOrdersRes.recordset || []).reduce(
      (
        acc: {
          totalPrice: number;
          totalAfterRate: number;
          totalDeducted: number;
        },
        o: any
      ) => {
        const price = Number(o.order_total_amount ?? 0) || 0;
        const chargeRate = Number(o.order_charge_rate ?? 0) / 100; // e.g., 200 => 2.0%
        const toDeduct = price * (isFinite(chargeRate) ? chargeRate : 0);

        acc.totalPrice += price;
        acc.totalAfterRate += price - toDeduct;
        acc.totalDeducted += toDeduct;
        return acc;
      },
      { totalPrice: 0, totalAfterRate: 0, totalDeducted: 0 }
    );

    // Normalize to 2 decimals (optional; remove if you want raw numbers)
    const round2 = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100;

    return {
      merchantDetails: formattedShop,
      ordersCount: ordersCountRes.recordset?.[0] ?? {
        total_orders: 0,
        fulfilled_orders: 0,
        restocked_orders: 0,
        unfulfilled_orders: 0,
        cancelled_orders: 0,
        pending_orders: 0,
        partially_fulfilled_orders: 0,
      },
      productCount: productCountRes.recordset?.[0]?.totalCount ?? 0,
      orderTotalPrice: round2(totals.totalPrice),
      orderTotalAfterRate: round2(totals.totalAfterRate),
      orderTotalDeducted: round2(totals.totalDeducted),
    };
  } catch (error) {
    console.error("Error processing the query:", error);
    throw error;
  }
};

export const getTilesModel = async () => {
  try {
    const pool = await poolPromise;
    const result = await pool
      .request()
      .query("SELECT * FROM Shop_Tiles order by shop_tile_id");
    return result.recordset;
  } catch (error) {
    console.error("Error processing the query:", error);
    throw error;
  }
};

export const getMerchantProductsModel = async (
  shopId: number,
  page: number,
  limit: number,
  searchKeyword?: string,
  isActive?: boolean
) => {
  const offset = (page - 1) * limit;
  const search = (searchKeyword ?? "").trim();
  const whereClauses: string[] = [];
  if (search) {
    whereClauses.push(
      `(p.product_name LIKE '%' + @search + '%' OR p.product_description LIKE '%' + @search + '%')`
    );
  }
  if (shopId) {
    whereClauses.push(`p.product_shop_id = @shopId`);
  }
  if (isActive !== undefined) {
    whereClauses.push(`p.product_is_active = @isActive`);
  }
  const whereSQL = whereClauses.length
    ? `WHERE ${whereClauses.join(" AND ")}`
    : "";

  const query = `WITH Paged AS (
  SELECT
    p.*,
    v.variant_price,
    ROW_NUMBER() OVER (ORDER BY p.product_id DESC) AS rn
    FROM Products p
    OUTER APPLY (
    SELECT TOP 1 pv.variant_price
    FROM Product_Variants pv
    WHERE pv.variant_product_id = p.product_id
    ORDER BY pv.variant_id ASC
  ) v
  ${whereSQL}
  )
  SELECT p.*
  FROM Paged p
  WHERE p.rn > @offset AND p.rn <= @offset + @limit
  ORDER BY p.rn;
`;
  try {
    const pool = await poolPromise;
    const req = pool
      .request()
      .input("offset", sql.Int, offset)
      .input("limit", sql.Int, limit);

    if (search) req.input("search", sql.NVarChar, search);
    if (shopId) req.input("shopId", sql.Int, shopId);
    if (isActive !== undefined) req.input("isActive", isActive);
    const result = await req.query(query);
    return { Products: result.recordset };
  } catch (error: any) {
    throw new Error("Error fetching Products: " + error.message);
  }
};

export const getProductsCount = async (
  shopId: number,
  page: number,
  limit: number,
  searchKeyword?: string,
  isActive?: boolean
) => {
  const search = (searchKeyword ?? "").trim();
  const whereClauses: string[] = [];

  if (search) {
    whereClauses.push(
      `(p.product_name LIKE '%' + @search + '%' OR p.product_description LIKE '%' + @search + '%')`
    );
  }

  if (shopId) {
    whereClauses.push(`p.product_shop_id = @shopId`);
  }
  if (isActive !== undefined) {
    whereClauses.push(`p.product_is_active = @isActive`);
  }

  const whereSQL = whereClauses.length
    ? `WHERE ${whereClauses.join(" AND ")}`
    : "";

  const countQuery = `
    SELECT COUNT(*) AS totalCount
    FROM Products p
    ${whereSQL}
  `;

  try {
    const pool = await poolPromise;
    const req = pool.request();

    if (search) req.input("search", sql.NVarChar, search);
    if (shopId) req.input("shopId", sql.Int, shopId);
    if (isActive !== undefined) req.input("isActive", isActive);

    const result = await req.query(countQuery);
    const totalCount = result.recordset[0]?.totalCount ?? 0;
    const totalPages = Math.ceil(totalCount / limit);

    return {
      totalCount,
      totalPages,
    };
  } catch (error: any) {
    console.error("Error getting pagination:", error);
    throw new Error("Error fetching merchant products: " + error.message);
  }
};

export const updateMerchantStatusInDb = async (
  id: number,
  isEnabled: boolean
) => {
  const query = `
    UPDATE Shops
    SET shop_delisted = @isEnabled
    WHERE shop_id = @id
  `;

  try {
    const pool = await poolPromise;
    const result = await pool
      .request()
      .input("id", id)
      .input("isEnabled", isEnabled)
      .query(query);
    return result.recordset;
  } catch (error: any) {
    console.error("Error updating merchant status:", error);
    throw new Error("Error updating merchant status: " + error.message);
  }
};

export const getMerchantsDropdown = async (
  page: number,
  limit: number,
  searchKeyword?: string
): Promise<{
  merchants: MerchantDropdown[];
  totalCount: number;
  totalPages: number;
}> => {
  const offset = (page - 1) * limit;
  const search = (searchKeyword ?? "").trim();

  const query = `
    SELECT 
      s.shop_id,
      s.shop_name,
      s.shop_logo_url
    FROM dbo.Shops AS s
    WHERE (@search = '' OR s.shop_name LIKE '%' + @search + '%')
    ORDER BY s.shop_id DESC
    OFFSET @offset ROWS FETCH NEXT @limit ROWS ONLY;
  `;

  const countQuery = `
    SELECT COUNT(*) AS totalCount
    FROM dbo.Shops AS s
    WHERE (@search = '' OR s.shop_name LIKE '%' + @search + '%');
  `;

  const pool = await poolPromise;

  const listReq = pool
    .request()
    .input("search", sql.NVarChar, search)
    .input("offset", sql.Int, offset)
    .input("limit", sql.Int, limit);

  const listRes = await listReq.query<MerchantDropdown>(query);

  const countReq = pool.request().input("search", sql.NVarChar, search);
  const countRes = await countReq.query<{ totalCount: number }>(countQuery);

  const totalCount = countRes.recordset[0]?.totalCount ?? 0;
  const totalPages = Math.ceil(totalCount / limit);

  return {
    merchants: listRes.recordset,
    totalCount,
    totalPages,
  };
};

export const getBrandCount = async (limit: number, searchKeyword?: string) => {
  // Guard: avoid divide-by-zero later
  const pageSize = Math.max(1, Number(limit) || 1);

  // Build WHERE only if a keyword is provided
  const hasSearch =
    typeof searchKeyword === "string" && searchKeyword.trim().length > 0;
  const whereClauses: string[] = [];

  if (hasSearch) {
    whereClauses.push("b.brand_name LIKE @search");
  }
  whereClauses.push("b.brand_status = 'true'");

  const whereClause = whereClauses.length
    ? `WHERE ${whereClauses.join(" AND ")}`
    : "";

  // Count only (no extra columns needed)
  const query = `
    SELECT COUNT(*) AS totalCount
    FROM Brands AS b
    ${whereClause};
  `;

  try {
    const pool = await poolPromise;
    const req = pool.request();

    if (hasSearch) {
      // Bind the wildcarded value instead of concatenating in SQL
      req.input("search", `%${searchKeyword!.trim()}%`);
    }

    const result = await req.query(query);
    const totalCount = result.recordset[0]?.totalCount ?? 0;
    const totalPages = Math.ceil(totalCount / pageSize);

    return {
      totalCount,
      totalPages,
    };
  } catch (error: any) {
    throw new Error("Error fetching brand count: " + error.message);
  }
};

export const getBrandRequestCount = async (limit: number, page: number) => {
  const pageSize = Math.max(1, Number(limit) || 1);
  const offset = (page - 1) * pageSize;
  const query = `SELECT COUNT(*) AS totalCount FROM Brands b JOIN Brand_Approvals ba  on b.brand_id = ba.brand_approval_brand_id WHERE b.brand_status='false' AND ba.created_at = ba.updated_at`;
  try {
    const pool = await poolPromise;
    const request = pool.request();
    const result = await request.query(query);
    const totalCount = result.recordset[0]?.totalCount ?? 0;
    const totalPages = Math.ceil(totalCount / pageSize);
    return {
      totalCount,
      totalPages,
    };
  } catch (error: any) {
    throw new Error("Error fetching brand count: " + error.message);
  }
};

export const updateBrandsModel = async (brand_id: number,brand_name:string, brand_need_desc: string, brand_logo_url: string) => {
  const pool = await poolPromise;
  const tx = new sql.Transaction(pool);
  try {
    await tx.begin();

    if (brand_logo_url) {
      await new sql.Request(tx)
        .input("brand_id", sql.Int, brand_id)
        .input("brand_logo_url", sql.NVarChar, brand_logo_url).query(`
          UPDATE Brands
          SET brand_logo_url = @brand_logo_url
          WHERE brand_id = @brand_id;
        `);
    }
    if (brand_name) {
      await new sql.Request(tx)
        .input("brand_id", sql.Int, brand_id)
        .input("brand_name", sql.NVarChar, brand_name).query(`
          UPDATE Brands
          SET brand_name = @brand_name
          WHERE brand_id = @brand_id;
        `);
    }

    if (brand_need_desc) {
      await new sql.Request(tx)
        .input("brand_id", sql.Int, brand_id)
        .input("brand_need_desc", sql.NVarChar, brand_need_desc).query(`
          UPDATE Brand_Approvals
          SET brand_need_desc = @brand_need_desc
          WHERE brand_approval_brand_id = @brand_id;
        `);
    }

    await tx.commit();
    return true;
  } catch (err: any) {
    try {
      await tx.rollback();
    } catch {}
    console.error("Error updating brand request:", err);
    throw new Error("Error updating brand request: " + err.message);
  }
};

export const updateBrandRequest = async (
  brand_id: number,
  brand_status_is_approved: boolean, 
  user_id: number,
  brand_note?: string,
  brand_approval_is_approved?: boolean 
) => {
  const pool = await poolPromise;
  const tx = new sql.Transaction(pool);

  try {
    await tx.begin();

    await new sql.Request(tx)
      .input("brand_id", sql.Int, brand_id)
      .input("brand_status", brand_status_is_approved).query(`
        UPDATE Brands
        SET brand_status = @brand_status
        WHERE brand_id = @brand_id;
      `);

    if (brand_approval_is_approved === true) {
      await new sql.Request(tx)
        .input("brand_id", sql.Int, brand_id)
        .input("flag", sql.Bit, 1)
        .input("user_id", sql.Int, user_id)
        .input("note", sql.NVarChar(sql.MAX), brand_note ?? null).query(`
          UPDATE Brand_Approvals
          SET
            brand_approval_is_approved = @flag,
            brand_approval_description = @note,
            brand_approval_admin_id     = @user_id,
            updated_at                  = GETDATE()
          WHERE brand_approval_brand_id = @brand_id;
        `);
    } else if (brand_approval_is_approved === false) {
      await new sql.Request(tx)
        .input("brand_id", sql.Int, brand_id)
        .input("user_id", sql.Int, user_id)
        .input("note", sql.NVarChar(sql.MAX), brand_note ?? null).query(`
          UPDATE Brand_Approvals
          SET
            brand_approval_description = @note,
            brand_approval_admin_id     = @user_id,
            updated_at                  = GETDATE()
          WHERE brand_approval_brand_id = @brand_id;
        `);
      // No delete. No flag change.
    }
    // If undefined, we skip touching Brand_Approvals.

    await tx.commit();

    return {
      ok: true,
      action:
        brand_approval_is_approved === true
          ? "approved_and_updated"
          : brand_approval_is_approved === false
          ? "touched_updated_at_only"
          : "brand_status_updated",
      brand_id,
    };
  } catch (err: any) {
    try {
      await tx.rollback();
    } catch {}
    console.error("Error updating brand request:", err);
    throw new Error("Error updating brand request: " + err.message);
  }
};

export const getRequestedBrandsModel = async (
  page: number,
  limit: number,
  searchKeyword?: string
) => {
  const offset = (page - 1) * limit;
  const kw = (searchKeyword ?? "").trim();
  const hasKw = kw.length > 0;
  const searchBlock = hasKw
    ? `
      AND (
        b.brand_name           LIKE @kw
        OR b.brand_website_url LIKE @kw
        OR b.brand_need_desc   LIKE @kw
      )
    `
    : "";

  const query = `
    SELECT
    b.*,s.shop_name,s.shop_description
    FROM Brands AS b join Brand_Approvals ba on ba.brand_approval_brand_id=b.brand_id join Shops s on ba.brand_approval_shop_id = s.shop_id
    WHERE b.brand_status = 'false'
    AND ba.created_at IS NOT NULL
    AND ba.updated_at IS NOT NULL
    AND ba.created_at = ba.updated_at
	  ${searchBlock}
    ORDER BY b.brand_name ASC
	  OFFSET @offset ROWS FETCH NEXT @limit ROWS ONLY;
  `;

  try {
    const pool = await poolPromise;
    const request = pool
      .request()
      .input("offset", sql.Int, offset)
      .input("limit", sql.Int, limit);

    if (hasKw) {
      request.input("kw", sql.NVarChar, `%${kw}%`);
    }

    const result = await request.query(query);
    return result.recordset;
  } catch (error) {
    console.error("getRequestedBrandsModel error:", error);
    throw error;
  }
};

export const getBrandsModel = async (
  page: number,
  limit: number,
  searchKeyword?: string
) => {
  const offset = (page - 1) * limit;

  let whereClauses: string[] = [];
  whereClauses.push("b.brand_status = 'true'");

  if (searchKeyword) {
    whereClauses.push(`b.brand_name LIKE '%' + @search + '%'`);
  }

  const whereClause = whereClauses.length
    ? `WHERE ${whereClauses.join(" AND ")}`
    : "";

  const paginationClause = searchKeyword
    ? ""
    : "OFFSET @offset ROWS FETCH NEXT @limit ROWS ONLY";

  const query = `
    SELECT
  b.brand_id,
  b.brand_name,
  b.brand_logo_url,
  b.brand_website_url,
  x.product_shop_id
FROM Brands AS b
OUTER APPLY (
  SELECT TOP (1) p.product_shop_id
  FROM Products AS p
  WHERE p.product_brand_id = b.brand_id
  ORDER BY p.product_shop_id ASC
) AS x
${whereClause} ORDER BY b.brand_name ${paginationClause}`;

  try {
    const pool = await poolPromise;
    const request = pool.request();

    // Add inputs conditionally
    if (!searchKeyword) {
      request.input("offset", offset);
      request.input("limit", limit);
    }

    if (searchKeyword) {
      request.input("search", searchKeyword);
    }

    const result = await request.query(query);
    return result.recordset;
  } catch (error) {
    console.error(error);
    throw error; // Re-throw the error so calling code can handle it
  }
};

export const updateTilesModel = async (
  shop_tile_id: number,
  shop_tile_charges: number,
  shop_tile_name: string
) => {
  const pool = await poolPromise;

  try {
    // --- Basic validation ---
    if (!shop_tile_id || isNaN(shop_tile_id)) {
      throw new Error("Invalid or missing shop_tile_id.");
    }
    if (shop_tile_charges == null || isNaN(shop_tile_charges)) {
      throw new Error("Invalid or missing shop_tile_charges.");
    }
    if (!shop_tile_name || typeof shop_tile_name !== "string") {
      throw new Error("Invalid or missing shop_tile_name.");
    }

    // --- Perform update with OUTPUT clause ---
    const query = `
      UPDATE Shop_Tiles
      SET 
        shop_tile_charges = @tile_charges,
        shop_tile_name = @tile_name
      OUTPUT INSERTED.*
      WHERE shop_tile_id = @tile_id
    `;

    const result = await pool
      .request()
      .input("tile_id", shop_tile_id)
      .input("tile_charges", shop_tile_charges)
      .input("tile_name", shop_tile_name)
      .query(query);

    // --- Handle cases where no rows were updated ---
    if (!result.recordset || result.recordset.length === 0) {
      return {
        success: false,
        message: `No tile found with ID ${shop_tile_id}.`,
        updatedTile: null,
      };
    }

    // --- Success response ---
    return {
      success: true,
      message: "Tile updated successfully.",
      updatedTile: result.recordset[0],
    };
  } catch (error: any) {
    console.error("Error updating tile:", error);

    // --- Database or query-level error handling ---
    return {
      success: false,
      message:
        error?.message ||
        "An unexpected error occurred while updating the tile.",
      updatedTile: null,
    };
  }
};
