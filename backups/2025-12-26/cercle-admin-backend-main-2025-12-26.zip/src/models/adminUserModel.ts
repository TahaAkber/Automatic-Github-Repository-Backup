import { poolPromise } from "../config/db";
import sql from "mssql";

export const getAllUsersFromDb = async (page: number, limit: number) => {
  const offset = (page - 1) * limit;
  const query = `SELECT 
   admin_user_id,  MAX(CAST(admin_user_isactive AS INT)) AS admin_user_isactive, min (admin_user_name) AS admin_user_name, min(created_at) AS created_at,
  STRING_AGG(admin_role_name, ',') AS Roles
  FROM (
        SELECT DISTINCT 
          au.admin_user_id,
          au.admin_user_name,
          au.created_at,
          au.admin_user_isactive,
          ar.admin_role_name
        FROM Admin_Users au
        JOIN Admin_Role_Assign ara 
          ON au.admin_user_id = ara.role_assign_user_id
        JOIN Admin_Roles ar 
          ON ara.role_assigned_id = ar.admin_role_id
  ) AS DistinctRoles
  GROUP BY admin_user_id
  ORDER BY admin_user_id DESC
  OFFSET @offset ROWS
  FETCH NEXT @limit ROWS ONLY;
`;

  try {
    const pool = await poolPromise;

    const userResult = await pool
      .request()
      .input("offset", sql.Int, offset)
      .input("limit", sql.Int, limit)
      .query(query);

    return {
      users: userResult.recordset,
    };
  } catch (error: any) {
    throw new Error("Error fetching users: " + error.message);
  }
};

export const getAllUserCount = async (limit: number) => {
  const countQuery = `SELECT COUNT(DISTINCT au.admin_user_id) AS totalCount
  FROM Admin_Users au
  JOIN Admin_Role_Assign ara 
    ON au.admin_user_id = ara.role_assign_user_id
  JOIN Admin_Roles ar 
    ON ara.role_assigned_id = ar.admin_role_id;
`;
  const pool = await poolPromise;

  try {
    const countResult = await pool.request().query(countQuery);

    const totalCount = countResult.recordset[0].totalCount;
    const totalPages = Math.ceil(totalCount / limit);
    return {
      totalCount,
      totalPages,
    };
  } catch (error: any) {
    throw new Error("Error fetching total user count: " + error.message);
  }
};
export const updateUserStatus = async (id: any, status: boolean) => {
  const pool = await poolPromise;
  try {
    const response = await pool
      .request()
      .input("id", sql.VarChar, id)
      .input("status", status).query(`
       UPDATE Admin_Users
       SET admin_user_isactive = @status, updated_at = GETDATE()
       WHERE admin_user_id = @id
     `);
    return response.rowsAffected[0];
  } catch (error) {
    console.error("Error updating user status:", error);
  }
};

export const updateUser = async (id: number, body: any) => {
  const pool = await poolPromise;
  const tx = new sql.Transaction(pool);
  console.log("roles", body, id);
  try {
    await tx.begin();

    // 1) Update the user
    {
      const req = new sql.Request(tx);
      await req
        .input("id", sql.Int, id)
        .input("name", sql.VarChar, body.name)
        .input("isactive", sql.Bit, body.isActive ? 1 : 0).query(`
          UPDATE Admin_Users
          SET admin_user_name = @name,
              admin_user_isactive = @isactive,
              updated_at = GETDATE()
          WHERE admin_user_id = @id
        `);
    }

    // 2) Clear old role assignments
    {
      const req = new sql.Request(tx);
      await req.input("id", sql.Int, id).query(`
        DELETE FROM Admin_Role_Assign
        WHERE role_assign_user_id = @id
      `);
    }

    for (let i = 0; i < body.roles.length; i++) {
      const req = new sql.Request(tx);

      const { roleId, read, write } = body.roles[i];

      const paramUserId = `${id}`;
      const paramRoleId = `roleId_${i}`;
      const paramRead = `read_${i}`;
      const paramWrite = `write_${i}`;

      await req
        .input(paramUserId, sql.Int, id)
        .input(paramRoleId, sql.Int, roleId)
        .input(paramRead, sql.Bit, read)
        .input(paramWrite, sql.Bit, write).query(`
          INSERT INTO Admin_Role_Assign (
            role_assign_user_id, 
            role_assigned_id,
            role_assigned_read,
            role_assigned_write,
            created_at
          )
          VALUES (
            @${paramUserId}, 
            @${paramRoleId}, 
            @${paramRead}, 
            @${paramWrite}, 
            GETDATE()
          )
        `);
    }

    await tx.commit();
    return { success: true, message: "User updated successfully" };
  } catch (error: any) {
    await tx.rollback();
    console.error("Error updating user:", error);
    return {
      success: false,
      message: "Error updating user",
      error: error?.message,
    };
  }
};

export const deleteUserById = async (id: any) => {
  const pool = await poolPromise;
  try {
    await pool.request().input("id", sql.VarChar, id).query(`
      DELETE FROM Admin_Role_Assign
      WHERE role_assign_user_id = @id
    `);

    const response = await pool.request().input("id", sql.VarChar, id).query(`
       DELETE FROM Admin_Users
       WHERE admin_user_id = @id
     `);
    return response.rowsAffected[0];
  } catch (error) {
    console.error("Error deleting user:", error);
  }
};
