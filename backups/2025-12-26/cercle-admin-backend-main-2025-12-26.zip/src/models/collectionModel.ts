import { poolPromise } from "../config/db";
import sql from "mssql";

export const getAllCollectionFromDb = async (page: number, limit: number) => {
  const offset = (page - 1) * limit;

  const trendingQuery = `
    SELECT t.*
    FROM Trending_Collections AS t
    ORDER BY t.trending_id DESC
    OFFSET @offset ROWS
    FETCH NEXT @limit ROWS ONLY;
  `;

  const countsQuery = `
    SELECT
      c.collection_name,
      SUM(c.collection_product_count)              AS total_product_count,
      COUNT(DISTINCT c.collection_shop_id)         AS shop_count,
      (
        SELECT
          s.shop_logo_url
        FROM Collections AS c2
        JOIN Shops       AS s ON s.shop_id = c2.collection_shop_id
        WHERE 
          c2.collection_type_id = 2
          AND c2.collection_name = c.collection_name
        FOR JSON PATH
      )                                            AS shops_json
    FROM Collections AS c
    WHERE c.collection_type_id = 2
    GROUP BY c.collection_name
    ORDER BY total_product_count DESC;
  `;

  try {
    const pool = await poolPromise;

    // Paginated trending rows
    const collections = await pool
      .request()
      .input("offset", sql.Int, offset)
      .input("limit", sql.Int, limit)
      .query(trendingQuery);

    // Aggregated counts per collection_name
    const countsResult = await pool.request().query(countsQuery);

    // Build lookup: collection_name -> info
    const nameToInfo = new Map<
      string,
      { total_product_count: number; shop_count: number; shops_json: string }
    >();

    for (const row of countsResult.recordset) {
      nameToInfo.set(row.collection_name, {
        total_product_count: Number(row.total_product_count) || 0,
        shop_count: Number(row.shop_count) || 0,
        shops_json: row.shops_json ?? "[]", // JSON array of { shop_logo_url }
      });
    }

    // Merge info into trending rows by name
    const mergedTrending = collections.recordset.map((t: any) => {
      const info = nameToInfo.get(t.trending_name) ?? {
        total_product_count: 0,
        shop_count: 0,
        shops_json: "[]",
      };

      return {
        ...t,
        total_product_count: info.total_product_count,
        shop_count: info.shop_count,
        shops_json: info.shops_json,
      };
    });

    return {
      collections: mergedTrending,
    };
  } catch (error: any) {
    throw new Error("Error fetching Trending Collections: " + error.message);
  }
};

export const createTrendingCollectionModel = async (
  collection_Description: string,
  collection_Title: string,
  collection_image_url: string,
  end_Date: string
) => {
  const query = `
  INSERT INTO Trending_Collections (trending_description, trending_name, trending_banner_url, trending_expiration_date)
        VALUES (@collection_Description, @collection_Title, @collection_image_url, @end_Date)`;
  const pool = await poolPromise;
  try {
    const result = await pool
      .request()
      .input("collection_Description", sql.NVarChar, collection_Description)
      .input("collection_Title", sql.NVarChar, collection_Title)
      .input("collection_image_url", sql.NVarChar, collection_image_url)
      .input("end_Date", sql.NVarChar, end_Date)
      .query(query);

    return result.recordset;
  } catch (error: any) {
    throw new Error("Error creating Trending Collection: " + error.message);
  }
};

export const getCollectionByIdModel = async (collection_id: number) => {
  const pool = await poolPromise;

  // If your IDs can be BIGINT, switch sql.Int → sql.BigInt
  const result = await pool
    .request()
    .input("collection_id", sql.Int, collection_id).query(`
      SELECT
        tc.*,                               -- Trending_Collections fields
        c.collection_id       AS collection_id_ref,
        c.collection_name     AS collection_name_ref,
        c.collection_product_count AS collection_product_count_ref,
        s.shop_id             AS shop_id_ref,
        s.shop_name           AS shop_name_ref,
        s.shop_logo_url       AS shop_logo_url_ref
      FROM dbo.Trending_Collections AS tc
      LEFT JOIN dbo.Collections AS c
        ON c.collection_name = tc.trending_name
      LEFT JOIN dbo.SHOPS AS s
        ON s.shop_id = c.collection_shop_id
      WHERE tc.trending_id = @collection_id;
    `);

  if (!result.recordset?.length) {
    throw new Error(`Trending collection not found for id=${collection_id}`);
  }

  // keep your original return shape (collections: ...)
  return { collections: result.recordset };
};
export const updateTrendingCollectionModel = async (
  collection_id: number,
  collection_Description: string,
  collection_image_url: string
) => {
  const pool = await poolPromise;

  let query = `UPDATE Trending_Collections SET `;
  if (collection_Description && collection_image_url) {
    query += `trending_description = @collection_Description, trending_banner_url = @collection_image_url `;
  } else if (collection_Description) {
    query += `trending_description = @collection_Description `;
  } else if (collection_image_url) {
    query += `trending_banner_url = @collection_image_url `;
  }
  query += `WHERE trending_id = @collection_id;`;
  const updateQuery = query;
  try {
    const result = await pool
      .request()
      .input("collection_id", collection_id)
      .input("collection_Description", collection_Description)
      .input("collection_image_url", collection_image_url)
      .query(updateQuery);
    return result.recordset;
  } catch (error: any) {
    throw new Error("Error updating Trending Collection: " + error.message);
  }
};
export const getTotalCollectionsCount = async (limit: number) => {
  const countTrendingQuery = `SELECT COUNT(*) AS totalCount FROM Trending_Collections;`;

  try {
    const pool = await poolPromise;
    // Total trending count
    const countResult = await pool.request().query(countTrendingQuery);
    const totalCount = Number(countResult.recordset[0].totalCount) || 0;
    const totalPages = Math.ceil(totalCount / limit);
    return {
      totalCount,
      totalPages,
    };
  } catch (error: any) {
    throw new Error(
      "Error fetching total Trending Collection count: " + error.message
    );
  }
};

export const deleteTrendingCollectionModel = async (trending_id: number) => {
  const pool = await poolPromise;

  const query = `
  BEGIN TRY
    BEGIN TRAN;

    DECLARE @trending_name NVARCHAR(255);

    
    SELECT @trending_name = trending_name
    FROM Trending_Collections
    WHERE trending_id = @trending_id;

    IF @trending_name IS NULL
    BEGIN
      RAISERROR('Trending collection not found', 16, 1);
    END

    
    DELETE cp
    FROM Collection_Products AS cp
    INNER JOIN Collections AS c
      ON c.collection_id = cp.collection_id
    WHERE c.collection_type_id = 2
      AND c.collection_name = @trending_name;

  
    DELETE c
    FROM Collections AS c
    WHERE c.collection_type_id = 2
      AND c.collection_name = @trending_name;

    
    DELETE FROM Trending_Collections
    WHERE trending_id = @trending_id;

    COMMIT TRAN;
  END TRY
  BEGIN CATCH
    IF @@TRANCOUNT > 0 ROLLBACK TRAN;
    THROW;
  END CATCH;
  `;

  try {
    await pool.request().input("trending_id", trending_id).query(query);

    return true;
  } catch (error: any) {
    throw new Error("Error deleting Trending Collection: " + error.message);
  }
};

export const updateTrendingStatus = async (
  is_active: boolean,
  trending_id: number
) => {
  // Placeholder for future implementation
  const pool = await poolPromise;
  const query = `Update Trending_Collections Set trending_is_active = @is_active Where trending_id = @trending_id`;
  try {
    const result = await pool
      .request()
      .input("is_active", is_active)
      .input("trending_id", trending_id)
      .query(query);
    return result.recordset;

    // Implementation goes here
  } catch (error: any) {
    throw new Error("Error updating Trending Status: " + error.message);
  }
};
