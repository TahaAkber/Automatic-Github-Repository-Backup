import { Router } from "express";
import { validateToken } from "../middlewares/authMiddleware";
import {
  getAllOrders,
  getCancelOrders,
  getOrderItems,
  getOrderDetail,
} from "../controllers/orderController";

const router = Router();

router.get("/all", validateToken, getAllOrders);
router.get("/orderdetail/:id", validateToken, getOrderDetail);
router.get("/orderitems/:id", validateToken, getOrderItems);
router.get("/cancel-orders", validateToken, getCancelOrders);

export default router;
