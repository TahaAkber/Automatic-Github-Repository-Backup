import { Router } from "express";
import { validateToken } from "../middlewares/authMiddleware";
import {
  deletePlans,
  updatePlans,
  createPlans,
  getPlans,
} from "../controllers/planController";

const router = Router();

router.get("/All", validateToken, getPlans);
router.post("/createplan", validateToken, createPlans);
router.put("/updateplan/:id", validateToken, updatePlans);
router.delete("/deleteplan/:planId", validateToken, deletePlans);

export default router;
