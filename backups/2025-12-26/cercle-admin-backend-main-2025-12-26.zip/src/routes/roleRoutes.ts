import { Router } from "express";
import {
  getRoles,
  updateRole,
} from "../controllers/roleController";
import { validateToken } from "../middlewares/authMiddleware";

const router = Router();

router.get("/all", validateToken, getRoles);
router.put("/edit", validateToken, updateRole);

export default router;
