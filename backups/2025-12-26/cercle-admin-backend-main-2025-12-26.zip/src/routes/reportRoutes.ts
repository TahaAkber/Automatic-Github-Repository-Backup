import { Router } from "express";
import { validateToken } from "../middlewares/authMiddleware";
import { deleteReport, getAllReports, updateReportStatus } from "../controllers/reportController";

const router = Router();

router.get("/all", validateToken, getAllReports);
router.delete("/deleteReport/:id", validateToken, deleteReport);
router.put("/updateStatus/:id", validateToken, updateReportStatus);

export default router;
