import { Router } from "express";
import { validateToken } from "../middlewares/authMiddleware";
import {
  getAllUsers,
  updateUser,
  deleteUser,
} from "../controllers/adminUserController";

const router = Router();

router.get("/all", validateToken, getAllUsers);
router.put("/updatestatus", validateToken, updateUser);
router.delete("/delete", validateToken, deleteUser);

export default router;
