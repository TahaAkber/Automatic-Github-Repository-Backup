import { Router } from "express";
import { validateToken } from "../middlewares/authMiddleware";
import {
  createTrendingCollection,
  deleteTrendingCollecton,
  getAllCollections,
  getCollecionById,
  updateTrendingCollection,
  updateTrendingCollectionStatus,
} from "../controllers/collectionController";

const router = Router();

router.get("/all", validateToken, getAllCollections);
router.post("/createcollection", validateToken, createTrendingCollection);
router.post(
  "/deleteTrendingCollection",
  validateToken,
  deleteTrendingCollecton
);
router.post(
  "/updateTrendingStatus",
  validateToken,
  updateTrendingCollectionStatus
);
router.post(
  "/updateTrendingCollection",
  validateToken,
  updateTrendingCollection
);
router.get("/:collection_id", validateToken, getCollecionById);

export default router;
