import { Router } from "express";
import { validateToken } from "../middlewares/authMiddleware";
import {
  getAllProducts,
  getProductReviews,
  getProductsDropdownList,
} from "../controllers/productController";

const router = Router();

router.get("/all", validateToken, getAllProducts);
router.get("/dropdown", validateToken, getProductsDropdownList);
router.get("/reviews", validateToken, getProductReviews);

export default router;
