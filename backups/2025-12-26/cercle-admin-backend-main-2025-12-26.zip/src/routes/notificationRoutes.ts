import { Router } from "express";
import { validateToken } from "../middlewares/authMiddleware";
import {
  createInAppNotification,
  deleteInAppNotification,
  getAllInAppNotification,
  getScheduledAppNotification,
  setNotificationActiveToggleController,
} from "../controllers/notificationController";

const router = Router();

router.get("/inApp", validateToken, getAllInAppNotification);
router.get("/scheduled", validateToken, getScheduledAppNotification);
router.post("/inApp", validateToken, createInAppNotification);
router.delete("/inApp/:id", validateToken, deleteInAppNotification);
router.put("/inApp/:id/active", setNotificationActiveToggleController);

export default router;
