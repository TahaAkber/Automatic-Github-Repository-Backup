import { Router } from "express";
import { validateToken } from "../middlewares/authMiddleware";
import {
  getAllBrands,
  getAllMerchants,
  getMerchantDetails,
  getMerchantsDropdownList,
  getMerchantProducts,
  merchantIsEnable,
  getRequestedBrands,
  approveBrandsRequest,
  getTiles,
  updateTiles,updateBrands
} from "../controllers/merchantController";

const router = Router();

router.get("/all", validateToken, getAllMerchants);
router.get("/dropdown", validateToken, getMerchantsDropdownList);
router.get("/products", validateToken, getMerchantProducts);
router.get("/details", validateToken, getMerchantDetails);
router.get("/brands", validateToken, getAllBrands);
router.get("/request-brands", validateToken, getRequestedBrands);
router.get("/tiles", validateToken, getTiles);
router.post("/enable", validateToken, merchantIsEnable);
router.post("/approve-brands", validateToken, approveBrandsRequest);
router.post("/tile-update", validateToken, updateTiles);
router.post("/update-brands", validateToken, updateBrands);

export default router;
