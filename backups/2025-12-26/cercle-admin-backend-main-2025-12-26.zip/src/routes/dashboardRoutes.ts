import { Router } from "express";
import { validateToken } from "../middlewares/authMiddleware";
import {
    getDashboardBestSeller,
    getDashboardShopPrices,
  getDashboardShopProducts,
  getDashboardTransactions,
} from "../controllers/dashboardController";

const router = Router();

router.get("/transactions", validateToken, getDashboardTransactions);
router.get("/shop-products", validateToken, getDashboardShopProducts);
router.get("/shop-prices", validateToken, getDashboardShopPrices);
router.get("/best-seller", validateToken, getDashboardBestSeller);


export default router;
