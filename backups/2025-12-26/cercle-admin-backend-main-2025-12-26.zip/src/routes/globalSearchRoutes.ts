import { Router } from "express";
import { validateToken } from "../middlewares/authMiddleware";
import { globalSearch } from "../controllers/globalSearchController";

const router = Router();

router.get("/", validateToken, globalSearch);

export default router;
