import { Router } from "express";
import {
  getAdminCharges,
  getTrackingDetails,
  updateCharges,
} from "../controllers/trackingController";
import { validateToken } from "../middlewares/authMiddleware";

const router = Router();

router.get("/details", validateToken, getTrackingDetails);
router.get("/admin-charges", validateToken, getAdminCharges);
router.post("/update-charges", validateToken, updateCharges);

export default router;
