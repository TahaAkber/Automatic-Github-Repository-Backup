import { Router } from "express";
import {
  login,
  register,
  resetFirstPasswordController,
  forgotPassword,
} from "../controllers/authController";

const router = Router();

router.post("/login", login);
router.post("/register", register);
router.post("/reset-password", resetFirstPasswordController);
router.post("/forgot-password", forgotPassword);

export default router;
