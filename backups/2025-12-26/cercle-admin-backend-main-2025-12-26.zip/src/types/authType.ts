export interface LoginRequestBody {
  email: string;
  password: string;
}

export interface Admin_Users {
  admin_user_id: number;
  admin_user_name: string;
  admin_user_email: string;
  admin_user_password: string;
  admin_user_roles: any[];
  admin_user_onboarded: boolean;
}

export interface ChangePasswordBody {
  email: string;
  oldPassword: string;
  newPassword: string;
  otpToken?: string;
}

export interface RegisterAdminBody {
  username: string;
  email: string;
  roles: any[];
}

declare global {
  namespace Express {
    interface Request {
      user?: {
        id: number;
        email: string;
        username: string;
        roles: string[];
      };
    }
  }
}
