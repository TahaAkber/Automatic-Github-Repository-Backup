export type MerchantDropdown = {
  shop_id: number;
  shop_name: string;
  shop_logo_url: string | null;
};
