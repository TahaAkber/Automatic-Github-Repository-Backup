export type ProductDropdowns = {
  product_id: number;
  product_name: string;
  product_image_url: string | null;
};
