import express, { Request, Response } from "express";
import dotenv from "dotenv";
import path from "path";
import authRoutes from "./src/routes/authRoutes";
import rolesRoutes from "./src/routes/roleRoutes";
import ordersRoutes from "./src/routes/orderRoutes";
import merchantRoutes from "./src/routes/merchantRoutes";
import adminUserRoutes from "./src/routes/adminUserRoutes";
import planRoutes from "./src/routes/planRoutes";
import reportRoutes from "./src/routes/reportRoutes";
import collectionRoute from "./src/routes/collectionRoutes";
import productRoutes from "./src/routes/productRoutes";
import trackingRoutes from "./src/routes/trackingRoutes";
import notificationRoutes from "./src/routes/notificationRoutes";
import uploadRoutes from "./src/routes/uploadRoutes";
import dashboardRoutes from "./src/routes/dashboardRoutes";
import globalsearch from "./src/routes/globalSearchRoutes";
import { processNotifications } from "./src/utils/notification/notificationEvent";
import cron from "node-cron";

const cors = require("cors");

dotenv.config();

const app = express();
const port = process.env.PORT || 3500;
const corsOptions = {
  credentials: true,
  origin: [
    "http://localhost:3000",
    "http://localhost:5173",
    "http://localhost:5174",
    "http://localhost:4173",
    "https://admin-staging.cercle.one",
  ],
};

// Middleware
app.use(cors(corsOptions));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve uploaded files statically
const joinedPath = path.join(__dirname, "/src/uploads");
console.log("joinedPath", joinedPath);
app.use("/uploads", express.static(joinedPath));

// Shopify Routes
app.use("/api/auth", authRoutes);
app.use("/api/role", rolesRoutes);
app.use("/api/orders", ordersRoutes);
app.use("/api/merchant", merchantRoutes);
app.use("/api/users", adminUserRoutes);
app.use("/api/plans", planRoutes);
app.use("/api/collections", collectionRoute);
app.use("/api/search", globalsearch);
app.use("/api/products", productRoutes);
app.use("/api/tracking", trackingRoutes);
app.use("/api/upload", uploadRoutes);
app.use("/api/notifications", notificationRoutes);
app.use("/api/dashboard", dashboardRoutes);
app.use("/api/reports", reportRoutes) 
app.get("/", (req: Request, res: Response) => {
  res.send("Cercle Admin Backend Working");
});



app.get("/api", (req: Request, res: Response) => {
  res.send("Please define an API route after api/");
});

// Start Server
app.listen(port, () => {
  console.log(`Server is running on port http://localhost:${port}`);
});

cron.schedule("*/5 * * * *", async () => {
  console.log("⏰ Running notification cron job (every 5 mins)");
  await processNotifications();
});
