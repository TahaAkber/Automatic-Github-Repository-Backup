import React from 'react';
import { View } from 'react-native';
import AppNavigationContainer from './src/navigation/navigationContainer';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import GlobalLoader from '@component/loader/globalLoader';
import Toast from 'react-native-toast-message';
import useApp from './useApp';
import { GestureHandlerRootView } from 'react-native-gesture-handler';

const App = () => {
  const { globalLoader } = useApp({});
  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaProvider>
        {globalLoader && (
          <View style={{ zIndex: 1 }}>
            <GlobalLoader />
          </View>
        )}
        <AppNavigationContainer />
        <Toast />
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
};

export default App;