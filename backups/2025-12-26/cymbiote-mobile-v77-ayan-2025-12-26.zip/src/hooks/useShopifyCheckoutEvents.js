import {useEffect} from 'react';
import {useShopifyCheckoutSheet} from '@shopify/checkout-sheet-kit';
import {navigate} from '../utils/navigationRef/navigationRef';
import useReduxStore from '../utils/hooks/useReduxStore';

export default function useShopifyCheckoutEvents({checkOutDetail}) {
  const shopifyCheckout = useShopifyCheckoutSheet();
  const {getState} = useReduxStore();
  const {fetch_user_detail} = getState('auth');
  useEffect(() => {
    const subCompleted = shopifyCheckout.addEventListener(
      'completed',
      event => {
        shopifyCheckout.dismiss();
        const data = {
          ...checkOutDetail,
          order_email: event?.orderDetails?.email,
        };
        navigate('Checkout', data);
      },
    );

    const subDismissed = shopifyCheckout.addEventListener('close', event => {
    });

    return () => {
      subCompleted?.remove?.();
      subDismissed?.remove?.();
    };
  }, [shopifyCheckout, checkOutDetail]);

  return {shopifyCheckout};
}
