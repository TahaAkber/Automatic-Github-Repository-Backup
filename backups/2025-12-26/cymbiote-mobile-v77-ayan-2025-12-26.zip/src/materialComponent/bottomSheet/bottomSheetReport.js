import React, {
  useMemo,
  useState,
  forwardRef,
  useCallback,
  useEffect,
} from 'react';
import {
  View,
  TouchableOpacity,
  StyleSheet,
  Dimensions,
  TextInput,
} from 'react-native';
import {moderateScale, verticalScale} from 'react-native-size-matters';
import {colors, font, margin, WH} from '@constant/contstant';
import Icon from '@materialComponent/icon/icon';
import GorhomBottomSheet from './GorhomBottomSheet';
import CustomText from '@materialComponent/customText/customText';
import useReduxStore from '../../utils/hooks/useReduxStore';
import {_reportItem} from '../../redux/actions/merchant/merchant';
import CustomButton from '../customButton/customButton';

const {height: screenHeight, fontScale} = Dimensions.get('screen');

const BASE_HEIGHT = screenHeight * 0.6;
const DETAIL_HEIGHT = screenHeight * 0.55;
const OPTION_TOP_SPACE = verticalScale(8);

const productTree = [
  {
    id: 'product-info',
    title: 'Product Information Issues',
    defaultInput: true,
    placeHolder: 'Please specify (optional)',
    options: [
      {id: 'misleading-info', title: 'Misleading or incorrect information'},
      {id: 'pricing-issue', title: 'Wrong price or pricing issue'},
    ],
  },
  {
    id: 'authenticity',
    title: 'Authenticity Issues',
    defaultInput: true,
    placeHolder: 'Please specify (optional)',
    options: [
      {id: 'counterfeit', title: 'Counterfeit product'},
      {
        id: 'image-quality',
        title: 'Product images do not match original brand quality',
      },
    ],
  },
  {
    id: 'content-behaviour',
    title: 'Content & Behaviour Issues',
    defaultInput: true,
    placeHolder: 'Please specify (optional)',
    options: [
      {id: 'offensive', title: 'Inappropriate or offensive content'},
      {id: 'irrelevant', title: 'Irrelevant listing'},
    ],
  },
  {
    id: 'quality-safety',
    title: 'Quality & Safety Issues',
    defaultInput: true,
    placeHolder: 'Please specify (optional)',
    options: [
      {id: 'poor-quality', title: 'Poor quality or damaged product shown'},
      {id: 'unsafe', title: 'Unsafe or harmful product'},
    ],
  },
  {
    id: 'other',
    title: 'Other (please specify)',
    allowInput: true,
  },
];

const shopTree = [
  {
    id: 'fraud-authenticity',
    title: 'Fraud & Authenticity Issues',
    defaultInput: true,
    placeHolder: 'Please specify (optional)',
    options: [
      {id: 'shop-scam', title: 'Shop is a scam'},
      {id: 'fake-products', title: 'Selling fake / counterfeit products'},
    ],
  },
  {
    id: 'order-delivery',
    title: 'Order & Delivery Issues',
    defaultInput: true,
    placeHolder: 'Please specify (optional)',
    options: [
      {id: 'never-delivered', title: 'Shop never delivered my order'},
      {
        id: 'cancelled-unclear',
        title: 'Cancelled my order without a clear reason',
      },
    ],
  },
  {
    id: 'pricing-availability',
    title: 'Pricing & Availability Issues',
    defaultInput: true,
    placeHolder: 'Please specify (optional)',
    options: [
      {
        id: 'price-mismatch',
        title: 'Prices or charges are different from what was shown',
      },
      {
        id: 'always-out-of-stock',
        title: 'Keeps showing out-of-stock or unavailable items',
      },
    ],
  },
  {
    id: 'other',
    title: 'Other (please specify)',
    allowInput: true,
  },
];

const reelTree = [
  {
    id: 'inappropriate-offensive',
    title: 'Inappropriate or Offensive Content',
    defaultInput: true,
    placeHolder: 'Please specify (optional)',
    options: [
      {id: 'inappropriate-visuals', title: 'Contains inappropriate visuals'},
      {
        id: 'offensive-language',
        title: 'Contains abusive or offensive language',
      },
    ],
  },
  {
    id: 'misleading-false',
    title: 'Misleading or False Information',
    defaultInput: true,
    placeHolder: 'Please specify (optional)',
    options: [
      {id: 'misleading-claims', title: 'Misleading claims or promotions'},
      {id: 'false-info', title: 'False or incorrect information shown'},
    ],
  },
  {
    id: 'copyright-ownership',
    title: 'Copyright & Ownership Issues',
    defaultInput: true,
    placeHolder: 'Please specify (optional)',
    options: [
      {
        id: 'unauthorized-content',
        title: 'Using someone else’s content without permission',
      },
      {
        id: 'brand-misuse',
        title: 'Misuse of brand name, logo, or copyrighted material',
      },
    ],
  },
  {
    id: 'spam-irrelevant',
    title: 'Spam & Irrelevant Content',
    defaultInput: true,
    placeHolder: 'Please specify (optional)',
    options: [
      {
        id: 'spam-content',
        title: 'Irrelevant, repetitive, or spam content',
      },
      {
        id: 'low-quality-promo',
        title: 'Low-quality promotional content',
      },
    ],
  },
  {
    id: 'other',
    title: 'Other (please specify)',
    allowInput: true,
  },
];

const BottomSheetReport = forwardRef(
  (
    {
      onSubmit,
      onClose,
      tree,
      closeOnSubmit = false,
      product = false,
      shop = false,
      reel = false,
      story = false,
      id,
    },
    ref,
  ) => {
    const {dispatch} = useReduxStore();
    const [loader, setLoader] = useState(false);

    console.log('product =>', product, id);

    const selectedTree = useMemo(() => {
      if (tree) return tree;
      if (product) return productTree;
      if (shop) return shopTree;
      if (reel) return reelTree;
      if (story) return reelTree;
      return productTree;
    }, [product, shop, reel, tree]);

    const rootNode = useMemo(() => {
      const title = story
        ? 'Report Story'
        : product
        ? 'Report product'
        : shop
        ? 'Report shop'
        : reel
        ? 'Report reel'
        : 'Report';
      return {
        id: 'root',
        title,
        description: 'Help us keep the platform safe by choosing a reason.',
        options: selectedTree,
      };
    }, [product, reel, selectedTree, shop]);

    const [flow, setFlow] = useState({
      stack: [rootNode], // breadcrumb of steps
      leaf: null, // final selected leaf
      note: '',
    });

    const resetFlow = useCallback(
      () => setFlow({stack: [rootNode], leaf: null, note: ''}),
      [rootNode],
    );

    const currentNode = flow.stack[flow.stack.length - 1];
    const isRoot = currentNode.id === 'root';
    const wantsInput = flow.leaf?.allowInput || currentNode.defaultInput;
    const sheetHeight = useMemo(() => {
      const base = isRoot ? BASE_HEIGHT : DETAIL_HEIGHT;
      const shouldBump = wantsInput && isRoot; // only bump when root shows input
      if (shouldBump) {
        const bump = verticalScale(100); // give input room
        const maxHeight = screenHeight * 0.9; // soften cap so it can grow
        return Math.min(maxHeight, base + bump);
      }
      return base;
    }, [isRoot, wantsInput]);

    const handleSelect = option => {
      // If option has children, dive deeper
      if (option?.options?.length) {
        setFlow(prev => ({
          stack: [...prev.stack, option],
          leaf: null,
          note: prev.note,
        }));
      } else {
        setFlow(prev => ({...prev, leaf: option}));
      }
    };

    useEffect(() => {
      if (
        currentNode?.options?.length &&
        !currentNode.options.some(opt => opt.options?.length) &&
        !flow.leaf
      ) {
        setFlow(prev => ({...prev, leaf: currentNode.options[0]}));
      }
    }, [currentNode, flow.leaf]);

    const handleSubmit = async () => {
      if (!flow.leaf) return;
      const pathIds = flow.stack
        .slice(1)
        .map(step => step.id)
        .concat(flow.leaf.id);
      const pathTitles = flow.stack
        .slice(1)
        .map(step => step.title)
        .concat(flow.leaf.title);
      setLoader(true);
      console.log('pathTitles', pathTitles);
      const res = await dispatch(
        _reportItem({
          reason: pathTitles?.[0] || '',
          subReason: pathTitles?.[1] || '',
          note: flow.note,
          id,
          type: story
            ? 'story'
            : reel
            ? 'reel'
            : shop
            ? 'shop'
            : product
            ? 'product'
            : '',
        }),
      );
      setLoader(false);
      if (res) {
        ref?.current?.close?.();
        resetFlow();
      }
    };

    const allOptionsHaveChildren =
      currentNode.options?.length &&
      currentNode.options.every(opt => opt.options?.length);

    const handleBack = () => {
      if (flow.stack.length <= 1) return;
      setFlow(prev => ({
        stack: prev.stack.slice(0, -1),
        leaf: null,
        note: '',
      }));
    };

    return (
      <GorhomBottomSheet
        ref={ref}
        height={sheetHeight}
        onClose={() => {
          resetFlow();
          onClose?.();
        }}>
        <View style={styles.container}>
          <View style={styles.body}>
            <View style={styles.header}>
              {!isRoot ? (
                <TouchableOpacity
                  onPress={handleBack}
                  style={styles.iconButton}>
                  <Icon
                    icon_type="Ionicons"
                    name="chevron-back"
                    size={moderateScale(20)}
                    color="black"
                  />
                </TouchableOpacity>
              ) : null}
              <CustomText
                fontFamily={font.bold}
                fontSize={fontScale * 18}
                color="black"
                text={currentNode.title}
                style={styles.title}
              />
            </View>

            {currentNode.description ? (
              <CustomText
                fontFamily={font.regular}
                fontSize={fontScale * 13}
                color="#6f6f6f"
                text={currentNode.description}
                style={styles.subtitle}
              />
            ) : null}

            {currentNode.options?.map((option, idx) => {
              const hasChildren = option?.options?.length;
              const isSelectedLeaf = flow.leaf?.id === option.id;
              return (
                <TouchableOpacity
                  key={option.id}
                  style={[
                    styles.row,
                    hasChildren ? styles.optionRow : null,
                    isSelectedLeaf && styles.selected,
                    idx === 0 && styles.firstOption,
                  ]}
                  onPress={() => handleSelect(option)}>
                  <View style={{flex: 1}}>
                    <CustomText
                      fontFamily={font.medium}
                      fontSize={fontScale * 14}
                      color="black"
                      text={option.title}
                      style={styles.rowTitle}
                    />
                    {option.description ? (
                      <CustomText
                        fontFamily={font.regular}
                        fontSize={fontScale * 12}
                        color="#6f6f6f"
                        text={option.description}
                        style={styles.rowDesc}
                      />
                    ) : null}
                  </View>
                  <Icon
                    icon_type="Feather"
                    name={
                      hasChildren
                        ? 'chevron-right'
                        : isSelectedLeaf
                        ? 'check-circle'
                        : 'circle'
                    }
                    size={moderateScale(18)}
                    color={
                      hasChildren
                        ? '#000'
                        : isSelectedLeaf
                        ? 'black'
                        : '#b0b0b0'
                    }
                  />
                </TouchableOpacity>
              );
            })}

            {wantsInput ? (
              <TextInput
                placeholder={
                  currentNode.defaultInput
                    ? currentNode.placeHolder || 'Please specify (optional)'
                    : flow.leaf?.placeHolder ||
                      flow.leaf?.title ||
                      currentNode.placeHolder ||
                      'Enter details (optional)'
                }
                placeholderTextColor="#9e9e9e"
                style={styles.textInput}
                value={flow.note}
                onChangeText={text => setFlow(prev => ({...prev, note: text}))}
                multiline
              />
            ) : null}
          </View>

          {!allOptionsHaveChildren && (
            <View style={styles.footer}>
              <CustomButton
                onPress={handleSubmit}
                disabled={!flow.leaf}
                text={'Submit'}
                backgroundColor={'black'}
                loader={loader}
                loaderSize={moderateScale(10)}
              />
            </View>
          )}
        </View>
      </GorhomBottomSheet>
    );
  },
);

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  body: {
    flex: 1,
  },
  footer: {
    paddingTop: verticalScale(10),
    paddingBottom: verticalScale(16),
    paddingHorizontal: moderateScale(12),
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-start',
    marginTop: verticalScale(10),
    marginBottom: verticalScale(5),
  },
  title: {
    fontFamily: font.bold,
    fontSize: fontScale * 18,
    color: 'black',
    // marginLeft: WH.width(2),
  },
  subtitle: {
    fontFamily: font.regular,
    fontSize: fontScale * 13,
    color: '#6f6f6f',
    marginBottom: verticalScale(12),
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: verticalScale(12),
    paddingHorizontal: moderateScale(12),
    borderRadius: moderateScale(12),
    backgroundColor: '#f7f7f7',
    marginTop: OPTION_TOP_SPACE,
  },
  firstOption: {
    marginTop: OPTION_TOP_SPACE,
  },
  optionRow: {
    justifyContent: 'space-between',
  },
  rowTitle: {
    fontFamily: font.medium,
    fontSize: fontScale * 14,
    color: 'black',
  },
  rowDesc: {
    fontFamily: font.regular,
    fontSize: fontScale * 12,
    color: '#6f6f6f',
    marginTop: verticalScale(3),
  },
  iconButton: {
    width: WH.width(8),
    alignItems: 'flex-start',
  },
  selected: {
    backgroundColor: '#eaeaea',
  },
  textInput: {
    marginTop: OPTION_TOP_SPACE,
    borderRadius: moderateScale(12),
    paddingVertical: verticalScale(12),
    paddingHorizontal: moderateScale(14),
    backgroundColor: '#fafafa',
    borderWidth: 1,
    borderColor: '#e0e0e0',
    color: 'black',
    minHeight: verticalScale(60),
    fontFamily: font.medium,
    fontSize: fontScale * 13,
    textAlignVertical: 'top',
  },
});

export default BottomSheetReport;
