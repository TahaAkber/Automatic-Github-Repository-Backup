import { colors, font } from '@constant/contstant';
import React, { useState } from 'react';
import {
  Dimensions,
  FlatList,
  StyleSheet,
  TouchableOpacity,
  View,
} from 'react-native';
import { moderateScale, verticalScale } from 'react-native-size-matters';
import { margin, WH } from '../../constant/contstant';
import { _cancelOrder } from '../../redux/actions/orders/orders';
import useCancellationEnums from '../../screen/loggedIn/orders/useCancellationEnums ';
import useReduxStore from '../../utils/hooks/useReduxStore';
import CustomButton from '../customButton/customButton';
import CustomText from '../customText/customText';
import CustomImage from '../image/image';
import BottomSheetProductForm from './bottomSheetProductReviewForm';
import { AuthNavigating } from '../../helper/reUsableMethod/reUsableMethod';
import { _checkout } from '../../redux/actions/cart/cart';
import Icon from '../icon/icon';
import { defaultShopImages, formatPrice } from '../../utils/helper/helper';
import { currency } from '../../constant/signature';
import { navigate } from '../../utils/navigationRef/navigationRef';
import GorhomBottomSheet from './GorhomBottomSheet';

const { fontScale, width, height } = Dimensions.get('screen');

const BottomSheetProductReview = ({
  refReviewSheet,
  openReviewForm,
  refReviewFormSheet,
  selectedOrderProductId,
  height: sheetHeight,
  selectedOrderProduct,
  selectedOrder,
  onReviewSubmitted,
}) => {
  const [selectedReason, setSelectedReason] = useState(false);
  const [confirmed, setConfirmed] = useState(false);
  const [bottomSheetHeight, setBottomSheetHeight] = useState(height * 0.5);
  const { fetch_cancellation_enums_loader } = useCancellationEnums();
  const [isCancelling, setIsCancelling] = useState(false);
  const [checkOutLoader, setCheckOutLoader] = useState(null);
  // const { cancelOrder } = useOrders({ order: false });
  const { dispatch, getState } = useReduxStore();
  const { fetch_user_detail } = getState('auth');

  const handlePress = () => {
    updateHeight(height * 0.25);
  };

  const updateHeight = newHeight => {
    if (refReviewSheet?.current) {
      refReviewSheet.current.close();
      setConfirmed(true);
      setTimeout(() => {
        setBottomSheetHeight(newHeight);
        refReviewSheet.current.open();
      }, 300);
    }
  };

  const handleClose = () => {
    refReviewSheet.current.close();
    setTimeout(() => {
      setConfirmed(false);
      setBottomSheetHeight(height * 0.7);
      setSelectedReason(false);
    }, 50);
  };

  const closeSheet = () => {
    if (refReviewSheet?.current) {
      refReviewSheet.current.close();
    } else {
      console.log('Error: refReviewSheet is undefined or not assigned.');
    }
  };

  const openReviewFormandClose = id => {

    closeSheet();
    openReviewForm(id);
  };
  return (
    <View style={{ zIndex: 1 }}>
      <GorhomBottomSheet
        ref={refReviewSheet}
        closeOnDragDown={true}
        closeOnPressMask={true}
        height={sheetHeight || bottomSheetHeight}
        customStyles={{
          container: {
            borderTopRightRadius: width * 0.06,
            borderTopLeftRadius: width * 0.06,
            paddingVertical: 10,
          },
          indicator: { backgroundColor: 'black', width: width * 0.1 },
        }}>
        <View>
          <FlatList
            data={selectedOrderProduct}
            keyExtractor={(product, index) => index.toString()}
            renderItem={({ item: product, index }) => {
              const _handleBuyNow = async () => {
                //   const userLogin = AuthNavigating()
                //   if (userLogin) {
                //     const item = {
                //       shop: selectedOrder?.shop_detail,
                //       products: [
                //         {
                //           product_variant: {
                //             product: product?.product,
                //             variant: product?.variant,
                //           },
                //           quantity: product?.order_item_quantity
                //         }
                //       ]
                //     }

                //     setCheckOutLoader(product?.order_item_id)
                //     await dispatch(_checkout(item, fetch_user_detail?.id, ""))
                //     closeSheet();
                //     setCheckOutLoader(null)
                //   }
                // }
                closeSheet();
                navigate('ProductDetail', {
                  product_id: product?.product?.product_id,
                  shop_id: product?.product?.product_shop_id,
                  default_images: defaultShopImages(product?.product),
                  height,
                });
              };


              return (
                <>
                  <TouchableOpacity
                    onPress={closeSheet}
                    style={styles.closeIcon}>
                    <Icon
                      icon_type="AntDesign"
                      name="closecircleo"
                      color="black"
                      size={fontScale * 20}
                    />
                  </TouchableOpacity>
                  <View
                    style={[
                      styles.mainContainer,
                      { marginBottom: height * 0.02 },
                    ]}>
                    <View
                      style={{
                        width: '20%',
                        aspectRatio: 1,
                        borderWidth: 1,
                        borderRadius: 5,
                        borderColor: '#f7f7f7',

                      }}>
                      <CustomImage
                        style={{ width: '100%', height: '100%', borderRadius: 5 }}
                        source={{ uri: product.product.product_image_url }}
                      />
                    </View>
                    <View
                      style={{
                        marginLeft: '3%',
                        justifyContent: 'flex-start',
                        width: width * 0.7,
                      }}>
                      <CustomText
                        fontSize={fontScale * 13}
                        fontFamily={font.bold}
                        text={`${product.product.product_name}`}
                        marginTop={
                          product.variant?.selected_options.length > 0 ? 5 : 0
                        }
                        numberOfLines={1}
                        ellipsizeMode="tail"
                      />
                      {/* {product.variant?.selected_options.length > 0 && product.variant?.selected_options
                      ?.slice(1)
                      .map((data, index) => (
                        <View
                          style={{
                            backgroundColor: '#E5EBFC',
                            marginTop: 5,
                            borderRadius: 10,
                            paddingHorizontal: 10,
                            paddingVertical: 5,
                            flexDirection: 'row',
                            flexWrap: 'wrap',
                            alignSelf: 'flex-start',
                            marginRight: 5,
                          }}>
                          <CustomText
                            key={index}
                            fontSize={fontScale * 8}
                            fontFamily={font.bold}
                            text={`${data.name}`}
                          />
                        </View>
                      ))} */}
                      <View
                        style={{
                          flex: 1, // Ensure the parent container takes up available space
                          flexDirection: 'row',
                          justifyContent: 'space-between',
                          alignItems: 'center', // Align the content to the bottom
                          marginTop: 10,
                        }}>
                        <CustomText
                          fontSize={fontScale * 12}
                          fontFamily={font.bold}
                          style={styles.PriceText}
                          text={`${product?.product?.product_currency || currency
                            } ${formatPrice(product.variant.variant_price)}`}
                        />
                        <View style={{ flexDirection: 'row', gap: 10 }}>
                          <CustomButton
                            text={
                              product.review_completed ? 'Completed' : 'Review'
                            }
                            borderRadius={2}
                            onPress={() =>
                              !product.review_completed &&
                              openReviewFormandClose(product.order_item_id)
                            }
                            buttonStyle={{ marginRight: 1 }} // Add spacing between buttons
                            textStyle={{
                              fontSize: fontScale * 10,
                              color: '#000000',
                            }}
                            disabledOpacity={1}
                            paddingHorizontal={15}
                            backgroundColor={'#E4E4E4'}
                            forceHeight={height * 0.04}
                          />
                          <CustomButton
                            text={'Buy again'}
                            borderRadius={1}
                            buttonStyle={{ marginRight: height * 0.01 }} // Add spacing between buttons
                            textStyle={{
                              fontSize: fontScale * 10,
                              color: '#FFFFFF',
                            }}
                            disabledOpacity={1}
                            paddingHorizontal={15}
                            backgroundColor={'#000000'}
                            // loader={checkOutLoader == product?.order_item_id}
                            onPress={_handleBuyNow}
                            loaderSize={moderateScale(10)}
                            forceHeight={height * 0.04}
                          />
                        </View>
                      </View>
                    </View>
                  </View>
                </>
              );
            }}
          />
          {/* <TouchableOpacity onPress={() => closeSheet()} style={styles.close}>
            <Icon icon_type={"FontAwesome"} name={"close"} color={"black"} />
           
          </TouchableOpacity> */}
        </View>
      </GorhomBottomSheet>
      <BottomSheetProductForm
        selectedOrderProduct={selectedOrderProduct}
        refReviewFormSheet={refReviewFormSheet}
        selectedOrderProductId={selectedOrderProductId}
      />
    </View>
  );
};

export default BottomSheetProductReview;

const styles = StyleSheet.create({
  mainContainer: {
    display: 'flex',
    flexDirection: 'row',
    width: '100%',

    marginTop: height * 0.01,
    // padding:height*0.009,
  },
  titleContainer: {
    width: '80%',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: WH.height(2),
  },
  titleText: {
    fontFamily: font.bold,
    fontSize: moderateScale(25),
    color: 'black',
  },
  PriceText: {
    color: '#375DFB',
  },
  subtitleContainer: {
    width: '80%',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: verticalScale(10),
  },
  buttonContainer: {
    flexDirection: 'row',
    marginHorizontal: margin.horizontal,
    marginTop: WH.height(4),
    paddingHorizontal: WH.width(1),
    borderRadius: 15,
    backgroundColor: colors.light_theme.backgroundColor,
    borderWidth: 2,
    borderColor: '#f1f1f1',
    position: 'relative',
    marginBottom: verticalScale(20),
  },
  slider: {
    position: 'absolute',
    width: '50%',
    height: '100%',
    backgroundColor: 'white',
    borderRadius: 15,
  },
  button: {
    flex: 1,
    marginVertical: WH.height(0.3),
    paddingVertical: WH.height(1),
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 10,
  },
  buttonText: {
    fontFamily: font.medium,
  },
  close: {
    position: 'absolute',
    top: 10,
    right: margin.horizontal,
  },
  closeIcon: {
    alignItems: 'flex-end',
  },
});
