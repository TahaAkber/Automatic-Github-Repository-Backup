import { colors, font } from '@constant/contstant';
import Icon from '@materialComponent/icon/icon';
import React, { useRef, useState } from 'react';
import {
  Alert,
  Dimensions,
  FlatList,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import { moderateScale, verticalScale } from 'react-native-size-matters';
import { margin, WH } from '../../constant/contstant';
import { _sendUserReview } from '../../redux/actions/reviews/reviews';
import useReduxStore from '../../utils/hooks/useReduxStore';
import CustomButton from '../customButton/customButton';
import CustomText from '../customText/customText';
import CustomImage from '../image/image';
import RatingStars from '../ratingStars/ratingStars';
import BottomSheetForLibrary from './cameraSheet';
import {
  _getInternalOrder,
  updateOrderItemReviewStatus,
} from '../../redux/actions/orders/orders';
import GorhomBottomSheet from './GorhomBottomSheet';

const { fontScale, width, height } = Dimensions.get('screen');

const BottomSheetProductForm = ({
  refReviewFormSheet,
  height: sheetHeight,
  selectedOrderProductId,
}) => {
  const [rating, setRating] = useState(0);
  const refRBSheet = useRef();
  const [images, setImages] = useState([]);
  const [comment, setComment] = useState('');

  const [confirmed, setConfirmed] = useState(false);
  const [bottomSheetHeight, setBottomSheetHeight] = useState(height * 0.5);

  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmitReview = async () => {
    if (!comment.trim() || rating === 0) {
      return Alert.alert('Error', 'Please give a rating and write a comment.');
    }

    setIsSubmitting(true);
    const res = await dispatch(
      _sendUserReview({
        comment,
        rating,
        local_images: images,
        order_item_id: selectedOrderProductId,
      }),
    );

    setIsSubmitting(false);
   
    if (res === 1) {
      setComment('');
      setRating(0);
      setImages([]);
      handleClose();
      await dispatch(_getInternalOrder({ page: 1, tab: 0 }));
    }
  };
  const { dispatch } = useReduxStore();

  const handleClose = () => {
    refReviewFormSheet.current.close();
    setTimeout(() => {
      setConfirmed(false);
    }, 50);
  };

  return (
    <View style={{ zIndex: 1 }}>
      <GorhomBottomSheet
        ref={refReviewFormSheet}
        closeOnDragDown={true}
        closeOnPressMask={true}
        height={sheetHeight || height * 0.7}
        customStyles={{
          container: {
            borderTopRightRadius: width * 0.06,
            borderTopLeftRadius: width * 0.06,
            paddingHorizontal: width * 0.025,
          },
          indicator: { backgroundColor: 'black', width: width * 0.1 },
        }}>
        <View style={{ display: 'flex', alignItems: 'center', paddingTop: 20 }}>
          <CustomText
            fontSize={fontScale * 20}
            fontFamily={font.bold}
            text={`Give a Review`}
          />
          <View style={{ marginTop: WH.height(2) }}>
            <RatingStars setRating={setRating} rating={rating} size={40} />
          </View>
          <View style={{ marginTop: WH.height(2), width: '90%' }}>
            <CustomText
              fontSize={fontScale * 15}
              fontFamily={font.bold}
              text={`Detail Review`}
              color={"#9CA4AB"}
            />
            <TextInput
              style={{
                height: height * 0.2,
                borderColor: '#ccc',
                borderWidth: 1,
                borderRadius: 15,
                padding: width * 0.04,
                marginTop: 10,
                textAlignVertical: 'top',
                fontSize: fontScale * 14,
                fontFamily: font.medium,
                color:"black"
              }}
              multiline={true}
              onChangeText={text => setComment(text)}
              value={comment}
              placeholder="Write your review here..."
              placeholderTextColor="#aaa"
            />
          </View>
          <View style={[{ marginTop: height * 0.02, width: '90%' }]}>
            <FlatList
              data={
                images.length < 5 ? [{ isUploader: true }, ...images] : images
              } // Remove uploader if 5 images are added
              horizontal={true} // Enable horizontal scrolling
              keyExtractor={(item, index) => index.toString()}
              renderItem={({ item, index }) => (
                <View
                  style={{
                    width: width * 0.2,
                    aspectRatio: 1,
                    marginRight: 10,
                    borderRadius: 10,
                    overflow: 'hidden',
                    zIndex: 1,
                    borderWidth: 1,
                    borderColor: '#E9EBED',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}>
                  {item.isUploader ? (
                    <TouchableOpacity
                      activeOpacity={1}
                      onPress={() => refRBSheet?.current?.open()}
                      style={{
                        height: '100%',
                        width: '100%',
                        alignItems: 'center',
                        justifyContent: 'center',
                      }}>
                      {images.length === 0 ? ( // Show camera icon if no images are added
                        <>
                          <Icon
                            icon_type="Entypo"
                            name={'camera'}
                            color={'#5757C9'}
                            size={fontScale * 17} // Reduced icon size
                          />
                          <CustomText
                            fontSize={fontScale * 10} // Reduced text size
                            fontFamily={font.medium}
                            marginTop={height * 0.008}
                            text={`Add Photo`}
                          />
                        </>
                      ) : (
                        <Icon
                          icon_type="Entypo"
                          name={'plus'} // Show "+" icon if at least one image is added
                          color={'#5757C9'}
                          size={fontScale * 20} // Slightly larger "+" icon
                        />
                      )}
                    </TouchableOpacity>
                  ) : (
                    <CustomImage
                      style={{
                        height: '100%',
                        width: '100%',
                        borderRadius: 10,
                      }}
                      source={{ uri: item.uri }}
                    />
                  )}
                </View>
              )}
            />
          </View>
        </View>
        {/* Add Button at the Bottom */}
        <View
          style={{ width: '90%', alignSelf: 'center', marginTop: WH.height(3), marginBottom: height * 0.03 }}>
          <CustomButton
            text="Submit Review"
            loader={isSubmitting}
            // disabled={isSubmitting}
            onPress={handleSubmitReview}
            buttonStyle={{
              backgroundColor: '#5757C9',
              paddingVertical: WH.height(1.5),
              borderRadius: 10,
            }}
            textStyle={{
              fontSize: fontScale * 16,
              color: '#FFFFFF',
              textAlign: 'center',
            }}
          />
        </View>
      </GorhomBottomSheet>
      <BottomSheetForLibrary
        multiple={true}
        images={images}
        setImages={setImages}
        refRBSheet={refRBSheet}
       
      />
    </View>
  );
};

export default BottomSheetProductForm;

const styles = StyleSheet.create({
  mainContainer: {
    display: 'flex',
    flexDirection: 'row',
    width: '100%',
    marginTop: 10,
  },
  titleContainer: {
    width: '80%',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: WH.height(2),
  },
  titleText: {
    fontFamily: font.bold,
    fontSize: moderateScale(25),
    color: 'black',
  },
  PriceText: {
    color: '#375DFB',
  },
  subtitleContainer: {
    width: '80%',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: verticalScale(10),
  },
  buttonContainer: {
    flexDirection: 'row',
    marginHorizontal: margin.horizontal,
    marginTop: WH.height(4),
    paddingHorizontal: WH.width(1),
    borderRadius: 15,
    backgroundColor: colors.light_theme.backgroundColor,
    borderWidth: 2,
    borderColor: '#f1f1f1',
    position: 'relative',
    marginBottom: verticalScale(20),
  },
  slider: {
    position: 'absolute',
    width: '50%',
    height: '100%',
    backgroundColor: 'white',
    borderRadius: 15,
  },
  button: {
    flex: 1,
    marginVertical: WH.height(0.3),
    paddingVertical: WH.height(1),
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 10,
  },
  buttonText: {
    fontFamily: font.medium,
  },
  uploadMedia: {
    borderWidth: 1,
    borderColor: '#E9EBED',
    borderRadius: 10,
    padding: 10,
    alignItems: 'center',
    justifyContent: 'center',
    alignSelf: 'center',
    height: WH.height(14),
  },
});
