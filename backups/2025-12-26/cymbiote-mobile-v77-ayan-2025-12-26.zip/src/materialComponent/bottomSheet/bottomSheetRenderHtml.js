import React from 'react';
import {
  View,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  StatusBar,
  Dimensions,
} from 'react-native';
import Icon from '@materialComponent/icon/icon';
import {font} from '@constant/contstant';
import {CommonActions, useNavigation} from '@react-navigation/native';
import HTMLView from 'react-native-render-html';
import CustomText from '../customText/customText';
import {margin} from '../../constant/contstant';
import WebView from 'react-native-webview';
import GorhomBottomSheet from './GorhomBottomSheet';

const {fontScale, width, height} = Dimensions.get('screen');

const BottomSheetRenderHtml = ({
  onPress,
  refRBSheet,
  height: sheetHeight,
  heading,
  desc,
  buttonText,
  loader,
  htmlContent,
}) => {
  const navigation = useNavigation();



  const handlePress = async () => {
    onPress && (await onPress());
    if (!buttonText) {
      navigation.dispatch(
        CommonActions.reset({
          index: 1,
          routes: [{name: 'Home'}, {name: 'Profile'}],
        }),
      );
    }
    closeSheet();
  };

  const closeSheet = () => {
    if (refRBSheet?.current) {
      refRBSheet.current.close();
    } else {
      console.log('Error: refRBSheet is undefined or not assigned.');
    }
  };

  return (
    <View style={{zIndex: 1}}>
      <GorhomBottomSheet
        title={'Description'}
        ref={refRBSheet}
        closeOnDragDown={true}
        closeOnPressMask={true}
        height={sheetHeight || height * 0.45}>
        <StatusBar animated barStyle="light-content" translucent={false} />

        <View style={styles.content}>
          <ScrollView
            showsVerticalScrollIndicator={false}
            contentContainerStyle={styles.scrollContent}>
            <View
              style={
                {
                  // justifyContent: 'center',
                  // alignItems: 'center',
                  // width: width * 0.5,
                  // marginHorizontal: margin.horizontal,
                }
              }>
              <HTMLView
                source={{html: htmlContent}}
                tagsStyles={{
                  p: {margin: 0, padding: 0}, // Remove margin and padding from <p> tags
                  h1: {margin: 0, padding: 0}, // Remove margin and padding from <h1> tags
                  h2: {margin: 0, padding: 0}, // Remove margin and padding from <h2> tags
                  '*': {margin: 0, padding: 0}, // Apply to all tags to remove margin/padding globally
                }}
              />
              {/* <WebView
                source={{
                  html: htmlContent,
                }}
                style={{height}}
              /> */}
            </View>
          </ScrollView>
        </View>
      </GorhomBottomSheet>
    </View>
  );
};

export default BottomSheetRenderHtml;

const styles = StyleSheet.create({
  content: {
    flex: 1,
    // alignItems: 'center',
    zIndex: 1,
  },
  closeIcon: {
    marginTop: height * 0.015,
    // marginHorizontal: margin.horizontal,
    // width: '20%',
    // alignItems: 'flex-end',
    // padding: 5,
    // position: 'absolute',
    zIndex: 2,
    flexDirection: 'row',
    // width: width - margin.horizontal,
    justifyContent: 'space-between',
    paddingVertical: height * 0.01,
  },
  scrollContent: {
    // alignItems: 'center',
    // justifyContent: 'center',
    paddingTop: height * 0.01,
  },
  point: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: height * 0.01,
  },
  buttonContainer: {
    width: width * 0.9,
    marginTop: height * 0.03,
  },
  buttonStyle: {
    height: height * 0.05,
    borderRadius: 5,
  },
  buttonText: {
    fontSize: fontScale * 15,
    fontFamily: font.medium,
  },
});
