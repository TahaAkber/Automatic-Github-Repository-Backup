import {accessCamera, accessGallery} from '@utils/imagePicker/imagePicker';
import {moderateScale, verticalScale} from 'react-native-size-matters';
import CustomText from '@materialComponent/customText/customText';
import {colors, font, globalStyle} from '@constant/contstant';
import CommonModal from '@component/modal/modal';
import Icon from '@materialComponent/icon/icon';
import {WH} from '@constant/contstant';
import React, {useState} from 'react';
import {
  View,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  Text,
} from 'react-native';
import GorhomBottomSheet from './GorhomBottomSheet';
import {BottomSheetScrollView} from '@gorhom/bottom-sheet';

const BottomSheetForLibrary = ({refRBSheet, setImages, images, multiple}) => {
  const [modaDetail, setModalDetail] = useState({});

  const _closeSheet = () => {
    refRBSheet.current.close();
  };

  const _openGallery = async () => {
    const response = await accessGallery(multiple || false);
    _closeSheet();
    if (multiple) {
      setImages([...images, ...response]);
    } else {
      setImages(response);
    }
  };

  const _openCamera = async () => {
    const response = await accessCamera(multiple || false);
    console.log('response', response);
    _closeSheet();
    if (multiple && response) {
      setImages([...images, response]);
    } else {
      if (response) {
        setImages(response);
      }
    }
  };

  const data = [
    {
      iconName: 'folder-images',
      value: 'Images from gallery',
      onPress: _openGallery,
    },
    {
      iconName: 'camera',
      value: 'Capture image',
      onPress: _openCamera,
    },
  ];

  return (
    <View style={{zIndex: 1}}>
      <GorhomBottomSheet title={'Image Capture'} ref={refRBSheet}>
        <View style={{flex: 1}}>
          <View style={styles.formContainer}>
            <View style={{width: '100%'}}>
              <CustomText
                fontSize={moderateScale(12)}
                // marginTop={verticalScale(10)}
                fontFamily={font.regular}
                text={
                  'You can either click a picture or pick one from \n the library'
                }
              />
            </View>
          </View>

          <BottomSheetScrollView showsVerticalScrollIndicator={false}>
            {data.map((item, index) => (
              <TouchableOpacity
                key={index}
                style={styles.view}
                onPress={() => item.onPress()}>
                <View style={styles.iconContainer}>
                  <Icon
                    icon_type={'Entypo'}
                    name={item.iconName}
                    size={item.size || moderateScale(20)}
                    color={item.color || 'black'}
                  />
                </View>
                <Text style={[styles.text, {color: item.color || 'black'}]}>
                  {item.value}
                </Text>
              </TouchableOpacity>
            ))}
          </BottomSheetScrollView>
        </View>
      </GorhomBottomSheet>
      <CommonModal
        onPressOk={() => modaDetail?.onPress()}
        onPressCancel={() => setModalDetail({})}
        buttonTextCancel={'Cancel'}
        twoButton
        buttonText={'Go Proceed'}
        visible={modaDetail?.title ? true : false}
        modalText={modaDetail?.title}
        subtitle={modaDetail?.text}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  view: {
    borderRadius: moderateScale(10),
    height: WH.height(6),
    ...globalStyle.row,
  },
  title: {
    marginBottom: verticalScale(15),
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: '2%',
  },
  text: {
    marginLeft: moderateScale(12),
    fontSize: moderateScale(14),
    color: colors.light_theme.text,
    fontFamily: font.medium,
  },
  formContainer: {
    marginBottom: verticalScale(10),
    ...globalStyle.space_between,
    marginTop: WH.height(2),
  },
  brandTabContainer: {
    marginTop: WH.height(5),
  },
  followContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  circle: {
    width: moderateScale(25),
    backgroundColor: colors.light_theme.borderColor,
    justifyContent: 'center',
    alignItems: 'center',
    aspectRatio: 1 / 1,
    borderRadius: 180,
  },
  iconContainer: {
    height: WH.height(4),
    justifyContent: 'center',
    alignItems: 'center',
    aspectRatio: 1 / 1,
    borderRadius: 180,
  },
});

export default BottomSheetForLibrary;
