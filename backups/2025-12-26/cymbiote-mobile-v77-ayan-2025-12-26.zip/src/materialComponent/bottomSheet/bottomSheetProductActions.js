import {moderateScale, verticalScale} from 'react-native-size-matters';
import CustomText from '@materialComponent/customText/customText';
import {globalStyle, margin, WH} from '@constant/contstant';
import GorhomBottomSheet from './GorhomBottomSheet';
import Icon from '@materialComponent/icon/icon';
import {colors} from '@constant/contstant';
import {font} from '@constant/contstant';
import React, {useState} from 'react';
import Next from '@assets/images/next.svg';
import {
  View,
  TouchableOpacity,
  StyleSheet,
  Text,
  StatusBar,
} from 'react-native';
import {BottomSheetFlatList} from '@gorhom/bottom-sheet';

const bottomSheetProductActions = ({refRBSheet, title, data, height, setValue}) => {
  const [selectRadio, setSelectRadio] = useState({});
  const _handleSubmit = (press, id) => {
    if (setValue) {
      refRBSheet.current.close();
      setValue(id);
    } else {
      refRBSheet.current.close();
      press();
    }
  };

  return (
    <View style={{zIndex: 1}}>
      <GorhomBottomSheet title={title} ref={refRBSheet}>
        <StatusBar animated barStyle={'light-content'} translucent={false} />
        <BottomSheetFlatList
          data={data}
          keyExtractor={item => item.id.toString()}
          renderItem={({item, index}) =>
            renderItem({item, index}, _handleSubmit)
          }
          contentContainerStyle={{marginTop : height * 0.09}}
          showsVerticalScrollIndicator={false}
        />
      </GorhomBottomSheet>
    </View>
  );
};
export default bottomSheetProductActions;

const styles = StyleSheet.create({
  view: {
    borderRadius: moderateScale(10),
    height: WH.height(6),
    ...globalStyle.space_between,
    // marginTop: WH.height(2),
    // borderBottomWidth: 1,
    borderColor: colors.light_theme.gray,
  },
  bar: {
    marginTop: verticalScale(20),
    height: verticalScale(5),
    backgroundColor: colors.light_theme.darkBorderColor,
    alignSelf: 'center',
    borderRadius: 180,
    width: '10%',
  },
  title: {
    marginBottom: verticalScale(15),
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: '2%',
  },
  text: {
    marginLeft: moderateScale(12),
    fontSize: moderateScale(16),
    color: colors.light_theme.text,
    fontFamily: font.medium,
  },
  buttonView: {
    marginBottom: verticalScale(20),
    marginHorizontal: margin.horizontal,
  },
});

const renderItem = ({item, index}, _handleSubmit) => {
  return (
    <TouchableOpacity
      onPress={() =>
        item.onPress
          ? _handleSubmit(item.onPress, item.value)
          : _handleSubmit('', item.id)
      }
      style={styles.view}
      key={item.id} // FlatList doesn’t need this, but no harm
    >
      <View style={globalStyle.row}>
        {item.iconType && (
          <View
            style={{
              width: WH.width('8'),
              justifyContent: 'center',
              alignItems: 'center',
            }}>
            <Icon
              size={item.size || moderateScale(20)}
              color={item.color || 'black'}
              icon_type={item.iconType}
              name={item.iconName}
            />
          </View>
        )}

        {item?.image && (
          <View
            style={{
              marginLeft: WH.width(1),
              marginRight: WH.width(1.5),
              justifyContent: 'center',
              alignItems: 'center',
            }}>
            <item.image width={WH.width(9)} height={WH.width(9)} />
          </View>
        )}

        <Text
          style={[styles.text, {color: item.color || colors.light_theme.text}]}>
          {item.value}
        </Text>
      </View>

      {item.next && <Next width={WH.width(9)} height={WH.width(9)} />}
    </TouchableOpacity>
  );
};
