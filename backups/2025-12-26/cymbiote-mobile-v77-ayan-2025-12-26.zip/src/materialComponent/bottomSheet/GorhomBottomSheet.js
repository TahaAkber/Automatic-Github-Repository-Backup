import React, {
  forwardRef,
  useImperativeHandle,
  useRef,
  useMemo,
  useCallback,
} from 'react';
import {Dimensions, View} from 'react-native';
import {
  BottomSheetModal,
  BottomSheetBackdrop,
  BottomSheetView,
} from '@gorhom/bottom-sheet';
import {moderateScale} from 'react-native-size-matters';
import {font, margin} from '../../constant/contstant';
import CustomText from '../customText/customText';

const {height: SCREEN_HEIGHT} = Dimensions.get('window');
const MAX_SHEET_HEIGHT = SCREEN_HEIGHT * 0.9;

const GorhomBottomSheet = forwardRef(
  (
    {
      height,
      children,
      closeOnDragDown = true,
      closeOnPressMask = true,
      customStyles = {},
      onClose,
      enableDynamicSizing = true,
      title = '',
    },
    ref,
  ) => {
    const bottomSheetModalRef = useRef(null);
    const shouldUseDynamicSizing = enableDynamicSizing && !height;

    const snapPoints = useMemo(() => {
      if (shouldUseDynamicSizing) return ['30%', '40%', '60%'];
      if (height) {
        if (typeof height === 'number') {
          return [Math.min(height, MAX_SHEET_HEIGHT)];
        }
        return [height];
      }
      return [MAX_SHEET_HEIGHT];
    }, [height, shouldUseDynamicSizing]);

    useImperativeHandle(ref, () => ({
      open: () => bottomSheetModalRef.current?.present(),
      close: () => bottomSheetModalRef.current?.dismiss(),
      snapTo: position =>
        bottomSheetModalRef.current?.snapToPosition?.(position),
    }));

    const renderBackdrop = useCallback(
      props =>
        closeOnPressMask ? (
          <BottomSheetBackdrop
            {...props}
            disappearsOnIndex={-1}
            appearsOnIndex={0}
            opacity={0.5}
            pressBehavior="close"
          />
        ) : null,
      [closeOnPressMask],
    );

    return (
      <BottomSheetModal
        ref={bottomSheetModalRef}
        index={0}
        closeOnDragDown={true}
        closeOnPressMask={true}
        snapPoints={snapPoints || ['25%', '50%', '75%']}
        enablePanDownToClose={closeOnDragDown}
        backdropComponent={renderBackdrop}
        onDismiss={onClose}
        backgroundStyle={{
          backgroundColor: customStyles.container?.backgroundColor || 'white',
          borderTopLeftRadius: moderateScale(25),
          borderTopRightRadius: moderateScale(25),
        }}
        handleIndicatorStyle={{
          backgroundColor: customStyles.indicator?.backgroundColor || '#ccc',
          width: customStyles.indicator?.width || 50,
          ...customStyles.indicator,
        }}
        enableDynamicSizing={shouldUseDynamicSizing}
        maxDynamicContentSize={MAX_SHEET_HEIGHT}>
        <BottomSheetView
          style={[
            {
              maxHeight: MAX_SHEET_HEIGHT,
              flex: 1,
              paddingHorizontal: margin.horizontal,
            },
            customStyles.wrapper,
          ]}>
          {title ? (
            <CustomText
              fontFamily={font.bold}
              fontSize={moderateScale(17)}
              text={title}
              marginTop={SCREEN_HEIGHT * 0.02}
            />
          ) : (
            <></>
          )}

          {children}
        </BottomSheetView>
      </BottomSheetModal>
    );
  },
);

export default GorhomBottomSheet;
