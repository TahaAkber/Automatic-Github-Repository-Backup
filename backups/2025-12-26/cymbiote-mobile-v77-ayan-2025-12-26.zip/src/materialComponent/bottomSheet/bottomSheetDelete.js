import React from 'react';
import {
  View,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  StatusBar,
  Dimensions,
} from 'react-native';
import GorhomBottomSheet from './GorhomBottomSheet';
import {font} from '@constant/contstant';
import CustomText from '../customText/customText';
import CustomButton from '../customButton/customButton';
import {CommonActions, useNavigation} from '@react-navigation/native';

const {fontScale, width, height} = Dimensions.get('screen');

const BottomSheetDelete = ({
  onPress,
  refRBSheet,
  height: sheetHeight,
  heading,
  desc,
  buttonText,
  loader,
}) => {
  const navigation = useNavigation();

  const handlePress = async () => {
    onPress && (await onPress());
    if (!buttonText) {
      navigation.dispatch(
        CommonActions.reset({
          index: 1,
          routes: [{name: 'Home'}, {name: 'Profile'}],
        }),
      );
    }
    closeSheet();
  };

  const closeSheet = () => {
    if (refRBSheet?.current) {
      refRBSheet.current.close();
    } else {
    }
  };

  return (
    <View style={{zIndex: 1}}>
      <GorhomBottomSheet ref={refRBSheet}>
        <View style={styles.content}>
          <ScrollView
            showsVerticalScrollIndicator={false}
            contentContainerStyle={styles.scrollContent}>
            <View
              style={{
                justifyContent: 'center',
                alignItems: 'center',
                width: width * 0.7,
              }}>
              <CustomText
                fontFamily={font.bold}
                fontSize={fontScale * 20}
                marginTop={height * 0.02}
                text={heading || 'Are you sure you want to delete your account'}
                center
              />
            </View>
            <View
              style={{
                justifyContent: 'center',
                alignItems: 'center',
                width: width * 0.5,
              }}>
              <CustomText
                fontFamily={font.regular}
                fontSize={fontScale * 16}
                marginTop={height * 0.02}
                text={desc || 'Once deleted, your data will be lost.'}
                center
              />
            </View>

            <View style={styles.buttonContainer}>
              <CustomButton
                buttonStyle={styles.buttonStyle}
                textStyle={styles.buttonText}
                text={buttonText || 'Delete Account'}
                onPress={handlePress}
                loader={loader}
              />
            </View>
          </ScrollView>
        </View>
      </GorhomBottomSheet>
    </View>
  );
};

export default BottomSheetDelete;

const styles = StyleSheet.create({
  content: {
    flex: 1,
    alignItems: 'center',
    zIndex: 1,
  },
  closeIcon: {
    top: height * 0.015,
    right: width * 0.03,
    width: '20%',
    alignItems: 'flex-end',
    padding: 5,
    position: 'absolute',
    zIndex: 2,
  },
  scrollContent: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  point: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: height * 0.01,
  },
  buttonContainer: {
    width: width * 0.9,
    marginTop: height * 0.03,
  },
  buttonStyle: {
    height: height * 0.05,
    borderRadius: 5,
  },
  buttonText: {
    fontSize: fontScale * 15,
    fontFamily: font.medium,
  },
});
