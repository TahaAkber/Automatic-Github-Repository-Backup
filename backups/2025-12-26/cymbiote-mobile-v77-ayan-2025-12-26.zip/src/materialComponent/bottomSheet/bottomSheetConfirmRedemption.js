import React, {useEffect, useState} from 'react';
import {
  View,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  StatusBar,
  Dimensions,
  Text,
  TextInput,
  Vibration,
} from 'react-native';
import Icon from '@materialComponent/icon/icon';
import RewardSvg from '@assets/images/reward.svg';
import PointSvg from '@assets/images/point.svg';
import {colors, font} from '@constant/contstant';
import CustomText from '../customText/customText';
import CustomImage from '../image/image';
import CustomButton from '../customButton/customButton';
import {CommonActions, useNavigation} from '@react-navigation/native';
import CustomSlider from '../../component/redeemSlider/redeemSlider';
import useReduxStore from '../../utils/hooks/useReduxStore';
import {toFixedMethod2} from '../../utils/helper/helper';
import {_createVoucher} from '../../redux/actions/reward/reward';
import {globalStyle} from '../../constant/contstant';
import {triggerHaptic} from '../../utils/haptic/haptic';
import GorhomBottomSheet from './GorhomBottomSheet';

const {fontScale, width, height} = Dimensions.get('screen');

const BottomSheetConfirmRedemption = ({
  onPress,
  refRBSheet,
  height: sheetHeight,
  data,
  setVoucher,
  voucher,
  getAPI,
  embedded = false,
  onCloseRequest,
  onHeightChange,
  initialHeight,
  orderAmount,
}) => {
  const [index, setIndex] = useState(0);
  const [value, setValue] = useState(0); // Default slider value
  const [bottomSheetHeight, setBottomSheetHeight] = useState(
    initialHeight || height * 0.4,
  );
  const [loader, setLoader] = useState(false);
  const {getState, dispatch} = useReduxStore();
  const {user_point_history} = getState('reward');
  const navigation = useNavigation();

  const minimumValue = 50;
  const confirmPoint = parseFloat(user_point_history?.['0']?.totalPoints) || 0;
  const currentBalance = confirmPoint;
  console.log('Confirmed ===>', orderAmount);

  const {user_point} = getState('reward');
  const [isTransitioning, setIsTransitioning] = useState(false);

  // unified step transition
  const updateHeight = async (nextIndex, nextHeight) => {
    if (isTransitioning) return;
    setIsTransitioning(true);

    if (embedded) {
      setBottomSheetHeight(nextHeight);
      onHeightChange?.(nextHeight);
      setIndex(nextIndex);
      setTimeout(() => setIsTransitioning(false), 150);
      return;
    }

    setBottomSheetHeight(nextHeight);
    onHeightChange?.(nextHeight);
    setIndex(nextIndex);

    if (refRBSheet?.current?.snapTo) {
      refRBSheet.current.snapTo(nextHeight);
    }

    setTimeout(() => setIsTransitioning(false), 200);
  };

  const handlePress = async () => {
    if (isTransitioning) return;

    if (index === 0) {
      triggerHaptic();
      await updateHeight(1, height * 0.4);
      return;
    }

    if (index === 1) {
      triggerHaptic();
      setLoader(true);
      const res = await dispatch(_createVoucher(value, data?.shop_id));
      setLoader(false);

      if (res) {
        (await getAPI) && getAPI();
        setVoucher?.(res);
        await updateHeight(2, height * 0.4);
      }
      return;
    }

    // index >= 2 (ThankYou → close & reset)
  if (embedded) {
    setIndex(0);
    setValue(0);
    onCloseRequest ? onCloseRequest() : null;
  } else if (refRBSheet?.current) {
    refRBSheet.current.close();
    setIndex(0);
    setValue(0);
    triggerHaptic();
  }
};

  const closeSheet = () => {
    if (embedded) {
      onCloseRequest ? onCloseRequest() : null;
      setIndex(0);
      setValue(0);
    } else if (refRBSheet?.current) {
      refRBSheet.current.close();
      setIndex(0);
      setValue(0);
    } else {
      console.log('Error: refRBSheet is undefined or not assigned.');
    }
  };

  const content = (
    <View style={styles.content}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
        key={`step-${index}`}>
        <CustomImage
          style={{width: width * 0.18, aspectRatio: 1, borderRadius: 180}}
          source={{uri: data?.shop_logo_url}}
        />

        {index == 0 ? (
          <RedeemPoint
            minimumValue={minimumValue}
            // totalPoints={user_point?.totalPoints}
            totalPoints={currentBalance}
            handlePress={handlePress}
            setValue={setValue}
            value={value}
          />
        ) : index == 1 ? (
          <RedeemConfirmation
            loader={loader}
            setValue={setValue}
            value={value}
            handlePress={handlePress}
            orderAmount={orderAmount}
          />
        ) : (
          <ThankYou value={value} handlePress={handlePress} />
        )}
      </ScrollView>
    </View>
  );

  if (embedded) {
    return <View style={{flex: 1}}>{content}</View>;
  }

  return (
    <View style={{zIndex: 1}}>
      <GorhomBottomSheet
        onClose={closeSheet}
        ref={refRBSheet}
        height={bottomSheetHeight}>
        <StatusBar animated barStyle="light-content" translucent={false} />
        {content}
      </GorhomBottomSheet>
    </View>
  );
};

export default BottomSheetConfirmRedemption;

const styles = StyleSheet.create({
  content: {
    flex: 1,
    alignItems: 'center',
    zIndex: 1,
  },
  closeIcon: {
    top: height * 0.015,
    right: width * 0.03,
    width: '20%',
    alignItems: 'flex-end',
    padding: 5,
    position: 'absolute',
    zIndex: 2,
  },
  scrollContent: {
    alignItems: 'center',
    justifyContent: 'space-between',
    flex: 1,
  },
  point: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: height * 0.01,
  },
  buttonContainer: {
    width: width * 0.9,
    marginTop: height * 0.02,
  },
  buttonStyle: {
    height: height * 0.05,
    borderRadius: 5,
    marginBottom: height * 0.02,
  },
  buttonText: {
    fontSize: fontScale * 15,
    fontFamily: font.medium,
  },
  input: {
    backgroundColor: '#D3D3D3',
    borderRadius: 10,
    width: '30%',
    paddingHorizontal: width * 0.01,
    fontFamily: font.regular,
    textAlign: 'center',
    color: 'black',
  },
});

const RedeemPoint = ({
  handlePress,
  setValue,
  value,
  totalPoints,
  minimumValue,
}) => {
  const isBelowMinimum = totalPoints < minimumValue;

  console.log('Total Points:', value);

  return (
    <>
      <CustomText
        fontFamily={font.bold}
        fontSize={fontScale * 20}
        text={'Redeem Your Points'}
      />

      <CustomText
        fontFamily={font.bold}
        fontSize={fontScale * 30}
        text={toFixedMethod2(totalPoints - value)}
      />

      {isBelowMinimum ? (
        <CustomText
          text={`You need at least ${minimumValue} points to redeem.`}
          color={'red'}
          fontSize={fontScale * 14}
          fontFamily={font.regular}
        />
      ) : (
        <CustomText
          text={
            value ? `You Have Used ${toFixedMethod2(value)}` : `You Have Points`
          }
          color={'#797979'}
          fontSize={fontScale * 14}
          fontFamily={font.regular}
        />
      )}

      {/* Show slider only if points are valid */}
      {!isBelowMinimum && (
        <View
          style={{width: '80%', marginTop: height * 0.02, alignSelf: 'center'}}>
          <CustomSlider
            totalPoints={totalPoints}
            setValue={setValue}
            value={value}
          />
          {/* <View style={[globalStyle.space_between, {marginTop: height * 0.03}]}>
            <CustomText text={'Enter Custom Points'} />
            <TextInput
              placeholderTextColor={'gray'}
              placeholder="0.00"
              style={styles.input}
              value={value?.toString()}
              onChangeText={text => setValue(text)}
              key={value}
              keyboardType="decimal-pad"
            />
          </View> */}
        </View>
      )}

      <View style={styles.buttonContainer}>
        <CustomButton
          buttonStyle={styles.buttonStyle}
          textStyle={styles.buttonText}
          text={'Next'}
          onPress={handlePress}
          disabled={isBelowMinimum} // ✅ Disable button if not enough points
        />
      </View>
    </>
  );
};

const RedeemConfirmation = ({handlePress, loader, value, orderAmount}) => {
  return (
    <>
      <CustomText
        fontFamily={font.bold}
        fontSize={fontScale * 16}
        text={`You are about to redeem ${toFixedMethod2(value)} points`}
        center
      />
      <View style={{width: '90%'}}>
        <Text
          style={{
            fontFamily: font.regular,
            color: 'black',
            textAlign: 'center',
            fontSize: fontScale * 14,
          }}>
          Once the voucher is generated, this action{' '}
          <Text style={{fontFamily: font.bold}}>cannot be reversed, </Text>and
          the points{' '}
          <Text style={{fontFamily: font.bold}}>
            cannot be used at any other store.
          </Text>
        </Text>
      </View>

      <CustomText
        text={'Are you sure you want to proceed?'}
        color={'black'}
        fontSize={fontScale * 14}
        fontFamily={font.medium}
      />

      <View style={styles.buttonContainer}>
        <CustomButton
          buttonStyle={styles.buttonStyle}
          textStyle={styles.buttonText}
          text={'Redeem Now'}
          onPress={handlePress}
          loader={loader}
          loaderSize={'small'}
        />
      </View>
    </>
  );
};

const ThankYou = ({handlePress, value}) => {
  return (
    <>
      <CustomText
        fontFamily={font.bold}
        fontSize={fontScale * 20}
        text={'Thank You'}
      />
      <View style={{width: '90%'}}>
        <Text
          style={{
            fontFamily: font.regular,
            color: 'black',
            textAlign: 'center',
            fontSize: fontScale * 15,
          }}>
          Your voucher for {toFixedMethod2(value)} points has been created.
        </Text>
      </View>

      <CustomText
        text={'Enjoy your shopping!'}
        color={'black'}
        fontSize={fontScale * 15}
        fontFamily={font.medium}
      />

      <View style={styles.buttonContainer}>
        <CustomButton
          buttonStyle={[styles.buttonStyle, {backgroundColor: 'black'}]}
          textStyle={styles.buttonText}
          text={'Done'}
          onPress={handlePress}
        />
      </View>
    </>
  );
};
