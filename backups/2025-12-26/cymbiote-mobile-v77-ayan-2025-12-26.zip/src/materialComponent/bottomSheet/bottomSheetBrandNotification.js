import React, { useEffect, useRef, useState } from 'react';
import {
  View,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  StatusBar,
  Dimensions,
} from 'react-native';
import Icon from '@materialComponent/icon/icon';
import { colors, font } from '@constant/contstant';
import CustomText from '../customText/customText';
import CustomButton from '../customButton/customButton';
import { CommonActions, useNavigation } from '@react-navigation/native';
import CustomRadioButton from '../radioButton/radioButton';
import useReduxStore from '../../utils/hooks/useReduxStore';
import {
  _createNotificationPreference,
  _storeFollowingUpdateStatus,
} from '../../redux/actions/merchant/merchant';
import BottomSheetPersonalized from './bottomSheetPersonalized';
import { moderateScale } from 'react-native-size-matters';
import GorhomBottomSheet from './GorhomBottomSheet';

const { fontScale, width, height } = Dimensions.get('screen');

const personalizedValues = [
  {
    id: 1,
    title: 'New Arrival Alerts',
    description: 'Get notified about the latest promotions and discounts.',
    toggle: false,
    db_value: 'NEW_ARRIVAL_ALERT',
  },
  {
    id: 2,
    title: 'New Collection added',
    description: 'Receive updates on your order status and delivery.',
    toggle: false,
    db_value: 'NEW_COLLECTION_ADDED',
  },
  {
    id: 3,
    title: 'Special Offers',
    description: 'Be the first to know about special offers and discounts.',
    toggle: false,
    db_value: 'SPECIAL_OFFERS',
  },

  {
    id: 4,
    title: 'Back in stock Reminder',
    description: 'Get notified when your favorite products are back in stock.',
    toggle: false,
    db_value: 'RESTOCK_ALERT',
  },
];
const BottomSheetBrandNotification = ({
  onPress,
  refRBSheet,
  height: sheetHeight,
  item,
}) => {
  const [selectedRules, setSelectedRules] = useState([]);
  const { getState, dispatch } = useReduxStore();

  const { fetch_store_following_list_local, fetch_store_following_list } =
    getState('merchant');

  const { fetch_store_products } = getState('merchant');
  const shopData = fetch_store_products?.data?.shop;
  const notificationPrefs = shopData?.notification;
  const liveStores = fetch_store_following_list?.data?.map(
    el => el?.shop_detail?.shop_id,
  );
  const localStores = fetch_store_following_list_local.map(el => el.shop_id);
  const finalArray = [...liveStores, ...localStores];

  const [savingPrefId, setSavingPrefId] = useState(null);
  const [follow, setFollow] = useState(finalArray.includes(item?.shop_id));
  const [followLoader, setFollowLoader] = useState(false);

  const [personalizedToggles, setPersonalizedToggles] = useState(() => {
    if (!notificationPrefs) {
      return personalizedValues.map(item => ({ ...item, toggle: false }));
    }

    return personalizedValues.map(item => ({
      ...item,
      toggle: notificationPrefs.rules?.includes(item.db_value) || false,
    }));
  });
  const [selectedNotif, setSelectedNotif] = useState(
    shopData?.notification?.preference,
  );
  const [selectedPrefrencesItems, setSelectedPrefrencesItems] = useState([]);

  const _handleFollow = async () => {
    try {
      setFollowLoader(true);
      setFollow(prevFollow => !prevFollow);
      await dispatch(
        _storeFollowingUpdateStatus(
          item?.shop_id,
          !follow,
          item,
          false,
          false,
          true,
        ),
      );
    } catch (error) {
      // Revert state in case of error
      setFollow(prevFollow => !prevFollow);
    } finally {
      setFollowLoader(false);
    }
  };

  const navigation = useNavigation();

  const handlePress = () => {
    _handleFollow();
  };

  const closeSheet = () => {
    if (refRBSheet?.current) {
      refRBSheet.current.close();
    } else {
    }
  };

  const { fetch_user_detail } = getState('auth');
  const userId = fetch_user_detail?.id;
  const merchantId = item?.shop_id;

  const handleSelectPreference = async (id, prefValue) => {
    setSelectedNotif(id);
    setSavingPrefId(id);

    try {
      if (prefValue === 'personalized') {
        setSelectedPrefrencesItems(
          personalizedValues?.map((item, index) => item.db_value),
        );
      } else {
        setSelectedPrefrencesItems([]);
      }

      const rules =
        prefValue === 'personalized'
          ? personalizedValues?.map((item, index) => item.db_value)
          : [];

      const payload = {
        userId,
        merchantId,
        preference: prefValue,
        rules,
      };

      const res = await dispatch(_createNotificationPreference(payload));
    } catch (e) {
    } finally {
      setSavingPrefId(null);
    }
  };
  const refRBPersonalized = useRef();

  const openPersonalizedSheet = () => {
    if (selectedNotif !== null) {
    }
    refRBSheet.current?.close();
    setTimeout(() => {
      refRBPersonalized.current?.open();
    }, 250);
  };

  const handleToggleInPersonalizedSheet = updatedToggles => {
  };

  useEffect(() => {
    setSelectedNotif(shopData?.notification?.preference || '');
    if (shopData?.notification?.preference == 'personalized') {
      setSelectedPrefrencesItems(shopData?.notification?.rules);
    }
  }, [shopData]);

  return (
    <View style={{ zIndex: 1 }}>
      <GorhomBottomSheet title={'Notifications'} ref={refRBSheet} height={sheetHeight}>
        <StatusBar animated barStyle="light-content" translucent={false} />

        <View style={styles.content}>
          <ScrollView
            showsVerticalScrollIndicator={false}
            contentContainerStyle={styles.scrollContent}>
            <View style={{ width: '100%', marginTop: height * 0.01 }}>
              {notifications.map((item, index) => {
                const prefVal = item.db_value;
                const isSelected = item?.db_value == selectedNotif;
                return (
                  <View
                    key={item?.db_value}
                    style={[
                      styles.options,
                      {
                        marginTop: height * 0.02,
                        width: '92%',
                        paddingHorizontal: width * 0.02,
                      },
                    ]}>
                    <View style={styles.radioButton}>
                      <CustomRadioButton
                        selected={isSelected}
                        onPress={() =>
                          handleSelectPreference(item.db_value, prefVal)
                        }
                      />
                    </View>
                    <View style={{ marginLeft: '5%' }}>
                      <CustomText
                        fontSize={moderateScale(15)}
                        fontFamily={font.medium}
                        text={item.title}
                      />
                      <CustomText
                        marginTop={height * 0.005}
                        fontSize={moderateScale(12)}
                        fontFamily={font.regular}
                        text={item.desc}
                      />
                    </View>
                    {item.db_value === 'personalized' &&
                      selectedNotif === 'personalized' && (
                        <TouchableOpacity
                          onPress={openPersonalizedSheet}
                          hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
                          style={{
                            position: 'absolute',
                            right: '-5%',
                            top: '30%',
                            transform: [{ translateY: -(fontScale * 10) }],
                          }}>
                          <Icon
                            name="right"
                            size={fontScale * 18}
                            color="black"
                            icon_type="AntDesign"
                          />
                        </TouchableOpacity>
                      )}
                  </View>
                );
              })}
            </View>
          </ScrollView>
        </View>
      </GorhomBottomSheet>
      <BottomSheetPersonalized
        refRBSheet={refRBPersonalized}
        userId={userId}
        merchantId={merchantId}
        toggles={personalizedValues}
        setToggles={handleToggleInPersonalizedSheet}
        selectedPrefrencesItems={selectedPrefrencesItems}
        setSelectedPrefrencesItems={setSelectedPrefrencesItems}
      />
    </View>
  );
};

export default BottomSheetBrandNotification;

const styles = StyleSheet.create({
  content: {
    flex: 1,
    zIndex: 1,
  },
  closeIcon: {
    top: height * 0.015,
    right: width * 0.03,
    width: '20%',
    alignItems: 'flex-end',
    padding: 5,
    position: 'absolute',
    zIndex: 2,
  },
  scrollContent: {
    // alignItems: 'center',
    justifyContent: 'space-between',
    // marginTop: height * 0.05,
    flex: 1,
  },
  point: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: height * 0.01,
  },
  buttonContainer: {
    marginTop: height * 0.03,
    marginBottom: height * 0.02,
    width: '96%',
    alignSelf: 'center',
  },
  buttonStyle: {
    height: height * 0.05,
    borderRadius: 10,
    backgroundColor: 'black',
    width: '100%',
  },
  buttonText: {
    fontSize: fontScale * 15,
    fontFamily: font.medium,
  },
  options: {
    flexDirection: 'row',
  },
  radioButton: {
    alignItems: 'baseline',
    marginTop: height * 0.001,
  },
});

const notifications = [
  {
    title: 'All Updates',
    desc: 'Get every notification this store sends about its products or collection.',
    db_value: 'all',
  },
  {
    title: 'Personalized',
    desc: 'Get the notification that are most relevent to you.',
    db_value: 'personalized',
  },
  {
    title: 'None',
    desc: 'You won’t get notifications from this store, but may still receive notifications from cercle.',
    db_value: 'none',
  },
];
