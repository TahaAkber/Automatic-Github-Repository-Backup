import {Image, StyleSheet, View, ActivityIndicator} from 'react-native';
import React, {memo, useEffect, useMemo, useState} from 'react';
import {colors} from '@constant/contstant';
import FastImage from 'react-native-fast-image';
import {noImageUrl} from '../../constant/contstant';
import {useRef} from 'react';

const normalizeSource = src => {
  if (!src) return null;

  if (typeof src === 'string') {
    const trimmed = src.trim();
    return trimmed ? {uri: trimmed} : null;
  }

  if (typeof src === 'object' && 'uri' in src) {
    const rawUri = src.uri;
    const trimmed = typeof rawUri === 'string' ? rawUri.trim() : rawUri ?? null;
    return trimmed ? {...src, uri: trimmed} : null;
  }

  return null;
};

const isSameSource = (a, b) => {
  if (a === b) return true;
  if (!a || !b) return false;
  return a.uri === b.uri;
};

const CustomImage = ({source, style, size, resizeMode}) => {
  const normalizedSource = useMemo(() => normalizeSource(source), [source]);
  const fallbackSource = useMemo(
    () => ({uri: noImageUrl, priority: FastImage.priority.low}),
    [],
  );
  const [loading, setLoading] = useState(false);
  const [imageError, setImageError] = useState(false);
  const [resolvedSource, setResolvedSource] = useState(
    normalizedSource || fallbackSource,
  );
  const failedUrisRef = useRef(new Set());

  useEffect(() => {
    setLoading(false);
    if (normalizedSource?.uri && failedUrisRef.current.has(normalizedSource.uri)) {
      setImageError(true);
      setResolvedSource(fallbackSource);
      return;
    }

    setImageError(false);
    setResolvedSource(prev => {
      const next = normalizedSource || fallbackSource;
      return isSameSource(prev, next) ? prev : next;
    });
  }, [source, normalizedSource, fallbackSource]);

  const handleImageLoadStart = () => {
    // Skip spinner when we are already on fallback or no source is provided
    if (!imageError && normalizedSource) {
      setLoading(true);
    }
    setImageError(false);
  };

  const handleImageLoad = () => setLoading(false);

  const handleImageError = () => {
    if (imageError && resolvedSource === fallbackSource) return;
    setLoading(false);
    setImageError(true);
    if (normalizedSource?.uri) {
      failedUrisRef.current.add(normalizedSource.uri);
    }
    setResolvedSource(fallbackSource);
  };

  const displaySource =
    !imageError && normalizedSource ? normalizedSource : resolvedSource;
  const showLoader = loading && !imageError && !!normalizedSource;

  console.log('displaySource', JSON.stringify(displaySource));

  return (
    <View style={[styles.container, style]}>
      <FastImage
        source={displaySource}
        resizeMode={resizeMode || 'cover'}
        style={[styles.image, style]}
        onLoadStart={source?.uri && handleImageLoadStart}
        onLoad={source?.uri && handleImageLoad}
        onLoadEnd={source?.uri && handleImageLoad}
        onError={source?.uri && handleImageError}
        fadeDuration={300}
        resizeMethod="resize"
      />

      {showLoader && source?.uri && (
        <>
          <Image
            source={displaySource}
            style={[styles.image, StyleSheet.absoluteFill, style]}
            blurRadius={15}
            resizeMode={resizeMode || 'cover'}
          />
        </>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    position: 'relative',
    // backgroundColor: 'rgba(0,0,0,0.5)', // Optional: adjust based on needs
    backgroundColor: '#EFEFEF', // Optional: adjust based on needs
  },
  loader: {
    position: 'absolute',
    top: '50%',
    left: '50%',
  },
  image: {
    width: '100%',
    height: '100%',
  },
});

export default memo(CustomImage);
