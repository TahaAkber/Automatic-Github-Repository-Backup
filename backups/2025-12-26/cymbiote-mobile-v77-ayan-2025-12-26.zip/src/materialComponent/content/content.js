import React, { forwardRef } from 'react'; // Import forwardRef from React
import { StyleSheet, ScrollView } from 'react-native';
import { colors, WH } from '@constant/contstant';

// Use forwardRef to forward the ref correctly
const Content = forwardRef(({
  children,
  style,
  marginBottom,
  contentContainerStyle,
  paddingBottom,
  refreshControl,
  onScroll,
  horizontal,
  scrollEventThrottle,
  stickyHeaderIndices,
  disabled = false,
  backgroundColor,
}, ref) => {
  return (
    <ScrollView
      ref={ref}
      refreshControl={refreshControl}
      contentContainerStyle={contentContainerStyle}
      horizontal={horizontal}
      showsVerticalScrollIndicator={false}
      showsHorizontalScrollIndicator={false}
      onScroll={onScroll}
      scrollEventThrottle={scrollEventThrottle}
      keyboardShouldPersistTaps={'handled'}
      nestedScrollEnabled={true}
      pointerEvents={disabled ? 'none' : 'auto'} // Disable touch interactions
      stickyHeaderIndices={stickyHeaderIndices}
      style={[
        styles.view,
        backgroundColor && { backgroundColor },
        style,
        {
          marginBottom: marginBottom || 0,
          paddingBottom: paddingBottom || 0,
        },
      ]}
    >
      {children}
    </ScrollView>
  );
});

export default Content;

const styles = StyleSheet.create({
  view: {
    backgroundColor: colors.theme,
    height: WH.height('100%'),
    paddingBottom: 10,
    flex: 1,
  },
});
