import React from 'react';
import {View, Text, TextInput, StyleSheet} from 'react-native';
import CustomText from '../customText/customText';

const CustomInput = ({
  label,
  value,
  onChangeText,
  onBlur,
  onFocus,
  placeholder,
  error,
  required = false,
  keyboardType = 'default',
  returnKeyType = 'done',
  onSubmitEditing,
  inputRef,
  countryCode,
}) => {
  return (
    <View style={styles.container}>
      {/* Floating label */}
      {label && (
        <Text style={styles.label}>
          {label}
          {required && <Text style={styles.asterisk}>*</Text>}
        </Text>
      )}

      {/* Input box */}
      <View style={styles.inputWrapper}>
        <View style={styles.blueLine} />
        {countryCode ? (
          <CustomText style={styles.countryCode} text={countryCode} />
        ) : (
          <></>
        )}
        <TextInput
          ref={inputRef}
          style={styles.input}
          placeholder={placeholder}
          placeholderTextColor="#909294"
          value={value}
          onChangeText={onChangeText}
          onBlur={onBlur}
          onFocus={onFocus}
          keyboardType={keyboardType}
          returnKeyType={returnKeyType}
          onSubmitEditing={onSubmitEditing}
        />
      </View>

      {/* Error */}
      {/* {!!error && <Text style={styles.error}>* {error}</Text>} */}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    // marginBottom: 16,
    marginTop: 15,
  },
  label: {
    position: 'absolute',
    top: -10,
    left: 12,
    backgroundColor: '#fff',
    paddingHorizontal: 4,
    fontSize: 12,
    color: '#000',
    zIndex: 1,
  },
  asterisk: {
    color: 'green',
  },
  inputWrapper: {
    borderWidth: 2,
    borderColor: '#ebebeb', // Always focused style
    borderRadius: 8,
    backgroundColor: '#fff',
    paddingHorizontal: 12,
    paddingTop: 16,
    paddingBottom: 10,
    flexDirection: 'row',
    alignItems: 'center',
    height: 60, // Set a fixed height for the input box
  },
  input: {
    fontSize: 14,
    color: '#000',
    padding: 0,
    margin: 0,

    marginLeft: 3,
    width: '95%',
  },
  countryCode: {
    fontSize: 14,
    color: '#000',
    padding: 0,
    margin: 0,

    marginLeft: 3,
  },
  error: {
    color: 'red',
    fontSize: 12,
    marginTop: 4,
    marginLeft: 4,
  },
  blueLine: {
    width: 3,
    height: '100%',
    marginRight: 8,
    backgroundColor: '#0066FF',
    borderRadius: 8,
    // borderTopLeftRadius: 8,
    // borderBottomLeftRadius: 8,
  },
});

export default CustomInput;
