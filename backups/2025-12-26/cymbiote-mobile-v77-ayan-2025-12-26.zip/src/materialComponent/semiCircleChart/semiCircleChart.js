import React from 'react';
import {View, Text, StyleSheet, Dimensions} from 'react-native';
import Svg, {Path} from 'react-native-svg';
import CustomText from '../customText/customText';
import {colors, font} from '../../constant/contstant';
import {toFixedMethod, toFixedMethod2} from '../../utils/helper/helper';

// Get screen width dynamically
const {width, height, fontScale} = Dimensions.get('screen');
const size = width * 0.7; // 70% of screen width for responsiveness

const SemiCircleChart = ({userPoint}) => {
  const confirmPoint = Number(userPoint?.confirmPoint || 0);
  const pendingPoint = Number(userPoint?.pendingPoint || 0);
  const redeemedPoint = Number(userPoint?.processingPoint || 0);
  const totalPoints = confirmPoint + pendingPoint + redeemedPoint || 0;
  const ShowtotalPoints = userPoint?.totalPoints || 0;

  const strokeWidth = size * 0.09; // Thickness relative to size
  const radius = (size - strokeWidth) / 2;
  const centerX = size / 2;
  const centerY = size / 2;

  const color = [
    totalPoints ? colors.light_theme.confirmed : colors.light_theme.themeGray,
    totalPoints ? colors.light_theme.pending : colors.light_theme.themeGray,
    totalPoints ? colors.light_theme.theme : colors.light_theme.themeGray,
  ];
  // const angles = [Math.PI, 1.5 * Math.PI, 1.8 * Math.PI, 2 * Math.PI]; // Start & end angles

  const startAngle = Math.PI; // Start at 180°

  let angles;

  if (totalPoints > 0) {
    const confirmAngle = (confirmPoint / totalPoints) * Math.PI;
    const pendingAngle = (pendingPoint / totalPoints) * Math.PI;
    const redeemedAngle = (redeemedPoint / totalPoints) * Math.PI;

    angles = [
      startAngle,
      startAngle + confirmAngle,
      startAngle + confirmAngle + pendingAngle,
      Math.PI * 2,
    ];
  } else {
    // If totalPoints is 0, show equal thirds
    angles = [
      startAngle,
      startAngle + Math.PI / 3,
      startAngle + (2 * Math.PI) / 3,
      Math.PI * 2,
    ];
  }

  // Function to create an arc path
  const createArcPath = (startAngle, endAngle) => {
    const startX = centerX + radius * Math.cos(startAngle);
    const startY = centerY + radius * Math.sin(startAngle);
    const endX = centerX + radius * Math.cos(endAngle);
    const endY = centerY + radius * Math.sin(endAngle);

    const largeArcFlag = endAngle - startAngle <= Math.PI ? '0' : '1';

    return `
            M ${startX} ${startY}
            A ${radius} ${radius} 0 ${largeArcFlag} 1 ${endX} ${endY}
        `;
  };

  return (
    <View style={styles.container}>
      {/* SVG for Semi-Circle with Rounded Ends */}
      <Svg width={size} height={size / 2} viewBox={`0 0 ${size} ${size / 2}`}>
        {color.map((color, index) => (
          <Path
            key={index}
            d={createArcPath(angles[index], angles[index + 1])}
            stroke={color}
            strokeWidth={strokeWidth}
            fill="none"
          />
        ))}
      </Svg>

      {/* Display Total Points */}
      <View
        style={{
          marginTop: height * -0.06,
          justifyContent: 'center',
          alignItems: 'center',
        }}>
        {/* <CustomText fontFamily={font.bold} fontSize={fontScale * 25} text={toFixedMethod(userPoint?.totalPoints)} /> */}
        <CustomText
          fontFamily={font.bold}
          fontSize={fontScale * 20}
          text={toFixedMethod2(ShowtotalPoints)}
        />
        <CustomText
          color={'#7B78AA'}
          fontSize={fontScale * 15}
          text={'Total Points'}
        />
      </View>

      <View
        style={{
          marginTop: height * 0.04,
          flexDirection: 'row',
          justifyContent: 'space-between',
          alignItems: 'center',
        }}>
        <View
          style={{
            width: '30%',
            justifyContent: 'center',
            alignItems: 'center',
          }}>
          <View
            style={{
              width: '50%',
              height: height * 0.008,
              backgroundColor: colors.light_theme.confirmed,
              borderRadius: 180,
            }}
          />
          <CustomText
            marginTop={height * 0.005}
            color={'#808080'}
            fontFamily={font.medium}
            fontSize={fontScale * 13}
            text={'Confirmed'}
          />
          <CustomText
            marginTop={height * 0.002}
            color={'black'}
            fontFamily={font.medium}
            fontSize={fontScale * 13}
            text={toFixedMethod2(confirmPoint)}
          />
        </View>
        <View
          style={{
            width: '30%',
            justifyContent: 'center',
            alignItems: 'center',
          }}>
          <View
            style={{
              width: '50%',
              height: height * 0.008,
              backgroundColor: colors.light_theme.pending,
              borderRadius: 180,
            }}
          />
          <CustomText
            marginTop={height * 0.005}
            color={'#808080'}
            fontFamily={font.medium}
            fontSize={fontScale * 13}
            text={'Pending'}
          />
          <CustomText
            marginTop={height * 0.002}
            color={'black'}
            fontFamily={font.medium}
            fontSize={fontScale * 13}
            text={toFixedMethod2(pendingPoint)}
          />
        </View>
        <View
          style={{
            width: '30%',
            justifyContent: 'center',
            alignItems: 'center',
          }}>
          <View
            style={{
              width: '50%',
              height: height * 0.008,
              backgroundColor: colors.light_theme.theme,
              borderRadius: 180,
            }}
          />
          <CustomText
            marginTop={height * 0.005}
            color={'#808080'}
            fontFamily={font.medium}
            fontSize={fontScale * 13}
            text={'Redeemed'}
          />
          <CustomText
            marginTop={height * 0.002}
            color={'black'}
            fontFamily={font.medium}
            fontSize={fontScale * 13}
            text={toFixedMethod2(redeemedPoint)}
          />
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    alignSelf: 'center',
    // height: size / 2,
    width: size,
    // borderRadius: size / 2,
    // overflow: "hidden"
  },
  points: {
    fontSize: 24,
    fontWeight: 'bold',
    marginTop: -30,
  },
  label: {
    fontSize: 14,
    color: 'gray',
  },
});

export default SemiCircleChart;
