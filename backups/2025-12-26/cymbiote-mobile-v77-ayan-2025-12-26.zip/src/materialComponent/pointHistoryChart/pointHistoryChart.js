import React from "react";
import { View, Text, StyleSheet, Dimensions } from "react-native";
import { PieChart } from "react-native-gifted-charts";
import CustomText from "../customText/customText";
import { font } from "../../constant/contstant";

const { width, height, fontScale } = Dimensions.get("window");

const GiftedChart = () => {
    const data = [
        { value: 1200, color: "#FDD835" }, // Collect
        { value: 700, color: "#A4C2F4" },  // Redeem
    ];

    return (
        <View style={styles.container}>
            <View style={styles.chartContainer}>
                <PieChart
                    data={data}
                    radius={width * 0.25} // Dynamic radius based on screen width
                    innerRadius={width * 0.18} // Adjusts inner radius accordingly
                    showText={false}
                    donut
                />
                <View style={styles.centerTextContainer}>
                    <CustomText fontSize={fontScale * 16} fontFamily={font.bold} text={"PKR 2,000"} />
                    <CustomText fontSize={fontScale * 14} marginTop={height * 0.005} color={"#899D8F"} fontFamily={font.regular} text={"Total Points"} />
                </View>
            </View>

            {/* Legend */}
            <View style={styles.legendContainer}>
                <View style={styles.legendItem}>
                    <View style={[styles.legendDot, { backgroundColor: "#A4C2F4" }]} />
                    <CustomText fontSize={fontScale * 14} fontFamily={font.medium} text={"Redeem"} />
                </View>
                <View style={styles.legendItem}>
                    <View style={[styles.legendDot, { backgroundColor: "#FDD835" }]} />
                    <CustomText fontSize={fontScale * 14} fontFamily={font.medium} text={"Collect"} />
                </View>
            </View>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        alignItems: "center",
        justifyContent: "center",
        marginTop: 20,
    },
    chartContainer: {
        alignItems: "center",
        justifyContent: "center",
        width: "100%",
    },
    centerTextContainer: {
        position: "absolute",
        justifyContent: "center",
        alignItems: "center",
    },
    points: {
        fontSize: 24,
        fontWeight: "bold",
        color: "#000",
    },
    subtitle: {
        fontSize: 14,
        color: "gray",
    },
    legendContainer: {
        flexDirection: "row",
        justifyContent: "center",
        marginTop: height * 0.02,
        width: "80%",
    },
    legendItem: {
        flexDirection: "row",
        alignItems: "center",
        marginHorizontal: 10,
    },
    legendDot: {
        width: width * 0.02,
        aspectRatio: 1,
        borderRadius: 180,
        marginRight: width * 0.02,
    },
    legendText: {
        fontSize: 14,
        color: "#000",
    },
});

export default GiftedChart;
