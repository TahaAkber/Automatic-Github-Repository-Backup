// @flow

import React, { memo, useEffect, useState } from 'react';
import { StyleSheet, TouchableOpacity, FlatList } from 'react-native';
import { Image } from 'react-native';
import { ScrollView } from 'react-native';
import { View, Text, Picker } from 'react-native';
import { Menu, MenuOption, MenuOptions, MenuTrigger } from 'react-native-popup-menu';
import colors from '../../constantData/colors';
import Entypo from 'react-native-vector-icons/Entypo'
import AuthInput from '../../component/input/authInput';

/* ============================================================================
  <DropDown />
 ============================================================================= */
const DropDown = ({
    label,
    selectedValue,
    editable,
    onChange,
    data,
    labelStatus,
    allSelect,
    marginHorizontal,
    setType
}) => {

    const displaylabel = () => {
        if (setType) {
            return setType
        }
        else if (allSelect) {
            return 'All'
        } else {
            return 'Select'
        }
    }

    const [text, setText] = useState('')

    const getSelectedValue = data.filter((item, index) => item.id == selectedValue)
    const getSelectedValue1 = data.map((item, index) => {
        if (item.id == selectedValue) {
            return index
        }
    })

    const [filteredDataSource, setFilteredDataSource] = useState([]);

    const getSelectedValue2 = getSelectedValue1.filter((item, index) => item != undefined).[0] || 0

    const showLable = getSelectedValue.length ? getSelectedValue[0].value : `${displaylabel()} ${label.toLowerCase()}`
    // const allSelected = getSelectedValue.length ? getSelectedValue[0].value : `All ${label.toLowerCase()}`

    const [menu, setMenu] = React.useState(false)

    const hideMenu = () => {
        setMenu(false)
    }


    const searchFilterFunction = text => {
        setText(text);
        if (text) {
            const newData = data.filter(function (item) {
                const itemData = item.value;
                if (typeof itemData === 'string') {
                    const textData = text.toUpperCase();
                    return itemData.toUpperCase().indexOf(textData) > -1;
                }
                return false;
            });
            setFilteredDataSource(newData);
        } else {
            setFilteredDataSource(data);
        }
    };


    useEffect(() => {
        setFilteredDataSource(data)
        setText('')
    }, [data, menu])




    return (
        <View>
            {label && !labelStatus && (
                <Text
                    style={{
                        marginTop: 5,
                        color: '#696969',
                    }}>
                    {label}
                </Text>
            )}

            <View>
                <Menu opened={menu} onBackdropPress={hideMenu}>
                    <MenuTrigger children={
                        <TouchableOpacity
                            activeOpacity={0.7}
                            onPress={() => setMenu(true)}
                            disabled={editable}
                            style={[{
                                backgroundColor: !editable ? 'white' : '#DEDEDE',
                                marginHorizontal: marginHorizontal ? marginHorizontal : 0
                            }, styles.MenuTrigger]}>
                            <Text style={{ fontSize: 17, width: '80%' }}>{showLable}</Text>
                            <Entypo color='black' name={menu ? "chevron-up" : "chevron-down"} size={20} />
                        </TouchableOpacity>
                    } >
                    </MenuTrigger>
                    <MenuOptions optionsContainerStyle={{ width: '70%' }}>
                        {data.length >= 10 && <AuthInput
                            placeholder={`Search ${label.toLocaleLowerCase()}...`}
                            style={{ marginBottom: 0 }}
                            onChangeText={text => searchFilterFunction(text)}
                            value={text}
                        />}

                        <FlatList
                            style={{ maxHeight: 200 }}
                            data={filteredDataSource}
                            // initialScrollIndex={getSelectedValue2} // set the initialScrollIndex prop here
                            renderItem={({ item }) => (
                                <MenuOption
                                    style={styles.label}
                                    onSelect={() => {
                                        hideMenu();
                                        onChange(item.id);
                                    }}
                                    customStyles={selectedValue === item.id ? { optionWrapper: { backgroundColor: colors.backgroundColor } } : null}
                                    text={item.value}
                                />
                            )}
                            keyExtractor={(item) => item.id.toString()}
                            ListHeaderComponent={
                                <View>
                                    {text ?
                                        null :
                                        <MenuOption
                                            style={styles.label}
                                            onSelect={() => {
                                                hideMenu();
                                                onChange(0);
                                            }}
                                            text={`${displaylabel()} ${label.toLowerCase()}`}
                                        />
                                    }

                                </View>
                            }
                        />

                    </MenuOptions>
                </Menu>
            </View>

        </View>
    )
}

DropDown.defaultProps = {
    editable: false,
};

/* export
============================================================================= */
export default memo(DropDown);

const styles = StyleSheet.create({
    label: {
        fontSize: 15,
        marginHorizontal: 10,
        borderBottomWidth: 1,
        borderColor: colors.borderColor,
        width: '100%',
        paddingVertical: 10
    },
    MenuTrigger: {
        borderWidth: 1,
        borderColor: colors.borderColor,
        paddingRight: 5,
        // marginBottom: marginControl.filedMargin,
        paddingVertical: 9,
        paddingHorizontal: 5,
        flexDirection: 'row', justifyContent: 'space-between',
        height: 43,
        // alignItems : 'center'
        // marginTop : -5,
    }
})