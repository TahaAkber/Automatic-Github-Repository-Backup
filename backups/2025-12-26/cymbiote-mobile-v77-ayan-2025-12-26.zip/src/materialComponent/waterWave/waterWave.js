import React from 'react';
import { StyleSheet, View } from 'react-native';
import Animated, { Easing, withRepeat, withTiming } from 'react-native-reanimated';
import Svg, { Path } from 'react-native-svg';

const WaterWave = () => {
    const waveAnimation = withRepeat(
        withTiming(1, { duration: 3000, easing: Easing.linear }),
        -1, // Infinite repeat
        true // Reverse after each iteration
    );

    return (
        <View style={styles.container}>
            <Animated.View style={[styles.water, { transform: [{ translateY: waveAnimation }] }]}>
                <Svg width="100%" height="100%">
                    <Path
                        fill="rgba(0, 122, 255, 0.5)" // Light blue color for water
                        d="M0,50 Q50,20 100,50 T200 50 T300 50 T400 50 T500 50"
                        stroke="none"
                    />
                </Svg>
            </Animated.View>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#fff',
    },
    water: {
        position: 'absolute',
        bottom: 0,
        left: 0,
        right: 0,
    },
});

export default WaterWave;
