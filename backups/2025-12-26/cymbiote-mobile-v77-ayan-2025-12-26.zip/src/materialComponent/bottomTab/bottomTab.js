import React, { useState, useEffect } from 'react';
import { StyleSheet, TouchableOpacity, View, Animated } from 'react-native';
import Icon from '@materialComponent/icon/icon';
import { colors, globalStyle, shadow, WH } from '@constant/contstant';
import { moderateScale } from 'react-native-size-matters';
import LinearGradient from 'react-native-linear-gradient';
import useReduxStore from '@utils/hooks/useReduxStore'; // Assuming useReduxStore is custom hook
import { SET_TAB } from '@redux/types/common/common';
import { navigate } from '../../utils/navigationRef/navigationRef';
// import { useNavigation } from '@react-navigation/native';

const iconSize = moderateScale(17);

const BottomTab = () => {
  // const navigation = useNavigation()
  const { dispatch, getState } = useReduxStore(); // Redux hook
  const [activeTab, setActiveTab] = useState('home'); // Default active tab
  const [tabAnimation] = useState(new Animated.Value(1)); // Animation for tab icon scale
  const [sliderPosition] = useState(new Animated.Value(0)); // Slider position animation
  const [bgOpacity] = useState(new Animated.Value(0)); // Animated value for background opacity

  // Get the current tab from redux store
  const { tab } = getState("common");

  useEffect(() => {
    if (tab) {
      setActiveTab(tab); // Update the active tab from redux
    }
  }, [tab]);

  const tabs = ['home', 'search1', 'shoppingcart'];

  const handleTabPress = (tab, index) => {
    setActiveTab(tab);

    // Animate the tab icon (scale effect)
    Animated.spring(tabAnimation, {
      toValue: 1.2, // Scale up the icon when pressed
      friction: 3,
      useNativeDriver: true,
    }).start(() => {
      // After animation, return the scale to normal
      Animated.spring(tabAnimation, {
        toValue: 1,
        friction: 5,
        useNativeDriver: true,
      }).start();
    });

    // Animate the slider position to the active tab
    Animated.spring(sliderPosition, {
      toValue: index * (tab == "shoppingcart" ? WH.height(7.2) : tab == "search1" ? WH.height(7.2) : WH.height(7)), // Adjust slider position based on tab index
      friction: 3,
      useNativeDriver: true,
    }).start();

    // Animate the background color opacity gradually
    Animated.timing(bgOpacity, {
      toValue: 1, // Set opacity to full
      duration: 500, // Duration of the animation
      useNativeDriver: false, // We're animating the backgroundColor, so we need to disable native driver
    }).start();

    // Dispatch action to update the tab in the redux store
    dispatch({ type: SET_TAB, payload: tab });
  };

  return (
    <View style={styles.container}>
      {/* Gradient Background with animated opacity */}
      <Animated.View
        style={[
          StyleSheet.absoluteFillObject,
          {
            opacity: bgOpacity, // Bind animated opacity to the background
          },
        ]}
      >
        <LinearGradient
          colors={['rgba(255, 255, 255, 1)', 'rgba(255, 255, 255, 0)']}
          start={{ x: 0.5, y: 1 }}
          end={{ x: 0.5, y: 0 }}
          style={StyleSheet.absoluteFillObject}
        />
      </Animated.View>

      {/* Bottom Tab Content */}
      <View style={styles.innerContainer}>
        {/* Left Button (Back) */}
        <View style={{ width: '20%' }}>
          <TouchableOpacity onPress={() => console.log('Back pressed')} style={styles.backButton}>
            <Icon icon_type={'AntDesign'} name={'arrowleft'} size={iconSize} color={'black'} />
          </TouchableOpacity>
        </View>

        {/* Center Tabs */}
        <View style={{ width: '60%' }}>
          <View style={styles.tabs}>
            {/* Tab Icons */}
            {tabs.map((tab, index) => (
              <TouchableOpacity
                key={tab}
                onPress={() => handleTabPress(tab, index)}
                style={[
                  styles.tabIcon,
                  activeTab === tab && { backgroundColor: colors.light_theme.theme }, // Active tab
                ]}
              >
                {/* Animated tab icon */}
                <Animated.View
                  style={{
                    transform: [{ scale: activeTab === tab ? tabAnimation : 1 }],
                  }}
                >
                  <Icon
                    icon_type={'AntDesign'}
                    name={tab}
                    size={iconSize}
                    color={activeTab === tab ? 'white' : 'black'}
                  />
                </Animated.View>
              </TouchableOpacity>
            ))}

            {/* Slider under active tab */}
            <Animated.View
              style={[
                styles.slider,
                {
                  transform: [{ translateX: sliderPosition }], // Slider animation based on position
                },
              ]}
            />
          </View>
        </View>

        {/* Right Button (Cart) */}
        <View style={{ width: '20%', alignItems: 'flex-end' }}>
          {/* <TouchableOpacity onPress={() => navigate('Cart')} style={[styles.backButton, { backgroundColor: colors.light_theme.theme }]}>
            <Icon icon_type={'AntDesign'} name={'Cart'} size={iconSize} color={'white'} />
          </TouchableOpacity> */}
        </View>
      </View>
    </View>
  );
};

export default BottomTab;

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    bottom: 0,
    width: '100%',
    alignItems: 'center',
    paddingBottom: 10, // Adjust as needed
    paddingHorizontal: moderateScale(20),
  },
  innerContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    width: '90%', // Centers the tab bar without margin issues
    paddingVertical: 10,
    justifyContent: 'space-between', // Adjusts space between left, center, and right sections
  },
  tabs: {
    width: '100%',
    backgroundColor: 'white',
    height: WH.height(6),
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'space-around',
    flexDirection: 'row',
    ...shadow,
    position: 'relative', // Make sure the slider stays below tabs
  },
  tabIcon: {
    backgroundColor: 'white',
    borderRadius: 10,
    height: WH.height(4),
    aspectRatio: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  slider: {
    position: 'absolute',
    bottom: 0,
    width: WH.height(4), // Set slider width to match tab icon width
    height: 3, // Height of the slider
    backgroundColor: colors.light_theme.theme, // Slider color
    borderRadius: 2, // Optional rounded corners for the slider
  },
  backButton: {
    backgroundColor: 'white',
    height: WH.height(6),
    aspectRatio: 1,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    ...shadow,
  },
});
