import React from "react";
import { View, StyleSheet, Dimensions } from "react-native";
import CustomText from "../customText/customText";
import LinearGradient from "react-native-linear-gradient";
import { font, globalStyle } from "../../constant/contstant";

const steps = [
    { label: "In Progress", color: "#2E7DC1" },
    { label: "Shipped", color: "#FCB914" },
    { label: "In Transit", color: "#F57F21" },
    { label: "Delivered", color: "#23B477" },
];

const { height, width, fontScale } = Dimensions.get("screen");

const CustomProgressIndicatorVertical = ({ currentStep }) => {
    return (
        <View style={styles.container}>
            <View style={styles.progressContainer}>
                {/* Vertical Progress Bar */}
                <View style={styles.progressBar}>

                    {/* Gradient Progress for Each Completed Step */}
                    {currentStep >= 1 && (
                        <LinearGradient
                            colors={["#2E7DC1", "#FCB914"]}
                            start={{ x: 0, y: 0 }} // Top to Bottom Gradient
                            end={{ x: 0, y: 1 }}
                            style={[styles.gradientProgress, { height: height * 0.1, }]}
                        />
                    )}

                    {currentStep >= 2 && (
                        <LinearGradient
                            colors={["#FCB914", "#F57F21"]}
                            start={{ x: 0, y: 0 }}
                            end={{ x: 0, y: 1 }}
                            style={[styles.gradientProgress, { height: height * 0.1, }]}
                        />
                    )}

                    {currentStep >= 3 && (
                        <LinearGradient
                            colors={["#F57F21", "#23B477"]}
                            start={{ x: 0, y: 0 }}
                            end={{ x: 0, y: 1 }}
                            style={[styles.gradientProgress, { height: height * 0.1, }]}
                        />
                    )}
                    {currentStep >= 4 && (
                        <LinearGradient
                            colors={["white", "white"]}
                            start={{ x: 0, y: 0 }}
                            end={{ x: 0, y: 1 }}
                            style={[styles.gradientProgress, { height: height * 0.1, }]}
                        />
                    )}
                </View>

                {/* Steps Indicators & Labels */}
                <View style={styles.stepsContainer}>
                    {steps.map((step, index) => (
                        <View key={index} style={styles.stepWrapper}>
                            <View
                                style={[
                                    styles.stepCircle,
                                    { backgroundColor: index <= currentStep ? step.color : "#D9D9D9" },
                                ]}
                            />
                            <View style={{ height: height * 0.1, width: width * 0.8 }}>
                                <View style={{ marginTop: height * -0.005, ...globalStyle.space_between }}>
                                    <CustomText color={"black"} fontSize={fontScale * 15} fontFamily={font.bold} text={step.label} />
                                    <CustomText color={"black"} fontSize={fontScale * 15} fontFamily={font.medium} text={"April,19 12:31"} />
                                </View>
                                <CustomText marginTop={height * 0.002} color={"black"} fontSize={fontScale * 13} fontFamily={font.regular} text={"Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore."} />
                            </View>
                        </View>
                    ))}
                </View>
            </View>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        marginTop: height * 0.02,
        // alignItems: "center",
        zIndex: 1
    },
    progressContainer: {
        flexDirection: "row",
        alignItems: "center",
        height: height * 0.4,
    },
    progressBar: {
        width: width * 0.02,
        height: height * 0.4,
        borderRadius: 20,
        // backgroundColor: "#E5EBFC",
        // backgroundColor: "blue",
        // position: "absolute",
        // left: width * 0.03,
        zIndex: 1,
    },
    stepWrapper: {
        flexDirection: "row",
        // marginRight: -50

        // alignItems: "center",
        // marginBottom: height * 0.05, // Spacing between steps
    },
    stepCircle: {
        width: width * 0.05,
        aspectRatio: 1,
        // height: width * 0.04,
        borderRadius: 50,
        marginRight: width * 0.05,
        zIndex: 2,
        marginTop: height * -0.003

    },
    gradientProgress: {
        width: "100%",
        // position: "absolute",
        left: 0,
        zIndex: 2,
    },
    stepsContainer: {
        flexDirection: "column",
        marginLeft: width * -0.035,

        // backgroundColor: "red"
    },
});

export default CustomProgressIndicatorVertical;
