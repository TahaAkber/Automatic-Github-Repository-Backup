import {
    Dimensions,
    StyleSheet,
    TouchableOpacity,
} from 'react-native';
import React from 'react';
import { colors } from '@constant/contstant';
import Icon from '@materialComponent/icon/icon';

const { width } = Dimensions.get("screen")

const CircleIcon = ({ onPress, icon_type, name, color, size, style }) => {
    return (
        <TouchableOpacity onPress={onPress} style={[styles.mainView, style]}>
            <Icon icon_type={icon_type} name={name} color={color || "white"} size={size || width * 0.05} />
        </TouchableOpacity>
    );
};

export default CircleIcon;

const styles = StyleSheet.create({
    mainView: {
        width: width * 0.09,
        aspectRatio: 1,
        backgroundColor: colors.light_theme.theme,
        justifyContent: "center",
        alignItems: "center",
        borderRadius: 180
    },
});
