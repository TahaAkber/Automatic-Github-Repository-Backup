import React, { memo, useEffect, useState } from 'react';
import { Animated, StyleSheet, TouchableOpacity, View } from 'react-native';
import { moderateScale } from 'react-native-size-matters';
import { colors } from '@constant/contstant';
import Icon from '@materialComponent/icon/icon';
import useReduxStore from '../../utils/hooks/useReduxStore';
import { _favoriteUpdateStatus } from '../../redux/actions/user/user';

const Like = ({ style, size, product_id }) => {
  const { getState, dispatch } = useReduxStore()
  const { fetch_favorite_list_local, fetch_favorite_list } = getState("user")
  const liveProductIds = fetch_favorite_list.flatMap(shop => shop.products || []).map(p => p.product_id);
  const localProductIds = fetch_favorite_list_local.map(p => p.wishlist_product_id);
  const finalArray = [
    ...(Array.isArray(liveProductIds) ? liveProductIds : []),
    ...(Array.isArray(localProductIds) ? localProductIds : [])
  ];

  const [like, setLike] = useState(finalArray.includes(product_id)); // Track if the heart is liked
  const [scale] = useState(new Animated.Value(1)); // Scale animation for "pop" effect


  const _handleFavorite = async (value) => {
    try {
      setLike(value);
      const data = {
        wishlist_product_id: product_id
      }
      const response = await dispatch(_favoriteUpdateStatus(product_id, value, data, false, false, true));
    } catch (error) {
 
    }
  }

  const handleHeartClick = () => {
    // setIsLiked(!isLiked);
    _handleFavorite(!like);

    // // Start the "pop" animation
    // Animated.sequence([
    //   Animated.spring(scale, {
    //     toValue: 1.2, // scale up the icon
    //     friction: 3, // smooth spring animation
    //     useNativeDriver: true,
    //   }),
    //   Animated.spring(scale, {
    //     toValue: 1, // scale it back to original size
    //     friction: 3,
    //     useNativeDriver: true,
    //   }),
    // ]).start();
  };

  return (
    <TouchableOpacity
      activeOpacity={1}
      onPress={handleHeartClick}
      style={[
        styles.wishlist,
        style,
        {
          backgroundColor: like
            ? colors.light_theme.theme
            : 'rgba(0,0,0,0.2)',
        },
      ]}>
      <View>
        <Animated.View style={{ transform: [{ scale }], alignItems: "center", justifyContent: "center", marginTop: 2 }}>
          <Icon
            icon_type="AntDesign"
            color={'white'}
            name={like ? 'heart' : 'hearto'}
            size={size || moderateScale(12)}
          />
        </Animated.View>
      </View>
    </TouchableOpacity>
  );
};

export default memo(Like);

const styles = StyleSheet.create({
  wishlist: {
    position: 'absolute',
    // bottom: 0,
    top: 10,
    left: 10,
    backgroundColor: 'rgba(0,0,0,0.2)',
    borderRadius: 180,
    justifyContent: 'center',
    alignItems: 'center',
    width: moderateScale(25),
    height: moderateScale(25),
  },
});
