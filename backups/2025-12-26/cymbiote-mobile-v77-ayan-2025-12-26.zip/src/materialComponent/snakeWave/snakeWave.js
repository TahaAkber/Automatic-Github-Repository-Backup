import React from 'react';
import { StyleSheet, Dimensions, View } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import { colors, WH } from '../../constant/contstant';

const SnakeWave = () => {
    return (
        <View style={styles.blurContainer}>
            <LinearGradient
                colors={["rgba(84, 112, 199, 0.6)", "rgba(84, 112, 199, 0.3)", "rgba(255, 255, 255, 0.2)"]} // Smooth transition from blue to white
                locations={[0, 0.5, 1]} // Define where each color stop happens for a smoother gradient
                style={styles.gradient}
            />
        </View>
    );
};

const styles = StyleSheet.create({
    blurContainer: {
        position: 'absolute',
        top: 0,
        left: 0,
        width: '100%',
        height: WH.height(15), // Height of the gradient wave
    },
    gradient: {
        position: 'absolute',
        top: 0,
        left: 0,
        width: '100%',
        height: '100%', // Full height to ensure the gradient looks smooth
    },
});

export default SnakeWave;