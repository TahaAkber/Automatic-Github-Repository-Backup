import React, {useState, useEffect, useRef} from 'react';
import {
  View,
  Animated,
  TouchableWithoutFeedback,
  StyleSheet,
  Dimensions,
  Text,
  Vibration,
} from 'react-native';
import {font} from '../../constant/contstant';
import useReduxStore from '../../utils/hooks/useReduxStore';
import {_updateNotificationStatus} from '../../redux/actions/user/user';
import { triggerHaptic } from '../../utils/haptic/haptic';

const {width, fontScale} = Dimensions.get('screen');

const TOGGLE_WIDTH = width * 0.12; // Adjusted width
const TOGGLE_HEIGHT = TOGGLE_WIDTH * 0.6;
const CIRCLE_SIZE = TOGGLE_HEIGHT * 0.8;
const PADDING = TOGGLE_HEIGHT * 0.12;
const BORDER_RADIUS = TOGGLE_HEIGHT / 2;

const ToggleSwitch = ({isOn, onToggle}) => {
  const animatedValue = useRef(new Animated.Value(isOn ? 1 : 0)).current;

  useEffect(() => {
    Animated.timing(animatedValue, {
      toValue: isOn ? 1 : 0,
      duration: 200,
      useNativeDriver: false,
    }).start();
  }, [isOn]);

  const switchColor = animatedValue.interpolate({
    inputRange: [0, 1],
    outputRange: ['#ddd', '#007AFF'],
  });

  const translateX = animatedValue.interpolate({
    inputRange: [0.1, 1.2],
    outputRange: [PADDING, TOGGLE_WIDTH - CIRCLE_SIZE - PADDING],
  });

  return (
    <TouchableWithoutFeedback onPress={onToggle}>
      <Animated.View
        style={[
          styles.toggleContainer,
          {
            backgroundColor: switchColor,
            width: TOGGLE_WIDTH,
            height: TOGGLE_HEIGHT,
            padding: PADDING,
            borderRadius: BORDER_RADIUS,
          },
        ]}>
        <Animated.View
          style={[
            styles.circle,
            {
              transform: [{translateX}],
              width: CIRCLE_SIZE,
              height: CIRCLE_SIZE,
            },
          ]}
        />
      </Animated.View>
    </TouchableWithoutFeedback>
  );
};

const NotificationSetting = ({marginTop, text, item}) => {
  const {dispatch, getState} = useReduxStore();
  const {fetch_user_notification_statuses} = getState('user');
  const [isEnabled, setIsEnabled] = useState(
    fetch_user_notification_statuses?.[item?.db_value] || false,
  );

  const handleToggle = () => {
    setIsEnabled(!isEnabled);
    triggerHaptic()
    dispatch(_updateNotificationStatus(item.db_value, !isEnabled));
  };

  return (
    <View style={[styles.mainView, {marginTop}]}>
      <View style={styles.content}>
        <View style={styles.row}>
          <Text style={styles.text}>{text}</Text>
          {/* Fixing right spacing issue */}
          <View style={styles.toggleWrapper}>
            <ToggleSwitch isOn={isEnabled} onToggle={handleToggle} />
          </View>
        </View>
      </View>
    </View>
  );
};

export default NotificationSetting;

const styles = StyleSheet.create({
  mainView: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  content: {
    width: '100%',
    // paddingVertical: width * 0.02,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between', // ✅ Ensures correct spacing
    // paddingVertical: width * 0.02,
  },
  text: {
    fontSize: fontScale * 15,
    fontFamily: font.regular,
    color: 'black',
  },
  toggleWrapper: {
    width: TOGGLE_WIDTH + 10, // ✅ Ensures proper spacing
    alignItems: 'flex-end', // ✅ Positions toggle correctly
    // paddingRight: width * 0.03, // ✅ Adds proper right padding
  },
  toggleContainer: {
    justifyContent: 'center',
  },
  circle: {
    backgroundColor: 'white',
    borderRadius: 50,
  },
});
