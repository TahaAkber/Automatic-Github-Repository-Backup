import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Animated,
  Easing,
} from 'react-native';
import {font, fontScale, margin} from '../../constant/contstant';
import {moderateScale} from 'react-native-size-matters';

const CustomToggle = ({value, onValueChange, text, description, marginTop}) => {
  const toggleWidth = 50;
  const toggleHeight = 28;
  const circleSize = 24;

  const translateX = React.useRef(
    new Animated.Value(value ? toggleWidth - circleSize - 2 : 2),
  ).current;

  React.useEffect(() => {
    Animated.timing(translateX, {
      toValue: value ? toggleWidth - circleSize - 2 : 2,
      duration: 200,
      useNativeDriver: true,
      easing: Easing.out(Easing.circle),
    }).start();
  }, [value]);

  const handlePress = () => {
    onValueChange(!value);
  };

  return (
    <View
      style={{
        marginTop: marginTop || 20,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        marginHorizontal: margin.horizontal - 10,
      }}>
      <Text style={styles.text}>{text}</Text>
      {description && <Text style={styles.desc}>{description}</Text>}

      <TouchableOpacity
        style={[
          styles.toggleContainer,
          {width: toggleWidth, height: toggleHeight},
        ]}
        onPress={handlePress}
        activeOpacity={0.8}>
        {/* Background */}
        <Animated.View
          style={[
            StyleSheet.absoluteFill,
            {
              borderRadius: toggleHeight / 2,
              backgroundColor: value ? '#007AFF' : '#dcdde1', // ✅ Active / Inactive color
            },
          ]}
        />

        {/* Circle */}
        <Animated.View
          style={[
            styles.circle,
            {
              transform: [{translateX}],
              width: circleSize,
              height: circleSize,
              borderRadius: circleSize / 2,
            },
          ]}
        />
      </TouchableOpacity>
    </View>
  );
};

export default CustomToggle;

const styles = StyleSheet.create({
  toggleContainer: {
    justifyContent: 'center',
    backgroundColor: 'transparent',
    borderRadius: 30,
  },
  circle: {
    backgroundColor: '#fff',
    position: 'absolute',
    top: 2,
    left: 0,
    shadowColor: '#000',
    shadowOffset: {width: 0, height: 1},
    shadowOpacity: 0.2,
    shadowRadius: 1.5,
    elevation: 2,
  },
  text: {
    fontSize: moderateScale(13),
    fontFamily: font.bold,
    marginBottom: 4,
  },
  desc: {
    fontSize: fontScale * 12,
    color: '#555',
    marginBottom: 6,
  },
});
