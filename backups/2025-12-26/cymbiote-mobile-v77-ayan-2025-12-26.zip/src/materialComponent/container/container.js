import React from 'react';
import {Dimensions, StatusBar, View} from 'react-native';
import {StyleSheet, SafeAreaView} from 'react-native';
import {colors} from '@constant/contstant';
import useReduxStore from '../../utils/hooks/useReduxStore';
import {isAndroid} from '../../constant/contstant';
import {useSafeAreaInsets} from 'react-native-safe-area-context';

const Container = ({
  children,
  style,
  barColor,
  translucent,
  backgroundColor,
  safeArea,
  isFocused,
  dark,
  bgColor,
}) => {
  const {getState} = useReduxStore();
  const {token} = getState('auth');
  const insets = useSafeAreaInsets();
  const SafeArea = View;

  return (
    <SafeArea
      style={[
        styles.view,
        style,
        {paddingTop: isAndroid && insets.top},
        {paddingBottom: isAndroid && insets.bottom},
        barColor && {backgroundColor: barColor},
        bgColor && {backgroundColor: bgColor},
      ]}>
      {isAndroid ? (
        isFocused && (
          <StatusBar
            animated
            networkActivityIndicatorVisible={true}
            backgroundColor={barColor}
            translucent={translucent || false}
            barStyle={dark ? 'dark-content' : 'light-content'}
          />
        )
      ) : (
        <View
          style={{
            height: insets.top,
            backgroundColor:
              barColor || colors.light_theme.themeBackgroundColor,
          }}>
          <StatusBar
            animated
            networkActivityIndicatorVisible={true}
            backgroundColor={barColor}
            translucent={translucent || false}
            barStyle={dark ? 'dark-content' : 'light-content'}
          />
        </View>
      )}
      {children}
    </SafeArea>
  );
};

export default Container;

const styles = StyleSheet.create({
  view: {
    flex: 1,
  },
});
