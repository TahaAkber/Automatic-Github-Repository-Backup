import React from 'react';
import { StyleSheet, TouchableOpacity } from 'react-native';
import { goBack } from '@utils/navigationRef/navigationRef';
import { moderateScale } from 'react-native-size-matters';
import Icon from '@materialComponent/icon/icon';
import { shadow } from '@constant/contstant';
import { WH } from '@constant/contstant';

const BackOverLay = () => {
    return (
        <TouchableOpacity onPress={() => goBack()} style={styles.view}>
            <Icon
                size={moderateScale(20)}
                icon_type={"Ionicons"}
                name={"arrow-back"}
                color={"black"}
            />
        </TouchableOpacity>
    );
};

export default BackOverLay;

const styles = StyleSheet.create({
    view: {
        width: WH.width(12),
        backgroundColor: "white",
        justifyContent: "center",
        position: "absolute",
        alignItems: "center",
        borderRadius: 10,
        aspectRatio: 1,
        bottom: 20,
        ...shadow,
        left: 15
    }
})