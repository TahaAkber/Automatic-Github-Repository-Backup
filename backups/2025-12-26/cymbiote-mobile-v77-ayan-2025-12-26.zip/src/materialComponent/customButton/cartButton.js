import { StyleSheet, Text, View, TouchableOpacity, ActivityIndicator, Dimensions } from 'react-native';
import React from 'react';
import { moderateScale, scale, verticalScale } from 'react-native-size-matters';
import { colors, font, WH } from '@constant/contstant';
import DeleteCart from '@assets/images/cart_delete.svg';
import Icon from '../icon/icon';
const { fontScale } = Dimensions.get("screen")

const CartButton = ({
    filename,
    name,
    editText,
    logoutIcon,
    textStyle,
    text,
    buttonStyle,
    onPress,
    disabled,
    enabled,
    light,
    backgroundColor,
    width,
    height,
    fontSize,
    marginTop,
    color,
    iconType,
    size,
    loader,
    outline,
    ImageComponent,
    price,
    deleteIcon,
    deletePress
}) => {
    return (
        <View>
            <TouchableOpacity
                style={[
                    styles.designButton,
                    light && styles.lightButton,
                    // backgroundColor && { backgroundColor },
                    width && { width },
                    height && { height },
                    marginTop && { marginTop },
                    buttonStyle,
                    (loader || disabled) && { opacity: 0.7 },
                    outline && { backgroundColor: "white", borderWidth: 1, borderColor: colors.light_theme.backgroundColor }
                ]}
                onPress={onPress}
                disabled={loader || disabled}
                enabled={enabled}>
                {deleteIcon ?
                    <TouchableOpacity onPress={deletePress} activeOpacity={1} style={{ backgroundColor: "#375DFB", borderRadius: 180, width: WH.height(2.8), aspectRatio: 1, justifyContent: "center", alignItems: "center" }}>
                        <DeleteCart
                            width={WH.height(1.5)}
                            height={WH.height(1.5)}
                        />
                    </TouchableOpacity> : <></>
                }

                <Text
                    style={[
                        styles.text,
                        light && { color: 'white' },
                        outline && { color: colors.light_theme.theme },
                        fontSize && { fontSize },
                        textStyle,
                        // ImageComponent && { marginLeft: 10 }
                    ]}>
                    {text}
                </Text>
                {price &&
                    <Text
                        style={[
                            styles.text,
                            light && { color: 'white' },
                            outline && { color: colors.light_theme.theme },
                            fontSize && { fontSize },
                            textStyle,
                            // ImageComponent && { marginLeft: 10 }
                        ]}>
                        {price}
                    </Text>
                }

                {/* {loader &&
                    <ActivityIndicator color={"white"} size={"large"} />
                } */}

            </TouchableOpacity>
        </View>
    );
};

export default CartButton;

const styles = StyleSheet.create({
    designButton: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        backgroundColor: "black",
        // width:'25%',
        paddingHorizontal: scale(12),
        paddingLeft: scale(8),
        alignItems: 'center',
        // paddingVertical: verticalScale(10),
        borderRadius: 100,
        height: WH.height(6.5),
    },
    lightButton: {
        flexDirection: 'row',
        justifyContent: 'center',
        backgroundColor: 'white',
        // width:'25%',
        paddingHorizontal: scale(20),
        alignItems: 'center',
        // paddingVertical: verticalScale(10),
        borderRadius: moderateScale(10),
        height: WH.height(6.5),
    },
    text: {
        color: 'white',
        fontSize: fontScale * 15,
        fontFamily: font.bold,
        textAlign: "center"
    },
});
