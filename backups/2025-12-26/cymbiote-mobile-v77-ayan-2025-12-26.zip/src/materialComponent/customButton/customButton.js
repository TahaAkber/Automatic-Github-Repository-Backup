import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  ActivityIndicator,
  Dimensions,
} from 'react-native';
import React from 'react';
import {moderateScale, scale, verticalScale} from 'react-native-size-matters';
import {colors, font, WH} from '@constant/contstant';
import Icon from '../icon/icon';

const {height: customHeight} = Dimensions.get('screen');

const CustomButton = ({
  // Default value
  filename,
  name,
  editText,
  logoutIcon,
  textStyle,
  text,
  buttonStyle,
  onPress,
  disabled,
  enabled,
  light,
  backgroundColor,
  width,
  height,
  fontSize,
  marginTop,
  color,
  iconType,
  size,
  loader,
  outline,
  ImageComponent,
  iconStyle,
  imageComponentStyle,
  ImageComponentSize,
  ImageComponentPress,
  paddingHorizontal, // Default value
  loaderSize,
  borderColor,
  borderRadius,
  disabledOpacity = 0.7,
  forceHeight,
}) => {
  const IsTouchableOpacity = ImageComponentPress ? TouchableOpacity : View;
  return (
    <View>
      <TouchableOpacity
        activeOpacity={1}
        style={[
          borderRadius && {borderRadius},
          styles.designButton,
          light && styles.lightButton,
          backgroundColor && {backgroundColor},
          width && {width},
          height && {height},
          marginTop && {marginTop},
          buttonStyle,
          (loader || disabled) && {opacity: disabledOpacity},
          paddingHorizontal && {paddingHorizontal},
          outline && {
            backgroundColor: 'white',
            borderWidth: 1,
            borderColor: borderColor || colors.light_theme.backgroundColor,
          },
          {borderRadius: 180},
          {height: customHeight * 0.054},
          forceHeight && {height: forceHeight},
        ]}
        onPress={onPress}
        disabled={loader || disabled}
        enabled={enabled}>
        {iconType && (
          <Icon
            icon_type={iconType}
            name={name ? name : 'logout'}
            size={size || 20}
            color={color || 'white'}
            style={[iconStyle]}
          />
        )}
        {ImageComponent && (
          <IsTouchableOpacity
            onPress={ImageComponentPress}
            activeOpacity={1}
            style={[imageComponentStyle]}>
            <ImageComponent
              width={ImageComponentSize || WH.height(3.5)}
              height={ImageComponentSize || WH.height(3.5)}
            />
          </IsTouchableOpacity>
        )}
        {text && !loader && (
          <View
            // style={
            //   // ImageComponent &&
            //   // !imageComponentStyle && {width: '100%'}
            // }
            >
            <Text
              style={[
                styles.text,
                light && {color: 'black'},
                outline && {color: colors.light_theme.theme},
                fontSize && {fontSize},
                textStyle,
                // ImageComponent && { marginLeft: 10 }
              ]}>
              {text}
            </Text>
          </View>
        )}

        {loader && (
          <ActivityIndicator color={'white'} size={loaderSize || 'large'} />
        )}
      </TouchableOpacity>
    </View>
  );
};

export default CustomButton;

const styles = StyleSheet.create({
  designButton: {
    flexDirection: 'row',
    justifyContent: 'center',
    backgroundColor: colors.light_theme.theme,
    // width:'25%',
    // paddingHorizontal: scale(20),
    alignItems: 'center',
    // paddingVertical: verticalScale(10),
    borderRadius: moderateScale(10),
    height: WH.height(6.5),
  },
  lightButton: {
    flexDirection: 'row',
    justifyContent: 'center',
    backgroundColor: 'white',
    // width:'25%',
    paddingHorizontal: scale(20),
    alignItems: 'center',
    // paddingVertical: verticalScale(10),
    borderRadius: moderateScale(10),
    height: WH.height(6.5),
  },
  text: {
    color: 'white',
    fontSize: moderateScale(16),
    fontFamily: font.medium,
    // backgroundColor:"red",
    // maxWidth : "70%"
  },
});
