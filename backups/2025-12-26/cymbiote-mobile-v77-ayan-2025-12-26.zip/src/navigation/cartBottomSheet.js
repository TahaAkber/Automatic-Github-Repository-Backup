import React, {useRef} from 'react';
import {
  Animated,
  PanResponder,
  StyleSheet,
  TouchableOpacity,
  View,
} from 'react-native';
import {useSafeAreaInsets} from 'react-native-safe-area-context';
import Cart from '../screen/loggedIn/cart/cart';
import EmptyScreen from '../component/emptyScreen/emptyScreen';
import Icon from '../materialComponent/icon/icon';
import {margin, shadow} from '../constant/contstant';
import {
  heightPercentageToDP as hp,
  widthPercentageToDP as wp,
} from 'react-native-responsive-screen';
import {moderateScale} from 'react-native-size-matters';

const CartBottomSheet = ({
  animatedHeight,
  isVisible,
  cartItems,
  onClose,
  backgroundDim,
  tabsTranslateY,
  opacity = 1,
}) => {
  const insets = useSafeAreaInsets();
  const hasItems = Array.isArray(cartItems) && cartItems.length > 0;
  const openHeight = hp(101);
  const openTranslate = -hp(105);
  const dragState = useRef({startHeight: openHeight}).current;

  const syncTabsTranslate = heightValue => {
    const progress = openHeight === 0 ? 0 : heightValue / openHeight;

    if (tabsTranslateY) {
      const targetTranslate = openTranslate * progress;
      tabsTranslateY.setValue(targetTranslate);
    }

    if (backgroundDim) {
      backgroundDim.setValue(progress);
    }
  };

  const panResponder = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onMoveShouldSetPanResponder: (_, gestureState) =>
        Math.abs(gestureState.dy) > 5,
      onPanResponderGrant: () => {
        dragState.startHeight =
          typeof animatedHeight?.__getValue === 'function'
            ? animatedHeight.__getValue()
            : openHeight;
      },
      onPanResponderMove: (_, gestureState) => {
        const newHeight = dragState.startHeight - gestureState.dy;
        const clampedHeight = Math.max(0, Math.min(openHeight, newHeight));
        animatedHeight.setValue(clampedHeight);
        syncTabsTranslate(clampedHeight);
      },
      onPanResponderRelease: (_, gestureState) => {
        const shouldClose = gestureState.dy > hp(8);

        if (shouldClose) {
          onClose && onClose();
          return;
        }

        Animated.parallel([
          Animated.timing(animatedHeight, {
            toValue: openHeight,
            duration: 200,
            useNativeDriver: false,
          }),
          tabsTranslateY
            ? Animated.timing(tabsTranslateY, {
                toValue: openTranslate,
                duration: 200,
                useNativeDriver: false,
              })
            : null,
        ].filter(Boolean)).start();

      },
    }),
  ).current;

  return (
    <Animated.View
      style={[styles.container, {height: animatedHeight, opacity}]}>
      <Animated.View
        style={[
          styles.handleContainer,
          {paddingTop: hp(5) + Math.max(insets.top * 0.4, hp(1))},
        ]}
        {...panResponder.panHandlers}>
        <View style={styles.handle} />
      </Animated.View>

      <View style={styles.content}>
        {hasItems ? (
          <Cart />
        ) : (
          <View style={styles.emptyState}>
            <EmptyScreen
              image="empty_cart"
              heading="Your Cart is Empty!"
              desc="Start exploring and find amazing deals on your favorite items. Add products and check out whenever you're ready. Happy shopping!"
            />
          </View>
        )}
      </View>

      {isVisible && (
        <TouchableOpacity onPress={onClose} style={styles.close}>
          <Icon
            icon_type="AntDesign"
            name="close"
            color="white"
            size={moderateScale(20)}
          />
        </TouchableOpacity>
      )}
    </Animated.View>
  );
};

export default CartBottomSheet;

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#f6f6f6',
    position: 'absolute',
    bottom: -10,
    width: '100%',
  },
  handleContainer: {
    paddingHorizontal: margin.horizontal,
    justifyContent: 'flex-end',
    backgroundColor: 'white',
    paddingVertical: hp(3),
    paddingTop: hp(5),
    borderBottomRightRadius: 30,
    borderBottomLeftRadius: 30,
  },
  handle: {
    width: '12%',
    height: hp(0.7),
    backgroundColor: 'black',
    borderRadius: 180,
    alignSelf: 'center',
  },
  content: {
    flex: 1,
    backgroundColor: '#f6f6f6',
  },
  emptyState: {
    justifyContent: 'center',
    alignItems: 'center',
    flex: 1,
  },
  close: {
    backgroundColor: 'black',
    width: wp(10),
    aspectRatio: 1,
    borderRadius: 180,
    position: 'absolute',
    bottom: hp(5),
    alignSelf: 'center',
    justifyContent: 'center',
    alignItems: 'center',
    ...shadow,
  },
});
