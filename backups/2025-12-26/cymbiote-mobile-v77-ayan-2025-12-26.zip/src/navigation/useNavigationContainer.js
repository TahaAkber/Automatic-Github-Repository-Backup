import useReduxStore from '@utils/hooks/useReduxStore';
import {useEffect, useState, useRef} from 'react';
import {Animated, Easing} from 'react-native';
import {heightPercentageToDP as hp} from 'react-native-responsive-screen';
import {
  _initiateApi,
  _checkAppUpdate,
  _skipAppUpdate,
} from '../redux/actions/common/common';

const useNavigationContainer = () => {
  const [splash, setSplash] = useState(true);

  const duration = 500;

  const animatedHeight = useRef(new Animated.Value(0)).current; // Controls bottom sheet height
  const appTabsTranslateY = useRef(new Animated.Value(0)).current; // Controls AppTabs movement
  const appTabsOpacity = useRef(new Animated.Value(1)).current; // Controls AppTabs opacity (fade-in/out)
  const bottomSheetOpacity = useRef(new Animated.Value(0)).current; // Controls bottom sheet opacity

  const {getState, dispatch} = useReduxStore();
  const {cartBottomSheet, introSlider, notificationToken, appUpdateStatus} =
    getState('common');
  let {cart_item} = getState('cart');
  const backgroundColorAnim = useRef(new Animated.Value(0)).current; // Controls background color transition

  console.log('notificationToken', cartBottomSheet);

  const checkAppUpdate = async () => {
    try {
      await dispatch(_checkAppUpdate());
    } catch (error) {
      console.log('update check error', error?.message);
    }
  };

  // Function to handle smooth animation with fade-in/out effects
  const animateUI = expand => {
    Animated.parallel([
      Animated.timing(animatedHeight, {
        toValue: expand ? hp(101) : 0, // Expand to 101% or collapse
        duration: duration,
        easing: Easing.out(Easing.exp),
        useNativeDriver: false, // Needed for height animation
      }),
      Animated.timing(appTabsTranslateY, {
        toValue: expand ? -hp(105) : 0, // Move AppTabs up when expanded
        duration: duration,
        easing: Easing.out(Easing.exp),
        useNativeDriver: false,
      }),
      Animated.timing(appTabsOpacity, {
        toValue: expand ? 0.3 : 1, // Reduce opacity when expanded (fade out), restore when collapsed
        duration: duration,
        easing: Easing.out(Easing.exp),
        useNativeDriver: false,
      }),
      Animated.timing(bottomSheetOpacity, {
        toValue: expand ? 1 : 0, // Fade in the bottom sheet when expanded
        duration: duration,
        easing: Easing.out(Easing.exp),
        useNativeDriver: false, // Keep JS driver to avoid mixing with height animation
      }),
      Animated.timing(backgroundColorAnim, {
        toValue: expand ? 1 : 0, // Change background color based on state
        duration: duration,
        easing: Easing.out(Easing.exp),
        useNativeDriver: false, // Color animation not supported on native driver
      }),
    ]).start();
  };

  useEffect(() => {
    animateUI(cartBottomSheet); // Animate when cartBottomSheet state changes
  }, [cartBottomSheet]);

  const fetchAPI = async () => {
    await dispatch(_initiateApi(setSplash, false, true));
  };

  useEffect(() => {
    checkAppUpdate();
    fetchAPI();
  }, []);

  const animatedBackgroundColor = backgroundColorAnim.interpolate({
    inputRange: [0, 1],
    outputRange: ['transparent', 'rgba(0,0,0,0.6)'], // Transition from clear to dimmed black
  });

  const skipUpdateScreen = () => {
    dispatch(_skipAppUpdate(appUpdateStatus?.updatedAt || ''));
  };

  return {
    setSplash,
    showUpdateScreen: appUpdateStatus?.needsUpdate,
    canSkipUpdate: appUpdateStatus?.canSkip,
    updateUrl: appUpdateStatus?.storeUrl,
    latestVersion: appUpdateStatus?.latestVersion,
    skipUpdateScreen,
    animatedBackgroundColor,
    backgroundColorAnim,
    appTabsTranslateY,
    appTabsOpacity,
    animatedHeight,
    bottomSheetOpacity,
    introSlider,
    dispatch,
    splash,
    cartBottomSheet,
    cart_item,
  };
};

export default useNavigationContainer;
