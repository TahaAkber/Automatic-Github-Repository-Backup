import {useRef, useEffect} from 'react';
import {useIsFocused} from '@react-navigation/native';
import analytics from '@react-native-firebase/analytics';
import {Platform} from 'react-native';
import {getDeviceId, getStoreState} from '../../utils/helper/helper';

/**
 * Helper function to remove null, undefined, and empty string values from event objects
 * This keeps analytics data clean and reduces payload size
 */
const cleanEvent = eventData => {
  return Object.fromEntries(
    Object.entries(eventData).filter(
      ([_, value]) => value !== null && value !== undefined && value !== '',
    ),
  );
};

// export const useEventTriggers = screenName => {
//   const startTimeRef = useRef(null);
//   const startInteractionTimeRef = useRef(null);
//   useFocusEffect(() => {
//     startInteractionTimeRef.current = new Date().toISOString();
//     startTimeRef.current = Date.now();

//     const logScreenEvent = async () => {
//       const screenEventPayload = {
//         screen_name: screenName,
//         start_time: startInteractionTimeRef.current,
//       };

//       // console.log(
//       //   `[${screenName}] Logging screen_event with details:`,
//       //   screenEventPayload,
//       // );

//       await analytics().logEvent('screen_event', screenEventPayload);
//       // console.log(`[${screenName}] screen_event logged`);
//     };

//     logScreenEvent();

//     return () => {
//       const endTime = Date.now();
//       const durationSec = (
//         (endTime - (startTimeRef.current || endTime)) /
//         1000
//       ).toFixed(2);

//       const currentTime = new Date().toISOString(); // Current time when interaction ends

//       const screenEventPayload = {
//         screen_name: screenName,
//         screen_time_seconds: Number(durationSec), // Time spent in seconds
//         start_time: startInteractionTimeRef.current, // Interaction start time
//         end_time: currentTime, // Interaction end time
//       };

//       console.log(
//         `[${screenName}] Logging screen_event with complete details:`,
//         screenEventPayload,
//       );

//       analytics().logEvent('screen_event', screenEventPayload);

//       console.log(`[${screenName}] Time spent: ${durationSec}s`);
//     };
//   });
// };

// export const useEventTriggers = screenName => {
//   const startTimeRef = useRef(null);
//   const startInteractionTimeRef = useRef(null);

//   const triggerEvent = async () => {
//     startInteractionTimeRef.current = new Date().toISOString();
//     startTimeRef.current = Date.now();

//     const startPayload = {
//       screen_name: screenName,
//       start_time: startInteractionTimeRef.current,
//     };

//     console.log(`[${screenName}] Starting screen_event`, startPayload);
//     await analytics().logEvent('screen_event', startPayload);
//   };

//   const endEvent = async () => {
//     const endTime = Date.now();
//     const durationSec = (
//       (endTime - (startTimeRef.current || endTime)) /
//       1000
//     ).toFixed(2);

//     const endPayload = {
//       screen_name: screenName,
//       screen_time_seconds: Number(durationSec),
//       start_time: startInteractionTimeRef.current,
//       end_time: new Date().toISOString(),
//     };

//     console.log(`[${screenName}] Ending screen_event`, endPayload);
//     await analytics().logEvent('click_event', endPayload);
//   };

//   return {triggerEvent, endEvent};
// };



export const useEventTriggers = (screenName, context = {}) => {
  const {fetch_user_detail} = getStoreState('auth');
  const isFocused = useIsFocused();
  const startTimeRef = useRef(null);

  useEffect(() => {
    const isContextValid =
      context.product_id &&
      context.product_name &&
      context.merchant_id &&
      context.merchant_name;

    if (!isFocused || !isContextValid) return;

    startTimeRef.current = Date.now();

    return () => {
      // Only send if screen was focused and context remained valid
      if (!isContextValid || !startTimeRef.current) return;

      const duration = ((Date.now() - startTimeRef.current) / 1000).toFixed(2);

      const sendEvent = async () => {
        const deviceId = await getDeviceId();
        const now = new Date();
        const userInfo = getUserInfo();

        const event = {
          event_type: 'product_detail',
          product_view: 1,
          screen_time_seconds: Number(duration),
          screen_name: screenName,
          user_id: userInfo.user_id,
          user_name: userInfo.user_name,
          product_id: context.product_id,
          product_name: context.product_name,
          merchant_id: context.merchant_id,
          merchant_name: context.merchant_name,
          merchant_shopify_id: context.merchant_shopify_id,
          is_from_search: context.is_from_search || false,
          search_query: context.search_query || '',
          device_id: deviceId,
          platform: Platform.OS,
          timestamp: now.toISOString(),
        };

        console.log(`[${screenName}] product_detail`, event);
        await analytics().logEvent('product_detail', cleanEvent(event));
      };

      sendEvent();
      startTimeRef.current = null; // Reset so it doesn't double fire
    };
  }, [
    isFocused,
    context.product_id,
    context.product_name,
    context.merchant_id,
    context.merchant_name,
  ]);
};
export const useEventMerchantTrigger = (screenName, context = {}) => {
  const {fetch_user_detail} = getStoreState('auth');
  const isFocused = useIsFocused();
  const startTimeRef = useRef(null);

  useEffect(() => {
    const isContextValid = context.merchant_id && context.merchant_name;

    if (!isFocused || !isContextValid) return;

    startTimeRef.current = Date.now();

    return () => {
      if (!isContextValid || !startTimeRef.current) return;

      const duration = ((Date.now() - startTimeRef.current) / 1000).toFixed(2);

      const sendEvent = async () => {
        const deviceId = await getDeviceId();
        const now = new Date();
        const userInfo = getUserInfo();

        const event = {
          event_type: 'shop_view',
          merchant_view: 1,
          screen_time_seconds: Number(duration),
          screen_name: screenName,
          user_id: userInfo.user_id,
          user_name: userInfo.user_name,
          merchant_id: context.merchant_id,
          merchant_name: context.merchant_name,
          merchant_shopify_id: context.merchant_shopify_id,
          is_from_search: context.is_from_search || false,
          search_query: context.search_query || '',
          device_id: deviceId,
          platform: Platform.OS,
          timestamp: now.toISOString(),
        };

        console.log(`[${screenName}] shop><><><><><>`, event);
        await analytics().logEvent('shop', cleanEvent(event));
      };

      sendEvent();
      startTimeRef.current = null; // Reset so it doesn't double fire
    };
  }, [isFocused, context.merchant_id, context.merchant_name]);
};
export const useEventHomeTrigger = screenName => {
  const {fetch_user_detail} = getStoreState('auth');
  const isFocused = useIsFocused();
  const startTimeRef = useRef(null);
  console.log(fetch_user_detail, 'fetch_user_detail');
  useEffect(() => {
    if (!isFocused) return;

    startTimeRef.current = Date.now();

    return () => {
      if (!startTimeRef.current) return;

      const duration = ((Date.now() - startTimeRef.current) / 1000).toFixed(2);

      const sendEvent = async () => {
        const deviceId = await getDeviceId();
        const now = new Date();

        const userInfo = getUserInfo();
        const event = {
          event_type: 'home_view',
          screen_time_seconds: Number(duration),
          screen_name: screenName,
          user_id: userInfo.user_id,
          user_name: userInfo.user_name,
          device_id: deviceId,
          platform: Platform.OS,
          timestamp: now.toISOString(),
        };

        console.log(`[${screenName}]hometrigger`, event);
        await analytics().logEvent('home', cleanEvent(event));
      };

      sendEvent();
      startTimeRef.current = null; // Reset so it doesn't double fire
    };
  }, [isFocused]);
};

export const logSearchQueryEvent = async (searchQuery, results = {}) => {
  try {
    const deviceId = await getDeviceId();
    const now = new Date();
    const userInfo = getUserInfo();

    const event = {
      event_type: 'search_query',
      search_query: searchQuery,
      total_results: results.total_results || 0,
      products_count: results.products_count || 0,
      shops_count: results.shops_count || 0,
      user_id: userInfo.user_id,
      user_name: userInfo.user_name,
      device_id: deviceId,
      platform: Platform.OS,
      timestamp: now.toISOString(),
    };

    console.log('✅ [Firebase Analytics] search_query event logged:', {
      query: searchQuery,
      total: results.total_results || 0,
      products: results.products_count || 0,
      shops: results.shops_count || 0,
      user: event.user_name,
    });
    console.log('[Search] search_query FULL EVENT:', event);
    await analytics().logEvent('search_query', cleanEvent(event));
  } catch (error) {
    console.error('❌ [Firebase Analytics] Error logging search query:', error);
  }
};

export const logSearchItemClickEvent = async (
  item,
  searchQuery,
  position,
  resultType,
) => {
  try {
    const deviceId = await getDeviceId();
    const now = new Date();
    const userInfo = getUserInfo();

    const isShop = resultType === 'shop';

    const event = {
      event_type: 'search_click',
      search_query: searchQuery,
      result_type: resultType,
      position_in_results: position,
      item_id: isShop ? item.shop_id : item.product_id,
      item_name: isShop ? item.shop_name : item.product_name,
      shop_id: isShop ? item.shop_id : item.product_shop_id,
      shop_name: isShop ? item.shop_name : null,
      product_id: isShop ? null : item.product_id,
      product_name: isShop ? null : item.product_name,
      user_id: userInfo.user_id,
      user_name: userInfo.user_name,
      device_id: deviceId,
      platform: Platform.OS,
      timestamp: now.toISOString(),
    };

    console.log('✅ [Firebase Analytics] search_click event logged:', {
      type: resultType,
      itemName: event.item_name,
      position,
      query: searchQuery,
    });
    console.log('[Search] search_click FULL EVENT:', event);
    await analytics().logEvent('search_click', cleanEvent(event));
  } catch (error) {
    console.error('❌ [Firebase Analytics] Error logging search click:', error);
  }
};

export const logSearchSkippedItemsEvent = async (
  displayedItems,
  clickedItemIds,
  searchQuery,
) => {
  try {
    const deviceId = await getDeviceId();
    const now = new Date();
    const userInfo = getUserInfo();

    // Filter out clicked items to get skipped items
    const skippedItems = displayedItems.filter(item => {
      const itemId = item.type === 'shop' ? item.shop_id : item.product_id;
      return !clickedItemIds.includes(itemId);
    });

    if (skippedItems.length === 0) {
      console.log(
        '⚪ [Firebase Analytics] No skipped items to log (all items were clicked!)',
      );
      return;
    }

    const event = {
      event_type: 'search_skipped_items',
      search_query: searchQuery,
      skipped_count: skippedItems.length,
      skipped_shops_count: skippedItems.filter(i => i.type === 'shop').length,
      skipped_products_count: skippedItems.filter(i => i.type !== 'shop')
        .length,
      skipped_items: JSON.stringify(
        skippedItems.map((item, index) => ({
          item_id: item.type === 'shop' ? item.shop_id : item.product_id,
          item_type: item.type || 'product',
          position: index,
        })),
      ),
      user_id: userInfo.user_id,
      user_name: userInfo.user_name,
      device_id: deviceId,
      platform: Platform.OS,
      timestamp: now.toISOString(),
    };

    console.log('✅ [Firebase Analytics] search_skipped_items event logged:', {
      query: searchQuery,
      skipped: skippedItems.length,
      skippedShops: event.skipped_shops_count,
      skippedProducts: event.skipped_products_count,
    });
    console.log('[Search] search_skipped_items FULL EVENT:', event);
    await analytics().logEvent('search_skipped_items', cleanEvent(event));
  } catch (error) {
    console.error(
      '❌ [Firebase Analytics] Error logging skipped items:',
      error,
    );
  }
};

export const logSearchTabChangeEvent = async (
  searchQuery,
  fromTab,
  toTab,
  itemCounts,
) => {
  try {
    const deviceId = await getDeviceId();
    const now = new Date();
    const userInfo = getUserInfo();

    const event = {
      event_type: 'search_tab_change',
      search_query: searchQuery,
      from_tab: fromTab,
      to_tab: toTab,
      all_count: itemCounts.all || 0,
      products_count: itemCounts.products || 0,
      shops_count: itemCounts.shops || 0,
      user_id: userInfo.user_id,
      user_name: userInfo.user_name,
      device_id: deviceId,
      platform: Platform.OS,
      timestamp: now.toISOString(),
    };

    console.log('✅ [Firebase Analytics] search_tab_change event logged:', {
      query: searchQuery,
      fromTab,
      toTab,
      counts: itemCounts,
    });
    console.log('[Search] search_tab_change FULL EVENT:', event);
    await analytics().logEvent('search_tab_change', cleanEvent(event));
  } catch (error) {
    console.error('❌ [Firebase Analytics] Error logging tab change:', error);
  }
};

export const logSearchFilterChangeEvent = async (
  searchQuery,
  filterType,
  filterValue,
  previousValue = '',
) => {
  try {
    const deviceId = await getDeviceId();
    const now = new Date();
    const userInfo = getUserInfo();

    const event = {
      event_type: 'search_filter_change',
      search_query: searchQuery,
      filter_type: filterType,
      filter_value: filterValue,
      previous_value: previousValue,
      user_id: userInfo.user_id,
      user_name: userInfo.user_name,
      device_id: deviceId,
      platform: Platform.OS,
      timestamp: now.toISOString(),
    };

    console.log('✅ [Firebase Analytics] search_filter_change event logged:', {
      query: searchQuery,
      filterType,
      filterValue,
      previousValue,
    });
    console.log('[Search] search_filter_change FULL EVENT:', event);
    await analytics().logEvent('search_filter_change', cleanEvent(event));
  } catch (error) {
    console.error(
      '❌ [Firebase Analytics] Error logging filter change:',
      error,
    );
  }
};

/**
 * Helper function to get user info with proper fallbacks
 * Always returns user_id as a string for consistency across all events
 */
const getUserInfo = () => {
  const {fetch_user_detail} = getStoreState('auth');
  const userId = fetch_user_detail?.id ?? fetch_user_detail?.user_id ?? 0;
  const firstName = fetch_user_detail?.firstname || '';
  const lastName = fetch_user_detail?.lastname || '';
  const fullName = `${firstName} ${lastName}`.trim();
  const userName = fullName || 'Guest';
  return {
    user_id: String(userId),
    user_name: userName,
  };
};

export const logHomeDealClickEvent = async (dealItem, position) => {
  try {
    const deviceId = await getDeviceId();
    const now = new Date();
    const userInfo = getUserInfo();

    const event = {
      event_type: 'home_deal_click',
      deal_id: dealItem.trending_id || dealItem.id,
      deal_banner_url: dealItem.trending_banner_url || '',
      position_in_list: position,
      user_id: userInfo.user_id,
      user_name: userInfo.user_name,
      device_id: deviceId,
      platform: Platform.OS,
      timestamp: now.toISOString(),
    };

    console.log('✅ [Firebase Analytics] home_deal_click event logged:', {
      dealName: event.deal_name,
      position,
      user: event.user_name,
    });
    console.log('[Home] home_deal_click FULL EVENT:', event);

    await analytics().logEvent('home_deal_click', cleanEvent(event));
    console.log(
      '✨ [HOME ANALYTICS] home_deal_click sent to Firebase successfully',
    );
  } catch (error) {
    console.error('❌ [Firebase Analytics] Error logging deal click:', error);
  }
};

/**
 * Logs when a recently viewed item is clicked
 */
export const logHomeRecentViewedClickEvent = async (item, position) => {
  try {
    console.log('🔥 [HOME ANALYTICS] Triggering: home_recent_viewed_click');

    const deviceId = await getDeviceId();
    const now = new Date();
    const userInfo = getUserInfo();

    const isShop = !!item.shop_id && !item.product_id;

    const event = {
      event_type: 'home_recent_viewed_click',
      item_type: isShop ? 'shop' : 'product',
      item_id: isShop ? item.shop_id : item.product_id,
      shop_id: isShop ? item.shop_id : item.product_shop_id,
      product_id: isShop ? null : item.product_id,
      position_in_list: position,
      user_id: userInfo.user_id,
      user_name: userInfo.user_name,
      device_id: deviceId,
      platform: Platform.OS,
      timestamp: now.toISOString(),
    };

    console.log(
      '✅ [Firebase Analytics] home_recent_viewed_click event logged:',
      {
        type: event.item_type,
        itemName: event.item_name,
        position,
        user: event.user_name,
      },
    );
    console.log('[Home] home_recent_viewed_click FULL EVENT:', event);

    await analytics().logEvent('home_recent_viewed_click', cleanEvent(event));
    console.log(
      '✨ [HOME ANALYTICS] home_recent_viewed_click sent to Firebase successfully',
    );
  } catch (error) {
    console.error(
      '❌ [Firebase Analytics] Error logging recent viewed click:',
      error,
    );
  }
};

/**
 * Logs when a shop tile is clicked (brand navigation)
 */
export const logHomeShopTileClickEvent = async (shopItem, tilePosition) => {
  try {
    console.log('🔥 [HOME ANALYTICS] Triggering: home_shop_tile_click');

    const deviceId = await getDeviceId();
    const now = new Date();
    const userInfo = getUserInfo();

    const event = {
      event_type: 'home_shop_tile_click',
      shop_id: shopItem.shop_id,
      shop_tile_type: shopItem.shop_tile_type,
      tile_position: tilePosition,
      user_id: userInfo.user_id,
      user_name: userInfo.user_name,
      device_id: deviceId,
      platform: Platform.OS,
      timestamp: now.toISOString(),
    };

    console.log('✅ [Firebase Analytics] home_shop_tile_click event logged:', {
      shopName: event.shop_name,
      tileType: event.shop_tile_type,
      position: tilePosition,
      user: event.user_name,
    });
    console.log('[Home] home_shop_tile_click FULL EVENT:', event);

    await analytics().logEvent('home_shop_tile_click', cleanEvent(event));
    console.log(
      '✨ [HOME ANALYTICS] home_shop_tile_click sent to Firebase successfully',
    );
  } catch (error) {
    console.error(
      '❌ [Firebase Analytics] Error logging shop tile click:',
      error,
    );
  }
};

/**
 * Logs when a product within a shop tile is clicked
 */
export const logHomeProductClickEvent = async (
  productItem,
  shopItem,
  productPosition,
  tilePosition,
) => {
  try {
    console.log('🔥 [HOME ANALYTICS] Triggering: home_product_click');

    const deviceId = await getDeviceId();
    const now = new Date();
    const userInfo = getUserInfo();

    const event = {
      event_type: 'home_product_click',
      product_id: productItem.product_id,
      product_position_in_tile: productPosition,
      shop_id: shopItem.shop_id,
      shop_tile_type: shopItem.shop_tile_type,
      tile_position: tilePosition,
      user_id: userInfo.user_id,
      user_name: userInfo.user_name,
      device_id: deviceId,
      platform: Platform.OS,
      timestamp: now.toISOString(),
    };

    console.log('✅ [Firebase Analytics] home_product_click event logged:', {
      productName: event.product_name,
      shopName: event.shop_name,
      productPos: productPosition,
      tilePos: tilePosition,
      user: event.user_name,
    });
    console.log('[Home] home_product_click FULL EVENT:', event);

    await analytics().logEvent('home_product_click', cleanEvent(event));
    console.log(
      '✨ [HOME ANALYTICS] home_product_click sent to Firebase successfully',
    );
  } catch (error) {
    console.error(
      '❌ [Firebase Analytics] Error logging product click:',
      error,
    );
  }
};

/**
 * Logs shop tile views (impression tracking)
 * Called when a shop tile becomes visible in viewport
 */
export const logHomeShopTileViewEvent = async (
  shopItem,
  tilePosition,
  viewDuration = 0,
) => {
  try {
    console.log('🔥 [HOME ANALYTICS] Triggering: home_shop_tile_view');

    const deviceId = await getDeviceId();
    const now = new Date();
    const userInfo = getUserInfo();

    const event = {
      event_type: 'home_shop_tile_view',
      shop_id: shopItem.shop_id,
      shop_tile_type: shopItem.shop_tile_type,
      tile_position: tilePosition,
      view_duration_seconds: Number(viewDuration.toFixed(2)),
      products_count: shopItem.products?.length || 0,
      user_id: userInfo.user_id,
      user_name: userInfo.user_name,
      device_id: deviceId,
      platform: Platform.OS,
      timestamp: now.toISOString(),
    };

    console.log('✅ [Firebase Analytics] home_shop_tile_view event logged:', {
      shopName: event.shop_name,
      tileType: event.shop_tile_type,
      position: tilePosition,
      duration: viewDuration.toFixed(2) + 's',
      productsCount: event.products_count,
      user: event.user_name,
    });
    console.log('[Home] home_shop_tile_view FULL EVENT:', event);

    await analytics().logEvent('home_shop_tile_view', cleanEvent(event));
    console.log(
      '✨ [HOME ANALYTICS] home_shop_tile_view sent to Firebase successfully',
    );
  } catch (error) {
    console.error(
      '❌ [Firebase Analytics] Error logging shop tile view:',
      error,
    );
  }
};

/**
 * Logs product views within shop tiles (impression tracking)
 */
export const logHomeProductViewEvent = async (
  productItem,
  shopItem,
  productPosition,
  tilePosition,
  viewDuration = 0,
) => {
  try {
    console.log('🔥 [HOME ANALYTICS] Triggering: home_product_view');

    const deviceId = await getDeviceId();
    const now = new Date();
    const userInfo = getUserInfo();

    const event = {
      event_type: 'home_product_view',
      product_id: productItem.product_id,
      product_price:
        productItem.product_price || productItem.product_selling_price,
      product_position_in_tile: productPosition,
      shop_id: shopItem.shop_id,
      shop_tile_type: shopItem.shop_tile_type,
      tile_position: tilePosition,
      view_duration_seconds: Number(viewDuration.toFixed(2)),
      user_id: userInfo.user_id,
      user_name: userInfo.user_name,
      device_id: deviceId,
      platform: Platform.OS,
      timestamp: now.toISOString(),
    };

    console.log('✅ [Firebase Analytics] home_product_view event logged:', {
      productName: event.product_name,
      shopName: event.shop_name,
      productPos: productPosition,
      tilePos: tilePosition,
      duration: viewDuration.toFixed(2) + 's',
      user: event.user_name,
    });
    console.log('[Home] home_product_view FULL EVENT:', event);

    await analytics().logEvent('home_product_view', cleanEvent(event));
    console.log(
      '✨ [HOME ANALYTICS] home_product_view sent to Firebase successfully',
    );
  } catch (error) {
    console.error('❌ [Firebase Analytics] Error logging product view:', error);
  }
};

/**
 * Logs skipped/unviewed items on home page
 * Should be called when user leaves home or after significant scroll
 */
export const logHomeSkippedItemsEvent = async (
  displayedShops,
  viewedShopIds,
  clickedShopIds,
) => {
  try {
    console.log('🔥 [HOME ANALYTICS] Triggering: home_skipped_shops');

    const deviceId = await getDeviceId();
    const now = new Date();
    const userInfo = getUserInfo();

    // Filter shops that were displayed but neither viewed nor clicked
    const skippedShops = displayedShops.filter(shop => {
      const shopId = shop.shop_id;
      return (
        !viewedShopIds.includes(shopId) && !clickedShopIds.includes(shopId)
      );
    });

    if (skippedShops.length === 0) {
      console.log(
        '⚪ [Firebase Analytics] No skipped shops to log (all shops were viewed or clicked!)',
      );
      return;
    }

    // Create array of skipped shop IDs for easy reference
    const skippedShopIds = skippedShops.map(shop => shop.shop_id);

    const event = {
      event_type: 'home_skipped_shops',
      skipped_count: skippedShops.length,
      skipped_shop_ids: JSON.stringify(skippedShopIds), // Array of IDs for easy querying
      skipped_shops: JSON.stringify(
        skippedShops.map((shop, index) => ({
          shop_id: shop.shop_id,
          tile_type: shop.shop_tile_type,
          position: index,
        })),
      ),
      total_displayed: displayedShops.length,
      total_viewed: viewedShopIds.length,
      total_clicked: clickedShopIds.length,
      user_id: userInfo.user_id,
      user_name: userInfo.user_name,
      device_id: deviceId,
      platform: Platform.OS,
      timestamp: now.toISOString(),
    };

    console.log('✅ [Firebase Analytics] home_skipped_shops event logged:', {
      skipped: skippedShops.length,
      skippedShopIds: skippedShopIds,
      displayed: displayedShops.length,
      viewed: viewedShopIds.length,
      clicked: clickedShopIds.length,
      user: event.user_name,
    });
    console.log('[Home] home_skipped_shops FULL EVENT:', event);

    await analytics().logEvent('home_skipped_shops', cleanEvent(event));
    console.log(
      '✨ [HOME ANALYTICS] home_skipped_shops sent to Firebase successfully',
    );
  } catch (error) {
    console.error(
      '❌ [Firebase Analytics] Error logging skipped shops:',
      error,
    );
  }
};

/**
 * Logs skipped products within shop tiles
 */
export const logHomeSkippedProductsEvent = async (
  shopItem,
  tilePosition,
  displayedProducts,
  viewedProductIds,
  clickedProductIds,
) => {
  try {
    console.log('🔥 [HOME ANALYTICS] Triggering: home_skipped_products');

    const deviceId = await getDeviceId();
    const now = new Date();
    const userInfo = getUserInfo();

    // Filter products that were displayed but neither viewed nor clicked
    const skippedProducts = displayedProducts.filter(product => {
      const productId = product.product_id;
      return (
        !viewedProductIds.includes(productId) &&
        !clickedProductIds.includes(productId)
      );
    });

    if (skippedProducts.length === 0) {
      console.log(
        `⚪ [Firebase Analytics] No skipped products in shop ${shopItem.shop_name}`,
      );
      return;
    }

    // Create array of skipped product IDs for easy reference
    const skippedProductIds = skippedProducts.map(
      product => product.product_id,
    );

    const event = {
      event_type: 'home_skipped_products',
      shop_id: shopItem.shop_id,
      shop_tile_type: shopItem.shop_tile_type,
      tile_position: tilePosition,
      skipped_count: skippedProducts.length,
      skipped_product_ids: JSON.stringify(skippedProductIds), // Array of IDs for easy querying
      skipped_products: JSON.stringify(
        skippedProducts.map((product, index) => ({
          product_id: product.product_id,
          position_in_tile: index,
        })),
      ),
      total_products: displayedProducts.length,
      total_viewed: viewedProductIds.length,
      total_clicked: clickedProductIds.length,
      user_id: userInfo.user_id,
      user_name: userInfo.user_name,
      device_id: deviceId,
      platform: Platform.OS,
      timestamp: now.toISOString(),
    };

    console.log('✅ [Firebase Analytics] home_skipped_products event logged:', {
      shopName: event.shop_name,
      skipped: skippedProducts.length,
      skippedProductIds: skippedProductIds,
      total: displayedProducts.length,
      viewed: viewedProductIds.length,
      clicked: clickedProductIds.length,
      user: event.user_name,
    });
    console.log('[Home] home_skipped_products FULL EVENT:', event);

    await analytics().logEvent('home_skipped_products', cleanEvent(event));
    console.log(
      '✨ [HOME ANALYTICS] home_skipped_products sent to Firebase successfully',
    );
  } catch (error) {
    console.error(
      '❌ [Firebase Analytics] Error logging skipped products:',
      error,
    );
  }
};

export const logSearchNavigationEvent = async (
  searchQuery,
  fromScreen,
  toScreen,
  resultCounts = {},
) => {
  try {
    const deviceId = await getDeviceId();
    const now = new Date();
    const userInfo = getUserInfo();

    const event = {
      event_type: 'search_navigation',
      search_query: searchQuery,
      from_screen: fromScreen,
      to_screen: toScreen,
      total_results: resultCounts.total || 0,
      products_count: resultCounts.products || 0,
      shops_count: resultCounts.shops || 0,
      user_id: userInfo.user_id,
      user_name: userInfo.user_name,
      device_id: deviceId,
      platform: Platform.OS,
      timestamp: now.toISOString(),
    };

    console.log('✅ [Firebase Analytics] search_navigation event logged:', {
      query: searchQuery,
      fromScreen,
      toScreen,
      resultCounts,
    });
    console.log('[Search] search_navigation FULL EVENT:', event);
    await analytics().logEvent('search_navigation', cleanEvent(event));
  } catch (error) {
    console.error(
      '❌ [Firebase Analytics] Error logging search navigation:',
      error,
    );
  }
};

/**
 * Logs when the user opens/launches the app
 * Tracks app open time and user information
 */
export const logAppOpenEvent = async () => {
  try {
    console.log('🔥 [APP ANALYTICS] Triggering: app_open');
    const deviceId = await getDeviceId();
    const now = new Date();
    const userInfo = getUserInfo();

    const event = {
      event_type: 'app_open',
      user_id: userInfo.user_id,
      user_name: userInfo.user_name,
      device_id: deviceId,
      platform: Platform.OS,
      timestamp: now.toISOString(),
      date: now.toLocaleDateString(),
      time: now.toLocaleTimeString(),
    };

    console.log('✅ [Firebase Analytics] app_open event logged:', {
      userId: userInfo.user_id,
      userName: userInfo.user_name,
      platform: Platform.OS,
      timestamp: now.toISOString(),
    });
    console.log('[App] app_open FULL EVENT:', event);
    await analytics().logEvent('app_open', cleanEvent(event));
    console.log('✨ [APP ANALYTICS] app_open sent to Firebase successfully');
  } catch (error) {
    console.error('❌ [Firebase Analytics] Error logging app open:', error);
  }
};

/**
 * Logs when a user views a reel
 * Tracks watch duration and engagement
 */
export const logReelViewEvent = async (
  reelData,
  watchDuration,
  totalDuration,
) => {
  try {
    console.log('🔥 [REEL ANALYTICS] Triggering: reel_view');

    const deviceId = await getDeviceId();
    const now = new Date();
    const userInfo = getUserInfo();

    const event = {
      event_type: 'reel_view',
      video_url_id: reelData.video_url_id,
      video_id: reelData.id,
      shop_id: reelData.shop_id,
      shop_name: reelData.shop_name,
      watch_duration_seconds: Number(watchDuration.toFixed(2)),
      total_duration_seconds: Number(totalDuration.toFixed(2)),
      completion_rate:
        totalDuration > 0
          ? Number(((watchDuration / totalDuration) * 100).toFixed(2))
          : 0,
      video_likes_count: reelData.video_likes_count || 0,
      video_views_count: reelData.video_views_count || 0,
      is_liked: reelData.isLiked || false,
      user_id: userInfo.user_id,
      user_name: userInfo.user_name,
      device_id: deviceId,
      platform: Platform.OS,
      timestamp: now.toISOString(),
    };

    console.log('✅ [Firebase Analytics] reel_view event logged:', {
      videoId: event.video_url_id,
      shopName: event.shop_name,
      watchDuration: watchDuration.toFixed(2) + 's',
      completionRate: event.completion_rate + '%',
      user: event.user_name,
    });
    console.log('[Reel] reel_view FULL EVENT:', event);

    await analytics().logEvent('reel_view', cleanEvent(event));
    console.log('✨ [REEL ANALYTICS] reel_view sent to Firebase successfully');
  } catch (error) {
    console.error('❌ [Firebase Analytics] Error logging reel view:', error);
  }
};

/**
 * Logs when a user clicks on a product within a reel
 * Tracks product interaction and click behavior
 */
export const logReelProductClickEvent = async (
  reelData,
  productData,
  clickOrder,
  productPosition,
  watchDurationBeforeClick,
) => {
  try {
    console.log('🔥 [REEL ANALYTICS] Triggering: reel_product_click');

    const deviceId = await getDeviceId();
    const now = new Date();
    const userInfo = getUserInfo();

    const event = {
      event_type: 'reel_product_click',
      video_url_id: reelData.video_url_id,
      video_id: reelData.id,
      shop_id: reelData.shop_id,
      shop_name: reelData.shop_name,
      product_id: productData.product_id,
      product_name: productData.product_name,
      product_price:
        productData.product_price || productData.product_selling_price,
      click_order: clickOrder,
      product_position: productPosition,
      watch_duration_before_click_seconds: Number(
        watchDurationBeforeClick.toFixed(2),
      ),
      user_id: userInfo.user_id,
      user_name: userInfo.user_name,
      device_id: deviceId,
      platform: Platform.OS,
      timestamp: now.toISOString(),
    };

    console.log('✅ [Firebase Analytics] reel_product_click event logged:', {
      videoId: event.video_url_id,
      productName: event.product_name,
      shopName: event.shop_name,
      clickOrder: clickOrder,
      position: productPosition,
      watchDuration: watchDurationBeforeClick.toFixed(2) + 's',
      user: event.user_name,
    });
    console.log('[Reel] reel_product_click FULL EVENT:', event);

    await analytics().logEvent('reel_product_click', cleanEvent(event));
    console.log(
      '✨ [REEL ANALYTICS] reel_product_click sent to Firebase successfully',
    );
  } catch (error) {
    console.error(
      '❌ [Firebase Analytics] Error logging reel product click:',
      error,
    );
  }
};

/**
 * Logs when a similar product (from same shop) is clicked on product detail page
 */
export const logProductDetailSimilarProductClickEvent = async (
  productData,
  currentProductId,
  position,
  shopData,
) => {
  try {
    console.log(
      '🔥 [PRODUCT DETAIL ANALYTICS] Triggering: product_detail_similar_click',
    );

    const deviceId = await getDeviceId();
    const now = new Date();
    const userInfo = getUserInfo();

    const event = {
      event_type: 'product_detail_similar_click',
      current_product_id: currentProductId,
      clicked_product_id: productData.product_id,
      clicked_product_name: productData.product_name,
      clicked_product_price:
        productData.product_price || productData.product_selling_price,
      position_in_list: position,
      shop_id: shopData.shop_id,
      shop_name: shopData.shop_name,
      user_id: userInfo.user_id,
      user_name: userInfo.user_name,
      device_id: deviceId,
      platform: Platform.OS,
      timestamp: now.toISOString(),
    };

    console.log(
      '✅ [Firebase Analytics] product_detail_similar_click event logged:',
      {
        currentProduct: currentProductId,
        clickedProduct: productData.product_name,
        position,
        user: event.user_name,
      },
    );
    console.log(
      '[ProductDetail] product_detail_similar_click FULL EVENT:',
      event,
    );

    await analytics().logEvent(
      'product_detail_similar_click',
      cleanEvent(event),
    );
    console.log(
      '✨ [PRODUCT DETAIL ANALYTICS] product_detail_similar_click sent to Firebase successfully',
    );
  } catch (error) {
    console.error(
      '❌ [Firebase Analytics] Error logging similar product click:',
      error,
    );
  }
};

/**
 * Logs when a related product is clicked on product detail page
 */
export const logProductDetailRelatedProductClickEvent = async (
  productData,
  currentProductId,
  position,
  currentShopData,
) => {
  try {
    console.log(
      '🔥 [PRODUCT DETAIL ANALYTICS] Triggering: product_detail_related_click',
    );

    const deviceId = await getDeviceId();
    const now = new Date();
    const userInfo = getUserInfo();

    const event = {
      event_type: 'product_detail_related_click',
      current_product_id: currentProductId,
      current_shop_id: currentShopData.shop_id,
      current_shop_name: currentShopData.shop_name,
      clicked_product_id: productData.product_id,
      clicked_product_name: productData.product_name,
      clicked_product_price:
        productData.product_price || productData.product_selling_price,
      clicked_product_shop_id: productData.product_shop_id,
      position_in_list: position,
      user_id: userInfo.user_id,
      user_name: userInfo.user_name,
      device_id: deviceId,
      platform: Platform.OS,
      timestamp: now.toISOString(),
    };

    console.log(
      '✅ [Firebase Analytics] product_detail_related_click event logged:',
      {
        currentProduct: currentProductId,
        clickedProduct: productData.product_name,
        position,
        user: event.user_name,
      },
    );
    console.log(
      '[ProductDetail] product_detail_related_click FULL EVENT:',
      event,
    );

    await analytics().logEvent(
      'product_detail_related_click',
      cleanEvent(event),
    );
    console.log(
      '✨ [PRODUCT DETAIL ANALYTICS] product_detail_related_click sent to Firebase successfully',
    );
  } catch (error) {
    console.error(
      '❌ [Firebase Analytics] Error logging related product click:',
      error,
    );
  }
};

/**
 * Logs user actions on product detail page (add to cart, buy now, quantity changes)
 */
export const logProductDetailActionEvent = async (
  actionType,
  productData,
  variantData,
  quantity,
  shopData,
) => {
  try {
    console.log(
      '🔥 [PRODUCT DETAIL ANALYTICS] Triggering: product_detail_action',
    );

    const deviceId = await getDeviceId();
    const now = new Date();
    const userInfo = getUserInfo();

    const event = {
      event_type: 'product_detail_action',
      action_type: actionType,
      product_id: productData.product_id,
      product_name: productData.product_name,
      variant_id: variantData?.variant_id,
      variant_name: variantData?.variant_name,
      variant_price: variantData?.variant_price,
      variant_discounted_price: variantData?.variant_discounted_price,
      quantity: quantity,
      shop_id: shopData.shop_id,
      shop_name: shopData.shop_name,
      shop_currency: shopData.shop_currency,
      user_id: userInfo.user_id,
      user_name: userInfo.user_name,
      device_id: deviceId,
      platform: Platform.OS,
      timestamp: now.toISOString(),
    };

    console.log('✅ [Firebase Analytics] product_detail_action event logged:', {
      action: actionType,
      product: productData.product_name,
      variant: variantData?.variant_name,
      quantity,
      user: event.user_name,
    });
    console.log('[ProductDetail] product_detail_action FULL EVENT:', event);

    await analytics().logEvent('product_detail_action', cleanEvent(event));
    console.log(
      '✨ [PRODUCT DETAIL ANALYTICS] product_detail_action sent to Firebase successfully',
    );
  } catch (error) {
    console.error(
      '❌ [Firebase Analytics] Error logging product detail action:',
      error,
    );
  }
};

/**
 * Logs skipped products on product detail page
 * Should be called when user leaves the page
 */
export const logProductDetailSkippedProductsEvent = async (
  currentProductId,
  shopData,
  displayedSimilarProducts,
  clickedSimilarProductIds,
  displayedRelatedProducts,
  clickedRelatedProductIds,
) => {
  try {
    console.log(
      '🔥 [PRODUCT DETAIL ANALYTICS] Triggering: product_detail_skipped_products',
    );

    const deviceId = await getDeviceId();
    const now = new Date();
    const userInfo = getUserInfo();

    // Filter similar products that were displayed but not clicked
    const skippedSimilarProducts = displayedSimilarProducts.filter(product => {
      return !clickedSimilarProductIds.includes(product.product_id);
    });

    // Filter related products that were displayed but not clicked
    const skippedRelatedProducts = displayedRelatedProducts.filter(product => {
      return !clickedRelatedProductIds.includes(product.product_id);
    });

    const totalSkipped =
      skippedSimilarProducts.length + skippedRelatedProducts.length;

    if (totalSkipped === 0) {
      console.log('⚪ [Firebase Analytics] No skipped products to log');
      return;
    }

    const event = {
      event_type: 'product_detail_skipped_products',
      current_product_id: currentProductId,
      shop_id: shopData.shop_id,
      shop_name: shopData.shop_name,
      skipped_similar_count: skippedSimilarProducts.length,
      skipped_related_count: skippedRelatedProducts.length,
      total_skipped_count: totalSkipped,
      skipped_similar_product_ids: JSON.stringify(
        skippedSimilarProducts.map(p => p.product_id),
      ),
      skipped_related_product_ids: JSON.stringify(
        skippedRelatedProducts.map(p => p.product_id),
      ),
      total_displayed_similar: displayedSimilarProducts.length,
      total_clicked_similar: clickedSimilarProductIds.length,
      total_displayed_related: displayedRelatedProducts.length,
      total_clicked_related: clickedRelatedProductIds.length,
      user_id: userInfo.user_id,
      user_name: userInfo.user_name,
      device_id: deviceId,
      platform: Platform.OS,
      timestamp: now.toISOString(),
    };

    console.log(
      '✅ [Firebase Analytics] product_detail_skipped_products event logged:',
      {
        currentProduct: currentProductId,
        skippedSimilar: skippedSimilarProducts.length,
        skippedRelated: skippedRelatedProducts.length,
        totalSkipped,
        user: event.user_name,
      },
    );
    console.log(
      '[ProductDetail] product_detail_skipped_products FULL EVENT:',
      event,
    );

    await analytics().logEvent(
      'product_detail_skipped_products',
      cleanEvent(event),
    );
    console.log(
      '✨ [PRODUCT DETAIL ANALYTICS] product_detail_skipped_products sent to Firebase successfully',
    );
  } catch (error) {
    console.error(
      '❌ [Firebase Analytics] Error logging skipped products:',
      error,
    );
  }
};

/**
 * Logs when a user clicks on a product in the brand/shop page
 */
export const logBrandProductClickEvent = async (
  productData,
  shopData,
  position,
  collectionId = null,
  collectionName = null,
) => {
  console.log('🚀 [DEBUG] logBrandProductClickEvent FUNCTION CALLED');
  console.log('🚀 [DEBUG] Parameters received:', {
    productData: productData ? 'exists' : 'null',
    shopData: shopData ? 'exists' : 'null',
    position,
    collectionId,
    collectionName,
  });

  try {
    console.log('🔥 [BRAND ANALYTICS] Triggering: brand_product_click');

    const deviceId = await getDeviceId();
    const now = new Date();
    const userInfo = getUserInfo();

    const event = {
      event_type: 'brand_product_click',
      product_id: productData.product_id,
      product_name: productData.product_name,
      product_price:
        productData.product_price || productData.product_selling_price,
      position_in_list: position,
      shop_id: shopData.shop_id || shopData.shop_shopify_id,
      shop_name: shopData.shop_name,
      collection_id: collectionId,
      collection_name: collectionName,
      user_id: userInfo.user_id,
      user_name: userInfo.user_name,
      device_id: deviceId,
      platform: Platform.OS,
      timestamp: now.toISOString(),
    };

    console.log('✅ [Firebase Analytics] brand_product_click event logged:', {
      product: productData.product_name,
      shop: shopData.shop_name,
      collection: collectionName || 'All',
      position,
      user: event.user_name,
    });
    console.log('[Brand] brand_product_click FULL EVENT:', event);
    console.log(
      '📤 [Firebase] Sending brand_product_click with data:',
      JSON.stringify(cleanEvent(event), null, 2),
    );

    await analytics().logEvent('brand_product_click', cleanEvent(event));
    console.log(
      '✨ [BRAND ANALYTICS] brand_product_click sent to Firebase successfully',
    );
  } catch (error) {
    console.error(
      '❌ [Firebase Analytics] Error logging brand product click:',
      error,
    );
    console.error('❌ [DEBUG] Error details:', {
      message: error?.message,
      stack: error?.stack,
      name: error?.name,
    });
  }
};

/**
 * Logs when a user changes collection/filter on brand page
 */
export const logBrandCollectionChangeEvent = async (
  shopData,
  fromCollection,
  toCollection,
  productsCount,
  clickedProductIds = [],
) => {
  try {
    console.log('🔥 [BRAND ANALYTICS] Triggering: brand_collection_change');

    const deviceId = await getDeviceId();
    const now = new Date();
    const userInfo = getUserInfo();

    const event = {
      event_type: 'brand_collection_change',
      shop_id: shopData.shop_id || shopData.shop_shopify_id,
      shop_name: shopData.shop_name,
      from_collection_id: fromCollection?.id || null,
      from_collection_name: fromCollection?.name || 'All',
      to_collection_id: toCollection?.id,
      to_collection_name: toCollection?.name,
      products_count: productsCount,
      clicked_products_count: clickedProductIds.length,
      clicked_product_ids: JSON.stringify(clickedProductIds),
      user_id: userInfo.user_id,
      user_name: userInfo.user_name,
      device_id: deviceId,
      platform: Platform.OS,
      timestamp: now.toISOString(),
    };

    console.log(
      '✅ [Firebase Analytics] brand_collection_change event logged:',
      {
        shop: shopData.shop_name,
        from: fromCollection?.name || 'All',
        to: toCollection?.name,
        productsCount,
        clickedProductsCount: clickedProductIds.length,
        user: event.user_name,
      },
    );
    console.log('[Brand] brand_collection_change FULL EVENT:', event);
    console.log(
      '📤 [Firebase] Sending brand_collection_change with data:',
      JSON.stringify(cleanEvent(event), null, 2),
    );

    await analytics().logEvent('brand_collection_change', cleanEvent(event));
    console.log(
      '✨ [BRAND ANALYTICS] brand_collection_change sent to Firebase successfully',
    );
  } catch (error) {
    console.error(
      '❌ [Firebase Analytics] Error logging collection change:',
      error,
    );
  }
};

/**
 * Logs when a user follows/unfollows a brand
 */
export const logBrandFollowActionEvent = async (
  shopData,
  actionType,
  isFromBrandPage = true,
) => {
  try {
    console.log('🔥 [BRAND ANALYTICS] Triggering: brand_follow_action');

    const deviceId = await getDeviceId();
    const now = new Date();
    const userInfo = getUserInfo();

    const event = {
      event_type: 'brand_follow_action',
      action_type: actionType, // 'follow' or 'unfollow'
      shop_id: shopData.shop_id ,
      shop_name: shopData.shop_name,
      is_from_brand_page: isFromBrandPage,
      user_id: userInfo.user_id,
      user_name: userInfo.user_name,
      device_id: deviceId,
      platform: Platform.OS,
      timestamp: now.toISOString(),
    };

    console.log('✅ [Firebase Analytics] brand_follow_action event logged:', {
      action: actionType,
      shop: shopData.shop_name,
      fromBrandPage: isFromBrandPage,
      user: event.user_name,
    });
    console.log('[Brand] brand_follow_action FULL EVENT:', event);
    console.log(
      '📤 [Firebase] Sending brand_follow_action with data:',
      JSON.stringify(cleanEvent(event), null, 2),
    );

    await analytics().logEvent('brand_follow_action', cleanEvent(event));
    console.log(
      '✨ [BRAND ANALYTICS] brand_follow_action sent to Firebase successfully',
    );
  } catch (error) {
    console.error(
      '❌ [Firebase Analytics] Error logging brand follow action:',
      error,
    );
  }
};

/**
 * Logs when a user clicks on reels navigation from brand page
 */
export const logBrandReelsClickEvent = async (shopData, reelsCount) => {
  try {
    console.log('🔥 [BRAND ANALYTICS] Triggering: brand_reels_click');

    const deviceId = await getDeviceId();
    const now = new Date();
    const userInfo = getUserInfo();

    const event = {
      event_type: 'brand_reels_click',
      shop_id: shopData.shop_id || shopData.shop_shopify_id,
      shop_name: shopData.shop_name,
      reels_count: reelsCount,
      user_id: userInfo.user_id,
      user_name: userInfo.user_name,
      device_id: deviceId,
      platform: Platform.OS,
      timestamp: now.toISOString(),
    };

    console.log('✅ [Firebase Analytics] brand_reels_click event logged:', {
      shop: shopData.shop_name,
      reelsCount,
      user: event.user_name,
    });
    console.log('[Brand] brand_reels_click FULL EVENT:', event);
    console.log(
      '📤 [Firebase] Sending brand_reels_click with data:',
      JSON.stringify(cleanEvent(event), null, 2),
    );

    await analytics().logEvent('brand_reels_click', cleanEvent(event));
    console.log(
      '✨ [BRAND ANALYTICS] brand_reels_click sent to Firebase successfully',
    );
  } catch (error) {
    console.error(
      '❌ [Firebase Analytics] Error logging brand reels click:',
      error,
    );
  }
};

/**
 * Logs when a user clicks on search in brand page
 */
export const logBrandSearchClickEvent = async (shopData, productsCount) => {
  try {
    console.log('🔥 [BRAND ANALYTICS] Triggering: brand_search_click');

    const deviceId = await getDeviceId();
    const now = new Date();
    const userInfo = getUserInfo();

    const event = {
      event_type: 'brand_search_click',
      shop_id: shopData.shop_id || shopData.shop_shopify_id,
      shop_name: shopData.shop_name,
      products_count: productsCount,
      user_id: userInfo.user_id,
      user_name: userInfo.user_name,
      device_id: deviceId,
      platform: Platform.OS,
      timestamp: now.toISOString(),
    };

    console.log('✅ [Firebase Analytics] brand_search_click event logged:', {
      shop: shopData.shop_name,
      productsCount,
      user: event.user_name,
    });
    console.log('[Brand] brand_search_click FULL EVENT:', event);
    console.log(
      '📤 [Firebase] Sending brand_search_click with data:',
      JSON.stringify(cleanEvent(event), null, 2),
    );

    await analytics().logEvent('brand_search_click', cleanEvent(event));
    console.log(
      '✨ [BRAND ANALYTICS] brand_search_click sent to Firebase successfully',
    );
  } catch (error) {
    console.error(
      '❌ [Firebase Analytics] Error logging brand search click:',
      error,
    );
  }
};

/**
 * Logs product impressions (views) on brand page
 */
export const logBrandProductViewEvent = async (
  productData,
  shopData,
  position,
  viewDuration,
  collectionId = null,
  collectionName = null,
) => {
  try {
    console.log('🔥 [BRAND ANALYTICS] Triggering: brand_product_view');

    const deviceId = await getDeviceId();
    const now = new Date();
    const userInfo = getUserInfo();

    const event = {
      event_type: 'brand_product_view',
      product_id: productData.product_id,
      product_name: productData.product_name,
      product_price:
        productData.product_price || productData.product_selling_price,
      position_in_list: position,
      view_duration_seconds: Number(viewDuration.toFixed(2)),
      shop_id: shopData.shop_id || shopData.shop_shopify_id,
      shop_name: shopData.shop_name,
      collection_id: collectionId,
      collection_name: collectionName,
      user_id: userInfo.user_id,
      user_name: userInfo.user_name,
      device_id: deviceId,
      platform: Platform.OS,
      timestamp: now.toISOString(),
    };

    console.log('✅ [Firebase Analytics] brand_product_view event logged:', {
      product: productData.product_name,
      shop: shopData.shop_name,
      collection: collectionName || 'All',
      position,
      duration: viewDuration.toFixed(2) + 's',
      user: event.user_name,
    });
    console.log('[Brand] brand_product_view FULL EVENT:', event);
    console.log(
      '📤 [Firebase] Sending brand_product_view with data:',
      JSON.stringify(cleanEvent(event), null, 2),
    );

    await analytics().logEvent('brand_product_view', cleanEvent(event));
    console.log(
      '✨ [BRAND ANALYTICS] brand_product_view sent to Firebase successfully',
    );
  } catch (error) {
    console.error(
      '❌ [Firebase Analytics] Error logging brand product view:',
      error,
    );
  }
};

/**
 * Logs skipped products on brand page
 * Should be called when user leaves the page or changes collection
 */
export const logBrandSkippedProductsEvent = async (
  shopData,
  displayedProducts,
  viewedProductIds,
  clickedProductIds,
  collectionId = null,
  collectionName = null,
) => {
  try {
    console.log('🔥 [BRAND ANALYTICS] Triggering: brand_skipped_products');

    const deviceId = await getDeviceId();
    const now = new Date();
    const userInfo = getUserInfo();

    // Filter products that were displayed but neither viewed nor clicked
    const skippedProducts = displayedProducts.filter(product => {
      const productId = product.product_id;
      return (
        !viewedProductIds.includes(productId) &&
        !clickedProductIds.includes(productId)
      );
    });

    if (skippedProducts.length === 0) {
      console.log(
        '⚪ [Firebase Analytics] No skipped products to log on brand page',
      );
      return;
    }

    const skippedProductIds = skippedProducts.map(
      product => product.product_id,
    );

    const event = {
      event_type: 'brand_skipped_products',
      shop_id: shopData.shop_id || shopData.shop_shopify_id,
      shop_name: shopData.shop_name,
      collection_id: collectionId,
      collection_name: collectionName || 'All',
      skipped_count: skippedProducts.length,
      skipped_product_ids: JSON.stringify(skippedProductIds),
      skipped_products: JSON.stringify(
        skippedProducts.map((product, index) => ({
          product_id: product.product_id,
          position: index,
        })),
      ),
      total_displayed: displayedProducts.length,
      total_viewed: viewedProductIds.length,
      total_clicked: clickedProductIds.length,
      user_id: userInfo.user_id,
      user_name: userInfo.user_name,
      device_id: deviceId,
      platform: Platform.OS,
      timestamp: now.toISOString(),
    };

    console.log(
      '✅ [Firebase Analytics] brand_skipped_products event logged:',
      {
        shop: shopData.shop_name,
        collection: collectionName || 'All',
        skipped: skippedProducts.length,
        displayed: displayedProducts.length,
        viewed: viewedProductIds.length,
        clicked: clickedProductIds.length,
        user: event.user_name,
      },
    );
    console.log('[Brand] brand_skipped_products FULL EVENT:', event);
    console.log(
      '📤 [Firebase] Sending brand_skipped_products with data:',
      JSON.stringify(cleanEvent(event), null, 2),
    );

    await analytics().logEvent('brand_skipped_products', cleanEvent(event));
    console.log(
      '✨ [BRAND ANALYTICS] brand_skipped_products sent to Firebase successfully',
    );
  } catch (error) {
    console.error(
      '❌ [Firebase Analytics] Error logging brand skipped products:',
      error,
    );
  }
};
