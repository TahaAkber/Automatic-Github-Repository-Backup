import {url} from '@utils/url/url';
import Toast from 'react-native-simple-toast';
import {store} from '../../redux/store/store';
import {navigate, push} from '../../utils/navigationRef/navigationRef';
import {ai_global_url, ai_secondary_url} from '../../utils/url/url';
import {Vibration} from 'react-native';
import {getStoreState} from '../../utils/helper/helper';
import {filtersData} from '../../constant/contstant';
import {_cartBottomSheet} from '../../redux/actions/common/common';
// import perf from '@react-native-firebase/perf';

export const showToast = message => {
  Toast.show(message, Toast.LONG);
};

export const handleNotificationPress = (notificationBanner, dispatch) => {
  try {
    const parseStr = notificationBanner?.data?.payload
      ? JSON.parse(notificationBanner?.data?.payload)
      : {};

    const jsonStringConverter =
      typeof parseStr === 'string' ? JSON.parse(parseStr) : parseStr;
    if (notificationBanner?.data?.screenName == 'Orders') {
      navigate('OrderDetail', {
        order_id: Number(jsonStringConverter?.orderId),
        tracking_id: jsonStringConverter?.trackingId
          ? Number(jsonStringConverter?.trackingId)
          : '',
      });
    } else if (notificationBanner?.data?.screenName == 'TrendingCollection') {
      navigate('TrendingCollection', {
        item: {
          trending_id: Number(jsonStringConverter?.trendingId),
          trending_name: jsonStringConverter?.trendingName,
          trending_banner_url: jsonStringConverter?.trendingBannerUrl,
        },
      });
    } else if (notificationBanner?.data?.screenName == 'ProductDetail') {
      push('ProductDetail', {
        product_id: Number(jsonStringConverter?.productId),
        default_images: [jsonStringConverter?.productImage],
        shop_id: jsonStringConverter?.shopId,
      });
    } else if (notificationBanner?.data?.screenName == 'ReelsScreen') {
      push('ReelsScreen', {
        videoId: Number(jsonStringConverter?.videoId),
      });
    } else if (notificationBanner?.data?.screenName == 'Cart') {
      dispatch(_cartBottomSheet(true));
    }
  } catch (error) {}
};

// export const call = async ({
//   baseUrl,
//   method,
//   body,
//   headers,
//   credentials,
//   signal,
//   ai_url,
//   other_url,
//   ai_second_url,
// }) => {
//   // const token = await getToken()
//   const token = '16|poO3EW8IVqxenB1tULrMAjnCB4nZfqFLSS3wmwSd';

//   const checkStatus = async api_response => {
//     const response = await api_response.json();

//     if (response.status == 200 || response.status == 201) {
//       return response;
//     }

//     const error = new Error(response.message || response.error);
//     error.response = response;

//     throw error;
//   };

//   const checkError = response => {
//     if (
//       response.status == 302 ||
//       response.status == 404 ||
//       response.status == 500 ||
//       response.status == 401 ||
//       response.status == 400
//     ) {
//       throw new Error(response.message);
//     }
//     console.log('response', response);
//     if (response.status == 200 || response.status == 201) return response;
//   };

//   const config = {
//     method: method || 'POST',
//     headers: {
//       Accept: 'application/json',
//       'Content-Type': headers || 'application/json',
//       token: token,
//       Authorization: `Bearer ${token}`,
//     },
//   };

//   // if (headers) {
//   //   config.headers = headers
//   // }

//   console.log(
//     'config',
//     (ai_second_url ? ai_secondary_url : ai_url ? ai_global_url : url) +
//       (other_url || baseUrl),
//     method,
//   );

//   if (signal) {
//     config.signal = signal;
//   }
//   if (body) {
//     config.body = body;
//   }
//   if (credentials) {
//     config.credentials = credentials;
//   }

//   let response;

//   const finalUrl = `${
//     (ai_second_url ? ai_secondary_url : ai_url ? ai_global_url : url) +
//     (other_url || baseUrl)
//   }`;

//   try {
//     // const metric = await perf().newHttpMetric(finalUrl, method); // Replace 'GET' with the actual method if needed.
//     // metric.start();
//     response = await fetch(finalUrl, config);
//     // metric.setHttpResponseCode(response.status);
//     // metric.stop();
//     // metric.setResponseContentType(response.headers.get('Content-Type'));
//     // metric.setResponsePayloadSize(response.headers.get('Content-Length'));
//     response = await checkStatus(response);
//     response = await checkError(response);
//     return response;
//   } catch (error) {
//     console.log('error', error?.message);
//     // metric.setHttpResponseCode(500); // Assuming 500 on error. Adjust based on error types.
//     // metric.stop();
//     throw new Error(error.message);
//   }
// };

// Cache to store recent requests

const requestCache = new Map();

export const call = async ({
  baseUrl,
  method,
  body,
  headers,
  credentials,
  signal,
  ai_url,
  other_url,
  ai_second_url,
}) => {
  const token = '16|poO3EW8IVqxenB1tULrMAjnCB4nZfqFLSS3wmwSd';

  const checkStatus = async api_response => {
    const response = await api_response.json();

    if (response.status == 200 || response.status == 201) {
      return response;
    }

    const error = new Error(response.message || response.error);
    error.response = response;
    throw error;
  };

  const checkError = response => {
    if (
      response.status == 302 ||
      response.status == 404 ||
      response.status == 500 ||
      response.status == 401 ||
      response.status == 400
    ) {
      throw new Error(response.message);
    }

    if (response.status == 200 || response.status == 201) {
      return response;
    }
  };

  const config = {
    method: method || 'POST',
    headers: {
      Accept: 'application/json',
      'Content-Type': headers || 'application/json',
      token: token,
      Authorization: `Bearer ${token}`,
    },
  };

  if (signal) config.signal = signal;
  if (body) config.body = body;
  if (credentials) config.credentials = credentials;

  const finalUrl = `${
    (ai_second_url ? ai_secondary_url : ai_url ? ai_global_url : url) +
    (other_url || baseUrl)
  }`;

  console.log('API_URL', finalUrl);

  // 🧠 Unique key for throttling: based on URL + method + body
  const requestKey = JSON.stringify({
    url: finalUrl,
    method: config.method,
    body: config.body,
  });

  const now = Date.now();
  const cached = requestCache.get(requestKey);

  if (cached && now - cached.timestamp < 2000) {
    return cached.promise;
  }

  let responsePromise;

  try {
    // const metric = await perf().newHttpMetric(finalUrl, method);
    // metric.start();

    responsePromise = fetch(finalUrl, config)
      .then(checkStatus)
      .then(checkError);

    // Cache this request
    requestCache.set(requestKey, {
      timestamp: now,
      promise: responsePromise,
    });

    // Clean the cache after 2 seconds
    setTimeout(() => {
      requestCache.delete(requestKey);
    }, 2000);

    const response = await responsePromise;

    // metric.setHttpResponseCode(response.status);
    // metric.setResponseContentType(response.headers.get('Content-Type'));
    // metric.setResponsePayloadSize(response.headers.get('Content-Length'));
    // metric.stop();

    return response;
  } catch (error) {
    // metric.setHttpResponseCode(500);
    // metric.stop();
    throw new Error(error.message);
  }
};

export const ProfileDisplay = (token, profile) => {
  if (token) {
    if (profile) return profile;
    else return 'https://cdn-icons-png.flaticon.com/512/149/149071.png';
  } else {
    return 'https://cdn-icons-png.flaticon.com/512/149/149071.png';
  }
};

export const nameDisplay = data => {
  const firstName = data?.firstname ? data?.firstname + ' ' : '';
  const lastName = data?.lastname ? data?.lastname : '';
  const name = firstName + lastName;
  return name;
};

export const AuthNavigating = () => {
  const token = store.getState().auth.token;
  if (token) {
    return true;
  } else {
    navigate('AuthNavigator');
  }
};

export const AuthNavigatingProfile = () => {
  const token = store.getState().auth.token;
  if (token) {
    navigate('Profile');
    return true;
  } else {
    navigate('AuthNavigator');
  }
};
export const isCenterOfTriple = index => {
  return index % 3 === 1;
};

export const dateFormate = date => {
  const day = date.getDate();
  const month = date.getMonth() + 1; // Months are zero-based, so add 1
  const year = date.getFullYear();

  // Adding leading zero to day and month if they are less than 10
  const formattedDay = day < 10 ? `0${day}` : day;
  const formattedMonth = month < 10 ? `0${month}` : month;

  return `${formattedDay}/${formattedMonth}/${year}`;
};

export const filterObject = (screen, key, api_keyword) => {
  try {
    const {screenFilters} = getStoreState('common');
    const data = screenFilters?.[screen][key] || '';
    if (data) {
      const filterData = filtersData.find(item => item.db_value === key);
      if (filterData?.db_value && api_keyword) {
        return (
          filterData?.data?.find(item => item.id === data)?.[api_keyword] ||
          data
        );
      } else {
        return data;
      }
    }
  } catch (error) {
    return '';
  }
};
