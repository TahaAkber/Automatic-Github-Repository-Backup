export const CHAT_AI_LOADER = 'CHAT_AI_LOADER';
export const CHAT_AI_ERROR = 'CHAT_AI_ERROR';
export const CHAT_AI = 'CHAT_AI';
export const CHAT_AI_RESET = 'CHAT_AI_RESET';
export const CHAT_AI_APPEND = 'CHAT_AI_APPEND';
