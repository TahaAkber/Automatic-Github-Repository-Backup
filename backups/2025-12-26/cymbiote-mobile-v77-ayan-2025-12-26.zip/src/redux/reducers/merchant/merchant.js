import {
  FETCH_BRAND_SEARCH_PRODUCTS,
  FETCH_BRAND_SEARCH_PRODUCTS_ERROR,
  FETCH_BRAND_SEARCH_PRODUCTS_LOADER,
  FETCH_FILTER_COLLECTION,
  FETCH_FILTER_COLLECTION_ERROR,
  FETCH_STORE,
  FETCH_STORE_COLLECTION,
  FETCH_STORE_COLLECTION_ERROR,
  FETCH_STORE_COLLECTION_LOADER,
  FETCH_STORE_ERROR,
  FETCH_STORE_FOLLOWING_LIST,
  FETCH_STORE_FOLLOWING_LIST_ERROR,
  FETCH_STORE_FOLLOWING_LIST_LOADER,
  FETCH_STORE_FOLLOWING_LIST_LOCAL,
  FETCH_STORE_FOR_REDEEM,
  FETCH_STORE_LOADER,
  FETCH_STORE_PRODUCT_DETAIL,
  FETCH_STORE_PRODUCT_DETAIL_ERROR,
  FETCH_STORE_PRODUCT_DETAIL_LOADER,
  FETCH_STORE_PRODUCTS,
  FETCH_STORE_PRODUCTS_ERROR,
  FETCH_STORE_PRODUCTS_LOADER,
  FETCH_STORE_SINGLE_COLLECTION,
  FETCH_STORE_SINGLE_COLLECTION_ERROR,
  FETCH_STORE_SINGLE_COLLECTION_LOADER,
  FETCH_STORIES_FOLLOWING_LIST,
  FETCH_STORIES_FOLLOWING_LIST_ERROR,
  FETCH_STORIES_FOLLOWING_LIST_LOADER,
  FETCH_TRENDING_COLLECTION,
  FETCH_TRENDING_COLLECTION_ERROR,
  FETCH_TRENDING_COLLECTION_LOADER,
} from '../../types/merchant/merchant';
const initial_state = {
  fetch_store: {},
  fetch_store_for_redeem: {},
  fetch_store_loader: true,
  fetch_store_error: '',

  fetch_store_product_detail: {},
  fetch_store_product_detail_loader: false,
  fetch_store_product_detail_error: '',

  fetch_store_products: {},
  fetch_store_products_loader: false,
  fetch_store_products_error: '',

  fetch_store_following_list: [],
  fetch_store_following_list_loader: false,
  fetch_store_following_list_error: '',

  fetch_store_following_list_local: [],

  fetch_store_collection: [],
  fetch_store_collection_loader: false,
  fetch_store_collection_error: '',

  fetch_store_single_collection: {},
  fetch_store_single_collection_loader: false,
  fetch_store_single_collection_error: '',

  trending_collection: [],
  trending_collection_loader: false,
  trending_collection_error: '',

  brand_search_products: {},
  brand_search_products_laoder: false,
  brand_search_products_error: '',

  fetch_stories_following_list: [],
  fetch_stories_following_list_loader: false,
  fetch_stories_following_list_error: '',

  fetch_filter_collection: false,
  fetch_filter_collection_error: '',
};

const merchantReducer = (state = initial_state, action) => {
  switch (action.type) {
    case FETCH_STORE_FOR_REDEEM:
      return {...state, fetch_store_for_redeem: action.payload};
    case FETCH_STORE:
      return {...state, fetch_store: action.payload};
    case FETCH_STORE_LOADER:
      return {...state, fetch_store_loader: action.payload};
    case FETCH_STORE_ERROR:
      return {...state, fetch_store_error: action.payload};
    case FETCH_STORE_PRODUCTS:
      return {...state, fetch_store_products: action.payload};
    case FETCH_STORE_PRODUCTS_ERROR:
      return {...state, fetch_store_products_error: action.payload};
    case FETCH_STORE_PRODUCTS_LOADER:
      return {...state, fetch_store_products_loader: action.payload};
    case FETCH_STORE_PRODUCT_DETAIL:
      return {...state, fetch_store_product_detail: action.payload};
    case FETCH_STORE_PRODUCT_DETAIL_LOADER:
      return {...state, fetch_store_product_detail_loader: action.payload};
    case FETCH_STORE_PRODUCT_DETAIL_ERROR:
      return {...state, fetch_store_product_detail_error: action.payload};
    case FETCH_STORE_FOLLOWING_LIST:
      return {...state, fetch_store_following_list: action.payload};
    case FETCH_STORE_FOLLOWING_LIST_LOADER:
      return {...state, fetch_store_following_list_loader: action.payload};
    case FETCH_STORE_FOLLOWING_LIST_ERROR:
      return {...state, fetch_store_following_list_error: action.payload};
    case FETCH_STORE_FOLLOWING_LIST_LOCAL:
      return {...state, fetch_store_following_list_local: action.payload};
    case FETCH_STORE_COLLECTION:
      return {...state, fetch_store_collection: action.payload};
    case FETCH_STORE_COLLECTION_LOADER:
      return {...state, fetch_store_collection_loader: action.payload};
    case FETCH_STORE_COLLECTION_ERROR:
      return {...state, fetch_store_collection_error: action.payload};
    case FETCH_STORE_SINGLE_COLLECTION:
      return {...state, fetch_store_single_collection: action.payload};
    case FETCH_STORE_SINGLE_COLLECTION_LOADER:
      return {...state, fetch_store_single_collection_loader: action.payload};
    case FETCH_STORE_SINGLE_COLLECTION_ERROR:
      return {...state, fetch_store_single_collection_error: action.payload};
    case FETCH_TRENDING_COLLECTION:
      return {...state, trending_collection: action.payload};
    case FETCH_TRENDING_COLLECTION_LOADER:
      return {...state, trending_collection_loader: action.payload};
    case FETCH_TRENDING_COLLECTION_ERROR:
      return {...state, trending_collection_error: action.payload};
    case FETCH_BRAND_SEARCH_PRODUCTS:
      return {...state, brand_search_products: action.payload};
    case FETCH_BRAND_SEARCH_PRODUCTS_LOADER:
      return {...state, brand_search_products_laoder: action.payload};
    case FETCH_BRAND_SEARCH_PRODUCTS_ERROR:
      return {...state, brand_search_products_error: action.payload};
    case FETCH_STORIES_FOLLOWING_LIST:
      return {...state, fetch_stories_following_list: action.payload};
    case FETCH_STORIES_FOLLOWING_LIST_LOADER:
      return {...state, fetch_stories_following_list_loader: action.payload};
    case FETCH_STORIES_FOLLOWING_LIST_ERROR:
      return {...state, fetch_stories_following_list_error: action.payload};
    case FETCH_FILTER_COLLECTION:
      return {...state, fetch_filter_collection: action.payload};
    case FETCH_FILTER_COLLECTION_ERROR:
      return {...state, fetch_filter_collection_error: action.payload};
    default: {
      return state;
    }
  }
};
export default merchantReducer;
