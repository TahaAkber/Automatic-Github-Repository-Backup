import {
  CHAT_AI,
  CHAT_AI_APPEND,
  CHAT_AI_ERROR,
  CHAT_AI_LOADER,
  CHAT_AI_RESET,
} from '../../types/chatai/chatai';

const initialState = {
  data: [],
  chatHistory: [], // ✅ Must be array

  loading: false,
  error: null,
};

const chatAiReducer = (state = initialState, action) => {
  switch (action.type) {
    case CHAT_AI_LOADER:
      return {
        ...state,
        loading: action.payload,
      };

    case CHAT_AI:
      return {
        ...state,
        data: action.payload,
        error: null,
      };

    case CHAT_AI_ERROR:
      return {
        ...state,
        error: action.payload,
      };

    case CHAT_AI_APPEND:
      return {
        ...state,
        chatHistory: [action.payload, ...(state.chatHistory || [])],
      };

    case CHAT_AI_RESET:

      return {
        // ...state,
        chatHistory: [],
        data: [],
      };

    default:
      return state;
  }
};

export default chatAiReducer;
