import {
  FETCH_CONNECTED_ACCOUNT,
  FETCH_CONNECTED_ACCOUNT_ERROR,
  FETCH_CONNECTED_ACCOUNT_LOADER,
  FETCH_INTERNAL_ORDER,
  FETCH_INTERNAL_ORDER_ERROR,
  FETCH_INTERNAL_ORDER_LOADER,
  FETCH_CANCELLATION_ENUMS,
  FETCH_CANCELLATION_ENUMS_LOADER,
  FETCH_CANCELLATION_ENUMS_ERROR,
  CANCEL_ORDER,
  CANCEL_ORDER_LOADER,
  CANCEL_ORDER_ERROR,
  FETCH_ACTIVE_ORDER,
  FETCH_ACTIVE_ORDER_ERROR,
  FETCH_ACTIVE_ORDER_LOADER,
  SET_PAGINATION,
  FETCH_ORDER_DETAIL,
  FETCH_ORDER_DETAIL_LOADER,
  FETCH_ORDER_DETAIL_ERROR,
  FETCH_TRACKING,
  FETCH_TRACKING_LOADER,
  FETCH_TRACKING_ERROR,
  FETCH_TRACKING_SERVICES,
} from '../../types/orders/orders';

const initial_state = {
  fetch_connected_account: [],
  fetch_connected_account_loader: true,
  fetch_connected_account_error: '',

  fetch_internal_order: {
    0: {},
    2: {},
    3: {},
    4: {},
  },
  fetch_internal_order_loader: true,
  fetch_internal_order_error: '',

  fetch_cancellation_enums: [],
  fetch_cancellation_enums_loader: false,
  fetch_cancellation_enums_error: '',

  cancel_order_loader: false,
  cancel_order_error: '',
  cancelledOrders: [],
  fetch_active_order: [],
  fetch_active_order_loader: false,
  fetch_active_order_error: '',
  pagination: {
    totalOrders: 0,
    totalPages: 1,
    currentPage: 1,
    pageSize: 10,
  },
  fetch_order_detail: {},
  fetch_order_detail_loader: false,
  fetch_order_detail_error: '',
  fetch_tracking: {},
  fetch_tracking_loader: false,
  fetch_tracking_error: '',
  fetch_tracking_services: [],
};

const orderReducer = (state = initial_state, action) => {
  switch (action.type) {
    case FETCH_CONNECTED_ACCOUNT:
      return {...state, fetch_connected_account: action.payload};
    case FETCH_CONNECTED_ACCOUNT_LOADER:
      return {...state, fetch_connected_account_loader: action.payload};
    case FETCH_CONNECTED_ACCOUNT_ERROR:
      return {...state, fetch_connected_account_error: action.payload};
    case FETCH_INTERNAL_ORDER:
      return {...state, fetch_internal_order: action.payload};
    case FETCH_INTERNAL_ORDER_LOADER:
      return {...state, fetch_internal_order_loader: action.payload};
    case FETCH_INTERNAL_ORDER_ERROR:
      return {...state, fetch_internal_order_error: action.payload};
    case FETCH_CANCELLATION_ENUMS:
      return {
        ...state,
        fetch_cancellation_enums: action.payload,
        fetch_cancellation_enums_error: '',
      };
    case FETCH_CANCELLATION_ENUMS_LOADER:
      return {...state, fetch_cancellation_enums_loader: action.payload};
    case FETCH_CANCELLATION_ENUMS_ERROR:
      return {...state, fetch_cancellation_enums_error: action.payload};

    case CANCEL_ORDER_LOADER:
      return {...state, cancel_order_loader: action.payload};
    case CANCEL_ORDER_ERROR:
      return {
        ...state,
        cancel_order_error: action.payload,
        cancel_order_loader: false,
      };

    case FETCH_ACTIVE_ORDER:
      return {
        ...state,
        fetch_active_order: action.payload,
        fetch_active_order_error: '',
      };
    case FETCH_ACTIVE_ORDER_ERROR:
      return {
        ...state,
        fetch_active_order_error: action.payload,
        fetch_active_order_loader: false,
      };
    case FETCH_ACTIVE_ORDER_LOADER:
      return {...state, fetch_active_order_loader: action.payload};
    case FETCH_ORDER_DETAIL:
      return {...state, fetch_order_detail: action.payload};
    case FETCH_ORDER_DETAIL_LOADER:
      return {...state, fetch_order_detail_loader: action.payload};
    case FETCH_ORDER_DETAIL_ERROR:
      return {...state, fetch_order_detail_error: action.payload};
    case FETCH_TRACKING:
      return {...state, fetch_tracking: action.payload};
    case FETCH_TRACKING_LOADER:
      return {...state, fetch_tracking_loader: action.payload};
    case FETCH_TRACKING_ERROR:
      return {...state, fetch_tracking_error: action.payload};
    case FETCH_TRACKING_SERVICES:
      return {...state, fetch_tracking_services: action.payload};
    default: {
      return state;
    }
  }
};

export default orderReducer;
