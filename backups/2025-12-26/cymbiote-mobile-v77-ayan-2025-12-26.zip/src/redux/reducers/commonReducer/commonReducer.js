import {
  IS_LOADING_AUTH,
  SNACK_BAR,
  GET_INTRO_SLIDER,
} from '@redux/types/common/common';
import {
  CART_BOTTOM_SHEET,
  FOCUS_HOME_TAB,
  NOTIFICATION_TOKEN,
  RESET_VIDEO_INDEXES,
  SET_VIDEO_INDEXES,
  TRIGGER_CART_BOUNCE,
  SET_HOME_SCROLL_POSITION,
  FETCH_APP_UPDATE_CONFIG,
  SET_APP_UPDATE_STATUS,
} from '../../types/common/common';
import {
  FETCH_SEARCH_FILTERS,
  FETCH_TAXONOMIES,
  RECENT_SEARCHES,
} from '../../types/user/user';
import { _getTaxonomies } from '../../actions/common/common';

const initial_state = {
  snackBar: {},
  fetched_taxonomies: [],
  globalLoader: false,
  introSlider: false,
  tab: 'home',
  cartBottomSheet: false,
  focusHomeScreen: true,
  notificationToken: '',
  recentSearches: [],
  screenFilters: {},
  homeScrollPosition: false,
  appUpdateConfig: {},
  appUpdateStatus: {
    needsUpdate: false,
    canSkip: true,
    storeUrl: '',
    updatedAt: '',
    latestVersion: '',
  },
};

const commonReducer = (state = initial_state, action) => {
  switch (action.type) {
    case SNACK_BAR:
      return { ...state, snackBar: action.payload };
    case IS_LOADING_AUTH:
      return { ...state, globalLoader: action.payload };
    case GET_INTRO_SLIDER:
      return { ...state, introSlider: action.payload };
    case CART_BOTTOM_SHEET:
      return { ...state, cartBottomSheet: action.payload };
    case FOCUS_HOME_TAB:
      return { ...state, focusHomeScreen: action.payload };
    case NOTIFICATION_TOKEN:
      return { ...state, notificationToken: action.payload };
    case RECENT_SEARCHES:
      return { ...state, recentSearches: action.payload };
    case FETCH_TAXONOMIES:
      return { ...state, fetched_taxonomies: action.payload };
    case TRIGGER_CART_BOUNCE:
      return { ...state, cartBounce: action.payload };
    case FETCH_SEARCH_FILTERS:
      return { ...state, screenFilters: action.payload };
    case SET_VIDEO_INDEXES:
      return {
        ...state,
        index: action.payload.index,
        activeVideoIndex: action.payload.activeIndex,
      };
    case RESET_VIDEO_INDEXES:
      return {
        ...state,
        index: 0,
        activeVideoIndex: 0,
      };

    case SET_HOME_SCROLL_POSITION:
      return { ...state, homeScrollPosition: action.payload };
    case FETCH_APP_UPDATE_CONFIG:
      return { ...state, appUpdateConfig: action.payload };
    case SET_APP_UPDATE_STATUS:
      return { ...state, appUpdateStatus: action.payload };
    default: {
      return state;
    }
  }
};
export default commonReducer;
