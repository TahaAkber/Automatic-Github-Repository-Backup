// import {
//     GET_ALL_VOUCHERS,
//     GET_ALL_VOUCHERS_LOADER,
//     GET_ALL_VOUCHERS_ERROR,
//     APPEND_ALL_VOUCHERS,
//   } from "@redux/types/reward/allVochers";

import { GET_ALL_VOUCHERS_LOADER ,
    GET_ALL_VOUCHERS,
    GET_ALL_VOUCHERS_ERROR,
    APPEND_ALL_VOUCHERS} from "../../types/reward/reward";

    const initial_state = {
        all_vouchers: {
          logs: [],
          pagination: { totalPages: 1, currentPage: 1, pageSize: 5 }
        },
        all_vouchers_loader: false,
        all_vouchers_error: ""
      };
      
      const AllVouchersReducer = (state = initial_state, action) => {
        switch (action.type) {
          case GET_ALL_VOUCHERS:
            return {
              ...state,
              all_vouchers: action.payload
            };
      
          case GET_ALL_VOUCHERS_LOADER:
            return { ...state, all_vouchers_loader: action.payload };
      
          case GET_ALL_VOUCHERS_ERROR:
            return { ...state, all_vouchers_error: action.payload };
      
          default:
            return state;
        }
      };
      export default AllVouchersReducer;