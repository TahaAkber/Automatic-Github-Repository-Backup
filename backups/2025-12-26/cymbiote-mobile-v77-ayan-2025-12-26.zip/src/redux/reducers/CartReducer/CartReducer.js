import {
  ADD_TO_CART,
  CART_ITEM_LOADER,
  FETCH_CART_DB_ITEM,
  FETCH_CART_ITEM,
  RESET_CART,
  SYNC_CART_TO_DB_LOADING,
  UPDATE_CART_QUANTITY,
  UPDATE_CART_QUANTITY_OPTIMISTIC,
} from '../../types/cart/cart';

const initialState = {
  cart: [],
  cart_item: [],
  cart_item_loader: false,
  check_out: {},
  check_out_loader: false,
  syncingCart: false,
};

const CartReducer = (state = initialState, action) => {
  switch (action.type) {
    case FETCH_CART_ITEM:
      return {...state, cart: action.payload};

    case FETCH_CART_DB_ITEM:
      return {...state, cart_item: action.payload};

    case ADD_TO_CART: {
      // Update quantity in cart
      const updatedCart = state.cart.map(shop => {
        if (shop.shop.shop_id === action.payload.shop_id) {
          return {
            ...shop,
            products: shop.products.map(product => {
              const variant = product.product_variant.variant;
              if (variant.variant_id === action.payload.variant_id) {
                return {
                  ...product,
                  product_variant: {
                    ...product.product_variant,
                    variant: {
                      ...variant,
                      quantity: variant.quantity + action.payload.change,
                    },
                  },
                };
              }
            
              return product;
            }),
          };
        }
        return shop;
      });

      return {
        ...state,
        cart: updatedCart,
      };
    }
    case UPDATE_CART_QUANTITY: {
      // **Absolute quantity update**
      const updatedCartQuantity = state.cart.map(shop => {
        if (shop.shop.shop_id === action.payload.shop_id) {
          return {
            ...shop,
            products: shop.products.map(product => {
              if (
                product.product_variant.variant.variant_id ===
                action.payload.variant_id
              ) {
                return {
                  ...product,
                  quantity: action.payload.quantity, // <-- absolute, not additive
                };
              }
              return product;
            }),
          };
        }
        return shop;
      });
      return {...state, cart: updatedCartQuantity};
    }

    case CART_ITEM_LOADER:
      return {
        ...state,
        cart_item_loader: action.payload,
      };
    case RESET_CART:
      return initialState;

    case SYNC_CART_TO_DB_LOADING:
      return {
        ...state,
        syncingCart: action.payload,
      };
    default:
      return state;
  }
};

export default CartReducer;
