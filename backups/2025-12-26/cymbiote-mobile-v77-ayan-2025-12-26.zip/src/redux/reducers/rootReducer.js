import authReducer from './auth/auth';
import CartReducer from './CartReducer/CartReducer';
import commonReducer from './commonReducer/commonReducer';
import merchantReducer from './merchant/merchant';
import {combineReducers} from 'redux';
import userReducer from './user/user';
import rewardReducer from './rewardReducer/rewardReducer';
import orderReducer from './orderReducer/orderReducer';
import reelsReducer from './reelsReducer/reelsReducer';
import AllVouchersReducer from './rewardReducer/voucherReducer';
import reviewReducer from './reviewReducer/reviewReducer';
import chatAiReducer from './chataiReducer/chataiReducer';

const rootReducer = combineReducers({
  common: commonReducer,
  merchant: merchantReducer,
  cart: CartReducer,
  auth: authReducer,
  user: userReducer,
  reward: rewardReducer,
  order: orderReducer,
  reels: reelsReducer,
  vouchers: AllVouchersReducer,
  reviews: reviewReducer,
  chatAi: chatAiReducer,
});

export default rootReducer;
