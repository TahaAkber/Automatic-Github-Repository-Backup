import {_commonDispatcher} from '../common/common';
import {call} from '@helper/reUsableMethod/reUsableMethod';
import {getStoreState} from '@utils/helper/helper';
// import { GET_USER_POINTS, GET_USER_POINTS_ERROR, GET_USER_POINTS_LOADER } from "@redux/types/reward/reward";
import {showToast} from '../../../helper/reUsableMethod/reUsableMethod';
import {
  GET_USER_POINTS,
  GET_USER_POINTS_ERROR,
  GET_USER_POINTS_LOADER,
  APPEND_USER_POINTS_HISTORY,
  GET_USER_POINTS_HISTORY,
  GET_USER_POINTS_HISTORY_LOADER,
  GET_USER_POINTS_HISTORY_ERROR,
} from '@redux/types/reward/reward';
import {
  APPEND_ALL_VOUCHERS,
  APPEND_USER_VOUCHERS,
  GET_ALL_VOUCHERS,
  GET_ALL_VOUCHERS_ERROR,
  GET_ALL_VOUCHERS_LOADER,
  GET_USER_VOUCHERS,
  GET_USER_VOUCHERS_ERROR,
  GET_USER_VOUCHERS_LOADER,
} from '../../types/reward/reward';

export const _getPoints = () => {
  return async dispatch => {
    const {fetch_user_detail} = getStoreState('auth');
    try {
      if (fetch_user_detail?.id) {
        dispatch(_commonDispatcher(GET_USER_POINTS_ERROR, ''));
        dispatch(_commonDispatcher(GET_USER_POINTS_LOADER, true));
        const responseData = await call({
          baseUrl: `/points/user/${fetch_user_detail?.id}`,
          method: 'GET',
        });
        let pointsHistory = [];
        if (responseData?.logs) {
          pointsHistory = responseData.logs.flatMap(log =>
            log.data
              .filter(entry =>
                [2, 3, 4, 6].includes(entry.points_log_criteria_id),
              )
              .map(entry => ({
                month: log.month,
                criteria_id: entry.points_log_criteria_id,
                points: entry.points_log_transaction_count,
                date: entry.created_at.split('T')[0],
                description: entry.points_log_description,
                image:
                  entry.points_log_criteria_id === 6
                    ? 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQb2jzreRUyHH1GJkhb_ZikhLfGQ8mlODNYvg&s'
                    : entry.shop?.shop_logo_url || '',
                status: entry.points_status || 'unknown',
              })),
          );
        }
        dispatch(_commonDispatcher(GET_USER_POINTS, responseData));
        dispatch(
          _commonDispatcher(GET_USER_POINTS_HISTORY, {
            tab: 0,
            points: pointsHistory,
          }),
        );
        dispatch(_commonDispatcher(GET_USER_POINTS_LOADER, false));
        return {pointsHistory};
      }
    } catch (error) {
      dispatch(_commonDispatcher(GET_USER_POINTS, {}));
      dispatch(_commonDispatcher(GET_USER_POINTS_LOADER, false));
      dispatch(_commonDispatcher(GET_USER_POINTS_ERROR, error.message));
      return 0;
    }
  };
};

export const _createVoucher = (point, shop_id) => {
  return async dispatch => {
    const {fetch_user_detail} = getStoreState('auth');
    try {
      const rawData = {
        userId: fetch_user_detail?.id,
        pointsToDeduct: point,
        shopId: shop_id,
      };
      const responseData = await call({
        baseUrl: `/points/voucher`,
        method: 'POST',
        body: JSON.stringify(rawData),
      });
      await dispatch(_getPointsHistory({page: 1, tab: 0}));
      await dispatch(_getVouchers({pageSize: 3}));
      await dispatch(_getAllVouchers({page: 1}));
      showToast(responseData?.message);
      const data = responseData?.data;
      return data;
    } catch (error) {
      showToast(error?.message);
      return 0;
    }
  };
};

export const _getVouchers = ({page = 1}) => {
  return async dispatch => {
    const {fetch_user_detail} = getStoreState('auth');
    if (fetch_user_detail?.id) {
      try {
        dispatch(_commonDispatcher(GET_USER_VOUCHERS_ERROR, ''));
        dispatch(_commonDispatcher(GET_USER_VOUCHERS_LOADER, true));
        const responseData = await call({
          baseUrl: `/points/user/voucher/${fetch_user_detail?.id}?page=${page}`,
          method: 'GET',
        });
        let vouchers = [];
        if (responseData?.logs) {
          vouchers = responseData.logs.flatMap(log =>
            log.data.map(entry => ({
              month: log.month,
              voucher_code: entry.voucher_code,
              voucher_expiration_date: entry.voucher_expiration_date
                ? entry.voucher_expiration_date.split('T')[0]
                : 'No Expiration',
              store_logo: entry.shop?.shop_logo_url || '',
              voucher_value: entry.voucher_value,
            })),
          );
        }
        dispatch(_commonDispatcher(GET_USER_VOUCHERS, vouchers));
        dispatch(_commonDispatcher(GET_USER_VOUCHERS_LOADER, false));
        return {vouchers};
      } catch (error) {
        dispatch(_commonDispatcher(GET_USER_VOUCHERS, []));
        dispatch(_commonDispatcher(GET_USER_VOUCHERS_LOADER, false));
        dispatch(_commonDispatcher(GET_USER_VOUCHERS_ERROR, error.message));
        return {};
      }
    }
  };
};

export const _getPointsHistory = ({page, tab, pull = false}) => {
  return async dispatch => {
    const {fetch_user_detail} = getStoreState('auth');
    const {user_point_history} = getStoreState('reward');
    if (fetch_user_detail?.id) {
      dispatch({type: GET_USER_POINTS_HISTORY_LOADER, payload: true});

      try {
        const responseData = await call({
          baseUrl: `/points/user/${fetch_user_detail?.id}?page=${page}&status=${tab}`,
          method: 'GET',
        });
        if (page === 1) {
          let updatedResponse = responseData;

          if (pull) {
            const previousData = user_point_history?.[tab]?.logs || [];
            const updatedData = [
              ...responseData.logs.slice(
                0,
                responseData?.pagination?.pageSize || 0,
              ),
              ...previousData.slice(responseData?.pagination?.pageSize || 0),
            ];
            updatedResponse = {...responseData, logs: updatedData};
          }

          const logs = {...user_point_history, [tab]: updatedResponse};
          dispatch({type: GET_USER_POINTS_HISTORY, payload: logs});
          dispatch({type: GET_USER_POINTS_HISTORY_ERROR, payload: ''});
        } else {
          let previousData = user_point_history?.[tab]?.logs || [];
          let updatedData = [...previousData, ...responseData.logs];
          const updatedResponse = {...responseData, logs: updatedData};
          const logs = {...user_point_history, [tab]: updatedResponse};
          dispatch({type: GET_USER_POINTS_HISTORY, payload: logs});
          dispatch({type: GET_USER_POINTS_HISTORY_ERROR, payload: ''});
        }
        dispatch({type: GET_USER_POINTS_HISTORY_ERROR, payload: ''});
        dispatch({type: GET_USER_POINTS_HISTORY_LOADER, payload: false});
      } catch (error) {
        const data = {...user_point_history, [tab]: {logs: []}};
        dispatch({type: GET_USER_POINTS_HISTORY, payload: data});
        dispatch({
          type: GET_USER_POINTS_HISTORY_ERROR,
          payload: error?.message,
        });
        dispatch({type: GET_USER_POINTS_HISTORY_LOADER, payload: false});
        return 0;
      }
    }
  };
};

export const _getAllVouchers = ({page = 1, pull = false}) => {
  return async dispatch => {
    const {fetch_user_detail} = getStoreState('auth');

    const {all_vouchers} = getStoreState('vouchers');

    dispatch({type: GET_ALL_VOUCHERS_ERROR, payload: ''});

    if (fetch_user_detail?.id) {
      try {
        const responseData = await call({
          baseUrl: `/points/user/voucher/${fetch_user_detail?.id}?page=${page}`,
          method: 'GET',
        });
        let updatedResponse = responseData;
        if (page === 1) {
          if (pull) {
            const previousData = all_vouchers?.logs || [];
            const updatedLogs = [
              ...responseData.logs.slice(
                0,
                responseData?.pagination?.pageSize || 0,
              ),
              ...previousData.slice(responseData?.pagination?.pageSize || 0),
            ];
            updatedResponse = {...responseData, logs: updatedLogs};
          }
          dispatch({
            type: GET_ALL_VOUCHERS,
            payload: updatedResponse,
          });
        } else {
          const previousLogs = all_vouchers?.logs || [];
          const updatedLogs = [...previousLogs, ...responseData.logs];

          const updatedResponse = {
            ...responseData,
            logs: updatedLogs,
          };
          dispatch({
            type: GET_ALL_VOUCHERS,
            payload: updatedResponse,
          });
        }
        dispatch({type: GET_ALL_VOUCHERS_LOADER, payload: false});
        return updatedResponse;
      } catch (error) {
        const fallback = {
          logs: [],
          pagination: {totalPages: 1, currentPage: 1},
        };
        dispatch({type: GET_ALL_VOUCHERS, payload: fallback});
        dispatch({type: GET_ALL_VOUCHERS_ERROR, payload: error?.message});
        dispatch({type: GET_ALL_VOUCHERS_LOADER, payload: false});
        return null;
      }
    }
  };
};
