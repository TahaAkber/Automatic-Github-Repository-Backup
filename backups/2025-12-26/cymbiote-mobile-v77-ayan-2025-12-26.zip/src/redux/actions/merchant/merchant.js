import {_commonDispatcher} from '../common/common';
import {
  FETCH_STORE,
  FETCH_STORE_LOADER,
  FETCH_STORE_ERROR,
  FETCH_STORE_PRODUCT_DETAIL,
  FETCH_STORE_PRODUCT_DETAIL_LOADER,
  FETCH_STORE_PRODUCT_DETAIL_ERROR,
  FETCH_STORE_PRODUCTS,
  FETCH_STORE_PRODUCTS_LOADER,
  FETCH_STORE_PRODUCTS_ERROR,
  FETCH_STORE_FOLLOWING_LIST_LOCAL,
  FETCH_STORE_FOLLOWING_LIST_ERROR,
  FETCH_STORE_FOLLOWING_LIST_LOADER,
  FETCH_STORE_FOLLOWING_LIST,
  FETCH_STORE_FOR_REDEEM,
  FETCH_STORE_COLLECTION,
  FETCH_STORE_COLLECTION_LOADER,
  FETCH_STORE_COLLECTION_ERROR,
  FETCH_STORE_SINGLE_COLLECTION_LOADER,
  FETCH_STORE_SINGLE_COLLECTION,
  FETCH_STORE_SINGLE_COLLECTION_ERROR,
  FETCH_TRENDING_COLLECTION_LOADER,
  FETCH_TRENDING_COLLECTION_ERROR,
  FETCH_TRENDING_COLLECTION,
  FETCH_BRAND_SEARCH_PRODUCTS_ERROR,
  FETCH_BRAND_SEARCH_PRODUCTS_LOADER,
  FETCH_BRAND_SEARCH_PRODUCTS,
  FETCH_STORIES_FOLLOWING_LIST,
  FETCH_STORIES_FOLLOWING_LIST_LOADER,
  FETCH_STORIES_FOLLOWING_LIST_ERROR,
  FETCH_FILTER_COLLECTION,
  FETCH_FILTER_COLLECTION_ERROR,
} from '../../types/merchant/merchant';
import {call} from '@helper/reUsableMethod/reUsableMethod';
import NetInfo from '@react-native-community/netinfo';
import {getStoreState} from '../../../utils/helper/helper';
import {
  filterObject,
  showToast,
} from '../../../helper/reUsableMethod/reUsableMethod';
import {getHomeStoresCache} from '../../../utils/cache/homeCache';

// export const _getStores = ({ page, user_id }) => {
//     return async dispatch => {
//         try {
//             dispatch(_commonDispatcher(FETCH_STORE_ERROR, ""));
//             page == 1 && dispatch(_commonDispatcher(FETCH_STORE_LOADER, true));
//             const responseData = await call({ baseUrl: `/api/shops/all?page=${page}&user_id=${user_id}`, method: "GET" });
//             const data = responseData.shops;
//             page == 1 && dispatch(_commonDispatcher(FETCH_STORE, responseData));
//             dispatch(_commonDispatcher(FETCH_STORE_LOADER, false));
//             return data;
//         } catch (error) {
//             page == 1 && dispatch(_commonDispatcher(FETCH_STORE, {}));
//             page == 1 && dispatch(_commonDispatcher(FETCH_STORE_LOADER, false));
//             dispatch(_commonDispatcher(FETCH_STORE_ERROR, error.message));
//             return 0;
//         }
//     };
// };
export const _getStores = ({
  page,
  user_id,
  pull = false,
  paramters = '',
  categories = '',
  loader,
  pageSize,
}) => {
  return async dispatch => {
    const {fetch_store, fetch_store_for_redeem} = getStoreState('merchant');
    // dispatch(_commonDispatcher(FETCH_STORE_FOR_REDEEM, []));?

    // Stale-while-revalidate: Load cached data immediately on page 1
    if (page === 1 && !pull) {
      const cachedData = await getHomeStoresCache();
      if (cachedData) {
        dispatch(_commonDispatcher(FETCH_STORE, cachedData));
        dispatch(_commonDispatcher(FETCH_STORE_LOADER, false));
        // Continue fetching fresh data in background
      }
    }

    loader && dispatch(_commonDispatcher(FETCH_STORE_LOADER, true));
    dispatch(_commonDispatcher(FETCH_STORE_ERROR, ''));

    try {
      const responseData = await call({
        baseUrl: `/shops/all?page=${page}&user_id=${
          user_id || ''
        }${paramters}&categories=${categories}&shown_shop_ids=${
          fetch_store?.pagination?.repeatCheck
            ? ''
            : fetch_store?.pagination?.updatedShopIds || ''
        }&page_size=${pageSize ? pageSize : 3}`,
        method: 'GET',
      });
      if (page === 1) {
        let updatedResponse = responseData;

        if (pull) {
          const previousData = paramters
            ? fetch_store_for_redeem?.shops || []
            : fetch_store?.shops || [];
          const updatedData = [
            ...responseData.shops.slice(
              0,
              responseData?.pagination?.pageSize || 0,
            ),
            ...previousData.slice(responseData?.pagination?.pageSize || 0),
          ];

          // updatedResponse = {...responseData, shops: updatedData};
          dispatch(_commonDispatcher(FETCH_STORE, responseData));
          dispatch(_commonDispatcher(FETCH_STORE_LOADER, false));
        }
        if (paramters) {
          dispatch(_commonDispatcher(FETCH_STORE_FOR_REDEEM, updatedResponse));
          dispatch(_commonDispatcher(FETCH_STORE_LOADER, false));
        } else {
          dispatch(_commonDispatcher(FETCH_STORE, updatedResponse));
          dispatch(_commonDispatcher(FETCH_STORE_LOADER, false));

          // Save to cache for next time
          saveHomeStoresCache(updatedResponse);

          return updatedResponse;
        }
      } else {
        // let previousData = fetch_store?.shops || [];
        const previousData = paramters
          ? fetch_store_for_redeem?.shops || []
          : fetch_store?.shops || [];
        let updatedData = previousData.concat(responseData.shops);

        const updatedResponse = {...responseData, shops: updatedData};
        if (paramters) {
          dispatch(_commonDispatcher(FETCH_STORE_FOR_REDEEM, updatedResponse));
          dispatch(_commonDispatcher(FETCH_STORE_LOADER, false));
        } else {
          dispatch(_commonDispatcher(FETCH_STORE, updatedResponse));
          dispatch(_commonDispatcher(FETCH_STORE_LOADER, false));
        }
      }

      dispatch(_commonDispatcher(FETCH_STORE_LOADER, false));
    } catch (error) {
      if (paramters) {
        dispatch(_commonDispatcher(FETCH_STORE_FOR_REDEEM, {shops: []}));
      } else {
        // dispatch(_commonDispatcher(FETCH_STORE, {shops: []}));
      }
      dispatch(_commonDispatcher(FETCH_STORE_ERROR, error?.message));
      dispatch(_commonDispatcher(FETCH_STORE_LOADER, false));
      return 0;
    }
  };
};

export const _getStoresForRedeem = ({page, user_id, pull = false}) => {
  return async dispatch => {
    const {fetch_store, fetch_store_for_redeem} = getStoreState('merchant');

    dispatch(_commonDispatcher(FETCH_STORE_ERROR, ''));
    try {
      const responseData = await call({
        baseUrl: `/shops/search?page=${page}&page_size=12`,
        method: 'GET',
      });
      if (page == 1) {
        dispatch(_commonDispatcher(FETCH_STORE_FOR_REDEEM, responseData));
      } else {
        const data = {
          ...fetch_store_for_redeem,
          data: {
            ...fetch_store_for_redeem.data,
            shops: [
              ...fetch_store_for_redeem.data.shops,
              ...responseData.data.shops,
            ],
          },
        };
        dispatch(_commonDispatcher(FETCH_STORE_FOR_REDEEM, data));
      }
      dispatch(_commonDispatcher(FETCH_STORE_LOADER, false));
    } catch (error) {
      dispatch(_commonDispatcher(FETCH_STORE_FOR_REDEEM, {shops: []}));
      dispatch(_commonDispatcher(FETCH_STORE_LOADER, false));
      return 0;
    }
  };
};

export const _storeFollowingUpdateStatus = (
  shop_id,
  is_following,
  item,
  date,
  user_id,
  not_loading,
) => {
  return async dispatch => {
    const {fetch_store_following_list_local} = getStoreState('merchant');
    try {
      const {fetch_user_detail} = getStoreState('auth');
      if (user_id || fetch_user_detail?.id) {
        const created_at = date || new Date().toISOString();
        const rawData = {
          user_id: user_id || fetch_user_detail?.id,
          shop_id,
          is_following,
          created_at,
        };

        const response = await call({
          baseUrl: `/following/create-following-log`,
          method: 'POST',
          body: JSON.stringify(rawData),
        });

        const updateLocalList = fetch_store_following_list_local.filter(
          el => el.shop_id !== shop_id,
        );
        dispatch(
          _commonDispatcher(FETCH_STORE_FOLLOWING_LIST_LOCAL, updateLocalList),
        );
        dispatch(_getFollowingStore(true, [], not_loading));
      } else {
        // Copying the list to avoid mutation of original state
        const updatedList = [...fetch_store_following_list_local];
        item.shop_following = is_following;
        item.created_at = new Date().toISOString();

        const existingIndex = updatedList.findIndex(
          el => el.shop_id === item.shop_id,
        );
        if (existingIndex !== -1) {
          updatedList.splice(existingIndex, 1); // Remove existing item
        } else {
          updatedList.push(item); // Add new item
        }

        dispatch(
          _commonDispatcher(FETCH_STORE_FOLLOWING_LIST_LOCAL, updatedList),
        );
      }

      return 1;
    } catch (error) {
      console.log('error', error?.message);
      return 0;
    }
  };
};

export const _appendToFollowingList = user_id => {
  return async dispatch => {
    try {
      const {fetch_store_following_list_local} = getStoreState('merchant');
      fetch_store_following_list_local.forEach(element => {
        dispatch(
          _storeFollowingUpdateStatus(
            element.shop_id,
            true,
            false,
            element.created_at,
            user_id,
          ),
        );
      });
      return 1;
    } catch (error) {
      console.log('error', error?.message);
      return 0;
    }
  };
};

export const _getFollowingStore = (
  product,
  following_local,
  not_loading,
  page = 1,
) => {
  return async dispatch => {
    try {
      const {fetch_user_detail} = getStoreState('auth');
      const {fetch_store_following_list} = getStoreState('merchant');

      page == 1 &&
        dispatch(_commonDispatcher(FETCH_STORE_FOLLOWING_LIST_LOADER, true));
      const rawData = {
        user_id: fetch_user_detail?.id || false,
        product: product || false,
        following_local: following_local,
        pageSize: 4,
        page: page,
      };
      const responseData = await call({
        baseUrl: `/following/user-following-log`,
        method: 'POST',
        body: JSON.stringify(rawData),
      });

      if (page != 1) {
        const response = {
          ...responseData,
          data: [...fetch_store_following_list?.data, ...responseData?.data],
          pagination: responseData?.pagination,
        };
        dispatch(_commonDispatcher(FETCH_STORE_FOLLOWING_LIST, response));
        dispatch(_commonDispatcher(FETCH_STORE_FOLLOWING_LIST_LOADER, false));
        dispatch(_commonDispatcher(FETCH_STORE_FOLLOWING_LIST_ERROR, ''));
      } else {
        dispatch(_commonDispatcher(FETCH_STORE_FOLLOWING_LIST, responseData));
        dispatch(_commonDispatcher(FETCH_STORE_FOLLOWING_LIST_LOADER, false));
        dispatch(_commonDispatcher(FETCH_STORE_FOLLOWING_LIST_ERROR, ''));
      }
      return 1;
    } catch (error) {
      dispatch(_commonDispatcher(FETCH_STORE_FOLLOWING_LIST_LOADER, false));
      dispatch(
        _commonDispatcher(FETCH_STORE_FOLLOWING_LIST_ERROR, error.message),
      );
      return 0;
    }
  };
};

export const _getFollowingStories = (
  product,
  following_local,
  not_loading,
  page = 1,
) => {
  return async dispatch => {
    try {
      const {fetch_user_detail} = getStoreState('auth');
      const {fetch_stories_following_list} = getStoreState('merchant');

      dispatch(_commonDispatcher(FETCH_STORIES_FOLLOWING_LIST_ERROR, ''));
      page == 1 &&
        dispatch(_commonDispatcher(FETCH_STORIES_FOLLOWING_LIST_LOADER, true));
      const rawData = {
        user_id: fetch_user_detail?.id || false,
        product: product || false,
        following_local: following_local,
        pageSize: 6,
        page: page,
      };
      const responseData = await call({
        baseUrl: `/following/user-following-log`,
        method: 'POST',
        body: JSON.stringify(rawData),
      });

      if (page != 1) {
        const response = {
          ...responseData,
          data: [...fetch_stories_following_list?.data, ...responseData?.data],
          pagination: responseData?.pagination,
        };
        dispatch(_commonDispatcher(FETCH_STORIES_FOLLOWING_LIST, response));
        dispatch(_commonDispatcher(FETCH_STORIES_FOLLOWING_LIST_LOADER, false));
      } else {
        dispatch(_commonDispatcher(FETCH_STORIES_FOLLOWING_LIST, responseData));
        dispatch(_commonDispatcher(FETCH_STORIES_FOLLOWING_LIST_LOADER, false));
      }
      return 1;
    } catch (error) {
      dispatch(_commonDispatcher(FETCH_STORIES_FOLLOWING_LIST_LOADER, false));
      dispatch(
        _commonDispatcher(FETCH_STORIES_FOLLOWING_LIST_ERROR, error.message),
      );
      return 0;
    }
  };
};

export const _getStoreProducts = (
  shop_id,
  page = 1,
  without_redux = false,
  product_id,
) => {
  return async dispatch => {
    const {fetch_store_products} = getStoreState('merchant');
    const {fetch_user_detail} = getStoreState('auth');
    try {
      if (page === 1 && !without_redux) {
        dispatch(_commonDispatcher(FETCH_STORE_PRODUCT_DETAIL_LOADER, true));
      }
      dispatch(_commonDispatcher(FETCH_STORE_PRODUCTS_ERROR, ''));
      page == 1 &&
        !without_redux &&
        dispatch(_commonDispatcher(FETCH_STORE_PRODUCTS, {}));
      const rawData = {shop_id, user_id: fetch_user_detail?.id || ''};
      const responseData = await call({
        baseUrl: `/shops/shop-products?page=${page}&product_id=${
          product_id || ''
        }`,
        method: 'POST',
        body: JSON.stringify(rawData),
      });
      console.log('responseData =======>', responseData);
      // dispatch(_commonDispatcher(FETCH_STORE_PRODUCT_DETAIL_LOADER, false));
      // page == 1 &&
      //   dispatch(_commonDispatcher(FETCH_STORE_PRODUCTS, responseData));
      // dispatch(_commonDispatcher(FETCH_STORE_PRODUCTS_LOADER, false));

      if (page != 1) {
        const response = {
          ...responseData,
          data: {
            ...responseData?.data,
            shop: responseData?.data?.shop,
            products: [
              ...fetch_store_products?.data?.products,
              ...responseData?.data?.products,
            ],
          },
          pagination: responseData?.pagination,
        };
        !without_redux &&
          dispatch(_commonDispatcher(FETCH_STORE_PRODUCTS, response));
        dispatch(_commonDispatcher(FETCH_STORE_PRODUCTS_LOADER, false));
        dispatch(_commonDispatcher(FETCH_STORE_PRODUCT_DETAIL_LOADER, false));
        return 1;
      } else {
        !without_redux &&
          dispatch(_commonDispatcher(FETCH_STORE_PRODUCTS, responseData));
        dispatch(_commonDispatcher(FETCH_STORE_PRODUCTS_LOADER, false));
        dispatch(_commonDispatcher(FETCH_STORE_PRODUCT_DETAIL_LOADER, false));
        return responseData;
      }
    } catch (error) {
      if (shop_id != fetch_store_products?.data?.shop?.shop_id) {
        dispatch(_commonDispatcher(FETCH_STORE_PRODUCTS, {}));
      }
      dispatch(_commonDispatcher(FETCH_STORE_PRODUCT_DETAIL_LOADER, false));
      dispatch(_commonDispatcher(FETCH_STORE_PRODUCTS_LOADER, false));
      dispatch(_commonDispatcher(FETCH_STORE_PRODUCTS_ERROR, error.message));
      return 0;
    }
  };
};

export const _getStoreProductDetail = product_id => {
  return async dispatch => {
    try {
      const {fetch_user_detail} = getStoreState('auth');
      dispatch(_commonDispatcher(FETCH_STORE_PRODUCT_DETAIL_ERROR, ''));
      dispatch(_commonDispatcher(FETCH_STORE_PRODUCT_DETAIL_LOADER, true));
      const rawData = {product_id};
      const responseData = await call({
        baseUrl: `/products/product-detail?product_id=${product_id}&user_id=${fetch_user_detail?.id}`,
        method: 'GET',
      });

      const data = responseData.data;
      dispatch(_commonDispatcher(FETCH_STORE_PRODUCT_DETAIL, data));
      dispatch(_commonDispatcher(FETCH_STORE_PRODUCT_DETAIL_LOADER, false));
      return data;
    } catch (error) {
      dispatch(_commonDispatcher(FETCH_STORE_PRODUCT_DETAIL_LOADER, false));
      dispatch(
        _commonDispatcher(FETCH_STORE_PRODUCT_DETAIL_ERROR, error.message),
      );
      return 0;
    }
  };
};

export const _getBrandSearchProducts = (shop_id, page = 1) => {
  return async dispatch => {
    const {brand_search_products} = getStoreState('merchant');
    try {
      dispatch(_commonDispatcher(FETCH_BRAND_SEARCH_PRODUCTS_ERROR, ''));
      page == 1 &&
        dispatch(_commonDispatcher(FETCH_BRAND_SEARCH_PRODUCTS_LOADER, true));
      const rawData = {shop_id};
      const responseData = await call({
        baseUrl: `/shops/shop-products?page=${page}`,
        method: 'POST',
        body: JSON.stringify(rawData),
      });
      if (page != 1) {
        const response = {
          ...responseData,
          data: {
            shop: responseData?.data?.shop,
            products: [
              ...brand_search_products?.data?.products,
              ...responseData?.data?.products,
            ],
          },
          pagination: responseData?.pagination,
        };
        dispatch(_commonDispatcher(FETCH_BRAND_SEARCH_PRODUCTS, response));
      } else {
        dispatch(_commonDispatcher(FETCH_BRAND_SEARCH_PRODUCTS, responseData));
      }
      dispatch(_commonDispatcher(FETCH_BRAND_SEARCH_PRODUCTS_LOADER, false));
      return responseData;
    } catch (error) {
      dispatch(_commonDispatcher(FETCH_BRAND_SEARCH_PRODUCTS_LOADER, false));
      dispatch(
        _commonDispatcher(FETCH_BRAND_SEARCH_PRODUCTS_ERROR, error.message),
      );
      return 0;
    }
  };
};

export const _getStoreProductDetailReview = product_id => {
  return async dispatch => {
    try {
      const {fetch_user_detail} = getStoreState('auth');
      const responseData = await call({
        baseUrl: `/review/product/${product_id}?userId=${fetch_user_detail?.id}`,
        method: 'GET',
      });
      const data = responseData.productReviews;
      return data;
    } catch (error) {
      return 0;
    }
  };
};

export const getRelatedStore = shop_id => {
  return async dispatch => {
    try {
      const {fetch_user_detail} = getStoreState('auth');
      const rawData = {shop_id, user_id: fetch_user_detail?.id || false};

      const responseData = await call({
        baseUrl: `/shops/shop-related`,
        method: 'POST',
        body: JSON.stringify(rawData),
      });
      const data = responseData.data || [];
      return data;
    } catch (error) {
      console.log('object', error?.message);
      return 0;
    }
  };
};

export const _getShopCollections = shop_id => {
  return async dispatch => {
    try {
      const rating = filterObject('brand_collection', 'ratings', 'main_search');
      dispatch(_commonDispatcher(FETCH_STORE_COLLECTION_LOADER, true));
      dispatch(_commonDispatcher(FETCH_STORE_COLLECTION_ERROR, ''));

      const responseData = await call({
        baseUrl: `/shops/collection?shopId=${shop_id}&collectionTypeId=1`,
        // baseUrl: `/shops/collection?shopId=16&collectionTypeId=1`,
        method: 'GET',
      });
      const data = responseData.data || [];
      dispatch(_commonDispatcher(FETCH_STORE_COLLECTION, data));
      dispatch(_commonDispatcher(FETCH_STORE_COLLECTION_LOADER, false));
      return 1;
    } catch (error) {
      dispatch(_commonDispatcher(FETCH_STORE_COLLECTION, []));
      dispatch(_commonDispatcher(FETCH_STORE_COLLECTION_LOADER, false));
      dispatch(_commonDispatcher(FETCH_STORE_COLLECTION_ERROR, error?.message));
      console.log('object', error?.message);
      return 0;
    }
  };
};

export const _getShopSingleCollection = (
  shop_collection_id,
  page,
  collection_type_id,
  collection_shop_id,
) => {
  return async dispatch => {
    try {
      const {fetch_store_single_collection} = getStoreState('merchant');

      const maxPrice = filterObject('brand_collection', 'price');
      const rating = filterObject('brand_collection', 'ratings', 'main_search');
      const sortBy = filterObject(
        'brand_collection',
        'sort_by',
        'collection_filter',
      );
      const sortByPrice = filterObject(
        'brand_collection',
        'sort_by',
        'collection_price_filter',
      );

      if (page == 1) {
        dispatch(_commonDispatcher(FETCH_STORE_SINGLE_COLLECTION_LOADER, true));
      }

      const responseData = await call({
        baseUrl: `/shops/collection/${shop_collection_id}?sortOrder=${
          Array.isArray(sortBy) && sortBy?.[0] ? sortBy?.[0] : ''
        }&sortBy=${
          Array.isArray(sortBy) && sortBy?.[1] ? sortBy?.[1] : ''
        }&minPrice=${Array.isArray(maxPrice) ? maxPrice?.[0] : '0'}&maxPrice=${
          Array.isArray(maxPrice) ? maxPrice?.[1] : '1000000000000000'
        }&minRating=${rating || ''}&page=${page}&sortPrice=${
          sortByPrice || ''
        }&collection_type_id=${collection_type_id || ''}&collection_shop_id=${
          collection_shop_id || ''
        }`,
        // baseUrl: `/shops/filter-products?filterId=${shopify_collection_id}&shopId=${shop_id}&endCursor=${
        //   endCursor || ''
        // }`,
        method: 'GET',
      });

      const data = responseData.data || {};

      if (page != 1) {
        const response = {
          ...responseData,
          data: {
            ...fetch_store_single_collection?.data,
            products: [
              ...fetch_store_single_collection?.data?.products,
              ...responseData?.data?.products,
            ],
          },
          pagination: responseData?.pagination,
        };

        // Dispatch to the store
        dispatch(_commonDispatcher(FETCH_STORE_SINGLE_COLLECTION, response));
        dispatch(
          _commonDispatcher(FETCH_STORE_SINGLE_COLLECTION_LOADER, false),
        );
        dispatch(_commonDispatcher(FETCH_STORE_SINGLE_COLLECTION_ERROR, ''));
        return 1;
      } else {
        dispatch(
          _commonDispatcher(FETCH_STORE_SINGLE_COLLECTION, responseData),
        );
        dispatch(
          _commonDispatcher(FETCH_STORE_SINGLE_COLLECTION_LOADER, false),
        );
        dispatch(_commonDispatcher(FETCH_STORE_SINGLE_COLLECTION_ERROR, ''));
        return 1;
      }
    } catch (error) {
      console.log('error =>', error?.message);
      dispatch(_commonDispatcher(FETCH_STORE_SINGLE_COLLECTION, {}));
      dispatch(_commonDispatcher(FETCH_STORE_SINGLE_COLLECTION_LOADER, false));
      dispatch(_commonDispatcher(FETCH_STORE_SINGLE_COLLECTION_ERROR, ''));
      dispatch(
        _commonDispatcher(FETCH_STORE_SINGLE_COLLECTION_ERROR, error?.message),
      );
      return 0;
    }
  };
};

export const _getTrendingCollection = () => {
  return async dispatch => {
    try {
      dispatch(_commonDispatcher(FETCH_TRENDING_COLLECTION_LOADER, true));
      dispatch(_commonDispatcher(FETCH_TRENDING_COLLECTION_ERROR, ''));

      const responseData = await call({
        baseUrl: `/shops/trending-collections`,
        method: 'GET',
      });

      console.log('first', responseData?.data);

      dispatch(
        _commonDispatcher(FETCH_TRENDING_COLLECTION, responseData?.data),
      );
      dispatch(_commonDispatcher(FETCH_TRENDING_COLLECTION_LOADER, false));

      return 1;
    } catch (error) {
      console.log('error =>', error?.message);
      dispatch(_commonDispatcher(FETCH_TRENDING_COLLECTION_LOADER, false));
      dispatch(
        _commonDispatcher(FETCH_TRENDING_COLLECTION_ERROR, error?.message),
      );
      return 0;
    }
  };
};

export const _getTrendingSingleCollection = (collection_id, page) => {
  return async dispatch => {
    try {
      const {fetch_store_single_collection} = getStoreState('merchant');
      const maxPrice = filterObject('trending_collection_screen', 'price');
      const rating = filterObject(
        'trending_collection_screen',
        'ratings',
        'main_search',
      );
      const sortBy = filterObject(
        'trending_collection_screen',
        'sort_by',
        'collection_filter',
      );
      const sortByPrice = filterObject(
        'trending_collection_screen',
        'sort_by',
        'collection_price_filter',
      );

      if (page == 1) {
        dispatch(_commonDispatcher(FETCH_STORE_SINGLE_COLLECTION_LOADER, true));
      }

      const responseData = await call({
        baseUrl: `/shops/trending-collection/${collection_id}?sortOrder=${
          Array.isArray(sortBy) && sortBy?.[0] ? sortBy?.[0] : ''
        }&sortBy=${
          Array.isArray(sortBy) && sortBy?.[1] ? sortBy?.[1] : ''
        }&minPrice=${Array.isArray(maxPrice) ? maxPrice?.[0] : '0'}&maxPrice=${
          Array.isArray(maxPrice) ? maxPrice?.[1] : '1000000000000000'
        }&minRating=${rating || ''}&page=${page}&sortPrice=${
          sortByPrice || ''
        }`,
        // baseUrl: `/shops/filter-products?filterId=${shopify_collection_id}&shopId=${shop_id}&endCursor=${
        //   endCursor || ''
        // }`,
        method: 'GET',
      });

      const data = responseData.data || {};

      if (page != 1) {
        const response = {
          ...responseData,
          data: {
            // shop: responseData?.data?.shop,
            ...responseData?.data,
            products: [
              ...fetch_store_single_collection?.data?.products,
              ...responseData?.data?.products,
            ],
          },
          pagination: responseData?.pagination,
        };

        // Dispatch to the store
        dispatch(_commonDispatcher(FETCH_STORE_SINGLE_COLLECTION, response));
        dispatch(
          _commonDispatcher(FETCH_STORE_SINGLE_COLLECTION_LOADER, false),
        );
        dispatch(_commonDispatcher(FETCH_STORE_SINGLE_COLLECTION_ERROR, ''));
        return 1;
      } else {
        dispatch(
          _commonDispatcher(FETCH_STORE_SINGLE_COLLECTION, responseData),
        );
        dispatch(
          _commonDispatcher(FETCH_STORE_SINGLE_COLLECTION_LOADER, false),
        );
        dispatch(_commonDispatcher(FETCH_STORE_SINGLE_COLLECTION_ERROR, ''));
        return 1;
      }
    } catch (error) {
      console.log('error =>', error?.message);
      dispatch(_commonDispatcher(FETCH_STORE_SINGLE_COLLECTION, {}));
      dispatch(_commonDispatcher(FETCH_STORE_SINGLE_COLLECTION_LOADER, false));
      dispatch(
        _commonDispatcher(FETCH_STORE_SINGLE_COLLECTION_ERROR, error?.message),
      );
      return 0;
    }
  };
};

export const _subCategoryProducts = ({
  collectionId,
  page = 1,
  subCategory,
  shopId,
  collection_type,
}) => {
  return async () => {
    try {
      const responseData = await call({
        baseUrl: `/products/filter/product-categories?collectionType_id=${
          collection_type || ''
        }&category_name=${encodeURIComponent(subCategory)}&collection_id=${
          collectionId == 'ALL' ? '' : collectionId || ''
        }&page=${page}&shop_id=${collectionId == 'ALL' ? shopId : ''}`,
        // baseUrl: `/product-categories?collection_type=&category_name=Ankle%20Socks&collection_id=&page=${page}&shop_id=116`,
        method: 'GET',
      });

      return {
        products: responseData?.data?.Products || [],
        productCategories: responseData?.data?.productCategories || [],
        pagination: {
          totalPages: responseData?.pagination?.totalPages || 1,
          currentPage: responseData?.pagination?.currentPage || page,
        },
      };
    } catch (error) {
      return {
        products: [],
        pagination: {totalPages: 1, currentPage: page},
      };
    }
  };
};

export const _getFilteredByCollectionId = (
  collectionId,
  page = 1,
  subCategory,
  shopId,
) => {
  return async dispatch => {
    try {
      if (subCategory) {
        // Dispatch the subcategory products action
        const responseData = await dispatch(
          _subCategoryProducts({
            collectionId,
            shopId,
            subCategory,
            page,
          }),
        );

        return {
          products: responseData?.products,
          pagination: responseData?.pagination,
          productCategories: responseData?.productCategories,
          // productCategories: [],
        };
      } else {
        // Call API directly without dispatch
        const baseUrl = `/shops/filtered-collection/${collectionId}?page=${page}`;
        const responseData = await call({
          baseUrl,
          method: 'GET',
        });

        console.log('baseUrl', responseData?.data);
        return {
          products: responseData?.data?.products || [],
          productCategories: responseData?.data?.productCategories || [],
          pagination: {
            totalPages: responseData?.data?.totalPages || 1,
            currentPage: responseData?.data?.currentPage || page,
          },
        };
      }
    } catch (error) {
      console.error(
        'Error fetching filter products by collection:',
        error?.message,
      );
      return {
        products: [],
        pagination: {totalPages: 1, currentPage: page},
        productCategories: [],
      };
    }
  };
};

export const _createNotificationPreference = payload => {
  return async dispatch => {
    try {
      const res = await call({
        baseUrl: '/notification-preference/create',
        method: 'POST',
        body: JSON.stringify(payload),
      });
      return res;
    } catch (e) {
      throw e;
    }
  };
};

export const _reportItem = ({
  reason = '',
  subReason = '',
  note = '',
  id = '',
  type = 'product',
}) => {
  return async dispatch => {
    const {fetch_user_detail} = getStoreState('auth');
    const payload = {
      reported_type: type,
      reported_reference_id: id,
      reported_by_user_id: fetch_user_detail?.id,
      reason_main: reason,
      reason_sub: subReason,
      reason_other_text: note,
    };

    console.log('JSON.stringify(payload)', JSON.stringify(payload));

    try {
      const res = await call({
        baseUrl: '/reports',
        method: 'POST',
        body: JSON.stringify(payload),
      });
      showToast(res?.message);
      return 1;
    } catch (error) {
      showToast(error?.message);
      return 0;
    }
  };
};
