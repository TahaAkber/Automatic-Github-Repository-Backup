import {_commonDispatcher, _uploadImage} from '../common/common';
import {call} from '@helper/reUsableMethod/reUsableMethod';
import {getStoreState} from '@utils/helper/helper';
import {
  FETCH_CONNECTED_ACCOUNT,
  FETCH_CONNECTED_ACCOUNT_ERROR,
  FETCH_CONNECTED_ACCOUNT_LOADER,
  FETCH_INTERNAL_ORDER,
  FETCH_INTERNAL_ORDER_ERROR,
  FETCH_INTERNAL_ORDER_LOADER,
  CANCEL_ORDER,
  CANCEL_ORDER_LOADER,
  CANCEL_ORDER_ERROR,
  FETCH_CANCELLATION_ENUMS,
  FETCH_CANCELLATION_ENUMS_LOADER,
  FETCH_CANCELLATION_ENUMS_ERROR,
  FETCH_ACTIVE_ORDER_ERROR,
  FETCH_ACTIVE_ORDER,
  FETCH_ACTIVE_ORDER_LOADER,
  FETCH_ORDER_DETAIL,
  FETCH_ORDER_DETAIL_LOADER,
  FETCH_ORDER_DETAIL_ERROR,
  FETCH_TRACKING,
  FETCH_TRACKING_ERROR,
  FETCH_TRACKING_SERVICES,
} from '../../types/orders/orders';
import {showToast} from '../../../helper/reUsableMethod/reUsableMethod';

export const _connectSocialAccount = (
  social_id,
  social_email,
  social_type,
  server_auth_token,
) => {
  return async dispatch => {
    const {fetch_user_detail} = getStoreState('auth');
    try {
      const rawData = {
        user_id: fetch_user_detail?.id,
        social_id: social_id,
        social_email: social_email,
        social_type: social_type,
        server_auth_token: server_auth_token,
      };
      const responseData = await call({
        // baseUrl: `/social-account/create-social-account-log`, //api from ayan
        baseUrl: `/api/auth/google/connect-mobile`,
        method: 'POST',
        body: JSON.stringify(rawData),
        ai_url: true,
      });
      await dispatch(_getConnectedAccounts());
      const data = responseData;

      return data;
    } catch (error) {
      console.log('error', error?.message);
      return 0;
    }
  };
};

export const _removeConnectedAccount = link_connect_id => {
  return async dispatch => {
    try {
      const rawData = {
        link_connect_id: link_connect_id,
      };
      const responseData = await call({
        // baseUrl: `/social-account/remove-social-account-log`,
        baseUrl: `/api/auth/google/remove-connection`,
        method: 'POST',
        body: JSON.stringify(rawData),
        ai_url: true,
      });
      await dispatch(_getConnectedAccounts());
      const data = responseData;
      return data;
    } catch (error) {
      console.log('error', error?.message);
      return 0;
    }
  };
};

export const _getConnectedAccounts = () => {
  return async dispatch => {
    const {fetch_user_detail} = getStoreState('auth');
    dispatch({type: FETCH_CONNECTED_ACCOUNT_LOADER, payload: true});
    dispatch({type: FETCH_CONNECTED_ACCOUNT_ERROR, payload: ''});
    try {
      const rawData = {
        user_id: fetch_user_detail?.id,
      };
      const responseData = await call({
        baseUrl: `/api/auth/google/get-connections`,
        method: 'POST',
        body: JSON.stringify(rawData),
        ai_url: true,
      });
      const data = responseData;

      dispatch({type: FETCH_CONNECTED_ACCOUNT, payload: responseData?.data});
      dispatch({type: FETCH_CONNECTED_ACCOUNT_LOADER, payload: false});
      return data;
    } catch (error) {
      dispatch({type: FETCH_CONNECTED_ACCOUNT, payload: []});
      dispatch({type: FETCH_CONNECTED_ACCOUNT_ERROR, payload: error?.message});
      dispatch({type: FETCH_CONNECTED_ACCOUNT_LOADER, payload: false});
      console.log('error =>', error?.message);
      return 0;
    }
  };
};

export const _getInternalOrder = ({page, tab, pull = false}) => {
  return async dispatch => {
    const {fetch_user_detail} = getStoreState('auth');
    const {fetch_internal_order} = getStoreState('order');
    if (fetch_user_detail?.id) {
      !pull && dispatch({type: FETCH_INTERNAL_ORDER_LOADER, payload: true});
      // dispatch({type: FETCH_INTERNAL_ORDER, payload: {}});

      try {
        const responseData = await call({
          // baseUrl: `/order/get-orders?page=${page}&user_id=${53}&status=${tab}&pageSize=10`,
          baseUrl: `/order/get-orders?page=${page}&user_id=${fetch_user_detail?.id}&status=${tab}&pageSize=10`,
          method: 'GET',
        });
        if (page === 1) {
          let updatedResponse = responseData;
          if (pull) {
            const previousData = fetch_internal_order?.[tab]?.data || [];
            const updatedData = [
              ...responseData.data.slice(
                0,
                responseData?.pagination?.pageSize || 0,
              ),
              ...previousData.slice(responseData?.pagination?.pageSize || 0),
            ];
            updatedResponse = {...responseData, data: updatedData};
          }

          const data = {...fetch_internal_order, [tab]: updatedResponse};
          dispatch({type: FETCH_INTERNAL_ORDER, payload: data});
          dispatch({type: FETCH_INTERNAL_ORDER_ERROR, payload: ''});
        } else {
          let previousData = fetch_internal_order?.[tab]?.data || [];
          let updatedData = [...previousData, ...responseData.data];

          const updatedResponse = {...responseData, data: updatedData};
          const data = {...fetch_internal_order, [tab]: updatedResponse};
          dispatch({type: FETCH_INTERNAL_ORDER, payload: data});
          dispatch({type: FETCH_INTERNAL_ORDER_ERROR, payload: ''});
        }
        dispatch({type: FETCH_INTERNAL_ORDER_ERROR, payload: ''});
        dispatch({type: FETCH_INTERNAL_ORDER_LOADER, payload: false});
      } catch (error) {
        const data = {...fetch_internal_order, [tab]: {data: []}};
        dispatch({type: FETCH_INTERNAL_ORDER, payload: data});
        dispatch({type: FETCH_INTERNAL_ORDER_ERROR, payload: error?.message});
        dispatch({type: FETCH_INTERNAL_ORDER_LOADER, payload: false});
        console.log('error', error?.message);
        return 0;
      }
    }
  };
};

const updateCancelledOrdersByShopifyId = (
  ordersData,
  shopifyOrderId,
  tabId,
) => {
  let updatedOrdersData = {...ordersData};

  const findOrder = updatedOrdersData?.[tabId]?.data?.find(
    item => item?.order_shopify_id == shopifyOrderId,
  );
  findOrder.order_cancelled_by = 'customer';

  return updatedOrdersData;
};

export const _cancelOrder = (
  shop_id,
  shopify_order_id,
  reason = 'CUSTOMER',
  staff_note = '',
  orderCancelReason,
  tabId,
) => {
  return async dispatch => {
    dispatch({type: CANCEL_ORDER_LOADER, payload: true});

    const {fetch_internal_order} = getStoreState('order');

    try {
      const rawData = {
        shop_id,
        shopify_order_id,
        reason: 'CUSTOMER',
        staff_note: orderCancelReason || staff_note,
      };
      // const rawData = { shop_id, shopify_order_id, reason: reason, staff_note };

      const responseData = await call({
        baseUrl: `/order/order-cancellation`,
        method: 'POST',
        body: JSON.stringify(rawData),
      });
      // await dispatch(_getInternalOrder({ page: 1 }));
      const updatedArr = updateCancelledOrdersByShopifyId(
        fetch_internal_order,
        shopify_order_id,
        tabId,
      );

      showToast('Order Cancelled Successfully.');
      dispatch({type: CANCEL_ORDER_LOADER, payload: false});
      dispatch({type: FETCH_INTERNAL_ORDER, payload: updatedArr});
      return 1;
    } catch (error) {
      showToast(error?.message);
      dispatch({type: CANCEL_ORDER_ERROR, payload: error.message});
      dispatch({type: CANCEL_ORDER_LOADER, payload: false});
      return 0;
    }
  };
};

export const _getCancellationEnums = (shop_id = 2) => {
  return async (dispatch, getState) => {
    const {fetch_cancellation_enums} = getState('order');

    // ✅ If enums are already loaded, no need to fetch again
    if (fetch_cancellation_enums.length > 0) {
      return;
    }

    dispatch({type: FETCH_CANCELLATION_ENUMS_LOADER, payload: true});

    try {
      const responseData = await call({
        baseUrl: '/order/get-cancellation-enums',
        method: 'POST',
        body: {shop_id},
      });

      dispatch({type: FETCH_CANCELLATION_ENUMS, payload: responseData.data});

      return res;
    } catch (error) {
      console.error(' Cancellation Enums API Error:', error?.message);
      dispatch({type: FETCH_CANCELLATION_ENUMS_ERROR, payload: error?.message});
    } finally {
      dispatch({type: FETCH_CANCELLATION_ENUMS_LOADER, payload: false});
    }
  };
};
// export const updateOrderItemReviewStatus = orderItemId => {
//   return async (dispatch, getState) => {
//     const {fetch_internal_order} = getState('order'); // Get the current state of orders

//     // Clone the current state to avoid mutating the original state
//     const updatedOrders = {...fetch_internal_order};

//     // Iterate through the orders and update the specific order item's review_completed status
//     Object.keys(updatedOrders).forEach(key => {
//       const orderList = updatedOrders[key]?.data || [];
//       updatedOrders[key] = {
//         ...updatedOrders[key],
//         data: orderList.map(order => {
//           // Check if the order contains the order_item to update
//           if (order.order_item && order.order_item.length > 0) {
//             const updatedOrderItems = order.order_item.map(item => {
//               if (item.order_item_id === orderItemId) {
//                 return {...item, review_completed: true}; // Update the review_completed status
//               }
//               return item;
//             });

//             return {...order, order_item: updatedOrderItems}; // Return the updated order
//           }
//           return order; // Return the order as is if no order_item exists
//         }),
//       };
//     });

//     console.log('Updated Orders:', updatedOrders);

//     dispatch({
//       type: FETCH_INTERNAL_ORDER,
//       payload: updatedOrders,
//     });
//   };
// };
export const _getActiveOrders = () => {
  return async dispatch => {
    const {fetch_user_detail} = getStoreState('auth');
    dispatch({type: FETCH_ACTIVE_ORDER_ERROR, payload: ''});

    if (!fetch_user_detail?.id) {
      return;
    }

    try {
      dispatch({type: FETCH_ACTIVE_ORDER_LOADER, payload: true});

      const responseData = await call({
        baseUrl: `/order/order-active?user_id=${fetch_user_detail.id}`,
        method: 'GET',
      });

      dispatch({
        type: FETCH_ACTIVE_ORDER,
        payload: responseData.data,
      });

      dispatch({type: FETCH_ACTIVE_ORDER_LOADER, payload: false});

      return responseData;
    } catch (error) {
      dispatch({type: FETCH_ACTIVE_ORDER_ERROR, payload: error?.message});
      dispatch({type: FETCH_ACTIVE_ORDER_LOADER, payload: false});

      console.error('Error fetching active orders:', error);
      return;
    }
  };
};

export const _getOrderDetail = (order_id, tracking_id, table_id) => {
  return async dispatch => {
    const {fetch_user_detail} = getStoreState('auth');
    try {
      dispatch({type: FETCH_ORDER_DETAIL_ERROR, payload: ''});
      dispatch({type: FETCH_ORDER_DETAIL_LOADER, payload: true});
      dispatch({type: FETCH_ORDER_DETAIL, payload: {}});

      const responseData = await call({
        baseUrl: table_id
          ? `/api/orders/${table_id}`
          : `/order/order-details?order_id=${order_id}&mobile_app=true&tracking_id=${
              tracking_id || ''
            }`,
        method: table_id ? 'POST' : 'GET',
        ai_second_url: table_id ? true : false,
        body: table_id
          ? JSON.stringify({user_id: fetch_user_detail?.id})
          : false,
      });

      dispatch({type: FETCH_ORDER_DETAIL_ERROR, payload: ''});
      dispatch({type: FETCH_ORDER_DETAIL, payload: responseData?.data});
      dispatch({type: FETCH_ORDER_DETAIL_LOADER, payload: false});

      return 1;
    } catch (error) {
      console.log('responseData', error?.message);
      dispatch({type: FETCH_ORDER_DETAIL_LOADER, payload: false});
      dispatch({type: FETCH_ORDER_DETAIL, payload: {}});
      dispatch({type: FETCH_ORDER_DETAIL_ERROR, payload: error?.message});
      return 0;
    }
  };
};

export const _getOrderReceipt = order_id => {
  return async dispatch => {
    try {
      const responseData = await call({
        baseUrl: `/order/order-receipt?order_id=${order_id}`,
        method: 'GET',
      });
      return responseData?.data;
    } catch (error) {
      console.log('error =>', error?.message);
      return 0;
    }
  };
};

export const _getLatestOrderDetail = (shop_id, order_email) => {
  return async dispatch => {
    try {
      const {fetch_user_detail} = getStoreState('auth');
      const isUpdate = Boolean(order_email == fetch_user_detail?.email);
      const responseData = await call({
        // baseUrl: `/order/latest-order?user_id=${fetch_user_detail?.id}&shop_id=${shop_id}`,
        baseUrl: `/order/latest-order?user_id=${
          fetch_user_detail?.id
        }&shop_id=${shop_id}&update=${
          !isUpdate ? true : false
        }&order_email=${order_email}`,
        method: 'GET',
      });
      await dispatch(_getInternalOrder({page: 1, tab: 1, pull: false}));
      return responseData?.data;
    } catch (error) {
      return 0;
    }
  };
};

export const _getTrackings = (page = 1) => {
  return async dispatch => {
    const {fetch_user_detail} = getStoreState('auth');
    const {fetch_tracking} = getStoreState('order');
    if (fetch_user_detail?.id) {
      try {
        const responseData = await call({
          // baseUrl: `/tracking/custom-trackings?user_id=${50}&page=${page}&page_size=1`,
          baseUrl: `/tracking/custom-trackings?user_id=${fetch_user_detail?.id}&page=${page}`,
          method: 'GET',
        });

        console.log('responseData', responseData);

        if (page != 1) {
          const response = {
            ...responseData,
            data: [...fetch_tracking?.data, ...(responseData?.data || [])],
          };
          dispatch(_commonDispatcher(FETCH_TRACKING, response));
          dispatch(_commonDispatcher(FETCH_TRACKING_ERROR, ''));
          return 1;
        } else {
          dispatch(_commonDispatcher(FETCH_TRACKING, responseData));
          dispatch(_commonDispatcher(FETCH_TRACKING_ERROR, ''));
        }
        return 1;
      } catch (error) {
        dispatch(_commonDispatcher(FETCH_TRACKING, {}));
        dispatch(_commonDispatcher(FETCH_TRACKING_ERROR, error?.message || ''));
        return 0;
      }
    }
  };
};

export const _addTracking = (service, trackingNumber, packageName) => {
  return async dispatch => {
    const {fetch_user_detail} = getStoreState('auth');
    const {fetch_tracking} = getStoreState('order');
    if (fetch_user_detail?.id) {
      const rawData = {
        tracking_number: trackingNumber,
        courier: service,
        tracking_name: packageName,
        user_id: fetch_user_detail?.id,
      };
      try {
        const responseData = await call({
          baseUrl: `/tracking/add-custom-tracking`,
          method: 'POST',
          body: JSON.stringify(rawData),
        });
        dispatch(_getTrackings(1));
        return responseData?.custom_tracking_id;
      } catch (error) {
        showToast(error?.message);
        return 0;
      }
    }
  };
};

export const _getTrackingDetail = custom_tracking_id => {
  return async dispatch => {
    const {fetch_user_detail} = getStoreState('auth');
    if (fetch_user_detail?.id) {
      try {
        const responseData = await call({
          baseUrl: `/tracking/custom-tracking?custom_tracking_id=${custom_tracking_id}`,
          method: 'GET',
        });
        return responseData?.custom_tracking;
      } catch (error) {
        showToast(error?.message);
        return 0;
      }
    }
  };
};

export const _removeTracking = custom_tracking_id => {
  return async dispatch => {
    const {fetch_user_detail} = getStoreState('auth');
    const {fetch_tracking} = getStoreState('order');
    if (fetch_user_detail?.id) {
      try {
        await call({
          baseUrl: `/tracking/custom-tracking?tracking_id=${custom_tracking_id}`,
          method: 'DELETE',
        });
        const response = {
          ...fetch_tracking,
          data: (fetch_tracking?.data || [])?.filter(
            (item, index) => item?.manual_tracking_id != custom_tracking_id,
          ),
        };
        dispatch(_commonDispatcher(FETCH_TRACKING, response));
        return 1;
      } catch (error) {
        showToast(error?.message);
        return 0;
      }
    }
  };
};

export const _geTrackingServices = () => {
  return async dispatch => {
    try {
      const responseData = await call({
        baseUrl: `/tracking/couriers`,
        method: 'GET',
      });
      const data = (responseData?.data || [])?.map(item => {
        return {
          id: item?.courier_id || '',
          value: item?.courier_name || '',
          image_url: item?.courier_image_url || '',
        };
      });
      console.log('data', data);
      dispatch(_commonDispatcher(FETCH_TRACKING_SERVICES, data));
      return data[0].id || 0;
    } catch (error) {
      showToast(error?.message);
      dispatch(_commonDispatcher(FETCH_TRACKING_SERVICES, []));
      return 0;
    }
  };
};
