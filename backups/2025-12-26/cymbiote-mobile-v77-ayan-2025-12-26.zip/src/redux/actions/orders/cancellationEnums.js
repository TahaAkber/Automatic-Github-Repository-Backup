import {_commonDispatcher} from '../common/common';
import {call} from '@helper/reUsableMethod/reUsableMethod';
import {
  FETCH_CANCELLATION_ENUMS,
  FETCH_CANCELLATION_ENUMS_LOADER,
  FETCH_CANCELLATION_ENUMS_ERROR,
} from '../../types/orders/orders';

export const _getCancellationEnums = (shop_id = 2) => {
  return async (dispatch, getState) => {
    const {fetch_cancellation_enums} = getState('order');

    // ✅ If enums are already loaded, no need to fetch again
    if (fetch_cancellation_enums.length > 0) {
     
      return;
    }

    dispatch({type: FETCH_CANCELLATION_ENUMS_LOADER, payload: true});

    try {

      const responseData = await call({
        baseUrl: '/order/get-cancellation-enums',
        method: 'POST',
        body: {shop_id},
      });

      console.log(' API Response:', responseData);

      dispatch({type: FETCH_CANCELLATION_ENUMS, payload: responseData.data});

      return res;
    } catch (error) {
      console.error(' Cancellation Enums API Error:', error?.message);
      dispatch({type: FETCH_CANCELLATION_ENUMS_ERROR, payload: error?.message});
    } finally {
      dispatch({type: FETCH_CANCELLATION_ENUMS_LOADER, payload: false});
    }
  };
};

// export const _getCancellationEnums = (shop_id = 2) => {
//     return async (dispatch, getState) => {
//         const { fetch_cancellation_enums } = getState().order;

//         // ✅ Prevent unnecessary API calls if data is already available
//         if (fetch_cancellation_enums.length > 0) {
//             console.log("✅ Cancellation enums already loaded.");
//             return;
//         }

//         dispatch({ type: FETCH_CANCELLATION_ENUMS_LOADER, payload: true });

//         try {
//             // console.log("📡 Sending API Request: /api/order/get-cancellation-enums");
//             // console.log("🔹 Request Body:", { shop_id });

//             const responseData = await call({
//                 baseUrl: "/api/order/get-cancellation-enums",
//                 method: "POST",
//                 body: { shop_id }
//             });

//             console.log("✅ API Response:", responseData);

//             if (responseData?.status === 200 && responseData?.data?.length > 0) {
//                 dispatch({ type: FETCH_CANCELLATION_ENUMS, payload: responseData.data });
//             } else {
//                 throw new Error(responseData?.message || "Unknown API error");
//             }
//         } catch (error) {
//             // console.error("❌ Cancellation Enums API Error:", error?.message);
//             dispatch({ type: FETCH_CANCELLATION_ENUMS_ERROR, payload: error?.message });
//         } finally {
//             dispatch({ type: FETCH_CANCELLATION_ENUMS_LOADER, payload: false });
//         }
//     };
// };
