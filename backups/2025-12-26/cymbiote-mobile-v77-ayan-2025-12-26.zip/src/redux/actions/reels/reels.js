import {_commonDispatcher} from '../common/common';
import {
  FETCH_LATEST_REEL,
  FETCH_LATEST_REEL_ERROR,
  FETCH_LATEST_REEL_LOADER,
  FETCH_MERCHANT_REELS,
  FETCH_REELS,
  FETCH_REELS_ERROR,
  FETCH_REELS_LOADER,
  FETCH_REELS_PAGINATION,
  FETCH_SHOP_DATA,
  FETCH_SHOP_REELS,
  FETCH_SHOP_REELS_ERROR,
  FETCH_SHOP_REELS_LOADER,
  FETCH_SHOP_REELS_PAGINATION,
  FETCH_SHOP_SAVED_REELS,
  FETCH_STORIES,
  FETCH_USER_SAVED_REELS,
  FETCH_USER_SAVED_REELS_ERROR,
  FETCH_USER_SAVED_REELS_LOADER,
  UPDATE_SHOP_REEL,
} from '../../types/reels/reels';
import {call, showToast} from '../../../helper/reUsableMethod/reUsableMethod';
import {getStoreState} from '../../../utils/helper/helper';

export const _getReels = ({page = 1, user_id, shop_id}) => {
  return async dispatch => {
    try {
      dispatch({type: FETCH_REELS_LOADER, payload: true});

      const responseData = await call({
        baseUrl: `/shops/shop-reel?page=${page}&user_id=${user_id}`,
        method: 'POST',
        body: JSON.stringify({shop_id}),
      });

      // console.log("Full API Response:", JSON.stringify(responseData, null, 2));
      if (
        !responseData.data ||
        !responseData.data.products ||
        !responseData.data.shop
      ) {
        throw new Error(
          'Invalid API response: Missing `data.products` or `data.shop`',
        );
      }
      // ✅ Extract products (Reels)
      const reelsData = responseData.data.products || [];
      const shopData = responseData.data.shop || {};
      const pagination = responseData.pagination || {};

      console.log('Extracted Reels Data:', reelsData);
      console.log('✅ Extracted Shop Data:', shopData);
      console.log('Pagination Info:', pagination);

      if (page === 1) {
        dispatch({type: FETCH_REELS, payload: reelsData});
        dispatch({type: FETCH_SHOP_DATA, payload: shopData}); // ✅ Store Shop Data Separately
      } else {
        dispatch({type: FETCH_REELS_PAGINATION, payload: reelsData});
      }

      dispatch({type: FETCH_REELS_LOADER, payload: false});

      return {reelsData, pagination};
    } catch (error) {
      console.error('Error fetching reels:', error.message);
      dispatch({type: FETCH_REELS_LOADER, payload: false});
      dispatch({type: FETCH_REELS_ERROR, payload: error.message});
      return 0;
    }
  };
};
export const _getLatestReels = ({offset}) => {
  return async dispatch => {
    try {
      console.log(`Fetching latest reels with offset: ${offset}`);

      dispatch({type: FETCH_LATEST_REEL_LOADER, payload: true});

      const responseData = await call({
        baseUrl: `/reels-stories/latest-reel?offset=0`,
        method: 'GET',
      });

      if (!responseData.data || !responseData.data.video_url) {
        throw new Error('Invalid API response: Missing `data.video_url`');
      }

      console.log('Extracted Latest Reel:', responseData.data);

      dispatch({type: FETCH_LATEST_REEL, payload: responseData.data});

      dispatch({type: FETCH_LATEST_REEL_LOADER, payload: false});

      return responseData.data;
    } catch (error) {
      console.error('Error fetching latest reels:', error.message);

      dispatch({type: FETCH_LATEST_REEL_LOADER, payload: false});
      dispatch({type: FETCH_LATEST_REEL_ERROR, payload: error.message});

      return 0;
    }
  };
};

export const _getShopReels = ({videoId, page = 1, pageSize = 3, shopId}) => {
  const {fetch_user_detail} = getStoreState('auth');
  const isPagination = page > 1;
  console.log(
    videoId,
    fetch_user_detail?.id,
    'videoId, page, pageSize, shopId',
  );
  return async dispatch => {
    dispatch({type: FETCH_SHOP_REELS_LOADER, payload: true});
    try {
      const queryParams = new URLSearchParams();
      if (fetch_user_detail?.id)
        queryParams.append('userId', fetch_user_detail.id);
      queryParams.append('pageSize', pageSize);
      queryParams.append('page', page);
      if (shopId) queryParams.append('shopId', shopId);

      const url = `/reels-stories/video/${videoId}?${queryParams.toString()}`;

      const responseData = await call({
        baseUrl: url,
        method: 'GET',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
        },
      });

      if (!responseData.data || !Array.isArray(responseData.data)) {
        throw new Error('Invalid API response: expected array in data');
      }

      const filteredData = isPagination
        ? responseData.data.filter(item => item.video_url_id !== videoId)
        : responseData.data;

      dispatch({
        type: FETCH_SHOP_REELS,
        payload: filteredData,
        meta: {isPagination},
      });

      if (responseData.pagination) {
        dispatch({
          type: FETCH_SHOP_REELS_PAGINATION,
          payload: {
            totalReelCount: responseData.pagination.totalReelCount,
            totalPages: responseData.pagination.totalPages,
            currentPage: responseData.pagination.currentPage,
          },
        });
      }

      return filteredData;
    } catch (error) {
      console.log('Error fetching videoReels:', error.message);
      dispatch({type: FETCH_SHOP_REELS_ERROR, payload: error.message});
      return [];
    } finally {
      dispatch({type: FETCH_SHOP_REELS_LOADER, payload: false});
    }
  };
};

export const _getMerchantReels = ({shopId}) => {
  console.log(shopId, 'shopIdddd');
  return async dispatch => {
    try {
      dispatch({type: FETCH_MERCHANT_REELS, payload: []});

      const responseData = await call({
        baseUrl: `/reels-stories/shop/${shopId}`,
        method: 'GET',
      });
      console.log('Raw response:', shopId);

      if (!responseData.data) {
        throw new Error('Invalid API response`');
      }
      console.log('responsive', responseData.data);
      dispatch({type: FETCH_MERCHANT_REELS, payload: responseData.data});

      return responseData.data;
    } catch (error) {
      console.log('Error fetching merchantreels:', error.message);

      return [];
    }
  };
};

export const _getShopAndSavedReels = ({shopId}) => {
  return async dispatch => {
    if (!shopId) {
      return {};
    }

    try {
      const {fetch_user_detail} = getStoreState('auth');
      const queryParams = fetch_user_detail?.id
        ? `?userId=${fetch_user_detail.id}`
        : '';
      const responseData = await call({
        baseUrl: `/reels-stories/shop/${shopId}/saved-reels${queryParams}`,
        method: 'GET',
      });
      console.log('Raw response:', responseData);

      if (!responseData.data) {
        throw new Error('Invalid API response`');
      }

      dispatch({type: FETCH_SHOP_SAVED_REELS, payload: responseData.data});

      return responseData.data;
    } catch (error) {
      console.error('Error fetching savedreels:', error.message);

      return [];
    }
  };
};

export const _savedReel = (video_id, isSaved) => {
  return async (dispatch, getState) => {
    const {fetch_user_detail} = getState().auth;
    try {
      const rawData = {
        user_id: fetch_user_detail.id,
        video_id,
        status: isSaved,
      };

      const responseData = await call({
        baseUrl: `/reels-stories/save-reel`,
        method: 'POST',
        body: JSON.stringify(rawData),
      });

      if (responseData?.status) {
        showToast(
          responseData?.message ||
            (isSaved
              ? 'Video saved successfully.'
              : 'Video unsaved successfully.'),
        );
        return {
          status: true,
          message: responseData?.message,
        };
      } else {
        showToast(responseData?.message || 'Something went wrong.');
        return {status: false};
      }
    } catch (error) {
      showToast(error?.message || 'An error occurred.');
      return {status: false};
    }
  };
};

export const _updateReelViewCount = videoId => {
  return async dispatch => {
    try {
      console.log('testinclude', videoId, 'videoId');
      const responseData = await call({
        baseUrl: `/reels-stories/view/${videoId}`,
        method: 'PATCH',
      });
      console.log('Raw response:sss', responseData);

      console.log(responseData);
      return responseData;
    } catch (error) {
      // console.error('Error update count', error.message);

      return [];
    }
  };
};

export const _likeReel = (video_id, status) => {
  return async dispatch => {
    const {fetch_user_detail} = getStoreState('auth');
    try {
      const rawData = {
        user_id: fetch_user_detail.id,
        video_id,
        liked: status,
      };

      const responseData = await call({
        baseUrl: `/reels-stories/like-reel`,
        method: 'POST',
        body: JSON.stringify(rawData),
      });

      const data = responseData?.data;
      return data;
    } catch (error) {
      console.log('Like API Error:', error);
      return 0;
    }
  };
};

export const _getStories = ({shopId, userId}) => {
  return async dispatch => {
    try {
      // Build URL with optional userId query parameter
      let url = `/reels-stories/stories/${shopId}`;
      if (userId) {
        url += `?userId=${userId}`;
      }

      console.log('Stories API URL:', url);
      console.log('Stories API - shopId:', shopId, 'userId:', userId);

      const responseData = await call({
        baseUrl: url,
        method: 'GET',
      });

      if (!responseData || !Array.isArray(responseData.data)) {
        throw new Error('Invalid API response structure');
      }
      console.log('Stories API Response:', JSON.stringify(responseData, null, 2));
      dispatch({type: FETCH_STORIES, payload: responseData.data});
      return responseData.data;
    } catch (error) {
      console.log('Stories API Error:', error.message);
      return [];
    }
  };
};

export const updateShopReel = (id, updates) => {
  return {
    type: UPDATE_SHOP_REEL,
    payload: {
      id,
      updates,
    },
  };
};

export const _getUserSavedReels = ({page = 1}) => {
  return async dispatch => {
    try {
      const {userSavedReels} = getStoreState('reels');
      console.log('Fetching user saved reels...', userSavedReels);
      page == 1 &&
        dispatch({type: FETCH_USER_SAVED_REELS_LOADER, payload: true});

      const {fetch_user_detail} = getStoreState('auth');
      const userId = fetch_user_detail?.id;
      if (!userId) {
        return {};
      }
      console.log('Fetching user saved reels for user:', userId, 'page:', page);
      const responseData = await call({
        baseUrl: `/reels-stories/saved-reels/${userId}?page=${page}`,
        method: 'GET',
      });
      console.log('Raw response:', responseData);

      if (!responseData || !responseData.data) {
        throw new Error('Invalid API response');
      }

      if (page != 1) {
        const response = {
          ...responseData,
          data: [...userSavedReels?.data, ...responseData?.data],
          pagination: responseData?.pagination,
        };
        dispatch({type: FETCH_USER_SAVED_REELS, payload: response});
        dispatch({type: FETCH_USER_SAVED_REELS_ERROR, payload: ""});
      } else {
        dispatch({type: FETCH_USER_SAVED_REELS, payload: responseData});
        dispatch({type: FETCH_USER_SAVED_REELS_LOADER, payload: false});
        dispatch({type: FETCH_USER_SAVED_REELS_ERROR, payload: ""});
      }
      dispatch({type: FETCH_USER_SAVED_REELS_ERROR, payload: ""});

      return responseData.data;
    } catch (error) {
      console.error(
        'Error fetching savedreels:',
        error,
        error?.message,
        error?.response || error?.data,
      );
      dispatch({type: FETCH_USER_SAVED_REELS_LOADER, payload: false});
      dispatch({type: FETCH_USER_SAVED_REELS_ERROR, payload: error.message});
      return [];
    }
  };
};
