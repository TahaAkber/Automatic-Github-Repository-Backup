import {call} from '../../../helper/reUsableMethod/reUsableMethod';
import {
  CHAT_AI,
  CHAT_AI_APPEND,
  CHAT_AI_ERROR,
  CHAT_AI_LOADER,
  CHAT_AI_RESET,
} from '../../types/chatai/chatai';

export const _chatWithAI = message => {
  return async (dispatch, getState) => {
    try {
      const state = getState?.();
      const chatAi = state?.chatAi || {};

      const now = new Date().toLocaleTimeString([], {
        hour: '2-digit',
        minute: '2-digit',
      });
      const userMessage = {
        id: Date.now().toString() + '_user',
        type: 'text',
        text: message,
        isOutgoing: true,
        time: now,
      };
      if (message?.trim()?.length > 0) {
        dispatch({type: CHAT_AI_APPEND, payload: userMessage});
        dispatch({type: CHAT_AI_LOADER, payload: true});
      }

      const rawData = {
        message,
        session_id: chatAi?.data?.session_id || null,
      };

      const responseData = await call({
        baseUrl: `/chat`,
        ai_url: true,
        method: 'POST',
        body: JSON.stringify(rawData),
      });

      if (!responseData || typeof responseData !== 'object') {
        throw new Error('Invalid AI response format');
      }

      dispatch({type: CHAT_AI, payload: responseData});

      const aiMessage = {
        id: Date.now().toString() + '_ai',
        type: 'text',
        text: responseData?.reply || 'No response',
        isOutgoing: false,
        time: new Date().toLocaleTimeString([], {
          hour: '2-digit',
          minute: '2-digit',
        }),
        products: responseData?.products || [],
      };

      dispatch({type: CHAT_AI_APPEND, payload: aiMessage});

      if (responseData.session_id) {
        dispatch({
          type: 'CHAT_AI_SESSION_ID',
          payload: responseData.session_id,
        });
      }

      dispatch({type: CHAT_AI_LOADER, payload: false});
      console.log('✅ Chat AI response:', responseData);
      return responseData;
    } catch (error) {
      console.error('❌ Chat AI error:', error);
      dispatch({type: CHAT_AI_LOADER, payload: false});
      dispatch({type: CHAT_AI_ERROR, payload: error.message});
      return {};
    }
  };
};

export const resetChatData = () => ({
  type: CHAT_AI_RESET,
});
