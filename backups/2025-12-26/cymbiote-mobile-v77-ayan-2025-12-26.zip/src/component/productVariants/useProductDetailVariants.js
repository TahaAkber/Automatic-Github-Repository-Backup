import { useEffect, useState } from 'react';
import { Animated } from 'react-native';
import useReduxStore from '@utils/hooks/useReduxStore';

const useProductDetailVariants = ({ data }) => {
    const { getState } = useReduxStore();
    const { fetch_user_detail } = getState('auth');
    const [slideAnimation] = useState(new Animated.Value(0));
    const [result, setResult] = useState([]);


    const handleValue = (groupName, variantId) => {
        setResult((prevResult) => {
            const selectedColorGroup = prevResult.find((g) => g.name === 'Color');
            const selectedColorValue = selectedColorGroup?.values.find(
                (v) => v.variant_id === (groupName === 'Color' ? variantId : selectedColorGroup.selectedValue)
            )?.value;

            return prevResult.map((group) => {
                if (group.name === groupName) {
                    return {
                        ...group,
                        selectedValue: variantId,
                    };
                } else if (group.name === 'Size') {
                    if (groupName === 'Color' && selectedColorValue) {
                        const filteredSizes = data
                            .filter((variant) =>
                                variant?.selected_options?.some(
                                    (opt) => opt.name === 'Color' && opt.value.toLowerCase() === selectedColorValue
                                )
                            )
                            .map((variant) => ({
                                variant_id: variant.variant_id,
                                name: 'Size',
                                value: variant.selected_options.find((opt) => opt.name === 'Size')?.value,
                                available: variant.variant_quantity,
                            }));

                        return {
                            ...group,
                            values: filteredSizes,
                            selectedValue: filteredSizes[0]?.variant_id || '', // Auto-select the first size
                        };
                    }
                    return group;
                }
                return group;
            });
        });
    };

    const getSelectedVariant = () => {
        const selectedValues = result.reduce((acc, group) => {
            const selectedItem = group.values.find((v) => v.variant_id === group.selectedValue);
            if (selectedItem) {
                acc[group.name] = selectedItem.value;
            }
            return acc;
        }, {});

        const matchingVariant = data.find((variant) =>
            variant.selected_options.every((opt) => selectedValues[opt.name] === opt.value.toLowerCase())
        );

        return matchingVariant || null; // Return the full variant details or null if no match
    };

    useEffect(() => {
        const groupedData = data.reduce((acc, variant) => {
            // Ensure selected_options exist and contain valid entries
            if (variant?.selected_options?.length > 0 && variant.selected_options.every(option => option?.value)) {
                variant.selected_options.forEach(({ name, value, selected_options }) => {
                    if (!acc[name]) {
                        acc[name] = {
                            name,
                            selectedValue: '',
                            values: [],
                            selected_options: variant?.selected_options
                        };
                    }

                    // Check for duplicates before adding
                    if (!acc[name].values.some((v) => v.value === value.toLowerCase())) {
                        acc[name].values.push({
                            variant_id: variant.variant_id,
                            name,
                            value: value.toLowerCase(),
                            available: variant.variant_quantity,
                        });
                    }
                });
            }
            return acc;
        }, {});

        const formattedResult = Object.values(groupedData).map((group) => ({
            ...group,
            selectedValue: group.values[0]?.variant_id || '', // Default to the first value if available
        }));

        setResult(formattedResult);
    }, [data]);


    return {
        fetch_user_detail,
        handleValue,
        result,
        slideAnimation,
        getSelectedVariant, // Expose the function to get the selected variant
    };
};

export default useProductDetailVariants;
