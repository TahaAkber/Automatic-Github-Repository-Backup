import CustomText from '@materialComponent/customText/customText';
import { moderateScale, verticalScale } from 'react-native-size-matters';
import { Dimensions, StyleSheet, TouchableOpacity, View } from 'react-native';
import { font, WH, globalStyle, shadow } from '@constant/contstant';
import { margin } from '@constant/contstant';
import React from 'react';
import NotificationSvg from '@assets/images/notification_header.js';
import SettingSvg from '@assets/images/setting';
import { useNavigation } from '@react-navigation/native';
import useReduxStore from '@utils/hooks/useReduxStore';
import CustomImage from '@materialComponent/image/image';
import { ProfileDisplay } from '@helper/reUsableMethod/reUsableMethod';
import ProfileIcon from '@assets/images/profile.svg';
import Icon from '../../materialComponent/icon/icon';
import { Image } from 'react-native-svg';

const { fontScale, width, height } = Dimensions.get("screen")

const ChatHeader = ({ title, notification, setting, profile, style, light, name, image }) => {

  const navigation = useNavigation()
  const { getState } = useReduxStore()
  const { fetch_user_detail, token } = getState("auth")


  return (
    <View style={[styles.header, style]}>
      <View style={globalStyle.row}>
        <TouchableOpacity>
          <Icon icon_type={"AntDesign"} name={"arrowleft"} color={"black"} size={20} onPress={() => navigation.goBack()} />
        </TouchableOpacity>
        {profile && image ? (
          <CustomImage style={styles.image} source={{ uri: image }} />
        ) : (
          <ProfileIcon width={WH.width(3.8)} height={WH.width(3.8)} />
        )}
        <View>
          {profile && name && (
            <CustomText style={styles.profileName}>{name}</CustomText>
          )}
        </View>


      </View>
      <View style={globalStyle.row}>
        {notification ?
          <TouchableOpacity
            style={[styles.circle, { marginRight: width * 0.02 }, light && { backgroundColor: "white" }]}
            onPress={() => navigation.navigate('Notification')}
          >
            <NotificationSvg width={WH.width(3.8)} height={WH.width(3.8)} />
          </TouchableOpacity> : <></>
        }

        {setting ?
          <TouchableOpacity
            style={[styles.circle, light && { backgroundColor: "white" }]}
            onPress={() => navigation.navigate('Setting')}
          >
            <SettingSvg width={WH.width(3.8)} height={WH.width(3.8)} />
          </TouchableOpacity> : <></>
        }

      </View>
    </View>
  );
};

export default ChatHeader;

const styles = StyleSheet.create({
  header: {
    paddingTop: verticalScale(10),
    marginBottom: height * 0.02,
    paddingHorizontal: margin.horizontal,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center"
    // justifyContent: 'center',
    // alignItems: 'center',
  },
  profileName: {
    color: "black",
    fontFamily: font.medium,
    fontSize: fontScale * 15
  },
  text: {
    color: "black",
    fontFamily: font.bold,
    fontSize: fontScale * 25
  },
  circle: {
    width: width * 0.08,
    aspectRatio: 1,
    backgroundColor: "rgba(35, 101, 232, 0.1)",
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 180,
  },
  header_image: {
    width: width * 0.09,
    height: width * 0.09,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 180,
  },
  image: {
    width: "32%",
    aspectRatio: 1,
    marginRight: "5%",
    borderRadius: 180,
  },
});
