import CustomText from '@materialComponent/customText/customText';
import {moderateScale, verticalScale} from 'react-native-size-matters';
import {Dimensions, StyleSheet, TouchableOpacity, View} from 'react-native';
import {font, WH, globalStyle, shadow} from '@constant/contstant';
import {margin} from '@constant/contstant';
import React from 'react';
import NotificationSvg from '@assets/images/notification_header.js';
import SettingIcon from '@assets/images/setting';
import {useNavigation} from '@react-navigation/native';
import useReduxStore from '@utils/hooks/useReduxStore';
import CustomImage from '@materialComponent/image/image';
import {ProfileDisplay} from '@helper/reUsableMethod/reUsableMethod';
import ProfileIcon from '@assets/images/profile.svg';
import {AuthNavigating} from '../../helper/reUsableMethod/reUsableMethod';
import {navigate} from '../../utils/navigationRef/navigationRef';
import {colors} from '../../constant/contstant';
import Icon from '../../materialComponent/icon/icon';

const {fontScale, width, height} = Dimensions.get('screen');

const InnerHeader = ({
  title,
  notification,
  setting,
  profile,
  share,
  style,
  light,
  headerTextColor,
  fontSize,
  showBackIcon = false,
  titleStyle,
  onPressShare,
  plus,
  onPressPlus,
}) => {
  const navigation = useNavigation();
  const {getState} = useReduxStore();
  const {fetch_user_detail, token} = getState('auth');

  const name = fetch_user_detail?.firstname
    ? fetch_user_detail?.firstname + ' ' + fetch_user_detail?.lastname
    : 'Guest';

  const _handleNavigate = async screen => {
    const userLogin = AuthNavigating();
    if (userLogin) {
      navigate(screen);
    }
  };

  return (
    <View style={[styles.header, style]}>
      <View style={globalStyle.row}>
        {profile ? (
          <TouchableOpacity
            onPress={() => navigation.navigate('Profile')}
            style={[
              styles.circle,
              {marginRight: width * 0.03},
              {
                backgroundColor: 'white',
                width: width * 0.11,
                height: width * 0.11,
                ...shadow,
              },
            ]}>
            {fetch_user_detail?.profile ? (
              <CustomImage
                source={{
                  uri: ProfileDisplay(token, fetch_user_detail?.profile),
                }}
                style={styles.header_image}
              />
            ) : (
              <ProfileIcon
                color={'white'}
                width={WH.width(5)}
                height={WH.width(5)}
              />
            )}
          </TouchableOpacity>
        ) : (
          <></>
        )}
        <View>
          <View style={[globalStyle.row, {alignItems: 'center'}]}>
            {showBackIcon && (
              <TouchableOpacity
                onPress={() => navigation.goBack()}
                style={{marginRight: width * 0.05}}>
                <Icon
                  icon_type={'Ionicons'}
                  name={'arrow-back'}
                  size={moderateScale(15)}
                  color={'black'}
                  style={{marginTop: 5}}
                />
              </TouchableOpacity>
            )}
            <View style={[titleStyle]}>
              <CustomText
                fontFamily={profile ? font.medium : font.bold}
                text={profile ? name : title}
                color={light ? headerTextColor || 'white' : 'black'}
                style={[
                  styles.text,
                  profile && styles.profileName,
                  {fontSize: fontSize || fontScale * 20},
                ]}
              />

              {profile ? (
                <CustomText
                  fontSize={fontScale * 13}
                  fontFamily={font.light}
                  text={fetch_user_detail?.email || 'Guest@example.com'}
                  color={light ? 'white' : 'black'}
                />
              ) : (
                <></>
              )}
            </View>
          </View>
        </View>
      </View>
      <View style={globalStyle.row}>
        {share ? (
          <TouchableOpacity
            style={[styles.circle, light && {backgroundColor: 'white'}]}
            onPress={onPressShare}>
            <Icon
              icon_type={'FontAwesome'}
              name={'share-alt'}
              color={colors.light_theme.theme}
              width={WH.width(3.8)}
              height={WH.width(3.8)}
            />
          </TouchableOpacity>
        ) : (
          <></>
        )}
        {plus ? (
          <TouchableOpacity
            style={[
              styles.circle,
              light && {backgroundColor: 'white'},
              {marginRight: width * 0.02},
            ]}
            onPress={onPressPlus}>
            <Icon
              icon_type={'FontAwesome'}
              name={'plus-circle'}
              color={colors.light_theme.theme}
              size={moderateScale(20)}
            />
          </TouchableOpacity>
        ) : (
          <></>
        )}

        {notification ? (
          <TouchableOpacity
            style={[
              styles.circle,
              {marginRight: width * 0.02},
              light && {backgroundColor: 'white'},
            ]}
            onPress={() => _handleNavigate('Notification')}>
            <NotificationSvg
              color={colors.light_theme.theme}
              width={WH.width(3.8)}
              height={WH.width(3.8)}
            />
          </TouchableOpacity>
        ) : (
          <></>
        )}

        {setting ? (
          <TouchableOpacity
            style={[styles.circle, light && {backgroundColor: 'white'}]}
            // onPress={() => navigation.navigate('Settings')}
            onPress={() => _handleNavigate('Settings')}>
            <SettingIcon
              color={colors.light_theme.theme}
              width={WH.width(3.8)}
              height={WH.width(3.8)}
            />
          </TouchableOpacity>
        ) : (
          <></>
        )}
      </View>
    </View>
  );
};

export default InnerHeader;

const styles = StyleSheet.create({
  header: {
    paddingTop: verticalScale(10),
    marginBottom: height * 0.02,
    paddingHorizontal: margin.horizontal,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    // justifyContent: 'center',
    // alignItems: 'center',
  },
  profileName: {
    color: 'black',
    fontFamily: font.medium,
    fontSize: fontScale * 15,
  },
  text: {
    color: 'black',
    fontFamily: font.bold,
    fontSize: fontScale * 25,
  },
  circle: {
    width: width * 0.08,
    aspectRatio: 1,
    backgroundColor: 'rgba(35, 101, 232, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 180,
  },
  header_image: {
    width: width * 0.09,
    height: width * 0.09,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 180,
  },
});
