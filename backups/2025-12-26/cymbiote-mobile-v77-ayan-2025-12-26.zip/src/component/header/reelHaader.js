import {
  Dimensions,
  StyleSheet,
  TouchableOpacity,
  View,
  Animated,
} from 'react-native';
import {colors, font, globalStyle, margin} from '../../constant/contstant';
import CustomImage from '../../materialComponent/image/image';
import {homeData} from '../../constant/dummyData';
import images from '../../assets/images/images';
import CustomText from '../../materialComponent/customText/customText';
import Icon from '../../materialComponent/icon/icon';
import {navigate} from '../../utils/navigationRef/navigationRef';
import {useState} from 'react';

const {width, height, fontScale} = Dimensions.get('screen');
const ReelHeader = () => {
  const [scrollY] = useState(new Animated.Value(0));
  const textColor = scrollY.interpolate({
    inputRange: [0, height * 0.3],
    outputRange: ['white', 'black'],
    extrapolate: 'clamp',
  });
  return (
    //         <View style={styles.container}>
    //             <View style={styles.header}>
    //                 <View style={globalStyle.row}>
    //                 <CustomImage source={images.outfittersBlack } style={styles.logoUrl} />
    //                 <View style={{marginLeft:"7%",height:height * 0.04, justifyContent:"space-between"}}>
    //                     <CustomText text={"Outfitters"} fontSize={fontScale * 14} fontFamily={font.bold}/>
    //                     <View style={globalStyle.row}>
    //                         <CustomText text={"4.9"} fontSize={fontScale * 9}  fontFamily={font.bold} style={styles.ratingText}/>
    //                           <Icon icon_type={"AntDesign"} name={"star"} color={"black"}  size={9} style={styles.starText}/>
    //                           <CustomText text={"  (865)"} fontSize={fontScale * 9} fontFamily={font.bold} style={styles.starText}/>
    //                     </View>
    //                 </View>
    //                 </View>
    //                 <View style={globalStyle.row}>

    //                             <TouchableOpacity >
    //                                     <Icon icon_type={"Ionicons"} size={fontScale * 18} name={"notifications-outline"} color={"black"} style={{marginRight:10}} />
    //                             </TouchableOpacity>
    //                             <TouchableOpacity onPress={() => navigate("BrandSearch")}>
    //                                     <Icon icon_type={"MaterialIcons"} size={fontScale * 18} name={"search"}  color={"black"}style={{marginRight:10}}/>
    //                             </TouchableOpacity>
    //                             <TouchableOpacity >
    //                                     <Icon icon_type={"Entypo"} size={fontScale * 18} name={"dots-three-horizontal"} color={"black"}  style={{marginRight:10}}/>
    //                             </TouchableOpacity>
    //                         </View>

    //             </View>
    // <View style={styles.line }/>
    //         </View>
    <>
      <View style={{backgroundColor: 'white'}}>
        <View style={styles.brandTab}>
          <View style={globalStyle.row}>
            {/* <CustomImage
            source={{uri: homeData[0].shop_logo_url}}
            style={styles.logoUrl}
          /> */}
            <View style={{marginLeft: '7%'}}>
              <Animated.Text
                style={{
                  fontSize: fontScale * 20,
                  color: 'black',
                  fontFamily: font.bold,
                }}>
                Reels
              </Animated.Text>

              {/* <View style={globalStyle.row}>
              <Animated.Text
                style={{
                  fontSize: fontScale * 9,
                  color: 'black',
                  fontFamily: font.bold,
                  marginRight: 5,
                }}>
                4.6
              </Animated.Text>

              <Animated.Text style={{color: textColor}}>
                <Icon icon_type={'AntDesign'} name={'star'} color={'black'} />
              </Animated.Text>

              <Animated.Text
                style={{
                  fontSize: fontScale * 9,
                  color: 'black',
                  fontFamily: font.bold,
                  marginLeft: 5,
                }}>
                (865)
              </Animated.Text>
            </View> */}
            </View>
          </View>

          <View style={globalStyle.row}>
            {/* <TouchableOpacity onPress={()=> navigate("Reels")}>
                                    <Animated.Text style={{ color: textColor, marginRight: 10 }}>
                                        <Icon icon_type={"Feather"} size={fontScale * 17} name={"film"}  />
                                    </Animated.Text>
                                    </TouchableOpacity> */}

            <TouchableOpacity>
              <Animated.Text style={{color: textColor}}>
                {/* <Icon
                  icon_type={'Entypo'}
                  size={fontScale * 25}
                  name={'dots-three-horizontal'}
                  color={'black'}
                /> */}
              </Animated.Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
      <View style={styles.line} />
    </>
  );
};
export default ReelHeader;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    // marginHorizontal: margin.horizontal,

    padding: '2%',
  },
  logoUrl: {
    width: '28%',
    aspectRatio: 1,
    borderRadius: 180,
    backgroundColor: 'black',
  },
  ratingText: {
    marginRight: '2%',
  },
  starText: {
    marginLeft: '2%',
  },
  line: {
    // // backgroundColor: colors.light_theme.borderColor,
    // backgroundColor: '#b2b2b2',
    // height: height * 0.001,
    // // marginHorizontal:margin.horizontal,
    // marginTop: '2%',
  },
  brandTab: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginHorizontal: margin.horizontal,
    paddingVertical: '5%',
  },
  logoUrl: {
    width: '28%',
    aspectRatio: 1,
    borderRadius: 180,
  },
});
