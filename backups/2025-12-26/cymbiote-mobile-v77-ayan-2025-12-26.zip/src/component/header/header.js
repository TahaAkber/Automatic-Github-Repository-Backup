import React, {useRef} from 'react';
import {
  StyleSheet,
  TouchableOpacity,
  TextInput,
  Image,
  Dimensions,
  StatusBar,
} from 'react-native';
import {View} from 'react-native';
import {font, shadow, globalStyle, margin, WH} from '@constant/contstant';
import {moderateScale, verticalScale} from 'react-native-size-matters';
import Icon from '@materialComponent/icon/icon';
import {colors} from '@constant/contstant';
import AppIcon from '@assets/images/app_icon.svg';
import ProfileIcon from '@assets/images/profile.svg';
import TrackOrderSvg from '@assets/images/track_order_header.svg';
import NotificationSvg from '@assets/images/notification_header.js';
import {useNavigation} from '@react-navigation/native';
import CustomText from '@materialComponent/customText/customText';
import useReduxStore from '@utils/hooks/useReduxStore';
import {ProfileDisplay} from '@helper/reUsableMethod/reUsableMethod';
import CustomImage from '@materialComponent/image/image';
import OrdersBottomSheet from '../Chat/ordersBottomSheet';
import images from '../../assets/images/images';
import {AuthNavigating} from '../../helper/reUsableMethod/reUsableMethod';
import LinearGradient from 'react-native-linear-gradient';
import {navigate} from '../../utils/navigationRef/navigationRef';
import useActiveOrders from '../Chat/useActiveOrder';
import {isAndroid} from '../../constant/contstant';

const {fontScale, height, width} = Dimensions.get('screen');

const orderData = [
  {
    id: '1',
    orderId: '#92287157',
    status: 'Shipped',
    itemsCount: '4',
    images: [images.t_shirt, images.t_shirt, images.t_shirt, images.t_shirt],
  },
  {
    id: '2',
    orderId: '#9977866',
    status: 'Delivered',
    itemsCount: '3',
    images: [images.t_shirt, images.t_shirt, images.t_shirt, images.t_shirt],
  },
];

const Header = ({
  // onOpenOrdersSheet
  whiteBackground,
}) => {
  const {getState, dispatch} = useReduxStore();

  const {fetch_user_detail, token} = getState('auth');
  const navigation = useNavigation();
  const ordersSheetRef = useRef(null);

  const _handleNavigate = async screen => {
    const userLogin = AuthNavigating();
    if (userLogin) {
      navigate(screen);
    }
  };

  const Linear = fetch_user_detail?.profile ? LinearGradient : View;
  return (
    <View
      style={[
        styles.header,
        {
          backgroundColor: whiteBackground ? 'white' : '#f4f4f4',
          paddingVertical: height * 0.02,
        },
      ]}>
      {isAndroid ? <StatusBar barStyle={'dark-content'} /> : <></>}

      <View style={globalStyle.space_between}>
        <View style={globalStyle.row}>
          <View style={styles.location_container}>
            <AppIcon width={width * 0.3} height={35} />
            {/* <CustomText fontFamily={font.bold} style={{ marginLeft: WH.width(2) }} color={colors.light_theme.theme} text={"Cymbiote"} /> */}
          </View>
        </View>
        <View style={globalStyle.row}>
          <TouchableOpacity
            style={[
              styles.circle,
              {marginRight: moderateScale(5), backgroundColor: '#03C47E'},
            ]}
            // onPress={onOpenOrdersSheet}
            onPress={() => {
              ordersSheetRef.current.open();
            }}>
            <TrackOrderSvg width={WH.width(4)} height={WH.width(4)} />
          </TouchableOpacity>
          <TouchableOpacity
            style={[
              styles.circle,
              {marginRight: moderateScale(5), backgroundColor: '#FF9624'},
            ]}
            onPress={() => _handleNavigate('Notification')}>
            <NotificationSvg
              color={'white'}
              width={WH.width(3.8)}
              height={WH.width(3.8)}
            />
          </TouchableOpacity>

          <TouchableOpacity onPress={() => navigation.navigate('Profile')}>
            <Linear
              colors={[
                fetch_user_detail?.profile
                  ? colors.light_theme.lightBlue
                  : 'white',
                fetch_user_detail?.profile
                  ? colors.light_theme.confirmed
                  : 'white',
              ]}
              start={{x: 0, y: 0}}
              end={{x: 1, y: 1}}
              style={[
                styles.circle,
                fetch_user_detail?.profile && {
                  ...shadow,
                  height: moderateScale(40),
                  width: moderateScale(40),
                },
              ]}>
              {fetch_user_detail?.profile ? (
                <CustomImage
                  source={{
                    uri: ProfileDisplay(token, fetch_user_detail?.profile),
                  }}
                  style={styles.header_image}
                />
              ) : (
                <ProfileIcon
                  color={'white'}
                  width={WH.width(4)}
                  height={WH.width(4)}
                />
              )}
            </Linear>
          </TouchableOpacity>
          <OrdersBottomSheet
            ref={ordersSheetRef}
            orders={orderData}
            buttonText="Track"
          />
        </View>
      </View>
    </View>
  );
};

export default Header;

const styles = StyleSheet.create({
  header: {
    paddingVertical: verticalScale(10),
    paddingHorizontal: margin.horizontal,
    backgroundColor: colors.light_theme.themeBackgroundColor,
  },
  location_container: {
    // marginLeft: moderateScale(15),
    flexDirection: 'row',
    alignItems: 'center',
    marginLeft: width * -0.03,
  },
  input_container: {
    height: WH.height(5),
    paddingHorizontal: margin.horizontal,
    backgroundColor: 'black',
    ...globalStyle.row,
    borderRadius: 10,
  },
  searchbar: {
    marginLeft: moderateScale(10),
    fontFamily: font.medium,
    height: '100%',
    width: '100%',
  },
  header_image: {
    height: moderateScale(32),
    width: moderateScale(32),
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 180,
  },
  circle: {
    height: moderateScale(30),
    width: moderateScale(30),
    backgroundColor: 'rgba(35, 101, 232, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 180,
  },
});
