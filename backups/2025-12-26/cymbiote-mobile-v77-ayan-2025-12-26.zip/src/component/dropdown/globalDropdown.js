import React, {forwardRef, useImperativeHandle, useState} from 'react';
import {View, TouchableOpacity, StyleSheet, FlatList} from 'react-native';
import {moderateScale, verticalScale} from 'react-native-size-matters';
import {WH, colors, font} from '@constant/contstant';
import CustomText from '@materialComponent/customText/customText';
import Icon from '@materialComponent/icon/icon';
import CustomImage from '../../materialComponent/image/image';
import {widthPercentageToDP} from 'react-native-responsive-screen';
import {globalStyle} from '../../constant/contstant';

const DropdownInput = forwardRef(
  (
    {
      options = [],
      onSelect,
      value = null, // Expected: { id: ..., value: ... }
      placeholder = 'Select...',
      errorMessage = null,
      marginTop = 0,
      hide = false,
      backgroundColor,
    },
    ref,
  ) => {
    const [visible, setVisible] = useState(false);

    useImperativeHandle(ref, () => ({
      close: () => setVisible(false),
      open: () => setVisible(true),
      toggle: () => setVisible(prev => !prev),
    }));

    const handleSelect = item => {
      onSelect(item.id);
      setVisible(false);
    };

    const findValue = options?.find(item => item.id == value)?.value;
     return hide ? null : (
      <View style={{marginTop}}>
        <TouchableOpacity
          style={[
            styles.container,
            backgroundColor && {backgroundColor},
            errorMessage && styles.errorBorder,
          ]}
          onPress={() => setVisible(!visible)}
          activeOpacity={0.8}>
          <CustomText
            text={value ? findValue : placeholder}
            fontSize={moderateScale(14)}
            color={value ? colors.light_theme.text : colors.light_theme.gray}
            style={styles.text}
          />

          <View style={styles.iconContainer}>
            <Icon
              icon_type="Feather"
              name={visible ? 'chevron-up' : 'chevron-down'}
              size={moderateScale(18)}
              color="#ACB5BB"
            />
          </View>
        </TouchableOpacity>

        {errorMessage && (
          <CustomText
            marginTop={verticalScale(5)}
            fontSize={moderateScale(12)}
            text={`* ${errorMessage}`}
            color="red"
          />
        )}

        {visible && (
          <View style={styles.dropdown}>
            <FlatList
              data={options}
              keyExtractor={(item, index) => item.id.toString()}
              nestedScrollEnabled
              showsVerticalScrollIndicator={false}
              renderItem={({item}) => (
                <TouchableOpacity
                  style={styles.option}
                  onPress={() => handleSelect(item)}>
                  <View style={globalStyle.row}>
                    {item?.image_url && (
                      <CustomImage
                        style={styles.image}
                        source={{uri: item?.image_url}}
                      />
                    )}

                    <CustomText
                      text={item.value}
                      fontSize={moderateScale(14)}
                      color={colors.light_theme.text}
                    />
                  </View>
                  {item.id == value ? (
                    <Icon
                      icon_type={'Ionicons'}
                      name={'checkmark-done'}
                      color={'black'}
                      size={moderateScale(20)}
                    />
                  ) : (
                    <></>
                  )}
                </TouchableOpacity>
              )}
            />
          </View>
        )}
      </View>
    );
  },
);

export default DropdownInput;

const styles = StyleSheet.create({
  container: {
    width: '100%',
    backgroundColor: 'white',
    overflow: 'hidden',
    borderRadius: moderateScale(10),
    height: WH.height(6.5),
    justifyContent: 'center',
    paddingHorizontal: moderateScale(15),
  },
  text: {
    fontFamily: font.medium,
  },
  errorBorder: {
    borderColor: colors.light_theme.red,
    borderWidth: 1,
  },
  iconContainer: {
    position: 'absolute',
    right: 15,
    top: '35%',
  },
  dropdown: {
    backgroundColor: 'white',
    borderRadius: moderateScale(10),
    marginTop: verticalScale(5),
    borderWidth: 1,
    borderColor: colors.light_theme.borderColor,
    maxHeight: WH.height(30),
    overflow: 'hidden',
  },
  option: {
    paddingVertical: verticalScale(10),
    paddingHorizontal: moderateScale(15),
    borderBottomWidth: 1,
    borderColor: '#f4f4f4',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  image: {
    width: widthPercentageToDP(8),
    aspectRatio: 1,
    borderRadius: 180,
    marginRight: widthPercentageToDP(2),
  },
});
