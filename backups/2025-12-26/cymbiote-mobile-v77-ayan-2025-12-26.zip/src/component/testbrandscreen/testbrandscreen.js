import React, {useRef, useState, useEffect, useCallback} from 'react';
import {
  View,
  Text,
  Image,
  Animated,
  StyleSheet,
  Dimensions,
  FlatList,
  ActivityIndicator,
  StatusBar,
  TouchableOpacity,
} from 'react-native';
import {useSafeAreaInsets} from 'react-native-safe-area-context';

const {height, width} = Dimensions.get('window');
const IMAGE_HEIGHT = height;
const START_PRODUCTS_FROM = height * 0.5;
const AnimatedFlatList = Animated.createAnimatedComponent(FlatList);

const categoriesData = [
  {id: 'all', title: 'All'},
  {id: 'bags', title: 'Bags'},
  {id: 'shoes', title: 'Shoes'},
  {id: 'watches', title: 'Watches'},
  {id: 'accessories', title: 'Accessories'},
];

const collectionsData = [
  {id: '1', title: 'Summer Sale', image: 'https://picsum.photos/400/300?1'},
  {id: '2', title: 'New Arrivals', image: 'https://picsum.photos/400/300?2'},
  {id: '3', title: 'Luxury Picks', image: 'https://picsum.photos/400/300?3'},
  {
    id: '4',
    title: 'Winter Essentials',
    image: 'https://picsum.photos/400/300?4',
  },
];

const AnimatedProductScreen = ({
  backgroundColor = '#FFFFFF',
  merchantName = 'Zara Official',
}) => {
  const insets = useSafeAreaInsets();
  const scrollY = useRef(new Animated.Value(0)).current;

  // Animation refs
  const headerAnim = useRef(new Animated.Value(-60)).current;
  const headerOpacity = useRef(new Animated.Value(0)).current;
  const topCategoryAnim = useRef(new Animated.Value(-60)).current;
  const topCategoryOpacity = useRef(new Animated.Value(0)).current;

  const [isHeaderVisible, setHeaderVisible] = useState(false);
  const [activeCategory, setActiveCategory] = useState('all');
  const [products, setProducts] = useState(generateProducts(30));
  const [filtered, setFiltered] = useState(products);
  const [loading, setLoading] = useState(false);
  const [page, setPage] = useState(1);

  // Filter
  useEffect(() => {
    if (activeCategory === 'all') setFiltered(products);
    else
      setFiltered(
        products.filter(p => p.category.toLowerCase().includes(activeCategory)),
      );
  }, [activeCategory, products]);

  // Load more
  const loadMore = async () => {
    if (loading) return;
    setLoading(true);
    setTimeout(() => {
      const newProducts = generateProducts(30, page * 30);
      setProducts(prev => [...prev, ...newProducts]);
      setPage(prev => prev + 1);
      setLoading(false);
    }, 1000);
  };

  // Watch category visibility
  const viewabilityConfig = useRef({
    viewAreaCoveragePercentThreshold: 50,
  }).current;

  const onViewableItemsChanged = useRef(({viewableItems}) => {
    const isCategoryVisible = viewableItems.some(
      item => item.key === 'category-section',
    );

    if (!isCategoryVisible && !isHeaderVisible) {
      // Category is gone -> show header
      setHeaderVisible(true);
      Animated.parallel([
        Animated.timing(headerAnim, {
          toValue: 0,
          duration: 200,
          useNativeDriver: true,
        }),
        Animated.timing(headerOpacity, {
          toValue: 1,
          duration: 200,
          useNativeDriver: true,
        }),
        Animated.timing(topCategoryAnim, {
          toValue: 0,
          duration: 200,
          useNativeDriver: true,
        }),
        Animated.timing(topCategoryOpacity, {
          toValue: 1,
          duration: 200,
          useNativeDriver: true,
        }),
      ]).start();
    } else if (isCategoryVisible && isHeaderVisible) {
      // Category visible -> hide header
      setHeaderVisible(false);
      Animated.parallel([
        Animated.timing(headerAnim, {
          toValue: -60,
          duration: 200,
          useNativeDriver: true,
        }),
        Animated.timing(headerOpacity, {
          toValue: 0,
          duration: 200,
          useNativeDriver: true,
        }),
        Animated.timing(topCategoryAnim, {
          toValue: -60,
          duration: 200,
          useNativeDriver: true,
        }),
        Animated.timing(topCategoryOpacity, {
          toValue: 0,
          duration: 200,
          useNativeDriver: true,
        }),
      ]).start();
    }
  }).current;

  // Background parallax
  const bgOpacity = scrollY.interpolate({
    inputRange: [0, 150],
    outputRange: [0.2, 1],
    extrapolate: 'clamp',
  });
  const imageOpacity = scrollY.interpolate({
    inputRange: [0, IMAGE_HEIGHT / 1.5],
    outputRange: [1, 0],
    extrapolate: 'clamp',
  });
  const imageTranslate = scrollY.interpolate({
    inputRange: [0, IMAGE_HEIGHT],
    outputRange: [0, -IMAGE_HEIGHT / 3],
    extrapolate: 'clamp',
  });

  // Render functions
  const renderCategory = useCallback(
    ({item}) => (
      <TouchableOpacity
        onPress={() => setActiveCategory(item.id)}
        style={[
          styles.categoryChip,
          activeCategory === item.id && styles.categoryChipActive,
        ]}>
        <Text
          style={[
            styles.categoryText,
            activeCategory === item.id && styles.categoryTextActive,
          ]}>
          {item.title}
        </Text>
      </TouchableOpacity>
    ),
    [activeCategory],
  );

  const renderCollection = useCallback(
    ({item}) => (
      <View style={styles.collectionCard}>
        <Image source={{uri: item.image}} style={styles.collectionImage} />
        <View style={styles.collectionOverlay}>
          <Text style={styles.collectionTitle}>{item.title}</Text>
        </View>
      </View>
    ),
    [],
  );

  const renderProduct = useCallback(
    ({item}) => (
      <View style={styles.card}>
        <Image source={{uri: item.image}} style={styles.cardImage} />
        <View style={{flex: 1}}>
          <Text style={styles.cardTitle}>{item.title}</Text>
          <Text style={styles.cardSubtitle}>{item.category}</Text>
        </View>
      </View>
    ),
    [],
  );

  const listData = [
    {key: 'collections', type: 'collections'},
    {key: 'category-section', type: 'category'},
    ...filtered.map(p => ({key: p.id.toString(), type: 'product', ...p})),
  ];

  const renderItem = ({item}) => {
    if (item.type === 'collections') {
      return (
        <View style={styles.collectionContainer}>
          <Text style={styles.collectionHeading}>Collections</Text>
          <FlatList
            horizontal
            data={collectionsData}
            keyExtractor={i => i.id}
            renderItem={renderCollection}
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={{paddingHorizontal: 16}}
          />
        </View>
      );
    }
    if (item.type === 'category') {
      return (
        <View style={styles.bottomCategoryContainer}>
          <FlatList
            horizontal
            data={categoriesData}
            keyExtractor={i => i.id}
            renderItem={renderCategory}
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.categoriesContainer}
          />
        </View>
      );
    }
    return renderProduct({item});
  };

  return (
    <View style={styles.container}>
      <StatusBar
        translucent
        backgroundColor="transparent"
        barStyle="dark-content"
      />

      {/* Background Image */}
      <Animated.Image
        source={{uri: 'https://picsum.photos/1080/1920'}}
        style={[
          styles.fullImage,
          {
            opacity: imageOpacity,
            transform: [{translateY: imageTranslate}],
            marginTop: -insets.top,
            height: IMAGE_HEIGHT + insets.top,
          },
        ]}
        resizeMode="cover"
      />

      {/* Fade overlay */}
      <Animated.View
        style={[
          styles.dynamicBackground,
          {backgroundColor, opacity: bgOpacity},
        ]}
      />

      {/* Merchant Header */}
      <Animated.View
        style={[
          styles.topHeader,
          {
            paddingTop: insets.top,
            height: 50 + insets.top,
            transform: [{translateY: headerAnim}],
            opacity: headerOpacity,
          },
        ]}>
        <Text style={styles.headerTitle}>{merchantName}</Text>
      </Animated.View>

      {/* Top Category Bar */}
      <Animated.View
        style={[
          styles.categoryHeaderTop,
          {
            transform: [{translateY: topCategoryAnim}],
            opacity: topCategoryOpacity,
          },
        ]}>
        <FlatList
          horizontal
          data={categoriesData}
          keyExtractor={item => item.id}
          renderItem={renderCategory}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.categoriesContainer}
        />
      </Animated.View>

      {/* Unified FlatList */}
      <AnimatedFlatList
        data={listData}
        renderItem={renderItem}
        keyExtractor={item => item.key}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{
          paddingTop: START_PRODUCTS_FROM,
          paddingBottom: 100,
        }}
        scrollEventThrottle={16}
        onScroll={Animated.event(
          [{nativeEvent: {contentOffset: {y: scrollY}}}],
          {useNativeDriver: false},
        )}
        onEndReached={loadMore}
        onEndReachedThreshold={0.5}
        onViewableItemsChanged={onViewableItemsChanged}
        viewabilityConfig={viewabilityConfig}
        ListFooterComponent={
          loading ? <ActivityIndicator size="small" color="#999" /> : null
        }
      />
    </View>
  );
};

// Dummy products
function generateProducts(count, start = 0) {
  const categories = ['Bags', 'Shoes', 'Watches', 'Accessories'];
  return Array.from({length: count}).map((_, i) => ({
    id: start + i + 1,
    title: `Product ${start + i + 1}`,
    category: categories[i % categories.length],
    image: `https://picsum.photos/seed/${start + i}/300/300`,
  }));
}

const styles = StyleSheet.create({
  container: {flex: 1},
  fullImage: {position: 'absolute', width: '100%'},
  dynamicBackground: {
    position: 'absolute',
    top: 0,
    bottom: 0,
    left: 0,
    right: 0,
  },
  topHeader: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderColor: '#ddd',
    zIndex: 30,
  },
  headerTitle: {fontSize: 18, fontWeight: '700', color: '#111'},
  categoryHeaderTop: {
    position: 'absolute',
    top: 50 + (StatusBar.currentHeight || 40),
    left: 0,
    right: 0,
    backgroundColor: '#fff',
    zIndex: 25,
    paddingBottom: 5,
  },
  bottomCategoryContainer: {paddingTop: 8},
  categoriesContainer: {paddingHorizontal: 16, paddingTop: 5},
  categoryChip: {
    backgroundColor: '#F3F3F3',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    marginRight: 10,
  },
  categoryChipActive: {backgroundColor: '#111'},
  categoryText: {color: '#555', fontWeight: '500'},
  categoryTextActive: {color: '#FFF'},
  collectionContainer: {paddingVertical: 8},
  collectionHeading: {
    fontSize: 18,
    fontWeight: '700',
    marginLeft: 16,
    marginBottom: 8,
    color: '#111',
  },
  collectionCard: {
    width: width * 0.6,
    height: 160,
    borderRadius: 12,
    marginRight: 12,
    overflow: 'hidden',
    backgroundColor: '#eee',
  },
  collectionImage: {width: '100%', height: '100%'},
  collectionOverlay: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: 'flex-end',
    padding: 12,
    backgroundColor: 'rgba(0,0,0,0.3)',
  },
  collectionTitle: {color: '#fff', fontSize: 16, fontWeight: '600'},
  card: {
    backgroundColor: '#f9f9f9',
    borderRadius: 10,
    marginHorizontal: 16,
    marginBottom: 12,
    padding: 10,
    elevation: 2,
    flexDirection: 'row',
    alignItems: 'center',
  },
  cardImage: {width: 60, height: 60, borderRadius: 10, marginRight: 12},
  cardTitle: {fontSize: 16, fontWeight: '600', color: '#333'},
  cardSubtitle: {fontSize: 12, color: '#888'},
});

export default AnimatedProductScreen;
