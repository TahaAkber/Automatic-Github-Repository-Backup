import React, { useState } from 'react';
import { SafeAreaView, Text, StyleSheet, Platform, View } from 'react-native';

import {
    CodeField,
    Cursor,
    useBlurOnFulfill,
    useClearByFocusCell,
} from 'react-native-confirmation-code-field';
import CustomText from '@materialComponent/customText/customText';
import { moderateScale } from 'react-native-size-matters';
import { colors, WH } from '@constant/contstant';
import useOtpContainer from './useOtpContainer';



const OtpContainer = ({ route }) => {
    const { ref, props, value, setValue, CELL_COUNT } = useOtpContainer({ route })

    return (
        <SafeAreaView style={styles.root}>
            <CodeField
                autoComplete={Platform.select({ android: 'sms-otp', default: 'one-time-code' })}
                renderCell={({ index, symbol, isFocused }) => (
                    <View style={[styles.cell, isFocused && styles.focusCell, index < value?.length && { borderWidth: 1 , borderColor:"#007B5D" }]}>
                        <CustomText text={symbol || (isFocused ? <Cursor /> : null)} />
                    </View>
                )}
                rootStyle={styles.codeFieldRoot}
                textContentType="oneTimeCode"
                keyboardType="number-pad"
                onChangeText={setValue}
                cellCount={CELL_COUNT}
                testID="my-code-input"
                value={value}
                {...props}
                ref={ref}

            />
        </SafeAreaView>
    );
};

export default OtpContainer;

const styles = StyleSheet.create({
    title: {
        textAlign: 'center',
        fontSize: 30
    },
    codeFieldRoot: {
        marginTop: 20
    },
    cell: {
        fontSize: moderateScale(15),
        height: WH.width(12),
        width: WH.width(12),
        alignSelf: "center", verticalAlign: "center",
        borderColor: '#00000030',
        justifyContent: "center",
        alignItems: "center",
        textAlign: 'center',
        borderRadius: 10,
        lineHeight: 38,
        borderWidth: 1,
    },
    focusCell: {
        // borderColor: "#007B5D",
    },
});