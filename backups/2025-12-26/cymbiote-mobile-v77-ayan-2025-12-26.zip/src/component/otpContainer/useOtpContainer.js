import {
  useBlurOnFulfill,
  useClearByFocusCell,
} from 'react-native-confirmation-code-field';
import {_getStores} from '@redux/actions/merchant/merchant';
import {useNavigation} from '@react-navigation/native';
import useReduxStore from '@utils/hooks/useReduxStore';
import {_otpVerify} from '@redux/actions/auth/auth';
import {_login} from '@redux/actions/auth/auth';
import {useEffect, useState} from 'react';

const CELL_COUNT = 6;

const useOtpContainer = ({route}) => {
  const {getState, dispatch} = useReduxStore();
  const [value, setValue] = useState('');
  const navigation = useNavigation();

  const ref = useBlurOnFulfill({value, cellCount: CELL_COUNT});
  const [props, getCellOnLayoutHandler] = useClearByFocusCell({
    value,
    setValue,
  });

  const _handleSubmit = async () => {
    if (route?.data.forgotPassword) {
      const copyObj = {
        ...route,
        forgotPassword: true,
        data: {...route.data, otp: value},
      };
      const res = await dispatch(_otpVerify({data: copyObj.data}));
    } else {
      const copyObj = {...route, data: {...route.data, otp: value}};
      const res = await dispatch(_otpVerify({data: copyObj.data}));
    }
  };

  useEffect(() => {
    if (value && value.length == CELL_COUNT) {
      _handleSubmit();
    }
  }, [value]);

  return {
    _handleSubmit,
    setValue,
    CELL_COUNT,
    props,
    value,
    ref,
  };
};

export default useOtpContainer;
