import BottomSheetForBrand from '@materialComponent/bottomSheet/bottomSheetFormBrand';
import {
  Animated,
  Easing,
  StyleSheet,
  TouchableOpacity,
  View,
} from 'react-native';
import CustomText from '@materialComponent/customText/customText';
import {font, globalStyle, WH} from '@constant/contstant';
import {moderateScale} from 'react-native-size-matters';
import CustomImage from '@materialComponent/image/image';
import {brandThreeDots} from '@constant/dummyData';
import Icon from '@materialComponent/icon/icon';
import React, {useEffect, useRef, useState} from 'react';
import {colors} from '@constant/contstant';
import {navigate} from '@utils/navigationRef/navigationRef';
import {useDispatch} from 'react-redux';
import {_storeFollowingUpdateStatus} from '@redux/actions/merchant/merchant';
import useReduxStore from '@utils/hooks/useReduxStore';
import {_cartBottomSheet} from '../../redux/actions/common/common';
import LinearGradient from 'react-native-linear-gradient';
import useReels from '../../screen/reels/useReels';
import {_getStories} from '../../redux/actions/reels/reels';
import {Dimensions} from 'react-native';
import {goBack} from '../../utils/navigationRef/navigationRef';
import {logBrandFollowActionEvent, logHomeShopTileClickEvent} from '../../helper/eventTriggers/useEventTriggers';
import {timeAgo} from '../../utils/helper/helper';
const {fontScale, width, height} = Dimensions.get('screen');

const BrandTab = ({
  removeFollowText,
  item,
  text,
  light,
  cross,
  onPress,
  disabled,
  mainViewStyle,
  imageStyle,
  shopNameFontSize,
  followStyle,
  followColor,
  dot,
  isProductDetail,
  followSize,
  followText,
  followPress,
  removeStoryRing,
  navigateToReel,
  showFollowButton = true,
  showSearchIcon = false,
  onSearchPress = null,
  showBellIcon = false,
  onBellPress = null,
  disabledDots,
  isFromReels,
  handleToggleVolume,
  toggleVolume,
  horizontal,
  brand_screen,
  ratingSize,
  ratingIconSize,
  iconHorizontal,
  ratingStyle,
  tilePosition,
  markShopAsClicked,
  storyCreatedAt,
  id,
  shop,
  reel,
  story,
  crossColor,
}) => {
  const rotation = useRef(new Animated.Value(0)).current;
  // const {fetchStories, storiesLoader} = useReels({
  //   shop_id: item.shop_id,
  // });
  console.log(item?.shop_name, 'item in BrandTab component');
  const dispatch = useDispatch();

  const [isRotating, setIsRotating] = useState(false);
  const [animationDuration, setAnimationDuration] = useState(3000);
  const [loading, setLoading] = useState(false);
  const {getState} = useReduxStore();

  const {fetch_store_following_list_local, fetch_store_following_list} =
    getState('merchant');
  const {fetch_user_detail} = getState('auth');

  const existingIndex = fetch_store_following_list_local.findIndex(
    el => el.shop_id === item?.shop_id,
  );
  const liveStores = (fetch_store_following_list?.data || []).map(
    el => el?.shop_detail?.shop_id,
  );
  const localStores = fetch_store_following_list_local.map(el => el.shop_id);
  const finalArray = [...liveStores, ...localStores];

  console.log('finalArray', finalArray);

  const [follow, setFollow] = useState(false);
  const refRBSheet = useRef();

  const _handleFollow = async () => {
    try {
      setFollow(!follow);
      const response = await dispatch(
        _storeFollowingUpdateStatus(
          item?.shop_id,
          !follow,
          item,
          false,
          false,
          true,
        ),
      );
       logBrandFollowActionEvent(
              item,
              follow ? 'follow' : 'unfollow',
              true,
            );
    } catch (error) {
      console.log('error', error?.message);
    }
  };

  const _handleNavigate = async () => {
    if (tilePosition !== undefined) {
      await logHomeShopTileClickEvent(item, tilePosition);
    }
    if (markShopAsClicked) {
      markShopAsClicked(item?.shop_id);
    }
    dispatch(_cartBottomSheet(false));
    navigate('Brand', {shop_id: item.shop_id, shop: item});
  };

  const _handleNavigatetoReels = () => {
    navigate('Reels', {
      shopId: item.shop_id,
    });
  };

  const startRingAnimation = () => {
    setIsRotating(true);
    rotation.setValue(0); // Reset the rotation value to start from 0 degrees

    // Start rotating the ring indefinitely while the stories are loading
    Animated.loop(
      Animated.timing(rotation, {
        toValue: 1,
        duration: animationDuration, // Duration based on the API call duration
        easing: Easing.linear,
        useNativeDriver: true,
      }),
    ).start();

    // Fetch the stories after starting the animation
    loadStories();
  };

  const loadStories = async () => {
    const startTime = performance.now();
    setLoading(true);
    try {
      const userId = fetch_user_detail?.id;
      await dispatch(_getStories({shopId: item.shop_id, userId}));
      const endTime = performance.now();
      const apiDuration = endTime - startTime;
      setAnimationDuration(apiDuration);

      setIsRotating(false);
      rotation.stopAnimation();

      navigate('Stories', {from: 'popup'});
    } catch (error) {
      console.log('Error fetching stories:', error);
      setIsRotating(false);
    } finally {
      setLoading(false);
    }
  };

  const rotateInterpolate = rotation.interpolate({
    inputRange: [0, 1],
    outputRange: ['0deg', '360deg'],
  });
  console.log(item, '<><>item');
  useEffect(() => {
    setFollow(finalArray.includes(item?.shop_id));
  }, [finalArray.length]);

  console.log(imageStyle);

  const privacy_policy_url = item?.shop_privacy_policy_url;
  const return_policy_url = item?.shop_return_policy_url;
  const instagram_url = item?.shop_instagram_url;
  const facebook_url = item?.shop_facebook_url;
  const twitter_url = item?.shop_twitter_url;
  const web_url = item?.shop_web_url;

  const showDots = true;
  // const showDots =
  //   privacy_policy_url ||
  //   return_policy_url ||
  //   instagram_url ||
  //   facebook_url ||
  //   twitter_url ||
  //   web_url;
  console.log(timeAgo(storyCreatedAt), 'with funcSS');
  console.log(storyCreatedAt, 'withOUT funcSS');
  return (
    <TouchableOpacity
      activeOpacity={1}
      disabled={disabled}
      onPress={
        brand_screen
          ? goBack
          : navigateToReel
          ? _handleNavigatetoReels
          : _handleNavigate
      }
      style={[globalStyle.space_between, styles.topSection, mainViewStyle]}>
      {/* Left Section */}
      <View style={[globalStyle.row, {flex: 1}]}>
        {!removeStoryRing && item?.shopHaveStory ? (
          <TouchableOpacity onPress={startRingAnimation}>
            <LinearGradient
              colors={['#DE0046', '#F7A34B', '#C100CC']} // Closer to Instagram's
              start={{x: 0.1, y: 0.2}}
              end={{x: 0.9, y: 0.8}}
              locations={[0, 0.5, 1]}
              style={[
                styles.brandView,
                imageStyle,
                {justifyContent: 'center', alignItems: 'center'},
              ]}>
              {/* <View style={[styles.brandView, imageStyle]}> */}
              <CustomImage
                size={moderateScale(5)}
                source={{uri: item?.shop_logo_url}}
                style={[
                  {
                    width: '88%',
                    height: '88%',
                    borderRadius: 180,
                    justifyContent: 'center',
                    alignItems: 'center',
                  },
                ]}
              />
              {/* </View> */}
            </LinearGradient>
          </TouchableOpacity>
        ) : (
          <View style={[styles.brandView, imageStyle]}>
            <CustomImage
              source={{uri: item?.shop_logo_url}}
              style={styles.brandProfile}
              size={'small'}
            />
          </View>
        )}
        <View>
          <CustomText
            fontSize={shopNameFontSize || moderateScale(10)}
            style={[styles.brandText]}
            color={light || 'black'}
            fontFamily={font.bold}
            text={item?.shop_name}
          />
          {text ? (
            <CustomText
              fontSize={moderateScale(10)}
              style={styles.ratingText}
              color={light || 'black'}
              fontFamily={font.bold}
              text={text}
            />
          ) : storyCreatedAt ? (
            <CustomText
              fontSize={moderateScale(9)}
              style={styles.ratingText}
              color={light || 'rgba(255, 255, 255, 0.8)'}
              fontFamily={font.medium}
              text={timeAgo(storyCreatedAt, true)}
            />
          ) : (
            <View style={[globalStyle.row, ratingStyle]}>
              <CustomText
                fontSize={ratingSize || moderateScale(9)}
                style={styles.ratingText}
                color={light || 'black'}
                fontFamily={font.medium}
                text={item?.shop_rating ? item?.shop_rating?.toFixed(1) : '0'}
              />
              <Icon
                size={ratingIconSize || moderateScale(8)}
                color={light || '#9FCD22'}
                icon_type="FontAwesome"
                style={[
                  styles.icon,
                  iconHorizontal && {marginHorizontal: iconHorizontal},
                ]}
                name="star"
              />
              <CustomText
                fontSize={ratingSize || moderateScale(9)}
                color={light || 'black'}
                fontFamily={font.bold}
                text={`(${item?.total_reviews || 0})`}
              />
            </View>
          )}
        </View>
      </View>

      {/* Right Section */}

      <View style={[globalStyle.row, {alignItems: 'center'}]}>
        {showSearchIcon && (
          <TouchableOpacity onPress={onSearchPress} disabled={!onSearchPress}>
            <Icon
              icon_type="Ionicons"
              name="search"
              size={moderateScale(17)}
              style={{marginRight: 20}}
            />
          </TouchableOpacity>
        )}

        {showBellIcon && (
          <TouchableOpacity onPress={onBellPress} disabled={!onBellPress}>
            <Icon
              icon_type="FontAwesome"
              name="bell-o"
              color="black"
              size={moderateScale(17)}
              style={{marginRight: showDots ? 20 : 0}}
            />
          </TouchableOpacity>
        )}

        {cross && !dot ? (
          <TouchableOpacity
            onPress={onPress}
            style={[styles.followContainer, styles.circle]}>
            <Icon
              size={moderateScale(17)}
              color={crossColor || light || 'black'}
              icon_type="Ionicons"
              name="close"
            />
          </TouchableOpacity>
        ) : dot ? (
          <>
            {showDots ? (
              <>
                <TouchableOpacity
                  disabled={disabledDots}
                  onPress={() => refRBSheet?.current?.open()}>
                  <Icon
                    name="dots-three-horizontal"
                    size={moderateScale(20)}
                    color={light || 'black'}
                    icon_type="Entypo"
                  />
                </TouchableOpacity>
                {cross && (
                  <TouchableOpacity
                    onPress={onPress}
                    style={[
                      styles.followContainer,
                      styles.circle,
                      {marginLeft: moderateScale(15)},
                    ]}>
                    <Icon
                      size={moderateScale(17)}
                      color={crossColor || light || 'black'}
                      icon_type="Ionicons"
                      name="close"
                    />
                  </TouchableOpacity>
                )}
              </>
            ) : (
              <></>
            )}
          </>
        ) : (
          showFollowButton &&
          !removeFollowText && (
            <View style={styles.followContainer}>
              <TouchableOpacity
                key={finalArray.length}
                style={[
                  follow && styles.followingButton,
                  styles.followButton,
                  followStyle,
                ]}
                disabled={disabled}
                onPress={() => (followPress ? followPress() : _handleFollow())}>
                <CustomText
                  text={followText || (follow ? 'Following' : 'Follow')}
                  fontSize={followSize || moderateScale(12)}
                  color={followColor || 'white'}
                  fontFamily={font.medium}
                />
              </TouchableOpacity>
            </View>
          )
        )}

        {isFromReels && (
          <View style={styles.iconWrapper}>
            <TouchableOpacity
              onPress={handleToggleVolume}
              // disabled={saveLoading}
              style={[
                styles.iconContainer,
                {
                  height: width * 0.1,
                  width: width * 0.1,
                  marginHorizontal: 0,
                  backgroundColor: 'rgba(255, 255, 255, 0.3)',
                },
                // iconContainerStyle,
              ]}>
              <Icon
                icon_type={'MaterialIcons'}
                name={toggleVolume ? 'volume-off' : 'volume-up'}
                size={fontScale * 17}
                color={'white'}
              />
            </TouchableOpacity>
          </View>
        )}
      </View>

      <BottomSheetForBrand
        refRBSheet={refRBSheet}
        data={brandThreeDots}
        brand={item}
        isProductDetail={isProductDetail}
        shop={shop}
        reel={reel}
        story={story}
        id={id}
      />
    </TouchableOpacity>
  );
};

export default BrandTab;

const styles = StyleSheet.create({
  topSection: {
    paddingHorizontal: moderateScale(5),
    marginBottom: moderateScale(10),
    flexDirection: 'row', // Ensures row alignment
    alignItems: 'center',
  },
  brandView: {
    borderRadius: moderateScale(180),
    marginRight: moderateScale(10),
    backgroundColor: 'white',
    height: WH.width('12.5%'),
    width: WH.width('12.5%'),
    overflow: 'hidden',
  },
  brandProfile: {
    width: '100%',
    height: '100%',
  },
  brandText: {
    marginBottom: moderateScale(4),
  },
  icon: {
    marginHorizontal: moderateScale(6),
  },
  followContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  followButton: {
    paddingHorizontal: moderateScale(15),
    paddingVertical: moderateScale(6),
    borderRadius: moderateScale(10),
    // marginRight: moderateScale(10),
    backgroundColor: 'black',
    borderWidth: 0,
  },
  followingButton: {
    borderWidth: 1,
    borderColor: 'white',
  },
  circle: {
    backgroundColor: colors.light_theme.borderColor,
    width: moderateScale(25),
    justifyContent: 'center',
    alignItems: 'center',
    aspectRatio: 1 / 1,
    borderRadius: 180,
  },
  gradientBorder: {
    borderRadius: moderateScale(180),
    height: WH.width('11%'),
    width: WH.width('11%'),
    alignItems: 'center',
    justifyContent: 'center',
    padding: 3,
    // marginRight: moderateScale(10),
  },
  brandViewWithRing: {
    borderRadius: moderateScale(180),
    backgroundColor: 'white',
    height: WH.width('11%') - 3,
    width: WH.width('11%') - 3,
    overflow: 'hidden',
    // borderWidth: 1,
  },
  gradientWrapper: {
    justifyContent: 'center',
    alignItems: 'center',
    height: WH.width('10%'),
    width: WH.width('10%'),
    marginRight: moderateScale(10),
  },

  animatedRing: {
    position: 'absolute',
    height: WH.width('12%') - 2.5,
    width: WH.width('12%') - 2.5,
    borderRadius: WH.width('11%') / 2,
    overflow: 'hidden',
  },

  gradientRing: {
    height: '100%',
    width: '100%',
    borderRadius: WH.width('11%') / 2,
  },
  iconContainer: {
    // width: width * 0.12,
    // height: width * 0.12,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(34, 30, 30, 0.3)',
    borderRadius: (width * 0.15) / 2,
    marginHorizontal: moderateScale(4),
  },
});
