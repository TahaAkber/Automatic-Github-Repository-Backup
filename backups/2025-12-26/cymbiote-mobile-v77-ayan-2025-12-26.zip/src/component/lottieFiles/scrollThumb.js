// ScrollThumb.js
import React, {useRef} from 'react';
import {Dimensions, StyleSheet, View} from 'react-native';
import LottieView from 'lottie-react-native';
import Lottie from '@assets/lottie/scrollThumb.json';
import CustomText from '../../materialComponent/customText/customText';

const {width, height, fontScale} = Dimensions.get('screen');

const ScrollThumb = ({onFinish}) => {
  const lottieRef = useRef(null);

  return (
    <View style={styles.lottieContainer}>
      <LottieView
        ref={lottieRef}
        style={styles.lottie}
        source={Lottie}
        autoPlay
        loop={true}
        speed={1}
        onAnimationFinish={onFinish}
      />
      <CustomText text={'Swipe Up for More'} style={styles.text} />
    </View>
  );
};

export default ScrollThumb;

const styles = StyleSheet.create({
  lottie: {
    width: width * 70,
    height: height * 0.3, // Bigger vertical s
    marginBottom: 50, // Space from the bottom
  },

  lottieContainer: {
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 120, // Space from the bottom
  },
  text: {
    color: 'white',
    fontSize: fontScale * 20, // Adjusted for better visibility
    fontWeight: 'bold',
    position: 'absolute',
    bottom: 20, // Adjust as needed for better visibility
    marginTop: 80, // Space between the animation and text
  },
});
