import { Dimensions, StyleSheet, View } from 'react-native';
import React from 'react';
import { WH } from '@constant/contstant';
import CustomSkeleton from '@materialComponent/customSkeleton/customSkeleton';
import { moderateScale, verticalScale } from 'react-native-size-matters';
import { margin } from '../../constant/contstant';

const { height, width } = Dimensions.get("screen")

const OrderLoader = ({ loading, removeHorizontalMargin, rounded, marginTop }) => {
  return (
    <View style={[styles.container, { marginHorizontal: removeHorizontalMargin ? 0 : margin.horizontal, marginTop: marginTop || height * 0.00 }]}>
      {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((_, index) => (
        <View key={index} style={styles.cardSkeleton}>
          <CustomSkeleton
            loading={loading}
            style={[styles.imageSkeleton, rounded && { borderRadius: 180 }]}
          />
          <View style={styles.rightContainer}>
            <View style={[styles.topRow,]}>
              <CustomSkeleton
                loading={loading}
                style={styles.orderTitleSkeleton}
              />
            </View>
            <CustomSkeleton
              loading={loading}
              style={styles.detailsSkeleton}
            />
          </View>
        </View>
      ))}
    </View>
  );
};

export default OrderLoader;

const styles = StyleSheet.create({
  container: {
    marginHorizontal: margin.horizontal,
    marginTop: height * 0.01
  },
  cardSkeleton: {
    flexDirection: 'row', // Align image and content in a row
    marginTop: height * 0.01,
    padding: moderateScale(10),
    borderRadius: moderateScale(10),
    backgroundColor: 'white', // Light gray background for the card
  },
  imageSkeleton: {
    // width: WH.width(15), // Adjust width for the image placeholder
    // height: WH.width(15), // Adjust height for the image placeholder
    // borderRadius: moderateScale(10), // Rounded corners for the image
    // marginRight: moderateScale(10), // Spacing between image and content
    width: width * 0.12, aspectRatio: 1, borderRadius: 5
  },
  rightContainer: {
    flex: 1, // Take remaining space
    justifyContent: "space-evenly",
    marginLeft: "2%",
  },
  topRow: {
    flexDirection: 'row', // Align order title and button in a row
    justifyContent: 'space-between', // Space between title and button
    marginBottom: verticalScale(5), // Spacing between top row and details
  },
  orderTitleSkeleton: {
    width: WH.width(15), // Adjust width for the order title
    height: verticalScale(7), // Adjust height for the order title
    borderRadius: moderateScale(5),
    // marginTop: moderateScale(5)
  },
  buttonSkeleton: {
    width: WH.width(20), // Adjust width for the button
    height: verticalScale(20), // Adjust height for the button
    borderRadius: moderateScale(5),
    marginTop: moderateScale(2)
  },
  detailsSkeleton: {
    width: WH.width(30), // Adjust width for the order title
    height: verticalScale(7), // Adjust height for the details
    borderRadius: moderateScale(5),

  },
});