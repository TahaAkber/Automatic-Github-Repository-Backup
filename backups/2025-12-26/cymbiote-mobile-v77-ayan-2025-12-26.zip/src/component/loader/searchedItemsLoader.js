import {
  Dimensions,
  FlatList,
  Image,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import React from 'react';
import {colors, globalStyle, WH} from '@constant/contstant';
import Container from '@materialComponent/container/container';
import CustomSkeleton from '@materialComponent/customSkeleton/customSkeleton';
import CartBackgroundSvg from '../../assets/images/cart_background';

const {height, width, fontScale} = Dimensions.get('screen');

const dynamicWith = width * 0.44;
const dynamicHeight = width * 0.4;

const SearchedItemsLoader = ({category, marginTop, removeProducts}) => {
  return (
    <View
      style={{
        width: '100%',
        marginTop,
        // paddingHorizontal: width * 0.03,
      }}>
      <View>
        {category ? (
          <>
            <FlatList
              scrollEnabled={false}
              data={[1, 2, 3, 4, 5, 6]}
              columnWrapperStyle={{
                justifyContent: 'space-between',
              }}
              renderItem={({item, index}) => {
                return (
                  <View
                    style={{
                      marginTop: index == 0 || index == 1 ? 0 : height * 0.02,
                    }}>
                    <CustomSkeleton
                      loading={true}
                      highlightColor={'#F9F9F9'}
                      style={[
                        styles.image,
                        {height: height * 0.1, marginRight: 0},
                      ]}
                    />
                  </View>
                );
              }}
              keyExtractor={(item, index) => index.toString()}
              showsHorizontalScrollIndicator={false}
              numColumns={2}
              contentContainerStyle={{marginTop: height * 0.02}}
              // ListFooterComponent={() => {
              //   return (
              //     <>
              //       {paginationLoader && <PagionationLoader />}
              //     </>
              //   )
              // }}
            />
            <View style={{width: '100%', marginTop: height * 0.01}}>
              <CustomSkeleton
                loading={true}
                highlightColor={'#F9F9F9'}
                style={[{height: height * 0.08, borderRadius: 10}]}
              />
            </View>
          </>
        ) : (
          <></>
        )}

        {removeProducts ? (
          <></>
        ) : (
          <FlatList
            scrollEnabled={false}
            data={[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]}
            columnWrapperStyle={{justifyContent: 'space-between'}}
            renderItem={({item, index}) => {
              return (
                <View
                  style={{
                    marginTop: index == 0 || index == 1 ? 0 : height * 0.02,
                  }}>
                  <CustomSkeleton
                    loading={true}
                    highlightColor={'#F9F9F9'}
                    style={styles.image}
                  />
                  <View style={{marginTop: height * 0.01}}>
                    <CustomSkeleton
                      loading={true}
                      highlightColor={'#F9F9F9'}
                      style={styles.text}
                    />
                  </View>
                  <View style={{marginTop: height * 0.01}}>
                    <CustomSkeleton
                      loading={true}
                      highlightColor={'#F9F9F9'}
                      style={styles.desc}
                    />
                  </View>
                </View>
              );
            }}
            keyExtractor={(item, index) => index.toString()}
            showsHorizontalScrollIndicator={false}
            numColumns={2}
            contentContainerStyle={{marginTop: height * 0.02}}
            // ListFooterComponent={() => {
            //   return (
            //     <>
            //       {paginationLoader && <PagionationLoader />}
            //     </>
            //   )
            // }}
          />
        )}
      </View>
    </View>
  );
};

export default React.memo(SearchedItemsLoader);

const styles = StyleSheet.create({
  image: {
    width: dynamicWith,
    height: dynamicHeight,
    borderRadius: 10,
    // marginRight: width * 0.01,
  },
  text: {
    width: width * 0.4,
    height: width * 0.03,
    borderRadius: 10,
    marginRight: width * 0.01,
  },
  desc: {
    width: width * 0.2,
    height: width * 0.03,
    borderRadius: 10,
    marginRight: width * 0.01,
  },
});
