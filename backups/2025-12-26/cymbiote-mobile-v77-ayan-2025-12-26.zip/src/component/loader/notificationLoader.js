import {Dimensions, FlatList, StyleSheet, View} from 'react-native';
import React from 'react';
import CustomSkeleton from '@materialComponent/customSkeleton/customSkeleton';
import {moderateScale, verticalScale} from 'react-native-size-matters';
import {margin} from '../../constant/contstant';

const {height} = Dimensions.get('screen');

const NotificationLoader = ({loading}) => {
  const renderItem = ({item, index}) => {
    return (
      <View style={styles.container}>
        <View style={[styles.topRow, {borderTopWidth: index == 0 ? 1 : 0}]}>
          <CustomSkeleton loading={loading} style={styles.image} />
          <View style={styles.textContainer}>
            <CustomSkeleton loading={loading} style={styles.text} />
            <View style={styles.descContainer}>
              <CustomSkeleton loading={loading} style={styles.desc} />
            </View>
          </View>
        </View>
      </View>
    );
  };

  return (
    <FlatList
      data={Array(12).fill(null)} // This will render 12 skeleton items
      renderItem={renderItem}
      keyExtractor={(item, index) => index.toString()}
    />
  );
};

export default NotificationLoader;

const styles = StyleSheet.create({
  container: {
    // marginBottom: verticalScale(10), // Space between each skeleton loader
  },
  topRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f6f8f9', // Remove or replace with actual color
    paddingVertical: verticalScale(10),
    paddingHorizontal: margin.horizontal,
    borderBottomWidth: 1, // border is consistent now
    borderColor: '#E0E0E0', // specify a consistent color for the bottom border
  },
  image: {
    height: moderateScale(50),
    width: moderateScale(50),
    borderRadius: 180,
  },
  textContainer: {
    marginLeft: 8,
    width: '70%',
  },
  text: {
    height: verticalScale(7),
    borderRadius: moderateScale(5),
  },
  descContainer: {
    marginTop: 5,
    width: '40%',
  },
  desc: {
    height: verticalScale(7),
    borderRadius: moderateScale(5),
  },
});
