
import { Dimensions, FlatList, Image, StyleSheet, Text, View } from 'react-native'
import React from 'react'
import { colors, globalStyle, WH } from '@constant/contstant';
import Container from '@materialComponent/container/container';
import CustomSkeleton from '@materialComponent/customSkeleton/customSkeleton';
import CartBackgroundSvg from '../../assets/images/cart_background';
import { margin } from '../../constant/contstant';

const { height, width, fontScale } = Dimensions.get("screen")

const RedeemStoreLoader = () => {
    const renderItem = ({ item, index }) => {
        return (
            <View style={{ marginTop: index > 2 ? height * 0.01 : 0 }}>
                <CustomSkeleton
                    style={styles.voucher}
                    loading={true}
                />
                <View style={{ marginTop: height * 0.01 }}>
                    <CustomSkeleton
                        style={{ width: width * 0.15, height: height * 0.01, borderRadius: 10 }}
                        loading={true}
                    />
                </View>
                <View style={{ marginTop: height * 0.01 }}>
                    <CustomSkeleton
                        style={{ width: width * 0.1, height: height * 0.01, borderRadius: 10 }}
                        loading={true}
                    />
                </View>
            </View>
        )
    };
    return (
        <Container barColor={colors.light_theme.themeBackgroundColor}>
            <FlatList
                scrollEnabled={true}
                data={[1, 2, 3, 4, 5, 6, 7, , 8, 9, 10, 11, , 12, 13, 14, 15]}
                renderItem={renderItem}
                keyExtractor={(item, index) => index.toString()}
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={styles.shopsList}
                columnWrapperStyle={{ justifyContent: "space-between", marginTop: height * 0.01 }}
                numColumns={3}
                showsVerticalScrollIndicator={false}
            />

        </Container >
    )
}

export default RedeemStoreLoader

const styles = StyleSheet.create({
    voucher: {
        width: WH.width(28),
        height: height * 0.1,
        borderRadius: 10,
    },
    shopsList: {
        marginHorizontal: margin.horizontal,
        marginTop : height * 0.02
    }
})