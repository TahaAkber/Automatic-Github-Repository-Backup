// src/component/loader/CollectionLoader.js

import React from 'react';
import {View, StyleSheet, Dimensions, FlatList} from 'react-native';
import CustomSkeleton from '@materialComponent/customSkeleton/customSkeleton';
import {margin, WH} from '@constant/contstant';


const {width,height} = Dimensions.get('screen');

const CollectionLoader = () => {
  const dummyItems = Array(3).fill(null);

  return (

    <FlatList
      data={dummyItems}
      horizontal
      showsHorizontalScrollIndicator={false}
      keyExtractor={(_, index) => index.toString()}
      contentContainerStyle={{paddingHorizontal: margin.horizontal}}
      renderItem={() => (
        <View style={styles.skeletonCard}>
          <CustomSkeleton loading style={styles.image} />
        </View>
      )}
    />

  );
};

const styles = StyleSheet.create({
  skeletonCard: {
    width: WH.width(40),
    marginRight: width * 0.03,
    marginTop:height * 0.02,
  },
  image: {
    width: WH.width(40),
    height: WH.width(30),
    borderRadius: 10,
  },
});

export default CollectionLoader;
