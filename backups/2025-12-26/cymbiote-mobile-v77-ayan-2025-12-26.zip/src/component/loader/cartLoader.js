import React from 'react';
import {View, StyleSheet, Dimensions} from 'react-native';
import {moderateScale, scale, verticalScale} from 'react-native-size-matters';
import CustomSkeleton from '@materialComponent/customSkeleton/customSkeleton';

const {width, height} = Dimensions.get('screen');

const CartLoader = () => {
  return (
    <View style={styles.container}>
      {[...Array(2)].map((_, shopIndex) => (
        <View key={shopIndex} style={styles.card}>
          {/* Shop Header Skeleton */}
          <View style={styles.brandSection}>
            <CustomSkeleton loading style={styles.shopLogo} />
            <CustomSkeleton loading style={styles.shopName} />
          </View>

          {[...Array(2)].map((_, productIndex) => (
            <View key={productIndex} style={styles.productCard}>
              <CustomSkeleton loading style={styles.image} />

              <View style={styles.textWrapper}>
                <CustomSkeleton loading style={styles.titleLine} />
                <CustomSkeleton loading style={styles.optionLine} />
                <View style={styles.bottomRow}>
                  <CustomSkeleton loading style={styles.priceLine} />
                  <View style={styles.qtyButtons}>
                    <CustomSkeleton loading style={styles.qtyButton} />
                    <CustomSkeleton loading style={styles.qtyCounter} />
                    <CustomSkeleton loading style={styles.qtyButton} />
                  </View>
                </View>
              </View>
            </View>
          ))}

          {/* Button Skeleton */}
          <View style={styles.buttonWrapper}>
            <CustomSkeleton loading style={styles.checkoutButton} />
          </View>
        </View>
      ))}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: scale(10),
    paddingTop: verticalScale(20),
  },
  card: {
    backgroundColor: '#EFEFEF', // light soft blue
    padding: scale(12),
    borderRadius: 20,
    marginBottom: verticalScale(25),
    borderWidth: 1,
    borderColor: '#EFEFEF',
  },
  brandSection: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: verticalScale(10),
  },
  shopLogo: {
    width: moderateScale(40),
    height: moderateScale(40),
    borderRadius: 20,
  },
  shopName: {
    marginLeft: 10,
    width: moderateScale(120),
    height: moderateScale(14),
    borderRadius: 10,
  },
  productCard: {
    flexDirection: 'row',
    marginTop: verticalScale(15),
  },
  image: {
    width: width * 0.18,
    height: width * 0.18,
    borderRadius: 8,
    marginRight: scale(10),
  },
  textWrapper: {
    flex: 1,
    justifyContent: 'space-between',
  },
  titleLine: {
    width: '70%',
    height: moderateScale(14),
    borderRadius: 6,
    marginBottom: verticalScale(8),
  },
  optionLine: {
    width: '50%',
    height: moderateScale(12),
    borderRadius: 6,
    marginBottom: verticalScale(8),
  },
  priceLine: {
    width: '40%',
    height: moderateScale(14),
    borderRadius: 6,
  },
  bottomRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  qtyButtons: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
  },
  qtyButton: {
    width: moderateScale(25),
    height: moderateScale(25),
    borderRadius: 5,
  },
  qtyCounter: {
    width: moderateScale(30),
    height: moderateScale(14),
    borderRadius: 5,
  },
  buttonWrapper: {
    marginTop: verticalScale(20),
    alignItems: 'center',
  },
  checkoutButton: {
    width: '90%',
    height: moderateScale(40),
    borderRadius: 180,
  },
});

export default CartLoader;
