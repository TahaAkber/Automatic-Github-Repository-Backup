import {verticalScale} from 'react-native-size-matters';
import {Dimensions, StyleSheet, View} from 'react-native';
import React, {useRef, useEffect} from 'react';
import LottieView from 'lottie-react-native';
import Lottie from '@assets/lottie/paginationLoader.json';

const {width} = Dimensions.get('screen');

const PagionationLoader = ({size}) => {
  const lottieRef = useRef(null);

  useEffect(() => {
    if (lottieRef.current) {
      lottieRef.current.play();
    }
  }, []);

  const handleAnimationFinish = () => {
    if (lottieRef.current) {
      // Restart immediately, no wait
      lottieRef.current.play();
    }
  };

  return (
    <View style={!size ? styles.mainView : null}>
      <LottieView
        ref={lottieRef}
        style={styles.lootie}
        source={Lottie}
        autoPlay
        loop={false} // We disable internal loop
        speed={0.5}
        onAnimationFinish={handleAnimationFinish} // Manually handle the loop
        cacheComposition // Caches the animation for better performance
        enableMergePathsAndroidForKitKatAndAbove // Android rendering optimization
      />
    </View>
  );
};

export default PagionationLoader;

const styles = StyleSheet.create({
  mainView: {
    marginVertical: verticalScale(20),
    marginBottom: verticalScale(50),
    backgroundColor: 'transparent',
  },
  lootie: {
    width: width * 0.1,
    height: width * 0.1,
    alignSelf: 'center',
    backgroundColor: 'transparent',
  },
});
