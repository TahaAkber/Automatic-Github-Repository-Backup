import {View, StyleSheet, Dimensions} from 'react-native';
import React from 'react';
import CustomSkeleton from '@materialComponent/customSkeleton/customSkeleton';
import {moderateScale, verticalScale} from 'react-native-size-matters';
import {margin, WH} from '@constant/contstant';

const {width} = Dimensions.get('screen');

const ReviewDetailLoader = ({loading}) => {
  return (
    <View style={styles.container}>
      {/* Header */}

      {/* Product Row */}
      <View style={styles.productRow}>
        <CustomSkeleton loading={loading} style={styles.productImage} />
        <View style={styles.productDetails}>
          <CustomSkeleton loading={loading} style={styles.productTitle} />
          <View style={styles.productSubRow}>
            <CustomSkeleton loading={loading} style={styles.price} />
            <CustomSkeleton loading={loading} style={styles.qty} />
          </View>
        </View>
      </View>

      {/* Reviewer Info */}
      <View style={styles.reviewerRow}>
        <CustomSkeleton loading={loading} style={styles.avatar} />
        <View>
          <CustomSkeleton loading={loading} style={styles.nameLine} />
          <CustomSkeleton loading={loading} style={styles.timeLine} />
        </View>
      </View>

      {/* Review Text */}
      <View style={{marginTop: verticalScale(15)}}>
        <CustomSkeleton loading={loading} style={styles.textLine} />
        <CustomSkeleton
          loading={loading}
          style={[styles.textLine, {width: '90%'}]}
        />
        <CustomSkeleton
          loading={loading}
          style={[styles.textLine, {width: '70%'}]}
        />
      </View>

      {/* Image Carousel */}
      <View style={{marginTop: verticalScale(30)}}>
        <CustomSkeleton loading={loading} style={styles.carouselImage} />
      </View>

      {/* Brand Reply */}
      <View style={styles.brandRow}>
        <CustomSkeleton loading={loading} style={styles.brandLogo} />
        <View style={{flex: 1, marginLeft: 10}}>
          <CustomSkeleton loading={loading} style={styles.brandName} />
          <CustomSkeleton loading={loading} style={styles.replyLine} />
          <CustomSkeleton loading={loading} style={styles.replyDate} />
        </View>
        <CustomSkeleton loading={loading} style={styles.likeIcon} />
      </View>

      {/* Bottom Bar */}
      {/* <View style={styles.bottomBar}>
        {[1, 2, 3, 4].map((_, index) => (
          <CustomSkeleton key={index} loading={loading} style={styles.navIcon} />
        ))}
      </View> */}
    </View>
  );
};

export default ReviewDetailLoader;
const styles = StyleSheet.create({
  container: {
    padding: margin.horizontal,
    paddingTop: verticalScale(20),
  },

  productRow: {
    flexDirection: 'row',
    marginBottom: verticalScale(16),
  },
  productImage: {
    width: WH.width(20),
    aspectRatio: 1,
    borderRadius: 6,
  },
  productDetails: {
    flex: 1,
    marginLeft: '4%',
    justifyContent: 'space-evenly',
  },
  productTitle: {
    width: WH.width(60),
    height: 15,
    borderRadius: 4,
    marginBottom: 6,
  },
  productSubRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: WH.width(60),
  },
  price: {
    width: 60,
    height: 12,
    borderRadius: 4,
  },
  qty: {
    width: 40,
    height: 12,
    borderRadius: 4,
  },
  reviewerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    //   marginBottom: verticalScale(8),
    marginTop: verticalScale(8),
  },
  avatar: {
    width: '15%',
    aspectRatio: 1,
    borderRadius: 35,
    marginRight: width * 0.02,
  },
  nameLine: {
    width: 100,
    height: 15,
    borderRadius: 4,
    marginBottom: 4,
  },
  timeLine: {
    width: 80,
    height: 12,
    borderRadius: 4,
  },
  textLine: {
    width: '100%',
    height: 12,
    borderRadius: 4,
    marginBottom: 6,
  },
  carouselImage: {
    width: '100%',
    height: verticalScale(230),
    borderRadius: 12,
    //   marginTop: verticalScale(30),
    marginBottom: verticalScale(20),
  },
  brandRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: verticalScale(30),
  },
  brandLogo: {
    width: '15%',
    aspectRatio: 1,
    borderRadius: 35,
    //   marginTop: width *0.02,
  },
  replyLine: {
    width: WH.width(55),
    height: 12,
    borderRadius: 4,
    marginBottom: 6,
  },
  replyDate: {
    width: WH.width(20),
    height: 12,
    borderRadius: 4,
    // marginBottom: 2,
  },
  likeIcon: {
    width: '10%',
    height: 22,
    borderRadius: 4,
    //   marginLeft: 8,
  },
  bottomBar: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  navIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
  },
  brandName: {
    width: '20%',
    height: 10,
    borderRadius: 4,
    marginBottom: 6,
  },
});
