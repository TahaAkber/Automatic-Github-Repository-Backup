import React from 'react';
import { View, StyleSheet, Dimensions } from 'react-native';
import CustomSkeleton from '@materialComponent/customSkeleton/customSkeleton';

const { width } = Dimensions.get('screen');

const FollowingLoader = () => (
  <View style={styles.container}>
    {/* Search Bar Skeleton */}
    {/* <CustomSkeleton 
      loading={true} 
      style={styles.searchBar} 
    /> */}
    
    {/* Following Stores Header */}
    <CustomSkeleton 
      loading={true} 
      style={styles.sectionHeader} 
    />
    
    {/* Store List Skeleton */}
  <></>
    <View style={styles.storeList}>
      {[...Array(5)].map((_, index) => (
        <View key={index} style={styles.storeItem}>
          <CustomSkeleton 
            loading={true} 
            style={styles.storeImage} 
          />
          <View style={styles.storeInfo}>
        
          </View>
        </View>
      ))}
    </View>
    
    {/* Products Section Header */}
    <CustomSkeleton 
      loading={true} 
      style={styles.sectionHeader} 
    />
    
    {/* Products Grid Skeleton */}
    <View style={styles.productsGrid}>
      {/* {[...Array(9)].map((_, index) => (
        <View key={index} style={styles.productItem}>
          <CustomSkeleton 
            loading={true} 
            style={styles.productImage} 
          />
          <CustomSkeleton 
            loading={true} 
            style={styles.productName} 
          />
          <CustomSkeleton 
            loading={true} 
            style={styles.productPrice} 
          />
        </View>
      ))} */}
      <CustomSkeleton loading={true} style={styles.productImage} />
           <CustomSkeleton loading={true} style={styles.productImage} />
    </View>
  </View>
);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 15,
    backgroundColor: '#fff',
  },
  searchBar: {
    height: 50,
    borderRadius: 25,
    marginBottom: 20,
    backgroundColor: '#e0e0e0',
  },
  sectionHeader: {
    height: 25,
    width: 150,
    borderRadius: 5,
    marginBottom: 15,
    backgroundColor: '#e0e0e0',
  },
  storeList: {
    marginBottom: 25,
    flexDirection: 'row',
    justifyContent:"center",

  },
  storeItem: {
    flexDirection: 'row',
    marginBottom: 15,
    alignItems: 'center',
  },
  storeImage: {
    width: 60,
    height: 60,
    borderRadius: 30,
    marginRight: 7,
    backgroundColor: '#e0e0e0',
  },
  storeInfo: {
    flex: 1,
  },
  storeName: {
    height: 20,
    width: '60%',
    marginBottom: 5,
    borderRadius: 5,
    backgroundColor: '#e0e0e0',
  },
  storeRating: {
    height: 15,
    width: '40%',
    marginBottom: 5,
    borderRadius: 5,
    backgroundColor: '#e0e0e0',
  },
  followingBadge: {
    height: 20,
    width: 80,
    borderRadius: 10,
    backgroundColor: '#e0e0e0',
  },
  productsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  productItem: {
    width: '28%',
    marginBottom: 20,
   
    
  },
  productImage: {
    width: '100%',
    height: 300,
    borderRadius: 10,
    marginBottom: 8,
    backgroundColor: '#e0e0e0',
  },
  productName: {
    height: 16,
    width: '80%',
    marginBottom: 5,
    borderRadius: 5,
    backgroundColor: '#e0e0e0',
  },
  productPrice: {
    height: 14,
    width: '60%',
    borderRadius: 5,
    backgroundColor: '#e0e0e0',
  },
});

export default FollowingLoader;