import {moderateScale} from 'react-native-size-matters';
import Lottie from '@assets/lottie/chatTyping.json';
import {StyleSheet, View} from 'react-native';
import LottieView from 'lottie-react-native';
import {WH} from '@constant/contstant';
import React from 'react';

const GlobalLoader = () => {
  return (
    <View style={styles.mainView}>
      <View style={styles.lottieContainer}>
        <LottieView
          style={[styles.lootie]}
          source={Lottie}
          speed={0.7}
          autoPlay
          loop
        />
      </View>
    </View>
  );
};
export default GlobalLoader;

const styles = StyleSheet.create({
  mainView: {
    height: WH.height('100%'),
    width: WH.width('100%'),
    backgroundColor: 'rbga(rgba(0,0,0,0.8)',
    justifyContent: 'center',
    alignItems: 'center',
    position: 'absolute',
    flex: 1,
  },
  lootie: {
    overflow: 'hidden',
    borderRadius: 180,
    height: '60%',
    width: '60%',
  },
  lottieContainer: {
    height: moderateScale(90),
    width: moderateScale(90),
    backgroundColor: 'white',
    overflow: 'hidden',
    borderRadius: 180,
  },
});
