import {Dimensions, StyleSheet, View} from 'react-native';
import React from 'react';
import {WH} from '@constant/contstant';
import CustomSkeleton from '@materialComponent/customSkeleton/customSkeleton';
import {moderateScale, verticalScale} from 'react-native-size-matters';
import {globalStyle, margin} from '../../constant/contstant';

const {height, width} = Dimensions.get('screen');

const BrandLoader = ({loading}) => {
  return (
    <View style={styles.container}>
      {/* Banner Skeleton */}
      <CustomSkeleton loading={loading} style={styles.bannerSkeleton} />

      {/* Logo Skeleton */}
      <View style={styles.logoContainer}>
        <CustomSkeleton loading={loading} style={styles.logoSkeleton} />
      </View>

      {/* Profile Image Skeleton */}
      <CustomSkeleton loading={loading} style={styles.profileImageSkeleton} />

      {/* Content Area */}
      <View style={styles.contentContainer}>
        {/* Shop Name */}
        <CustomSkeleton loading={loading} style={styles.shopNameSkeleton} />

        {/* Rating Row */}
        <View style={styles.ratingRow}>
          <CustomSkeleton loading={loading} style={styles.ratingSkeleton} />
          <CustomSkeleton loading={loading} style={styles.starSkeleton} />
          <CustomSkeleton
            loading={loading}
            style={styles.ratingCountSkeleton}
          />
        </View>

        {/* Description */}
        <CustomSkeleton loading={loading} style={styles.descriptionSkeleton} />
        <CustomSkeleton
          loading={loading}
          style={[styles.descriptionSkeleton, {width: '80%'}]}
        />

        {/* Buttons Row */}
        <View style={styles.buttonsRow}>
          <CustomSkeleton
            loading={loading}
            style={styles.followButtonSkeleton}
          />
          <CustomSkeleton loading={loading} style={styles.iconButtonSkeleton} />
          <CustomSkeleton loading={loading} style={styles.iconButtonSkeleton} />
        </View>

        {/* Collections Title */}
        <CustomSkeleton loading={loading} style={styles.sectionTitleSkeleton} />

        {/* Collections Row */}
        <View style={styles.collectionsRow}>
          {[1, 2, 3, 4].map((_, index) => (
            <CustomSkeleton
              key={index}
              loading={loading}
              style={styles.collectionItemSkeleton}
            />
          ))}
        </View>

        {/* Products Grid */}
        <View style={styles.productsGrid}>
          {[1, 2, 3, 4, 5, 6].map((_, index) => (
            <View key={index} style={styles.productItem}>
              <CustomSkeleton
                loading={loading}
                style={styles.productImageSkeleton}
              />
              <CustomSkeleton
                loading={loading}
                style={styles.productTitleSkeleton}
              />
              <CustomSkeleton
                loading={loading}
                style={styles.productPriceSkeleton}
              />
            </View>
          ))}
        </View>
      </View>
    </View>
  );
};

export default BrandLoader;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  bannerSkeleton: {
    height: height * 0.4,
    width: '100%',
  },
  logoContainer: {
    position: 'absolute',
    top: height * 0.3,
    alignSelf: 'center',
  },
  logoSkeleton: {
    width: width * 0.5,
    aspectRatio: 1,
    borderRadius: moderateScale(10),
  },
  profileImageSkeleton: {
    width: width * 0.27,
    height: height * 0.12,
    borderRadius: 100,
    borderWidth: 3,
    borderColor: '#fff',
    position: 'absolute',
    top: height * 0.35,
    left: 10,
    backgroundColor: '#f0f0f0',
    zIndex: 2,
  },
  contentContainer: {
    // marginTop: -20,
    backgroundColor: '#f0f0f0',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    paddingTop: height * 0.08,
    paddingHorizontal: margin.horizontal,
    flex: 1,
    zIndex: 1,
  },
  shopNameSkeleton: {
    width: '60%',
    height: verticalScale(25),
    borderRadius: moderateScale(5),
    marginBottom: verticalScale(10),
  },
  ratingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: verticalScale(10),
  },
  ratingSkeleton: {
    width: width * 0.1,
    height: verticalScale(15),
    borderRadius: moderateScale(5),
  },
  starSkeleton: {
    width: width * 0.05,
    height: verticalScale(15),
    borderRadius: moderateScale(5),
    marginLeft: moderateScale(10),
  },
  ratingCountSkeleton: {
    width: width * 0.1,
    height: verticalScale(15),
    borderRadius: moderateScale(5),
    marginLeft: moderateScale(10),
  },
  descriptionSkeleton: {
    width: '100%',
    height: verticalScale(15),
    borderRadius: moderateScale(5),
    marginBottom: verticalScale(5),
  },
  buttonsRow: {
    flexDirection: 'row',
    marginVertical: verticalScale(15),
  },
  followButtonSkeleton: {
    width: width * 0.4,
    height: verticalScale(45),
    borderRadius: moderateScale(5),
  },
  iconButtonSkeleton: {
    width: width * 0.1,
    height: verticalScale(45),
    borderRadius: moderateScale(5),
    marginLeft: moderateScale(10),
  },
  sectionTitleSkeleton: {
    width: '40%',
    height: verticalScale(20),
    borderRadius: moderateScale(5),
    marginVertical: verticalScale(15),
  },
  collectionsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: verticalScale(15),
  },
  collectionItemSkeleton: {
    width: width * 0.22,
    height: verticalScale(80),
    borderRadius: moderateScale(5),
  },
  productsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  productItem: {
    width: width * 0.43,
    marginBottom: verticalScale(20),
  },
  productImageSkeleton: {
    width: '100%',
    height: height * 0.2,
    borderRadius: moderateScale(10),
  },
  productTitleSkeleton: {
    width: '70%',
    height: verticalScale(15),
    borderRadius: moderateScale(5),
    marginTop: verticalScale(5),
  },
  productPriceSkeleton: {
    width: '30%',
    height: verticalScale(12),
    borderRadius: moderateScale(5),
    marginTop: verticalScale(5),
  },
});
