import { Dimensions, StyleSheet, View } from 'react-native';
import React from 'react';
import CustomSkeleton from '@materialComponent/customSkeleton/customSkeleton';
import { WH } from '@constant/contstant';
import { moderateScale, verticalScale } from 'react-native-size-matters';
import { margin } from '@constant/contstant';

const { height, width } = Dimensions.get('screen');

const ProductReviewListLoader = ({ loading }) => {
  return (
    <View style={styles.container}>
      {/* Reviews List Skeleton */}
      <View style={styles.reviewsContainer}>
        {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((_, index) => (
          <View key={index} style={styles.reviewCard}>
            {/* Avatar Skeleton */}
            <CustomSkeleton loading={loading} style={styles.reviewAvatar} />
            <View style={styles.reviewContent}>
              {/* Name Skeleton */}
              <CustomSkeleton loading={loading} style={styles.reviewTitle} />
              {/* Star Rating Skeleton */}
              <CustomSkeleton
                loading={loading}
                style={styles.starRatingSkeleton}
              />
              {/* Comment Skeleton */}
              <CustomSkeleton loading={loading} style={styles.reviewText} />
              {/* Image in Comment Skeleton */}
              {/* <View style={{flexDirection: 'row'}}>
                {[1, 2, 3, 4, 5].map(() => (
                  <CustomSkeleton
                    loading={loading}
                    style={styles.commentImage}
                  />
                ))}
              </View> */}
              {/* Additional Lines Skeleton */}
              {/* <CustomSkeleton loading={loading} style={styles.additionalLine} /> */}
              {/* <CustomSkeleton loading={loading} style={styles.additionalLine} /> */}
            </View>
          </View>
        ))}
      </View>
    </View>
  );
};

export default ProductReviewListLoader;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: margin.horizontal,
    // paddingTop: height * 0.1,
  },
  reviewsContainer: {
    marginTop: height * 0.02,
  },
  reviewCard: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: height * 0.03,
  },
  reviewAvatar: {
    width: WH.width(15),
    height: WH.width(15),
    borderRadius: WH.width(7.5),
    marginRight: WH.width(5),
  },
  reviewContent: {
    flex: 1,
  },
  reviewTitle: {
    width: WH.width(40),
    height: verticalScale(10),
    borderRadius: moderateScale(5),
    marginBottom: height * 0.01,
  },
  starRatingSkeleton: {
    width: WH.width(25),
    height: verticalScale(10),
    borderRadius: moderateScale(5),
    marginBottom: height * 0.01,
  },
  reviewText: {
    width: WH.width(60),
    height: verticalScale(10),
    borderRadius: moderateScale(5),
    marginBottom: height * 0.01,
  },
  commentImage: {
    width: WH.width(10),
    height: WH.width(10),
    borderRadius: moderateScale(5),
    marginBottom: height * 0.01,
    marginRight: WH.width(2),
  },
  additionalLine: {
    width: WH.width(60),
    height: verticalScale(10),
    borderRadius: moderateScale(5),
    marginBottom: height * 0.01,
  },
});
