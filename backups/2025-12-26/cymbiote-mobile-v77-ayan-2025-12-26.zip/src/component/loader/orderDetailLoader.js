import {Dimensions, FlatList, StyleSheet, View} from 'react-native';
import React from 'react';
import CustomSkeleton from '@materialComponent/customSkeleton/customSkeleton';
import {moderateScale, verticalScale} from 'react-native-size-matters';
import {globalStyle, margin} from '../../constant/contstant';
import {widthPercentageToDP} from 'react-native-responsive-screen';

const {height} = Dimensions.get('screen');

const OrderDetailLoader = ({loading, removeMargin}) => {
  const renderItem = ({item, index}) => {
    return (
      <View style={styles.container}>
        <View style={[styles.topRow, {borderTopWidth: index == 0}]}>
          <CustomSkeleton loading={loading} style={styles.image} />
          <View style={styles.textContainer}>
            <CustomSkeleton loading={loading} style={styles.text} />
            <View style={styles.descContainer}>
              <CustomSkeleton loading={loading} style={styles.desc} />
            </View>
          </View>
        </View>
      </View>
    );
  };

  return (
    <View>
      <View style={[styles.container, !removeMargin && {marginTop: 0}]}>
        <View style={[styles.topRow, {borderTopWidth: 1}]}>
          <View
            style={{
              height: height * 0.16,
              width: '100%',
              justifyContent: 'flex-end',
            }}>
            <View style={globalStyle.space_between}>
              <CustomSkeleton loading={loading} style={styles.orderTitle} />
              <View style={globalStyle.space_between}>
                <View style={{marginRight: 10}}>
                  <CustomSkeleton
                    loading={loading}
                    style={styles.settingIcon}
                  />
                </View>
                <View style={{marginRight: 0}}>
                  <CustomSkeleton
                    loading={loading}
                    style={styles.settingIcon}
                  />
                </View>
              </View>
            </View>
            <View style={{marginTop: height * 0.01}}>
              <CustomSkeleton loading={loading} style={styles.orderDate} />
            </View>
            <View style={{marginTop: height * 0.01}}>
              <CustomSkeleton loading={loading} style={styles.orderStatus} />
            </View>
            <View style={{marginTop: height * 0.01}}>
              <CustomSkeleton
                loading={loading}
                style={styles.orderStatusTitle}
              />
            </View>
          </View>
        </View>
        <View style={{marginHorizontal: margin.horizontal}}>
          <View style={{marginTop: height * 0.01, width: '100%'}}>
            <View style={globalStyle.space_between}>
              <View style={globalStyle.space_between}>
                <CustomSkeleton loading={loading} style={styles.image} />
                <View style={{marginLeft: 10}}>
                  <CustomSkeleton loading={loading} style={styles.orderTitle} />
                  <View style={{marginTop: height * 0.01}}>
                    <CustomSkeleton
                      loading={loading}
                      style={styles.orderDate}
                    />
                  </View>
                </View>
              </View>
              <CustomSkeleton loading={loading} style={styles.button} />
            </View>
          </View>
        </View>

        <View style={{marginHorizontal: margin.horizontal}}>
          <View
            style={{
              marginTop: height * 0.01,
              width: '100%',
              justifyContent: 'center',
            }}>
            <View
              style={{
                borderBottomWidth: 1,
                paddingBottom: 10,
                borderColor: '#E0E0E0',
              }}>
              <View
                style={[globalStyle.space_between, {alignItems: 'flex-start'}]}>
                <View
                  style={[
                    [globalStyle.space_between, {alignItems: 'flex-start'}],
                  ]}>
                  <View style={{justifyContent: 'center'}}>
                    <CustomSkeleton
                      loading={loading}
                      style={[
                        styles.image,
                        {
                          borderRadius: 5,
                          width: widthPercentageToDP(20),
                          height: widthPercentageToDP(20),
                        },
                      ]}
                    />
                  </View>
                  <View style={{marginLeft: 10, marginTop: 10}}>
                    <CustomSkeleton
                      loading={loading}
                      style={styles.orderTitle}
                    />
                    <View style={{marginTop: height * 0.01}}>
                      <CustomSkeleton
                        loading={loading}
                        style={styles.orderDate}
                      />
                    </View>
                  </View>
                </View>
                <View style={{marginTop: 10}}>
                  <CustomSkeleton
                    loading={loading}
                    style={[styles.button, {height: moderateScale(10)}]}
                  />
                </View>
              </View>
              <View
                style={[
                  globalStyle.space_between,
                  {alignItems: 'flex-start', marginTop: height * 0.01},
                ]}>
                <View
                  style={[
                    [globalStyle.space_between, {alignItems: 'flex-start'}],
                  ]}>
                  <View style={{justifyContent: 'center'}}>
                    <CustomSkeleton
                      loading={loading}
                      style={[
                        styles.image,
                        {
                          borderRadius: 5,
                          width: widthPercentageToDP(20),
                          height: widthPercentageToDP(20),
                        },
                      ]}
                    />
                  </View>
                  <View style={{marginLeft: 10, marginTop: 10}}>
                    <CustomSkeleton
                      loading={loading}
                      style={styles.orderTitle}
                    />
                    <View style={{marginTop: height * 0.01}}>
                      <CustomSkeleton
                        loading={loading}
                        style={styles.orderDate}
                      />
                    </View>
                  </View>
                </View>
                <View style={{marginTop: 10}}>
                  <CustomSkeleton
                    loading={loading}
                    style={[styles.button, {height: moderateScale(10)}]}
                  />
                </View>
              </View>
              <View
                style={[
                  globalStyle.space_between,
                  {alignItems: 'flex-start', marginTop: height * 0.01},
                ]}>
                <View
                  style={[
                    [globalStyle.space_between, {alignItems: 'flex-start'}],
                  ]}>
                  <View style={{justifyContent: 'center'}}>
                    <CustomSkeleton
                      loading={loading}
                      style={[
                        styles.image,
                        {
                          borderRadius: 5,
                          width: widthPercentageToDP(20),
                          height: widthPercentageToDP(20),
                        },
                      ]}
                    />
                  </View>
                  <View style={{marginLeft: 10, marginTop: 10}}>
                    <CustomSkeleton
                      loading={loading}
                      style={styles.orderTitle}
                    />
                    <View style={{marginTop: height * 0.01}}>
                      <CustomSkeleton
                        loading={loading}
                        style={styles.orderDate}
                      />
                    </View>
                  </View>
                </View>
                <View style={{marginTop: 10}}>
                  <CustomSkeleton
                    loading={loading}
                    style={[styles.button, {height: moderateScale(10)}]}
                  />
                </View>
              </View>
            </View>
          </View>
        </View>
        <View style={{marginHorizontal: margin.horizontal}}>
          <View
            style={{
              marginTop: height * 0.01,
              width: '100%',
              justifyContent: 'center',
            }}>
            <View style={{marginTop: height * 0.01}}>
              <CustomSkeleton
                loading={loading}
                style={[styles.orderTitle, {width: widthPercentageToDP(30)}]}
              />
            </View>
            <View style={{marginTop: height * 0.01}}>
              <View style={globalStyle.space_between}>
                <CustomSkeleton loading={loading} style={[styles.orderDate]} />
                <CustomSkeleton loading={loading} style={[styles.orderDate]} />
              </View>
            </View>
            <View style={{marginTop: height * 0.008}}>
              <View style={globalStyle.space_between}>
                <CustomSkeleton loading={loading} style={[styles.orderDate]} />
                <CustomSkeleton loading={loading} style={[styles.orderDate]} />
              </View>
            </View>
            <View style={{marginTop: height * 0.008}}>
              <View style={globalStyle.space_between}>
                <CustomSkeleton loading={loading} style={[styles.orderDate]} />
                <CustomSkeleton loading={loading} style={[styles.orderDate]} />
              </View>
            </View>
          </View>
        </View>
      </View>
    </View>
  );
};

export default OrderDetailLoader;

const styles = StyleSheet.create({
  container: {
    // marginBottom: verticalScale(10), // Space between each skeleton loader
    backgroundColor:"white",
    height : height * 1
  },
  topRow: {
    flexDirection: 'row',
    alignItems: 'center',
    // backgroundColor: 'red', // Remove or replace with actual color
    paddingVertical: verticalScale(10),
    paddingHorizontal: margin.horizontal,
    borderBottomWidth: 1, // border is consistent now
    borderColor: '#E0E0E0', // specify a consistent color for the bottom border
  },
  orderTitle: {
    height: moderateScale(10),
    width: moderateScale(50),
    borderRadius: 180,
  },
  orderDate: {
    height: moderateScale(7),
    width: moderateScale(100),
    borderRadius: 180,
  },
  orderStatus: {
    height: moderateScale(10),
    width: moderateScale(50),
    borderRadius: 180,
  },
  orderStatusTitle: {
    height: moderateScale(10),
    width: widthPercentageToDP(50),
    borderRadius: 180,
  },
  settingIcon: {
    // height: moderateScale(30),
    width: moderateScale(25),
    aspectRatio: 1,
    borderRadius: 180,
  },
  image: {
    height: moderateScale(50),
    width: moderateScale(50),
    borderRadius: 180,
  },
  button: {
    height: moderateScale(20),
    width: moderateScale(60),
    borderRadius: 5,
  },
});
