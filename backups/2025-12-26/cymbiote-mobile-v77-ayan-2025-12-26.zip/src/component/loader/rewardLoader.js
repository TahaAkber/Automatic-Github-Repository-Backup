import { Dimensions, Image, StyleSheet, Text, View } from 'react-native'
import React from 'react'
import { colors, globalStyle, WH } from '@constant/contstant';
import Container from '@materialComponent/container/container';
import CustomSkeleton from '@materialComponent/customSkeleton/customSkeleton';
import CartBackgroundSvg from '../../assets/images/cart_background';

const { height, width, fontScale } = Dimensions.get("screen")

const RewardLoader = () => {
    return (
        <Container barColor={colors.light_theme.themeBackgroundColor}>
            <CustomSkeleton
                highlightColor={"#F9F9F9"}
                style={styles.address}
            />
            <View style={{ marginTop: height * 0.02, }}>
                <View style={{ zIndex: 1 }}>
                    <CustomSkeleton
                        highlightColor={"#F9F9F9"}
                        style={styles.cart}
                    />
                </View>
            </View>
            <View style={{ marginTop: height * 0.02, width: "45%" }}>
                <CustomSkeleton
                    highlightColor={"#F9F9F9"}
                    style={styles.heading}
                />
            </View>
            <View style={{ marginTop: height * 0.02, }}>
                <CustomSkeleton
                    highlightColor={"#F9F9F9"}
                    style={styles.voucher}
                />
            </View>
            <View style={{ marginTop: height * 0.02, }}>
                <CustomSkeleton
                    highlightColor={"#F9F9F9"}
                    style={styles.voucher}
                />
            </View>
            <View style={{ marginTop: height * 0.02, }}>
                <CustomSkeleton
                    highlightColor={"#F9F9F9"}
                    style={styles.voucher}
                />
            </View>
        </Container >
    )
}

export default RewardLoader

const styles = StyleSheet.create({
    address: {
        width: "100%",
        height: height * 0.25,
        borderRadius: 10,
    },
    cart: {
        width: "100%",
        height: height * 0.03,
        borderRadius: 10,
    },
    heading: {
        height: height * 0.03,
        borderRadius: 10,
    },
    voucher: {
        width: "100%",
        height: height * 0.15,
        borderRadius: 10,
    },
})