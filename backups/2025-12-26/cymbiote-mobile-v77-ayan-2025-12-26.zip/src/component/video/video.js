import React, { useEffect, useMemo, useState } from 'react';
import {
  ActivityIndicator,
  Platform,
  StyleSheet,
  View,
} from 'react-native';
import Video from 'react-native-video';
import * as RNFS from 'react-native-fs';
import NetInfo from '@react-native-community/netinfo';
// Optional: show latency or a message
import CustomText from '../../materialComponent/customText/customText';

const getExtFromUrl = (url) => {
  try {
    const clean = (url || '').split('?')[0].split('#')[0];
    const last = clean.split('/').pop() || '';
    const dot = last.lastIndexOf('.');
    if (dot !== -1) {
      const ext = last.slice(dot + 1).toLowerCase();
      if (['mp4', 'mov', 'm4v'].includes(ext)) return ext;
      if (ext === 'm3u8') return 'm3u8';
    }
  } catch {}
  return 'mp4';
};

const getSafeBasename = (url) =>
  (url || '').replace(/^https?:\/\//, '').replace(/[\/:.?&#=%+]/g, '_');

const CustomVideo = ({ item, paused }) => {
  const [cachedUri, setCachedUri] = useState(null);
  const [loading, setLoading] = useState(true);
  const [latency, setLatency] = useState(null);
  const [isOnline, setIsOnline] = useState(true);
  const [offlineMiss, setOfflineMiss] = useState(false); // offline & no cache

  const videoUrl = item?.shop_banner_url;

  useEffect(() => {
    const sub = NetInfo.addEventListener((state) => {
      setIsOnline(Boolean(state.isConnected && state.isInternetReachable));
    });
    return () => sub && sub();
  }, []);

  // Guard: no URL
  if (!videoUrl) return null;

  const ext = useMemo(() => getExtFromUrl(videoUrl), [videoUrl]);
  const isHLS = ext === 'm3u8';

  // Use persistent, stable cache folder
  const baseDir = Platform.select({
    ios: RNFS.LibraryDirectoryPath,           // persistent, not temp
    android: RNFS.CachesDirectoryPath,
  });
  const cacheDir = `${baseDir}/VideoCache`;

  const uniqueBase = useMemo(() => getSafeBasename(videoUrl), [videoUrl]);
  const cachedVideoPath = `${cacheDir}/${uniqueBase}.${ext}`;

  useEffect(() => {
    let isMounted = true;
    const startTime = Date.now();

    const run = async () => {
      try {
        // Ensure cache dir exists
        await RNFS.mkdir(cacheDir);

        // HLS: don't cache (works online; offline will show placeholder)
        if (isHLS) {
          if (!isMounted) return;
          if (isOnline) {
            setCachedUri(null); // stream remote
            setOfflineMiss(false);
          } else {
            // offline + HLS cannot play
            setCachedUri(null);
            setOfflineMiss(true);
          }
          setLatency(Date.now() - startTime);
          return;
        }

        const exists = await RNFS.exists(cachedVideoPath);
        if (exists) {
          const localPath = `file://${cachedVideoPath}`;
          if (!isMounted) return;
          setCachedUri(localPath);
          setOfflineMiss(false);
          setLatency(Date.now() - startTime);
        } else {
          // File not in cache
          if (!isOnline) {
            // OFFLINE: do NOT fallback to remote — show placeholder
            if (!isMounted) return;
            setCachedUri(null);
            setOfflineMiss(true);
            setLatency(Date.now() - startTime);
          } else {
            // ONLINE: download and cache
            await RNFS.downloadFile({
              fromUrl: encodeURI(videoUrl),
              toFile: cachedVideoPath,
              background: true,
              discretionary: true,
            }).promise;

            const stat = await RNFS.stat(cachedVideoPath);
            if (!stat.isFile()) throw new Error('Downloaded path is not a file');

            if (!isMounted) return;
            setCachedUri(`file://${cachedVideoPath}`);
            setOfflineMiss(false);
            setLatency(Date.now() - startTime);
          }
        }
      } catch (e) {
        // Fallbacks
        if (!isMounted) return;
        if (isOnline && !isHLS) {
          // Try to stream remote as a last resort
          setCachedUri(null);
          setOfflineMiss(false);
        } else {
          // Offline or HLS + error
          setCachedUri(null);
          setOfflineMiss(true);
        }
      } finally {
        if (isMounted) setLoading(false);
      }
    };

    run();
    return () => {
      isMounted = false;
    };
  }, [videoUrl, cachedVideoPath, cacheDir, isHLS, isOnline]);

  // Loading state
  if (loading) {
    return (
      <View style={styles.loading}>
        <ActivityIndicator size="large" color="white" />
      </View>
    );
  }

  // Offline with no cache available → show a clean placeholder instead of black
  if (offlineMiss) {
    return (
      <View style={styles.offlineContainer}>
        <CustomText
          text="Video unavailable offline"
          fontSize={14}
          color="white"
          style={{ opacity: 0.8 }}
        />
      </View>
    );
  }

  // Choose source: prefer cached if present, else remote (online only)
  const source = cachedUri ? { uri: cachedUri } : { uri: videoUrl };

  return (
    <Video
      source={source}
      style={styles.video}
      resizeMode="cover"
      paused={paused}
      repeat
      muted
      ignoreSilentSwitch="ignore"
      allowsExternalPlayback={false}
      preventsDisplaySleepDuringVideoPlayback
      useTextureView={Platform.OS === 'android'}
      renderToHardwareTextureAndroid
      onError={(e) => {
        console.log('Video error:', e?.error || e);
      }}
      // Helpful on low bandwidth
      // bufferConfig={{
      //   minBufferMs: 15000,
      //   maxBufferMs: 50000,
      //   bufferForPlaybackMs: 2500,
      //   bufferForPlaybackAfterRebufferMs: 5000,
      // }}
    />
  );
};

export default CustomVideo;

const styles = StyleSheet.create({
  video: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'black',
  },
  loading: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'black',
    justifyContent: 'center',
    alignItems: 'center',
  },
  offlineContainer: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'black',
    justifyContent: 'center',
    alignItems: 'center',
  },
});
