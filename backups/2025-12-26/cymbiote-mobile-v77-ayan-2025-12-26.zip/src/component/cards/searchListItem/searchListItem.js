import React from 'react';
import {Dimensions, StyleSheet, TouchableOpacity, View} from 'react-native';
import Icon from '@materialComponent/icon/icon';
import {font, globalStyle} from '@constant/contstant';
import {moderateScale} from 'react-native-size-matters';
import CustomText from '@materialComponent/customText/customText';
import CustomImage from '@materialComponent/image/image';
import {navigate} from '../../../utils/navigationRef/navigationRef';
import {defaultShopImages} from '../../../utils/helper/helper';
import {useNavigation} from '@react-navigation/native';
import BrandTab from '../../brandTab/brandTab';
import useImageHeight from '../../../utils/hooks/useImageHeight';
import {logSearchItemClickEvent} from '@helper/eventTriggers/useEventTriggers';

const {fontScale} = Dimensions.get('screen');

const SearchListItem = ({
  marginTop,
  image,
  text,
  rating,
  onPress,
  item,
  searchQuery = '',
  position = 0,
  onItemClick,
}) => {
  const {height} = useImageHeight(defaultShopImages(item)?.[0]);

  const navigation = useNavigation();

  const _handleNavigation = async () => {
    const isShop = item?.type === 'shop';
    const resultType = isShop ? 'shop' : 'product';

    // Log the click event
    if (searchQuery) {
      await logSearchItemClickEvent(item, searchQuery, position, resultType);
    }

    // Call the parent's click handler
    if (onItemClick) {
      onItemClick();
    }

    // Navigate with isFromSearch flag
    if (isShop) {
      navigate('Brand', {
        shop_id: item.shop_id,
        shop: item,
        isFromSearch: !!searchQuery,
        searchQuery: searchQuery,
      });
    } else {
      navigation.push('ProductDetail', {
        product_id: item.product_id,
        shop_id: item.product_shop_id,
        default_images: defaultShopImages(item),
        height,
        isFromSearch: !!searchQuery,
        searchQuery: searchQuery,
      });
    }
  };

  const isShop = item?.type == 'shop';

  return (
    <View style={{marginTop}}>
      {isShop ? (
        <BrandTab
          headingStyle={styles.heading}
          mainViewStyle={styles.container}
          item={item}
          imageStyle={styles.image}
          removeFollowText={true}
          shopNameFontSize={fontScale * 12}
        />
      ) : (
        <TouchableOpacity onPress={_handleNavigation} style={[styles.row]}>
          <View style={styles.image}>
            <CustomImage
              size={moderateScale(5)}
              source={{
                uri: isShop ? item?.shop_logo_url : item.product_image_url,
              }}
              style={{width: '100%', height: '100%'}}
            />
          </View>
          <View style={styles.textContainer}>
            <CustomText
              text={isShop ? item?.shop_name : item.product_name}
              fontFamily={font.medium}
              fontSize={moderateScale(12)}
              numberOfLines={1}
              style={styles.heading}
            />
          </View>
        </TouchableOpacity>
      )}
    </View>
  );
};

export default SearchListItem;

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: 0,
    paddingVertical: 0,
    marginTop: 0,
    marginBottom: 0,
  },
  heading: {
    fontSize: fontScale * 50,
  },
  row: {
    ...globalStyle.row,
  },
  image: {
    width: moderateScale(40),
    height: moderateScale(40),
    borderRadius: 180,
    borderWidth: 1,
    overflow: 'hidden',
    borderColor: '#f7f7f7',
  },
  textContainer: {
    width: '85%',
    marginLeft: '3%',
  },
  ratingContainer: {
    ...globalStyle.row,
    marginTop: moderateScale(5),
  },
  ratingText: {
    marginLeft: moderateScale(5),
    color: 'gray',
  },
});

// <TouchableOpacity onPress={_handleNavigation} style={[styles.row, { borderBottomWidth: 1, paddingVertical: marginTop, borderBottomColor: "#f7f7f7" }]}>
//     <View style={styles.image}>
//         <CustomImage
//             source={{ uri: isShop ? item?.shop_logo_url : item.product_image_url }}
//             style={{ width: "100%", height: "100%" }}
//         />
//     </View>
//     <View style={styles.textContainer}>
//         <CustomText
//             text={isShop ? item?.shop_name : item.product_name}
//             fontFamily={font.medium}
//             fontSize={moderateScale(12)}
//             numberOfLines={1}
//             color={"gray"}
//         />
//         <View style={styles.ratingContainer}>
//             <Icon
//                 icon_type={"Entypo"}
//                 name={rating ? "star" : "star-outlined"}
//                 size={moderateScale(12)}
//                 color={"#E4A70A"}
//             />
//             <CustomText
//                 text={`${(isShop ? item?.shop_rating : item.product_rating) || 0}`}
//                 fontFamily={font.bold}
//                 fontSize={moderateScale(10)}
//                 style={styles.ratingText}
//             />
//         </View>
//     </View>
// </TouchableOpacity>
