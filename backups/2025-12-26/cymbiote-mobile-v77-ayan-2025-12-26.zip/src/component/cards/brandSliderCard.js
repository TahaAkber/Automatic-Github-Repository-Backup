import CustomImage from '@materialComponent/image/image';
import { moderateScale } from 'react-native-size-matters';
import { StyleSheet, View } from 'react-native';
import { shadow } from '@constant/contstant';
import images from '@assets/images/images';
import React from 'react';

const BrandSliderCard = () => {
  return (
    <View style={styles.brand_slider}>
      <CustomImage
        style={styles.brand_slider_image}
        source={images.nike}
        resizeMode="contain"
        size={'small'}
      />
    </View>
  );
};

export default BrandSliderCard;

const styles = StyleSheet.create({
  brand_slider: {
    borderRadius: moderateScale(180),
    marginRight: moderateScale(20),
    height: moderateScale(70),
    backgroundColor: 'white',
    ...shadow,
  },
  brand_slider_image: {
    height: moderateScale(70),
    width: moderateScale(70),
  },
});
