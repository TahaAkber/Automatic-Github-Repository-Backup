import {
    Dimensions,
    StatusBar,
    StyleSheet,
    Text,
    View,
} from 'react-native';
import React from 'react';
import { globalStyle, margin, font } from '@constant/contstant';
import PointSvg from "@assets/images/point.svg"
import CustomText from '@materialComponent/customText/customText';
import CustomImage from '@materialComponent/image/image';
import CustomButton from '@materialComponent/customButton/customButton';
import BadgeSvg from "@assets/images/badge.svg"
import { colors } from '@constant/contstant';
import { toFixedMethod } from '@utils/helper/helper';

const { width, height, fontScale } = Dimensions.get("screen")

const PointCard = ({ style, milestone, marginTop, heading,
    date,
    point,
    reward,
    image,
    backgroundColor,
    item,
    pointColor
}) => {
    return (
        <React.Fragment>
            <View style={{ overflow: "hidden", marginTop: marginTop || height * 0.02 }}>
                <View style={[styles.voucher, style, { backgroundColor: backgroundColor || "#F6F7FA" }]}>
                    <View style={[styles.imageContainer]}>
                        {reward ?
                            <View style={[styles.image, { backgroundColor: "#ececec", justifyContent: "center", alignItems: "center" }]}>
                                <BadgeSvg width={width * 0.12} height={width * 0.12} />
                            </View> :
                            <CustomImage
                                source={{ uri: image }}
                                style={styles.image}
                            />
                        }
                        {/* {item?.points_log_criteria_id  ?
                            <View style={[styles.image, { backgroundColor: "#ececec", justifyContent: "center", alignItems: "center" }]}>
                                <BadgeSvg width={width * 0.12} height={width * 0.12} />
                            </View> :
                            <CustomImage
                                source={{ uri: image }}
                                style={styles.image}
                            />
                        } */}
                    </View>
                    <View style={styles.content}>
                        <CustomText fontFamily={font.bold} fontSize={fontScale * 10} text={heading || "You’ve collected your milestone points"} />
                        <View style={{ padding: 2, borderRadius: 180, backgroundColor: "#e6e6e6", alignSelf: "flex-start", marginTop: height * 0.005, paddingHorizontal: 10, borderWidth: 1, borderColor: "#ababab" }}>
                            <CustomText fontFamily={font.bold} color={"#242B4266"} fontSize={fontScale * 8} text={date || "Date: 01-01-2025"} />
                        </View>
                    </View>
                    <View style={styles.point}>
                        <PointSvg width={width * 0.035} height={width * 0.035} />
                        <CustomText style={{ marginLeft: "10%" }} text={point ? toFixedMethod(point) : "200"} color={pointColor} fontSize={fontScale * 12} fontFamily={font.bold} />
                    </View>
                </View>
            </View>
        </React.Fragment>
    );
};

export default PointCard;

const styles = StyleSheet.create({
    voucher: {
        // borderWidth: 2,
        flexDirection: "row",
        alignItems: "center",
        borderRadius: 10,
        borderColor: "#E6E9ED",
        marginHorizontal: margin.horizontal,
        backgroundColor: "#F6F7FA"
        // paddingVertical: height * 0.005,
    },
    imageContainer: {
        width: "20%",
        aspectRatio: 1,
        // backgroundColor: "red",
        justifyContent: "center",
        alignItems: "center",
        borderColor: "#E6E9ED"
    },

    image: {
        width: "70%",
        aspectRatio: 1,
        borderRadius: 10
    },
    content: {
        // backgroundColor: "red",
        width: "55%"
    },
    point: {
        width: "20%",
        ...globalStyle.row,
        justifyContent: "flex-end",
        // backgroundColor: "green"
    },
});