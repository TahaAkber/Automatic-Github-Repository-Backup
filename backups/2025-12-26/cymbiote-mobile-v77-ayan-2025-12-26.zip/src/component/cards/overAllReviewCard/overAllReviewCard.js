import {
  Animated,
  Dimensions,
  StyleSheet,
  TouchableOpacity,
  View,
} from 'react-native';
import React from 'react';
import CustomText from '@materialComponent/customText/customText';
import { font, globalStyle, margin } from '@constant/contstant';
import Icon from '@materialComponent/icon/icon';
import CustomImage from '@materialComponent/image/image';
import BorderLine from '@component/borderLine/borderLine';
import useOverAllReviewCard from './useOverAllReviewCard';
import { colors } from '@constant/contstant';
import ImageSlider from '@component/imageCarousel/imageCarousel';
import { timeAgo } from '../../../utils/helper/helper';
import { StarRatingDisplay } from 'react-native-star-rating-widget';
import ProfileIcon from '@assets/images/profile.svg';
import { shadow } from 'react-native-paper';

const { width, height, fontScale } = Dimensions.get('screen');

const renderStars = rating => {
  return (
    <View
      style={{
        flexDirection: 'row',
        justifyContent: 'flex-start',
        alignItems: 'center',
        margin: 0,
        padding: 0,
      }}>
      <StarRatingDisplay
        rating={rating}
        starSize={fontScale * 15}
        maxStars={5}
        starStyle={{ marginRight: 0, marginLeft: 0 }}
        color="#E4A70A"
      />
    </View>
  );
};

const OverAllReviewCard = ({
  likeSectionRemove,
  marginTop,
  slider,
  onPress,
  showComment,
  item,
  own,
  review_detail,
  total_comment,
  padding = width * 0.03,
  margin = width * 0.03,
  elevation = 4,
}) => {
  const {
    handleLike,
    like,
    likeIconStyle,
    images,
    fetch_user_detail,
    likeCount,
  } = useOverAllReviewCard({ review_detail, item });
  const IsTouchableOpacity = onPress ? TouchableOpacity : View;

  return (
    <IsTouchableOpacity
      activeOpacity={1}
      onPress={onPress}
      style={[
        {
          padding,
          margin,
          borderRadius: 5,
          borderColor: '#cdcbcd',
          elevation,
          backgroundColor: 'white',
          ...shadow(1),
        },
        marginTop && { marginTop },
      ]}>
      <View style={styles.headerContainer}>
        <View style={styles.imageWrapper}>
          {own ? (
            fetch_user_detail?.profile ? (
              <CustomImage
                style={styles.image}
                source={{ uri: fetch_user_detail.profile }}
              />
            ) : (
              <CustomImage
                source={{
                  uri: 'https://img.freepik.com/premium-vector/default-ava…le-silhouette-vector-illustration_561158-3383.jpg',
                }}
                style={styles.image}
              />
            )
          ) : review_detail?.user_detail?.user_image_url ||
            item?.user?.avatar ? (
            <CustomImage
              style={styles.image}
              source={{
                uri:
                  review_detail?.user_detail?.user_image_url ||
                  item?.user?.avatar,
              }}
            />
          ) : (
            <CustomImage
              source={{
                uri: 'https://img.freepik.com/premium-vector/default-ava…le-silhouette-vector-illustration_561158-3383.jpg',
              }}
              style={styles.image}
            />
          )}{' '}
        </View>
        <View style={styles.detailsWrapper}>
          <CustomText
            fontFamily={font.bold}
            text={
              own
                ? `${fetch_user_detail?.firstname} ${fetch_user_detail?.lastname}`
                : review_detail
                  ? `${review_detail?.user_detail?.user_first_name} ${review_detail?.user_detail?.user_last_name}`
                  : item?.user?.name
            }
          />
          <View style={[globalStyle.row, styles.starRatingContainer]}>
            {/* {[...Array(5)].map((_, i) => (
                            <Icon key={i} icon_type="Entypo" name="star" color={i === 4 ? "#C9C9C9" : "#E4A70A"} size={fontScale * 15} />
                        ))} */}
            {renderStars(
              review_detail?.review_detail?.order_item_review_rating ||
              item?.review_item?.order_item_review_rating ||
              item?.order_item_review_rating ||
              0,
            )}
            <CustomText
              style={styles.timeText}
              text={
                item?.review_item?.created_at ||
                  review_detail?.review_detail ||
                  item?.created_at
                  ? timeAgo(
                    review_detail?.review_detail?.created_at ||
                    item?.review_item?.created_at ||
                    item?.created_at,
                  )
                  : '2 mins ago'
              }
            />
          </View>
        </View>
        {/* <View style={styles.dotsIconWrapper}>
                    <Icon icon_type="Entypo" name="dots-three-vertical" color={"black"} size={fontScale * 15} />
                </View> */}
      </View>

      <CustomText
        fontSize={fontScale * 14}
        marginTop={height * 0.015}
        text={
          item?.review_item?.order_item_review_comment ||
          item?.order_item_review_comment ||
          review_detail?.review_detail?.order_item_review_comment ||
          ''
        }
      />

      {slider ? (
        images.length ? (
          <ImageSlider
            customWidth={width * 0.9}
            brand={false}
            images={images || []}
            removeSpace={true}
          />
        ) : (
          <></>
        )
      ) : (
        <View style={styles.imagesContainer}>
          {(item?.review_item?.images || item?.images || []).length ? (
            (item?.review_item?.images || item?.images)?.map((item, index) => {
              return (
                <CustomImage
                  style={styles.thumbnailImage}
                  source={{ uri: item }}
                />
              );
            })
          ) : (
            <></>
          )}
        </View>
      )}
      {slider ? (
        <></>
      ) : (
        <BorderLine marginTop={height * 0.01} style={styles.borderLine} />
      )}
      {likeSectionRemove ? (
        <></>
      ) : (
        <View style={styles.reactionContainer}>
          <TouchableOpacity
            onPress={handleLike}
            activeOpacity={1}
            style={styles.reactionItem}>
            <Animated.View style={likeIconStyle}>
              <Icon
                icon_type="AntDesign"
                name={like ? 'like1' : 'like2'}
                color={like ? colors.light_theme.theme : 'black'}
                size={fontScale * 15}
              />
            </Animated.View>
            {/* <CustomText style={styles.reactionText} text={`${like ? 1 : 0} Likes`} /> */}
            <CustomText
              style={styles.reactionText}
              text={`${(item?.likeCount || item?.review_item?.total_reaction || 0) +
                likeCount
                } Likes`}
            />
          </TouchableOpacity>
          <TouchableOpacity activeOpacity={1} style={styles.reactionItem}>
            <Icon
              icon_type="Fontisto"
              name="comment"
              color={'black'}
              size={fontScale * 13}
            />
            <CustomText
              style={styles.reactionText}
              text={`${total_comment} Comments`}
            />
          </TouchableOpacity>
        </View>
      )}

      {showComment ? (
        <View>
          <View
            style={[
              styles.headerContainer,
              { marginTop: !images?.length && height * 0.02 },
            ]}>
            <View style={styles.imageWrapper}>
              <CustomImage
                style={styles.image}
                source={{
                  uri: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQJu9wA0TUpLapX6ryDlIVvT3snPmY2Q3UzAA&s',
                }}
              />
            </View>
            <View style={[styles.detailsWrapper, { width: '76%' }]}>
              <CustomText fontFamily={font.bold} text={'Nike'} />
              <View style={[globalStyle.row, styles.starRatingContainer]}>
                <CustomText
                  fontSize={fontScale * 13}
                  text={'Consequat velit qui adipisicing sunt do '}
                />
              </View>
              <View style={[globalStyle.row, styles.starRatingContainer]}>
                <CustomText fontSize={fontScale * 10} text={'1 Jan 2025'} />
              </View>
            </View>
            <TouchableOpacity
              onPress={handleLike}
              activeOpacity={1}
              style={styles.reactionItem}>
              <Animated.View style={likeIconStyle}>
                <Icon
                  icon_type="AntDesign"
                  name={like ? 'like1' : 'like2'}
                  color={like ? colors.light_theme.theme : 'black'}
                  size={fontScale * 20}
                />
              </Animated.View>
            </TouchableOpacity>
          </View>
        </View>
      ) : (
        <></>
      )}
    </IsTouchableOpacity>
  );
};

export default OverAllReviewCard;

const styles = StyleSheet.create({
  headerContainer: {
    flexDirection: 'row',
    // alignItems: "center",
  },
  imageWrapper: {
    width: '15%',
  },
  image: {
    width: '85%',
    aspectRatio: 1,
    borderRadius: 180,
  },
  detailsWrapper: {
    width: '70%',
  },
  starRatingContainer: {
    marginTop: height * 0.005,
  },
  timeText: {
    fontSize: fontScale * 13,
    marginLeft: '3%',
    color: '#333333',
  },
  dotsIconWrapper: {
    width: '15%',
    justifyContent: 'center',
    alignItems: 'center',
  },
  imagesContainer: {
    flexDirection: 'row',
    marginTop: height * 0.01,
  },
  thumbnailImage: {
    width: '15%',
    aspectRatio: 1,
    borderRadius: 5,
    marginRight: width * 0.02,
    borderWidth: 0.1,
    borderColor: colors.light_theme.gray,
  },
  borderLine: {
    marginLeft: 0,
    width: '95%',
    backgroundColor: '#00000033',
    height: height * 0.003,
    alignSelf: 'center',
    opacity: 0.3,
  },
  reactionContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: height * 0.01,
  },
  reactionItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: width * 0.06,
    zIndex: 1,
  },
  reactionText: {
    marginLeft: width * 0.02,
    fontSize: fontScale * 13,
  },
  commentBox: {
    flexDirection: 'row',
    width: '100%',
  },
});
