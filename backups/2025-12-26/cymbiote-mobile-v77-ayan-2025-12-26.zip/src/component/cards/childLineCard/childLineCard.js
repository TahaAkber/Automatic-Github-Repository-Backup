import {
    Dimensions,
    StyleSheet,
    Text,
    TouchableOpacity,
    View,
} from 'react-native';
import React from 'react';
import { colors, margin, font } from '@constant/contstant';
import RewardSvg from "@assets/images/reward.svg"
// import Voucher from '@assets/images/voucher';
import CustomText from '@materialComponent/customText/customText';

const { width, height, fontScale } = Dimensions.get("screen")

const ChildLineCard = ({ heading,activeOpacity=1,isTouchable=false ,firstLineCode, secondineCode, reward, marginTop, firstIcon: FirstIcon, style, headingFontSize, fontSize, onPress }) => {
    return (
        <View style={[styles.content, { marginTop }]}>
            <TouchableOpacity activeOpacity={isTouchable ? 0.2 : activeOpacity} 
                onPress={isTouchable ? onPress : undefined} > 
            
            <View style={[styles.redeem, reward && { alignItems: "centers" }, style]}>
                {FirstIcon ?
                    <FirstIcon width={width * 0.06} height={width * 0.06} /> : <></>
                }
                <View style={[styles.redeemContent, FirstIcon && { marginLeft: "5%" }]}>
                    <CustomText style={[reward && { marginBottom: height * 0.005 }]} fontFamily={font.bold} fontSize={headingFontSize || fontScale * 14} text={heading} />
                    <Text style={[styles.redeemText, fontSize && { fontSize }]}>
                        {firstLineCode + " "} {secondineCode ?
                            <TouchableOpacity onPress={onPress}>
                                <Text style={[styles.redeemText, { textDecorationLine: "underline", fontFamily: font.bold, color: colors.light_theme.theme }]}>Tap here for redeem</Text>
                            </TouchableOpacity> : <></>
                        }
                    </Text>
                </View>
                {reward ?
                    <RewardSvg width={width * 0.15} height={width * 0.15} />
                    : <></>
                }
            </View>
            </TouchableOpacity>
        </View>
    );
};

export default ChildLineCard;

const styles = StyleSheet.create({
    redeem: {
        borderWidth: 1,
        borderColor: "#e6e9ef",
        padding: width * 0.04,
        borderRadius: 5,
        flexDirection: "row",
    },
    redeemContent: {
        width: "85%",
    },
    redeemText: {
        fontFamily: font.light,
        color: "black",
        fontSize: fontScale * 10
    },
});