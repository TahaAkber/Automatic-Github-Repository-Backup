import React, { useRef, useState } from 'react';
import {
  View,
  StyleSheet,
  Dimensions,
  Animated,
  TouchableOpacity,
} from 'react-native';
import CustomImage from '@materialComponent/image/image';
import CustomText from '@materialComponent/customText/customText';
import CartButton from '@materialComponent/customButton/cartButton';
import { font, shadow, colors } from '@constant/contstant';
import { _addToCart, _removeCartProduct } from '../../../redux/actions/cart/cart';
import useReduxStore from '../../../utils/hooks/useReduxStore';
import { navigate } from '../../../utils/navigationRef/navigationRef';
import { defaultShopImages } from '../../../utils/helper/helper';
import useImageHeight from '../../../utils/hooks/useImageHeight';

const { width, height, fontScale } = Dimensions.get('window');

const SingleCard = ({
  style,
  image,
  product_name,
  product_description,
  imageStyle,
  headingFontSize,
  descFontSize,
  textContainerStyle,
  variant_id,
  shop_id,
  current_variant,
  product,
}) => {
  const { dispatch, getState } = useReduxStore();
  const { cart } = getState('cart');

  const { height } = useImageHeight(defaultShopImages(product)?.[0])

  // const cartVariant = cartShop.product_variant.find((variant) => variant.variant_id === variantId);
  const variant =
    cart
      .find(shop => shop.shop_id === shop_id)
      ?.product_variant.find(variant => variant.variant_id === variant_id) ||
    null;

  // deleteIcon,
  // deletePress

  return (
    <Animated.View style={[styles.cardWrapper, style]}>
      <TouchableOpacity
        activeOpacity={1}
        onPress={() =>
          navigate('ProductDetail', {
            product_id: product.product_id,
            shop_id: product?.product_shop_id,
            default_images: defaultShopImages(product),
            height
          })
        }>
        {variant ? (
          <View
            style={{
              position: 'absolute',
              top: 10,
              right: 10,
              zIndex: 3,
              backgroundColor: 'black',
              padding: width * 0.01,
              borderRadius: 3,
            }}>
            <CustomText
              text={`${variant?.qty} QTY`}
              fontSize={fontScale * 10}
              color={'white'}
              fontFamily={font.bold}
            />
          </View>
        ) : (
          <></>
        )}

        <CustomImage style={[styles.image, imageStyle]} source={{ uri: image }} />
        <View style={[styles.textContainer, textContainerStyle]}>
          <CustomText
            fontSize={headingFontSize || fontScale * 10}
            marginTop={height * 0.01}
            text={product_name}
            fontFamily={font.bold}
            color={'black'}
            numberOfLines={1}
            center
          />
          {product_description ? (
            <CustomText
              color={'#8B8B8B'}
              fontFamily={font.light}
              marginTop={height * 0.005}
              center
              fontSize={descFontSize || fontScale * 10}
              text={product_description}
              numberOfLines={1}
            />
          ) : null}
          <CartButton
            deletePress={() =>
              dispatch(_removeCartProduct(shop_id, variant_id))
            }
            deleteIcon={variant ? true : false}
            price={current_variant?.variant_price}
            backgroundColor={'black'}
            width={'100%'}
            marginTop={height * 0.01}
            fontSize={fontScale * 8}
            height={height * 0.05}
            text={variant ? 'Add More' : 'Add to Cart'}
            onPress={() => dispatch(_addToCart(shop_id, variant_id, 1))}
          />
        </View>
      </TouchableOpacity>
    </Animated.View>
  );
};

export default SingleCard;

const styles = StyleSheet.create({
  cardWrapper: {
    width: width * 0.45,
    alignItems: 'center',
    paddingVertical: height * 0.01,
    borderRadius: 20,
    marginRight: 15,
    ...shadow,
    backgroundColor: 'white',
    borderWidth: 1,
    borderColor: colors.light_theme.borderColor,
  },
  image: {
    width: width * 0.4,
    aspectRatio: 1,
    backgroundColor: '#e7ecf2',
    borderRadius: 18,
  },
  textContainer: {
    width: width * 0.4,
    alignItems: 'center',
  },
});
