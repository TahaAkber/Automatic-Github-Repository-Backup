import {moderateScale, scale, verticalScale} from 'react-native-size-matters';
import BottomSheetReUsable from '@materialComponent/bottomSheet/bottomSheet';
import CustomText from '@materialComponent/customText/customText';
import {colors, font, shadow} from '@constant/contstant';
import {_logout} from '@redux/actions/common/common';
import useReduxStore from '@utils/hooks/useReduxStore';
import {globalStyle, WH} from '@constant/contstant';
import Icon from '@materialComponent/icon/icon';
import React, {useRef} from 'react';
import {TouchableOpacity, StyleSheet, View, Dimensions} from 'react-native';
import {navigate} from '@utils/navigationRef/navigationRef';
import BorderLine from '../../borderLine/borderLine';
import {margin} from '../../../constant/contstant';
import {goBack} from '../../../utils/navigationRef/navigationRef';

const {fontScale, height, width} = Dimensions.get('screen');

const ProfileItem = ({item, index, data, marginTop, fontSize}) => {
  const {dispatch, getState} = useReduxStore();
  const {token} = getState('auth');

  const refRBSheet = useRef();

  const _handleSubmit = () => {
    if (item.option_name === 'Sign out') {
      refRBSheet?.current?.open();
    } else if (item.screen) {
      navigate(item?.screen, item.params || {setting: true});
    }
  };

  const _handleLogout = () => {
    dispatch(_logout());
    goBack();
  };

  const options = [
    {
      onPress: () => _handleLogout(),
      iconType: 'AntDesign',
      iconName: 'logout',
      value: 'Logout',
      color: 'red',
      id: 1,
      // size: moderateScale(15)
    },
    {
      onPress: () => refRBSheet?.current?.close(),
      iconName: 'closecircle',
      iconType: 'AntDesign',
      value: 'Cancel',
      id: 1,
      // size: moderateScale(18)
    },
  ];

  // const showLogout = data.length - 1 == index && !token ? true : false
  if (item.option_name === 'Sign out' && !token) {
    return null;
  }

  return (
    <>
      {/* <TouchableOpacity onPress={_handleSubmit} style={styles.flatlistView}>
                <View style={[styles.imageView,]}>
                    <View style={{ width: WH.width(5), justifyContent: "center", alignItems: "center" }}>
                        <Icon icon_type={item.icon_type} name={item.name} size={item.size || moderateScale(17)} color={item.color || "black"} />
                    </View>
                    <CustomText style={{ marginLeft: moderateScale(15) }} color={item.color || "black"} fontSize={moderateScale(12)} text={item.title} />
                </View>
                {item.color == "red" ? <></> :
                    <View style={styles.textView}>
                        <Icon icon_type={"MaterialIcons"} name={"arrow-forward-ios"} size={moderateScale(15)} color={item.color || colors.light_theme.gray} />
                    </View>
                }



            </TouchableOpacity> */}

      <TouchableOpacity activeOpacity={1} onPress={_handleSubmit}>
        {item.heading ? (
          <BorderLine
            marginTop={index == 0 ? height * 0.02 : height * 0.03}
            style={[styles.borderLine]}
          />
        ) : (
          <></>
        )}
        <View style={[styles.options, marginTop && {marginTop}]}>
          {item.heading ? (
            <CustomText
              fontFamily={font.regular}
              fontSize={fontSize || moderateScale(16)}
              color={'#ADADAD'}
              text={item.heading}
            />
          ) : (
            <></>
          )}
          {!item.heading ? (
            <View style={styles.optionContainer}>
              <CustomText
                color={item.color || 'black'}
                fontFamily={item.color ? font.bold : font.regular}
                fontSize={fontSize || moderateScale(16)}
                text={item.option_name}
              />
              {!item.color && (
                <Icon
                  icon_type={'FontAwesome5'}
                  name={'chevron-right'}
                  color={'black'}
                  size={fontScale * 15}
                />
              )}
            </View>
          ) : (
            <></>
          )}
        </View>
      </TouchableOpacity>
      <BottomSheetReUsable
        title={'Are you sure you want to logout?' || ''}
        refRBSheet={refRBSheet}
        data={options}
        height={200}
   
      />
    </>
  );
};

export default ProfileItem;

const styles = StyleSheet.create({
  mainView: {
    flex: 1,
    backgroundColor: 'white',
  },
  header: {
    backgroundColor: colors.light_theme.theme,
    paddingBottom: height * 0.07,
    borderBottomRightRadius: 20,
    borderBottomLeftRadius: 20,
    paddingHorizontal: margin.horizontal,
    paddingTop: height * 0.02,
  },
  headerHeading: {
    marginLeft: width * 0.03,
  },
  content: {
    marginHorizontal: margin.horizontal,
    backgroundColor: 'white',
    flex: 1,
    borderTopRightRadius: 20,
    borderTopLeftRadius: 20,
    padding: width * 0.05,
    marginTop: height * -0.05,
    // ...shadow,
    // elevation: 1,
  },
  header_image: {
    width: width * 0.06,
    height: width * 0.06,
    borderRadius: 180,
  },
  circle: {
    width: width * 0.08,
    height: width * 0.08,
    backgroundColor: 'white',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 180,
    marginRight: width * 0.03,
  },
  borderLine: {
    width: '100%',
    marginLeft: 0,
  },
  options: {
    marginTop: height * 0.03,
  },
  optionContainer: {
    ...globalStyle.space_between,
  },
});
