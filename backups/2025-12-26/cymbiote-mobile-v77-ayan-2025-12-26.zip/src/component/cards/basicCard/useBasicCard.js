import React, { useRef, useState } from 'react';
import { View, StyleSheet, Dimensions, Animated } from 'react-native';
import { font, shadow, colors } from '@constant/contstant';
import HomeDualCard from '../homeDualCard';
import { WH } from '@constant/contstant';
import { homeData } from '@constant/dummyData';
import CustomImage from '../../../materialComponent/image/image';
import CustomText from '../../../materialComponent/customText/customText';
import CartButton from '../../../materialComponent/customButton/cartButton';

const { fontScale, height, width } = Dimensions.get('window');

const useBasicCard = ({ data }) => {
    const [currentIndex, setCurrentIndex] = useState(2);

    const getCurrentProduct = data?.[currentIndex] || {}
    const getCurrentProductVariantId = getCurrentProduct?.product_variant?.[0]?.variant_id
    const getCurrentVariant = getCurrentProduct?.product_variant?.[0]
    return {
        currentIndex,
        setCurrentIndex,
        getCurrentProduct,
        getCurrentProductVariantId,
        getCurrentVariant
    }
};

export default useBasicCard;

const styles = StyleSheet.create({
    cardWrapper: {
        width: width * 0.45,
        alignItems: 'center',
        paddingVertical: height * 0.01,
        borderRadius: 20,
        marginRight: 15,
        ...shadow,
        backgroundColor: "white",
        borderWidth: 1,
        borderColor: colors.light_theme.borderColor,
    },
    image: {
        width: width * 0.40,
        aspectRatio: 1,
        backgroundColor: '#e7ecf2',
        borderRadius: 18,
    },
    textContainer: {
        width: width * 0.40,
        alignItems: 'center',
    },
})
