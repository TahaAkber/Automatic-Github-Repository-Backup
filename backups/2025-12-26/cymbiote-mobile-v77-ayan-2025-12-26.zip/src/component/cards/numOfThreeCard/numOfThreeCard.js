import React, { memo, useRef, useState } from 'react';
import {
  View,
  StyleSheet,
  Dimensions,
  Animated,
  TouchableOpacity,
  FlatList,
} from 'react-native';
import useNumOfThreeCard from './useNumOfThreeCard';
import ShopTileCategories from '@component/shopTIleCategories/shopTIleCategories';
import { margin, WH } from '@constant/contstant';

const { height } = Dimensions.get('window');

const NumOfThreeCard = ({ data, item, tilePosition, markShopAsClicked }) => {
  const { renderItem } = useNumOfThreeCard(item, tilePosition, markShopAsClicked);
  // const [numColumns, setNumColumns] = useState(4);

  // Change numColumns dynamically if needed

  return (
    <View style={{ zIndex: 1, flex: 1 }}>
      <View
        style={{
          marginBottom: height * 0.02,
          paddingHorizontal: margin.horizontal,
        }}>
        <View style={styles.flatlist}>
          <FlatList
            // scrollEnabled={true}
            data={Array.isArray(data) ? data.slice(0, 4) : []}
            renderItem={renderItem}
            keyExtractor={(item, index) => index.toString()}
            showsHorizontalScrollIndicator={false}
            columnWrapperStyle={{ marginTop: height * 0.02 }}
            numColumns={2}
            showsVerticalScrollIndicator={false}
          // key={numColumns}  //
          />
        </View>
      </View>
    </View>
  );
};

export default memo(NumOfThreeCard);

const styles = StyleSheet.create({});
