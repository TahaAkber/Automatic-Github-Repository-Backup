import React, { memo } from 'react';
import { View, Dimensions } from 'react-native';
import useHomeHorizontalCard from './useHomeHorizontalCard';
import HorizontalProduct from './horizontalProduct';

const { height } = Dimensions.get('window');

const HomeHorizontalCard = ({ data, horizontal, removeLogo, item, tilePosition, markShopAsClicked }) => {
  const {
    currentIndex,
    setCurrentIndex,
  } = useHomeHorizontalCard({ data });

  return (
    <View>
      <View
        style={
          horizontal
            ? {
              justifyContent: 'center',
              alignSelf: 'center',
              alignItems: 'center',
              marginBottom: height * 0.01,
            }
            : {
              position: 'absolute',
              bottom: height * 0.15,
              left: 0,
              // flexDirection: "row",
            }
        }>

      </View>
      <HorizontalProduct
        horizontal={horizontal}
        data={data}
        currentIndex={currentIndex}
        setCurrentIndex={setCurrentIndex}
        item={item}
        tilePosition={tilePosition}
        markShopAsClicked={markShopAsClicked}
      />
    </View>
  );
};

export default memo(HomeHorizontalCard);
