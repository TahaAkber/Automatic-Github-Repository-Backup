import { useState } from 'react';

const useVerticalCard = () => {
    const [currentIndex, setCurrentIndex] = useState(0);

    return {
        currentIndex,
        setCurrentIndex,
    };
};

export default useVerticalCard;
