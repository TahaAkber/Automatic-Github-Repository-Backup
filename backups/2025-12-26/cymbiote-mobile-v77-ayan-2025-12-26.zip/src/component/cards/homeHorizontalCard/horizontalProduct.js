import React, { useState, useCallback, useMemo, useRef, useEffect } from 'react';
import {
  View,
  StyleSheet,
  Dimensions,
  TouchableOpacity,
  ActivityIndicator,
  FlatList,
} from 'react-native';
import Carousel from 'react-native-snap-carousel';
import CustomImage from '@materialComponent/image/image';
import Icon from '@materialComponent/icon/icon';
import { moderateScale } from 'react-native-size-matters';
import CustomText from '../../../materialComponent/customText/customText';
import { font, globalStyle, noImageUrl } from '../../../constant/contstant';
import { currency } from '../../../constant/signature';
import {
  defaultShopImages,
  formatPrice,
  getImageHeightFromItem,
  showingVaraintPrice,
  toFixedMethod,
} from '../../../utils/helper/helper';
import { navigate } from '../../../utils/navigationRef/navigationRef';
import Like from '../../../materialComponent/like/like';
import useReduxStore from '../../../utils/hooks/useReduxStore';
import useImageHeight from '../../../utils/hooks/useImageHeight';
import { logHomeProductClickEvent } from '../../../helper/eventTriggers/useEventTriggers';

const { height, width, fontScale } = Dimensions.get('window');
const dynamicWidthHeight = width * 0.55;
const dynamicImageWidthHeight = height * 0.06;

const HorizontalProduct = ({
  data,
  setCurrentIndex,
  currentIndex,
  horizontal,
  item: shopItem,
  tilePosition,
  markShopAsClicked,
}) => {
  const carouselRef = useRef(null);
  const [carouselData] = useState(data.slice(0, 5)); // Start with first 5 items
  const [productHeights, setProductHeights] = useState({});


  useEffect(() => {
    if (!carouselData || carouselData.length === 0) return; // 👈 guard clause
    const loadHeights = async () => {
      const heightsMap = {};

      await Promise.all(
        carouselData.map(async (item) => {
          try {
            const imageUrl = defaultShopImages(item)?.[0];
            const height = await getImageHeightFromItem(imageUrl);
            heightsMap[item.product_id] = height;
          } catch (err) {
            console.error("Failed to get height for", item, err);
          }
        })
      );

      setProductHeights(heightsMap);
    };

    loadHeights();
  }, [carouselData]);

  const renderItem = useCallback(({ item: productItem, index: productIndex }) => {
    const height = productHeights[productItem.product_id];

    const handleProductPress = async () => {
      // Log product click analytics
      if (shopItem && tilePosition !== undefined) {
        await logHomeProductClickEvent(
          productItem,
          shopItem,
          productIndex,
          tilePosition,
        );
      }

      // Mark shop as clicked
      if (markShopAsClicked && shopItem?.shop_id) {
        markShopAsClicked(shopItem.shop_id);
      }

      navigate('ProductDetail', {
        product_id: productItem.product_id,
        shop_id: productItem.product_shop_id,
        default_images: defaultShopImages(productItem),
        height
      });
    };

    return (
      <TouchableOpacity
        activeOpacity={0.9}
        onPress={handleProductPress}
        style={styles.cardContainer}
      >
        <CustomImage
          style={styles.productImage}
          source={{ uri: productItem?.product_image_url_low || productItem.product_image_url || noImageUrl }}
        />
        <View style={styles.textContainer}>
          <CustomText
            numberOfLines={1}
            fontSize={fontScale * 12}
            color="white"
            fontFamily={font.medium}
            text={productItem.product_name}
          />

          <CustomText
            numberOfLines={1}
            marginTop={height * 0.009}
            fontSize={fontScale * 11}
            color="white"
            fontFamily={font.medium}
            text={`${productItem?.product_currency || currency} ${formatPrice(
              showingVaraintPrice(
                productItem.product_variant[0]?.variant_price,
                productItem.product_variant[0]?.variant_discounted_price,
              ).discounted_price,
            )}`}
          />
          {productItem.product_variant[0]?.variant_discounted_price ? (
            <CustomText
              numberOfLines={1}
              marginTop={height * 0.00}
              fontSize={fontScale * 11}
              color="white"
              fontFamily={font.medium}
              style={{ textDecorationLine: 'line-through', opacity: 0.8 }}
              text={`${productItem?.product_currency || currency} ${formatPrice(
                showingVaraintPrice(
                  productItem.product_variant[0]?.variant_price,
                  productItem.product_variant[0]?.variant_discounted_price,
                ).original_price,
              )}`}
            />
          ) : (
            <></>
          )}
        </View>
        <Like
          style={{
            // bottom: '-50%',
            // right: '20%',
            top: '78%',
            left: '92%',
            width: moderateScale(28),
            height: moderateScale(28),
          }}
          size={moderateScale(15)}
          product_id={productItem?.product_id}
        />
      </TouchableOpacity>
    );
  }, [productHeights, shopItem, tilePosition, markShopAsClicked]);

  return (
    <View style={[styles.container]}>
      <View style={[!horizontal && styles.carouselContainer]}>

        <FlatList
          data={data}
          renderItem={renderItem}
          keyExtractor={(item, index) => index.toString()}
          horizontal={horizontal}
          showsHorizontalScrollIndicator={false}
          snapToAlignment="center"
          decelerationRate="fast"
          snapToInterval={width * 0.65 + 10} // spacing between items
          contentContainerStyle={styles.carouselContent}
          onEndReachedThreshold={0.5}
        // onEndReached={() => {
        //   if (carouselData.length > 0) loadMoreData();
        // }}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    position: 'absolute',
    bottom: height * 0.02,
    right: 0,
    width: '100%',
  },
  carouselContainer: {
    alignItems: 'center',
  },
  cardContainer: {
    width: width * 0.65,
    borderRadius: 10,
    overflow: 'hidden',
    flexDirection: 'row',
    height: height * 0.12,
    padding: width * 0.025,
    backgroundColor: 'rgba(0, 0, 0, 0.6)',
    alignItems: 'center',
    marginHorizontal: width * 0.01,
  },
  productImage: {
    height: width * 0.2,
    aspectRatio: 1,
    borderRadius: 7,
  },
  textContainer: {
    width: height * 0.15,
    marginLeft: height * 0.01,
    alignSelf: 'flex-start',
    marginTop: height * 0.013,
  },
  carouselContent: {
    paddingVertical: 10,
    paddingHorizontal: 10,
  },
});

export default React.memo(HorizontalProduct);
