import React, { useRef, useState } from 'react';
import { View, StyleSheet, Dimensions, TouchableOpacity, ActivityIndicator } from 'react-native';
import Carousel from 'react-native-snap-carousel';
import Icon from '@materialComponent/icon/icon';

const { height, width, fontScale } = Dimensions.get('window');
const dynamicWidthHeight = height * 0.02;

const ColorProducts = ({ data, horizontal, setVariant, variant, colorCode }) => {

    const carouselRef = useRef(null);
    // const colors = ["#4169E1", "#FAFAFA", "#FFA500", "#DD3333"]

    const [carouselData, setCarouselData] = useState(colorCode); // Start with first 5 items
    const [isLoading, setIsLoading] = useState(false);

    // Simulate fetching more data
    const loadMoreData = () => {
        if (!isLoading && carouselData.length < data.length) {
            setIsLoading(true);
            setTimeout(() => {
                const newData = data.slice(carouselData.length, carouselData.length + 5);
                setCarouselData([...carouselData, ...newData]);
                setIsLoading(false);
            }, 1500);
        }
    };

    // Render Carousel Item
    const renderItem = ({ item, index }) => (
        <TouchableOpacity
            onPress={() => setVariant(index)} // Set active index on item click
            style={{
                width: horizontal ? width * 0.0021 : width * 0.085,
                height: height * 0.02,
                justifyContent: "center",
                alignItems: "center"
            }}
        >
            <View
                style={[
                    styles.carouselItem,
                    { backgroundColor: item },
                    variant === index && { borderWidth: 2, borderColor: 'white' }, // Highlight active item
                ]}
            />
        </TouchableOpacity>
    );



    return colorCode?.length > 0 ? (
        <View style={styles.container}>
            {/* Left Arrow */}
            <TouchableOpacity
                onPress={() => {
                    if (carouselRef.current) carouselRef.current.snapToPrev();
                }}
                style={styles.arrowButton}
            >
                <Icon
                    icon_type="MaterialIcons"
                    name="keyboard-arrow-left"
                    color="black"
                    size={fontScale * 10}
                />
            </TouchableOpacity>

            {/* Carousel */}
            <View style={styles.carouselContainer}>
                {/* <Carousel
                    ref={carouselRef}
                    data={carouselData}
                    renderItem={renderItem}
                    sliderWidth={width * 0.15} // Adjust carousel width
                    itemWidth={width * 0.08}
                    inactiveSlideOpacity={1}
                    inactiveSlideScale={1}
                    loop={false}
                    useScrollView
                    firstItem={0} // Start from the first item
                    nestedScrollEnabled
                    contentContainerCustomStyle={styles.carouselContent}
                    onSnapToItem={(index) => {
                        setCurrentIndex(index);
                        if (index === carouselData.length - 1) loadMoreData();
                    }}
                /> */}

                <Carousel
                    ref={carouselRef}
                    data={carouselData}
                    renderItem={renderItem}
                    sliderWidth={horizontal ? width * 0.15 : width * 0.23} // Adjust carousel width
                    itemWidth={horizontal ? width * 0.065 : width * 0.085}
                    inactiveSlideOpacity={1}
                    inactiveSlideScale={1}
                    // loop={true} // Enable loop for continuous scroll
                    useScrollView
                    firstItem={2} // Start from the first item
                    nestedScrollEnabled
                    contentContainerCustomStyle={styles.carouselContent}
                    onSnapToItem={(index) => {
                        setVariant(index);
                        // Load more data when last item is reached
                        if (index === carouselData.length - 1) {
                            loadMoreData();
                        }
                    }}
                />
            </View>

            {/* Loader */}
            {isLoading && (
                <ActivityIndicator size="small" color="#3498db" style={styles.loader} />
            )}

            {/* Right Arrow */}
            <TouchableOpacity
                onPress={() => {
                    if (carouselRef.current) carouselRef.current.snapToNext();
                }}
                style={styles.arrowButton}
            >
                <Icon
                    icon_type="MaterialIcons"
                    name="keyboard-arrow-right"
                    color="black"
                    size={fontScale * 10}
                />
            </TouchableOpacity>
        </View>
    ) : <></>
};

export default ColorProducts;

const styles = StyleSheet.create({
    container: {
        justifyContent: 'center',
        alignItems: 'center',
        flexDirection: 'row',
        alignSelf: 'center',
        borderWidth: 1, borderColor: "white",
        paddingVertical: 3,
        borderRadius: 180
    },
    carouselItem: {
        backgroundColor: 'red',
        width: width * 0.04,
        aspectRatio: 1,
        borderRadius: 180,
    },
    arrowButton: {
        width: width * 0.04,
        aspectRatio: 1,
        backgroundColor: '#D9D9D9',
        borderRadius: 180,
        justifyContent: 'center',
        alignItems: 'center',
        marginHorizontal: width * 0.02,
    },
    carouselContainer: {
        paddingTop: height * 0.002,
    },
    carouselContent: {
        alignItems: 'center',
        justifyContent: "center"
    },
    loader: {
        marginVertical: 10,
    },
});
