import React, {useState, useCallback, useEffect} from 'react';
import {FlatList, StyleSheet, View, Dimensions, Text} from 'react-native';
import ReelCard from './reelCard';
import CustomText from '../../../materialComponent/customText/customText';
import {font, margin, WH} from '../../../constant/contstant';
import {moderateScale, verticalScale} from 'react-native-size-matters';
import ReelIcon from '@assets/images/reelIcon.svg';
import useReduxStore from '../../../utils/hooks/useReduxStore';
import {useIsFocused} from '@react-navigation/native';

const {width, height} = Dimensions.get('screen');

const ReelList = ({item, isMerchantScreen, index}) => {
  const {getState} = useReduxStore();
  const isFocused = useIsFocused();
  const {activeVideoIndex} = getState('common');

  const [visibleIndex, setVisibleIndex] = useState(0);
  const [currentPlayingIndex, setCurrentPlayingIndex] = useState(0);

  const onViewableItemsChanged = useCallback(({viewableItems}) => {
    if (viewableItems.length > 0) {
      const firstVisibleItem = viewableItems[0];
      setVisibleIndex(firstVisibleItem.index);
      setCurrentPlayingIndex(firstVisibleItem.index);
    }
  }, []);

  useEffect(() => {
    if (!isFocused) return;

    const interval = setInterval(() => {
      setCurrentPlayingIndex(prevIndex => {
        const indices = [visibleIndex, visibleIndex + 1];
        const nextIndex = prevIndex === indices[0] ? indices[1] : indices[0];
        return nextIndex;
      });
    }, 3000); // Change every 3 seconds

    return () => clearInterval(interval);
  }, [visibleIndex, isFocused]);

  const renderItem = useCallback(
    ({item, index}) => {
      if (item.isDummy) {
        return <View style={{width: width * 0.5}} />;
      }

      return (
        <ReelCard
          index={index}
          item={item}
          activeVideoIndex={activeVideoIndex}
          visibleIndex={visibleIndex}
          setVisibleIndex={setVisibleIndex}
          setActiveVideoIndex={() => {}}
          showProduct={true}
          style={[
            styles.reelCard,
            {
              marginRight: isMerchantScreen
                ? moderateScale(-45)
                : moderateScale(-12),
              marginLeft: index === 0 ? moderateScale(15) : 0,
            },
          ]}
          isProductDetail={false}
          isPlaying={index === currentPlayingIndex}
          isMerchantScreen={isMerchantScreen}
        />
      );
    },
    [currentPlayingIndex, activeVideoIndex, visibleIndex, isMerchantScreen],
  );

  return (
    <View
      style={[
        styles.container,
        {
          backgroundColor: isMerchantScreen ? 'transparent' : 'white',
          paddingTop: isMerchantScreen ? 1 : 2,
          marginLeft: isMerchantScreen ? 1 : 0,
        },
      ]}>
      {!isMerchantScreen && (item.reels || [])?.length > 0 ? (
        <View style={styles.headingContainer}>
          <ReelIcon
            width={WH.width(6)}
            height={WH.width(6)}
            marginTop={width * 0.01}
          />
          <CustomText
            text="Reels"
            style={styles.heading}
            fontSize={moderateScale(18)}
            fontFamily={font.medium}
          />
        </View>
      ) : (
        <></>
      )}
      <FlatList
        data={[...item.reels, ...(isMerchantScreen ? [] : [])]}
        renderItem={renderItem}
        keyExtractor={(item, index) => index.toString()}
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.flatListContainer}
        initialNumToRender={3}
        removeClippedSubviews={true}
        onViewableItemsChanged={onViewableItemsChanged} // Track visible items
        viewabilityConfig={{
          itemVisiblePercentThreshold: 50,
        }}
      />
    </View>
  );
};

export default React.memo(ReelList, (prevProps, nextProps) => {
  return (
    prevProps.isMerchantScreen === nextProps.isMerchantScreen &&
    prevProps.index === nextProps.index &&
    prevProps.item?.reels?.length === nextProps.item?.reels?.length &&
    JSON.stringify(prevProps.item?.reels) ===
      JSON.stringify(nextProps.item?.reels)
  );
});

const styles = StyleSheet.create({
  container: {
    flex: 1,
    marginTop: width * 0.03,
    // paddingTop: 10,
    // marginLeft: 15,
    // backgroundColor: 'white',
  },
  heading: {
    marginLeft: 10,
    // marginBottom: 1,
  },
  reelCard: {
    width: width * 0.44,
    // marginRight: moderateScale(-15),
  },
  flatListContainer: {
    paddingRight: moderateScale(10),
  },
  headingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginLeft: margin.horizontal,
    marginTop: verticalScale(15),
  },
});
