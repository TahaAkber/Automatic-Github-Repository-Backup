import React, {useEffect, useRef, useState} from 'react';
import {
  Animated,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  Dimensions,
  Easing,
  AppState,
} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import {moderateScale, verticalScale} from 'react-native-size-matters';
import CustomImage from '../../../materialComponent/image/image';
import {navigate} from '../../../utils/navigationRef/navigationRef';
import {shadow} from '@constant/contstant';
import {tileHeight} from '../../../constant/contstant';
import Overlay from '../../../materialComponent/overlay/overlay';
import {_getStories} from '../../../redux/actions/reels/reels';
import {useDispatch} from 'react-redux';
import {_cartBottomSheet} from '../../../redux/actions/common/common';
import {useIsFocused} from '@react-navigation/native';
import ReelPreviewVideo from '../../video/reelPreviewVideo';
import useReduxStore from '../../../utils/hooks/useReduxStore';
import {heightPercentageToDP} from 'react-native-responsive-screen';

const {width, height} = Dimensions.get('screen');

const ReelCard = React.memo(
  ({
    index,
    visibleIndex,
    visibleIndexes,
    playNeighbors = 1,
    isPlaying,
    style,
    item,
    isMerchantScreen,
  }) => {
    const dispatch = useDispatch();
    const {getState} = useReduxStore();
    const {fetch_user_detail} = getState('auth');
    const {activeVideoIndex} = getState('common');

    const [animationDuration, setAnimationDuration] = useState(3000);
    const [isRotating, setIsRotating] = useState(false);
    const rotation = useRef(new Animated.Value(0)).current;

    // App & screen focus
    const isFocused = useIsFocused();
    const [appActive, setAppActive] = useState(true);
    const appState = useRef(AppState.currentState);

    useEffect(() => {
      const sub = AppState.addEventListener('change', nextState => {
        const goingInactive =
          appState.current === 'active' &&
          (nextState === 'inactive' || nextState === 'background');
        if (goingInactive) setAppActive(false);
        if (nextState === 'active') setAppActive(true);
        appState.current = nextState;
      });
      return () => {
        rotation.stopAnimation();
        setIsRotating(false);
        sub.remove();
      };
    }, [rotation]);

    const closeCartAndOpenBrand = async () => {
      dispatch(_cartBottomSheet(false));
      navigate('Brand', {shop_id: item.shop_id, shop: item});
    };

    const startRingAnimation = () => {
      setIsRotating(true);
      rotation.setValue(0);
      Animated.loop(
        Animated.timing(rotation, {
          toValue: 1,
          duration: animationDuration,
          easing: Easing.linear,
          useNativeDriver: true,
        }),
      ).start();
      loadStories();
    };

    const loadStories = async () => {
      const t0 = (global?.performance && performance.now?.()) ?? Date.now();
      try {
        const userId = fetch_user_detail?.id;
        await dispatch(_getStories({shopId: item.shop_id, userId}));
        const t1 = (global?.performance && performance.now?.()) ?? Date.now();
        setAnimationDuration(Math.max(1200, t1 - t0));
        setIsRotating(false);
        rotation.stopAnimation();
        navigate('Stories', {from: 'popup'});
      } catch (e) {
        setIsRotating(false);
      }
    };

    const rotateInterpolate = rotation.interpolate({
      inputRange: [0, 1],
      outputRange: ['0deg', '360deg'],
    });

    if (!item) return <Text>No reel data available.</Text>;

    const handleNavigate = () => {
      navigate('ReelsScreen', {
        videoId: item.video_url_id,
        ...(isMerchantScreen ? {shopId: item.shop_id} : {}),
      });
    };

    const previewUrl = item?.video_url_preview || '';

    const tileVisible = (() => {
      const inSet = (() => {
        if (!visibleIndexes) return undefined;
        if (Array.isArray(visibleIndexes)) return visibleIndexes.includes(index);
        if (visibleIndexes instanceof Set) return visibleIndexes.has(index);
        return undefined;
      })();

      const isWithinWindow = center =>
        typeof center === 'number'
          ? Math.abs(index - center) <= playNeighbors
          : undefined;

      if (typeof inSet === 'boolean') return inSet;
      const inVisible = isWithinWindow(visibleIndex);
      const inActive = isWithinWindow(activeVideoIndex);
      if (typeof inVisible === 'boolean') return inVisible;
      if (typeof inActive === 'boolean') return inActive;
      return true;
    })();

    const parentWantsPlay = typeof isPlaying === 'boolean' ? isPlaying : true;
    const shouldPlay =
      isFocused && appActive && parentWantsPlay && tileVisible && !!previewUrl;

    const paused = !shouldPlay;

    return (
      <Animated.View style={[{opacity: 1}, style]}>
        <TouchableOpacity activeOpacity={1} onPress={handleNavigate}>
          <View
            style={[
              styles.video_container,
              {
                width: isMerchantScreen ? '69%' : '90%',
                height: isMerchantScreen ? height * 0.22 : heightPercentageToDP(25),
                marginTop: isMerchantScreen
                  ? verticalScale(0)
                  : verticalScale(20),
              },
            ]}>
            {previewUrl && !isMerchantScreen && isFocused ? (
              <>
                <ReelPreviewVideo
                  uri={previewUrl}
                  thumbnailUri={item.video_thumbnail_url}
                  style={styles.video}
                  resizeMode="cover"
                  muted
                  repeat
                  paused={paused}
                  index={index}
                  onError={e => console.warn('Video error:', e?.message || e)}
                  onBuffer={e =>
                    console.log('Buffering...', e.isBuffering, item.video_url)
                  }
                />
              </>
            ) : (
              <CustomImage
                source={{uri: item.video_thumbnail_url}}
                style={styles.video}
              />
            )}

            <Overlay borderRadius={moderateScale(10)} />

            {!isMerchantScreen && (
              <TouchableOpacity
                activeOpacity={0.8}
                onPress={
                  item.shopHaveStory ? startRingAnimation : closeCartAndOpenBrand
                }
                style={styles.brandTabContainer}>
                {item.shopHaveStory ? (
                  <View style={styles.gradientWrapper}>
                    <Animated.View
                      style={[
                        styles.animatedRing,
                        {transform: [{rotate: rotateInterpolate}]},
                      ]}>
                      <LinearGradient
                        colors={['#ED1D1D', '#1A97CD', '#00CE83', '#FF7F00']}
                        start={{x: 0.1, y: 0.2}}
                        end={{x: 0.9, y: 0.8}}
                        locations={[0, 0.3, 0.7, 1]}
                        style={styles.gradientRing}
                      />
                    </Animated.View>
                    <View style={styles.brandViewWithRing}>
                      <CustomImage
                        source={{uri: item.shop_logo_url}}
                        style={styles.brandTabImageStyle}
                        size={'small'}
                      />
                    </View>
                  </View>
                ) : (
                  <CustomImage
                    source={{uri: item.shop_logo_url}}
                    style={styles.brandTabImageStyle}
                    size={'small'}
                  />
                )}
              </TouchableOpacity>
            )}
          </View>
        </TouchableOpacity>
      </Animated.View>
    );
  },
);

export default ReelCard;

const styles = StyleSheet.create({
  video_container: {
    borderRadius: moderateScale(10),
    marginTop: verticalScale(20),
    height: tileHeight - 300,
    borderColor: '#f7f7f7',
    backgroundColor: 'white',
    position: 'relative',
    overflow: 'hidden',
    borderWidth: 1,
    width: '90%',
    flex: 1,
  },
  video: {
    height: '100%',
    width: '100%',
    position: 'absolute',
    borderRadius: moderateScale(10),
  },
  brandTabContainer: {
    position: 'absolute',
    top: 10,
    left: 10,
    zIndex: 1,
  },
  brandTabImageStyle: {
    borderRadius: moderateScale(180),
    width: width * 0.1,
    height: width * 0.1,
    ...shadow,
    backgroundColor: 'white',
    elevation: 2,
  },
  gradientWrapper: {
    justifyContent: 'center',
    alignItems: 'center',
    height: width * 0.11,
    width: width * 0.11,
    marginRight: moderateScale(10),
  },
  animatedRing: {
    position: 'absolute',
    height: width * 0.1,
    width: width * 0.1,
    borderRadius: (width * 0.1) / 2,
    overflow: 'hidden',
    justifyContent: 'center',
    alignItems: 'center',
  },
  gradientRing: {
    height: '100%',
    width: '100%',
    borderRadius: (width * 0.1) / 2,
  },
  brandViewWithRing: {
    borderRadius: moderateScale(180),
    backgroundColor: 'white',
    height: width * 0.1 - 3,
    width: width * 0.1 - 3,
    overflow: 'hidden',
    borderWidth: 1,
    alignItems: 'center',
  },
});
