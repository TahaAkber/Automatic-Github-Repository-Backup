import { moderateScale, verticalScale } from 'react-native-size-matters';
import Overlay from '@materialComponent/overlay/overlay';
import BrandTab from '@component/brandTab/brandTab';
import React from 'react';
import { colors, margin, WH, shadow } from '@constant/contstant';
import Video from 'react-native-video';
import {
    Dimensions,
    StyleSheet,
    TouchableOpacity,
    View,
} from 'react-native';
import HomeVerticalCard from '../homeVerticalCard/homeVerticalCard';
import CustomBackgoundImage from '@materialComponent/image/bgImage';
import { tileHeight } from '../../../constant/contstant';
import { navigate } from '../../../utils/navigationRef/navigationRef';

const { height, fontScale, width, } = Dimensions.get('screen');

const ShopTileTwo = ({ item, index, isProductDetail, style }) => {
    return (
        <View style={[{ paddingHorizontal: margin.horizontal }, style]}>
            <TouchableOpacity onPress={() => navigate("Brand", { shop_id: item.shop_id, shop: item })} activeOpacity={1}>
                <CustomBackgoundImage
                    style={[
                        index != 0 && { marginTop: verticalScale(20) },
                        styles.backgroundImage,
                        isProductDetail && { height: WH.height(25), marginTop: verticalScale(0) }
                    ]}
                    imageStyle={styles.imageStyle}
                    source={{
                        uri: item?.shop_banner_url,
                    }}
                    resizeMode="cover">
                    <Overlay />
                    <View style={[styles.contentContainer, isProductDetail && { justifyContent: 'flex-end' }]}>
                        {isProductDetail ?
                            <BrandTab
                                shopNameFontSize={fontScale * 8}
                                mainViewStyle={styles.brandTabMainViewStyle}
                                imageStyle={styles.brandTabImageStyle}
                                item={item}
                                followStyle={{ backgroundColor: "black" }}
                                light={"white"}
                                followColor={"white"}
                            /> :
                            <BrandTab light={"white"} item={item} />
                        }
                        {!isProductDetail && <HomeVerticalCard data={item.products} item={item} />}
                    </View>
                </CustomBackgoundImage >
            </TouchableOpacity>
        </View>

    );
};



export default ShopTileTwo;

const styles = StyleSheet.create({
    backgroundImage: {
        width: '100%',
        height: tileHeight,
        zIndex: 1,
        borderRadius: moderateScale(20),
        overflow: 'hidden',
        // marginTop: verticalScale(20),
        backgroundColor: 'white',
        borderColor: colors.light_theme.darkBorderColor,
    },
    imageStyle: {
        borderRadius: moderateScale(20),
        overflow: 'hidden',
    },
    contentContainer: {
        marginHorizontal: moderateScale(20),
        marginTop: verticalScale(18),
        justifyContent: 'space-between',
        flex: 1,
    },
    brandTabMainViewStyle: {
        paddingHorizontal: 0,
        paddingBottom: 10
    },
    brandTabImageStyle: {
        width: width * 0.1,
        height: width * 0.1,
        ...shadow,
        backgroundColor: 'white',
        elevation: 2,
    },
});
