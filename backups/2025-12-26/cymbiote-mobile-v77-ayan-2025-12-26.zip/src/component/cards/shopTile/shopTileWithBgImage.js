import {moderateScale, verticalScale} from 'react-native-size-matters';
import CustomBackgoundImage from '@materialComponent/image/bgImage';
import Overlay from '@materialComponent/overlay/overlay';
import BrandTab from '@component/brandTab/brandTab';
import {colors, WH} from '@constant/contstant';
import {homeData} from '@constant/dummyData';
import HomeDualCard from '../homeDualCard';
import React from 'react';
import {FlatList, StyleSheet, View} from 'react-native';

const ShopTileWithBgImage = ({item, index}) => {
  return (
    <CustomBackgoundImage
      style={[
        index != 0 && {marginTop: verticalScale(20)},
        styles.backgroundImage,
      ]}
      imageStyle={styles.imageStyle}
      source={{
        uri: item.shop_banner_url,
      }}
      resizeMode="cover">
      <Overlay />
      <View style={styles.contentContainer}>
        <BrandTab light={'white'} item={item} />

        <FlatList
          renderItem={({item}) => <HomeDualCard item={item} />}
          keyExtractor={(item, index) => index.toString()}
          contentContainerStyle={styles.flatListContainer}
          showsHorizontalScrollIndicator={false}
          data={item.products}
          horizontal
        />
      </View>
    </CustomBackgoundImage>
  );
};

export default ShopTileWithBgImage;

const styles = StyleSheet.create({
  backgroundImage: {
    width: '100%',
    height: WH.height('60'),
    zIndex: 1,
    borderRadius: moderateScale(20),
    overflow: 'hidden',
    // marginTop: verticalScale(20),
    backgroundColor: 'white',
    borderWidth: 1,
    borderColor: colors.light_theme.darkBorderColor,
  },
  imageStyle: {
    borderRadius: moderateScale(20),
    overflow: 'hidden',
  },
  overlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(97, 97, 97, 0.5)', // Semi-transparent gray overlay
  },
  contentContainer: {
    flex: 1,
    justifyContent: 'space-between',
    marginTop: verticalScale(15),
    marginHorizontal: moderateScale(20),
  },
  topSection: {
    marginBottom: moderateScale(10),
  },
  brandView: {
    width: WH.width('13%'),
    height: WH.width('13%'),
    borderRadius: moderateScale(12),
    marginRight: moderateScale(10),
    overflow: 'hidden',
    backgroundColor: 'white',
  },
  brandProfile: {
    width: '100%',
    height: '100%',
  },
  brandText: {
    marginBottom: moderateScale(4),
  },
  ratingText: {
    // marginRight: moderateScale(5),
  },
  icon: {
    marginRight: moderateScale(2),
  },
  followButton: {
    backgroundColor: 'rgba(0, 0, 0, 0.3)',
    paddingHorizontal: moderateScale(15),
    paddingVertical: moderateScale(8),
    borderRadius: moderateScale(10),
    borderWidth: 0,
    marginRight: moderateScale(10),
  },
  followingButton: {
    borderWidth: 1,
    borderColor: 'white',
  },
  flatListContainer: {
    marginTop: verticalScale(10),
    paddingVertical: verticalScale(5), // Add some vertical padding for spacing
    position: 'absolute',
    bottom: 5,
    // height: WH.width('55%'),
  },
  flatListContainerWithoutImage: {
    marginTop: verticalScale(10),
    paddingVertical: verticalScale(5), // Add some vertical padding for spacing
    bottom: 5,
    // height: WH.width('55%'),
  },
  container: {
    width: '100%',
    height: WH.height('57'),
    zIndex: 1,
    borderRadius: moderateScale(20),
    overflow: 'hidden',
    // marginTop: verticalScale(20),
    backgroundColor: 'white',
    borderWidth: 1,
    borderColor: colors.light_theme.darkBorderColor,
  },

  video_container: {
    flex: 1,
    width: '100%',
    height: WH.height('57'), // Adjust height as per your design
    position: 'relative',
    backgroundColor: 'white',
    borderRadius: moderateScale(20),
    overflow: 'hidden', // Prevents content from overflowing
    borderWidth: 1,
    borderColor: colors.light_theme.darkBorderColor,
  },

  // Video view styling
  video_view: {
    width: '100%',
    height: '100%',
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    zIndex: 0, // Ensures the video is behind everything
    justifyContent: 'center',
    alignItems: 'center',
  },
});
