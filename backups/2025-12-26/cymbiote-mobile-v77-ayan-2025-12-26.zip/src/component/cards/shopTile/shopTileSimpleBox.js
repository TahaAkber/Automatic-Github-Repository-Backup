import { moderateScale, verticalScale } from 'react-native-size-matters';
import { FlatList, StyleSheet, View } from 'react-native';
import BrandTab from '@component/brandTab/brandTab';
import { colors, WH } from '@constant/contstant';
import { homeData } from '@constant/dummyData';
import { shadow } from '@constant/contstant';
import HomeDualCard from '../homeDualCard';
import React from 'react';

const ShopTileSimpleBox = ({ item, index }) => {
  return (
    <View
      resizeMode="cover"
      style={[styles.container, index != 0 && { marginTop: verticalScale(20) }]}>
      <View style={styles.contentContainer}>
        <BrandTab item={item} />

        <FlatList
          data={item.products}
          renderItem={({ item }) => {
            return (
              <View style={{ marginRight: WH.width('2') }}>
                <HomeDualCard
                  width={WH.width('37')}
                  color={'black'}
                  item={item}
                />
              </View>
            );
          }}
          contentContainerStyle={styles.flatListContainerWithoutImage}
          keyExtractor={(item, index) => index.toString()}
          showsHorizontalScrollIndicator={false}
          numColumns={2}
        />
      </View>
    </View>
  );
};

export default ShopTileSimpleBox;

const styles = StyleSheet.create({
  backgroundImage: {
    borderRadius: moderateScale(20),
    height: WH.height('50'),
    borderColor: colors.light_theme.darkBorderColor,
    backgroundColor: 'white',
    overflow: 'hidden',
    width: '100%',
    zIndex: 1,
    ...shadow
  },
  flatListContainerWithoutImage: {
    marginTop: verticalScale(10),
    backgroundColor: 'red'
  },
  imageStyle: {
    borderRadius: moderateScale(20),
    overflow: 'hidden',
  },
  overlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(97, 97, 97, 0.5)',
  },
  contentContainer: {
    flex: 1,
    marginHorizontal: moderateScale(20),
    justifyContent: 'space-between',
    marginTop: verticalScale(15),
  },
  topSection: {
    marginBottom: moderateScale(10),
  },
  brandView: {
    borderRadius: moderateScale(12),
    marginRight: moderateScale(10),
    height: WH.width('13%'),
    width: WH.width('13%'),
    backgroundColor: 'white',
    overflow: 'hidden',
  },
  brandProfile: {
    height: '100%',
    width: '100%',
  },
  brandText: {
    marginBottom: moderateScale(4),
  },
  ratingText: {
    // marginRight: moderateScale(5),
  },
  icon: {
    marginRight: moderateScale(2),
  },
  followButton: {
    paddingHorizontal: moderateScale(15),
    paddingVertical: moderateScale(8),
    borderRadius: moderateScale(10),
    marginRight: moderateScale(10),
    backgroundColor: 'rgba(0, 0, 0, 0.3)',
    borderWidth: 0,
  },
  followingButton: {
    borderWidth: 1,
    borderColor: 'white',
  },
  flatListContainer: {
    paddingVertical: verticalScale(5),
    marginTop: verticalScale(10),
    position: 'absolute',
    bottom: 5,
  },
  flatListContainerWithoutImage: {
    paddingVertical: verticalScale(5),
    marginTop: verticalScale(10),
    bottom: 5,
  },
  container: {
    borderRadius: moderateScale(20),
    height: WH.height('60'),
    borderColor: colors.light_theme.darkBorderColor,
    backgroundColor: 'white',
    overflow: 'hidden',
    borderWidth: 1,
    width: '100%',
    zIndex: 1,
  },
});
