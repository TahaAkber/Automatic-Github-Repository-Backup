import {moderateScale, verticalScale} from 'react-native-size-matters';
import BrandTab from '@component/brandTab/brandTab';
import React from 'react';
import {colors, WH} from '@constant/contstant';
import {Dimensions, StyleSheet, View, Animated, Pressable} from 'react-native';
import CustomBackgoundImage from '@materialComponent/image/bgImage';
import HomeHorizontalCard from '../homeHorizontalCard/homeHorizontalCard';
import CategoryCard from '../categoryCard/categoryCard';
import {shadow} from '@constant/contstant';
import NumOfThreeCard from '../numOfThreeCard/numOfThreeCard';
import {
  margin,
  tileBasicHeight,
  tileBasicNoOfThreeHeight,
  tileHeight,
  tileShadow,
} from '../../../constant/contstant';
import ShopTileCategories from '../../shopTIleCategories/shopTIleCategories';
import useTilePressAnimation from './useTilePressAnimation';
import {navigate} from '../../../utils/navigationRef/navigationRef';

const {width, height} = Dimensions.get('window');

const ShopTileTwelve = ({item, index, markShopAsClicked}) => {
  const {scale, pressHandlers} = useTilePressAnimation();

  return (
    <Animated.View
      style={[
        index != 0 && {marginTop: verticalScale(20)},
        {
          marginHorizontal: margin.horizontal,
          borderRadius: moderateScale(40),
          alignItems: 'center',
          justifyContent: 'center',
          ...shadow,
          elevation: 10,
        },
        {transform: [{scale}]},
      ]}>
      <Pressable
        {...pressHandlers}
        onPress={() => navigate('Brand', {shop_id: item.shop_id, shop: item})}
        style={{flex: 1, width: '100%'}}>
        <View style={[styles.backgroundImage]} resizeMode="cover">
          <View style={styles.contentContainer}>
            <BrandTab
              followColor={'white'}
              followStyle={{backgroundColor: 'black'}}
              item={item}
              shopNameFontSize={12.5}
              tilePosition={index}
              markShopAsClicked={markShopAsClicked}
            />
          </View>
          <View style={{}}>
            <NumOfThreeCard
              horizontal={true}
              data={item.products}
              item={item}
              tilePosition={index}
              markShopAsClicked={markShopAsClicked}
            />
          </View>
        </View>
      </Pressable>
      {/* {Array.isArray(item?.filters) && item.filters.length > 0 ? (
        <View style={{paddingLeft: moderateScale(10)}}>
          <ShopTileCategories item={item?.filters} />
        </View>
      ) : null} */}
    </Animated.View>
  );
};

export default React.memo(ShopTileTwelve);

const styles = StyleSheet.create({
  backgroundImage: {
    width: '100%',
    alignSelf: 'center',
    zIndex: 1,
    borderRadius: moderateScale(20),
    overflow: 'hidden',
    backgroundColor: 'white',
  },
  imageStyle: {
    borderRadius: moderateScale(20),
    overflow: 'hidden',
  },
  contentContainer: {
    marginHorizontal: moderateScale(10),
    marginTop: verticalScale(12),
  },
});
