import {moderateScale, verticalScale} from 'react-native-size-matters';
import Overlay from '@materialComponent/overlay/overlay';
import BrandTab from '@component/brandTab/brandTab';
import React from 'react';
import {colors, margin} from '@constant/contstant';
import Video from 'react-native-video';
import {Dimensions, StyleSheet, TouchableOpacity, View} from 'react-native';
import HomeVerticalCard from '../homeVerticalCard/homeVerticalCard';
import {tileHeight} from '../../../constant/contstant';
import {navigate} from '../../../utils/navigationRef/navigationRef';
// import CustomVideo from '../../video/video';

const {height} = Dimensions.get('window');

const ShopTileThree = ({
  item,
  index,
  activeVideoIndex,
  setActiveVideoIndex,
  showProduct,
}) => {
  return (
    <View style={{paddingHorizontal: margin.horizontal}}>
      <View
        handleTouchEnd={index => setActiveVideoIndex(index)}
        onStartShouldSetResponder={() => setActiveVideoIndex(index)}
        style={[
          styles.video_container,
          index != 0 && {marginTop: verticalScale(20)},
        ]}>
        <TouchableOpacity
          style={styles.video_container}
          onPressIn={() => setActiveVideoIndex(index)} // Sets the active video on tap
          onPress={() => navigate('Brand', {shop_id: item.shop_id, shop: item})} // Navigates to Brand screen
          activeOpacity={1}>
          {/* <Video
            source={{uri: item.shop_banner_url}}
            style={styles.video_view}
            resizeMode="cover"
            muted={true}
                        disableFocus={true}

            repeat={true}
            paused={!Boolean(activeVideoIndex == index)} // Pause the video when it's not the active one
          /> */}

          {/* <CustomVideo
            item={item}
            paused={!Boolean(activeVideoIndex == index)}
          /> */}

          <Overlay />
          <View style={styles.contentContainer}>
            <BrandTab light={'white'} item={item} />
            <HomeVerticalCard
              horizontal={true}
              data={item.products}
              item={item}
            />
          </View>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default ShopTileThree;

const styles = StyleSheet.create({
  video_container: {
    borderRadius: moderateScale(20),
    height: tileHeight,
    borderColor: colors.light_theme.darkBorderColor,
    backgroundColor: 'white',
    position: 'relative',
    overflow: 'hidden',
    // borderWidth: 1,
    width: '100%',
    flex: 1,
  },
  video_view: {
    justifyContent: 'center',
    alignItems: 'center',
    position: 'absolute',
    height: '100%',
    width: '100%',
    zIndex: 0,
    bottom: 0,
    right: 0,
    left: 0,
    top: 0,
  },
  contentContainer: {
    marginHorizontal: moderateScale(20),
    marginTop: verticalScale(15),
    justifyContent: 'space-between',
    flex: 1,
  },
});
