import React from 'react';
import {Dimensions, FlatList, StyleSheet, View} from 'react-native';
import {moderateScale, verticalScale} from 'react-native-size-matters';
import Overlay from '@materialComponent/overlay/overlay';
import BrandTab from '@component/brandTab/brandTab';
import Video from 'react-native-video';
import {colors, WH, margin, shadow} from '@constant/contstant';
import HomeDualCard from '../homeDualCard';
import {tileHeight} from '../../../constant/contstant';
// import CustomVideo from '../../video/video';

const {fontScale, width} = Dimensions.get('screen');

const ShopTileSeven = ({
  item,
  index,
  activeVideoIndex,
  setActiveVideoIndex,
  showProduct,
  style,
  tabStyle,
  isProductDetail,
}) => {
  return (
    <View style={[{paddingHorizontal: margin.horizontal}, style]}>
      <View
        handleTouchEnd={index =>
          setActiveVideoIndex ? setActiveVideoIndex(index) : null
        }
        onStartShouldSetResponder={() =>
          setActiveVideoIndex ? setActiveVideoIndex(index) : null
        }
        style={[
          styles.video_container,
          index != 0 && {marginTop: verticalScale(20)},
          isProductDetail && {
            height: WH.height(25),
            marginTop: verticalScale(0),
          },
        ]}>
        {/* Video Background */}
        {/* <Video
          source={{uri: item.shop_banner_url}}
          style={[
            styles.video_view,
            isProductDetail && {height: WH.height(25)},
          ]}
          resizeMode="cover"
          muted={true}
                      disableFocus={true}

          repeat={true}
          paused={!Boolean(activeVideoIndex == index)} // Pause the video when it's not the active one
        /> */}

        {/* <CustomVideo item={item} paused={!Boolean(activeVideoIndex == index)} /> */}

        <Overlay />

        {/* BrandTab Positioned on Top of Video */}
        <View style={[styles.brandTabContainer, tabStyle]}>
          {isProductDetail ? (
            <BrandTab
              shopNameFontSize={fontScale * 8}
              mainViewStyle={[styles.brandTabMainViewStyle]} // Decrease width
              imageStyle={styles.brandTabImageStyle}
              item={item}
              followStyle={{backgroundColor: 'black'}}
              light={'white'}
              followColor={'white'}
            />
          ) : (
            <BrandTab
              isProductDetail={isProductDetail}
              mainViewStyle={[styles.brandTabMainViewStyle]} // Decrease width
              light={'white'}
              item={item}
            />
          )}
        </View>

        {showProduct ? (
          <FlatList
            data={item.products}
            horizontal
            renderItem={({item}) => <HomeDualCard item={item} />}
            keyExtractor={(item, index) => index.toString()}
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.flatListContainer}
          />
        ) : (
          <></>
        )}
      </View>
    </View>
  );
};

export default ShopTileSeven;

const styles = StyleSheet.create({
  video_container: {
    borderRadius: moderateScale(20),
    height: tileHeight,
    borderColor: colors.light_theme.darkBorderColor,
    backgroundColor: 'white',
    position: 'relative',
    overflow: 'hidden',
    borderWidth: 1,
    width: '100%',
    flex: 1,
  },
  video_view: {
    justifyContent: 'center',
    alignItems: 'center',
    position: 'absolute',
    height: '100%',
    width: '100%',
    zIndex: 0,
    bottom: 0,
    right: 0,
    left: 0,
    top: 0,
  },
  brandTabContainer: {
    top: verticalScale(20),
    left: moderateScale(20),
    zIndex: 1,
  },
  flatListContainer: {
    paddingVertical: verticalScale(5),
    marginTop: verticalScale(10),
    position: 'absolute',
    bottom: 5,
  },
  brandTabMainViewStyle: {
    paddingHorizontal: 0,
    paddingBottom: 20,
    width: '85%',
  },
  brandTabImageStyle: {
    width: width * 0.1,
    height: width * 0.1,
    ...shadow,
    backgroundColor: 'white',
    elevation: 2,
  },
});
