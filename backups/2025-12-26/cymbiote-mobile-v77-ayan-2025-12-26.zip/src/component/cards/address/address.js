
import { ActivityIndicator, Alert, StyleSheet, TouchableOpacity, View } from 'react-native';
import { moderateScale, scale, verticalScale } from 'react-native-size-matters';
import CustomText from '@materialComponent/customText/customText';
import { navigate } from '@utils/navigationRef/navigationRef';
import { colors, font, shadow } from '@constant/contstant';
import Icon from '@materialComponent/icon/icon';
import useAddressCard from './useAddressCard';
import React from 'react';

const AddressCard = ({ item, isCard }) => {
  const {
    showConfirmationAlert,
    defaultAddress,
    defaultLoader,
    loader,
  } = useAddressCard({ address_id: item.address_id })
  return (
    <TouchableOpacity onPress={() => navigate("CreateAddress", { address_id: item.address_id })} style={styles.flatlistView}>

      {isCard ?
        <CustomText fontSize={moderateScale(12)} text={`Default Address`} /> : <></>
      }

      <View style={styles.textView}>
        <CustomText fontSize={moderateScale(12)} text={`${item.address_one}, ${item.address_two}`} />
        <CustomText fontSize={moderateScale(12)} text={`${item.address_city}, ${item.address_province}`} />
        <CustomText fontSize={moderateScale(12)} text={`Postal Code: ${item.address_postal_code}`} />

        {isCard ? null :
          <TouchableOpacity onPress={() => !item.address_default_select && defaultAddress()} style={{ position: "absolute", top: -10, right: -3, height: verticalScale(40), aspectRatio: 1, borderRadius: 180, alignItems: "center", justifyContent: "center", backgroundColor: "white", ...shadow }}>
            {defaultLoader ?
              <ActivityIndicator color={colors.light_theme.theme} size={"small"} />
              : <Icon icon_type={"Fontisto"} name={item.address_default_select ? "checkbox-active" : "checkbox-passive"} color={"black"} size={moderateScale(20)} />
            }
          </TouchableOpacity>
        }


        {item.address_latitude && item.address_longitude ?
          <CustomText fontSize={moderateScale(12)} text={`Latitude: ${item.address_latitude}, Longitude: ${item.address_longitude}`} />
          : null
        }

        {isCard ? null :
          <TouchableOpacity onPress={showConfirmationAlert} style={{ position: "absolute", bottom: 0, right: -3, height: verticalScale(25), aspectRatio: 1, borderRadius: 180, alignItems: "center", justifyContent: "center", backgroundColor: "white", ...shadow }}>
            {loader ? <ActivityIndicator color={colors.light_theme.theme} size={"small"} /> :
              <Icon icon_type={"MaterialCommunityIcons"} name={"delete"} color={"red"} size={moderateScale(20)} />
            }
          </TouchableOpacity>
        }


      </View>
    </TouchableOpacity>
  );
};

export default AddressCard;

const styles = StyleSheet.create({
  flatlistView: {
    paddingVertical: verticalScale(15),
    marginBottom: verticalScale(10),
    paddingHorizontal: scale(15),
    backgroundColor: colors.light_theme.white,
    borderRadius: 10,
    ...shadow,
    backgroundColor: "white"
  },
  textView: {
    width: '100%',
  },
  descText: {
    fontSize: moderateScale(15),
    fontFamily: font.medium,
    color: "black",
    marginBottom: verticalScale(5),
  },
  cityText: {
    fontSize: moderateScale(14),
    fontFamily: font.regular,
    color: colors.light_theme.gray,
    marginBottom: verticalScale(5),
  },
  postalText: {
    fontSize: moderateScale(13),
    fontFamily: font.regular,
    color: colors.light_theme.gray,
    marginBottom: verticalScale(5),
  },
  defaultText: {
    fontSize: moderateScale(14),
    fontFamily: font.bold,
    color: colors.primary_theme,
    marginBottom: verticalScale(5),
  },
  coordsText: {
    fontSize: moderateScale(12),
    fontFamily: font.italic,
    color: colors.light_theme.gray,
  },
});
