import {useNavigation} from '@react-navigation/native';
import {useRef, useState} from 'react';
import {Animated, PanResponder} from 'react-native';
import {formatTimestampToTime} from '../../../utils/helper/helper';
import useReduxStore from '../../../utils/hooks/useReduxStore';

const useInboxCard = ({item, index}) => {
  const {getState} = useReduxStore();
  const {fetch_user_detail} = getState('auth');
  const [swiped, setSwiped] = useState(false);
  const translateX = useRef(new Animated.Value(0)).current;
  const actionTranslateX = useRef(new Animated.Value(200)).current; // Start off-screen

  // Background color animation based on swipe
  const backgroundColor = translateX.interpolate({
    inputRange: [-100, 0], // When swiped left, change color
    outputRange: ['#f1f6fa', '#fff'], // From light blue to original
    extrapolate: 'clamp',
  });

  const panResponder = PanResponder.create({
    onMoveShouldSetPanResponder: () => true,
    onPanResponderMove: (event, gestureState) => {
      let newTranslateX = gestureState.dx;

      if (newTranslateX < 0) {
        translateX.setValue(newTranslateX);
        actionTranslateX.setValue(Math.max(0, 250 + newTranslateX)); // Moves further out
      }
    },
    onPanResponderRelease: (e, {dx}) => {
      if (dx < -50) {
        // If swiped left enough
        Animated.parallel([
          Animated.timing(translateX, {
            toValue: -120, // Moves further left
            duration: 150,
            useNativeDriver: true,
          }),
          Animated.timing(actionTranslateX, {
            toValue: -20, // Makes actions more visible
            duration: 150,
            useNativeDriver: true,
          }),
        ]).start(() => setSwiped(true));
      } else {
        // Reset if not swiped enough
        Animated.parallel([
          Animated.timing(translateX, {
            toValue: 0,
            duration: 100,
            useNativeDriver: true,
          }),
          Animated.timing(actionTranslateX, {
            toValue: 250, // Hide actions again
            duration: 100,
            useNativeDriver: true,
          }),
        ]).start(() => setSwiped(false));
      }
    },
  });

  const navigation = useNavigation();

  const handlePressIn = () => {
    const data = {
      orderId: item?.order_id,
      vendorId: item?.shop_id,
      customerId: item?.customer_id,
      title: item?.shop_name,
      image: item?.order_image,
      orderTitle: item?.order_title,
    };
    navigation.navigate('Chat', data);
  };

  let messageTime = formatTimestampToTime(item?.last_message_time);

  return {
    translateX,
    actionTranslateX,
    backgroundColor,
    panResponder,
    navigation,
    handlePressIn,
    item,
    index,
    messageTime,
    fetch_user_detail,
  };
};

export default useInboxCard;
