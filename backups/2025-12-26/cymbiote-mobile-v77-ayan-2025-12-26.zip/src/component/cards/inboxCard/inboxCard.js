import React, {useState, useRef} from 'react';
import {
  Dimensions,
  View,
  StyleSheet,
  Animated,
  PanResponder,
  Text,
  TouchableOpacity,
} from 'react-native';
import CustomImage from '@materialComponent/image/image';
import CustomText from '@materialComponent/customText/customText';
import {colors, font} from '@constant/contstant';
import {margin} from '@constant/contstant';
import MarkAsUnreadSvg from '@assets/images/markAsUnread.svg';
import DeleteCart from '@assets/images/cart_delete.svg';
import useInboxCard from './useInboxCard';
import {moderateScale} from 'react-native-size-matters';

const {width, height, fontScale} = Dimensions.get('screen');

const InboxCard = ({item, index}) => {
  const [swiped, setSwiped] = useState(false);

  console.log('item ==>', item);

  const {
    actionTranslateX,
    backgroundColor,
    panResponder,
    translateX,
    handlePressIn,
    messageTime,
    fetch_user_detail,
  } = useInboxCard({item, index});

  const myMsg = fetch_user_detail?.id == item?.last_message_sender_id;

  return (
    <TouchableOpacity activeOpacity={1} onPress={handlePressIn}>
      <Animated.View
        style={[
          styles.container,
          {backgroundColor},
          index == 0 && {marginTop: 0, borderBottomWidth: 1, borderTopWidth: 1},
        ]}
        {...panResponder.panHandlers}>
        <Animated.View style={[styles.cardHeader, {transform: [{translateX}]}]}>
          <View style={[styles.cardHeader]}>
            <View style={styles.cardInfo}>
              <CustomImage
                style={styles.image}
                source={{uri: item?.order_image}}
              />
              <View>
                <CustomText
                  fontFamily={font.medium}
                  fontSize={moderateScale(12)}
                  text={item.shop_name + ` (${item?.order_title || ''}) `}
                />
                <CustomText
                  marginTop={height * 0.005}
                  fontSize={moderateScale(10)}
                  color={'#797C7B'}
                  text={`${myMsg ? 'You: ' : ''}${item.last_message}`}
                />
              </View>
            </View>
            <View style={styles.rightSection}>
              <CustomText
                fontSize={moderateScale(9)}
                color={'#797C7B'}
                text={messageTime}
              />
              {item?.unseen_for_customer && (
                <View style={styles.notificationBadge}>
                  <CustomText
                    fontSize={fontScale * 10}
                    color={'white'}
                    text={`${item?.unseen_for_customer}`}
                  />
                </View>
              )}
            </View>
          </View>
        </Animated.View>

        <Animated.View
          style={[
            styles.actionButtons,
            {transform: [{translateX: actionTranslateX}]},
          ]}>
          <TouchableOpacity
            style={[styles.actionButton, {backgroundColor: 'black'}]}>
            <MarkAsUnreadSvg width={width * 0.055} height={width * 0.055} />
          </TouchableOpacity>
          <TouchableOpacity style={[styles.actionButton]}>
            <DeleteCart width={width * 0.055} height={width * 0.055} />
          </TouchableOpacity>
        </Animated.View>
      </Animated.View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  container: {
    position: 'relative',
    overflow: 'hidden',
    marginTop: height * 0.005,
    paddingVertical: height * 0.02,
    backgroundColor: 'red',
    borderBottomWidth: 1,
    borderColor: '#f4f4f4',
    paddingHorizontal: margin.horizontal,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    // backgroundColor: 'white',
    borderRadius: 10,
  },
  cardInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    width: '80%',
  },
  image: {
    width: '15%',
    aspectRatio: 1,
    marginRight: '5%',
    borderRadius: 180,
  },
  rightSection: {
    width: '20%',
    alignItems: 'flex-end',
  },
  notificationBadge: {
    width: '28%',
    aspectRatio: 1,
    backgroundColor: colors.light_theme.theme,
    borderRadius: 180,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: height * 0.005,
  },
  actionButtons: {
    position: 'absolute',
    right: 0,
    top: '50%',
    transform: [{translateY: -10}],
    flexDirection: 'row',
    gap: 10,
  },
  actionButton: {
    backgroundColor: colors.light_theme.theme,
    borderRadius: 180,
    width: width * 0.1,
    aspectRatio: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  actionText: {
    color: 'white',
    fontSize: 16,
  },
});

export default InboxCard;
