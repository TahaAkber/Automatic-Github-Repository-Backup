import { moderateScale, verticalScale } from 'react-native-size-matters';
import CustomText from '@materialComponent/customText/customText';
import CustomImage from '@materialComponent/image/image';
import { Image, StyleSheet, View } from 'react-native';
import images from '@assets/images/images';
import { font } from '@constant/contstant';
import React from 'react';

const HomeProductSliderCard = () => {
  return (
    <View style={styles.brand_slider}>
      <CustomImage
        style={styles.brand_slider_image}
        source={images.t_shirt}
        size={'small'}
      />
      <CustomText
        marginTop={verticalScale(5)}
        fontSize={moderateScale(10)}
        fontFamily={font.medium}
        style={{ zIndex: 2 }}
        text={'Jack Beos'}
        numberOfLines={1}
        center
      />
    </View>
  );
};

export default HomeProductSliderCard;

const styles = StyleSheet.create({
  brand_slider: {
    marginRight: moderateScale(20),
    backgroundColor: 'white',
    zIndex: 1,
  },
  brand_slider_image: {
    borderTopRightRadius: moderateScale(10),
    borderTopLeftRadius: moderateScale(10),
    height: moderateScale(100),
    width: moderateScale(100),
  },
});
