import React, { useState } from 'react';
import { Animated, Dimensions, StyleSheet, TouchableOpacity, View } from 'react-native';
import CustomText from '@materialComponent/customText/customText';
import CustomImage from '@materialComponent/image/image';
import { font, globalStyle } from '@constant/contstant';
import Icon from '@materialComponent/icon/icon';
import RatingStars from '../../../materialComponent/ratingStars/ratingStars';
import { moderateScale } from 'react-native-size-matters';
import { formatDateTime } from '../../../utils/helper/helper';
import { colors } from '../../../constant/contstant';

const { width, height, fontScale } = Dimensions.get("screen");

const ProductReviewCard = ({ marginTop, item,  }) => {
    const [like, setLike] = useState(false)
    const [like2, setLike2] = useState(false)
    const scaleAnim = useState(new Animated.Value(1))[0];
    const scaleAnim2 = useState(new Animated.Value(1))[0];

    const handleLike = () => {
        setLike(prev => !prev);

        // Animate scaling effect
        Animated.sequence([
            Animated.spring(scaleAnim, { toValue: 1.1, useNativeDriver: true }),  // Enlarge
            Animated.spring(scaleAnim, { toValue: 1, useNativeDriver: true }),    // Return to normal
        ]).start();
    };

    const likeIconStyle = {
        transform: [{ scale: scaleAnim }],
    };

    const handleLike2 = () => {
        setLike2(prev => !prev);

        // Animate scaling effect
        Animated.sequence([
            Animated.spring(scaleAnim2, { toValue: 1.1, useNativeDriver: true }),  // Enlarge
            Animated.spring(scaleAnim2, { toValue: 1, useNativeDriver: true }),    // Return to normal
        ]).start();
    };

    const likeIconStyle2 = {
        transform: [{ scale: scaleAnim2 }],
    };

    return (
        <View style={{
            marginTop: marginTop || height * 0.02, padding: width * 0.03, borderRadius: 10,
            borderWidth: 1,
            borderColor: colors.light_theme.themeGray,
            borderStyle: "dashed",
            width: width * 0.9,
            marginRight: width * 0.04,
            paddingBottom: 5
        }}>
            <View style={styles.ratingContainer}>
                {/* {[...Array(5)].map((_, i) => (
                    <Icon key={i} icon_type="AntDesign" name="star" color="#FF7F00" style={styles.starIcon} size={fontScale * 18} />
                ))} */}
                <RatingStars setRating={() => console.log("")} size={moderateScale(22)} color={"#FF7F00"} rating={item.order_item_review_rating} />
            </View>
            <CustomText marginTop={height * 0.01} fontSize={fontScale * 13} text={item.order_item_review_comment} fontFamily={font.black} />
            <CustomText marginTop={height * 0.008} fontSize={fontScale * 10} text={formatDateTime(item.created_at)} fontFamily={font.light} />
            <View style={[globalStyle.space_between, styles.infoContainer]}>
                <View style={globalStyle.row}>
                    <CustomImage style={styles.profileImage} resizeMode={"contain"} size={"small"} source={{ uri: item?.user?.avatar }} />
                    <CustomText fontSize={fontScale * 11} fontFamily={font.medium} text={item?.user?.name} />
                </View>

                {/* <View style={globalStyle.row}>

                    <TouchableOpacity activeOpacity={1} onPress={handleLike}>
                        <Animated.View style={likeIconStyle}>
                            <View style={styles.likeDislikeContainer}>
                                <Icon icon_type="AntDesign" name={like ? "like1" : "like2"} style={styles.likeIcon} color={like ? "green" : "black"} size={fontScale * 15} />
                                <CustomText fontSize={fontScale * 12} text={"0"} />
                            </View>
                        </Animated.View>
                    </TouchableOpacity>
                    <TouchableOpacity activeOpacity={1} onPress={handleLike2}>
                        <Animated.View style={likeIconStyle2}>
                            <View style={styles.likeDislikeContainer}>
                                <Icon icon_type="AntDesign" name={like2 ? "dislike1" : "dislike2"} style={styles.dislikeIcon} color={"black"} size={fontScale * 15} />
                                <CustomText fontSize={fontScale * 12} text={"0"} />
                            </View>
                        </Animated.View>
                    </TouchableOpacity>
                </View> */}
            </View>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        marginTop: height * 0.02,
    },
    ratingContainer: {
        flexDirection: "row",
    },
    starIcon: {
        marginRight: 5,
    },
    infoContainer: {
        marginTop: height * 0.02,
    },
    profileImage: {
        marginRight: width * 0.02,
        width: width * 0.07,
        aspectRatio: 1,
        borderRadius: 180,
    },
    likeDislikeContainer: {
        borderWidth: 1,
        padding: height * 0.008,
        borderRadius: 5,
        borderColor: "#E4E9EE",
        marginRight: 5,
        flexDirection: "row",
        alignItems: "center",
    },
    likeIcon: {
        marginRight: 5,
    },
    dislikeIcon: {
        marginRight: 5,
    },
});

export default ProductReviewCard;
