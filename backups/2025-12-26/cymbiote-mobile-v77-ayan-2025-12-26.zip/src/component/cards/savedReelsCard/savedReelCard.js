import React from 'react';
import {StyleSheet, View, Dimensions, TouchableOpacity} from 'react-native';
import CustomImage from '@materialComponent/image/image';
import {navigate} from '../../../utils/navigationRef/navigationRef';
import FastImage from 'react-native-fast-image';
import CustomText from '../../../materialComponent/customText/customText';
import {Icon} from 'react-native-paper';
import Overlay from '../../../materialComponent/overlay/overlay';

const {width} = Dimensions.get('screen');
const CARD_WIDTH = width / 2 - 20;
const LOGO_SIZE = CARD_WIDTH * 0.23;

const SavedReelCard = ({item, shop}) => {
  return (
    <TouchableOpacity
      onPress={() =>
        navigate('ReelsScreen', {
          videoId: item.video_url_id,
        })
      }
      activeOpacity={0.85}>
      <View style={styles.card}>
        <CustomImage
          source={{uri: item?.video_thumbnail_url}}
          style={styles.image}
          resizeMode="cover"
        />
        {/* <View style={{flex: 1, position: 'relative'}}> */}
        <Overlay reverseGradient={false} />
        {/* </View> */}
        {/* Bottom Overlay Row */}
        <View style={styles.overlayRow}>
          {/* Brand Info */}
          <View style={styles.brandPill}>
            <FastImage
              source={{uri: item?.shop_logo_url}}
              style={styles.brandLogo}
            />
            <View style={{flex: 1}}>
              <CustomText
                text={item?.shop_name}
                fontSize={10}
                numberOfLines={1}
                color="#ffff"
                style={{fontWeight: '700'}}
              />
              <View
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  // marginTop: 1,
                }}>
                <CustomText
                  text={item?.rating?.toFixed(1) || '4.6'}
                  fontSize={9}
                  color="#fff"
                />
                <Icon
                  icon_type="MaterialIcons"
                  name="star"
                  size={10}
                  color="#fff"
                />

                <CustomText
                  text={`(${item?.total_reviews || '865'})`}
                  fontSize={8}
                  color="#fff"
                />
              </View>
            </View>
          </View>
          {/* Badge/Action (e.g. product) */}
          <View style={styles.badgeContainer}>
            <CustomImage
              source={{uri: item?.product_image_url}}
              style={styles.badgeImage}
            />
          </View>
        </View>
      </View>
    </TouchableOpacity>
  );
};

export default SavedReelCard;

const styles = StyleSheet.create({
  card: {
    width: CARD_WIDTH,
    aspectRatio: 0.74,
    borderRadius: 10,
    margin: 5,
    overflow: 'hidden',
    backgroundColor: '#fff',
    // elevation: 1,
  },
  image: {
    width: '100%',
    height: '100%',
    // elevation: 2,
  },
  overlayRow: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    paddingHorizontal: 4,
    paddingBottom: 4,
    flexDirection: 'row',
    justifyContent: 'space-between',
    // alignItems: 'flex-end',
  },
  brandPill: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'transparent',
    // paddingVertical: 2,
    // borderRadius: 16,
    minWidth: CARD_WIDTH * 0.65,
    // elevation: 1,
  },
  brandLogo: {
    width: LOGO_SIZE,
    height: LOGO_SIZE,
    borderRadius: 180,
    marginRight: 3,
    marginLeft: 2,
    borderWidth: 1,
    borderColor: '#F4F4F4',
    // backgroundColor: '#eee',
  },
  badgeContainer: {
    borderRadius: 6,
    padding: 3,
    justifyContent: 'center',
    alignItems: 'center',

    // elevation: 2,
  },
  badgeImage: {
    width: LOGO_SIZE * 0.99,
    height: LOGO_SIZE * 0.99,
    borderRadius: 7,
    // backgroundColor: '#fff',
  },
});
