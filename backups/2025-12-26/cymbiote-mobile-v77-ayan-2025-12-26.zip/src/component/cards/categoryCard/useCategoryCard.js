import React, { useRef, useState } from 'react';
import { View, StyleSheet, Dimensions, Animated } from 'react-native';
import CustomImage from '@materialComponent/image/image';
import CustomText from '@materialComponent/customText/customText';
import CartButton from '@materialComponent/customButton/cartButton';
import { font, shadow, colors } from '@constant/contstant';
import SingleCard from '../singleCard/singleCard';

const { width, height, fontScale } = Dimensions.get('window');

const useCategoryCard = ({ data }) => {
    const animatedValue = useRef(new Animated.Value(0)).current;
    const carouselRef = useRef(null);
    const [currentIndex, setCurrentIndex] = useState(0)

    const animatedStyle = (index) => {
        const scale = animatedValue.interpolate({
            inputRange: [index - 1, index, index + 1],
            outputRange: [0.9, 1.1, 0.9], // Scale effect
            extrapolate: 'clamp',
        });

        const translateY = animatedValue.interpolate({
            inputRange: [index - 1, index, index + 1],
            outputRange: [8, -8, 8], // Reduce elevation effect
            extrapolate: 'clamp',
        });

        const animatedShadowOpacity = animatedValue.interpolate({
            inputRange: [index - 1, index, index + 1],
            outputRange: [0, 0.3, 0], // Shadow effect
            extrapolate: 'clamp',
        });

        const animatedShadowRadius = animatedValue.interpolate({
            inputRange: [index - 1, index, index + 1],
            outputRange: [0, 6, 0], // Shadow radius effect
            extrapolate: 'clamp',
        });

        const elevation = animatedValue.interpolate({
            inputRange: [index - 1, index, index + 1],
            outputRange: [0, 3, 0],
            extrapolate: 'clamp',
        });

        return {
            transform: [{ scale }, { translateY }],
            shadowColor: '#000',
            shadowOpacity: animatedShadowOpacity,
            shadowRadius: animatedShadowRadius,
            shadowOffset: {
                width: 0,
                height: animatedShadowRadius, // Dynamically linked to shadowRadius
            },
            elevation, // Android elevation
        };
    };


    const renderItem = ({ item, index }) => {
        return (
            <SingleCard
                image={item.product_image_url}
                product_description={item.product_description}
                product_name={item.product_name}
                product={item}
                key={index}
                style={[animatedStyle(index, index == currentIndex), { width: width * 0.45 }]}
                variant_id={item?.product_variant[0]?.variant_id}
                shop_id={item.product_shop_id}
                current_variant={item?.product_variant[0]}
                textContainerStyle={{ width: width * 0.4 }}
                headingFontSize={fontScale * 10}
                descFontSize={fontScale * 8}
                imageStyle={{ width: width * 0.3, borderRadius: 5, alignSelf : "center" }}
            // style={{ width: width * 0.55, borderRadius: 20 }}
            />


        )
    };

    //     <SingleCard
    //     textContainerStyle={{ width: width * 0.4 }}
    //     headingFontSize={fontScale * 12}
    //     descFontSize={fontScale * 8}
    //     imageStyle={{ width: width * 0.4, borderRadius: 5 }}
    //     style={{ width: width * 0.55, borderRadius: 20 }}
    //     image={getCurrentProduct?.product_image_url}
    //     product_description={getCurrentProduct?.product_description}
    //     product_name={getCurrentProduct?.product_name}
    //     key={500}
    //     variant_id={getCurrentProductVariantId}
    //     shop_id={item.shop_id}
    //     current_variant={getCurrentVariant}
    //     product={getCurrentProduct}
    // />

    return {
        renderItem,
        animatedValue,
        setCurrentIndex,
        carouselRef
    }
};

export default useCategoryCard;

const styles = StyleSheet.create({
    cardWrapper: {
        width: width * 0.45,
        alignItems: 'center',
        paddingVertical: height * 0.01,
        borderRadius: 20,
        marginRight: 15,
        ...shadow,
        backgroundColor: "white",
        borderWidth: 1,
        borderColor: colors.light_theme.borderColor,
    },
    image: {
        width: width * 0.40,
        aspectRatio: 1,
        backgroundColor: '#e7ecf2',
        borderRadius: 18,
    },
    textContainer: {
        width: width * 0.40,
        alignItems: 'center',
    },
});
