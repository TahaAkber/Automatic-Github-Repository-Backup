import React, { useRef, useState } from 'react';
import { View, StyleSheet, Dimensions, Animated, TouchableOpacity } from 'react-native';
import Carousel from 'react-native-snap-carousel';
import { shadow } from '@constant/contstant';
import { colors } from '@constant/contstant';
import useCategoryCard from './useCategoryCard';
import ShopTileCategories from '../../shopTIleCategories/shopTIleCategories';
import { WH } from '../../../constant/contstant';
import { moderateScale } from 'react-native-size-matters';
import Icon from '../../../materialComponent/icon/icon';

const { width, height, fontScale } = Dimensions.get('window');

const CategoryCard = ({ data, item }) => {
    const { renderItem, animatedValue, setCurrentIndex, carouselRef } = useCategoryCard({ data })

    return (
        <View style={{ zIndex: 1 }}>
         
            <View>
                <TouchableOpacity
                    onPress={() => carouselRef.current.snapToNext()}
                    style={[styles.arrowButton, { top: height * 0.12, right: 10 }]}
                >
                    <Icon icon_type="MaterialIcons" name={"keyboard-arrow-right"} color="white" size={moderateScale(22)} />
                </TouchableOpacity>
                <Carousel
                    ref={carouselRef}
                    data={data}
                    renderItem={renderItem}
                    sliderWidth={width}
                    itemWidth={width * 0.48}
                    onScroll={Animated.event(
                        [{ nativeEvent: { contentOffset: { x: animatedValue } } }],
                        {
                            useNativeDriver: false,
                            listener: (event) => {
                                const scrollPosition = event.nativeEvent.contentOffset.x / (width * 0.48);
                                animatedValue.setValue(scrollPosition); // Update animated value
                            },
                        }
                    )}
                    inactiveSlideScale={width * 0.2}
                    inactiveSlideOpacity={1}
                    contentContainerCustomStyle={styles.container}
                    loop={false}
                    autoplay={false}
                    onSnapToItem={(index) => {
                        setCurrentIndex(index);
                    }}
                />
                <TouchableOpacity
                    onPress={() => carouselRef.current.snapToPrev()}
                    style={[styles.arrowButton, { top: height * 0.12, left: 10 }]}
                >
                    <Icon icon_type="MaterialIcons" name={"keyboard-arrow-left"} color="white" size={moderateScale(22)} />
                </TouchableOpacity>
            </View>
        </View>
    );
};

export default CategoryCard;

const styles = StyleSheet.create({
    container: {
        alignItems: 'center',
        paddingVertical: 10,
        marginTop: height * 0.02,
    },
    arrowButton: {
        width: WH.width(8),
        aspectRatio: 1,
        backgroundColor: 'rgba(0, 0, 0, 0.6)',
        borderRadius: 180,
        justifyContent: 'center',
        alignItems: 'center',
        marginVertical: height * 0.01,
        position: "absolute",
        top: 10,
        zIndex: 2
    }
});
