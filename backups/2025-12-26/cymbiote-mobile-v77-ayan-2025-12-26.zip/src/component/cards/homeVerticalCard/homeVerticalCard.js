import React from 'react';
import { View, Dimensions, TouchableOpacity } from 'react-native';
import CustomImage from '@materialComponent/image/image';
import Icon from '@materialComponent/icon/icon';
import CustomText from '@materialComponent/customText/customText';
import VerticalProducts from './verticalProducts';
import { font, globalStyle, shadow, WH } from '@constant/contstant';
import { currency } from '@constant/signature';
import useVerticalCard from './useVerticalCard';
import ColorProducts from './colorProducts';
import LCSCard from '../../lcsCard/lcsCard';
import ImageSlider from '../../imageCarousel/imageCarousel';
import CustomCarousel from '../../../materialComponent/customCarousel/customCarousel';
import { navigate } from '../../../utils/navigationRef/navigationRef';
import { defaultShopImages } from '../../../utils/helper/helper';
import useImageHeight from '../../../utils/hooks/useImageHeight';

const { height, width, fontScale } = Dimensions.get('window');

const VerticalCarousel = ({ data, horizontal, item }) => {
    const {
        currentIndex,
        setCurrentIndex,
        carouselRef,
        loadMoreData,
        renderItem,
        colorCode,
        variant,
        setVariant,
        getCurrentProduct,
        getCurrentProductVariant,
        getCurrentProductVariantColors,
        getColors,
        images,
        findIndex,
        setVaraintItem
    } = useVerticalCard({ data });

    const { height } = useImageHeight(defaultShopImages(getCurrentProduct)?.[0])

    const showImage = images

    return (
        <View>
            <View
                style={horizontal ? {
                    justifyContent: "center",
                    alignSelf: "center",
                    alignItems: "center",
                    marginBottom: height * 0.01
                } : {
                    position: "absolute",
                    bottom: height * 0.15,
                    left: 0,
                    // flexDirection: "row",
                }}>
                <View style={horizontal && {
                    justifyContent: "center",
                    alignSelf: "center",
                    alignItems: "center",
                }}>
                    {horizontal &&
                        <CustomImage
                            style={{ width: width * 0.4, height: width * 0.1, backgroundColor: "rgba(0,0,0,0)", marginBottom: !data.length ? height * 0.28 : height * 0.02 }}
                            source={{
                                uri: item?.shop_banner_logo_url,
                            }}
                        />
                    }

                    {data.length > 0 ?
                        <>
                            <TouchableOpacity style={{ position: "absolute", flex: 1, bottom: "100%" }} activeOpacity={1} onPress={() => navigate("ProductDetail", { product_id: getCurrentProduct?.product_id, shop_id: getCurrentProduct?.product_shop_id, default_images: defaultShopImages(getCurrentProduct), height })}>
                                <View style={
                                    {
                                        width: horizontal ? width * 0.3 : width * 0.4,
                                        aspectRatio: 1,
                                        borderRadius: 10,
                                        // backgroundColor: "white",
                                        ...shadow,
                                    }
                                }>
                                    <ImageSlider
                                        stylePagination={{ bottom: 5 }}
                                        dotStyle={{ width: width * 0.02, ...shadow }}
                                        style={{ marginVertical: 0 }}
                                        imageRadius={10}
                                        customHeight={horizontal ? width * 0.3 : width * 0.4}
                                        customWidth={horizontal ? width * 0.3 : width * 0.4}
                                        images={showImage}
                                        activeIndex={findIndex}
                                        onPress={setVaraintItem}
                                    />
                                </View>

                                {/* </TouchableOpacity> */}
                                <View style={{ width: horizontal ? width * 0.3 : width * 0.4, marginTop: height * 0.01 }}>
                                    <ColorProducts getColors={getColors} colorCode={colorCode} setVariant={setVariant} variant={variant} horizontal={horizontal} data={getCurrentProduct} currentIndex={currentIndex} setCurrentIndex={setCurrentIndex} />
                                    <View style={{ width: width * 0.3, alignSelf: "center" }}>
                                        <CustomText numberOfLines={2} color="white" fontSize={fontScale * 12} fontFamily={font.medium} center text={getCurrentProduct?.product_name} />
                                    </View>
                                    <CustomText
                                        marginTop={height * 0.002}
                                        color="white"
                                        fontFamily={font.bold}
                                        fontSize={fontScale * 11}
                                        center
                                        text={`${getCurrentProduct?.product_currency || currency} ${getCurrentProduct?.product_variant?.[0]?.variant_price}`}
                                    />
                                    {/* <View style={[globalStyle.row, { justifyContent: "center", marginTop: height * 0.002 }]}>
                                        <CustomText
                                            style={{ marginRight: width * 0.01 }}
                                            marginTop={height * 0.002}
                                            color="white"
                                            fontFamily={font.light}
                                            fontSize={fontScale * 10}
                                            center
                                            text="4.7"
                                        />
                                        <View style={globalStyle.row}>
                                            {[...Array(5)].map((_, i) => (
                                                <Icon key={i} icon_type="Entypo" name="star" color="orange" size={fontScale * 10} />
                                            ))}
                                        </View>
                                    </View> */}
                                </View>
                            </TouchableOpacity>
                        </> : <></>
                    }

                </View>

            </View>
            {data.length ?
                <>
                    <LCSCard key={currentIndex} iconContainerStyle={{ marginBottom: height * 0.02 }} containerStyle={{ bottom: height * 0.04, }} product_id={getCurrentProduct?.product_id} horizontal={horizontal} data={data} />
                    <VerticalProducts horizontal={horizontal} data={data} currentIndex={currentIndex} setCurrentIndex={setCurrentIndex} />
                    {/* <CustomCarousel /> */}
                </>
                : <></>
            }

        </View>
    );
};

export default VerticalCarousel;
