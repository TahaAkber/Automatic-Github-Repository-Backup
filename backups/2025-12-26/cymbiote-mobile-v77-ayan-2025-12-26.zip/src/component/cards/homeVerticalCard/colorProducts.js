import React, { useCallback, useEffect, useRef, useState } from 'react';
import { View, StyleSheet, Dimensions, TouchableOpacity, ActivityIndicator, FlatList } from 'react-native';
import Icon from '@materialComponent/icon/icon';

const { height, width, fontScale } = Dimensions.get('window');

const ColorProducts = ({ data, horizontal, setVariant, variant, colorCode, getColors }) => {
    const [carouselData, setCarouselData] = useState(colorCode); // Start with initial data
    const [isLoading, setIsLoading] = useState(false);
    const flatListRef = useRef(null);

    const loadMoreData = () => {
        if (!isLoading && carouselData.length < data.length) {
            setIsLoading(true);
            setTimeout(() => {
                const newData = data.slice(carouselData.length, carouselData.length + 5);
                setCarouselData([...carouselData, ...newData]);
                setIsLoading(false);
            }, 1500);
        }
    };

    const renderItem = useCallback(({ item, index }) => {
        const isColor = item?.name?.includes("Color") || item?.name?.includes("color")
        return isColor && (
            <TouchableOpacity
                onPress={() => setVariant(item.variant_id)} // Set active index on item click
                style={{
                    height: height * 0.02,
                    justifyContent: "center",
                    alignItems: "center",
                }}
            >
                <View
                    style={[
                        styles.carouselItem,
                        { backgroundColor: item.value, zIndex: 1 },
                        variant === item.variant_id && {
                            borderWidth: 1,
                            borderColor: "white",
                            // backgroundColor: "rgba(0,0,0,0)", // Make the center transparent
                            justifyContent: "center",
                            alignItems: "center",
                        }, // Highlight active item
                    ]}
                >
                    {/* Inner circle for radio button effect */}
                    {variant === item.variant_id && (
                        <View
                            style={{
                                width: width * 0.02,
                                height: width * 0.02,
                                backgroundColor: item,
                                borderRadius: width * 0.01, // Make it circular
                            }}
                        />
                    )}
                </View>
            </TouchableOpacity>
        );
    }, [variant]);



    const scrollToIndex = (index) => {
        flatListRef.current?.scrollToIndex({
            index,
            animated: true,
            viewPosition: 0.5, // Center the selected item
        });
    };
    

    useEffect(() => {
        if ((getColors?.values || []).length) {
            setVariant(getColors?.values?.[0]?.variant_id)
        }
    }, [])

    useEffect(() => {
        if (variant) {
            const currentIndex = getColors?.values?.findIndex(v => v.variant_id === variant);
            if (currentIndex !== -1) {
                scrollToIndex(currentIndex);
            }
        }
    }, [variant]);

    return (getColors?.values || []).length > 0 ? (
        <View style={styles.container}>
            {/* Left Arrow */}
            <TouchableOpacity
                onPress={() => {
                    const currentIndex = getColors?.values.findIndex(v => v.variant_id === variant);
                    if (currentIndex > 0) { // Ensure we are not at the first item
                        const newVariantId = getColors?.values[currentIndex - 1]?.variant_id;
                        setVariant(newVariantId);
                        scrollToIndex(currentIndex - 1); // Scroll to the previous item
                    }
                }}

                style={styles.arrowButton}
            >
                <Icon
                    icon_type="MaterialIcons"
                    name="keyboard-arrow-left"
                    color="black"
                    size={fontScale * 10}
                />
            </TouchableOpacity>

            {/* FlatList */}
            <View style={[styles.carouselContainer, { width: horizontal ? width * 0.14 : width * 0.23, }]}>
                <FlatList
                    ref={flatListRef}
                    data={getColors?.values}
                    renderItem={renderItem}
                    keyExtractor={(item, index) => index.toString()}
                    horizontal
                    showsHorizontalScrollIndicator={false}
                    onEndReached={loadMoreData}
                    onEndReachedThreshold={0.5}
                    contentContainerStyle={[styles.carouselContent]}
                    extraData={variant} // Ye ensure karega ke list re-render ho
                />
            </View>

            {/* Loader */}
            {isLoading && (
                <ActivityIndicator size="small" color="#3498db" style={styles.loader} />
            )}

            {/* Right Arrow */}
            <TouchableOpacity
                onPress={() => {
                    const currentIndex = getColors?.values.findIndex(v => v.variant_id === variant);
                    if (currentIndex !== -1 && currentIndex < getColors?.values.length - 1) {
                        const newVariantId = getColors?.values[currentIndex + 1]?.variant_id;
                        setVariant(newVariantId);
                        scrollToIndex(currentIndex + 1); // Scroll to the next item
                    }
                }}

                style={styles.arrowButton}
            >
                <Icon
                    icon_type="MaterialIcons"
                    name="keyboard-arrow-right"
                    color="black"
                    size={fontScale * 10}
                />
            </TouchableOpacity>
        </View>
    ) : <></>;
};

export default ColorProducts;

const styles = StyleSheet.create({
    container: {
        justifyContent: 'center',
        alignItems: 'center',
        flexDirection: 'row',
        alignSelf: 'center',
        borderWidth: 1, borderColor: "white",
        paddingVertical: 3,
        borderRadius: 180
    },
    carouselItem: {
        width: width * 0.04,
        aspectRatio: 1,
        borderRadius: 180,
        marginRight: 10,
        justifyContent: "center",
        alignItems: "center",
    },
    arrowButton: {
        width: width * 0.04,
        aspectRatio: 1,
        backgroundColor: '#D9D9D9',
        borderRadius: 180,
        justifyContent: 'center',
        alignItems: 'center',
        marginHorizontal: width * 0.02,
    },
    carouselContainer: {
        paddingTop: height * 0.002,

    },
    carouselContent: {
        alignItems: 'center',
        justifyContent: "center",
    },
    loader: {
        marginVertical: 10,
    },
});
