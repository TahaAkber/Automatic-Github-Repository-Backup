import {Dimensions, StyleSheet, View, TouchableOpacity} from 'react-native';
import React, {useState} from 'react';
import {navigate} from '@utils/navigationRef/navigationRef';
import CustomProgressIndicator from '@materialComponent/customProgressIndicator/customProgressIndicator';
import CustomText from '@materialComponent/customText/customText';
import CustomButton from '@materialComponent/customButton/customButton';
import BottomSheetOrderCancellation from '@materialComponent/bottomSheet/bottomSheetOrderCancellation';
import useOrderHistoryCard from './useOrderHistoryCard';
import CustomImage from '../../../materialComponent/image/image';
import useReduxStore from '../../../utils/hooks/useReduxStore';
import {CANCEL_ORDER} from '../../../redux/types/orders/orders';
import {font} from '../../../constant/contstant';
import BottomSheetProductReview from '../../../materialComponent/bottomSheet/bottomSheetProductReview';

const {height, fontScale, width} = Dimensions.get('screen');

const OrderHistoryCard = ({item, onReviewSubmitted, isBordered, tabId}) => {
  console.log('item', item);
  const {
    refReviewFormSheet,
    getIndexStatus,
    refRBSheet,
    selectedOrderProductId,
    openSheet,
    openReviewSheet,
    openReviewForm,
    refReviewSheet,
    selectedOrderProduct,
    refConfirmationSheet,
  } = useOrderHistoryCard({item});
  const {getState, dispatch} = useReduxStore();
  const isOrderCancelled = item?.order_cancelled_by;
  const currentStatus = item?.status
    ? item?.status?.toUpperCase()
    : item?.tracking_status
    ? item?.tracking_status?.toUpperCase()
    : '';

  console.log('item.order_cancelled_by', isOrderCancelled);

  // ✅ Define valid statuses for the progress bar and cancellation rules
  const statusMap = {
    IN_PROGRESS: {label: 'In Progress', color: '#2E7DC1', theme: '#2E7DC1'},
    OUT_FOR_DELIVERY: {label: 'Shipped', color: '#FCB914', theme: '#FCB914'},
    IN_TRANSIT: {label: 'In Transit', color: '#F57F21', theme: '#F57F21'},
    INTRANSIT: {label: 'In Transit', color: '#F57F21', theme: '#F57F21'},
    CONFIRMED: {label: 'Delivered', color: '#23B477', theme: '#23B477'},
    DELIVERED: {label: 'Delivered', color: '#23B477', theme: '#23B477'},
    DELAYED: {label: 'Delayed', color: 'black', theme: 'black'},
    LABEL_PRINTED: {label: 'Label Printed', color: '#A0A0A0', theme: 'black'},
    LABEL_PURCHASED: {label: 'Label Purchased', color: 'black', theme: 'black'},
    READY_FOR_PICKUP: {label: 'Pickup', color: 'black', theme: 'black'},
    FAILURE: {label: 'Failed', color: 'black', theme: 'black'},
  };
  // console.log(@)
  // const statusInfo = statusMap[currentStatus] || null;
  const statusInfo = isOrderCancelled
    ? {label: 'Cancelled', theme: '#EE1F23'} // your red color here
    : statusMap[currentStatus] || null;

  const pinOrder = item.pin_delivered_recent;
  const showProgressBar = item.tracking_status || item.status || null;

  console.log('showProgressBar', item);
  const progressStep = Object.keys(statusMap).indexOf(currentStatus) + 1;

  const image =
    item?.product_detail?.variant?.images?.length > 0
      ? item?.product_detail?.variant.images[0]?.preview?.image?.url
      : item?.product_detail?.product?.product_image_url ||
        item?.image_url ||
        null;

  const updateOrderStatus = orderShopifyId => {
    dispatch({
      type: CANCEL_ORDER,
      payload: {shopify_order_id: orderShopifyId},
    });
    setIsCancelled(true);
  };

  const handleNavigation = () => {
    navigate('OrderDetail', {
      order_id: item?.order_id,
      tracking_id: item?.id || false,
      table_id: item?.table_id || false,
    });
  };

  const handleTrackingNavigation = () => {
    navigate('TrackingDetail', {
      custom_tracking_id: item?.manual_tracking_id,
    });
  };

  const isTracking = item?.type == 'tracking';

  console.log('isTracking', isTracking);

  return (item.order_item || []).length > 0 ||
    item?.item_count > 0 ||
    isTracking ? (
    <TouchableOpacity
      key={item.order_id}
      activeOpacity={1}
      onPress={isTracking ? handleTrackingNavigation : handleNavigation}
      style={[
        styles.container,
        isBordered && styles.borderedContainer,
        showProgressBar == 'DELIVERED' ||
          (showProgressBar && {height: height * 0.14}),
      ]}>
      <View>
        {((item.order_item || []).length > 0 ||
          item?.item_count > 0 ||
          isTracking) && (
          <View
            style={{
              flexDirection: 'row',
              // alignItems: 'center',
              justifyContent: 'space-between',
            }}>
            <CustomImage
              style={{
                width:
                  !isTracking && showProgressBar != 'DELIVERED' && pinOrder
                    ? '23%'
                    : '15%',
                aspectRatio: 1,
                borderRadius: 5,
                backgroundColor: '#f2efee',
              }}
              source={{
                uri: isTracking ? item?.manual_courier_image_url : image,
              }}
            />
            <View
              style={{
                marginLeft:
                  !isTracking && showProgressBar
                    ? height * 0.02
                    : height * 0.01,
                // justifyContent: 'space-evenly',
                width:
                  !isTracking && showProgressBar ? width * 0.4 : width * 0.42,
              }}>
              <View style={{marginTop: 0}}>
                <CustomText
                  fontSize={fontScale * 13}
                  fontFamily={font.bold}
                  text={
                    isTracking
                      ? `${item?.manual_tracking_name}`
                      : `Order ${item.order_title || item?.order_id_display}`
                  }
                  numberOfLines={1}
                />
                <CustomText
                  color={'#808080'}
                  fontSize={fontScale * 11}
                  numberOfLines={1}
                  text={
                    isTracking
                      ? `TN:${item?.manual_tracking_number} | ${item?.manual_tracking_status}`
                      : `${item?.shop_name} | ${
                          item?.order_item?.length || item?.item_count
                        } | ${item?.shop_currency || item?.currency} ${
                          item?.order_total_amount || item?.total_amount
                        }`
                  }
                />
              </View>
              <View
                style={{
                  width: '120%',
                  marginTop: showProgressBar && height * 0.01,
                  marginLeft: showProgressBar && height * 0.01,
                }}>
                {showProgressBar && statusInfo?.label != 'Delivered' && (
                  <CustomProgressIndicator currentStep={progressStep} />
                )}
              </View>
            </View>

            {/* Status Button (Cancelled, Shipped, etc.) */}
            <View style={{width: '25%', alignSelf: 'flex-start'}}>
              {
                isTracking ? (
                  <></>
                ) : isOrderCancelled ? (
                  <CustomButton
                    text="Cancelled"
                    disabledOpacity={1}
                    backgroundColor={'#EE1F23'}
                    disabled
                    borderRadius={5}
                    textStyle={{fontSize: fontScale * 10, color: 'white'}}
                    forceHeight={height * 0.03}
                  />
                ) : statusInfo?.label === 'Delivered' &&
                  item.order_item.some(
                    orderItem => !orderItem.review_completed,
                  ) ? (
                  // Show "Give Review" button if the order is delivered and any review is incomplete
                  item?.social_order ? (
                    <></>
                  ) : (
                    <CustomButton
                      text="Give Review"
                      onPress={() => openReviewSheet(item.order_item)}
                      disabledOpacity={1}
                      backgroundColor={'#375DFB'}
                      borderRadius={5}
                      buttonStyle={{height: height * 0.03}}
                      textStyle={{fontSize: fontScale * 10, color: 'white'}}
                      forceHeight={height * 0.03}
                    />
                  )
                ) : statusInfo ? (
                  // Show status button if no reviews are incomplete
                  <CustomButton
                    text={statusInfo.label}
                    backgroundColor={statusInfo.color}
                    disabled
                    borderRadius={5}
                    buttonStyle={{height: height * 0.03}}
                    textStyle={{fontSize: fontScale * 10, color: 'white'}}
                    disabledOpacity={1}
                    forceHeight={height * 0.03}
                  />
                ) : item?.social_order ? (
                  <></>
                ) : (
                  (!item?.order_fulfillment_status ||
                    item?.order_fulfillment_status === 'pending') && (
                    <CustomButton
                      onPress={() => openSheet(item)}
                      text={'Cancel Order'}
                      textStyle={{fontSize: fontScale * 10, color: 'black'}}
                      buttonStyle={{height: height * 0.03}}
                      backgroundColor={'#E5E5E5'}
                      borderRadius={5}
                      forceHeight={height * 0.03}
                    />
                  )
                )

                // Show "Cancel Order" button for eligible statuses
              }
              {item?.social_order ? (
                <CustomText
                  fontSize={fontScale * 8}
                  style={{marginTop: height * 0.005, color: 'red'}}
                  center
                  text={'* Not from cercle'}
                />
              ) : (
                <></>
              )}
            </View>
            {/* <View style={{width: '25%', alignSelf: 'flex-start'}}>
                <CustomButton
                  text="Testing Btn"
                  onPress={() => openReviewSheet(item.order_item)}
                  disabledOpacity={1}
                  backgroundColor={'#375DFB'}
                  borderRadius={5}
                  buttonStyle={{height: height * 0.03}}
                  textStyle={{fontSize: fontScale * 10, color: 'white'}}
                />
              </View> */}
          </View>
        )}
      </View>

      {/* Bottom Sheet for Cancellation */}
      <BottomSheetOrderCancellation
        refRBSheet={refRBSheet}
        refConfirmationSheet={refConfirmationSheet}
        selectedOrder={item}
        updateOrderStatus={updateOrderStatus}
        tabId={tabId}
      />

      <BottomSheetProductReview
        selectedOrderProduct={selectedOrderProduct}
        refReviewSheet={refReviewSheet}
        refReviewFormSheet={refReviewFormSheet}
        selectedOrder={item}
        openReviewForm={openReviewForm}
        selectedOrderProductId={selectedOrderProductId}
      />
    </TouchableOpacity>
  ) : (
    <></>
  );
};

export default OrderHistoryCard;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
    paddingHorizontal: height * 0.01,
    paddingVertical: height * 0.01,
    borderRadius: 10,
    // borderWidth: 1,
  },

  borderedContainer: {
    borderWidth: 1,
    borderColor: '#efefef',
    marginVertical: 5,
  },
});
