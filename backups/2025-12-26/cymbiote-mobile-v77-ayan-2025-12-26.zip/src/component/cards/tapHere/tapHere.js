import React from 'react';
import { Dimensions, StyleSheet, View, Text } from 'react-native';
import TruckSvg from '@assets/images/truck.svg';
import { colors, font } from '@constant/contstant';

const { fontScale, height, width } = Dimensions.get('screen');

const TabHere = () => {
    return (
        <View style={styles.container}>
            <View style={styles.iconContainer}>
                <TruckSvg width={width * 0.06} height={width * 0.06} />
            </View>
            <View style={styles.textContainer}>
                <Text style={styles.text}>
                    20 Dec - 25 Dec! Your order has been delivered, we hope you like it!{' '}
                    <Text style={styles.link}>Tap here to track your order.</Text>
                </Text>
            </View>
        </View>
    );
};

export default TabHere;

const styles = StyleSheet.create({
    container: {
        borderWidth: 1,
        borderColor: '# ',
        flexDirection: 'row',
        alignItems: 'center',
        width: '100%',
        paddingVertical: height * 0.01,
        borderRadius: 10,
    },
    iconContainer: {
        width: '15%',
        justifyContent: 'center',
        alignItems: 'center',
    },
    textContainer: {
        width: '85%',
        // flexWrap: 'wrap',
    },
    text: {
        fontSize: fontScale * 10,
        color: 'black',
        fontFamily: font.regular,
    },
    link: {
        fontSize: fontScale * 10,
        color: colors.light_theme.theme,
        fontFamily: font.medium,
        textDecorationLine: 'underline',
    },
});
