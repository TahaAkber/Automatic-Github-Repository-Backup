import { font, fontSizes, globalStyle, shadow } from '@constant/contstant';
import { moderateScale, verticalScale } from 'react-native-size-matters';
import CustomText from '@materialComponent/customText/customText';
import CustomImage from '@materialComponent/image/image';
import Icon from '@materialComponent/icon/icon';
import { StyleSheet, View } from 'react-native';
import React from 'react';

const HomeCard = ({ item }) => {
  return (
    <View>
      <View style={styles.card}>
        <View style={styles.imageView}>
          <CustomImage
            style={styles.brand_image}
            resizeMode="contain"
            source={item.image}
            size={'small'}
          />
        </View>
        <View style={styles.content}>
          <View>
            <CustomText
              fontSize={moderateScale(16)}
              fontFamily={font.bold}
              text={item.brand_name}
              color={'black'}
            />
            <CustomText
              marginTop={verticalScale(5)}
              fontSize={fontSizes.small}
              fontFamily={font.regular}
              text={item.title}
            />
          </View>
          <View>
            <View style={globalStyle.row}>
              <Icon
                size={moderateScale(20)}
                icon_type={'AntDesign'}
                color={'yellow'}
                name={'orange'}
              />
              <CustomText
                fontSize={moderateScale(12)}
                style={{ marginLeft: 10 }}
                text={'4.7'}
              />
            </View>
          </View>
        </View>
      </View>
      <View style={styles.borderLine} />
    </View>
  );
};

export default HomeCard;

const styles = StyleSheet.create({
  card: {
    paddingVertical: verticalScale(20),
    backgroundColor: 'white',
    marginTop: 10,
  },
  brand_image: {
    height: verticalScale(90),
    alignSelf: 'center',
    width: '100%',
  },
  content: {
    marginTop: verticalScale(10),
    ...globalStyle.space_between,
  },
  imageView: {
    backgroundColor: 'white',
    borderRadius: 8,
    padding: 10,
    ...shadow,
  },
  borderLine: {
    height: verticalScale(5),
    backgroundColor: '#f4f4f4',
    marginLeft: -100,
    width: '200%',
  },
});
