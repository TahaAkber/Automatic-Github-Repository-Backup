import {
  Alert,
  Dimensions,
  StatusBar,
  StyleSheet,
  Text,
  Touchable,
  TouchableOpacity,
  View,
} from 'react-native';
import React, {useEffect, useRef, useState} from 'react';
import {globalStyle, margin, font} from '@constant/contstant';
import PointSvg from '@assets/images/point.svg';
import CustomText from '@materialComponent/customText/customText';
import CustomImage from '@materialComponent/image/image';
import CustomButton from '@materialComponent/customButton/customButton';
import BadgeSvg from '@assets/images/badge.svg';
import {colors} from '@constant/contstant';
import {moderateScale, scale} from 'react-native-size-matters';
import {toFixedMethod2} from '../../../utils/helper/helper';
import Icon from '../../../materialComponent/icon/icon';
import Clipboard from '@react-native-clipboard/clipboard';
import {showToast} from '../../../helper/reUsableMethod/reUsableMethod';

const {width, height, fontScale} = Dimensions.get('screen');

const VoucherCard = ({
  style,
  milestone,
  expiryDate,
  heading,
  subTitle,
  point,
  buttonColor,
  reward,
  buttonText,
  image,
  marginTop,
  onPress,
  orderAmount,
}) => {
  const [isActive, setIsActive] = useState(false);
  const timerRef = useRef(null);
  const expiredColor = expiryDate ? expiryDate?.includes('Expired') : false;

  const onCopyIconPress = () => {
    // show an alert (no clipboard used)
    //   Alert.alert("voucher is copied");

    // flash icon color for 2s
    Clipboard.setString(subTitle ? subTitle.toUpperCase() : '');
    showToast(`Your voucher has been coppied`);
    setIsActive(true);
    if (timerRef.current) clearTimeout(timerRef.current);
    timerRef.current = setTimeout(() => setIsActive(false), 1000);
  };

  // cleanup on unmount
  useEffect(() => {
    return () => timerRef.current && clearTimeout(timerRef.current);
  }, []);

  console.log('point ==>', orderAmount);

  return (
    <React.Fragment>
      <View style={{overflow: 'hidden', marginTop: marginTop || height * 0.02}}>
        <View style={globalStyle.row}>
          <CustomImage source={{uri: image}} style={styles.image} />
          <View style={{marginLeft: width * 0.03}}>
            <CustomText
              text={heading || 'You have been rewarded your cashback'}
              color={'#242B42'}
              fontSize={fontScale * 11}
              fontFamily={font.bold}
            />
            {/* <View style={styles.point}>
                        <PointSvg width={width * 0.035} height={width * 0.035} />
                        <CustomText style={{ marginLeft: "10%" }} text={point ? toFixedMethod2(point) : "0"} color={"#242B42"} fontSize={fontScale * 12} fontFamily={font.bold} />
                    </View> */}
            <CustomText
              marginTop={height * 0.01}
              text={`Voucher Code: ${subTitle ? subTitle.toUpperCase() : ''}`}
              color={'#797979'}
              fontSize={fontScale * 10}
              fontFamily={font.medium}
            />
            {expiryDate ? (
              <View
                style={[
                  styles.expiryDate,
                  expiredColor && {
                    borderColor: 'red',
                    backgroundColor: 'white',
                  },
                ]}>
                <CustomText
                  marginTop={height * 0.002}
                  text={expiryDate}
                  color={expiredColor ? 'red' : '#797979'}
                  fontSize={fontScale * 8}
                  fontFamily={font.medium}
                />
              </View>
            ) : (
              <></>
            )}
          </View>

          <View style={styles.point}>
            <PointSvg width={width * 0.035} height={width * 0.035} />
            <CustomText
              style={{marginLeft: 5}}
              text={point ? toFixedMethod2(point) : '0'}
              color={'#242B42'}
              fontSize={fontScale * 12}
              fontFamily={font.bold}
            />
          </View>
          {onPress ? (
            <></>
          ) : (
            <TouchableOpacity onPress={onCopyIconPress} activeOpacity={0.7}>
              <View style={{alignItems: 'flex-end', marginLeft: width * 0.01}}>
                <Icon
                  icon_type={isActive ? 'Ionicons' : 'Feather'}
                  name={isActive ? 'checkmark-done' : 'copy'}
                  size={moderateScale(15)}
                  color={isActive ? '#22C55E' : '#000000'}
                />
              </View>
            </TouchableOpacity>
          )}

          {(orderAmount && parseFloat(point) >= parseFloat(orderAmount)) ? (
            <View style={styles.buttonContainer}>
              <CustomButton
                // onPress={onPress}
                buttonStyle={{
                  paddingHorizontal: scale(0),
                  borderRadius: 8,
                }}
                fontSize={fontScale * 9}
                forceHeight={height * 0.032}
                backgroundColor={'red'}
                text={'Not eligible'}
              />
            </View>
          ) : onPress ? (
            <View style={styles.buttonContainer}>
              <CustomButton
                onPress={onPress}
                buttonStyle={{
                  paddingHorizontal: scale(0),
                  height: height * 0.032,
                  borderRadius: 8,
                }}
                fontSize={fontScale * 9}
                forceHeight={height * 0.04}
                backgroundColor={buttonColor || '#AE1B3F'}
                text={buttonText || 'Collect'}
              />
            </View>
          ) : (
            <></>
          )}
        </View>
      </View>

      {/* <View style={{ overflow: "hidden", marginTop: marginTop || height * 0.02, }}>
                <View style={[styles.voucher, style]}>
                    <View style={styles.imageContainer}>
                        {/* <View style={{ borderWidth: 2, borderColor: "#E6E9ED", width: "20%", aspectRatio: 1, borderRadius: 180, position: "absolute", right: "-11%", top: "-17%", backgroundColor: "white" }} /> */}
      {/* <View style={{ borderWidth: 2, borderColor: "#E6E9ED", width: "20%", aspectRatio: 1, borderRadius: 180, position: "absolute", right: "-11%", bottom: "-17%", backgroundColor: "white" }} /> */}
      {/* {reward ?
                            <View style={[styles.image, { backgroundColor: "#ececec", justifyContent: "center", alignItems: "center" }]}>
                                <BadgeSvg width={width * 0.12} height={width * 0.12} />
                            </View> :
                            <CustomImage
                                source={{ uri: image }}
                                style={styles.image}
                            />
                        } */}

      {/* </View>
                    <View style={styles.voucherMainView}>
                        <View style={styles.voucherContent}>
                            <View style={[globalStyle.space_between, { alignItems: "flex-start" }]}>
                                <View style={{ width: "90%" }}>
                                    <CustomText text={heading || "You have been rewarded your cashback"} color={"#242B42"} fontSize={fontScale * 11} fontFamily={font.bold} />
                                </View>
                                <View style={styles.point}>
                                    <PointSvg width={width * 0.035} height={width * 0.035} />
                                    <CustomText style={{ marginLeft: "10%" }} text={point ? toFixedMethod2(point) : "0"} color={"#242B42"} fontSize={fontScale * 12} fontFamily={font.bold} />
                                </View>
                            </View>
                            <CustomText marginTop={height * 0.00} text={subTitle} color={"#797979"} fontSize={fontScale * 10} fontFamily={font.medium} />
                            {expiryDate ?
                                <View style={styles.expiryDate}>
                                    <CustomText marginTop={height * 0.002} text={expiryDate} color={"#797979"} fontSize={fontScale * 8} fontFamily={font.medium} />
                                </View> : <></>
                            }
                        </View>
                    </View>

                    {onPress ?
                        <View style={styles.buttonContainer}>
                            <CustomButton onPress={onPress} buttonStyle={{ paddingHorizontal: scale(5) }} fontSize={fontScale * 9} height={height * 0.04} backgroundColor={buttonColor || "#AE1B3F"} text={buttonText || "Collect"} />
                        </View> : <></>
                    }

                </View>
            </View> */}
    </React.Fragment>
  );
};

export default VoucherCard;

const styles = StyleSheet.create({
  voucher: {
    borderWidth: 1,
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 5,
    borderColor: '#E6E9ED',
    // marginHorizontal: margin.horizontal,
    // paddingVertical: height * 0.005,
  },
  imageContainer: {
    width: '25%',
    aspectRatio: 1,
    // backgroundColor: "red",
    // borderRightWidth: 2,
    borderStyle: 'dashed',
    justifyContent: 'center',
    alignItems: 'center',
    borderColor: '#E6E9ED',
  },
  voucherContent: {
    width: '90%',
    // backgroundColor: "red",
  },
  point: {
    width: width * 0.2,
    ...globalStyle.row,
    position: 'absolute',
    top: 0,
    right: 0,
    justifyContent: 'flex-end',
    // backgroundColor: "green"
  },
  image: {
    width: width * 0.17,
    aspectRatio: 1,
    borderRadius: 5,
  },
  voucherMainView: {
    width: '65%',
    alignSelf: 'center',
    alignSelf: 'center',
    justifyContent: 'center',
    backgroundColor: 'red',
    // marginLeft: "3%",
    // marginTop: "-7%",
  },
  buttonContainer: {
    width: width * 0.2,
    // marginRight: "1%",
    position: 'absolute',
    right: 0,
    bottom: 0,
    marginTop: height * 0.01,
  },
  expiryDate: {
    padding: 2,
    paddingBottom: 4,
    borderRadius: 180,
    backgroundColor: '#e6e6e6',
    alignSelf: 'flex-start',
    marginTop: height * 0.01,
    paddingHorizontal: 10,
    borderWidth: 1,
    borderColor: '#ababab',
    alignItems: 'center',
    justifyContent: 'center',
    // position: "absolute",
    // left: "32%",
    // bottom: 15
  },
});
