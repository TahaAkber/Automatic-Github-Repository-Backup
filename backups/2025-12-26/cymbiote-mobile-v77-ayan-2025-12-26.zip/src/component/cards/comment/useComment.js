import { Animated } from 'react-native';
import { useState } from 'react';
import useReduxStore from '../../../utils/hooks/useReduxStore';


const useComment = ({ }) => {
    const [like, setLike] = useState(false)
    const scaleAnim = useState(new Animated.Value(1))[0];
    const { dispatch, getState } = useReduxStore()
    const { fetch_user_detail } = getState("auth")

    const handleLike = () => {
        setLike(prev => !prev);

        Animated.sequence([
            Animated.spring(scaleAnim, { toValue: 1.3, useNativeDriver: true }),  // Enlarge
            Animated.spring(scaleAnim, { toValue: 1, useNativeDriver: true }),    // Return to normal
        ]).start();
    };

    const likeIconStyle = {
        transform: [{ scale: scaleAnim }],
    };

    return {
        like,
        handleLike,
        likeIconStyle,
        fetch_user_detail
    };
};

export default useComment;
