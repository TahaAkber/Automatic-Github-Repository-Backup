import {
    Dimensions,
    StyleSheet,
    TouchableOpacity,
    View,
} from 'react-native';
import CustomText from '@materialComponent/customText/customText';
import ChatSvg from "@assets/images/chat.svg"

const { fontScale, height, width } = Dimensions.get("screen")

const MerchantChatBox = ({onPress}) => {
    return (
        <View style={styles.mainView}>
            <ChatSvg width={width * 0.05} height={width * 0.05} />
            <TouchableOpacity onPress={onPress}>
            <CustomText style={styles.text} text={"Chat with Merchant"}  />
            </TouchableOpacity>
        </View>
    );
};

export default MerchantChatBox;

const styles = StyleSheet.create({
    mainView: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "center"
    },
    text: {
        marginLeft: width * 0.02,
        fontSize: fontScale * 14,
    }
});
