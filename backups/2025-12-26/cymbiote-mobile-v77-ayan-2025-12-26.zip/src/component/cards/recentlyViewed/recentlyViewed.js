import React, {useCallback, useEffect, useState} from 'react';
import {
  Dimensions,
  FlatList,
  Image,
  StyleSheet,
  TouchableOpacity,
  View,
} from 'react-native';
import {moderateScale, verticalScale} from 'react-native-size-matters';
import CustomText from '@materialComponent/customText/customText';
import {navigate} from '@utils/navigationRef/navigationRef';
import {font, globalStyle, WH} from '@constant/contstant';
import CustomImage from '@materialComponent/image/image';
import Icon from '@materialComponent/icon/icon';
import Like from '@materialComponent/like/like';
import {colors} from '@constant/contstant';
import useReduxStore from '../../../utils/hooks/useReduxStore';
import {
  defaultShopImages,
  getImageHeightFromItem,
} from '../../../utils/helper/helper';
import {noImageUrl} from '../../../constant/contstant';
import {logHomeRecentViewedClickEvent} from '../../../helper/eventTriggers/useEventTriggers';

const {height} = Dimensions.get('screen');

const RecentlyViewed = ({data, marginTop}) => {
  const {getState, dispatch} = useReduxStore();
  const {fetch_favorite_list_local, fetch_favorite_list} = getState('user');
  const [productHeights, setProductHeights] = useState({});
  const finalArray = [
    ...(Array.isArray(fetch_favorite_list)
      ? fetch_favorite_list.flatMap(shop =>
          Array.isArray(shop.products)
            ? shop.products.map(p => p.product_id)
            : [],
        )
      : []),
    ...(Array.isArray(fetch_favorite_list_local)
      ? fetch_favorite_list_local.map(p => p.wishlist_product_id)
      : []),
  ];

  useEffect(() => {
    if (!data || data.length === 0) return; // 👈 guard clause
    const loadHeights = async () => {
      const heightsMap = {};

      await Promise.all(
        data.map(async item => {
          try {
            if (item?.product_id) {
              const imageUrl = defaultShopImages(item)?.[0];
              const height = await getImageHeightFromItem(imageUrl);
              heightsMap[item.product_id] = height;
            }
          } catch (err) {
            console.error('Failed to get height for', item, err);
          }
        }),
      );

      setProductHeights(heightsMap);
    };

    loadHeights();
  }, [data]);

  const renderItem = useCallback(
    ({item, index}) => {
      const handlePress = async () => {
        // Log analytics event
        await logHomeRecentViewedClickEvent(item, index);

        if (item?.shop_id) {
          navigate('Brand', {shop_id: item?.shop_id, shop: item});
        } else {
          navigate('ProductDetail', {
            product_id: item?.product_id,
            shop_id: item?.product_shop_id,
            default_images: defaultShopImages(item),
            height: productHeights?.[item?.product_id],
          });
        }
      };

      return (
        <TouchableOpacity
          activeOpacity={1}
          onPress={handlePress}
          style={styles.contentContainer}>
          <CustomImage
            resizeMode="cover"
            style={styles.image}
            source={{
              uri:
                item?.shop_logo_url ||
                item?.product_image_url_low ||
                item?.product_image_url ||
                noImageUrl,
            }}
          />
          {!item?.shop_id ? (
            <Like key={finalArray.length} product_id={item?.product_id} />
          ) : null}
        </TouchableOpacity>
      );
    },
    [navigate, productHeights, defaultShopImages, noImageUrl, finalArray],
  );

  return (data || [])?.length ? (
    <View style={{marginTop: marginTop}}>
      <View style={[globalStyle.row, {marginLeft: 20}]}>
        <CustomText
          fontFamily={font.bold}
          fontSize={moderateScale(17)}
          text={'Recent Viewed'}
        />
      </View>
      <FlatList
        renderItem={renderItem}
        keyExtractor={(item, index) => index.toString()}
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.flatlist}
        data={data}
        horizontal
        directionalLockEnabled={false}
        showsVerticalScrollIndicator={false}
        bounces={false}
      />
    </View>
  ) : (
    <></>
  );
};

export default RecentlyViewed;

const styles = StyleSheet.create({
  contentContainer: {
    borderRadius: moderateScale(10),
    marginRight: moderateScale(10),
    backgroundColor: 'white',
    marginTop: height * 0.005,
  },
  image: {
    borderRadius: moderateScale(12),
    height: WH.width(25),
    width: WH.width(25),
  },
  flatlist: {
    // marginBottom: verticalScale(20),
    // height: WH.width(30),
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: verticalScale(5),
    paddingLeft: 20,
  },
  circle: {
    height: moderateScale(20),
    width: moderateScale(20),
    backgroundColor: colors.light_theme.borderColor,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 180,
  },
});
