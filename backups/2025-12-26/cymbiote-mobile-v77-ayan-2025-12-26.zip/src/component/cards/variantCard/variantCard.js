import React, {useEffect, useState} from 'react';
import {
  Dimensions,
  FlatList,
  StyleSheet,
  Text,
  TouchableOpacity,
  Vibration,
  View,
} from 'react-native';
import {moderateScale, scale, verticalScale} from 'react-native-size-matters';
import CustomText from '@materialComponent/customText/customText';
import CustomImage from '@materialComponent/image/image';
import Icon from '@materialComponent/icon/icon';
import {colors, font, shadow, WH, globalStyle} from '@constant/contstant';
import {navigate} from '@utils/navigationRef/navigationRef';
import {
  _addToCart,
  _getCardItems,
  _checkout,
  _removeShop,
} from '@redux/actions/cart/cart';
import {toFixedMethod} from '@utils/helper/helper';
import BorderLine from '../../borderLine/borderLine';
import {currency} from '@constant/signature';
import LCSCard from '../../lcsCard/lcsCard';
import useReduxStore from '../../../utils/hooks/useReduxStore';
import {_cartBottomSheet} from '../../../redux/actions/common/common';
import {defaultShopImages, formatPrice} from '../../../utils/helper/helper';
import {_removeCartProduct} from '../../../redux/actions/cart/cart';
import {triggerHaptic} from '../../../utils/haptic/haptic';
import useImageHeight from '../../../utils/hooks/useImageHeight';

const {fontScale, height, width} = Dimensions.get('screen');
const MAX_QTY = 50;
const VariantCard = ({
  qtyFontSize,
  mainWIdth,
  opitonsMarginTop,
  index,
  quantityFontSize,
  variant,
  product,
  image,
  shop,
  priceQuantityWidth,
  qty,
  isDisabled,
  variantStock,
  onDecreasePress,
  onIncreasePress,
  display,
  borderWidth,
  showReviews,
  showSocialIcons,
  headingSize,
  priceSize,
  priceFontFamily,
  imageStyle,
  marginTop,
  borderTopMargin,
  removeBorder,
  handleQty,
  cartId,
  cartItemId,
  qtyLoader,
  setQtyLoader,
  imageQty,
  productTitle,
  optionHeight,
  optionFontSize,
  priceText,
  curreny,
}) => {
  const {dispatch} = useReduxStore();
  const {height} = useImageHeight(defaultShopImages(product)?.[0]);
  const [quantity, setQuantity] = useState(qty);
  const handleQuantity = async (
    newQty,
    shop,
    variant,
    isDelete,
    itemId,
    prevQuantity,
  ) => {
    const res = await handleQty(
      shop.shop_id,
      variant?.variant_id,
      newQty,
      isDelete,
      itemId,
      prevQuantity, // <-- pass previous local quantity
    );
    // If API failed (and not aborted), rollback local UI too
    if (!res.ok && !res.aborted) {
      setQuantity(prevQuantity ?? 1);
    }
  };

  const handleRemoveProduct = async (shop_id, itemId) => {
    setQtyLoader(true);
    try {
      await dispatch(_removeCartProduct(shop_id, itemId));
    } catch (err) {
      console.error('Error removing product from cart:', err);
    } finally {
      setQtyLoader(false);
    }
  };

  const availableQty = Number(variant?.variant_quantity ?? Infinity);
  const isAtStockCap =
    Number.isFinite(availableQty) && quantity >= availableQty;

  useEffect(() => {
    setQuantity(qty);
  }, [qty]);
  useEffect(() => {
  }, [cartItemId]); // Track changes to cartItemId

  const removeDefaultTitle = (variant?.selected_options || [])?.filter(
    item => item.value != 'Default Title',
  );

  return (
    <>
      <TouchableOpacity
        activeOpacity={1}
        disabled={isDisabled}
        style={[
          isDisabled ? {opacity: 0.3} : {},
          {flexDirection: 'row', marginTop: index == 0 ? 0 : height * 0.01},
        ]}>
        {/* Product Image */}
        <TouchableOpacity
          style={styles.imageView}
          onPress={() => {
            if (!isDisabled) {
              triggerHaptic();
              navigate('ProductDetail', {
                product_id:
                  product?.product_variant?.product?.product_id ||
                  product?.product_id,
                shop_id:
                  product?.product_variant?.product?.product_shop_id ||
                  product?.product_shop_id,

                default_images: defaultShopImages(
                  product?.product_variant?.product || product,
                ),
                height,
              });
              dispatch(_cartBottomSheet(false));
            }
          }}>
          <CustomImage
            source={{uri: image}}
            style={[styles.image, imageStyle]}
          />
          {imageQty ? (
            <View
              style={{
                position: 'absolute',
                bottom: 5,
                right: 5,
                backgroundColor: 'white',
                ...shadow,
                borderRadius: 180,
                minWidth: width * 0.05,
                height: width * 0.05,
                justifyContent: 'center',
                alignItems: 'center',
              }}>
              <CustomText fontSize={fontScale * 10} text={`x${qty}`} />
            </View>
          ) : (
            <></>
          )}
        </TouchableOpacity>

        {/* Product Details */}
        <View
          style={[
            styles.textView,
            mainWIdth && {width: mainWIdth},
            showSocialIcons && {width: WH.width(70)},
          ]}>
          <Text
            numberOfLines={1}
            style={[styles.descText, headingSize && {fontSize: headingSize}]}
            // onPress={() => {
            //   if (!isDisabled) {
            //     Vibration.vibrate(100);

            //     navigate('ProductDetail', {
            //       product_id: product?.product_id,
            //       shop_id: product?.product_shop_id,
            //       default_images: defaultShopImages(product),
            //     });
            //     dispatch(_cartBottomSheet(false));
            //   }
            // }}
          >
            {productTitle || product?.product_variant?.product?.product_name}
          </Text>

          {/* Reviews and other components */}
          {showReviews ? (
            <View
              style={[
                globalStyle.row,
                {marginTop: marginTop || height * 0.01},
              ]}>
              <CustomText
                fontFamily={font.bold}
                text={`(${item?.rating?.total_reviews || 0})`}
                style={styles.ratingValue}
              />
              {[...Array(5)].map((_, i) => (
                <Icon
                  key={i}
                  icon_type="Entypo"
                  name="star"
                  color="#ECA61B"
                  size={fontScale * 12}
                />
              ))}
            </View>
          ) : removeDefaultTitle || [] ? (
            <FlatList
              data={removeDefaultTitle}
              horizontal
              renderItem={({item, index}) => (
                <View
                  style={{
                    backgroundColor: '#E5EBFC',
                    marginRight: 5,
                    paddingHorizontal: 10,
                    borderRadius: 180,
                    // paddingVertical: 2,
                    marginTop: opitonsMarginTop || marginTop || height * 0.01,
                    height: optionHeight || height * 0.025,
                    justifyContent: 'center',
                    alignItems: 'center',
                  }}>
                  <CustomText
                    color={'black'}
                    fontSize={optionFontSize || fontScale * 10}
                    text={item?.value}
                  />
                </View>
              )}
              keyExtractor={(item, index) => index.toString()}
              showsHorizontalScrollIndicator={false}
            />
          ) : null}

          {/* Price and Quantity controls */}
          {shop?.shop_is_active && (
            <View
              style={[
                globalStyle.space_between,
                {
                  marginTop: marginTop || height * 0.005,
                  width: priceQuantityWidth || '100%',
                },
              ]}>
              <CustomText
                fontFamily={priceFontFamily || font.bold}
                fontSize={priceSize || fontScale * 15}
                text={`${
                  curreny ||
                  product?.product_variant?.product?.product_currency ||
                  product?.product_currency ||
                  currency
                } ${formatPrice(
                  priceText || toFixedMethod(variant?.variant_price),
                )}`}
                color={colors.light_theme.theme}
              />
              {isDisabled && (
                <CustomText
                  fontFamily={font.bold}
                  fontSize={fontScale * 13}
                  text={'Out of Stock'}
                  // color={colors.light_theme.theme}
                />
              )}
              {display ? (
                showSocialIcons ? (
                  <View style={styles.iconContainer}>
                    <LCSCard
                      product_id={product?.product_variant?.product.product_id}
                      fontSize={fontScale * 17}
                      iconContainerStyle={{width: width * 0.07}}
                      containerStyle={styles.lcsIcon}
                      dark={true}
                    />
                  </View>
                ) : !imageQty ? (
                  <CustomText
                    fontSize={quantityFontSize || fontScale * 15}
                    fontFamily={font.bold}
                    text={`Qty ${qty}`}
                  />
                ) : (
                  <></>
                )
              ) : (
                <View style={[globalStyle.space_between, styles.actionButtons]}>
                  <TouchableOpacity
                    activeOpacity={1}
                    style={[
                      styles.qtyButton,
                      {backgroundColor: '#E5EBFC'},
                      variantStock && {opacity: 0.3},
                    ]}
                    disabled={qtyLoader}
                    onPress={async () => {
                      triggerHaptic();
                      const prev = quantity;

                      if (quantity <= 1) {
                        await handleQuantity(
                          0,
                          shop,
                          variant,
                          true,
                          product.cart_item_id,
                          prev,
                        );
                      } else {
                        const next = prev - 1;
                        setQuantity(next); // optimistic UI
                        const res = await handleQuantity(
                          next,
                          shop,
                          variant,
                          false,
                          undefined,
                          prev,
                        );
                        if (!res.ok && !res.aborted) {
                          setQuantity(prev); // rollback on real failure
                        }
                      }

                      triggerHaptic();
                    }}>
                    {quantity <= 1 ? (
                      <Icon
                        icon_type="AntDesign"
                        name="delete"
                        color={qtyLoader ? 'white' : 'black'}
                        size={moderateScale(13)}
                      />
                    ) : (
                      <Icon
                        icon_type="AntDesign"
                        name="minus"
                        color="black"
                        size={moderateScale(13)}
                      />
                    )}
                  </TouchableOpacity>

                  <CustomText
                    fontSize={qtyFontSize || fontScale * 15}
                    fontFamily={font.bold}
                    text={quantity}
                  />
                  <TouchableOpacity
                    style={[
                      styles.qtyButton,
                      {backgroundColor: '#E5EBFC'},
                      isAtStockCap && {opacity: 0.4}, // dim when at stock cap
                      quantity >= MAX_QTY && {opacity: 0.4}, // dim when at hard cap
                    ]}
                    disabled={
                      qtyLoader ||
                      isDisabled ||
                      isAtStockCap ||
                      quantity >= MAX_QTY
                    }
                    onPress={async () => {
                      if (
                        qtyLoader ||
                        isDisabled ||
                        isAtStockCap ||
                        quantity >= MAX_QTY
                      )
                        return;

                      triggerHaptic();

                      const prev = quantity;
                      const next = Math.min(prev + 1, availableQty, MAX_QTY); // clamp to stock & MAX

                      if (next === prev) return; // already capped; nothing to do

                      // optimistic UI
                      setQuantity(next);

                      // call parent (debounced) updater, pass prev for rollback
                      const res = await handleQuantity(
                        next,
                        shop,
                        variant,
                        false,
                        undefined,
                        prev,
                      );

                      // rollback UI on real failure (not aborted)
                      if (!res.ok && !res.aborted) {
                        setQuantity(prev);
                      }
                    }}>
                    <Icon
                      icon_type="AntDesign"
                      name="plus"
                      color={
                        qtyLoader ||
                        isDisabled ||
                        isAtStockCap ||
                        quantity >= MAX_QTY
                          ? '#9e9e9e'
                          : 'black'
                      }
                      size={moderateScale(13)}
                    />
                  </TouchableOpacity>
                </View>
              )}
            </View>
          )}
        </View>
      </TouchableOpacity>

      {removeBorder ? null : (
        <BorderLine
          marginTop={borderTopMargin || height * 0.025}
          style={[styles.borderLine, {width: borderWidth || '95%'}]}
        />
      )}
    </>
  );
};

export default VariantCard;

const styles = StyleSheet.create({
  image: {
    width: WH.width(20),
    aspectRatio: 1,
    borderRadius: 5,
  },
  flatlistView: {
    paddingVertical: verticalScale(20),
    paddingBottom: verticalScale(5),
    marginTop: verticalScale(15),
    paddingHorizontal: scale(10),
    // backgroundColor: 'white',
    borderRadius: 45,
    // ...shadow,
  },
  brand: {
    marginBottom: 10,
  },
  imageView: {
    marginRight: scale(10),
  },
  textView: {
    width: WH.width(60),
    // backgroundColor: "red"
  },
  descText: {
    fontSize: fontScale * 15,
    fontFamily: font.bold,
    color: 'black',
  },
  priceText: {
    fontSize: moderateScale(13),
    fontFamily: font.bold,
    color: 'black',
  },
  actionButtons: {
    width: '33%',
  },
  productStatus: {
    position: 'absolute',
    zIndex: 2,
    right: 10,
    top: 20,
  },
  qtyButton: {
    borderRadius: 5,
    width: width * 0.06,
    aspectRatio: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  borderLine: {
    marginLeft: 0,
    width: '95%',
    backgroundColor: '#00000033',
    height: height * 0.001,
    alignSelf: 'center',
    opacity: 0.3,
  },
  brandTabMainViewStyle: {},
  brandTabImageStyle: {
    ...shadow,
    backgroundColor: 'white',
  },
  ratingValue: {
    marginRight: width * 0.01,
    fontSize: fontScale * 14,
  },
  iconContainer: {
    width: width * 0.31,
    alignItems: 'flex-end',
  },
  lcsIcon: {
    bottom: 0,
    position: 'relative',
  },
});
