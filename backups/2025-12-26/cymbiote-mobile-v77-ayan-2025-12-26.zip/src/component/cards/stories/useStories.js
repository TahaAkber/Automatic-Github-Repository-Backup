import { useCallback, useEffect, useState } from 'react';
import { Dimensions } from 'react-native';
import { following } from '@constant/dummyData';
import useReduxStore from '../../../utils/hooks/useReduxStore';
import { _updateReelViewCount } from '../../../redux/actions/reels/reels';
import { _getFollowingStories } from '../../../redux/actions/merchant/merchant';
import { pagination } from '../../../utils/helper/helper';

const { fontScale, height, width } = Dimensions.get('screen');

const useStories = ({ }) => {
  const [modalVisible, setModalVisible] = useState(false);
  const [currentStoryIndex, setCurrentStoryIndex] = useState(0);
  const { getState, dispatch } = useReduxStore();
  const { fetch_stories_following_list, fetch_stories_following_list_loader } = getState('merchant');
  const [paginationLoader, setPaginationLoader] = useState(false);
  const [page, setPage] = useState(1);
  const [pullLoader, setPullLoader] = useState(false);

  const fetchAPI = async (isLoading) => {
    !isLoading && setPullLoader(true);
    !isLoading && setPage(1);

    await dispatch(_getFollowingStories(false, [], false, 1));
    setPullLoader(false);
  };

  useEffect(() => {
    fetchAPI(true);
  }, []);
  const paginationAPI = async () => {
    if (paginationLoader) return;

    const currentPage = fetch_stories_following_list?.pagination?.page ?? 1;
    const totalPages = fetch_stories_following_list?.pagination?.totalPages ?? 1;
    if (currentPage >= totalPages) return;

    const nextPage = pagination(page, totalPages); // same helper you use in useFollowing
    if (!nextPage) return;

    try {
      setPaginationLoader(true);
      await dispatch(_getFollowingStories(false, [], false, nextPage, true));
      setPage(nextPage);
    } finally {
      setPaginationLoader(false);
    }
  };


  const handleStoryPress = index => {
    // setCurrentStoryIndex(index);
    // setModalVisible(true);
  };

  const handleNextStory = () => {
    if (currentStoryIndex < following.length - 1) {
      setCurrentStoryIndex(currentStoryIndex + 1);
    } else {
      setModalVisible(false); // Close modal if it's the last story
    }
  };

  const handlePreviousStory = () => {
    if (currentStoryIndex > 0) {
      setCurrentStoryIndex(currentStoryIndex - 1);
    }
  };

  const handleViewableItemsChanged = useCallback(
    ({ viewableItems }) => {
      if (viewableItems.length > 0) {
        const { index, item } = viewableItems[0];
        setCurrentStoryIndex(index);
        const shopId = item?.shop_detail?.shop_id;
        if (shopId && !viewedStoryIds.current.has(shopId)) {
          viewedStoryIds.current.add(shopId);
          dispatch(_updateReelViewCount(shopId)); // 🔄 rename action to `_updateStoryViewCount` if needed
        }
      }
    },
    [dispatch, fetch_stories_following_list],
  );

  const viewabilityConfig = {
    itemVisiblePercentThreshold: 60,
  };

  return {
    modalVisible,
    setModalVisible,
    currentStoryIndex,
    setCurrentStoryIndex,
    handleStoryPress,
    handleNextStory,
    handlePreviousStory,
    fetch_stories_following_list,
    handleViewableItemsChanged,
    viewabilityConfig,
    fetch_stories_following_list_loader,
    paginationLoader,
    pullLoader,

    fetchAPI,
    paginationAPI,
  };
};

export default useStories;
