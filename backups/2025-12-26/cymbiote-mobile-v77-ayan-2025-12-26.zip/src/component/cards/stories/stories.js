import React, { useState } from 'react';
import {
  FlatList,
  Modal,
  StyleSheet,
  TouchableOpacity,
  View,
  Image,
  Text,
  Dimensions,
} from 'react-native';
import { moderateScale, verticalScale } from 'react-native-size-matters';
import { following } from '@constant/dummyData';
import { font, globalStyle, WH } from '@constant/contstant';
import CustomText from '@materialComponent/customText/customText';
import LinearGradient from 'react-native-linear-gradient';
import CustomImage from '@materialComponent/image/image';
import { colors } from '@constant/contstant';
import useStories from './useStories';
import { navigate } from '../../../utils/navigationRef/navigationRef';
import FollowingStoriesLoader from '../../loader/followingStoriesLoader';

const { fontScale, height, width } = Dimensions.get('screen');

const Stories = ({ heading, fontSize, onPress }) => {
  const {
    modalVisible,
    setModalVisible,
    currentStoryIndex,
    setCurrentStoryIndex,
    handleStoryPress,
    handleNextStory,
    handlePreviousStory,
    fetch_stories_following_list,
    fetch_store_following_list_loader,
    paginationLoader,
    pullLoader,
    fetchAPI,
    paginationAPI,

  } = useStories({});

  return fetch_stories_following_list?.data?.length > 0 ? (
    <View>
      <View style={[globalStyle.row]}>
        <CustomText
          fontFamily={font.bold}
          fontSize={fontScale * 20}
          text={heading}
          style={{ marginLeft: moderateScale(15) }}
        />
      </View>
      <FlatList
        data={fetch_stories_following_list?.data}
        horizontal
        showsHorizontalScrollIndicator={false}
        renderItem={({ item, index }) => (
          <TouchableOpacity
            activeOpacity={1}
            style={[
              styles.contentContainer,
              index === 0 && { marginLeft: moderateScale(10) },
              index === fetch_stories_following_list?.data?.length - 1 && { marginRight: moderateScale(10) },
            ]}
            onPress={() =>
              // onPress ? onPress(item?.shop_detail) : handleStoryPress(index)
               navigate('Brand', {shop_id: item?.shop_detail?.shop_id, shop: item?.shop_detail})
            }>
            <LinearGradient
              colors={[colors.light_theme.theme, 'white']}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={styles.gradientWrapper}>
              <CustomImage
                size={'small'}
                resizeMode="cover"
                style={styles.image}
                source={{ uri: item?.shop_detail?.shop_logo_url }}
              />
            </LinearGradient>
            {/* <CustomText
              fontFamily={font.regular}
              center
              marginTop={height * 0.007}
              text={item.shop_detail?.shop_name}
              fontSize={fontScale * 10}
            /> */}
          </TouchableOpacity>
        )}
        keyExtractor={(item, index) => index.toString()}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.flatlist}
         onEndReached={paginationAPI}
        onEndReachedThreshold={0.6}
        ListFooterComponent={
          paginationLoader ? (
        <View style={{ justifyContent: "center", alignItems: "center", }}>
             <FollowingStoriesLoader/>
            </View>
            
          ) :  null
        }
        
      />

      {/* Modal for Story Viewer */}
      <Modal
        visible={modalVisible}
        transparent
        animationType="slide"
        onRequestClose={() => setModalVisible(false)}>
        <View style={styles.modalContainer}>
          <Image
            source={{
              uri: fetch_stories_following_list?.data[currentStoryIndex].shop_detail
                ?.shop_logo_url,
            }}
            style={styles.storyImage}
          />
          <View style={styles.storyControls}>
            {/* Previous Story */}
            <TouchableOpacity
              style={styles.controlLeft}
              onPress={handlePreviousStory}
              disabled={currentStoryIndex === 0}>
              <Text style={styles.controlText}>{'<'}</Text>
            </TouchableOpacity>

            {/* Next Story */}
            <TouchableOpacity
              style={styles.controlRight}
              onPress={handleNextStory}
              disabled={currentStoryIndex === following.length - 1}>
              <Text style={styles.controlText}>{'>'}</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  ) : (
    <></>
  );
};

export default Stories;

const styles = StyleSheet.create({
  contentContainer: {
    borderRadius: 180,
    marginRight: moderateScale(5),
    padding: moderateScale(1.5),
    width: WH.width(17),
    aspectRatio: 1,
  },
  gradientWrapper: {
    borderRadius: 180,
    overflow: 'hidden',
    padding: moderateScale(2),
  },
  image: {
    width: WH.width(15),
    height: WH.width(15),
    borderRadius: 180,
  },
  flatlist: {
    marginBottom: verticalScale(2),
    height: WH.width(16),
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: verticalScale(10),
    paddingRight:verticalScale(110)
  },
  modalContainer: {
    flex: 1,
    backgroundColor: '#000',
    justifyContent: 'center',
    alignItems: 'center',
  },
  storyImage: {
    width: WH.width(90),
    height: WH.height(70),
    resizeMode: 'cover',
    borderRadius: moderateScale(10),
  },
  storyControls: {
    position: 'absolute',
    width: '100%',
    height: '100%',
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  controlLeft: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'flex-start',
    paddingLeft: moderateScale(10),
  },
  controlRight: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'flex-end',
    paddingRight: moderateScale(10),
  },
  controlText: {
    color: '#fff',
    fontSize: moderateScale(30),
    fontWeight: 'bold',
  },
});
