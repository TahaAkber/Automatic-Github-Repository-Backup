import { useEffect, useRef } from 'react';
import { Animated, Dimensions, PanResponder } from 'react-native';

const { width } = Dimensions.get("screen");

const useSwipeToDelete = ({ data }) => {
    const translateX = useRef(new Animated.Value(0)).current;
    const opacity = useRef(new Animated.Value(0)).current; // 🔹 Initially hidden
    const deleteTranslateX = useRef(new Animated.Value(50)).current; // 🔹 SVG starts off-screen (right)

    const isSwiping = useRef(false); // Track swiping state

    useEffect(() => {
        // 🔹 Ensure delete button starts hidden
        translateX.setOffset(0);
        opacity.setValue(0);
        deleteTranslateX.setValue(50); // 🔹 Start delete button off-screen (right side)
    }, []);

    const panResponder = PanResponder.create({
        onStartShouldSetPanResponder: () => true,
        onMoveShouldSetPanResponder: (_, gesture) => {
            if (Math.abs(gesture.dx) > Math.abs(gesture.dy) * 1.2) {
                isSwiping.current = true;
                return true;
            }
            isSwiping.current = false;
            return false;
        },
        onPanResponderMove: (_, gesture) => {
            if (isSwiping.current) {
                if (gesture.dx < -width * 0.03) { // 🔹 Reduced swipe threshold for easy activation
                    translateX.setValue(gesture.dx);

                    // 🔹 Fade in delete button smoothly
                    Animated.parallel([
                        Animated.timing(opacity, {
                            toValue: 1,
                            duration: 100,
                            useNativeDriver: true,
                        }),
                        Animated.timing(deleteTranslateX, {
                            toValue: 0, // 🔹 Move delete SVG from right to left
                            duration: 200,
                            useNativeDriver: true,
                        }),
                    ]).start();
                } else if (gesture.dx > width * 0.03) { // 🔹 Swiping right (reset position)
                    Animated.parallel([
                        Animated.timing(translateX, {
                            toValue: 0,
                            duration: 200,
                            useNativeDriver: true,
                        }),
                        Animated.timing(opacity, {
                            toValue: 0, // 🔹 Hide delete button when resetting
                            duration: 150,
                            useNativeDriver: true,
                        }),
                        Animated.timing(deleteTranslateX, {
                            toValue: 50, // 🔹 Move delete button back off-screen (right)
                            duration: 150,
                            useNativeDriver: true,
                        }),
                    ]).start();
                }
            }
        },
        onPanResponderRelease: (_, gesture) => {
            if (!isSwiping.current) return;

            if (gesture.dx < -width * 0.12) { // 🔹 Confirm delete button reveal
                Animated.timing(translateX, {
                    toValue: -width * 0.15,
                    duration: 150,
                    useNativeDriver: true,
                }).start();
            } else {
                Animated.parallel([
                    Animated.timing(translateX, {
                        toValue: 0,
                        duration: 200,
                        useNativeDriver: true,
                    }),
                    Animated.timing(opacity, {
                        toValue: 0, // 🔹 Fully hide delete button when resetting
                        duration: 150,
                        useNativeDriver: true,
                    }),
                    Animated.timing(deleteTranslateX, {
                        toValue: 50, // 🔹 Move delete button back off-screen (right)
                        duration: 150,
                        useNativeDriver: true,
                    }),
                ]).start();
            }
        },
    });

    return {
        translateX,
        opacity,
        deleteTranslateX, // 🔹 Added animation value for delete button's movement
        panResponder
    };
};

export default useSwipeToDelete;
