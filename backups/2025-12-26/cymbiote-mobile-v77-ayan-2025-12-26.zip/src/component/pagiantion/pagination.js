import { View, StyleSheet, TouchableOpacity, ScrollView, Dimensions } from 'react-native';
import React, { useState } from 'react';
import { scale, verticalScale, moderateScale } from 'react-native-size-matters';
import { colors } from '../../constant/contstant';
import CustomText from '../../materialComponent/customText/customText';
import { globalStyle } from '../../constant/contstant';
import Icon from '../../materialComponent/icon/icon';

const { width, height, fontScale } = Dimensions.get("screen")

const Pagination = ({ start, end, marginTop = 0 }) => {
    const [currentPage, setCurrentPage] = useState(1);
    const [currentPageNo, setCurrentPageNo] = useState(1);
    const itemsPerPage = 4; // Number of items to show per page

    const createArray = () => {
        let arr = [];
        for (let i = parseFloat(start); i <= parseFloat(end); i++) {
            arr.push(i);
        }
        return arr;
    };

    const arr = createArray();
    const maxPage = Math.ceil(arr.length / itemsPerPage);

    const handleNext = () => {
        setCurrentPage(currentPage + 1);
    };

    const handlePrevious = () => {
        setCurrentPage(currentPage - 1);
    };

    const startIdx = (currentPage - 1) * itemsPerPage;
    const endIdx = startIdx + itemsPerPage;
    const currentItems = arr.slice(startIdx, endIdx);

    const validation =
        arr[arr?.length - 1] == currentItems[currentItems?.length - 1];
    const startValidation = arr[0] == currentItems[0];

    return (
        <View style={[styles.mainview, { marginTop }]}>
            <Icon
                style={[styles.icon, { marginRight: width * 0.03 }]}
                icon_type={'Ionicons'}
                name={'chevron-back'}
                onPress={startValidation ? console.log('') : handlePrevious}
                color={startValidation ? "#E4E9EE" : "black"}
                size={14}
            />
            <View style={styles.paginationContainer}>
                <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                    <View style={globalStyle.space_between}>
                        {currentItems.map((item, index) => (
                            <TouchableOpacity
                                onPress={() => setCurrentPageNo(item)}
                                key={index}
                                style={[
                                    styles.counter,
                                    {
                                        borderWidth: 1,
                                        borderColor: currentPageNo === item ? "black" : "#E4E9EE"
                                    },
                                ]}>
                                <CustomText
                                    color={currentPageNo === item ? 'black' : '#E4E9EE'}
                                    text={item}
                                    fontSize={moderateScale(10)}
                                />
                            </TouchableOpacity>
                        ))}
                    </View>
                </ScrollView>
            </View>
            <Icon
                style={[styles.icon, { textAlign: 'right', marginLeft: width * 0.01 }]}
                icon_type={'Ionicons'}
                name={'chevron-forward'}
                onPress={validation ? console.log('') : handleNext}
                color={validation ? "black" : "#E4E9EE"}
                size={14}
            />
        </View>
    );
};

export default Pagination;

const styles = StyleSheet.create({
    mainview: {
        // ...globalStyle.space_between,
        marginVertical: verticalScale(10),
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "center"
        // justifyContent:"center",
        // alignItems:"center"
    },
    icon: {
        // width: '12%',
    },
    paginationContainer: {
        alignItems: "center"
    },
    counter: {
        width: width * 0.1,
        height: width * 0.08,
        // aspectRatio: 1,
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: moderateScale(5),
        marginRight: width * 0.02,
        paddingHorizontal : width * 0.02
    },
});
