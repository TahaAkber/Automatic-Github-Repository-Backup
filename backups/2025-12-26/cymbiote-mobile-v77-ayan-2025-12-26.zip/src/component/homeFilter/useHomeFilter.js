import {useRef, useState} from 'react';
import useReduxStore from '../../utils/hooks/useReduxStore';
import {_searchFilters} from '../../redux/actions/common/common';

const useHomeFilter = ({screen, setBrand}) => {
  const {dispatch, getState} = useReduxStore();
  const {screenFilters} = getState('common');
  const refRBSheet = useRef(null);
  const [selectData, setSelectData] = useState({});

  const filters = screenFilters?.[screen];

  const _handleSubmit = (key, value) => {
    if (selectData?.db_value == 'brands' && typeof setBrand === 'function') {
      setBrand(value);
    } else {
      dispatch(_searchFilters(key, value, screen));
    }
  };

  return {refRBSheet, selectData, filters, setSelectData, _handleSubmit};
};

export default useHomeFilter;
