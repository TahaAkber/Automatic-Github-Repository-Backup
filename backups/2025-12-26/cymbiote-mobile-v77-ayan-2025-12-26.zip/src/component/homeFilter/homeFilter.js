import React, {memo, useEffect, useState} from 'react';
import {FlatList, StyleSheet, Text, TouchableOpacity, View} from 'react-native';
import BottomSheetReUsable from '@materialComponent/bottomSheet/bottomSheet';
import {moderateScale, verticalScale} from 'react-native-size-matters';
import CustomText from '@materialComponent/customText/customText';
import {colors, globalStyle} from '@constant/contstant';
import Icon from '@materialComponent/icon/icon';
import useHomeFilter from './useHomeFilter';
import {filtersData, font} from '../../constant/contstant';
import BottomSheetFilters from '../../materialComponent/bottomSheet/bottomSheetFilters';

const HomeFilter = ({
  marginTop,
  screen,
  fetchAPI,
  removeFilters,
  brands,
  setBrand = () => console.log('DEFAULT_CONSOLE'),
  brand,
}) => {
  const {refRBSheet, setSelectData, selectData, _handleSubmit, filters} =
    useHomeFilter({
      screen,
      setBrand,
    });

  const data = {
    id: 99,
    heading: 'Brands',
    db_value: 'brands',
    type: 'radio',
    value: '',
    default_value: '',
    data: brands
      ? brands?.map((item, index) => {
          return {id: item, value: item};
        })
      : [],
  };

  const RenderItem = memo(
    ({item, refRBSheet, setValue, filters, brand}) => {
      const _handlePress = () => {
        if (item.type == 'single-select') {
          _handleSubmit(
            item.db_value,
            filters?.[item?.db_value] ? '' : item.id,
          );
          fetchAPI();
        } else {
          setValue(item);
          refRBSheet?.current?.open();
        }
      };

      const isSelected = () => {
        if (item.db_value === 'brands') {
          // return filters[item.db_value] == item.value;
          return Boolean(data.data.find(item => item.id == brand));
        } else if (item.type === 'single-select') {
          // return filters[item.db_value] == item.value;
          return Boolean(filters?.[item?.db_value]);
        } else if (item.type === 'checkbox') {
          return filters?.[item?.db_value]?.length > 0;
        } else if (item.type === 'radio') {
          return Boolean(filters?.[item?.db_value]);
        } else if (item.type === 'range') {
          const isDisabled =
            JSON.stringify(filters?.[item?.db_value]) ==
            JSON.stringify(item?.default_value);
          return isDisabled
            ? false
            : Boolean(filters?.[item?.db_value]?.length > 0);
        }
        return false;
      };

      return (
        <View>
          <TouchableOpacity
            onPress={_handlePress} // Open the bottom sheet when text is clicked
            style={[
              styles.filterSection,
              isSelected() && {backgroundColor: colors.light_theme.theme},
            ]}>
            <CustomText
              fontSize={moderateScale(12)}
              text={item.heading}
              fontFamily={font.medium}
              color={isSelected() && 'white'}
            />
            {item.type != 'single-select' && (
              <Icon
                name="chevron-thin-down"
                size={moderateScale(12)}
                icon_type="Entypo"
                color={isSelected() ? 'white' : 'black'}
                style={{marginLeft: moderateScale(15)}}
              />
            )}
          </TouchableOpacity>
        </View>
      );
    },
    [filters],
  );

  const finalData = removeFilters
    ? filtersData?.filter(
        (item, index) => !removeFilters.includes(item.db_value),
      )
    : filtersData;

  useEffect(() => {
    if (!data?.length) {
      setBrand('');
    }
  }, [data]);

  return (
    <View style={{marginTop, flexDirection: 'row'}}>
      <FlatList
        keyExtractor={(item, index) => index.toString()}
        showsHorizontalScrollIndicator={false}
        data={finalData}
        horizontal
        renderItem={({item, index}) => (
          <View
            style={[
              index === 0 && {marginLeft: moderateScale(10)},
              index === finalData.length - 1 && {
                marginRight: moderateScale(10),
              },
            ]}>
            <RenderItem
              setValue={setSelectData}
              refRBSheet={refRBSheet}
              item={item}
              filters={filters}
              brand={brand}
            />
          </View>
        )}
      />

      <BottomSheetFilters
        data={selectData?.db_value == 'brands' ? data : selectData || {}}
        removeSelectedData={() => setSelectData({})}
        refRBSheet={refRBSheet}
        screen={screen}
        onPress={_handleSubmit}
        fetchAPI={fetchAPI}
        filters={filters}
        setBrand={selectData?.db_value == 'brands' ? setBrand : null}
        brand={brand}
      />
    </View>
  );
};

export default HomeFilter;

const styles = StyleSheet.create({
  filterSection: {
    paddingHorizontal: moderateScale(10),
    borderRadius: moderateScale(5),
    marginRight: moderateScale(10),
    height: verticalScale(25),
    borderColor: colors.light_theme.darkBorderColor,
    alignSelf: 'flex-start',
    ...globalStyle.row,
    borderWidth: 1,
  },
});
