// // import { Dimensions, StyleSheet, View, Animated, PanResponder, TouchableOpacity, FlatList, Image } from 'react-native';
// // import React, { useCallback, useRef } from 'react';
// // import CustomText from '../../materialComponent/customText/customText';
// // import CustomBackgoundImage from '../../materialComponent/image/bgImage';
// // import { font, globalStyle, margin, WH } from '../../constant/contstant';
// // import Video from 'react-native-video';
// // import CustomImage from '../../materialComponent/image/image';
// // import Icon from '../../materialComponent/icon/icon';
// // import BorderLine from '../borderLine/borderLine';
// // import Collection from './collection';
// // import ShopTileCategories from '../shopTIleCategories/shopTIleCategories';
// // import HomeDualCard from '../cards/homeDualCard';
// // import BottomSheetBrandNotification from '../../materialComponent/bottomSheet/bottomSheetBrandNotification';

// // const { height, fontScale, width } = Dimensions.get("screen");

// // const TestContent = ({ shop, products }) => {
// //     // Define initial top position as a percentage of screen height
// //     // const initialTop = height * 0.25; // 20% of screen height
// //     const initialTop = height * 0.65;
// //     const LogoTop = height * 0.1; // 20% of screen height
// //     const topValue = useRef(new Animated.Value(initialTop)).current;
// //     const refRBNotificationSheet = useRef()

// //     // Interpolate text color based on topValue
// //     const textColor = topValue.interpolate({
// //         inputRange: [0, initialTop], // When topValue is between 0 and initialTop
// //         outputRange: ['black', 'white'], // Text color changes from black to white
// //         extrapolate: 'clamp', // Prevent extrapolation beyond the inputRange
// //     });

// //     const bgColor = topValue.interpolate({
// //         inputRange: [0, initialTop], // When topValue is between 0 and initialTop
// //         outputRange: ['white', shop?.shop_color], // Text color changes from black to white
// //         extrapolate: 'clamp', // Prevent extrapolation beyond the inputRange
// //     });

// //     const borderLineColor = topValue.interpolate({
// //         inputRange: [0, initialTop], // When topValue is between 0 and initialTop
// //         outputRange: ['#efefef', 'rgba(0,0,0,0.0)'], // Text color changes from black to white
// //         extrapolate: 'clamp', // Prevent extrapolation beyond the inputRange
// //     });

// //     const barColor = topValue.interpolate({
// //         inputRange: [0, initialTop], // When topValue is between 0 and initialTop
// //         outputRange: [shop?.shop_color, 'rgba(0,0,0,0.0)'], // Text color changes from black to white
// //         extrapolate: 'clamp', // Prevent extrapolation beyond the inputRange
// //     });

// //     const borderBottomRadius = topValue.interpolate({
// //         inputRange: [0, initialTop], // When topValue is between 0 and initialTop
// //         outputRange: [0, 20], // Text color changes from black to white
// //         extrapolate: 'clamp', // Prevent extrapolation beyond the inputRange
// //     });

// //     const brandTabMargin = topValue.interpolate({
// //         inputRange: [0, initialTop], // When topValue is between 0 and initialTop
// //         outputRange: [height * 0.02, 0], // Text color changes from black to white
// //         extrapolate: 'clamp', // Prevent extrapolation beyond the inputRange
// //     });

// //     // Create a PanResponder to handle gestures
// //     const panResponder = useRef(
// //         PanResponder.create({
// //             onStartShouldSetPanResponder: () => true, // Allow the view to respond to touch
// //             onPanResponderMove: (_, gestureState) => {
// //                 // Update the top value based on the gesture's vertical movement (dy)
// //                 const newTop = Math.max(0, initialTop + gestureState.dy); // Prevent going above top: 0
// //                 topValue.setValue(newTop);
// //             },
// //             onPanResponderRelease: (_, gestureState) => {
// //                 // When the gesture ends, decide the final position based on the drag distance
// //                 if (gestureState.dy < -height * 0.1) {
// //                     // If swiped up more than 10% of screen height, move to the top
// //                     Animated.timing(topValue, {
// //                         toValue: 0,
// //                         duration: 300,
// //                         useNativeDriver: false,
// //                     }).start();
// //                 } else {
// //                     // If not swiped enough, animate back to the initial position
// //                     Animated.timing(topValue, {
// //                         toValue: initialTop,
// //                         duration: 300,
// //                         useNativeDriver: false,
// //                     }).start();
// //                 }
// //             },
// //         })
// //     ).current;

// //     const renderProductItem = useCallback((item, index) => (
// //         <View key={index} style={{}}>
// //             <HomeDualCard item={item.item} width={WH.width("43")} marginRight={0} color={textColor} />
// //         </View>
// //     ), [textColor]); // Dependencies (only re-renders if textColor changes)

// //     const IsImage = shop?.shop_banner_type == "image" ? CustomBackgoundImage : View;


// //     return (
// //         <IsImage
// //             style={styles.backgroundImage}
// //             source={{
// //                 uri: shop?.shop_banner_url,
// //             }}>

// //             {shop?.shop_banner_type == "image" ?
// //                 <>
// //                 </> :
// //                 <Video
// //                     source={{ uri: shop?.shop_banner_url }}
// //                     style={styles.video_view}
// //                     resizeMode="cover"
// //                     muted
// //                     repeat
// //                 />
// //             }

// //             {/* <View style={{ position: "absolute", top: LogoTop }} > */}
// //             <Image style={{ width: width * 0.5, aspectRatio: 1, alignSelf: "center", marginTop: height * 0.06 }} resizeMode={"contain"} source={{ uri: shop?.shop_banner_logo_url }} />
// //             {/* </View> */}

// //             {/* Animated red View with gesture handling */}
// //             <Animated.View
// //                 {...panResponder.panHandlers} // Attach gesture handlers
// //                 style={{
// //                     backgroundColor: bgColor,
// //                     position: "absolute",
// //                     top: topValue, // Use animated top value
// //                     height: height, // Full screen height
// //                     width: "100%",
// //                     borderTopRightRadius: borderBottomRadius,
// //                     borderTopLeftRadius: borderBottomRadius,
// //                     overflow: "hidden"
// //                 }}
// //             >

// //                 {/* brand tab */}
// //                 <Animated.View style={{ width: "100%", backgroundColor: barColor, justifyContent: "center", alignItems: "center", borderBottomLeftRadius: 20, borderBottomRightRadius: 20 }}>
// //                     <View style={{ width: width * 0.1, height: height * 0.005, backgroundColor: "white", marginVertical: height * 0.03, borderRadius: 180 }} />
// //                 </Animated.View>
// //                 <View>
// //                     <Animated.View style={[styles.brandTab, { marginTop: brandTabMargin }]}>
// //                         <View style={globalStyle.row}>
// //                             <CustomImage source={{ uri: shop?.shop_logo_url }} style={styles.logoUrl} />
// //                             <View style={{ marginLeft: "7%" }}>
// //                                 <Animated.Text
// //                                     style={{
// //                                         fontSize: fontScale * 14,
// //                                         color: textColor, // Use interpolated text color
// //                                         fontFamily: font.bold
// //                                     }}
// //                                 >
// //                                     {shop?.shop_name}
// //                                 </Animated.Text>

// //                                 <View style={globalStyle.row}>
// //                                     <Animated.Text
// //                                         style={{
// //                                             fontSize: fontScale * 9,
// //                                             color: textColor, // Use interpolated text color
// //                                             fontFamily: font.bold,
// //                                             marginRight: 5
// //                                         }}
// //                                     >
// //                                         4.6
// //                                     </Animated.Text>

// //                                     <Animated.Text style={{ color: textColor }}>
// //                                         <Icon icon_type={"AntDesign"} name={"star"} />
// //                                     </Animated.Text>

// //                                     <Animated.Text
// //                                         style={{
// //                                             fontSize: fontScale * 9,
// //                                             color: textColor, // Use interpolated text color
// //                                             fontFamily: font.bold,
// //                                             marginLeft: 5
// //                                         }}
// //                                     >
// //                                         (865)
// //                                     </Animated.Text>
// //                                 </View>
// //                             </View>
// //                         </View>

// //                         <View style={globalStyle.row}>
// //                             {/* <TouchableOpacity onPress={() => navigate("Reels")}>
// //                                 <Animated.Text style={{ color: textColor, marginRight: 10 }}>
// //                                     <Icon icon_type={"Feather"} size={fontScale * 17} name={"film"} />
// //                                 </Animated.Text>
// //                             </TouchableOpacity> */}
// //                             <TouchableOpacity onPress={() => refRBNotificationSheet?.current?.open()} >
// //                                 <Animated.Text style={{ color: textColor, marginRight: 10 }}>
// //                                     <Icon icon_type={"Ionicons"} size={fontScale * 18} name={"notifications-outline"} />
// //                                 </Animated.Text>
// //                             </TouchableOpacity>
// //                             {/* <TouchableOpacity onPress={() => navigate("BrandSearch")}>
// //                                 <Animated.Text style={{ color: textColor, marginRight: 10 }}>
// //                                     <Icon icon_type={"MaterialIcons"} size={fontScale * 18} name={"search"} />
// //                                 </Animated.Text>
// //                             </TouchableOpacity> */}
// //                             {/* <TouchableOpacity onPress={() => refRBSheet?.current?.open()} >
// //                                 <Animated.Text style={{ color: textColor }}>
// //                                     <Icon icon_type={"Entypo"} size={fontScale * 18} name={"dots-three-horizontal"} />
// //                                 </Animated.Text>
// //                             </TouchableOpacity> */}
// //                         </View>
// //                     </Animated.View>
// //                     <BorderLine marginTop={height * 0.01} style={{ height: height * 0.0005 }} backgroundColor={borderLineColor} />
// //                 </View>

// //                 {/* <Collection marginTop={height * 0.01} textColor={textColor} /> */}
// //                 <ShopTileCategories item={shop?.filters} marginTop={height * 0.01} />
// //                 <View style={{ marginHorizontal: margin.horizontal, marginTop: height * 0.02 }}>
// //                     <FlatList
// //                         data={products}
// //                         renderItem={renderProductItem}
// //                         keyExtractor={(item, index) => index.toString()}
// //                         contentContainerStyle={{ paddingBottom: height * 0.5 }}
// //                         showsVerticalScrollIndicator={false}
// //                         numColumns={2}
// //                         columnWrapperStyle={{ justifyContent: "space-between", }}

// //                     />
// //                 </View>
// //             </Animated.View>
// //             <BottomSheetBrandNotification
// //                 refRBSheet={refRBNotificationSheet}
// //                 item={shop}
// //             />
// //         </IsImage>
// //     );
// // };

// // export default TestContent;

// // const styles = StyleSheet.create({
// //     backgroundImage: {
// //         height: height * 1,
// //         width: '100%',
// //         marginTop: -WH.height('5%'),
// //     },
// //     video_view: {
// //         position: 'absolute',
// //         height: '100%',
// //         width: '100%',
// //         zIndex: 0,
// //         bottom: 0,
// //         right: 0,
// //         left: 0,
// //         top: 0,
// //     },
// //     brandTab: {
// //         flexDirection: "row",
// //         alignItems: "center",
// //         justifyContent: "space-between",
// //         marginHorizontal: margin.horizontal,
// //     },
// //     logoUrl: {
// //         width: "28%",
// //         aspectRatio: 1,
// //         borderRadius: 180
// //     },
// // });

// import { Dimensions, StyleSheet, View, TouchableOpacity, FlatList, Image } from 'react-native';
// import React, { useCallback, useRef } from 'react';
// import Animated, {
//   useSharedValue,
//   useAnimatedStyle,
//   withTiming,
//   interpolateColor,
//   useDerivedValue,
//   interpolate
// } from 'react-native-reanimated';
// import { Gesture, GestureDetector } from 'react-native-gesture-handler';
// import CustomText from '../../materialComponent/customText/customText';
// import CustomBackgoundImage from '../../materialComponent/image/bgImage';
// import {font, globalStyle, margin, WH} from '../../constant/contstant';
// import Video from 'react-native-video';
// import CustomImage from '../../materialComponent/image/image';
// import Icon from '../../materialComponent/icon/icon';
// import BorderLine from '../borderLine/borderLine';
// import Collection from './collection';
// import ShopTileCategories from '../shopTIleCategories/shopTIleCategories';
// import HomeDualCard from '../cards/homeDualCard';
// import BottomSheetBrandNotification from '../../materialComponent/bottomSheet/bottomSheetBrandNotification';
// import useReduxStore from '../../utils/hooks/useReduxStore';
// import Collection from './collection';
// import CustomButton from '../../materialComponent/customButton/customButton';
// import {navigate} from '../../utils/navigationRef/navigationRef';

// const {height, fontScale, width} = Dimensions.get('screen');

// const TestContent = ({ shop, products }) => {
//   const initialTop = height * 0.5;
//   const topValue = useSharedValue(initialTop);
//   const startTop = useSharedValue(initialTop);
//   const refRBNotificationSheet = useRef();

//   // Pan gesture handler
//   const panGesture = Gesture.Pan()
//     .onStart(() => {
//       startTop.value = topValue.value;
//     })
//     .onUpdate((e) => {
//       const newTop = Math.max(0, startTop.value + e.translationY);
//       topValue.value = newTop;
//     })
//     .onEnd((e) => {
//       if (topValue.value < initialTop - height * 0.1) {
//         topValue.value = withTiming(0, { duration: 300 });
//       } else {
//         topValue.value = withTiming(initialTop, { duration: 300 });
//       }
//     });

//   // Animated container style
//   const containerStyle = useAnimatedStyle(() => ({
//     backgroundColor: interpolateColor(
//       topValue.value,
//       [0, initialTop],
//       ['white', shop?.shop_color || '#ffffff']
//     ),
//     top: topValue.value,
//     borderTopLeftRadius: interpolate(
//       topValue.value,
//       [0, initialTop],
//       [0, 20],
//       'clamp'
//     ),
//     borderTopRightRadius: interpolate(
//       topValue.value,
//       [0, initialTop],
//       [0, 20],
//       'clamp'
//     ),
//   }));

//   // Text color interpolation
//   const textColor = useDerivedValue(() =>
//     interpolateColor(
//       topValue.value,
//       [0, initialTop],
//       ['black', 'white']
//     )
//   );

//   // Animated text style
//   const animatedTextStyle = useAnimatedStyle(() => ({
//     color: textColor.value
//   }));

//   // Bar color animation
//   const barColorStyle = useAnimatedStyle(() => ({
//     backgroundColor: interpolateColor(
//       topValue.value,
//       [0, initialTop],
//       [shop?.shop_color || '#ffffff', 'rgba(0,0,0,0.0)']
//     )
//   }));

//   // Border line color
//   const borderLineStyle = useAnimatedStyle(() => ({
//     backgroundColor: interpolateColor(
//       topValue.value,
//       [0, initialTop],
//       ['#efefef', 'rgba(0,0,0,0.0)']
//     )
//   }));

//   // Brand tab margin
//   const brandTabStyle = useAnimatedStyle(() => ({
//     marginTop: interpolate(
//       topValue.value,
//       [0, initialTop],
//       [height * 0.02, 0],
//       'clamp'
//     )
//   }));

//   const renderProductItem = useCallback(({ item }) => (
//     <HomeDualCard
//       item={item}
//       width={WH.width("43")}
//       marginRight={0}
//       color={textColor}
//     />
//   ), [textColor]);

//   const IsImage = shop?.shop_banner_type === "image" ? CustomBackgoundImage : View;

//   return (
//     <IsImage
//       style={styles.backgroundImage}
//       source={{ uri: shop?.shop_banner_url }}
//     >
//       {shop?.shop_banner_type !== "image" && (
//         <Video
//           source={{ uri: shop?.shop_banner_url }}
//           style={styles.video_view}
//           resizeMode="cover"
//           muted
//           repeat
//         />
//       )}

//       <Image
//         style={styles.logoImage}
//         resizeMode="contain"
//         source={{ uri: shop?.shop_banner_logo_url }}
//       />

//         <Animated.View style={[styles.animatedContainer, containerStyle]}>
//       <GestureDetector gesture={panGesture}>
//           <Animated.View style={[styles.bar, barColorStyle]}>
//             <View style={styles.barHandle} />
//           </Animated.View>
//           </GestureDetector>

//           <View>
//             <Animated.View style={[styles.brandTab, brandTabStyle]}>
//               <View style={globalStyle.row}>
//                 <CustomImage
//                   source={{ uri: shop?.shop_logo_url }}
//                   style={styles.logoUrl}
//                 />
//                 <View style={styles.shopInfo}>
//                   <Animated.Text style={[styles.shopName, animatedTextStyle]}>
//                     {shop?.shop_name}
//                   </Animated.Text>
//                   <View style={globalStyle.row}>
//                     <Animated.Text style={[styles.ratingText, animatedTextStyle]}>
//                       4.6
//                     </Animated.Text>
//                     <Animated.Text style={animatedTextStyle}>
//                       <Icon icon_type="AntDesign" name="star" />
//                     </Animated.Text>
//                     <Animated.Text style={[styles.ratingCount, animatedTextStyle]}>
//                       (865)
//                     </Animated.Text>
//                   </View>
//                 </View>
//               </View>

//               <View style={globalStyle.row}>
//                 <TouchableOpacity onPress={() => refRBNotificationSheet?.current?.open()}>
//                   <Animated.Text style={animatedTextStyle}>
//                     <Icon
//                       icon_type="Ionicons"
//                       size={fontScale * 18}
//                       name="notifications-outline"
//                     />
//                   </Animated.Text>
//                 </TouchableOpacity>
//               </View>
//             </Animated.View>

//             <Animated.View style={[styles.borderLine, borderLineStyle]} />
//           </View>

//           <ShopTileCategories item={shop?.filters} marginTop={height * 0.01} />

//           <View style={styles.productList}>
//             <FlatList
//               data={products}
//               renderItem={renderProductItem}
//               keyExtractor={(item, index) => index.toString()}
//               contentContainerStyle={styles.listContent}
//               showsVerticalScrollIndicator={false}
//               numColumns={2}
//               columnWrapperStyle={styles.columnWrapper}

//             />
//           </View>
//         </Animated.View>

//       <BottomSheetBrandNotification
//         refRBSheet={refRBNotificationSheet}
//         item={shop}
//       />
//     </IsImage>
//   );
// };

// export default TestContent;

// const styles = StyleSheet.create({
//   backgroundImage: {
//     height: height * 1,
//     width: '100%',
//     marginTop: -WH.height('5%'),
//   },
//   video_view: {
//     ...StyleSheet.absoluteFillObject,
//     zIndex: 0,
//   },
//   logoImage: {
//     width: width * 0.5,
//     aspectRatio: 1,
//     alignSelf: "center",
//     marginTop: height * 0.06
//   },
//   animatedContainer: {
//     position: "absolute",
//     height: height,
//     width: "100%",
//     // overflow: "hidden"
//   },
//   bar: {
//     width: "100%",
//     justifyContent: "center",
//     alignItems: "center",
//     borderBottomLeftRadius: 20,
//     borderBottomRightRadius: 20,
//     height:height*0.08
//   },
//   barHandle: {
//     width: width * 0.1,
//     height: height * 0.005,
//     backgroundColor: "white",
//     marginVertical: height * 0.03,
//     borderRadius: 180
//   },
//   brandTab: {
//     flexDirection: "row",
//     alignItems: "center",
//     justifyContent: "space-between",
//     marginHorizontal: margin.horizontal,
//   },
//   logoUrl: {
//     width: "28%",
//     aspectRatio: 1,
//     borderRadius: 180
//   },
//   shopInfo: {
//     marginLeft: "7%"
//   },
//   shopName: {
//     fontSize: fontScale * 14,
//     fontFamily: font.bold
//   },
//   ratingText: {
//     fontSize: fontScale * 9,
//     fontFamily: font.bold,
//     marginRight: 5
//   },
//   ratingCount: {
//     fontSize: fontScale * 9,
//     fontFamily: font.bold,
//     marginLeft: 5
//   },
//   borderLine: {
//     marginTop: height * 0.01,
//     height: height * 0.0005
//   },
//   productList: {
//     marginHorizontal: margin.horizontal,
//     marginTop: height * 0.02
//   },
//   listContent: {
//     paddingBottom: height * 0.38
//   },
//   columnWrapper: {
//     justifyContent: "space-between",

//   }
// });

// export default TestContent;
