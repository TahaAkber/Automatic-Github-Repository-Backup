import React from 'react';
import {
  StyleSheet,
  View,
  StatusBar,
  FlatList,
  Alert,
  ActivityIndicator,
  Dimensions,
} from 'react-native';
import {colors, globalStyle, margin, WH} from '@constant/contstant';
import {SafeAreaView} from 'react-native-safe-area-context';
import HomeFilter from '@component/homeFilter/homeFilter';
import {dashboardFilters} from '@constant/dummyData';

import SearchInput from '@component/input/searchInput';
import {dashboardCollections, homeData} from '@constant/dummyData';
import CustomText from '@materialComponent/customText/customText';
import ImageSlider from '@component/imageCarousel/imageCarousel';

import {RefreshControl} from 'react-native-gesture-handler';
import {handleScroll} from '../../../utils/helper/helper';
import useMerchantSearches from './useMerchantSearches';
import SearchedItemsLoader from '../loader/searchedItemsLoader';
import PagionationLoader from '../loader/endReachLoader';
import EmptyScreen from '../emptyScreen/emptyScreen';
import { font } from '../../constant/contstant';

const {width, height, fontScale} = Dimensions.get('screen');

const MerchantSearches = ({disabled, route}) => {
  const {
    item,
    renderProduct,
    paginationLoader,
    fetch_store_single_collection,
    fetch_store_single_collection_loader,
    fetch_store_single_collection_error,
    paginationAPI,
    fetchAPI,
    pullLoader,
  } = useMerchantSearches({route});

  return (
    <SafeAreaView
      style={{
        flex: 1,
        backgroundColor: 'white',
        paddingHorizontal: margin.horizontal,
        paddingTop: height * 0.02,
      }}>
      <StatusBar
        animated
        barStyle="dark-content"
        backgroundColor="white"
        translucent={false}
      />
      {/* <SearchInput placeholder={'Search from outfitter'} /> */}
      <View style={{marginBottom: height * 0.02}}>
        <HomeFilter
          marginTop={height * 0.02}
          fetchAPI={fetchAPI}
          screen={'trending_collection_screen'}
          removeFilters={['cloth_size', 'colors', 'shoe_size', 'brands']}
        />
      </View>
      <FlatList
        data={[item]} // Wrap `item` in an array to pass it as `data` to FlatList
        keyExtractor={(item, index) => index.toString()}
        contentContainerStyle={styles.flatListContainerWithoutImage}
        onEndReached={paginationAPI} // Add pagination handler
        onEndReachedThreshold={0.8}
        renderItem={({item}) => (
          <View>
            <CustomText
              fontFamily={font.medium}
              text={item?.trending_name || ''}
              center
              fontSize={fontScale * 20}
            />
            {/* <ImageSlider
              style={{marginVertical: 0, marginTop: height * 0.02}}
              customHeight={height * 0.25}
              customWidth={width * 0.9}
              brand={false}
            //   images={[item.shop_banner_logo] || []}
            /> */}
            {fetch_store_single_collection_loader ? (
              <SearchedItemsLoader marginTop={height * 0.025} loading={true} />
            ) : (
              <View
                style={{
                  marginTop: height * 0.025,
                  paddingBottom: height * 0.05,
                }}>
                <FlatList
                  scrollEnabled={false}
                  data={fetch_store_single_collection?.data?.products || []}
                  renderItem={renderProduct}
                  keyExtractor={(item, index) => index.toString()}
                  showsHorizontalScrollIndicator={false}
                  numColumns={2}
                  ListFooterComponent={() => {
                    return <>{paginationLoader && <PagionationLoader />}</>;
                  }}
                  ListEmptyComponent={
                    <View style={{alignItems: 'center'}}>
                      <EmptyScreen
                        removeImage={true}
                        // desc={`No products are available in the ${item.trending_name}.`}
                        // heading={`No Products Found in the ${item.trending_name}`}
                      />
                    </View>
                  }
                />
              </View>
            )}
          </View>
        )}
        refreshControl={
          <RefreshControl refreshing={pullLoader} onRefresh={fetchAPI} />
        }
        backgroundColor={colors.light_theme.themeBackgroundColor}
      />
    </SafeAreaView>
  );
};

export default MerchantSearches;

const styles = StyleSheet.create({
  flatListContainerWithoutImage: {
    paddingBottom: height * 0.03,
  },
});
