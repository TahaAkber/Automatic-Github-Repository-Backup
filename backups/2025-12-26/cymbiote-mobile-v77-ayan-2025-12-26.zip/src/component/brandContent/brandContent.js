import React, { useCallback, useEffect, useRef, useState, useMemo } from 'react';
import Animated, {
  interpolate,
  useAnimatedRef,
  useAnimatedStyle,
  useScrollViewOffset,
  useSharedValue,
  withRepeat,
  withTiming,
  Easing,
  useAnimatedScrollHandler,
  runOnJS,
  Extrapolate,
  withSpring,
  useDerivedValue,
} from 'react-native-reanimated';
import {
  Dimensions,
  StyleSheet,
  View,
  StatusBar,
  FlatList,
  Text,
} from 'react-native';
import CustomBackgoundImage from '../../materialComponent/image/bgImage';
import { isAndroid, margin, WH } from '../../constant/contstant';
import HomeDualCard from '../cards/homeDualCard';
import BottomSheetBrandNotification from '../../materialComponent/bottomSheet/bottomSheetBrandNotification';
import { useDispatch } from 'react-redux';
import useReduxStore from '../../utils/hooks/useReduxStore';
import {
  _getFilteredByCollectionId,
  _storeFollowingUpdateStatus,
} from '../../redux/actions/merchant/merchant';
import { _getStories } from '../../redux/actions/reels/reels';

import BrandTab from '../brandTab/brandTab';
import StickyFilters from './brandContentStickyHeader';
import HeaderBlock from './headerBlock';
import MyTabView from '../tabView/testingTabView';
import BrandContentProducts from './brandContentProducts';
import ShopTileCategories from '../shopTIleCategories/shopTIleCategories';
import { navigate } from '../../utils/navigationRef/navigationRef';

import PagionationLoader from '../loader/endReachLoader';
import TabHeader from '../tabView/tabHeader';
import TabContent from '../tabView/tabContent';
import EmptyScreen from '../emptyScreen/emptyScreen';
import { triggerHaptic } from '../../utils/haptic/haptic';
import {
  logBrandProductClickEvent,
  logBrandFollowActionEvent,
  logBrandReelsClickEvent,
  logBrandSearchClickEvent,
  logBrandCollectionChangeEvent,
  logBrandSkippedProductsEvent,
  logBrandProductViewEvent,
} from '../../helper/eventTriggers/useEventTriggers';

const { height, width } = Dimensions.get('screen');
const IMG_HEIGHT = 300;

const BrandContent = ({
  shop,
  upadatedShop,
  products,
  shopsReels,
  handleSelectCollection,
  selectedCollectionId,
  collectionProducts,
  collectionLoading,
  paginationAPI,
  sub_category,
  showProducts,
  paginationLoader,
  setCollectionLoading,
  selectedSubCategory,
}) => {
  const dispatch = useDispatch();
  const { getState } = useReduxStore();
  const [animationDuration, setAnimationDuration] = useState(3000);

  console.log('shopsReels', shopsReels);
  const [loading, setLoading] = useState(false);

  const rotation = useSharedValue(0);
  const { fetch_user_detail } = getState('auth');

  const isLoggedIn = Array.isArray(fetch_user_detail)
    ? fetch_user_detail.length > 0
    : !!(fetch_user_detail?.id ?? fetch_user_detail?.user_id);
  const {
    fetch_store_following_list_local,
    fetch_store_following_list,
    fetch_store_product_detail_loader,
    fetch_store_collection,
    fetch_store_collection_loader,
  } = getState('merchant');

  console.log('Local following list:', fetch_store_following_list_local);
  console.log('Server following list:', fetch_store_following_list);

  const liveStores = fetch_store_following_list?.data?.map(
    el => el?.shop_detail?.shop_id,
  );
  const localStores = fetch_store_following_list_local.map(el => el.shop_id);
  const finalArray = [...liveStores, ...localStores];

  console.log('Combined follow array:', finalArray);
  console.log('Current shop ID:', shop?.shop_id);

  // State for follow status
  const [isRotating, setIsRotating] = useState(false);

  const [isFollowing, setIsFollowing] = useState(false);

  const animatedRingStyle = useAnimatedStyle(() => {
    const rotate = interpolate(rotation.value, [0, 1], [0, 360]);
    return {
      transform: [{ rotate: `${rotate}deg` }],
    };
  });

  // Start rotation animation
  const startRingAnimation = () => {
    setIsRotating(true);
    rotation.value = 0; // Reset the shared value

    // Start rotating the ring indefinitely
    rotation.value = withRepeat(
      withTiming(1, {
        duration: animationDuration,
        easing: Easing.linear,
      }),
      -1, // -1 means infinite repeats
      false, // Do not reverse
    );

    loadStories();
  };

  const loadStories = async () => {
    const startTime = performance.now();
    setLoading(true);
    try {
      const userId = fetch_user_detail?.id;
      await dispatch(_getStories({ shopId: shop.shop_id, userId }));
      const endTime = performance.now();
      const apiDuration = endTime - startTime;
      setAnimationDuration(apiDuration);

      rotation.value = withTiming(rotation.value); // Stop current animation
      setIsRotating(false);

      navigate('Stories', { from: 'popup' });
    } catch (error) {
      console.log('Error fetching stories:', error);
      setIsRotating(false);
    } finally {
      setLoading(false);
    }
  };

  const filterOptions = upadatedShop?.filters?.length
    ? [
      { filter_option_id: 'ALL', filter_option_value: 'All' },
      ...(upadatedShop?.filters || []),
    ]
    : [];

  useEffect(() => {
    setIsFollowing(finalArray.includes(shop?.shop_id));
  }, [finalArray.length, shop?.shop_id]);

  const _handleNavigatetoReels = () => {
    // Track reels navigation click
    logBrandReelsClickEvent(shop, shopsReels?.videos?.length || 0);

    navigate('Reels', {
      shopId: shop.shop_id,
    });
  };

  const handleFollow = async () => {
    try {
      console.log('Toggling follow status. Current status:', isFollowing);
      const newFollowStatus = !isFollowing;

      const response = await dispatch(
        _storeFollowingUpdateStatus(
          shop?.shop_id,
          newFollowStatus,
          shop,
          false,
          false,
          true,
        ),
      );

      console.log('Follow action response:', response);

      setIsFollowing(newFollowStatus);
      console.log('Updated follow status in UI:', newFollowStatus);

      // Track follow/unfollow action
      logBrandFollowActionEvent(
        shop,
        newFollowStatus ? 'follow' : 'unfollow',
        true,
      );
    } catch (error) {
      console.log('Follow error:', error?.message);
      console.log('Reverting follow status due to error');
      setIsFollowing();
    }
  };

  const refRBNotificationSheet = useRef();

  // Analytics tracking state
  const clickedProductIdsRef = useRef([]);
  const viewedProductIdsRef = useRef([]);
  const displayedProductsRef = useRef([]);
  const currentCollectionRef = useRef({ id: null, name: 'All' });
  const productViewTimestampsRef = useRef({}); // {product_id: {startTime, product, position}}

  const handleProductClick = useCallback(
    (product, index) => {
      console.log('🎯 [DEBUG] handleProductClick called with:', {
        productId: product?.product_id,
        productName: product?.product_name,
        index,
        shopId: shop?.shop_id,
        shopName: shop?.shop_name,
        collectionId: currentCollectionRef.current.id,
        collectionName: currentCollectionRef.current.name,
      });

      if (product?.product_id) {
        if (!clickedProductIdsRef.current.includes(product.product_id)) {
          clickedProductIdsRef.current.push(product.product_id);
        }
        console.log('🎯 [DEBUG] About to call logBrandProductClickEvent');
        logBrandProductClickEvent(
          product,
          shop,
          index,
          currentCollectionRef.current.id,
          currentCollectionRef.current.name,
        );
      } else {
        console.log('❌ [DEBUG] Product has no product_id, skipping analytics');
      }
    },
    [shop],
  );

  const renderProductItem = useCallback(
    (item, index) => {
      console.log('index ==>', index);

      // Track displayed products
      if (
        item?.item?.product_id &&
        !displayedProductsRef.current.find(
          p => p.product_id === item.item.product_id,
        )
      ) {
        displayedProductsRef.current.push(item.item);
      }

      return (
        <View key={index} style={{}}>
          <HomeDualCard
            item={item.item}
            width={WH.width('44')}
            color={shop?.shop_font_color}
            brandScreen={true}
            onPress={() => handleProductClick(item.item, index)}
          />
        </View>
      );
    },
    [showProducts?.length, shop, handleProductClick],
  );

  // Handle product viewability changes for analytics
  const handleViewableItemsChanged = useCallback(
    ({ viewableItems, changed }) => {
      changed.forEach(({ item, isViewable, index }) => {
        const product = item?.item || item;
        const productId = product?.product_id;

        if (!productId) return;

        if (isViewable) {
          // Product entered viewport - start tracking view time
          if (!productViewTimestampsRef.current[productId]) {
            console.log(
              `👁️ [VIEW TRACKING] Product entered viewport: ${product.product_name}`,
            );
            productViewTimestampsRef.current[productId] = {
              startTime: Date.now(),
              product: product,
              position: index,
            };
          }
        } else {
          // Product exited viewport - calculate view duration and log event
          const viewData = productViewTimestampsRef.current[productId];
          if (viewData) {
            const viewDuration = (Date.now() - viewData.startTime) / 1000;
            console.log(
              `👁️ [VIEW TRACKING] Product exited viewport: ${product.product_name
              }, duration: ${viewDuration.toFixed(2)}s`,
            );

            // Add to viewed products if not already there
            if (!viewedProductIdsRef.current.includes(productId)) {
              viewedProductIdsRef.current.push(productId);
            }

            // Log product view event
            logBrandProductViewEvent(
              viewData.product,
              shop,
              viewData.position,
              viewDuration,
              currentCollectionRef.current.id,
              currentCollectionRef.current.name,
            );

            // Clean up timestamp
            delete productViewTimestampsRef.current[productId];
          }
        }
      });
    },
    [shop],
  );

  const viewabilityConfig = useRef({
    itemVisiblePercentThreshold: 50, // Product must be 50% visible to count as viewed
    minimumViewTime: 500, // Must be visible for at least 500ms
  }).current;

  console.log('SHOW DATA', showProducts?.length);

  const scrollRef = useAnimatedRef();
  const scrollOffset = useScrollViewOffset(scrollRef);

  const imageAnimatedStyle = useAnimatedStyle(() => {
    return {
      transform: [
        {
          translateY: interpolate(
            scrollOffset.value,
            [-IMG_HEIGHT, 0, IMG_HEIGHT],
            [-IMG_HEIGHT / 2, 0, IMG_HEIGHT * 0.2],
          ),
        },
        {
          scale: interpolate(
            scrollOffset.value,
            [-IMG_HEIGHT, 0, IMG_HEIGHT],
            [2, 1, 2],
          ),
        },
      ],
    };
  });

  const headeterAniamtedStyle = useAnimatedStyle(() => {
    return {
      opacity: interpolate(scrollOffset.value, [0, IMG_HEIGHT], [0, 1]),
    };
  });

  const handlePress = () => {
    // Track brand search click
    logBrandSearchClickEvent(shop, products?.length || 0);

    navigate('BrandSearch', {
      brandName: shop?.shop_name,
      brandProducts: products,
      shop_id: shop?.shop_id,
    });
  };

  const sections = useMemo(
    () => [
      'HEADER', // collections + reels
      'STICKY', // ✅ your filters block (will stick)
      'CONTENT', // products (nested FlatList)
    ],
    [],
  );

  const safeFilterOptions = Array.isArray(filterOptions) ? filterOptions : [];
  const safeProducts = Array.isArray(products) ? products : [];
  const safeCollectionProducts = Array.isArray(collectionProducts)
    ? collectionProducts
    : [];

  const dataToShow = useMemo(() => {
    return selectedCollectionId ? safeCollectionProducts : safeProducts;
  }, [selectedCollectionId, safeCollectionProducts, safeProducts]);

  const TABS = useMemo(() => {
    return safeFilterOptions.map((item, index) => ({
      key: `${index}`,
      title: item?.filter_option_value,
      filter_option_id: item?.filter_option_id,
    }));
  }, [safeFilterOptions]);

  const [selectedTab, setSelectedTab] = useState(0);
  const [tabWidths, setTabWidths] = useState([]);
  const flatListRef = useRef(null);
  const scrollViewRef = useRef(null);
  const scrollX = useSharedValue(0);
  const lastFilterIdRef = useRef(null);

  const centerActiveTab = index => {
    if (!scrollViewRef.current || !tabWidths[index]) return;
    const screenCenter = width / 2;
    const scrollTo =
      tabWidths.slice(0, index).reduce((a, b) => a + b, 0) +
      tabWidths[index] / 2 -
      screenCenter;
    scrollViewRef.current.scrollTo({
      x: Math.max(0, scrollTo),
      animated: true,
    });
  };

  // const handleTabPress = useCallback(
  //   index => {
  //     if (!fetch_store_product_detail_loader && !collectionLoading) {
  //       console.log('index', index);
  //       index != 0 && setCollectionLoading(true);
  //       scrollX.value = withTiming(index * width, {
  //         duration: 300, // Adjust duration as needed for smoothness
  //         easing: Easing.out(Easing.quad), // Use a smooth easing function
  //       });
  //       setSelectedTab(index);
  //       flatListRef.current?.scrollToOffset({
  //         offset: index * width,
  //         animated: false,
  //       });
  //       centerActiveTab(index);
  //     }
  //   },
  //   [centerActiveTab, scrollX, width],
  // );

  const handleTabPress = useCallback(
    index => {
      if (!fetch_store_product_detail_loader && !collectionLoading) {
        setSelectedTab(index);
        scrollX.value = withTiming(index * width, {
          duration: 300,
          easing: Easing.out(Easing.quad),
        });
        flatListRef.current?.scrollToOffset({
          offset: index * width,
          animated: false,
        });
        centerActiveTab(index);
      }
    },
    [centerActiveTab, width],
  );

  const onScroll = useAnimatedScrollHandler({
    onScroll: event => {
      scrollX.value = event.contentOffset.x;
    },
    onMomentumEnd: event => {
      const index = Math.round(event.contentOffset.x / width);
      runOnJS(setSelectedTab)(index);
      runOnJS(centerActiveTab)(index);
    },
  });

  const underlineStyle = useAnimatedStyle(() => {
    if (tabWidths.length !== TABS.length || TABS.length < 2) {
      return {
        width: tabWidths[0] || 0, // fallback for single tab
        transform: [{ translateX: 0 }],
      };
    }
    const translateX = interpolate(
      scrollX.value,
      TABS.map((_, i) => i * width),
      TABS.map((_, i) => tabWidths.slice(0, i).reduce((a, b) => a + b, 0)),
    );
    const w = interpolate(
      scrollX.value,
      TABS.map((_, i) => i * width),
      TABS.map((_, i) => tabWidths[i] || 0),
    );
    return {
      transform: [{ translateX }],
      width: w,
    };
  });

  useEffect(() => {
    if (safeFilterOptions.length === 0) return;
    const currentId = safeFilterOptions[selectedTab]?.filter_option_id;
    if (!currentId) return;
    if (lastFilterIdRef.current !== currentId) {
      const previousCollection = currentCollectionRef.current;
      const newCollection = {
        id: currentId,
        name: safeFilterOptions[selectedTab]?.filter_option_value || 'All',
      };

      // Log any remaining products that are still in viewport before changing collection
      Object.keys(productViewTimestampsRef.current).forEach(productId => {
        const viewData = productViewTimestampsRef.current[productId];
        if (viewData) {
          const viewDuration = (Date.now() - viewData.startTime) / 1000;
          console.log(
            `👁️ [COLLECTION CHANGE] Logging remaining viewed product: ${viewData.product.product_name}`,
          );

          // Add to viewed products if not already there
          if (!viewedProductIdsRef.current.includes(productId)) {
            viewedProductIdsRef.current.push(productId);
          }

          // Log product view event
          logBrandProductViewEvent(
            viewData.product,
            shop,
            viewData.position,
            viewDuration,
            previousCollection.id,
            previousCollection.name,
          );
        }
      });

      // Log skipped products before changing collection
      if (displayedProductsRef.current.length > 0) {
        logBrandSkippedProductsEvent(
          shop,
          displayedProductsRef.current,
          viewedProductIdsRef.current,
          clickedProductIdsRef.current,
          previousCollection.id,
          previousCollection.name,
        );
      }

      // Log collection change
      logBrandCollectionChangeEvent(
        shop,
        previousCollection,
        newCollection,
        dataToShow?.length || 0,
        clickedProductIdsRef.current,
      );

      // Reset tracking state for new collection
      displayedProductsRef.current = [];
      viewedProductIdsRef.current = [];
      clickedProductIdsRef.current = [];
      productViewTimestampsRef.current = {};
      currentCollectionRef.current = newCollection;

      lastFilterIdRef.current = currentId;
      handleSelectCollection?.(currentId, false);
    }
  }, [
    selectedTab,
    safeFilterOptions,
    handleSelectCollection,
    shop,
    dataToShow?.length,
  ]);

  const HEADER_MAX = height * 0.12;
  const START_DELAY = 400; // px to scroll before header starts animating
  const REVEAL_DISTANCE = 180; // longer distance = smoother/gradual
  const SMOOTH_MS = 180;
  const scrollY = useSharedValue(0);

  const scrollHandler = useAnimatedScrollHandler({
    onScroll: event => {
      scrollY.value = event.contentOffset.y;
    },
  });

  const smoothY = useDerivedValue(() =>
    withTiming(scrollY.value, {
      duration: SMOOTH_MS,
      easing: Easing.out(Easing.cubic),
    }),
  );

  const headerAnimatedStyle = useAnimatedStyle(() => {
    // delay the start, then interpolate over a longer range
    const h = interpolate(
      smoothY.value,
      [START_DELAY, START_DELAY + REVEAL_DISTANCE],
      [0, HEADER_MAX],
      Extrapolate.CLAMP,
    );

    const translateY = interpolate(
      smoothY.value,
      [START_DELAY, START_DELAY + REVEAL_DISTANCE],
      [-HEADER_MAX, 0],
      Extrapolate.CLAMP,
    );

    return {
      height: h,
      transform: [{ translateY }],
    };
  });

  const hasTriggered = useSharedValue(false);

  const onHeaderFullyRevealed = () => {
    triggerHaptic();
  };

  useDerivedValue(() => {
    const h = interpolate(
      smoothY.value,
      [START_DELAY, START_DELAY + REVEAL_DISTANCE],
      [0, HEADER_MAX],
      Extrapolate.CLAMP,
    );

    if (h >= HEADER_MAX && !hasTriggered.value) {
      hasTriggered.value = true;
      runOnJS(onHeaderFullyRevealed)();
    } else if (h < HEADER_MAX && hasTriggered.value) {
      // reset when collapsed again, so next time expansion can trigger
      hasTriggered.value = false;
    }
  });

  // Cleanup: log remaining viewed products and skipped products when user leaves the brand page
  useEffect(() => {
    return () => {
      // Log any remaining products that are still in viewport
      Object.keys(productViewTimestampsRef.current).forEach(productId => {
        const viewData = productViewTimestampsRef.current[productId];
        if (viewData) {
          const viewDuration = (Date.now() - viewData.startTime) / 1000;
          console.log(
            `👁️ [CLEANUP] Logging remaining viewed product: ${viewData.product.product_name}`,
          );

          // Add to viewed products if not already there
          if (!viewedProductIdsRef.current.includes(productId)) {
            viewedProductIdsRef.current.push(productId);
          }

          // Log product view event
          logBrandProductViewEvent(
            viewData.product,
            shop,
            viewData.position,
            viewDuration,
            currentCollectionRef.current.id,
            currentCollectionRef.current.name,
          );
        }
      });

      // Log skipped products
      if (displayedProductsRef.current.length > 0) {
        logBrandSkippedProductsEvent(
          shop,
          displayedProductsRef.current,
          viewedProductIdsRef.current,
          clickedProductIdsRef.current,
          currentCollectionRef.current.id,
          currentCollectionRef.current.name,
        );
      }
    };
  }, [shop]);

  console.log('filterOptions ====>', filterOptions);

  return (
    <View style={[styles.container, { backgroundColor: shop?.shop_color }]}>
      <StatusBar translucent backgroundColor="transparent" />
      <Animated.View
        style={[styles.header, headerAnimatedStyle, { overflow: 'hidden' }]}>
        <BrandTab
          item={upadatedShop}
          disabledDots={false}
          disabled={true}
          mainViewStyle={{
            marginHorizontal: margin.horizontal,
            marginTop: width * 0.04,
          }}
          dot={true}
          showBellIcon={isLoggedIn}
          showSearchIcon={true}
          onSearchPress={() => handlePress()}
          onBellPress={
            isLoggedIn
              ? () => refRBNotificationSheet?.current?.open()
              : undefined
          }
          shopNameFontSize={15}
          id={shop?.shop_id}
          shop={true}
        />
      </Animated.View>

      <Animated.FlatList
        ref={scrollRef}
        data={sections}
        keyExtractor={k => k}
        renderItem={({ item }) => {
          if (item === 'HEADER')
            return (
              <>
                <HeaderBlock
                  IMG_HEIGHT={IMG_HEIGHT}
                  imageAnimatedStyle={imageAnimatedStyle}
                  shop={shop}
                  onSearchPress={() => handlePress()}
                  startRingAnimation={startRingAnimation}
                  _handleNavigatetoReels={_handleNavigatetoReels}
                  animatedRingStyle={animatedRingStyle}
                  upadatedShop={upadatedShop}
                  handleFollow={handleFollow}
                  isFollowing={isFollowing}
                  isLoggedIn={isLoggedIn}
                  refRBNotificationSheet={refRBNotificationSheet}
                  fetch_store_product_detail_loader={
                    fetch_store_collection_loader
                  }
                  fetch_store_collection={fetch_store_collection}
                  fetch_store_collection_loader={fetch_store_collection_loader}
                  shopsReels={shopsReels}
                />
              </>
            );
          if (item === 'STICKY') {
            return (
              <Animated.View
                style={[{ zIndex: 22, backgroundColor: 'white', paddingTop: 2 }]}>
                {/* <StickyFilters
                  filterOptions={filterOptions}
                  selectedCollectionId={selectedCollectionId}
                  collectionProducts={collectionProducts}
                  products={products}
                  fetch_store_product_detail_loader={
                    fetch_store_product_detail_loader
                  }
                  collectionLoading={collectionLoading}
                  paginationLoader={PagionationLoader}
                  shop={shop}
                  handleSelectCollection={handleSelectCollection}
                  sub_category={sub_category}
                  showProducts={showProducts}
                />   */}
                {Array.isArray(filterOptions) && filterOptions.length > 0 ? (
                  <TabHeader
                    TABS={filterOptions.map((f, i) => ({
                      key: `${i}`,
                      title: f.filter_option_value,
                      filter_option_id: f.filter_option_id,
                    }))}
                    selectedTab={selectedTab}
                    scrollX={scrollX}
                    tabWidths={tabWidths}
                    setTabWidths={setTabWidths}
                    scrollViewRef={scrollViewRef}
                    handleTabPress={handleTabPress}
                    underlineStyle={underlineStyle}
                    handleSelectCollection={handleSelectCollection}
                    sub_category={sub_category}
                    selectedCollectionId={selectedCollectionId}
                  />
                ) : (
                  <View>
                    <ShopTileCategories
                      marginTop={height * -0.02}
                      item={[]}
                      onSelect={handleSelectCollection}
                      subCategory={sub_category}
                      selectedCollectionId={selectedCollectionId}
                    />
                  </View>
                )}
              </Animated.View>
            );
          }
          if (item === 'CONTENT') {
            return (
              <View style={{ backgroundColor: 'white' }}>
                {Array.isArray(filterOptions) && filterOptions.length > 0 ? (
                  <TabContent
                    TABS={filterOptions.map((f, i) => ({
                      key: `${i}`,
                      title: f.filter_option_value,
                      filter_option_id: f.filter_option_id,
                    }))}
                    DATA={dataToShow}
                    selectedTab={selectedTab}
                    loader={
                      fetch_store_product_detail_loader || collectionLoading
                    }
                    renderItem={renderProductItem}
                    setCollectionLoading={setCollectionLoading}
                    flatListRef={flatListRef}
                    onScroll={onScroll}
                    paginationLoader={paginationLoader}
                    selectedSubCategory={selectedSubCategory}
                    onViewableItemsChanged={handleViewableItemsChanged}
                    viewabilityConfig={viewabilityConfig}
                  />
                ) : (
                  <View>
                    <BrandContentProducts
                      shop={shop}
                      loader={
                        fetch_store_product_detail_loader || collectionLoading
                      }
                      data={showProducts}
                      paginationLoader={paginationLoader}
                      selectedCollectionId={selectedCollectionId}
                      selectedSubCategory={selectedSubCategory}
                      key={selectedSubCategory}
                    />
                  </View>
                )}
              </View>
            );
          }
        }}
        contentContainerStyle={{ paddingBottom: 20 }} // optional
        stickyHeaderIndices={[1]} // header = 0, sticky filters = 1
        // onScroll={onScroll}
        scrollEventThrottle={16}
        showsVerticalScrollIndicator={false}
        onEndReached={paginationAPI}
        onEndReachedThreshold={0.5}
        removeClippedSubviews
        initialNumToRender={5}
        windowSize={7}
        maxToRenderPerBatch={10}
        onScroll={scrollHandler}
      />

      <BottomSheetBrandNotification
        refRBSheet={refRBNotificationSheet}
        item={shop}
        height={height * 0.4}
      />
    </View>
  );
};

export default BrandContent;

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    // position: 'absolute',
    // top: 0,
    // left: 0,
    // right: 0,
    height: 0, // Height of the header
    backgroundColor: '#fff',
    borderBottomColor: '#ccc',
    zIndex: 10,
    justifyContent: 'flex-end',
    alignItems: 'center',
    paddingBottom: 0,
    paddingTop: 0,
  },
});
