import {_getStores, _getStoreProducts} from '@redux/actions/merchant/merchant';
import {useCallback, useEffect, useMemo, useState} from 'react';
import HomeDualCard from '@component/cards/homeDualCard';
import {_recentViewed} from '@redux/actions/user/user';
import useReduxStore from '@utils/hooks/useReduxStore';
import {pagination} from '@utils/helper/helper';
import {WH} from '@constant/contstant';
import {View} from 'react-native';
import { _getTrendingSingleCollection } from '../../redux/actions/merchant/merchant';


const useMerchantSearches = ({route}) => {
  const {item} = route?.params || [];
  const {dispatch, getState} = useReduxStore();
  const {
    fetch_store_single_collection,
    fetch_store_single_collection_loader,
    fetch_store_single_collection_error,
  } = getState('merchant');

  const [page, setPage] = useState(1);
  const [paginationLoader, setPaginationLoader] = useState(false);
  const [pullLoader, setPullLoader] = useState(false);

  const renderProduct = useCallback(({item}) => {
    return (
      <View style={{marginRight: WH.width('2')}}>
        <HomeDualCard item={item} width={WH.width('43')} color={'black'} />
      </View>
    );
  }, []);

  const fetchAPI = loading => {
    !loading && setPullLoader(true);
    dispatch(_getTrendingSingleCollection(item?.trending_id, 1));
    setPage(1);
    setPullLoader(false);
  };

  const paginationAPI = async () => {
    if (!paginationLoader) {
      const totalPages = fetch_store_single_collection?.data?.totalPages;
      const nextPagination = pagination(page, totalPages);
      if (nextPagination) {
        setPaginationLoader(true);
        const response = await dispatch(
          _getTrendingSingleCollection(item?.trending_id, nextPagination),
        );
        setPage(nextPagination);
        setPaginationLoader(false);
      }
    }
  };

  useEffect(() => {
    fetchAPI(true);
  }, []);
  return {
    item,
    paginationLoader,
    renderProduct,
    fetch_store_single_collection,
    fetch_store_single_collection_loader,
    fetch_store_single_collection_error,
    paginationAPI,
    fetchAPI,
    pullLoader,
  };
};

export default useMerchantSearches;
