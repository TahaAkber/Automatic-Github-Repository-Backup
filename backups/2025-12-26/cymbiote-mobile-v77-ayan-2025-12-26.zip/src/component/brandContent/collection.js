import React, {useCallback} from 'react';
import {
  Animated,
  Dimensions,
  FlatList,
  StyleSheet,
  TouchableOpacity,
  View,
} from 'react-native';
import {font, margin} from '@constant/contstant';
import CustomImage from '@materialComponent/image/image';
import {useNavigation} from '@react-navigation/native';
import {WH} from '../../constant/contstant';
import CollectionLoader from '../loader/collectionLoader';

const {fontScale, height, width} = Dimensions.get('screen');

const Collection = ({
  textColor,
  marginTop,
  collection,
  loading,
  paddingTop,
  marginBottom,
}) => {
  const navigation = useNavigation();

  const renderItem = useCallback(({item, index}) => {
    return (
      <TouchableOpacity
        activeOpacity={1}
        onPress={() =>
          navigation.navigate('BrandCollection', {
            item,
          })
        }
        style={[
          styles.collectionCard,
          // collection?.length == 2 && {width: width * 0.44},
        ]}>
        <CustomImage
          style={[
            styles.image,
            // collection?.length == 2 && {width: width * 0.44},
          ]}
          source={{uri: item.collection_banner_url}}
        />
        <Animated.Text
          numberOfLines={1}
          style={{
            fontSize:
              // : collection?.length == 2 ? fontScale * 14 :
              fontScale * 12,
            color: textColor,
            fontFamily: font.medium,
            marginTop: height * 0.007,
            marginLeft: width * 0.02,
          }}>
          {item.collection_name}
        </Animated.Text>
      </TouchableOpacity>
    );
  }, []);

  return collection?.length ? (
    <View
      style={[
        styles.mainView,
        {marginTop: marginTop || height * 0.02, paddingTop, marginBottom},
      ]}>
      <View style={{marginHorizontal: margin.horizontal}}>
        <Animated.Text
          style={{
            fontSize: fontScale * 20,
            color: textColor,
            fontFamily: font.bold,
            marginTop: height * 0.007,
          }}>
          {'Collections'}
        </Animated.Text>
      </View>
      <View style={styles.collections}>
        {/* {loading ? (
          <CollectionLoader />
        ) : (  */}
        <FlatList
          data={collection}
          renderItem={renderItem}
          keyExtractor={(item, index) => index.toString()}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{paddingHorizontal: margin.horizontal}}
          horizontal
        />
        {/* )} */}
      </View>
    </View>
  ) : (
    <></>
  );
};

export default Collection;

const styles = StyleSheet.create({
  mainView: {
    marginTop: height * 0.02,
  },
  collections: {
    marginTop: height * 0.02,
  },
  image: {
    width: WH.width(40),
    height: WH.width(30),
    borderRadius: 10,
  },
  collectionCard: {
    width: WH.width(40),
    marginRight: width * 0.03,
  },
});
