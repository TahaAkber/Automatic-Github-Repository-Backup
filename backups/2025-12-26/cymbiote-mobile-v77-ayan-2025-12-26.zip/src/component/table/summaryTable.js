import React from 'react';
import { Dimensions, StyleSheet, View } from 'react-native';
import CustomText from '@materialComponent/customText/customText';
import { font } from '@constant/contstant';

const { fontScale, height, width } = Dimensions.get('screen');

const SummaryTable = ({ label, value, marginTop, summary, fontFamily, fontSize }) => {
    return (
        <View style={[styles.container, { marginTop }, summary && { flexDirection: "column", }]}>
            <CustomText fontFamily={fontFamily} style={[styles.text, fontSize && { fontSize }]} text={`${label} :`} />
            <CustomText fontFamily={fontFamily} style={[styles.text, summary && { marginTop: height * 0.01, fontFamily: font.regular }, fontSize && { fontSize }]} text={value} />
        </View>
    );
};

export default SummaryTable;

const styles = StyleSheet.create({
    container: {
        flexDirection: 'row',
        // alignItems: 'center',
        justifyContent: "space-between",
    },
    text: {
        fontFamily: font.medium,
        color: "black",
        fontSize: fontScale * 15,
    }
});
