import React, { forwardRef, useState } from "react";
import { View, StyleSheet, TextInput, TouchableOpacity,Dimensions } from "react-native";
import CustomText from "../../materialComponent/customText/customText";
import Icon from "../../materialComponent/icon/icon";
import { colors, font, margin } from "../../constant/contstant";
import CustomButton from "../../materialComponent/customButton/customButton";
import GorhomBottomSheet from "../../materialComponent/bottomSheet/GorhomBottomSheet";

const { fontScale, height, width } = Dimensions.get("screen")           
const RatingBottomSheet = forwardRef(({ onSubmit,onShowSummary }, ref) => {
    const [rating, setRating] = useState(0);
    const [comment, setComment] = useState("");

    const handleRating = (index) => {
        setRating(index + 1 === rating ? 0 : index + 1);
    };
const handleSubmit = () => {
        onSubmit(rating);
        onShowSummary();
    };

    return (
        <GorhomBottomSheet
            ref={ref}
            height={350}
            customStyles={{ container: styles.bottomSheet }}
            closeOnDragDown={true}
            closeOnPressMask={true}
        >
            <CustomText text={"Rate Our Service"} fontSize={fontScale * 28} fontFamily={font.bold} />
             <View style={styles.ratingContainer}>
                                        {[...Array(5)].map((_, index) => (
                                            <TouchableOpacity key={index} onPress={() => handleRating(index)}>
                                              <Icon
                            name={index < rating ? "star" : "star-o"} 
                            size={40}
                            color="#ECA61B" 
                            icon_type="FontAwesome"
                            style={styles.icon}
                        />
                                      
                                            </TouchableOpacity>  ))}
                                        </View>
                                        <TextInput 
                style={styles.commentBox} 
                placeholder="Your Comment..." 
                placeholderTextColor="#A9A9A9"
                value={comment}
                onChangeText={setComment}
                multiline
                textAlignVertical="top"
                
            />
            
            <CustomButton text={"Submit"} buttonStyle={styles.nextButton} marginTop={"5%"} onPress={handleSubmit}/>
        </GorhomBottomSheet>
    );
});

const styles = StyleSheet.create({
    bottomSheet: { padding: "7%",borderTopEndRadius:20,borderTopStartRadius:20 },
    ratingContainer: { flexDirection: "row", justifyContent: "flex-start", marginVertical: 10, },
    commentBox: { borderWidth: 1, borderColor: "#ddd", padding: 10, marginVertical: 10, borderRadius: 5 ,height:height * 0.15,color:"black",backgroundColor:"white"},
    submitButton: { backgroundColor: colors.dark_theme.theme, padding: 10, alignItems: "center", borderRadius: 5 },
    icon:{marginHorizontal:"2%",}
});

export default RatingBottomSheet;
