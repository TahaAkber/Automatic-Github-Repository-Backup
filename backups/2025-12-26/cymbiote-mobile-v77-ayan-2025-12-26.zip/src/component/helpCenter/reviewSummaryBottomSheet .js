import React, {forwardRef} from 'react';
import {View, StyleSheet, Image, Dimensions} from 'react-native';

import {font, margin} from '../../constant/contstant';
import CustomText from '../../materialComponent/customText/customText';
import Icon from '../../materialComponent/icon/icon';
import CustomImage from '../../materialComponent/image/image';
import images from '../../assets/images/images';
import GorhomBottomSheet from '../../materialComponent/bottomSheet/GorhomBottomSheet';

const {fontScale, height, width} = Dimensions.get('screen');
const ReviewSummaryBottomSheet = forwardRef(({rating}, ref) => {
  return (
    <GorhomBottomSheet
      ref={ref}
      height={280}
      customStyles={{container: styles.bottomSheet}}
      closeOnDragDown={true}
      closeOnPressMask={true}>
      <View style={styles.transparentOverlay} />
      <View style={styles.contentContainer}>
        <View style={styles.checkCircle}>
          <Image source={require('../../assets/images/check.png')} />
        </View>

        <CustomText
          text={'Done!'}
          fontSize={fontScale * 28}
          fontFamily={font.bold}
          style={styles.doneText}
        />
        <CustomText
          text={'Thank you for your review'}
          fontSize={16}
          fontFamily={font.medium}
          style={styles.thankText}
        />
        <View style={styles.ratingContainer}>
          {[...Array(5)].map((_, index) => (
            <Icon
              key={index}
              name={index < rating ? 'star' : 'star-o'}
              size={35}
              color="#ECA61B"
              icon_type="FontAwesome"
              style={styles.icon}
            />
          ))}
        </View>
      </View>
    </GorhomBottomSheet>
  );
});

const styles = StyleSheet.create({
  bottomSheet: {
    paddingBottom: 20,
    alignItems: 'center',
    borderTopStartRadius: 20,
    borderTopEndRadius: 20,
    backgroundColor: 'transparent',
  },
  transparentOverlay: {
    height: height * 0.12, // Controls the transparency at the top
    // backgroundColor: "transparent",
  },
  contentContainer: {
    width: '100%',
    backgroundColor: 'white',
    alignItems: 'center',
    borderTopStartRadius: 20,
    borderTopEndRadius: 20,
    paddingTop: 50,
    paddingBottom: 20,
  },
  checkCircle: {
    width: 55,
    height: 55,
    borderRadius: 27.5,
    // backgroundColor: "#4385F4",
    alignItems: 'center',
    justifyContent: 'center',
    position: 'absolute',
    top: -27,
    shadowColor: '#000',
    shadowOffset: {width: 0, height: 4},
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 6,
  },
  icon: {marginHorizontal: '2%'},

  doneText: {textAlign: 'center', fontSize: 22, color: 'black'},
  thankText: {marginTop: 5, textAlign: 'center', color: '#777'},
  ratingContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 10,
  },
});

export default ReviewSummaryBottomSheet;
