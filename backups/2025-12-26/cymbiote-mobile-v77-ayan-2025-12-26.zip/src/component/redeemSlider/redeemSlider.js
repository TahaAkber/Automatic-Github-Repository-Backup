import React, {useRef, useState} from 'react';
import {View, Text, StyleSheet, Image} from 'react-native';
import Slider from '@react-native-community/slider';
import {Dimensions} from 'react-native';
import RewardSvg from '@assets/images/reward.svg';
import {shadow} from '@constant/contstant';
import CustomText from '@materialComponent/customText/customText';
import {toFixedMethod, toFixedMethod2} from '../../utils/helper/helper';
import {colors} from '../../constant/contstant';
import Redeem from '@assets/images/thumb.png';

const screenWidth = Dimensions.get('screen').width;
const fontScale = Dimensions.get('screen').fontScale;
const sliderWidth = '100%'; // 80% of screen width

// const CustomSlider = ({setValue, value, totalPoints}) => {
//   const min = 0;
//   const max = Math.floor(totalPoints);

//   // Calculate the position for the medal based on the slider value
//   const medalPosition = (value / max) * 100;

//   return (
//     <View style={styles.container}>
//       {/* Progress Bar */}
//       <View style={styles.sliderTrack}>
//         <View style={[styles.filledTrack, {width: `${medalPosition}%`}]} />
//       </View>

//       {/* Reward Medal Icon - Positioned Dynamically */}
//       <View style={[styles.medalContainer, {left: `${medalPosition}%`}]}>
//         <View
//           style={[
//             {
//               backgroundColor: 'white',
//               paddingHorizontal: screenWidth * 0.02,
//               borderRadius: 5,
//             },
//             value && {...shadow},
//           ]}>
//           <CustomText
//             color={value ? 'black' : 'white'}
//             fontSize={fontScale * 12}
//             text={toFixedMethod2(value)}
//           />
//         </View>
//         <RewardSvg width={screenWidth * 0.09} height={screenWidth * 0.09} />
//       </View>

//       {/* Actual Hidden Slider for Value Control */}
//       <Slider
//         style={styles.slider}
//         minimumValue={min}
//         maximumValue={max}
//         step={1}
//         minimumTrackTintColor="transparent" // Hide built-in track
//         maximumTrackTintColor="transparent" // Hide built-in track
//         thumbTintColor="transparent" // Hide default thumb
//         value={value}
//         onValueChange={val => setValue(val)}
//       />
//     </View>
//   );
// };

// export default CustomSlider;

const CustomSlider = ({value, setValue, totalPoints}) => {
  const min = 0;
  const max = Math.floor(totalPoints || 100);
  const tempValue = useRef(value); // track without re-render

  const [displayValue, setDisplayValue] = useState(value); // shows current value while sliding

  const medalPosition = (displayValue / max) * 100;
  const formatPoints = () => {
    if (displayValue < 1000) return displayValue.toString();
    const formatted = (displayValue / 1000).toFixed(
      displayValue % 1000 >= 100 ? 1 : 0,
    );
    return `${formatted}k`;
  };

  return (
    <View style={styles.container}>
      {/* <Text>Selected Value: {displayValue}</Text> */}
      {/* <View style={[styles.medalContainer, {left: `${medalPosition}%`}]}>
        <View
          style={[
            {
              backgroundColor: 'white',
              paddingHorizontal: screenWidth * 0.02,
              borderRadius: 5,
            },
            displayValue && {...shadow},
          ]}>
          <CustomText
            color={displayValue ? 'black' : 'white'}
            fontSize={fontScale * 12}
            text={formatPoints()}
            // text={toFixedMethod2(displayValue)}
          />
        </View>
        <RewardSvg width={screenWidth * 0.09} height={screenWidth * 0.09} />
      </View> */}
      <Slider
        minimumValue={min}
        maximumValue={max}
        value={value}
        onValueChange={val => {
          tempValue.current = val;
          setDisplayValue(Math.floor(val));
        }}
        onSlidingComplete={val => {
          setValue(val);
        }}
        style={styles.slider}
        thumbTintColor={colors.light_theme.theme}
        minimumTrackTintColor={colors.light_theme.theme}
        maximumTrackTintColor="#D9D9D9"
        // trackImage={Redeem}
        // minimumTrackImage={Redeem}
        // maximumTrackImage={Redeem}
        // thumbImage={Redeem}
      />
      {/* <View style={styles.rangeContainer}>
        <Text>{min}</Text>
        <Text>{max}</Text>
      </View> */}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    width: sliderWidth,
    justifyContent: 'center',
    alignItems: 'center',
  },
  sliderTrack: {
    width: '100%',
    backgroundColor: '#D3D3D3', // Grey unfilled track
    borderRadius: 4,
    height: 8,
    position: 'relative',
  },
  filledTrack: {
    height: 8,
    backgroundColor: colors.light_theme.theme, // Blue filled track
    borderRadius: 4,
  },
  medalContainer: {
    position: 'absolute',
    justifyContent: 'center',
    alignItems: 'center',
    transform: [{translateX: -15}], // Center the medal on its left position
    top: -25,
  },
  valueText: {
    fontSize: 14,
    fontWeight: 'bold',
    marginBottom: 2,
    color: 'black',
  },
  medalIcon: {
    width: 30,
    height: 30,
    resizeMode: 'contain',
  },
  slider: {
    width: '100%',
    // height: 20,
    position: 'absolute', // Keep slider on top of the track
  },
});

export default CustomSlider;
