import React from 'react';
import {Alert, Dimensions, Linking, StyleSheet, View} from 'react-native';
import CustomButton from '../../materialComponent/customButton/customButton';
import {globalStyle} from '../../constant/contstant';
import {navigate} from '../../utils/navigationRef/navigationRef';
import {moderateScale} from 'react-native-size-matters';
import useReduxStore from '../../utils/hooks/useReduxStore';

const {height, width, fontScale} = Dimensions.get('screen');

const OrderLinks = ({shop, orderId, socialOrderItem, image, orderTitle}) => {
  const {getState} = useReduxStore();
  const {fetch_user_detail} = getState('auth');

  const handlePress = type => {
    if (type == 1) {
      const email = `mailto:${shop.shop_email}`;
      Linking.openURL(email).catch(err =>
        Alert.alert('Error', 'Could not open mail app'),
      );
    } else if (type == 2) {
      navigate('Brand', {shop_id: shop.shop_id, shop: shop});
    } else {
      navigate('OrderReceipt', {order_id: orderId, socialOrderItem});
    }
  };

  // const data = {
  //   orderId: `${orderId}`,
  //   vendorId: `${shop?.shop_id}`,
  //   customerId: `${fetch_user_detail?.id}`,
  //   title: shop?.shop_name,
  //   image: image,
  // };

  const data = {
    orderId: orderId,
    vendorId: shop?.shop_id,
    customerId: fetch_user_detail?.id,
    title: shop?.shop_name,
    image: image,
    orderTitle,
  };

  console.log('data ==>', data);
  return (
    <View>
      <View style={globalStyle.space_between}>
        <View style={{width: '49%'}}>
          <CustomButton
            fontSize={moderateScale(12)}
            color={'black'}
            textStyle={{color: 'black'}}
            backgroundColor={'#F0F0F0'}
            text={`Contact`}
            height={height * 0.05}
            iconType={'Ionicons'}
            name={'mail-outline'}
            onPress={() => handlePress(1)}
            iconStyle={{marginRight: width * 0.02}}
          />
        </View>
        <View style={{width: '49%'}}>
          <CustomButton
            fontSize={moderateScale(12)}
            color={'black'}
            textStyle={{color: 'black'}}
            backgroundColor={'#F0F0F0'}
            text={'Visit store'}
            height={height * 0.05}
            iconType={'Ionicons'}
            name={'storefront-outline'}
            onPress={() => handlePress(2)}
            iconStyle={{marginRight: width * 0.02}}
          />
        </View>
      </View>
      {socialOrderItem ? (
        <View style={{width: '100%', marginTop: height * 0.015}}>
          <CustomButton
            fontSize={fontScale * 14}
            color={'black'}
            textStyle={{color: 'black'}}
            backgroundColor={'#F0F0F0'}
            text={'Order Receipt'}
            height={height * 0.05}
            iconType={'Ionicons'}
            name={'receipt-outline'}
            onPress={() => handlePress(3)}
            iconStyle={{marginRight: width * 0.02}}
          />
        </View>
      ) : (
        // <View style={{width: '100%', marginTop: height * 0.015}}>
        //   <CustomButton
        //     fontSize={fontScale * 14}
        //     color={'black'}
        //     textStyle={{color: 'black'}}
        //     backgroundColor={'#F0F0F0'}
        //     text={'Order Receipt'}
        //     height={height * 0.05}
        //     iconType={'Ionicons'}
        //     name={'receipt-outline'}
        //     onPress={() => handlePress(3)}
        //     iconStyle={{marginRight: width * 0.02}}
        //   />
        // </View>
        <View style={globalStyle.space_between}>
          <View style={{width: '49%', marginVertical: height * 0.015}}>
            <CustomButton
              fontSize={moderateScale(12)}
              color={'black'}
              textStyle={{color: 'black'}}
              backgroundColor={'#F0F0F0'}
              text={'Order Receipt'}
              height={height * 0.05}
              iconType={'Ionicons'}
              name={'receipt-outline'}
              onPress={() => handlePress(3)}
              iconStyle={{marginRight: width * 0.02}}
            />
          </View>
          <View style={{width: '49%', marginVertical: height * 0.015}}>
            <CustomButton
              fontSize={moderateScale(12)}
              color={'black'}
              textStyle={{color: 'black'}}
              backgroundColor={'#F0F0F0'}
              text={`${shop?.shop_name}`}
              height={height * 0.05}
              iconType={'Fontisto'}
              name={'hipchat'}
              onPress={() => navigate('Chat', data)}
              iconStyle={{marginRight: width * 0.02}}
            />
          </View>
        </View>
      )}
    </View>
  );
};

export default OrderLinks;

const styles = StyleSheet.create({});
