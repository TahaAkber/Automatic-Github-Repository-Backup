import {
  ScrollView,
  TouchableOpacity,
  View,
  Text,
  Dimensions,
} from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedScrollHandler,
  useAnimatedStyle,
  interpolate,
  runOnJS,
} from 'react-native-reanimated';
import ShopTileCategories from '../shopTIleCategories/shopTIleCategories';
import {colors, font, margin} from '../../constant/contstant';

const {height} = Dimensions.get('screen');

export default function TabHeader({
  TABS,
  selectedTab,
  scrollX,
  tabWidths,
  setTabWidths,
  scrollViewRef,
  handleTabPress,
  underlineStyle,
  handleSelectCollection,
  sub_category,
  selectedCollectionId,
}) {
  return (
    <View>
      <View style={{marginHorizontal: margin.horizontal}}>
        <ScrollView
          ref={scrollViewRef}
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{position: 'relative'}}>
          {TABS.map((tab, index) => (
            <TouchableOpacity
              key={tab.key}
              activeOpacity={1}
              onPress={() => handleTabPress(index)}
              onLayout={e => {
                const w = e.nativeEvent.layout.width;
                setTabWidths(prev => {
                  const newWidths = [...prev];
                  newWidths[index] = w;
                  return newWidths;
                });
              }}
              style={{
                paddingHorizontal: 16,
                alignItems: 'center',
                paddingVertical: 12,
              }}>
              <Animated.Text style={[{fontFamily: font.bold}]}>
                {tab.title}
              </Animated.Text>
            </TouchableOpacity>
          ))}

          {tabWidths.length === TABS.length && (
            <Animated.View
              style={[
                {
                  position: 'absolute',
                  bottom: 0,
                  height: 2,
                  backgroundColor: colors.light_theme.theme,
                },
                underlineStyle,
              ]}
            />
          )}
        </ScrollView>
      </View>

      {/* ShopTileCategories stays just below tabs */}
      <ShopTileCategories
        item={[]}
        onSelect={handleSelectCollection}
        subCategory={sub_category}
        selectedCollectionId={selectedCollectionId}
        tabView={true}
        // marginTop={!TABS?.length && height * 0.02}
      />
    </View>
  );
}
