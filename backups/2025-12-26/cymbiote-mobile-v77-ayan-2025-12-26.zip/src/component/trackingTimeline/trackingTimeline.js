import React from 'react';
import {View, Text, FlatList, StyleSheet, Dimensions} from 'react-native';
import {margin, font, colors} from '../../constant/contstant';
import CustomText from '../../materialComponent/customText/customText';
import {moderateScale} from 'react-native-size-matters';

const {height, width, fontScale} = Dimensions.get('screen');

const formatDateTime = isoDate => {
  const date = new Date(isoDate);
  const options = {
    month: 'long',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    hour12: true,
  };
  return date.toLocaleString('en-US', options).replace(',', '');
};

const TrackingTimeline = ({trackingData = '[]', scrollEnabled = true}) => {
  if (!trackingData) return null;

  let parsedTrackingData = [];
  try {
    parsedTrackingData = JSON.parse(trackingData);
  } catch (error) {
    console.error('Error parsing tracking data:', error);
    return null;
  }

  if (!Array.isArray(parsedTrackingData) || parsedTrackingData.length === 0) {
    return null;
  }

  // Filter data based on expansion state
  const dataToShow = parsedTrackingData;

  console.log('dataToShow', trackingData);

  return (
    <View style={styles.container}>
      {/* <Text style={styles.heading}>Tracking Events</Text> */}
      <FlatList
        scrollEnabled={scrollEnabled}
        data={dataToShow}
        keyExtractor={(item, index) => index.toString()}
        renderItem={({item, index}) => {
          const isLast = index === dataToShow.length - 1;
          return (
            <View style={styles.eventContainer}>
              <View style={styles.timelineContainer}>
                <View style={styles.dot} />
                {!isLast && <View style={styles.line} />}
              </View>
              <View style={styles.textContainer}>
                <CustomText
                  style={styles.timeText}
                  text={formatDateTime(item.time_iso)}
                />
                <CustomText style={styles.eventText} text={item.description} />
              </View>
            </View>
          );
        }}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginHorizontal: margin.horizontal,
    marginTop: moderateScale(10),
    marginBottom: moderateScale(10),
  },
  heading: {
    fontSize: moderateScale(12),
    fontFamily: font.bold,
    marginBottom: moderateScale(10),
  },
  eventContainer: {
    flexDirection: 'row',
    // alignItems: 'flex-start', // Allow stretching so timeline line fills height
    marginBottom: 0,
    // minHeight: 70, // Remove fixed height
  },
  timelineContainer: {
    alignItems: 'center',
    marginRight: moderateScale(15),
    width: width * 0.04,
  },
  dot: {
    width: width * 0.03,
    height: width * 0.03,
    borderRadius: moderateScale(6),
    backgroundColor: colors.light_theme.theme, // Cyan color
    zIndex: 1,
    marginTop: moderateScale(5),
  },
  line: {
    width: width * 0.005,
    backgroundColor: colors.light_theme.theme, // Cyan color
    flex: 1,
    marginTop: moderateScale(4), // Connect to dot
    // marginBottom: -10, // Extend to next item
  },
  textContainer: {
    flex: 1,
    paddingBottom: moderateScale(20), // Add spacing between items here instead
  },
  eventText: {
    fontSize: moderateScale(11),
    fontFamily: font.bold,
  },
  timeText: {
    fontSize: moderateScale(10),
    fontFamily: font.medium,
    color: '#888',
    marginBottom: moderateScale(5),
  },
});

export default TrackingTimeline;
