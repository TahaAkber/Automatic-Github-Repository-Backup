import React from 'react';
import { View, Text, FlatList, StyleSheet, Dimensions } from 'react-native';
import { margin, font } from '../../constant/contstant';
import CustomText from '../../materialComponent/customText/customText';


const { height, width, fontScale } = Dimensions.get('screen');

const formatDateTime = (isoDate) => {
    const date = new Date(isoDate);
    const options = { month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true };
    return date.toLocaleString('en-US', options).replace(',', ''); // Remove comma for better formatting
};

const TrackingSummery = ({ trackingData = "[]" }) => {
    if (!trackingData) return null;

    let parsedTrackingData = [];
    try {
        parsedTrackingData = JSON.parse(trackingData);
    } catch (error) {
        console.error("Error parsing tracking data:", error);
        return null;
    }

    if (!Array.isArray(parsedTrackingData) || parsedTrackingData.length === 0) {
        return null;
    }

    return (
        <View style={styles.container}>
            <Text style={styles.heading}>Tracking Events</Text>
            <FlatList
                data={parsedTrackingData}
                keyExtractor={(item, index) => index.toString()}
                renderItem={({ item }) => (
                    <View style={styles.eventContainer}>
                        <CustomText style={styles.bullet} text={"•"} />
                        <View style={styles.textContainer}>
                            <CustomText style={styles.eventText} text={item.description} />
                            <CustomText style={styles.timeText} text={formatDateTime(item.time_iso)} />
                        </View>
                    </View>
                )}
            />
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        marginHorizontal: margin.horizontal,
        marginTop: 10,

    },
    heading: {
        fontSize: 15,
        fontFamily: font.bold,
        marginBottom: 10,
    },
    eventContainer: {
        flexDirection: 'row',
        alignItems: 'flex-start',
        marginBottom: 10,

    },
    bullet: {
        fontSize: 20,
        fontWeight: 'bold',
        marginRight: 10,
        marginTop: -3

    },
    textContainer: {
        flex: 1,
        // flexDirection:"row",
        // justifyContent:"space-between",

    },
    eventText: {
        fontSize: 14,
        fontFamily: font.medium,


    },
    timeText: {
        fontSize: 12,
        fontFamily: font.regular,
        color: '#888',
        marginTop: 2,
    },
});

export default TrackingSummery;
