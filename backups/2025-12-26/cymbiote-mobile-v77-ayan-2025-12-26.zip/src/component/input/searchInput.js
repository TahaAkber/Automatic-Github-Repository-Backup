import { moderateScale, verticalScale } from 'react-native-size-matters';
import { View, TextInput, StyleSheet, TouchableOpacity, Dimensions } from 'react-native';
import CustomText from '@materialComponent/customText/customText';
import { colors, font } from '@constant/contstant';
import React, { forwardRef, useState } from 'react';
import { WH } from '@constant/contstant';
import Icon from '@materialComponent/icon/icon';

const { fontScale, height, width } = Dimensions.get("screen")

const SearchInput = forwardRef(({
    keyboardType = 'default',
    secureTextEntry = false,
    returnKeyType = 'done',
    errorMessage = null,
    onSubmitEditing,
    marginTop = 0,
    onChangeText,
    placeholder,
    editable,
    onBlur,
    label,
    value,
    hide,
    removeSearchIcon,
    style,
    multiline = false,
    inputHeight
}, ref) => {
    // State to toggle password visibility
    const [isSecure, setIsSecure] = useState(secureTextEntry);

    const togglePasswordVisibility = () => {
        setIsSecure(!isSecure);
    };

    return hide ? null : (
        <View style={{ marginTop }}>
            <View style={[styles.container, style]}>
                {!removeSearchIcon &&
                    <View style={{ width: "5%", justifyContent: "center", alignItems: "center" }}>
                        <Icon icon_type={"Fontisto"} name={"search"} color={"#adadad"} size={width * 0.05} />
                    </View>
                }

                <TextInput
                    ref={ref} // Attach ref here
                    style={[
                        styles.input,
                        inputHeight && { height: inputHeight },
                        editable && { backgroundColor: colors.light_theme.darkBorderColor, color: colors.light_theme.gray },
                        errorMessage && styles.errorBorder,
                        removeSearchIcon && { width: "100%" }
                    ]}
                    placeholderTextColor={colors.light_theme.gray}
                    secureTextEntry={isSecure} // Controlled by isSecure state
                    onSubmitEditing={onSubmitEditing}
                    returnKeyType={returnKeyType}
                    keyboardType={keyboardType}
                    placeholder={placeholder}
                    onChangeText={onChangeText}
                    editable={!editable}
                    onBlur={onBlur}
                    value={value}
                    multiline={multiline}
                    verticalAlign={multiline && 'top'}
                />

                {value ?
                    <TouchableOpacity onPress={() => onChangeText("")} style={[styles.clearIcon, multiline && { top: 5, right: 5, width: width * 0.05, }]}>
                        <Icon icon_type={"AntDesign"} name={"close"} color={"white"} size={multiline ? width * 0.03 : width * 0.04} />
                    </TouchableOpacity> : <></>
                }
            </View>
        </View>
    );
});

export default SearchInput;

const styles = StyleSheet.create({
    container: {
        width: '100%',
        backgroundColor: "#f3f3f3",
        overflow: "hidden",
        height: height * 0.05,
        justifyContent: "center",
        borderRadius: moderateScale(180),
        flexDirection: "row",
        alignItems: "center"
    },
    label: {
        marginBottom: moderateScale(5),
        fontSize: moderateScale(14),
        color: colors.light_theme.gray,
        fontFamily: font.bold,
    },
    input: {
        fontSize: moderateScale(14),
        padding: moderateScale(10),
        paddingHorizontal: moderateScale(15),
        borderColor: colors.light_theme.gray,
        color: colors.light_theme.text,
        fontFamily: font.medium,
        width: "85%",
    },
    errorBorder: {
        borderColor: colors.light_theme.red,
    },
    errorText: {
        fontSize: moderateScale(12),
        marginTop: moderateScale(5),
        color: colors.light_theme.red,
    },
    iconContainer: {
        position: "absolute",
        right: 15,
    },
    clearIcon: {
        width: width * 0.07,
        aspectRatio: 1,
        borderRadius: 180,
        backgroundColor: "black",
        position: "absolute",
        right: 10,
        justifyContent: "center",
        alignItems: "center"
    }
});
