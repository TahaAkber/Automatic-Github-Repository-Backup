import {moderateScale, verticalScale} from 'react-native-size-matters';
import {View, TextInput, StyleSheet, TouchableOpacity} from 'react-native';
import CustomText from '@materialComponent/customText/customText';
import {colors, font} from '@constant/contstant';
import React, {forwardRef, useState} from 'react';
import {WH} from '@constant/contstant';
import Icon from '@materialComponent/icon/icon';

const AuthInput = forwardRef(
  (
    {
      keyboardType = 'default',
      secureTextEntry = false,
      returnKeyType = 'done',
      errorMessage = null,
      backgroundColor,
      onSubmitEditing,
      marginTop = 0,
      onChangeText,
      placeholder,
      editable,
      onBlur,
      onFocus,
      label,
      value,
      hide,
    },
    ref,
  ) => {
    // State to toggle password visibility
    const [isSecure, setIsSecure] = useState(secureTextEntry);

    const togglePasswordVisibility = () => {
      setIsSecure(!isSecure);
    };

    return hide ? null : (
      <View style={{marginTop}}>
        <View style={[styles.container, backgroundColor && {backgroundColor}]}>
          <TextInput
            ref={ref} // Attach ref here
            style={[
              styles.input,
              editable && {
                backgroundColor: colors.light_theme.darkBorderColor,
                color: colors.light_theme.gray,
              },
              errorMessage && styles.errorBorder,
            ]}
            placeholderTextColor={colors.light_theme.gray}
            secureTextEntry={isSecure} // Controlled by isSecure state
            onSubmitEditing={onSubmitEditing}
            returnKeyType={returnKeyType}
            keyboardType={keyboardType}
            placeholder={placeholder}
            onChangeText={onChangeText}
            editable={!editable}
            onBlur={onBlur}
            onFocus={onFocus}
            value={value}
          />
          {secureTextEntry && (
            <TouchableOpacity
              onPress={togglePasswordVisibility}
              style={styles.iconContainer}>
              <Icon
                icon_type="Feather"
                name={isSecure ? 'eye-off' : 'eye'} // Toggle icon based on state
                size={moderateScale(17)}
                color="#ACB5BB"
              />
            </TouchableOpacity>
          )}
        </View>
        {errorMessage && (
          <CustomText
            marginTop={verticalScale(5)}
            fontSize={moderateScale(12)}
            text={`* ${errorMessage}`}
            color="red"
          />
        )}
      </View>
    );
  },
);

export default AuthInput;

const styles = StyleSheet.create({
  container: {
    width: '100%',
    backgroundColor: 'white',
    overflow: 'hidden',
    borderRadius: moderateScale(10),
    height: WH.height(6.5),
    justifyContent: 'center',
  },
  label: {
    marginBottom: moderateScale(5),
    fontSize: moderateScale(14),
    color: colors.light_theme.gray,
    fontFamily: font.bold,
  },
  input: {
    fontSize: moderateScale(14),
    padding: moderateScale(10),
    paddingHorizontal: moderateScale(15),
    borderColor: colors.light_theme.gray,
    color: colors.light_theme.text,
    fontFamily: font.medium,
  },
  errorBorder: {
    borderColor: colors.light_theme.red,
  },
  errorText: {
    fontSize: moderateScale(12),
    marginTop: moderateScale(5),
    color: colors.light_theme.red,
  },
  iconContainer: {
    position: 'absolute',
    right: 15,
  },
});
