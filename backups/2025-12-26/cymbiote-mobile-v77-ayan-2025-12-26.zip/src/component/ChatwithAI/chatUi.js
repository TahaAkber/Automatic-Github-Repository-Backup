import React, {useEffect, useState, useRef} from 'react';
import {
  View,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  FlatList,
  Dimensions,
  KeyboardAvoidingView,
  Platform,
  Keyboard,
} from 'react-native';
import Icon from '../../materialComponent/icon/icon';
import {colors, font, margin} from '../../constant/contstant';
import CustomText from '../../materialComponent/customText/customText';
import useChatAI from '../../screen/loggedIn/chatwithai/useChatAI';
import ChatLoader from '../loader/chatLoader';
import HomeDualCard from '../cards/homeDualCard';

const {fontScale, width, height} = Dimensions.get('screen');

const ChatUI = ({messages, onSendMessage, products, onKeyboardToggle}) => {
  const {loading} = useChatAI({});

  const [text, setText] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const flatListRef = useRef(null);

  const handleSend = () => {
    if (text.trim().length > 0) {
      // Set loading state when a message is sent
      setIsLoading(true);
      // Send the user's message
      onSendMessage(text);
      setText('');
    }
  };
  // Function to open the camera

  useEffect(() => {
    if (!loading) {
      // Reset loading after receiving a response from the AI
      setIsLoading(false);
    }
  }, [loading]);

  // Scroll to the bottom when the messages change
  // useEffect(() => {
  //   if (flatListRef.current) {
  //     flatListRef.current.scrollToEnd({animated: true});
  //   }
  // }, [messages]);

  useEffect(() => {
    const showSubscription = Keyboard.addListener('keyboardDidShow', () => {
      onKeyboardToggle?.(true); // ✅ Notify parent
    });
    const hideSubscription = Keyboard.addListener('keyboardDidHide', () => {
      onKeyboardToggle?.(false); // ✅ Notify parent
    });

    return () => {
      showSubscription.remove();
      hideSubscription.remove();
    };
  }, []);
  const renderMessage = ({item}) => {
    return (
      <>
        {item.products?.length > 0 && (
          <View style={styles.messageContainer}>
            <FlatList
              data={item.products}
              keyExtractor={(prod, index) => `${prod.product_id}_${index}`}
              renderItem={({item}) => (
                <HomeDualCard item={item} home color={'black'} />
              )}
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={{paddingHorizontal: margin.horizontal}}
            />
          </View>
        )}

        <View
          style={[
            styles.messageContainer,
            item.isOutgoing ? styles.outgoingMessage : styles.incomingMessage,
          ]}>
          <View
            style={[
              styles.messageBubble,
              item.isOutgoing ? styles.outgoingBubble : styles.incomingBubble,
            ]}>
            <CustomText
              text={item.text}
              fontSize={fontScale * 14}
              color={item.isOutgoing ? '#fff' : '#000E08'}
              fontFamily={font.regular}
            />
          </View>
          {/* <View style={{width: '90%', alignSelf: 'center'}}>
            <CustomText
              text={item.time}
              fontSize={fontScale * 12}
              color={'#797C7B'}
              textAlign={item.isOutgoing ? 'right' : 'center'}
              marginTop={5}
              fontFamily={font.regular}
            />
          </View> */}
        </View>
      </>
    );
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      keyboardVerticalOffset={Platform.OS === 'ios' ? 90 : 0}
      style={styles.container}>
      <FlatList
        ref={flatListRef} // Reference to FlatList
        data={(messages || []).filter(msg => msg && msg.id)}
        renderItem={renderMessage}
        inverted
        keyExtractor={(item, index) => item.id?.toString() || index.toString()}
        // contentContainerStyle={{paddingBottom: 20}}
        ListHeaderComponent={
          loading && (
            <View style={styles.loadingContainer}>
              <ChatLoader />
            </View>
          )
        }
      />

      <View style={styles.inputContainer}>
        <View style={styles.inputBox}>
          <TextInput
            value={text}
            onChangeText={setText}
            style={styles.searchbar}
            placeholder={'Write your message...'}
            placeholderTextColor={colors.light_theme.gray}
            textAlignVertical="center"
          />
          <TouchableOpacity onPress={handleSend} style={styles.sendButton}>
            <Icon
              name="send"
              size={20}
              color={'#fff'}
              icon_type={'MaterialIcons'}
            />
          </TouchableOpacity>
        </View>
      </View>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  dayDivider: {
    alignSelf: 'center',
    backgroundColor: '#F8FBFA',
    color: '#000E08',
    borderRadius: 10,
    paddingHorizontal: 10,
    paddingVertical: 5,
    marginVertical: 10,
    fontSize: 14,
    fontWeight: '700',
  },
  messageContainer: {
    marginVertical: 5,
    paddingHorizontal: 10,
  },
  outgoingMessage: {
    alignItems: 'flex-end',
  },
  incomingMessage: {
    alignItems: 'flex-start',
    marginTop: 10,
  },
  messageBubble: {
    maxWidth: '75%',
    borderBottomEndRadius: 10,
    borderBottomLeftRadius: 10,
    borderTopLeftRadius: 10,
    padding: 10,
    marginHorizontal: margin.horizontal,
  },
  // loadingContainer: {
  //   maxWidth: '30%', // Reduced width
  //   height: 30, // Set a specific height to reduce the overall size
  //   borderRadius: 10,
  //   marginHorizontal: margin.horizontal,
  //   backgroundColor: '#f2f7fb',
  //   justifyContent: 'center', // Center the loader vertically
  //   alignSelf: 'flex-start',
  // },
  outgoingBubble: {
    backgroundColor: colors.dark_theme.theme,
    alignSelf: 'flex-end',
  },
  incomingBubble: {
    backgroundColor: '#f2f7fb',
    bottom: 10,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 10,
    backgroundColor: 'white',
    borderTopWidth: 1,
    borderTopColor: '#ddd',
  },
  inputBox: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#',
    borderRadius: 20,
    paddingHorizontal: 10,
  },
  searchbar: {
    flex: 1,
    paddingVertical: 8,
    fontFamily: font.medium,
    color: 'black',
  },
  sendButton: {
    backgroundColor: colors.light_theme.theme,
    borderRadius: 20,
    padding: 8,
    marginLeft: 5,
  },
});

export default ChatUI;
