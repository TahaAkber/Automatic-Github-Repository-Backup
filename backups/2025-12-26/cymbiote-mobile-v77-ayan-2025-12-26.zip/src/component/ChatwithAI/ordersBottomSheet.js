import React, {forwardRef, useState, useEffect} from 'react';
import {
  View,
  StyleSheet,
  FlatList,
  ActivityIndicator,
  RefreshControl,
  Dimensions,
} from 'react-native';
import CustomText from '../../materialComponent/customText/customText';
import OrderItem from './orderItem';
import useActiveOrders from './useActiveOrder';
import {useDispatch} from 'react-redux';
import OrderHistoryCard from '../cards/orderHistoryCard/orderHistoryCard';
import {navigate} from '../../utils/navigationRef/navigationRef';
import EmptyScreen from '../emptyScreen/emptyScreen';
import GorhomBottomSheet from '../../materialComponent/bottomSheet/GorhomBottomSheet';
const {width, height, fontScale} = Dimensions.get('screen');

const OrdersBottomSheet = forwardRef(
  ({buttonText, onSend, disableSendFunction = false}, ref) => {
    const {
      fetch_active_order,
      fetch_active_order_loader,
      fetch_active_order_error,

      fetchAPI,
    } = useActiveOrders();
    const renderItem = ({item}) => (
      <OrderHistoryCard
        item={item}
        onPress={() => navigate('ReviewDetail')}
        isBordered={true}
      />
    );
    return (
      <GorhomBottomSheet
        ref={ref}
        closeOnDragDown={true}
        closeOnPressMask={true}
        customStyles={{
          container: {
            ...styles.sheetContainer,
            maxHeight: height * 0.8,
            height: 'auto',
          },
        }}>
        <View style={styles.ordersContainer}>
          {fetch_active_order_loader ? (
            <ActivityIndicator size="large" color="#0000ff" />
          ) : fetch_active_order?.length === 0 ? (
            <View
              style={{
                justifyContent: 'center',
                alignItems: 'center',
                marginVertical: height * 0.1,
              }}>
              <EmptyScreen
                image={'empty_order'}
                heading={'No Orders Yet!'}
                desc={
                  'Looks like you haven’t placed any orders. Start shopping now and track your purchases here!'
                }
              />
            </View>
          ) : (
            <FlatList
              data={fetch_active_order}
              keyExtractor={item => item?.id?.toString()}
              renderItem={renderItem}
              ListFooterComponent={
                fetch_active_order_loader ? (
                  <ActivityIndicator size="large" color="#0000ff" />
                ) : null
              }
            />
          )}
        </View>
      </GorhomBottomSheet>
    );
  },
);

const styles = StyleSheet.create({
  sheetContainer: {
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    padding: 20,
    // flex: 1,
  },
  ordersContainer: {padding: 2},
  orderTitle: {fontSize: 18, fontWeight: 'bold', marginBottom: 10},
  orderItem: {flexDirection: 'row', alignItems: 'center', marginBottom: 15},
  orderImage: {width: 50, height: 50, borderRadius: 5, marginRight: 10},
  orderText: {fontSize: 16, fontWeight: 'bold'},
  orderStatus: {fontSize: 14, color: 'gray'},
  sendButton: {backgroundColor: 'blue', padding: 8, borderRadius: 5},
  sendText: {color: 'white', fontWeight: 'bold'},
});

export default OrdersBottomSheet;
