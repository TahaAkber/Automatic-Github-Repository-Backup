import React, {useState, useEffect} from 'react';
import ImageView from 'react-native-image-viewing';
import CustomText from '../../materialComponent/customText/customText';
import {font} from '../../constant/contstant';

const ImageViewer = ({
  images,
  visible,
  activeIndex,
  setIsVisible,
  setActiveIndex,
}) => {
  const [currentIndex, setCurrentIndex] = useState(activeIndex);

  // Ensure images are available before mapping
  const modifiedImages =
    Array.isArray(images) && images.length > 0
      ? images?.map(item => {
          // Make sure each item has a valid URI
          return {uri: item?.uri ? item?.uri : item};
        })
      : [];

  useEffect(() => {
    // Sync currentIndex with activeIndex from props
    setCurrentIndex(activeIndex);
  }, [activeIndex]);

  if (modifiedImages.length === 0) {
    // Don't render ImageView if no images are available
    return null;
  }

  return (
    <ImageView
      images={modifiedImages} // Use the formatted images array
      imageIndex={activeIndex} // Correct image based on the currentIndex
      visible={visible} // Control visibility with the prop
      onRequestClose={() => setIsVisible(false)}
      swipeToCloseEnabled={true}
      onImageIndexChange={index => {
        if (index !== currentIndex) {
          setCurrentIndex(index); // Update currentIndex on image change
        }
      }}
      presentationStyle="fullScreen"
      FooterComponent={() =>
        images.length > 1 ? (
          <CustomText
            color={'white'}
            text={`Photos ${currentIndex + 1}/${images.length}`}
            center
            style={styles.counterText}
          />
        ) : (
          <></>
        )
      }
      animationType="slide" // Optional: Add fade animation between images
    />
  );
};

const styles = {
  counterText: {
    color: '#fff',
    fontSize: 16,
    position: 'absolute',
    bottom: 20,
    left: '50%',
    transform: [{translateX: -35}],
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    padding: 5,
    borderRadius: 5,
    fontFamily: font.bold,
  },
};

export default ImageViewer;
