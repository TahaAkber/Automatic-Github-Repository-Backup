import React, {useState} from 'react';
import {
  StyleSheet,
  View,
  Dimensions,
  TouchableOpacity,
  Animated,
} from 'react-native';
import {moderateScale} from 'react-native-size-matters';
import {globalStyle} from '@constant/contstant';
import Icon from '../../materialComponent/icon/icon';
import {colors} from '../../constant/contstant';
import {_favoriteUpdateStatus} from '../../redux/actions/user/user';
import useReduxStore from '../../utils/hooks/useReduxStore';
import {shareItems} from '../../utils/helper/helper';

const {fontScale, width, height} = Dimensions.get('screen');

const LCSCard = ({
  horizontal,
  dark,
  iconContainerStyle,
  containerStyle,
  fontSize,
  product_id,
  product_image_url,
  shop_id,
  onPressReview,
}) => {
  const {getState, dispatch} = useReduxStore();
  const {fetch_favorite_list_local, fetch_favorite_list} = getState('user');
  const liveProductIds = fetch_favorite_list
    .flatMap(shop => shop.products || [])
    .map(p => p.product_id);
  const localProductIds = fetch_favorite_list_local.map(
    p => p.wishlist_product_id,
  );
  const finalArray = [...liveProductIds, ...localProductIds];
  const [like, setLike] = useState(finalArray.includes(product_id));
  const [scale] = useState(new Animated.Value(1));

  const _handleFavorite = async value => {
    try {
      setLike(value);
      const data = {wishlist_product_id: product_id};
      await dispatch(
        _favoriteUpdateStatus(product_id, value, data, false, false, true),
      );
    } catch (error) {
      console.log('error', error?.message);
    }
  };

  const handleHeartClick = () => {
    _handleFavorite(!like);
    Animated.sequence([
      Animated.spring(scale, {
        toValue: 1.2,
        friction: 3,
        useNativeDriver: true,
      }),
      Animated.spring(scale, {toValue: 1, friction: 3, useNativeDriver: true}),
    ]).start();
  };

  const shareData = {
    productId: product_id,
    productImage: product_image_url,
    shopId: shop_id,
    message: 'Check out this product on cercle',
    image_url: product_image_url,
  };

  return (
    <View>
      <View
        style={[
          horizontal
            ? {position: 'absolute', bottom: height * 0.15, right: 0}
            : [globalStyle.row, styles.bottom, containerStyle],
          containerStyle,
        ]}>
        <TouchableOpacity
          activeOpacity={1}
          onPress={handleHeartClick}
          style={[
            styles.iconContainer,
            horizontal && {height: width * 0.08, width: width * 0.08},
            iconContainerStyle,
          ]}>
          <Animated.View style={{transform: [{scale}]}}>
            <Icon
              icon_type="AntDesign"
              name={like ? 'heart' : 'hearto'}
              size={fontSize || fontScale * 20}
              color={like ? colors.light_theme.theme : dark ? 'black' : 'white'}
            />
          </Animated.View>
        </TouchableOpacity>
        <TouchableOpacity
          activeOpacity={1}
          onPress={onPressReview}
          style={[
            styles.iconContainer,
            horizontal && {height: width * 0.08, width: width * 0.08},
            iconContainerStyle,
          ]}>
          <Icon
            icon_type="Ionicons"
            name="chatbubble-ellipses-outline"
            size={fontSize || fontScale * 20}
            color={dark ? 'black' : 'white'}
          />
        </TouchableOpacity>
        <TouchableOpacity
          activeOpacity={1}
          onPress={() => shareItems('ProductDetail', product_id, shareData)}
          style={[
            styles.iconContainer,
            horizontal && {height: width * 0.08, width: width * 0.08},
            iconContainerStyle,
          ]}>
          <Icon
            icon_type="AntDesign"
            name="sharealt"
            size={fontSize || fontScale * 20}
            color={dark ? 'black' : 'white'}
          />
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default LCSCard;

const styles = StyleSheet.create({
  bottom: {
    position: 'absolute',
    bottom: height * 0.02,
    justifyContent: 'center',
    alignItems: 'center',
    alignSelf: 'center',
  },
  iconContainer: {
    width: width * 0.15,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
