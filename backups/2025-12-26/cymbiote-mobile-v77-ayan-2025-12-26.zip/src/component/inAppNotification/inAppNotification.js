import React, {useEffect, useRef} from 'react';
import {
  Animated,
  StyleSheet,
  View,
  Platform,
  Easing,
  TouchableOpacity,
  Vibration,
  Dimensions,
} from 'react-native';
import useApp from '../../../useApp';
import CustomImage from '../../materialComponent/image/image';
import CustomText from '../../materialComponent/customText/customText';
import {colors, font, margin, shadow} from '../../constant/contstant';
import {navigate} from '../../utils/navigationRef/navigationRef';
import {triggerHaptic} from '../../utils/haptic/haptic';
import {widthPercentageToDP} from 'react-native-responsive-screen';
import {handleNotificationPress} from '../../helper/reUsableMethod/reUsableMethod';
import useReduxStore from '../../utils/hooks/useReduxStore';

const {fontScale} = Dimensions.get('screen');

export default function InAppNotification() {
  const {dispatch} = useReduxStore();
  const {notificationBanner, setNotificationBanner} = useApp({});
  const slideAnim = useRef(new Animated.Value(-100)).current;
  const opacity = useRef(new Animated.Value(0)).current;


  useEffect(() => {
    if (notificationBanner) {
      triggerHaptic();
      Animated.parallel([
        Animated.timing(slideAnim, {
          toValue: Platform.OS === 'android' ? 10 : 70,
          duration: 500,
          easing: Easing.out(Easing.exp),
          useNativeDriver: false,
        }),
        Animated.timing(opacity, {
          toValue: 1,
          duration: 500,
          easing: Easing.out(Easing.exp),
          useNativeDriver: false,
        }),
      ]).start();

      const timer = setTimeout(() => {
        Animated.parallel([
          Animated.timing(opacity, {
            toValue: 0,
            duration: 400,
            easing: Easing.in(Easing.cubic),
            useNativeDriver: false,
          }),
          Animated.timing(slideAnim, {
            toValue: -100,
            duration: 400,
            easing: Easing.in(Easing.cubic),
            useNativeDriver: false,
          }),
        ]).start();
      }, 3000);

      return () => clearTimeout(timer);
    }
  }, [notificationBanner]);

  if (!notificationBanner) return null;

  return (
    <TouchableOpacity
      onPress={() => handleNotificationPress(notificationBanner, dispatch)}
      activeOpacity={0.9}>
      <Animated.View style={[styles.banner, {top: slideAnim, opacity}]}>
        {notificationBanner?.image && (
          <CustomImage
            source={{
              uri:
                notificationBanner?.image || 'https://via.placeholder.com/60',
            }}
            style={styles.bannerImage}
            resizeMode="cover"
          />
        )}
        <View style={styles.textWrapper}>
          <CustomText
            style={styles.bannerTitle}
            text={notificationBanner?.title}
            numberOfLines={1}
          />
          <CustomText
            style={styles.bannerBody}
            text={notificationBanner?.body}
            numberOfLines={2}
          />
        </View>
      </Animated.View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  banner: {
    position: 'absolute',
    left: margin.horizontal,
    right: margin.horizontal,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'white',
    borderRadius: 5,
    padding: 10,
    shadowColor: '#000',
    shadowOffset: {width: 0, height: 3}, // slightly deeper
    shadowOpacity: 0.15, // darker shadow
    shadowRadius: 6, // slightly larger blur
    elevation: 1,
    zIndex: 1000,
    // overflow: "vis"
  },
  bannerImage: {
    width: widthPercentageToDP(12),
    // height: 60,
    aspectRatio: 1,
    borderRadius: 10,
    marginRight: 10,
  },
  textWrapper: {
    flex: 1,
    // paddingTop: 6,
    // paddingHorizontal: 8,
  },
  bannerTitle: {
    color: colors.light_theme.text,
    fontFamily: font.bold,
    fontSize: fontScale * 12,
    // flexShrink: 1,
  },
  bannerBody: {
    color: colors.light_theme.text,
    fontSize: fontScale * 10,
    marginTop: 2,
    flexShrink: 1,
  },
});
