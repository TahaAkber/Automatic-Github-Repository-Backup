import React, {useState, useRef} from 'react';
import {
  View,
  StyleSheet,
  Dimensions,
  TouchableOpacity,
  Animated,
} from 'react-native';
import CustomImage from '@materialComponent/image/image';
import Overlay from '@materialComponent/overlay/overlay';
import BrandTab from '@component/brandTab/brandTab';
import ImageViewer from '../imageViewer/imageViewer';
import {moderateScale} from 'react-native-size-matters';

const ImageSlider = ({
  customWidth,
  images,
  brand,
  customHeight,
  style,
  imageRadius,
  dotStyle,
  stylePagination,
  activeIndex,
  onPress,
  brand_screen,
  originalResolution = [],
  removeSpace,
  productDetail,
  id,
}) => {
  const {width, height: screenHeight} = Dimensions.get('window');
  const imageWidth = customWidth || width * 0.9;
  const height = customHeight || imageWidth * 0.9;

  const [imageIndex, setImageIndex] = useState(0);
  const [isVisible, setIsVisible] = useState(false);

  const scrollX = useRef(new Animated.Value(0)).current;
  const scrollViewRef = useRef(null);

  const modifiedArr = images.map(item => ({uri: item}));

  const handleImageClick = index => {
    setIsVisible(true);
    setImageIndex(index);
  };

  const clamp = (value, min, max) => Math.max(min, Math.min(value, max));
  const finalHeight = clamp(height || 250, 250, screenHeight * 0.5);

  return (
    <View style={[styles.container, style]}>
      {brand && (
        <View style={{width: width * 0.9}}>
          <BrandTab
            mainViewStyle={{paddingHorizontal: 0}}
            item={brand}
            shopNameFontSize={moderateScale(14)}
            followStyle={{backgroundColor: 'black'}}
            followColor={'white'}
            brand_screen={brand_screen}
            isProductDetail={productDetail || true}
            dot={productDetail || false}
            id={id}
          />
        </View>
      )}

      <Animated.FlatList
        ref={scrollViewRef}
        data={modifiedArr}
        horizontal
        showsHorizontalScrollIndicator={false}
        keyExtractor={(item, index) => index.toString()}
        renderItem={({item, index}) => (
          <TouchableOpacity
            activeOpacity={1}
            onPress={() => handleImageClick(index)}
            style={{flexDirection: 'row'}}>
            <CustomImage
              source={{uri: item?.uri}}
              resizeMode={'cover'}
              style={{
                width: imageWidth,
                // height,
                height: finalHeight,
                resizeMode: 'cover',
                borderRadius: imageRadius || 20,
              }}>
              <Overlay />
            </CustomImage>
          </TouchableOpacity>
        )}
        snapToInterval={imageWidth + 10}
        decelerationRate="fast"
        contentContainerStyle={{
          alignItems: 'center',
          paddingHorizontal: removeSpace ? 0 : (width - imageWidth) / 2,
        }}
        ItemSeparatorComponent={() => <View style={{width: 10}} />}
        onScroll={Animated.event(
          [{nativeEvent: {contentOffset: {x: scrollX}}}],
          {useNativeDriver: false},
        )}
        scrollEventThrottle={16}
      />

      {/* Pagination Dots */}
      {images?.length > 1 ? (
        <View style={[styles.paginationWrapper, stylePagination]}>
          {images.map((_, i) => {
            const inputRange = [
              (i - 1) * imageWidth,
              i * imageWidth,
              (i + 1) * imageWidth,
            ];

            const dotScale = scrollX.interpolate({
              inputRange,
              outputRange: [0.8, 1.2, 0.8],
              extrapolate: 'clamp',
            });

            const dotOpacity = scrollX.interpolate({
              inputRange,
              outputRange: [0.3, 1, 0.3],
              extrapolate: 'clamp',
            });

            return (
              <Animated.View
                key={i}
                style={[
                  styles.dot,
                  dotStyle,
                  {transform: [{scale: dotScale}], opacity: dotOpacity},
                ]}
              />
            );
          })}
        </View>
      ) : (
        <></>
      )}

      {/* Image Viewer */}
      <ImageViewer
        images={originalResolution?.length ? originalResolution : images}
        activeIndex={imageIndex}
        setIsVisible={setIsVisible}
        visible={isVisible}
        setActiveIndex={setImageIndex}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    marginVertical: 20,
  },
  paginationWrapper: {
    flexDirection: 'row',
    position: 'absolute',
    bottom: 10,
    alignSelf: 'center',
  },
  dot: {
    backgroundColor: '#0000004D',
    marginHorizontal: 3,
    borderRadius: 180,
    width: moderateScale(7),
    height: moderateScale(7),
  },
});

export default ImageSlider;
