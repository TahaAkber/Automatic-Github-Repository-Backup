import React, { useState, useCallback } from 'react';
import {
    Dimensions,
    StyleSheet,
    View,
    Animated,
    LayoutAnimation,
    UIManager,
} from 'react-native';
import { margin, font, globalStyle } from '@constant/contstant';
import SummaryTable from '@component/table/summaryTable';

const { height, width } = Dimensions.get('screen');

// Enable LayoutAnimation for Android
if (Platform.OS === 'android' && UIManager.setLayoutAnimationEnabledExperimental) {
    UIManager.setLayoutAnimationEnabledExperimental(true);
}

const OrderSummary = ({ animatedHeight, orderSummary, expanded }) => {
    const [contentHeight, setContentHeight] = useState(0);

    // Callback function to measure content height
    const onContentLayout = useCallback((event) => {
        const { height } = event.nativeEvent.layout;
        setContentHeight(height); // Store the measured height
    }, []);

    return (
        <Animated.View
            style={{
                marginTop: height * 0.01,
                maxHeight: animatedHeight.interpolate({
                    inputRange: [0, 1],
                    outputRange: [0, contentHeight], // Dynamically set maxHeight based on content height
                }),
                overflow: 'hidden', // Ensure content doesn't overflow the animated container
            }}
        >
            {expanded && (
                <View
                    style={[styles.order, { paddingBottom: height * 0.01 }]}
                    onLayout={onContentLayout} // Measure the content height when it's laid out
                >
                    {orderSummary.map((item, index) => {
                        return (
                            <SummaryTable
                                key={index}
                                summary={true}
                                marginTop={index !== 0 && height * 0.01}
                                label={item.label}
                                value={item.value}
                            />
                        );
                    })}
                </View>
            )}
        </Animated.View>
    );
};

export default OrderSummary;

const styles = StyleSheet.create({
    order: {
        backgroundColor: '#FAFAFA',
        paddingHorizontal: margin.horizontal,
        paddingTop: height * 0.01,
    },
});
