import Animated, { interpolate, useAnimatedScrollHandler, useAnimatedStyle, useSharedValue } from "react-native-reanimated";
import { useQuery } from "@tanstack/react-query";
import { Text, View, Image, ScrollView, ActivityIndicator, FlatList, StyleSheet, Dimensions } from "react-native";

const uri = 'https://api.pexels.com/v1/search?query=clothing&per_page=10';
const { width, height, fontScale } = Dimensions.get("screen");

const _imageWidth = width * 0.7;
const _imageHeight = _imageWidth * 1.76;
const _spacing = 12; // space between images


const PhotoItem = ({ item, index, scrollX }) => {
    const animatedStyle = useAnimatedStyle(() => {
        return {
            transform: [
                {
                    scale: interpolate(
                        scrollX.value,
                        [index - 1, index, index + 1],
                        [1.6, 1, 1.6]
                    )
                },
                {
                    rotate: `${interpolate(
                        scrollX.value,
                        [index - 1, index, index + 1],
                        [15, 0, -15]
                    )}deg`,
                }
            ]
        }
    })
    return (
        <View style={styles.imageView}>
            <Animated.Image
                source={{ uri: item.src.medium }}
                // source={require('../assets/images/t-shirt.jpg')}
                
                style={[{ flex: 1,width:width,alignSelf:"center",justifyContent:"center",aspectRatio:1}, animatedStyle]}

            />
        </View>
    )
}

const BackDropPhoto = ({ item, index, scrollX }) => {
    const animatedStyle = useAnimatedStyle(() => {
        return {
            opacity: interpolate(scrollX.value,
                [index - 1, index, index + 1],
                [0, 1, 0])
        }
    })
    return (
        <Animated.View style={[StyleSheet.absoluteFill, animatedStyle]}>
          <Animated.Image
            source={{ uri: item.src.medium }}
            style={[StyleSheet.absoluteFillObject]}
            blurRadius={30}
          />
          <View style={styles.titleWrapper}>
            <Text style={styles.outfitName}>{item.alt || "Outfit Name"}</Text>
          </View>
        </Animated.View>
      );
}

const BackdropList = ({ data, scrollX }) => {
    return (
        <View style={StyleSheet.absoluteFill}>
            
            {data?.map((item, index) => (
                <BackDropPhoto
                    key={`bg-${item.id}`}
                    item={item}
                    index={index}
                    scrollX={scrollX}
                />
            ))}
        </View>
    );
};



export function PexelsWallpapers() {

    const scrollX = useSharedValue(0);
    const onScroll = useAnimatedScrollHandler((e) => {
        scrollX.value = e.contentOffset.x / (_imageWidth + _spacing);
    })

    const { data, isLoading, error } = useQuery({
        queryKey: ['pexels-wallpapers'],
        queryFn: async () => {
            const response = await fetch(uri, {
                headers: {
                    method: 'GET',
                    'Authorization': 'jJgpYZHgIP4BlBQE3jZsXgg7tH0oXSAqBykcifJI0bIEPVZvWx3Q6jna',
                },
            });
            const json = await response.json();
         
            return json.photos; // an array of photo objects
        },
    });

    if (isLoading) {
        return (
            <View style={styles.center}>
                <ActivityIndicator size="large" />
            </View>
        );
    }

    if (error || !data) {
        return (
            <View style={styles.center}>
                <Text>Error loading wallpapers</Text>
            </View>
        );
    }





    return (
        <View style={styles.center}>
            {/* <View style={StyleSheet.absoluteFillObject}>
            {data?.map((item,index)=>(
          
                    <BackDropPhoto   key={`bg-${item.id}`} item={item} index={index} scrollX={scrollX}/>
            )
            )
        }
        </View> */}
            <BackdropList data={data} scrollX={scrollX} />
            <Animated.FlatList
                data={data}
                keyExtractor={(item) => item.id.toString()}
                renderItem={({ item, index }) => (
                    <PhotoItem item={item} index={index} scrollX={scrollX} />
                )}
                horizontal
                contentContainerStyle={{
                    gap: _spacing,
                    paddingHorizontal: (width - _imageWidth) / 2,
                }}
                snapToInterval={_imageWidth + _spacing} // Adjust the interval to match the image width and gap
                decelerationRate={"fast"}
                style={{ flexGrow: 0 }} // Prevents the list from stretching to fill the screen
                showsHorizontalScrollIndicator={false}
                onScroll={onScroll}
                scrollEventThrottle={1000 / 60} // Adjust the throttle value as needed
            />

        </View>
    );
}

const styles = StyleSheet.create({

    center: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    imageView: {
        width: _imageWidth,
        height: _imageHeight,
        overflow: "hidden",
        borderRadius: 16
    },
    titleWrapper: {
        position: 'absolute',
        top: 60,
        left: 20,
        right: 20,
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 10,
      },
      outfitName: {
        fontSize: 18,
        color: '#fff',
        fontWeight: 'bold',
        textAlign: 'center',
        textShadowColor: 'rgba(0, 0, 0, 0.7)',
        textShadowOffset: { width: 0, height: 2 },
        textShadowRadius: 6,
      },
      
});