import React, { useState } from 'react';
import {
    Dimensions,
    FlatList,
    View,
} from 'react-native';
import useSearchSecondDegree from './useSearchSecondDegree';
import CustomButton from '@materialComponent/customButton/customButton';
import { moderateScale } from 'react-native-size-matters';

const { height } = Dimensions.get('screen');

const SearchSecondDegree = ({ route }) => {
    const {
        fetch_shop_categories,
        renderItem,
        subCategories
    } = useSearchSecondDegree({ route });

    const [showAll, setShowAll] = useState(false);

    const toggleShowAll = () => {
        setShowAll(!showAll);
    };

    const categoriesToShow = showAll ? fetch_shop_categories : fetch_shop_categories.slice(0, 8);

    return (
        <View>
            <FlatList
                numColumns={2}
                scrollEnabled={false}
                columnWrapperStyle={{ justifyContent: 'space-between' }}
                data={subCategories}
                showsVerticalScrollIndicator={false}
                keyExtractor={(item, index) => index.toString()}
                renderItem={renderItem}
                contentContainerStyle={{
                    marginTop: height * 0.01,
                }}
            />
        </View>
    );
}

export default SearchSecondDegree;
