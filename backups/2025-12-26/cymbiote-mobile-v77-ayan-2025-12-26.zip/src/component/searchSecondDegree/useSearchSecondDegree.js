import { useState, useEffect } from 'react';
import { Animated, View } from 'react-native';
import useReduxStore from '@utils/hooks/useReduxStore';
import { Dimensions, TouchableOpacity } from 'react-native';
import { font, WH } from '@constant/contstant';
import { SvgUri } from 'react-native-svg';
import CustomText from '@materialComponent/customText/customText';
import { moderateScale } from 'react-native-size-matters';
import { navigate } from '../../utils/navigationRef/navigationRef';
import { _fetchSubCategories } from '../../redux/actions/common/common';
import { colors } from '../../constant/contstant';
import { useNavigation } from '@react-navigation/native';

const { height } = Dimensions.get('screen');

const useSearchSecondDegree = ({ route }) => {
    const { getState, dispatch } = useReduxStore();
    const { fetch_shop_categories } = getState("user");

    // State to handle loading and animation for each item
    const [animations, setAnimations] = useState([]);
    const [loader, setLoader] = useState(false);
    const [subCategories, setSubCategories] = useState([]);
    const [loadingStates, setLoadingStates] = useState([]);

    // Initialize animations and loading states for each item

    const fetchAPI = async () => {
        setLoader(true)
        const response = await dispatch(_fetchSubCategories(route?.params?.first_degree_category))
        const newAnimations = response.map(() => new Animated.Value(0)); // Default to hidden (opacity 0)
        const newLoadingStates = response.map(() => true); // All items are initially loading
        setAnimations(newAnimations);
        setLoadingStates(newLoadingStates);
        setSubCategories(response)
        setLoader(false)
    }

    useEffect(() => {
        const categories = new Array(subCategories.length).fill(true)
        setLoadingStates(categories)
    }, [subCategories])

    // Function to handle item animations
    const animateItem = (index) => {
        if (animations[index]) {
            Animated.timing(animations[index], {
                toValue: 1, // Fade to fully visible
                duration: 300, // Animation duration
                useNativeDriver: true, // Use native driver for better performance
            }).start();
        }
    };

    // Function to handle when an SVG image has finished loading
    const handleImageLoad = (index) => {
        setLoadingStates(prevState => {
            const updatedState = [...prevState];
            updatedState[index] = false; // Mark item as loaded
            return updatedState;
        });
        animateItem(index); // Trigger the animation
    };

    const navigation = useNavigation()

    const renderItem = ({ item, index }) => {
        return (

            <TouchableOpacity
                onPress={() => navigation.push("SearchedItems", { searchTerm: item.store_sub_category_name })}
                activeOpacity={1}
                style={{
                    backgroundColor: item.category_background_color || colors.light_theme.theme,
                    width: "49%",
                    marginTop: index !== 1 && index !== 0 ? height * 0.01 : 0,
                    paddingVertical: height * 0.015,
                    borderRadius: 10,
                    justifyContent: 'center',
                    alignItems: "center",
                    // opacity: animations[index], // Apply animated opacity
                    // transform: animations[index] ? [{
                    //     translateY: animations[index].interpolate({
                    //         inputRange: [0, 1],
                    //         outputRange: [30, 0], // Animate from 30px down to original position
                    //     })
                    // }] : [],
                }}
            >
                {loadingStates[index] && (
                    <View style={{ width: WH.width(13), aspectRatio: 1, borderRadius: 180, backgroundColor: 'gray' }} />
                )}
                <SvgUri
                    uri={item.subcategory_image_url}
                    width={WH.width(13)}
                    height={WH.width(13)}
                    onLoad={() => handleImageLoad(index)} // Trigger when image loads
                />
                <CustomText
                    center
                    fontFamily={font.medium}
                    color="white"
                    fontSize={moderateScale(12)}
                    marginTop={height * 0.005}
                    text={item.store_sub_category_name}
                />
            </TouchableOpacity>
        );
    };

    useEffect(() => {
        fetchAPI()
    }, [])

    return {
        fetch_shop_categories,
        renderItem,
        subCategories
    };
};

export default useSearchSecondDegree;