import { moderateScale, verticalScale } from 'react-native-size-matters';
import { FlatList, Image, StyleSheet, View, Dimensions, TouchableOpacity, Animated } from 'react-native';
import { colors, WH, font } from '@constant/contstant';
import React, { useState } from 'react';
import CustomText from '@materialComponent/customText/customText';
import LinearGradient from 'react-native-linear-gradient';
import { margin } from '../../constant/contstant';
const { fontScale, height, width } = Dimensions.get("screen")

const TabBar = ({ arr, setId, id }) => {
    const handlePress = (index) => {
        setId(index);
    };
    return (
        <View style={{ width: "100%", zIndex: 1 }}>
            <FlatList
                renderItem={({ item, index }) => (
                    <TouchableOpacity activeOpacity={1} onPress={() => handlePress(index)}
                        style={[styles.contentContainer, index == id &&
                            { backgroundColor: "#cddbff", borderWidth: 1, borderColor: colors.light_theme.theme, },
                        index === 0 && { marginLeft: moderateScale(10) },
                        index === arr.length - 1 && { marginRight: moderateScale(10) },]}>
                        <View style={index == id && styles.active}>
                            <CustomText color={"black"} fontSize={fontScale * 14} fontFamily={font.medium} text={item} />
                        </View>
                    </TouchableOpacity>
                )}
                keyExtractor={(item, index) => index.toString()}
                contentContainerStyle={styles.flatlist}
                showsVerticalScrollIndicator={false}
                showsHorizontalScrollIndicator={false}
                data={arr}
                horizontal
            />
        </View>
    );
};

export default TabBar;

const styles = StyleSheet.create({
    contentContainer: {
        borderRadius: moderateScale(180),
        marginRight: moderateScale(5),
        backgroundColor: '#F1EDED',
        paddingHorizontal: width * 0.05,
        height: height * 0.045,
        justifyContent: "center",
        alignItems: "center",
        // marginHorizontal: margin.horizontal,


    },
    flatlist: {
        // marginBottom: verticalScale(20),
        // marginTop: verticalScale(10),
        justifyContent: 'center',
        height: WH.width(16),
        alignItems: 'center',
        // marginHorizontal: margin.horizontal,

    }
});
