import { verticalScale } from 'react-native-size-matters';
import { Animated, StyleSheet, Text, View } from 'react-native';
import { colors } from '@constant/contstant';
import React from 'react';

const BorderLine = ({ style, marginVertical, marginTop, marginBottom, backgroundColor }) => {
  return (
    <Animated.View
      style={[
        marginVertical && { marginVertical: marginVertical },
        marginBottom && { marginBottom: marginBottom },
        marginTop && { marginTop: marginTop },
        styles.border,
        backgroundColor && { backgroundColor: backgroundColor || colors.light_theme.borderColor, },
        style,
      ]}
    />
  );
};

export default BorderLine;

const styles = StyleSheet.create({
  border: {
    height: verticalScale(2),
    backgroundColor: colors.light_theme.borderColor,
    marginLeft: -200,
    width: "200%",
  },
});
