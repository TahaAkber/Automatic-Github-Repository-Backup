import { useEffect, useMemo, useRef, useState } from 'react';
import useReduxStore from '@utils/hooks/useReduxStore';
import { Dimensions, StyleSheet, TouchableOpacity, View } from 'react-native';
import SearchListItem from '@component/cards/searchListItem/searchListItem';
import { _recentSearchRecord } from '@redux/actions/common/common';
import Icon from '@materialComponent/icon/icon';
import CustomText from '@materialComponent/customText/customText';
import { moderateScale } from 'react-native-size-matters';
import { font, globalStyle } from '@constant/contstant';
import { colors } from '../../constant/contstant';
import { useNavigation } from '@react-navigation/native';
import {
  logSearchSkippedItemsEvent,
  logSearchTabChangeEvent,
} from '@helper/eventTriggers/useEventTriggers';

const { height } = Dimensions.get('screen');

const marginTop = height * 0.02;

const useActiveSearch = ({ searchQuery, displayedItems = [], localData = {} }) => {
  const { getState, dispatch } = useReduxStore();
  const { fetch_shop_categories } = getState('user');
  const { recentSearches, globalLoader } = getState('common');
  const [activeTab, setActiveTab] = useState('all');
  const navigation = useNavigation();
  const clickedItemsRef = useRef([]);
  const previousTabRef = useRef('all');

  // Handler for when an item is clicked
  const handleItemClick = (item, index) => {
    const itemId = item.type === 'shop' ? item.shop_id : item.product_id;
    if (!clickedItemsRef.current.includes(itemId)) {
      clickedItemsRef.current.push(itemId);

    }
  };

  // Handler for tab change with analytics
  const handleTabChange = newTab => {
    const fromTab = previousTabRef.current;
    const toTab = newTab;

    // Log tab change event
    if (searchQuery && fromTab !== toTab) {
      logSearchTabChangeEvent(searchQuery, fromTab, toTab, {
        all: (localData?.data?.all || []).length,
        products: (localData?.data?.products || []).length,
        shops: (localData?.data?.shops || []).length,
      });
    }

    previousTabRef.current = newTab;
    setActiveTab(newTab);
  };

  const renderSearchListItem = useMemo(
    () =>
      ({ item, index }) => {
        const isShop = item.type === 'shop';
        return (
          <SearchListItem
            marginTop={marginTop} // Add a marginTop for spacing between items
            item={item}
            navigation={navigation}
            searchQuery={searchQuery}
            position={index}
            onItemClick={() => handleItemClick(item, index)}
          />
        );
      },
    [searchQuery],
  );

  // Log skipped items when search query changes or component unmounts
  useEffect(() => {
    return () => {
      if (searchQuery && displayedItems.length > 0) {
        const skippedItems = displayedItems.filter(item => {
          const itemId = item.type === 'shop' ? item.shop_id : item.product_id;
          return !clickedItemsRef.current.includes(itemId);
        });

        logSearchSkippedItemsEvent(
          displayedItems,
          clickedItemsRef.current,
          searchQuery,
        );
      }
      // Reset clicked items for next search
      clickedItemsRef.current = [];
    };
  }, [searchQuery, displayedItems]);

  const renderSuggestionItem = useMemo(
    () =>
      ({ item, index }) => {
        return (
          <TouchableOpacity
            onPress={() =>
              dispatch(_recentSearchRecord({ searchTerm: item, navigation }))
            }
            style={[globalStyle.space_between, { marginTop: marginTop }]}>
            <View style={styles.searchListItem}>
              <View style={styles.imageView}>
                <Icon
                  icon_type={'AntDesign'}
                  name={'search1'}
                  size={moderateScale(15)}
                />
              </View>
              <CustomText
                fontSize={moderateScale(12)}
                fontFamily={font.medium}
                text={item}
                numberOfLines={1}
              />
            </View>
          </TouchableOpacity>
        );
      },
    [],
  );

  return {
    renderSearchListItem,
    renderSuggestionItem,
    recentSearches,
    dispatch,
    activeTab,
    setActiveTab,
    handleTabChange,
    navigation,
    handleItemClick,
  };
};

export default useActiveSearch;

const styles = StyleSheet.create({
  searchListItem: {
    ...globalStyle.row,
  },
  imageView: {
    width: moderateScale(40),
    height: moderateScale(40),
    backgroundColor: '#F2F2F2',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 180,
    marginRight: moderateScale(10),
    borderColor: colors.light_theme.darkBorderColor,
    borderWidth: 1,
  },
});
