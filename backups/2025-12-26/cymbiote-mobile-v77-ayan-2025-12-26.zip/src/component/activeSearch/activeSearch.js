import React from 'react';
import {
  Dimensions,
  FlatList,
  StyleSheet,
  TouchableOpacity,
  View,
} from 'react-native';
import OrderLoader from '@component/loader/orderLoader';
import useActiveSearch from './useActiveSearch';
import CustomText from '../../materialComponent/customText/customText';
import {colors, font, globalStyle, margin, WH} from '../../constant/contstant';
import {moderateScale, verticalScale} from 'react-native-size-matters';
import Icon from '../../materialComponent/icon/icon';
import {
  _recentSearchRecord,
  _recentSearchRemove,
} from '../../redux/actions/common/common';
import LinearGradient from 'react-native-linear-gradient';
import CercleThump from '@assets/images/cercle-thumb.svg';
import EmptyScreen from '../emptyScreen/emptyScreen';
import {navigate} from '../../utils/navigationRef/navigationRef';

const {height, width, fontScale} = Dimensions.get('screen');

const ActiveSearch = ({localData, searchLoader, value}) => {
  const {
    renderSearchListItem,
    renderSuggestionItem,
    recentSearches,
    dispatch,
    activeTab,
    setActiveTab,
    handleTabChange,
    navigation,
    handleItemClick,
  } = useActiveSearch({
    searchQuery: value,
    displayedItems: localData?.data?.[activeTab] || [],
    localData: localData,
  });

  const showEmptyScreen =
    !localData?.data?.['all'].length &&
    !localData?.data?.['products'].length &&
    !localData?.data?.['shops'].length &&
    !localData?.similar_suggestions?.length &&
    value;

 

  return (
    <View>
      {!value ? (
        <>
          <TouchableOpacity
            onPress={() => {
              navigate('ChatWithAI');
            }}>
            <View style={[styles.searchListItem, {paddingTop: height * 0.01}]}>
              <LinearGradient
                colors={['#00CE83', '#1A97CD', '#FF7F00', '#ED1D1D', '#6966CD']} // Gradient colors for the border
                start={{x: 0, y: 0}} // Gradient direction
                end={{x: 1, y: 1}} // Gradient direction
                style={[styles.imageView]} // Gradient border applied here
              >
                <View style={styles.iconWrapper}>
                  <CercleThump
                    width={moderateScale(16)}
                    height={moderateScale(16)}
                  />
                </View>
              </LinearGradient>
              <CustomText
                fontSize={moderateScale(14)}
                fontFamily={font.medium}
                text={value || 'Search with cercle AI'}
              />
            </View>
          </TouchableOpacity>
          {recentSearches.map((item, index) => {
            return (
              <TouchableOpacity
                onPress={() =>
                  dispatch(_recentSearchRecord({searchTerm: item, navigation}))
                }
                style={[globalStyle.space_between, {marginTop: height * 0.02}]}>
                <View style={styles.searchListItem}>
                  <View style={styles.imageView}>
                    <Icon
                      icon_type={'AntDesign'}
                      name={'search1'}
                      size={moderateScale(15)}
                    />
                  </View>
                  <View style={{maxWidth: '68%'}}>
                    <CustomText
                      fontSize={moderateScale(12)}
                      fontFamily={font.medium}
                      text={item}
                      numberOfLines={1}
                    />
                  </View>
                </View>
                <TouchableOpacity
                  onPress={() =>
                    dispatch(_recentSearchRemove({searchTerm: item}))
                  }
                  style={[styles.followContainer, styles.circle]}>
                  <Icon
                    icon_type="Ionicons"
                    name="close"
                    size={moderateScale(17)}
                    color={'black'}
                  />
                </TouchableOpacity>
              </TouchableOpacity>
            );
          })}
        </>
      ) : searchLoader ? (
        <OrderLoader
          rounded={true}
          removeHorizontalMargin={true}
          loading={searchLoader}
        />
      ) : showEmptyScreen ? (
        <View
          style={{
            flex: 1,
            justifyContent: 'center',
            alignItems: 'center',
            // backgroundColor: 'red',
            marginTop: '50%',
          }}>
          <EmptyScreen
            image={'empty_search'}
            heading={'We couldn’t find a match'}
            desc={'Try another keyword or search in'}
            // imageSize={width * 0.16}
            // headingSize={fontScale * 14}
            // descSize={fontScale * 12}
          />
          {/* <View
            style={[
              globalStyle.row,
              {
                flexWrap: 'wrap',
                width: '90%',
                justifyContent: 'center',
                marginTop: height * 0.01,
              },
            ]}>
            {recentSearches.map((item, index) => {
              return (
                <TouchableOpacity
                  onPress={() =>
                    dispatch(
                      _recentSearchRecord({searchTerm: item, navigation}),
                    )
                  }
                  style={[
                    globalStyle.space_between,
                    {marginTop: height * 0.01, marginRight: 5},
                  ]}>
                  <View
                    style={[
                      styles.searchListItem,
                      {
                        backgroundColor: '#f0f4ff',
                        padding: 10,
                        borderRadius: 10,
                      },
                    ]}>
                    <View style={{}}>
                      <CustomText
                        fontSize={moderateScale(12)}
                        fontFamily={font.medium}
                        text={item}
                        numberOfLines={1}
                      />
                    </View>
                  </View>
                </TouchableOpacity>
              );
            })}
          </View> */}
        </View>
      ) : (
        <>
          <TouchableOpacity
            onPress={() => {
              navigate('ChatWithAI', {searchQuery: value});
            }}>
            <View style={[styles.searchListItem, {paddingTop: height * 0.01}]}>
              <LinearGradient
                colors={['#00CE83', '#1A97CD', '#FF7F00', '#ED1D1D', '#6966CD']} // Gradient colors for the border
                start={{x: 0, y: 0}} // Gradient direction
                end={{x: 1, y: 1}} // Gradient direction
                style={[styles.imageView]} // Gradient border applied here
              >
                <View style={styles.iconWrapper}>
                  <CercleThump
                    width={moderateScale(16)}
                    height={moderateScale(16)}
                  />
                </View>
              </LinearGradient>
              <CustomText
                fontSize={moderateScale(14)}
                fontFamily={font.medium}
                text={value || 'Search with cercle AI'}
              />
            </View>
          </TouchableOpacity>
          {(localData?.data?.['all'] || [])?.length ? (
            <View style={styles.tabsContainer}>
              {tabs.map((item, index) => {
                return (
                  <TouchableOpacity
                    activeOpacity={1}
                    onPress={() => handleTabChange(item.keyword)}
                    key={`tabs_${index}`}
                    style={
                      item.keyword == activeTab
                        ? styles.activeTabs
                        : styles.tabs
                    }>
                    <CustomText
                      text={item.title}
                      color={item.keyword == activeTab ? 'white' : '#BBBBBB'}
                    />
                  </TouchableOpacity>
                );
              })}
            </View>
          ) : (
            <></>
          )}

          {(localData?.data?.[activeTab] || []).length ? (
            <FlatList
              // scrollEnabled={false}
              data={localData?.data?.[activeTab] || []}
              showsVerticalScrollIndicator={false}
              keyExtractor={(item, index) => index.toString()}
              renderItem={renderSearchListItem}
              contentContainerStyle={{
                marginTop: height * 0.01,
                marginBottom: height * 0.2,
              }}
            />
          ) : (
            <></>
          )}

          <FlatList
            scrollEnabled={false}
            data={localData?.similar_suggestions || []}
            showsVerticalScrollIndicator={false}
            keyExtractor={(item, index) => index.toString()}
            renderItem={renderSuggestionItem}
            // contentContainerStyle={{
            //     marginTop: height * 0.01,
            // }}
          />
        </>
      )}
    </View>
  );
};

export default ActiveSearch;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
  },
  innerContainer: {
    marginHorizontal: margin.horizontal,
    flex: 1,
    backgroundColor: 'white',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between', // Ensure proper spacing.
    marginVertical: verticalScale(10),
  },
  inputContainer: {
    borderRadius: 180,
    ...globalStyle.row,
    height: WH.height(5),
    paddingHorizontal: margin.horizontal,
    backgroundColor: 'rgba(201, 210, 239 , 0.4)',
    width: '80%',
  },
  searchbar: {
    fontFamily: font.medium,
    width: '100%',
    height: '100%',
    marginLeft: moderateScale(10),
    paddingRight: moderateScale(15),
  },
  cancelText: {
    fontFamily: font.medium,
    fontSize: moderateScale(16),
    color: colors.primary,
  },
  searchListItem: {
    ...globalStyle.row,
  },
  imageView: {
    width: moderateScale(40),
    height: moderateScale(40),
    backgroundColor: '#F2F2F2',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 180,
    marginRight: moderateScale(10),
    borderColor: colors.light_theme.darkBorderColor,
    borderWidth: 1,
  },
  circle: {
    backgroundColor: colors.light_theme.borderColor,
    borderRadius: 180,
    width: moderateScale(25),
    aspectRatio: 1 / 1,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: moderateScale(10),
  },
  iconWrapper: {
    backgroundColor: 'white', // Background color inside the border
    borderRadius: 180, // Same as the border radius for rounded corners
    padding: moderateScale(10), // Padding for the icon
  },
  activeTabs: {
    backgroundColor: 'black',
    width: '30%',
    paddingVertical: 5,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 5,
  },
  tabs: {
    backgroundColor: 'white',
    width: '30%',
    paddingVertical: 5,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 5,
  },
  tabsContainer: {
    ...globalStyle.space_between,
    borderWidth: 1,
    borderColor: '#E7E7E7',
    padding: width * 0.02,
    borderRadius: 5,
    marginTop: height * 0.01,
  },
});

const tabs = [
  {
    title: 'All',
    keyword: 'all',
  },
  {
    title: 'Products',
    keyword: 'products',
  },
  {
    title: 'Stores',
    keyword: 'shops',
  },
];
