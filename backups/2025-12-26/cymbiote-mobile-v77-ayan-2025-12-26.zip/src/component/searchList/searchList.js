import EmptySearchRecord from '@component/emptyRecord/emptySearchRecord';
import { moderateScale, verticalScale } from 'react-native-size-matters';
import { font, fontSizes, globalStyle } from '@constant/contstant';
import CustomText from '@materialComponent/customText/customText';
import { Animated, StyleSheet, Text, View } from 'react-native';
import CustomImage from '@materialComponent/image/image';
import { WH } from '@constant/contstant';
import React, { memo } from 'react';

const SearchList = ({ data, search }) => {
  const RenderItem = memo(({ item }) => {
    return (
      <View style={styles.searchListItem}>
        <View style={styles.imageView}>
          <CustomImage
            source={{ uri: item.image }}
            style={styles.Image}
            size={'small'}
          />
        </View>
        <CustomText
          fontSize={fontSizes.regular}
          fontFamily={font.regular}
          text={item.value}
        />
      </View>
    );
  });
  return (
    <View style={styles.container}>
      {data.length ? (
        <Animated.FlatList
          renderItem={({ item }) => <RenderItem item={item} />}
          keyExtractor={(item, index) => index.toString()}
          contentContainerStyle={styles.flatListBrand}
          showsHorizontalScrollIndicator={false}
          data={data}
        />
      ) : (
        <>
          {search ? (
            <EmptySearchRecord
              text={'Record Not Found!'}
              marginTop={WH.height(20)}
            />
          ) : (
            <Text>You can search data</Text>
          )}
        </>
      )}
    </View>
  );
};

export default SearchList;

const styles = StyleSheet.create({
  container: {
    marginTop: verticalScale(10),
    flex: 1,
  },
  searchListItem: {
    paddingHorizontal: moderateScale(10),
    borderRadius: moderateScale(10),
    marginTop: verticalScale(10),
    height: verticalScale(50),
    backgroundColor: 'rgba(239, 239, 239, 0.8)',
    ...globalStyle.row,
  },
  imageView: {
    marginRight: moderateScale(10),
    height: moderateScale(40),
    width: moderateScale(40),
    justifyContent: 'center',
    backgroundColor: 'white',
    alignItems: 'center',
    borderRadius: 180,
  },
  Image: {
    height: moderateScale(25),
    width: moderateScale(25),
    borderRadius: 180,
  },
});
