import React from 'react';
import Svg, { Path } from 'react-native-svg';
import { View, StyleSheet, Dimensions } from 'react-native';

const { height: screenHeight } = Dimensions.get('window'); // Get screen height

const Voucher = ({ width = 337, height = '30%', children }) => {
    // Calculate height based on screen height if height is a percentage
    const calculatedHeight = typeof height === 'string' && height.includes('%')
        ? (parseInt(height) / 100) * screenHeight
        : height;

    return (
        <View style={[styles.container, { width, height: calculatedHeight }]}>
            <Svg width={width} height={calculatedHeight} viewBox={`0 0 ${width} ${calculatedHeight}`} xmlns="http://www.w3.org/2000/svg">
                {/* First Path (white background) */}
                <Path
                    fillRule="evenodd"
                    clipRule="evenodd"
                    d="M102,7c3.3,0,6-2.7,6-6h216c6.6,0,12,5.4,12,12v76c0,6.6-5.4,12-12,12H107c0-3.3-2.7-6-6-6c-3.3,0-6,2.7-6,6H13c-6.6,0-12-5.4-12-12V13C1,6.4,6.4,1,13,1h83C96,4.3,98.7,7,102,7z"
                    fill="#FFFFFF"
                />

                {/* Second Path (light gray background) */}
                <Path
                    d="M108,1V0h-1v1H108z M107,101h-1v1h1V101z M95,101v1h1v-1H95z M96,1h1V0h-1V1z M107,1c0,2.8-2.2,5-5,5v2c3.9,0,7-3.1,7-7H107z M324,0H108v2h216V0z M337,13c0-7.2-5.8-13-13-13v2c6.1,0,11,4.9,11,11H337z M337,89V13h-2v76H337z M324,102c7.2,0,13-5.8,13-13h-2c0,6.1-4.9,11-11,11V102z M107,102h217v-2H107V102z M108,101c0-3.9-3.1-7-7-7v2c2.8,0,5,2.2,5,5H108z M101,94c-3.9,0-7,3.1-7,7h2c0-2.8,2.2-5,5-5V94z M13,102h82v-2H13V102z M0,89c0,7.2,5.8,13,13,13v-2c-6.1,0-11-4.9-11-11H0z M0,13v76h2V13H0z M13,0C5.8,0,0,5.8,0,13h2C2,6.9,6.9,2,13,2V0z M96,0H13v2h83V0z M102,6c-2.8,0-5-2.2-5-5h-2c0,3.9,3.1,7,7,7V6z"
                    fill="#E6E9ED"
                />

                {/* Third Path (dashed line) */}
                <Path
                    d="M101.5,7v88"
                    fill="none"
                    stroke="#E6E9ED"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeDasharray="9,6"
                />
            </Svg>

            {/* Render Children Inside the Voucher */}
            <View style={styles.childrenContainer}>
                {children}
            </View>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        position: 'relative',
        padding: 0, // No padding for the container
        margin: 0,  // No margin for the container
        overflow: 'hidden', // Prevent overflow of the content
    },
    childrenContainer: {
        position: 'absolute', // Absolute positioning
        top: 0, // Ensure the children are within the bounds of the SVG
        left: 0, // Ensure the children are within the bounds of the SVG
        right: 0, // Ensure the children are within the bounds of the SVG
        bottom: 0, // Ensure the children are within the bounds of the SVG
        justifyContent: 'center',
        alignItems: 'center',
    },
});

export default Voucher;
