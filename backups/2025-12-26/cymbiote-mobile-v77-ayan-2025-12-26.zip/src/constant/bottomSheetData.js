import images from "../assets/images/images";
import { WH } from "./contstant";
import Message from "@assets/images/message.svg"
import Email from "@assets/images/email.svg"
import { navigate } from "../utils/navigationRef/navigationRef";


export const forgotPasswordData = [
    {
        image: Message,
        width: WH.width(5),
        height: WH.width(5),
        value: "Password reset via SMS",
        next: true,
        onPress: () => navigate("ForgotPassword", { email: false })
    },
    {
        image: Email,
        width: WH.width(5),
        height: WH.width(5),
        value: "Password reset via Email",
        next: true,
        onPress: () => navigate("ForgotPassword", { email: true })
    }
]