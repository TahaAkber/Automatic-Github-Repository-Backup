import TopBackOverLay from '@materialComponent/backOverlay/topBackOverlay';
import Container from '@materialComponent/container/container';
import SnakeWave from '@materialComponent/snakeWave/snakeWave';
import SocialRegisterForm from './socialRegisterForm';
import React from 'react';
import { useIsFocused } from '@react-navigation/native';

const SocialRegister = ({ route }) => {
    const isFocused = useIsFocused()
    return (
        <Container
            barColor={"transparent"}
            translucent={true}
            isFocused={isFocused}
            dark
        >
            <SnakeWave />
            <SocialRegisterForm route={route} />
            <TopBackOverLay />
        </Container>
    );
};

export default SocialRegister;