import {_login, _socialLogin, _sendOtp} from '@redux/actions/auth/auth';
import {_getStores} from '@redux/actions/merchant/merchant';
import {_globalLoader} from '@redux/actions/common/common';
import useReduxStore from '@utils/hooks/useReduxStore';
import {useRef, useState} from 'react';
import * as Yup from 'yup';
import DeviceInfo from 'react-native-device-info';

const useSocialRegister = ({route}) => {
  const {getState, dispatch} = useReduxStore();
  const {fetch_token} = getState('auth');
  const [loader, setLoader] = useState(false);
  const phoneNoRef = useRef(null);
  const createPasswordRef = useRef(null);

  const validationSchema = Yup.object({
    // email: Yup.string()
    //     .required('Email is required'), // Ensures email field is not empty
  });

  const _handleSubmit = async values => {
    setLoader(true);
    const deviceId = await DeviceInfo.getUniqueId();
    const deviceName = await DeviceInfo.getManufacturer();
    const value = {
      ...values,
      ...route?.params?.data,
      device_id: deviceId,
      deviceName,
    };
    value.isLogin = false;

    const res = await dispatch(_socialLogin({ data: value }))
    setLoader(false);
  };

  return {
    _handleSubmit,
    validationSchema,
    createPasswordRef,
    phoneNoRef,
    loader,
  };
};

export default useSocialRegister;
