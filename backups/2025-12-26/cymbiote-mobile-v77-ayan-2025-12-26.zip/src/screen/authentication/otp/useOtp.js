import { _login, _socialLogin, _sendOtp } from '@redux/actions/auth/auth';
import { _getStores } from '@redux/actions/merchant/merchant';
import { _globalLoader } from '@redux/actions/common/common';
import useReduxStore from '@utils/hooks/useReduxStore';
import { useEffect, useState } from 'react';
import * as Yup from 'yup';
import { Vibration } from 'react-native';
import { triggerHaptic } from '../../../utils/haptic/haptic';
import { useIsFocused } from '@react-navigation/native';


const useOtp = ({ route }) => {
    const { getState, dispatch } = useReduxStore()
    const [loader, setLoader] = useState(false)
    const isFocused = useIsFocused()
    const [countdown, setCountdown] = useState(60); // Initial countdown value

    const _handleSubmit = async () => {
        triggerHaptic()
        setLoader(true)
        const res = await dispatch(_sendOtp({ params: route.params?.data, identifier: route?.params?.data?.identifier, sendAgain: true }))
        resetCountdown()
        setLoader(false)
    }

    // Reset the countdown to 60 seconds
    const resetCountdown = () => {
        setCountdown(60);
    };

    useEffect(() => {
        const interval = setInterval(() => {
            setCountdown((prev) => {
                if (prev <= 0) {
                    clearInterval(interval); // Clear interval when countdown reaches 0
                    return 0;
                }
                return prev - 1; // Decrement countdown
            });
        }, 1000);

        return () => clearInterval(interval); // Cleanup interval on unmount
    }, [countdown]); // Run only once on mount


    return {
        _handleSubmit,
        countdown,
        isFocused,
        loader
    };
};

export default useOtp;
