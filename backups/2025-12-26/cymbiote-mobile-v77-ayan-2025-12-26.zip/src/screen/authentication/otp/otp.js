import React from 'react';
import { ActivityIndicator, StyleSheet, TouchableOpacity, View } from 'react-native';
import { globalStyle, margin, colors, font, WH } from '@constant/contstant';
import TopBackOverLay from '@materialComponent/backOverlay/topBackOverlay';
import { moderateScale, verticalScale } from 'react-native-size-matters';
import CustomText from '@materialComponent/customText/customText';
import OtpContainer from '@component/otpContainer/otpContainer';
import SnakeWave from '@materialComponent/snakeWave/snakeWave';
import Container from '@materialComponent/container/container';
import Content from '@materialComponent/content/content';
import OtpSvg from "@assets/images/otp.svg"
import ForgotPasswordSvg from "@assets/images/set_password.svg"
import useOtp from './useOtp';

const Otp = ({ route }) => {
    const { data } = route.params
    const { _handleSubmit, loader, countdown, isFocused } = useOtp({ route })
    

    return (
        <Container
            barColor={"transparent"}
            translucent={true}
            isFocused={isFocused}
            dark
        >
            <SnakeWave />
            <Content contentContainerStyle={styles.mainView}>
                {/* Main Content */}
                <View style={[styles.mainView, { paddingHorizontal: margin.horizontal }]}>
                    <View style={styles.headerContainer}>
                        {data?.forgotPassword ?
                            <ForgotPasswordSvg width={WH.height(8)} height={WH.height(8)} />
                            :
                            <OtpSvg width={WH.height(8)} height={WH.height(8)} />
                        }
                        <View style={[styles.titleContainer, data?.socialtype && { width: "100%" }]}>
                            <CustomText center fontFamily={font.bold} text={data?.forgotPassword ? "Forgot Password" : data?.socialtype ? " an SMS" : "Enter OTP"} style={styles.titleText} />
                        </View>
                        <View style={styles.subtitleContainer}>
                            <CustomText
                                center
                                fontSize={moderateScale(12)}
                                fontFamily={font.light}
                                text={data?.forgotPassword ? "Enter the security code we sent to" : data?.socialtype ? "Enter the security code we sent to" : "Enter the otp we sent to "}
                            />
                            <CustomText
                                center
                                fontSize={moderateScale(12)}
                                fontFamily={font.light}
                                text={data?.identifier}
                            />
                        </View>
                    </View>
                    <OtpContainer route={route?.params} />
                    <View style={[globalStyle.space_between, { marginTop: WH.height(2) }]}>
                        <View style={[globalStyle.row]}>
                            <CustomText
                                center
                                fontSize={moderateScale(15)}
                                fontFamily={font.bold}
                                text={"Didn’t get the code?"}
                            />
                            {loader ? <ActivityIndicator size={"small"} color={colors.light_theme.theme} style={{ marginLeft: WH.width(3) }} /> :
                                <TouchableOpacity activeOpacity={1} onPress={() => !countdown && _handleSubmit()}>
                                    <CustomText
                                        center
                                        fontSize={moderateScale(15)}
                                        fontFamily={font.bold}
                                        text={"Resent it"}
                                        style={[countdown && { opacity: 0.5 }, { marginLeft: 5, color: colors.light_theme.theme }]}
                                    />
                                </TouchableOpacity>
                            }

                        </View>

                        <CustomText
                            center
                            fontSize={moderateScale(15)}
                            fontFamily={font.bold}
                            text={countdown ? (countdown + "s") : ""}
                        />

                    </View>
                    {/* <CustomButton text={"Done"} marginTop={WH.height(4)} /> */}
                </View>
            </Content>
            <TopBackOverLay />
        </Container>
    );
};

export default Otp;

const styles = StyleSheet.create({
    mainView: {
        flex: 1,
        // backgroundColor: colors.light_theme.background,
    },
    imageContainer: {
        alignItems: 'center',
        marginTop: verticalScale(20),
    },
    image: {
        width: moderateScale(150),
        height: moderateScale(150),
        resizeMode: 'contain',
    },
    footer: {
        position: 'absolute',
        bottom: 100,
        justifyContent: 'center',
        alignSelf: 'center',
        alignItems: 'center',
        flexDirection: 'row',
    },
    headerContainer: {
        marginHorizontal: margin.horizontal,
        justifyContent: "center",
        alignItems: "center",
        marginTop: WH.height(15),
    },
    titleContainer: {
        width: "80%",
        justifyContent: "center",
        alignItems: "center",
        marginTop: WH.height(2),
    },
    titleText: {
        fontFamily: font.bold,
        fontSize: moderateScale(25),
        color: "black",
    },
    subtitleContainer: {
        width: "80%",
        justifyContent: "center",
        alignItems: "center",
        marginTop: verticalScale(10),
    },
    buttonContainer: {
        flexDirection: "row",
        marginHorizontal: margin.horizontal,
        marginTop: WH.height(4),
        paddingHorizontal: WH.width(1),
        borderRadius: 15,
        backgroundColor: colors.light_theme.backgroundColor,
        borderWidth: 2,
        borderColor: "#f1f1f1",
        position: "relative",
    },
    slider: {
        position: "absolute",
        width: "50%",
        height: "100%",
        backgroundColor: "white",
        borderRadius: 15,
    },
    button: {
        flex: 1,
        marginVertical: WH.height(0.3),
        paddingVertical: WH.height(1),
        justifyContent: "center",
        alignItems: "center",
        borderRadius: 10,
    },
    buttonText: {
        fontFamily: font.medium,
    },
});
