import React from 'react';
import Container from '@materialComponent/container/container';
import RegisterForm from './registerForm';
import BackOverLay from '@materialComponent/backOverlay/backOverlay';

const Register = () => {
    return (
        <Container>
            <RegisterForm />
            <BackOverLay />
        </Container>
    );
};

export default Register;

    // marginTop: index == 0 ? height * 0.002 : height * 0.02,
    //     borderRadius: 15,
    //     borderWidth: 0,
    //     backgroundColor: 'white',
    //     elevation: 8,