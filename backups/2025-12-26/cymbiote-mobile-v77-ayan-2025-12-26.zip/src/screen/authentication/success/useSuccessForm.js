import {_login, _socialLogin, _sendOtp} from '@redux/actions/auth/auth';
import {navigate} from '@utils/navigationRef/navigationRef';
import {_getStores} from '@redux/actions/merchant/merchant';
import {_globalLoader} from '@redux/actions/common/common';
import {_resetPassword} from '@redux/actions/auth/auth';
import { Vibration } from 'react-native';
import { triggerHaptic } from '../../../utils/haptic/haptic';

const useSuccessForm = ({route}) => {
  const {method, title, subTitle, intrestShow} = route?.params;

  const _handleSubmit = async values => {
    triggerHaptic()
    if (intrestShow) {
      navigate('Intrest', {method});
    } else {
      method();
    }
  };

  return {
    _handleSubmit,
    title,
    subTitle,
  };
};

export default useSuccessForm;
