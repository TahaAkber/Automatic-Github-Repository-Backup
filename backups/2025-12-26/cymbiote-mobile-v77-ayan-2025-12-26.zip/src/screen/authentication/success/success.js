import React from 'react';
import Container from '@materialComponent/container/container';
import SuccessForm from './successForm';
import SnakeWave from '@materialComponent/snakeWave/snakeWave';
import TopBackOverLay from '@materialComponent/backOverlay/topBackOverlay';
import { useIsFocused } from '@react-navigation/native';

const Success = ({ route }) => {
    const isFocused = useIsFocused()
    return (
        <Container
            barColor={"transparent"}
            translucent={true}
            isFocused={isFocused}
            dark
        >
            <SnakeWave />
            <SuccessForm route={route} />
        </Container>
    );
};

export default Success;