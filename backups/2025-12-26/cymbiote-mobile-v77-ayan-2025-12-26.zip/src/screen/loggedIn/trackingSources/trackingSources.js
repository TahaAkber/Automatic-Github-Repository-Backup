import React from 'react';
import {
  Dimensions,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import InnerHeader from '@component/header/innerHeader';
import Content from '@materialComponent/content/content';
import {colors, font, globalStyle, WH, margin} from '@constant/contstant';
import Google from '@assets/images/google.svg';
import Outlook from '@assets/images/outlook.svg';
import Secure from '@assets/images/secure.svg';
// import CustomButton from '@materialComponent/customButton/customButton';
import CustomText from '@materialComponent/customText/customText';
import BorderLine from '@component/borderLine/borderLine';
import useTrackingSources from './useTrackingSources';
import CustomButton from '../../../materialComponent/customButton/customButton';
import Icon from '../../../materialComponent/icon/icon';
import BottomSheetDelete from '../../../materialComponent/bottomSheet/bottomSheetDelete';
import Container from '../../../materialComponent/container/container';

const {height, fontScale, width} = Dimensions.get('screen');

const TrackingSources = () => {
  const {
    _handleGoogleLogin,
    _handleRemoveAccount,
    setCurrentAccountId,
    fetch_connected_account,
    refRBSheet,
  } = useTrackingSources({});

  return (
    <Container barColor={'white'}>
      <View style={styles.mainView}>
        <InnerHeader title="Order tracking sources" />
        <Content>
          <View style={styles.content}>
            <Text style={styles.text}>
              Connect multiple email accounts to{' '}
              <Text style={{color: colors.light_theme.theme}}>Cercle</Text> and
              have all of your orders tracked in one place.
            </Text>
            {fetch_connected_account.map((item, index) => {
              return (
                <View style={[globalStyle.row, {marginTop: height * 0.03}]}>
                  <Google height={width * 0.12} width={width * 0.12} />
                  <View style={styles.connectAccount}>
                    <CustomText
                      fontFamily={font.medium}
                      fontSize={fontScale * 18}
                      text="Gmail Inbox"
                      // text={`${item.child_social_type} Inbox`}
                    />
                    <CustomText
                      fontFamily={font.regular}
                      fontSize={fontScale * 16}
                      text={item.child_social_email}
                    />
                  </View>
                  {/* {
                    item.child_social_status == "active" ?
                      <TouchableOpacity onPress={() => {
                        refRBSheet?.current?.open();
                        setCurrentAccountId(item.link_connect_id)
                      }} style={styles.circle}>
                        <Icon icon_type={"MaterialCommunityIcons"} name={"delete-outline"} color={"black"} size={fontScale * 20} />
                      </TouchableOpacity>
                      :
                      <TouchableOpacity onPress={_handleGoogleLogin} style={styles.reconnect}>
                        <CustomText text={"Reconnect"} fontFamily={font.bold} color={"red"} fontSize={fontScale * 10} />
                      </TouchableOpacity>

                  } */}
                  <TouchableOpacity
                    onPress={() => {
                      refRBSheet?.current?.open();
                      setCurrentAccountId(item.link_connect_id);
                    }}
                    style={styles.circle}>
                    <Icon
                      icon_type={'MaterialCommunityIcons'}
                      name={'delete-outline'}
                      color={'black'}
                      size={fontScale * 20}
                    />
                  </TouchableOpacity>
                </View>
              );
            })}

            <BorderLine style={styles.borderLine} marginTop={height * 0.015} />
            <CustomButton
              backgroundColor="white"
              outline
              marginTop={WH.height(4)}
              ImageComponentSize={width * 0.06}
              ImageComponent={Google}
              text="Connect Gmail"
              // imageComponentStyle={{left: '2%'}}
              onPress={_handleGoogleLogin}
              textStyle={{
                color: 'black',
                fontFamily: font.medium,
                fontSize: fontScale * 15,
              }}
              imageComponentStyle={{marginRight : "4%"}}
            />

            {/* <CustomButton
            backgroundColor="white"
            outline
            marginTop={WH.height(1)}
            ImageComponentSize={width * 0.06}
            ImageComponent={Outlook}
            text="Connect Outlook"
            imageComponentStyle={{ left: '25%' }}
            textStyle={{
              color: 'black',
              fontFamily: font.medium,
              fontSize: fontScale * 15,
            }}
          /> */}
            <View style={styles.secure}>
              <Secure height={width * 0.06} width={width * 0.06} />
              <CustomText
                style={{marginLeft: '5%', width: '85%'}}
                text="We use your shipping and order emails solely for package tracking updates, never for advertising or targeting."
              />
            </View>
          </View>
          <BottomSheetDelete
            refRBSheet={refRBSheet}
            height={height * 0.3}
            heading={'Are you sure you want to remove this account?'}
            desc={'If you want to remove the account, then press okay.'}
            onPress={_handleRemoveAccount}
            buttonText={'Okay'}
          />
        </Content>
      </View>
    </Container>
  );
};

export default TrackingSources;

const styles = StyleSheet.create({
  mainView: {
    flex: 1,
    backgroundColor: 'white',
  },
  content: {
    marginHorizontal: margin.horizontal,
    paddingBottom: height * 0.1,
  },
  text: {
    color: 'black',
    fontFamily: font.regular,
    fontSize: fontScale * 17,
  },
  connectAccount: {
    marginLeft: '4%',
  },
  borderLine: {
    marginLeft: 0,
    width: '100%',
    backgroundColor: colors.light_theme.borderColor,
    height: height * 0.003,
  },
  secure: {
    flexDirection: 'row',
    marginTop: height * 0.03,
    width: '100%',
  },
  circle: {
    width: '12%',
    position: 'absolute',
    right: 0,
    bottom: 0,
    borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: height * 0.005,
    borderColor: colors.light_theme.borderColor,
    borderRadius: 180,
    aspectRatio: 1,
  },
  reconnect: {
    width: '25%',
    position: 'absolute',
    right: 0,
    top: 0,
    borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: height * 0.005,
    borderColor: 'red',
    borderRadius: 5,
  },
});
