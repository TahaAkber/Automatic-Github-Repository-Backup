import {_register, _socialLogin, _userVerifier} from '@redux/actions/auth/auth';
import {_getStores} from '@redux/actions/merchant/merchant';
import {_globalLoader} from '@redux/actions/common/common';
import useReduxStore from '@utils/hooks/useReduxStore';
import {useEffect, useRef, useState} from 'react';
import {GoogleSignin} from '@react-native-google-signin/google-signin';
import {
  _connectSocialAccount,
  _getConnectedAccounts,
  _removeConnectedAccount,
} from '../../../redux/actions/orders/orders';
import {showToast} from '../../../helper/reUsableMethod/reUsableMethod';

const useTrackingSources = ({route}) => {
  const {getState, dispatch} = useReduxStore();
  const {fetch_user_detail} = getState('auth');
  const {
    fetch_connected_account,
    fetch_connected_account_loader,
    fetch_connected_account_error,
  } = getState('order');
  const [pullLoader, setPullLoader] = useState(false);
  const [currentAccountId, setCurrentAccountId] = useState();
  const refRBSheet = useRef();

  const fetchAPI = async isLoading => {
    !isLoading && setPullLoader(true);
    await dispatch(_getConnectedAccounts());
    setPullLoader(false);
  };

  const _handleGoogleLogin = async () => {
    try {
      await GoogleSignin.hasPlayServices();
      const userInfo = await GoogleSignin.signIn();
      try {
   
        await dispatch(
          _connectSocialAccount(
            userInfo?.data?.user?.id,
            userInfo?.data?.user?.email,
            'google',
            userInfo.data?.serverAuthCode,
          ),
        );
        await GoogleSignin.signOut();
      } catch (error) {
        showToast(userInfo?.data?.user?.id ? error.message : 'Invalid Attempt');
      }
    } catch (error) {
      showToast(error.message);
    }
  };

  const _handleRemoveAccount = () => {
    dispatch(_removeConnectedAccount(currentAccountId));
  };

  useEffect(() => {
    fetchAPI(true);
    GoogleSignin.configure({
      webClientId:
        '1045679124479-aqeukkjlkf80aim1i44dlul46cgp3upn.apps.googleusercontent.com',
      offlineAccess: true,
      scopes: ['https://www.googleapis.com/auth/gmail.readonly'],
    });
  }, []);

  return {
    fetchAPI,
    _handleGoogleLogin,
    _handleRemoveAccount,
    pullLoader,
    fetch_connected_account,
    setCurrentAccountId,
    refRBSheet,
  };
};

export default useTrackingSources;
