import {
    Dimensions,
    FlatList,
    StatusBar,
    StyleSheet,
    View,
} from 'react-native';
import React, { useState } from 'react';
import { moderateScale, scale, verticalScale } from 'react-native-size-matters';
import InnerHeader from '@component/header/innerHeader';
import { colors, font, globalStyle, shadow, WH } from '@constant/contstant';
import ProfileImage from '@component/profileImage/profileImage';
import { margin } from '@constant/contstant';
import LabelInput from '../../../component/input/labelInput';
import CustomButton from '../../../materialComponent/customButton/customButton';

const { fontScale, height, width } = Dimensions.get("screen")

const EditProfile = () => {
    const { firstName, setFirstName } = useState("")
    const { lastName, setLastName } = useState("")
    const { userName, setUserName } = useState("")
    const { phone, setPhone } = useState("")
    return (
        <View style={styles.mainView}>
            <StatusBar animated barStyle={"dark-content"} backgroundColor={"white"} translucent={false} />
            <InnerHeader title={'Edit Profile'} />
            <View style={{ flex: 1 }}>
                <ProfileImage edit />
                <LabelInput
                    label="First Name"
                    value={firstName}
                    onChangeText={setFirstName}
                    placeholder="Enter your first name"
                    marginTop={height * 0.05}
                />
                <LabelInput
                    label="Last Name"
                    value={lastName}
                    onChangeText={setLastName}
                    placeholder="Enter your last name"
                    marginTop={height * 0.01}
                />
                <LabelInput
                    label="User Name"
                    value={userName}
                    onChangeText={setUserName}
                    placeholder="Enter your user name"
                    marginTop={height * 0.01}
                />
                <LabelInput
                    label="Phone number"
                    value={phone}
                    onChangeText={setPhone}
                    placeholder="Enter your phone number"
                    marginTop={height * 0.01}
                />
                <CustomButton marginTop={height * 0.02} text={"Submit"} />
            </View>
        </View>
    );
};

export default EditProfile;

const styles = StyleSheet.create({
    mainView: {
        flex: 1,
        backgroundColor: 'white',
        paddingHorizontal: margin.horizontal
    },
    flatLists: {
        paddingVertical: verticalScale(10),
        paddingBottom: globalStyle.bottomSpace.marginBottom,
    },
});