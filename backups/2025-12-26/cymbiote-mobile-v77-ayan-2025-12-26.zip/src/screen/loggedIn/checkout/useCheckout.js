import useReduxStore from '@utils/hooks/useReduxStore';
import {FETCH_CART_DB_ITEM, FETCH_CART_ITEM} from '@redux/types/cart/cart';
import {useEffect, useState} from 'react';
import {_getInternalOrder} from '@redux/actions/orders/orders';
import {_removeShop} from '@redux/actions/cart/cart';
import {useIsFocused} from '@react-navigation/native';

const useCheckout = ({route}) => {
  const {shop_id, item, order_email} = route.params;
  const {dispatch, getState} = useReduxStore();
  const {cart, cart_item} = getState('cart');
  const [localCart, setLocalCart] = useState([]);
  const [showThankYouPage, setShowThankYouPage] = useState(true);
  const isFocused = useIsFocused();


  const resetStates = () => {
    setShowThankYouPage(true);
    const removeCartItem = cart?.filter(
      (item, index) => item.shop_id != shop_id,
    );
    const removeItem = cart_item?.filter(
      (item, index) => item.shop.shop_id != shop_id,
    );
    const selectedCart = cart_item?.find(item => item.shop.shop_id === shop_id);

    if (selectedCart) {
      const selectedCartId = selectedCart.cartId;

      // 2. Dispatch action to remove shop from cart
      dispatch(_removeShop(shop_id, selectedCartId));
    }

    dispatch({type: FETCH_CART_ITEM, payload: removeCartItem});
    dispatch({type: FETCH_CART_DB_ITEM, payload: removeItem});

    // dispatch(_getInternalOrder({page: 1, tab: 0}));
  };

  useEffect(() => {
    resetStates();
    const getCurrentCart = cart_item?.find(
      item => item?.shop?.shop_id === shop_id,
    );
    setLocalCart(getCurrentCart);
  }, []);

  return {
    showThankYouPage,
    cart,
    cart_item,
    dispatch,
    getState,
    shop_id,
    localCart,
    item,
    isFocused,
    order_email,
  };
};

export default useCheckout;
