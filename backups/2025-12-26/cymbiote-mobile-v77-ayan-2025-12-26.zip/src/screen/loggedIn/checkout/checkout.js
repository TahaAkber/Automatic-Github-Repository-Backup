import React, {useRef} from 'react';
import {StyleSheet, Text, View} from 'react-native';
import {scale, verticalScale} from 'react-native-size-matters';
import InnerHeader from '@component/header/innerHeader';
import {globalStyle} from '@constant/contstant';
import {WebView} from 'react-native-webview';
import useCheckout from './useCheckout';
import ThankYou from '../thankYou/thankYou';
import Container from '../../../materialComponent/container/container';

const Checkout = ({route}) => {
  const {localCart, item, isFocused, order_email} = useCheckout({route});

  // ✅ Updated injected script (works on iOS + Android)
  const injectedJavaScript = `
    setTimeout(function() {
      // Disable the email input field
      const emailInput = document.querySelector('input[name="email"]');
      if (emailInput) {
        emailInput.disabled = true;
        emailInput.style.backgroundColor = "#f0f0f0";
        console.log('Email input disabled.');
      }

      // Shopify "Sign in" link usually contains /customer_authentication/login
      const loginLink = document.querySelector('a[href*="customer_authentication/login"]');
      if (loginLink) {
        loginLink.style.display = "none"; // Hide instead of remove
        console.log('Log in link hidden.');
      }
    }, 1000);
    true;
  `;


  return (
    <Container isFocused={isFocused} barColor={'white'} dark>
      <View style={styles.mainView}>
        <ThankYou data={item} order_email={order_email} />
      </View>
    </Container>
  );
};

export default Checkout;

const styles = StyleSheet.create({
  mainView: {
    flex: 1,
    backgroundColor: 'white',
  },
  flatLists: {
    paddingHorizontal: scale(15),
    paddingVertical: verticalScale(10),
    paddingBottom: globalStyle.bottomSpace.marginBottom,
  },
});
