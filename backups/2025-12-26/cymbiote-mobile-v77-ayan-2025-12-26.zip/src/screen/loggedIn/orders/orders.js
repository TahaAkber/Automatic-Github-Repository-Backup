import {
  Dimensions,
  StatusBar,
  StyleSheet,
  View,
  Animated,
  ScrollView,
  ActivityIndicator,
  RefreshControl,
  FlatList,
} from 'react-native';
import React, {useCallback, useEffect, useMemo, useState} from 'react';
import InnerHeader from '@component/header/innerHeader';
import {margin} from '@constant/contstant';
import {navigate} from '@utils/navigationRef/navigationRef';
import PendingReviewCard from '@component/cards/pendingReviewCard/pendingReviewCard';
import TabBar from '@component/tabBar/tabBar';
import useInnerHeaderAnimation from '../../../hooks/innerHeaderAnimation';
import Content from '@materialComponent/content/content';
import OrderHistoryCard from '@component/cards/orderHistoryCard/orderHistoryCard';
import {homeData} from '@constant/dummyData';
import useOrders from './useOrders';
import useReduxStore from '../../../utils/hooks/useReduxStore';
import {_getCancellationEnums} from '../../../redux/actions/orders/orders';
import {colors, globalStyle} from '../../../constant/contstant';
import CustomSkeleton from '../../../materialComponent/customSkeleton/customSkeleton';
import OrderLoader from '../../../component/loader/orderLoader';
import PagionationLoader from '../../../component/loader/endReachLoader';
import {handleScroll, showErrorScreen} from '../../../utils/helper/helper';
import EmptyScreen from '../../../component/emptyScreen/emptyScreen';
import {moderateScale} from 'react-native-size-matters';
import Container from '../../../materialComponent/container/container';

const {height, fontScale} = Dimensions.get('screen');

const Orders = () => {
  const {headerOpacity, headerTranslate, onScroll} = useInnerHeaderAnimation();
  const {
    fetch_internal_order,
    fetch_internal_order_error,
    fetch_internal_order_loader,
    paginationLoader,
    pullLoader,
    paginationAPI,
    fetchAPI,
    id,
    setId,
    socialOrder,
    page,
    isFocused,
  } = useOrders({order: true});

  const renderItem = useMemo(
    () =>
      ({item, index}) =>
        (
          <View key={item.order_id}>
            {item.pendingReview ? (
              <PendingReviewCard
                marginTop={height * 0.01}
                paddingHorizontal={margin.horizontal}
                paddingVertical={height * 0.02}
              />
            ) : (
              <View
                style={[
                  ((item.order_item || []).length > 0 ||
                    item?.item_count > 0 ||
                    item?.type == 'tracking') &&
                    styles.contentContainer,
                ]}>
                <View style={styles.reviewsCard}>
                  <OrderHistoryCard
                    item={item}
                    removeBorder={true}
                    onPress={() => navigate('ReviewDetail')}
                    tabId={id}
                  />
                </View>
              </View>
            )}
          </View>
        ),
    [],
  );

  const getPaginatedDates = (orderCreatedDate, page = 1, perPage = 10) => {
    const count = page * perPage;
    return orderCreatedDate.slice(0, count).map(d => new Date(d).toISOString());
  };

  const sortedOrders = useMemo(() => {
    let socialOrders;
    if (id == 0) {
      socialOrders = socialOrder;
    } else if (id == 1) {
      socialOrders = socialOrder.filter(
        order => order.status === 'IN_PROGRESS',
      );
    } else if (id == 2) {
      socialOrders = socialOrder.filter(
        order => order.status === 'OUT_FOR_DELIVERY',
      );
    } else if (id == 3) {
      socialOrders = socialOrder.filter(order => order.status === 'IN_TRANSIT');
    } else if (id == 4) {
      socialOrders = socialOrder.filter(order => order.status === 'DELIVERED');
    }

    const internalOrders = fetch_internal_order?.[id]?.data || [];
    const orderCreatedDate = fetch_internal_order?.[id]?.orderCreatedDate || [];
    const socialOrdersList = socialOrders || [];
    const lastDates = getPaginatedDates(orderCreatedDate, page); // pass page dynamically



    // const filteredSocialOrders = socialOrdersList.filter(
    //   order =>
    //     order.order_date &&
    //     lastDates.includes(new Date(order.order_date).toISOString()),
    // );

    // helper
    const dayKey = iso => (iso ? iso.slice(0, 10) : '');

    const lastDateDaysArr = (lastDates || []).map(d => d.slice(0, 10)).sort(); // asc
    const minDay = lastDateDaysArr[0];
    const maxDay = lastDateDaysArr[lastDateDaysArr.length - 1];

    const filteredSocialOrders =
      page == fetch_internal_order?.[id]?.pagination?.totalPages
        ? socialOrdersList
        : socialOrdersList.filter(order => {
            if (!order?.order_date) return false;
            const d = dayKey(order.order_date);
            return d >= minDay && d <= maxDay; // ✅ only between first and last day
          });
    

    // Merge both orders
    const mergedOrders = [...internalOrders, ...filteredSocialOrders];

    const sorted = mergedOrders.sort((a, b) => {
      // Pin only applies to internal orders
      const aPin = a.pin_delivered_recent === 1;
      const bPin = b.pin_delivered_recent === 1;

      if (aPin && !bPin) return -1;
      if (!aPin && bPin) return 1;

      // Get order date depending on type
      const aDate = a.created_at || a.order_date; // internal has created_at, social has order_date
      const bDate = b.created_at || b.order_date;

      return new Date(bDate) - new Date(aDate); // descending
    });

    return sorted;
  }, [fetch_internal_order, id, socialOrder]);



  return showErrorScreen(fetch_internal_order_error) ? (
    <View style={globalStyle.show_error}>
      <EmptyScreen
        fullWidth={true}
        reload={fetchAPI}
        loader={pullLoader}
        message={fetch_internal_order_error}
      />
    </View>
  ) : (
    <Container
      isFocused={isFocused}
      barColor={'white'}
      dark
      style={styles.container}>
      {/* <View style={styles.container}> */}
      {/* <StatusBar
        animated
        barStyle="dark-content"
        backgroundColor="white"
        translucent={false}
      /> */}

      <Animated.View
        style={[
          styles.headerContainer,
          {
            // transform: [{translateY: headerTranslate}],
            // opacity: headerOpacity,
          },
        ]}>
        <InnerHeader
          onPressPlus={() => navigate('CreateTracking')}
          plus
          setting={true}
          title="Orders"
        />
      </Animated.View>

      <View style={styles.tabBarContainer}>
        <TabBar id={id} setId={setId} arr={tabBar} />
      </View>

      {/* Optional loading component if data is still fetching */}
      {fetch_internal_order_loader ? (
        <View style={{flexGrow: 1, backgroundColor: '#ededed'}}>
          <OrderLoader marginTop={height * 0.0} loading={true} />
        </View>
      ) : null}

      <FlatList
        // data={fetch_internal_order?.[id]?.data || []}
        data={sortedOrders}
        keyExtractor={(item, index) => `${id}_${index.toString()}`}
        renderItem={renderItem}
        scrollEventThrottle={16}
        onRefresh={() => fetchAPI()}
        onEndReached={paginationAPI}
        refreshing={pullLoader}
        // stickyHeaderIndices={[1]}
        ListEmptyComponent={
          !fetch_internal_order_loader && (
            <View
              style={{
                justifyContent: 'center',
                alignItems: 'center',
                marginTop: height * 0.25,
              }}>
              <EmptyScreen
                image={'empty_order'}
                heading={'No Orders Yet!'}
                desc={
                  'Looks like you haven’t placed any orders. Start shopping now and track your purchases here!'
                }
              />
            </View>
          )
        }
        ListFooterComponent={paginationLoader ? <PagionationLoader /> : null}
        contentContainerStyle={{
          paddingBottom: height * 0.15,
          paddingHorizontal: margin.horizontal,
          marginTop: height * 0.0,
          backgroundColor: '#ededed',
          flexGrow: 1,
        }}
        key={id}
      />
      {/* </View> */}
    </Container>
  );
};

export default Orders;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#ededed',
  },
  headerContainer: {
    width: '100%',
    zIndex: 2, // Ensure the header is above other content
    backgroundColor: 'white',
  },
  tabBarContainer: {
    zIndex: 3, // TabBar should have the highest zIndex to stay on top
    backgroundColor: 'white',
  },
  contentContainer: {
    marginTop: height * 0.01,
  },
  reviewsCard: {
    // paddingHorizontal: margin.horizontal,
    // marginTop: height * 0.04,
  },
  loader: {marginTop: 20, alignSelf: 'center'},
});

const tabBar = ['All', 'In Progress', 'Shipped', 'In Transit', 'Delivered'];

const data = [
  {
    pendingReview: true,
  },
  {
    shop: homeData[0],
    orderStatus: 'In Progress',
  },
  {
    shop: homeData[0],
    orderStatus: 'In Transit',
  },
  {
    shop: homeData[2],
    orderStatus: 'Shipped',
  },
  {
    shop: homeData[2],
    orderStatus: 'In Transit',
  },
  {
    shop: homeData[2],
    orderStatus: 'Delivered',
  },
];
