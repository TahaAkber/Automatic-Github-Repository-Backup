import {moderateScale} from 'react-native-size-matters';
import {
  Dimensions,
  FlatList,
  RefreshControl,
  StatusBar,
  StyleSheet,
  View,
} from 'react-native';
import React, {useEffect} from 'react';
import InnerHeader from '@component/header/innerHeader';
import {margin} from '@constant/contstant';
import Stories from '@component/cards/stories/stories';
import SearchInput from '@component/input/searchInput';
import BrandTab from '@component/brandTab/brandTab';
import {homeData} from '@constant/dummyData';
import ShopTileCategories from '@component/shopTIleCategories/shopTIleCategories';
import HomeDualCard from '@component/cards/homeDualCard';
import useFollowing from './useFollowing';
import GlobalLoader from '../../../component/loader/globalLoader';
import EmptyScreen from '../../../component/emptyScreen/emptyScreen';
import {globalStyle, shadow} from '../../../constant/contstant';
import FollowingLoader from '../../../component/loader/followingLoader';
import Container from '../../../materialComponent/container/container';
import PagionationLoader from '../../../component/loader/endReachLoader';
import FollowingSearchLoader from '../../../component/loader/followingSearchLoader';
import {isNotEmpty, showErrorScreen} from '../../../utils/helper/helper';

const {width, height, fontScale} = Dimensions.get('screen');

const Following = () => {
  const {
    dispatch,
    fetch_store_following_list_local,
    fetch_store_following_list,
    fetch_user_detail,
    fetch_store_following_list_loader,
    paginationAPI,
    paginationLoader,
    setSearch,
    search,
    handleSearch,
    searchLoader,
    localData,
    pullLoader,
    searchLoadingMore,
    fetchAPI,
    fetch_store_following_list_error,
  } = useFollowing({});

  useEffect(() => {
    if (search) {

    }
  }, [search, localData]);

  const renderProducts = ({item}) => (
    <View style={styles.similarProductCard}>
      <HomeDualCard
        headingSize={fontScale * 9}
        priceSize={fontScale * 10}
        discountPriceSize={fontScale * 8}
        width={width * 0.4}
        item={item}
        color="black"
        headingNumOfLines={1}
      />
    </View>
  );

  const renderShops = ({item}) => {

    return (
      <View
        style={{
          marginHorizontal: margin.horizontal,
          padding: height * 0.02,
          marginBottom: height * 0.02,
          backgroundColor: 'white',
          borderRadius: moderateScale(10),
          ...shadow,
          marginTop: height * 0.01,
        }}>
        <View style={{}}>
          <BrandTab
            item={item?.shop_detail}
            followColor={'white'}
            followStyle={{backgroundColor: 'black'}}
          />
        </View>
        {/* <ShopTileCategories item={item?.shop_detail?.filters || []} /> */}
        <View style={{marginTop: height * 0.015}}>
          <FlatList
            scrollEnabled={true}
            // data={item.products}
            data={Array.isArray(item.products) ? item.products.slice(0, 4) : []}
            renderItem={renderProducts}
            keyExtractor={(item, index) => index.toString()}
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.similarProductsList}
            numColumns={2}
          />
        </View>
      </View>
    );
  };


  return showErrorScreen(fetch_store_following_list_error) ? (
    <View style={globalStyle.show_error}>
      <EmptyScreen
        fullWidth={true}
        reload={fetchAPI}
        loader={pullLoader}
        message={fetch_store_following_list_error}
      />
    </View>
  ) : (
    <Container barColor={'white'}>
      <View style={styles.container}>
        <InnerHeader notification={true} setting={true} title={'Following'} />
        {fetch_store_following_list_loader ? (
          // <GlobalLoader />
          <FollowingLoader />
        ) : (
          <>
            {fetch_store_following_list?.data?.length == 0 ? (
              <View
                style={{
                  justifyContent: 'center',
                  alignItems: 'center',
                  flex: 1,
                  marginTop: height * -0.1,
                }}>
                <EmptyScreen
                  image={'empty_following'}
                  heading={"You're Not Following Any Stores Yet!"}
                  desc={
                    'Follow your favorite stores to stay updated on new arrivals, exclusive deals, and more!'
                  }
                />
              </View>
            ) : (
              <>
                <View style={[styles.horizontal, {marginTop: height * 0.02}]}>
                  <View style={{marginHorizontal: margin.horizontal}}>
                    <SearchInput
                      placeholder={'Search Your Following Store Here...'}
                      onChangeText={handleSearch}
                      value={search}
                    />
                  </View>

                  <View style={{marginTop: height * 0.015}}>
                    <Stories heading={'Following'} />
                  </View>
                </View>
                {searchLoader ? (
                  <View style={{marginTop: 8, height: height * 1}}>
                    <FollowingSearchLoader />
                  </View>
                ) : null}

                <View
                  style={{marginTop: height * 0.02, backgroundColor: 'white'}}>
                  <View>
                    <FlatList
                      scrollEnabled={true}
                      showsVerticalScrollIndicator={false}
                      data={
                        search
                          ? localData?.data || []
                          : fetch_store_following_list?.data || []
                      }
                      renderItem={renderShops}
                      keyExtractor={(item, index) => index.toString()}
                      showsHorizontalScrollIndicator={false}
                      contentContainerStyle={styles.shopsList}
                      onEndReached={
                        isNotEmpty(
                          search
                            ? localData?.data || []
                            : fetch_store_following_list?.data || [],
                        ) && paginationAPI
                      }
                      onEndReachedThreshold={0.5}
                      ListFooterComponent={
                        paginationLoader ? <PagionationLoader /> : null
                      }
                      refreshControl={
                        <RefreshControl
                          refreshing={pullLoader}
                          onRefresh={() => fetchAPI(false)}
                        />
                      }
                      ListEmptyComponent={
                        search &&
                        !searchLoader &&
                        localData?.data.length === 0 ? (
                          <View
                            style={{
                              paddingVertical: height * 0.15,
                              alignSelf: 'center',
                            }}>
                            <EmptyScreen
                              image="empty_following"
                              heading={`No stores matched "${search}"`}
                              desc="Try another keyword or check your spelling."
                            />
                          </View>
                        ) : null
                      }
                    />
                  </View>
                </View>
              </>
            )}
          </>
        )}
      </View>
    </Container>
  );
};

export default Following;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
  },
  horizontal: {
    // marginHorizontal: margin.horizontal,
    marginTop: height * 0.01,
  },
  contentContainer: {
    marginRight: moderateScale(10),
  },
  image: {
    width: moderateScale(80),
    height: moderateScale(80),
    borderRadius: moderateScale(10),
  },
  shopsList: {
    paddingBottom: height * 0.4,
  },
});

const shops = [
  {
    shop: homeData[0],
    products: homeData[0].products,
  },
  {
    shop: homeData[0],
    products: homeData[0].products,
  },
  {
    shop: homeData[0],
    products: homeData[0].products,
  },
];
