import {
  Dimensions,
  FlatList,
  Image,
  ImageBackground,
  RefreshControl,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import React from 'react';
import {moderateScale, scale, verticalScale} from 'react-native-size-matters';
import {useNavigation} from '@react-navigation/native';
import InnerHeader from '@component/header/innerHeader';
import {colors, font, globalStyle, shadow, WH} from '@constant/contstant';
import NotificationCard from '@component/cards/notification/notification';
import Container from '../../../materialComponent/container/container';
import useNotification from './useNotification';
import PagionationLoader from '../../../component/loader/endReachLoader';
import {heightPercentageToDP} from 'react-native-responsive-screen';
import {margin} from '../../../constant/contstant';
import NotificationLoader from '../../../component/loader/notificationLoader';
import EmptyScreen from '../../../component/emptyScreen/emptyScreen';
import {showErrorScreen} from '../../../utils/helper/helper';

const {fontScale, height} = Dimensions.get('screen');

const Notification = () => {
  const {
    fetch_user_notifications,
    fetch_user_detail,
    paginationLoader,
    paginationAPI,
    fetchAPI,
    isFocused,
    pullLoader,
    todayNotification,
    loader,
    fetch_user_notifications_error,
  } = useNotification();
  return showErrorScreen(fetch_user_notifications_error) ? (
    <View style={globalStyle.show_error}>
      <EmptyScreen
        fullWidth={true}
        reload={fetchAPI}
        loader={pullLoader}
        message={fetch_user_notifications_error}
      />
    </View>
  ) : (
    <Container isFocused={isFocused} dark={true} barColor={'white'}>
      <View style={styles.mainView}>
        <InnerHeader title={'Notifications'} />
        {todayNotification ? (
          <View
            style={{
              marginHorizontal: margin.horizontal,
              marginTop: height * -0.01,
              marginBottom: height * 0.01,
            }}>
            <Text
              style={{
                flexDirection: 'row',
                fontFamily: font.regular,
                fontSize: fontScale * 18,
                color: '#515978',
              }}>
              You have{' '}
              <Text
                style={{
                  fontFamily: font.bold,
                  fontSize: fontScale * 16,
                  color: colors.light_theme.theme,
                }}>
                {todayNotification?.data?.length} Notifications
              </Text>{' '}
              today.
            </Text>
          </View>
        ) : (
          <></>
        )}

        {loader ? (
          <NotificationLoader loading={true} />
        ) : (
          <View style={{flex: 1}}>
            <FlatList
              contentContainerStyle={styles.flatLists}
              showsVerticalScrollIndicator={false}
              onEndReached={paginationAPI}
              data={fetch_user_notifications?.data || []}
              // data={[]}
              keyExtractor={item => item.date}
              renderItem={({item, index}) => {
                return <NotificationCard index={index} item={item} />;
              }}
              refreshControl={
                <RefreshControl refreshing={pullLoader} onRefresh={fetchAPI} />
              }
              ListFooterComponent={
                paginationLoader ? (
                  <View
                    style={{
                      justifyContent: 'center',
                      alignItems: 'center',
                    }}>
                    <PagionationLoader />
                  </View>
                ) : null
              }
              ListEmptyComponent={
                <View
                  style={{
                    justifyContent: 'center',
                    alignItems: 'center',
                    marginTop: height * 0.25,
                  }}>
                  <EmptyScreen
                    image={'empty_notification'}
                    heading={'Notification Not Found'}
                    desc={`You haven't had any activity yet.`}
                    // imageSize={width * 0.16}
                    // headingSize={fontScale * 14}
                    // descSize={fontScale * 12}
                  />
                </View>
              }
            />
          </View>
        )}
      </View>
    </Container>
  );
};

export default Notification;

const styles = StyleSheet.create({
  mainView: {
    flex: 1,
    backgroundColor: 'white',
  },
  flatLists: {
    // paddingHorizontal: scale(15),
    paddingVertical: verticalScale(10),
    paddingBottom: heightPercentageToDP(20),
  },
});
