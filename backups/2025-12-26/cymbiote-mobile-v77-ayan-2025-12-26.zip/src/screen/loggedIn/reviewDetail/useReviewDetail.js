import { Animated, Dimensions } from 'react-native';
import useReduxStore from '@utils/hooks/useReduxStore';
import { useEffect, useRef, useState } from 'react';
import { _getPoints } from '@redux/actions/reward/reward';
import {
    _getPointsHistory,
    _getVouchers,
} from '../../../redux/actions/reward/reward';
import { _getReviewDetail, _sendComment } from '../../../redux/actions/reviews/reviews';

const { height, fontScale } = Dimensions.get('screen');


const useReviewDetail = ({ route }) => {
    const { item = {} } = route?.params
    const { dispatch, getState } = useReduxStore();
    const { fetch_user_detail } = getState("auth")
    const [reviewDetail, setReviewDetail] = useState([]);
    const [images, setImages] = useState([]);
    const [loader, setLoader] = useState(true);
    const [commentLoader, setCommentLoader] = useState(false);
    const [text, setText] = useState("");
    const [replyComment, setReplyComment] = useState({});
    const refRBSheet = useRef(null);
    const scrollRef = useRef(null);


    const [like, setLike] = useState(false)
    const scaleAnim = useState(new Animated.Value(1))[0];

    const handleLike = () => {
        setLike(prev => !prev);

        // Animate scaling effect
        Animated.sequence([
            Animated.spring(scaleAnim, { toValue: 1.3, useNativeDriver: true }),  // Enlarge
            Animated.spring(scaleAnim, { toValue: 1, useNativeDriver: true }),    // Return to normal
        ]).start();
    };

    const likeIconStyle = {
        transform: [{ scale: scaleAnim }],
    };


    const fetchAPI = async pull => {
        !pull && setLoader(true);
        const response = await dispatch(_getReviewDetail(item?.review_item?.order_item_review_id || item?.order_item_review_id));
        setReviewDetail(response?.data);
        setLoader(false);
    };

    const handleReplyPress = (item) => {
        setReplyComment(item);

        setTimeout(() => {
            scrollRef.current?.scrollToEnd({ animated: true });
        }, 300); // wait for layout to update (optional)
    };

    const handleDeleteImage = (indexToRemove) => {
        const filteredImages = images.filter((_, index) => index !== indexToRemove);
        setImages(filteredImages); // assuming you're using useState for `images`
    };

    const sendComment = async () => {
        setCommentLoader(true)
        const res = await dispatch(_sendComment(reviewDetail?.review_detail?.order_item_review_id, "user", fetch_user_detail?.id, text, images, replyComment?.commentId))
        if (res) {
            setText("")
            setImages([])
            setReplyComment({})
            fetchAPI(true)
            setCommentLoader(false)
        }
        setCommentLoader(false)
    }

    useEffect(() => {
        fetchAPI(false);
    }, []);

    return {
        reviewDetail,
        loader,
        text,
        refRBSheet,
        images,
        setImages,
        handleDeleteImage,
        setReplyComment,
        replyComment,
        setText,
        like,
        handleLike,
        handleReplyPress,
        scrollRef,
        likeIconStyle,
        sendComment,
        commentLoader
    };
};

export default useReviewDetail;
