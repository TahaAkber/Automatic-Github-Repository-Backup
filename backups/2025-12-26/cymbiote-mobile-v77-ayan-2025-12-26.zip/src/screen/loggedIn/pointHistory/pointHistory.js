


import { Dimensions, StatusBar, StyleSheet, View, Animated, FlatList, RefreshControl } from 'react-native';
import React, { useEffect, useMemo } from 'react';
import InnerHeader from '@component/header/innerHeader';
import { margin } from '@constant/contstant';
import TabBar from '@component/tabBar/tabBar';
import useInnerHeaderAnimation from '../../../hooks/innerHeaderAnimation';
import Content from '@materialComponent/content/content';
import PointCard from '@component/cards/pointCard/pointCard';
import { colors } from '@constant/contstant';
import usePointHistory from './usePointHistory';
import OrderLoader from '../../../component/loader/orderLoader';
import PagionationLoader from '../../../component/loader/endReachLoader';
import { handleScroll } from '../../../utils/helper/helper';
import EmptyScreen from '../../../component/emptyScreen/emptyScreen';
import CustomText from '../../../materialComponent/customText/customText';
import { font } from '../../../constant/contstant';
import Container from '../../../materialComponent/container/container';

const { height, fontScale, width } = Dimensions.get("screen");

const PointHistory = () => {
    const { headerOpacity, headerTranslate } = useInnerHeaderAnimation();
    const {
        user_point_history,
        user_point_history_loader,
        paginationAPI,
        paginationLoader,
        pullLoader,
        fetchAPI,
        id,
        setId,
        currentTabData
    } = usePointHistory({ points: true });

    // Group points by month
 
   
    // Get status color for point cards
    const getStatusColor = (status) => {
        if (!status) return "black";
        switch (status.toLowerCase()) {
            case "completed": return "#00CE83";
            case "redeemed": return "#800000"; // Maroon
            case "cancelled": return "#1A97CD";
            case "pending": return "#FF9624";
            default: return "black"; // Default color
        }
    };

    // Render each point card
    const renderPointCard = ({ item }) => {
        return (
            <PointCard
                heading={item.points_log_description}
                date={item.created_at ? `Date: ${new Date(item.created_at).toLocaleDateString()}` : "Date: N/A"}
                point={item.points_log_transaction_count}
                image={item?.shop?.shop_logo_url}
                pointColor={getStatusColor(item.points_status?.trim())}
                style={{ marginHorizontal: 0 }}
            />
        );
    };

    // Render each month's data
    const renderMonthData = ({ item }) => (
        <View style={{ marginTop: height * 0.02 }}>
            <View style={styles.dataView}>
                <CustomText fontSize={fontScale * 14} fontFamily={font.bold} text={item.month} />
            </View>
            <View style={{ marginHorizontal: margin.horizontal }}>
                <FlatList
                    data={Array.isArray(item.data) ? item.data : []}
                    keyExtractor={(item, index) => `point-${index}`}
                    renderItem={renderPointCard}
                />
            </View>
        </View>
    );

    return (
        <Container barColor={"white"}>
        <View style={styles.container}>
            {/* <StatusBar animated barStyle="dark-content" backgroundColor="white" translucent={false} /> */}

            {/* Scrollable content */}
            <Content
                contentContainerStyle={{ paddingBottom: height * 0.15 }}
                onScroll={e => handleScroll(e, paginationAPI)}
                scrollEventThrottle={16}
                stickyHeaderIndices={[1]}
                refreshControl={
                    <RefreshControl
                        refreshing={pullLoader} // Show loader while refreshing
                        onRefresh={fetchAPI} // Trigger refresh
                        colors={[colors.light_theme.theme]} // Customize loader color
                    />
                }
            >
                {/* Animated header */}
                <Animated.View
                    style={[styles.headerContainer, {
                        transform: [{ translateY: headerTranslate }],
                        opacity: headerOpacity,
                    }]}
                >
                    <InnerHeader notification={true} setting={true} title="Cash Back Activity" />
                </Animated.View>

                {/* Tab bar */}
                <View style={styles.tabBarContainer}>
                    <TabBar id={id} setId={setId} arr={tabBar} />
                </View>
               

                {user_point_history_loader ? <OrderLoader loading={true} /> : (
                    <>
                        {(user_point_history || [])?.length > 0 ? (
                            <FlatList
                                data={user_point_history}
                                keyExtractor={(month, index) => `month-${index + 1}`}
                                renderItem={renderMonthData}
                                contentContainerStyle={styles.flatListContent}
                                scrollEnabled={false}
                                // onEndReached={paginationAPI}

                                // onEndReachedThreshold={0.5}
                                ListFooterComponent={paginationLoader ? <PagionationLoader /> : null}
                            />
                        ) : (
                            <View style={{ justifyContent: "center", alignItems: "center", marginTop: height * 0.25 }}>
                                <EmptyScreen
                                    image={"empty_points"}
                                    heading={"No Cashback Rewards Yet!"}
                                    desc={"Start shopping and earn cashback on your purchases. Your rewards will appear here!"}
                                />
                            </View>

                        )}
                    </>
                )}



            </Content>
        </View>
        </Container>
    );
};

export default PointHistory;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: "white",
    },
    headerContainer: {
        width: '100%',
        zIndex: 2, // Ensure the header is above other content
    },
    tabBarContainer: {
        zIndex: 3, // TabBar should have the highest zIndex to stay on top
        backgroundColor: "white",
        flexDirection: "row",
        justifyContent: "center",
    },
    dataView: {
        width: width * 1,
        alignSelf: "center",
        backgroundColor: "#e6e6e6",
        paddingHorizontal: height * 0.025,
        paddingVertical: height * 0.007,
    },
});

const tabBar = ["All", "Pending", "Redeemed", "Completed", "Cancelled"];