
import { useState, useCallback } from "react";
import useReduxStore from "../../../utils/hooks/useReduxStore";
import { pagination } from "../../../utils/helper/helper";
import { useFocusEffect } from "@react-navigation/native";
import { _getPointsHistory } from "../../../redux/actions/reward/reward";

const usePointHistory = ({ points = false }) => {
    const { dispatch, getState } = useReduxStore();
    const { user_point_history, user_point_history_loader, user_point_history_error } = getState("reward");

    const [id, setId] = useState(0); // Default tab (0 = All)
    const [page, setPage] = useState(1);
    const [pullLoader, setPullLoader] = useState(false);
    const [paginationLoader, setPaginationLoader] = useState(false);

    /** ✅ Retrieve current tab's data */
    const currentTabData = user_point_history?.[id]?.logs || [];

    const fetchAPI = async (isLoading) => {
        if (points) {
            if (!isLoading) setPullLoader(true);
            await dispatch(_getPointsHistory({ page: 1, tab: id, pull: !isLoading }));
            setPullLoader(false);
        }
    };


    const paginationAPI = async () => {
        if (!paginationLoader) {
            try {
                const totalPages = user_point_history?.[id]?.pagination?.totalPages || 1
                const nextPagination = pagination(page, totalPages, setPage);

                if (nextPagination) {
                    setPaginationLoader(true);
                    const response = await dispatch(_getPointsHistory({ page: nextPagination, tab: id }));
                    setPaginationLoader(false);
                  

                }
            } catch (error) {
             
                setPaginationLoader(false);
            }
        }
    };

    useFocusEffect(
        useCallback(() => {
            fetchAPI(true);
        }, [id]) 
    );

    return {
        user_point_history: currentTabData,
        user_point_history_loader,
        user_point_history_error,
        pullLoader,
        paginationAPI,
        paginationLoader,
        fetchAPI,
        id,
        setId,


    };
};

export default usePointHistory;