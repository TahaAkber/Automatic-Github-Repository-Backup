import { useCallback, useEffect, useRef, useState } from 'react';
import HomeDualCard from '@component/cards/homeDualCard';
import useReduxStore from '@utils/hooks/useReduxStore';
import { WH } from '@constant/contstant';
import { Keyboard, View } from 'react-native';
import {
  // _fetchSearchedList,
  _recentSearchRecord,
  _searchMethod,
} from '@redux/actions/common/common';
import { _fetchSearchedList, _fetchSearchedListWithImage } from '../../../redux/actions/common/common';
import { useNavigation } from '@react-navigation/native';
import BrandCard from '../../../component/cards/brandCard/brandCard';
import { shadow } from '../../../constant/contstant';
import {
  logSearchItemClickEvent,
  logSearchSkippedItemsEvent,
  logSearchFilterChangeEvent,
} from '@helper/eventTriggers/useEventTriggers';

const useSearchedItems = ({ route }) => {
  const { dispatch, getState } = useReduxStore();
  const [value, setValue] = useState('');
  const [page, setPage] = useState(1);
  const [searchLoader, setSearchLoader] = useState(false);
  const [isKeyboardVisible, setIsKeyboardVisible] = useState(false);
  const [loader, setLoader] = useState(false);
  const [pullLoader, setPullLoader] = useState(false);
  const [paginationLoader, setPaginationLoader] = useState(false);
  const [isCameraOpen, setIsCameraOpen] = useState(false);
  const [brand, setBrand] = useState('');
  const [localData, setLocalData] = useState({});
  const [products, setProducts] = useState([]);
  const controllerRef = useRef(null);
  const clickedItemsRef = useRef([]);

  const debounceRef = useRef(null);
  const navigation = useNavigation();
  const searchQuery = route?.params?.searchTerm || '';
  const previousBrandRef = useRef('');

  useEffect(() => {
    const keyboardDidShowListener = Keyboard.addListener(
      'keyboardDidShow',
      () => {
        setIsKeyboardVisible(true); // Show "Cancel" button.
      },
    );

    const keyboardDidHideListener = Keyboard.addListener(
      'keyboardDidHide',
      () => {
        setIsKeyboardVisible(false); // Hide "Cancel" button.
      },
    );

    return () => {
      keyboardDidShowListener.remove();
      keyboardDidHideListener.remove();
    };
  }, [isKeyboardVisible]);

  const handleSearch = async text => {
    _searchMethod(
      text,
      setValue,
      setSearchLoader,
      setLocalData,
      debounceRef,
      '',
      controllerRef,
      '',
      true,
      '/rag_search?query=',
    );
  };

  const _handleBlur = async image => {
    if (value || image) {
      await dispatch(
        _recentSearchRecord({ searchTerm: value, image, navigation }),
      );
      setIsCameraOpen(false);
      setIsKeyboardVisible(false);
      setValue('');
    }
  };

  const handleProductClick = async (item, index) => {
    const itemId = item.product_id;

    // Track click
    if (!clickedItemsRef.current.includes(itemId)) {
      clickedItemsRef.current.push(itemId);

    }

    // Log click event to Firebase
    if (searchQuery) {
      await logSearchItemClickEvent(item, searchQuery, index, 'product');
    }
  };

  const renderProduct = useCallback(({ item, index }) => {
    return (
      <View style={{ marginRight: WH.width('2') }}>
        <HomeDualCard
          item={item}
          width={WH.width('43')}
          color={'black'}
          isFromSearch={!!searchQuery}
          searchQuery={searchQuery}
          onPress={() => handleProductClick(item, index)}
        />
      </View>
    );
  }, [searchQuery]);

  const handleShopClick = async (item, index) => {
    ('🏪 [SearchedItems Analytics] Shop clicked:', {
      shop_id: item.shop_id,
      shop_name: item.shop_name,
      position: index,
      searchQuery,
      isFromSearch: true,
    });

    // Log shop click event to Firebase
    if (searchQuery) {
      await logSearchItemClickEvent(item, searchQuery, index, 'shop');
    }
  };

  const renderBrandCard = useCallback(({ item, index }) => (
    <View style={{ borderRadius: 10, overflow: 'hidden', }}>
      <BrandCard
        item={item}
        onPress={() => handleShopClick(item, index)}
      />
    </View>
  ), [searchQuery]);

  const fetchAPI = async (child_brand, pull) => {
    try {
      setPage(1);
      let response;
      !pull && setLoader(true);
      pull && setPullLoader(true);
      if (route?.params?.image?.uri) {
        response = await dispatch(
          _fetchSearchedListWithImage(
            route?.params?.image,
            1,
            child_brand || brand,
          ),
        );
        setPullLoader(false);
      } else {
        response = await dispatch(
          _fetchSearchedList(
            route?.params?.searchTerm,
            true,
            1,
            true,
            child_brand || brand,
            "",
            false,
            true
          ),
        );
        setPullLoader(false);
      }
      setProducts(response);
      setLoader(false);

      // Log search results loaded
    } catch (error) {
      setPullLoader(false);
      setLoader(false);
      console.error('❌ [SearchedItems Analytics] Error loading search results:', error);
    }
  };


  const paginationAPI = async () => {
    if (!paginationLoader) {
      const totalPages = products?.total_pages || products?.data?.total_pages;
      const nextPagination = products?.next_page || products?.data?.next_page;
      let response;
      if (nextPagination) {
        setPage(nextPagination);
        setPaginationLoader(true);
        if (route?.params?.image?.uri) {
          response = await dispatch(
            _fetchSearchedListWithImage(
              route?.params?.image,
              nextPagination || totalPages,
            ),
          );
        } else {
          response = await dispatch(
            _fetchSearchedList(
              route?.params?.searchTerm,
              true,
              nextPagination || totalPages,
            ),
          );
        }

        if (route?.params?.image?.uri) {
          const data = {
            ...products,
            data: {
              products: [
                ...(products?.data?.products || []),
                ...(response?.data?.products || []),
              ],
              total_pages: response?.data?.total_pages,
              next_page: response?.data?.next_page || '',
            },
          };
          setProducts(data);
          setPaginationLoader(false);
        } else {
          if (response) {
            const data = {
              ...products,
              data: {
                ...products.data,
                products: [
                  ...(products?.data?.products || []),
                  ...(response?.data?.products || []),
                ],
              },
              total_pages: response?.totalPages,
              next_page: response?.next_page,
            };
            setProducts(data);
            setPaginationLoader(false);
          } else {
            setPaginationLoader(false);
          }
        }
      }
    }
  };

  useEffect(() => {
    fetchAPI();
  }, []);

  // Track brand filter changes
  useEffect(() => {
    if (brand && previousBrandRef.current !== brand && searchQuery) {

      logSearchFilterChangeEvent(
        searchQuery,
        'brand',
        brand,
        previousBrandRef.current,
      );

      previousBrandRef.current = brand;
    }
  }, [brand, searchQuery]);

  // Track skipped items when component unmounts
  useEffect(() => {
    return () => {
      const displayedProducts = products?.data?.products || [];
      if (searchQuery && displayedProducts.length > 0) {
        const displayedItems = displayedProducts.map(p => ({
          ...p,
          type: 'product',
        }));

        const skippedItems = displayedItems.filter(item => {
          const itemId = item.product_id;
          return !clickedItemsRef.current.includes(itemId);
        });

        logSearchSkippedItemsEvent(
          displayedItems,
          clickedItemsRef.current,
          searchQuery,
        );
      }
      // Reset clicked items
      clickedItemsRef.current = [];
    };
  }, [products, searchQuery]);

  const searchedTerm = route?.params?.searchTerm;
  const searchedImage = route?.params?.image;

  return {
    renderProduct,
    value,
    handleSearch,
    localData,
    searchLoader,
    isKeyboardVisible,
    _handleBlur,
    products,
    loader,
    searchedTerm,
    fetchAPI,
    paginationAPI,
    paginationLoader,
    searchedImage,
    isCameraOpen,
    setIsCameraOpen,
    brand,
    setBrand,
    pullLoader,
    setPullLoader,
    renderBrandCard
  };
};

export default useSearchedItems;
