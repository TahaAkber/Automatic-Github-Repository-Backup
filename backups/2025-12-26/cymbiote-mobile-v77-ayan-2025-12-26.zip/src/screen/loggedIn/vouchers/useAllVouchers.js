import { useState, useCallback } from "react";
import useReduxStore from "@utils/hooks/useReduxStore";
// import { _getAllVouchers } from "@redux/actions/reward/allVouchers";
import { useFocusEffect } from "@react-navigation/native";
import { _getAllVouchers } from "../../../redux/actions/reward/reward";
import { pagination } from "../../../utils/helper/helper";
import AllReviews from "../allReviews/allReviews";

const useAllVouchers = () => {
    const { dispatch, getState } = useReduxStore();
    const { all_vouchers, all_vouchers_loader, all_vouchers_error } = getState("vouchers");
    const [page, setPage] = useState(1);
    const [paginationLoader, setPaginationLoader] = useState(false);
    const [pullLoader, setPullLoader] = useState(false);


    const currentLogs = all_vouchers?.logs || [];
    /** ✅ Fetch All Vouchers (First Page) */
    // const fetchAPI = async () => {
    //     setPage(1);
    //     await dispatch(_getAllVouchers({ page: 1, pageSize: 4 })); // ✅ Load first 10 vouchers
    // };

    const fetchAPI=async(isLoading)=>{
        if (!isLoading) setPullLoader(true);
        await dispatch(_getAllVouchers({ page: 1, pull: !isLoading }));
        setPullLoader(false);

    }

    /** ✅ Fetch Next Page on Scroll */
    const paginationAPI = async () => {
        if(!paginationLoader){
            try {
                const totalPages =all_vouchers?.pagination?.totalPages || 1;
                const  nextPagination =pagination(page, totalPages,setPage)
                if(nextPagination){
                    setPaginationLoader(true);
                    const response =await dispatch(_getAllVouchers({page:nextPagination,}))
                }
            } catch (error) {
                console.error("Error fetching pagination data of vouchers: ", error);

            }
            finally {
                setPaginationLoader(false); // Ensure loader stops in case of error or success
            }
        }
     
        
      };

    useFocusEffect(
        useCallback(() => {
            fetchAPI(true); // ✅ Reload when navigating to Vouchers Screen
        }, [])
    );

    return {
        all_vouchers,
        all_vouchers_loader,
        all_vouchers_error,
        paginationAPI,
        paginationLoader,
        fetchAPI,
        pullLoader,
        
        
    };
};

export default useAllVouchers;
