import {
  Dimensions,
  StatusBar,
  StyleSheet,
  View,
  Animated,
  ScrollView,
  TouchableOpacity,
  FlatList,
  RefreshControl,
} from 'react-native';
import React, {memo, useMemo, useState} from 'react';
import InnerHeader from '@component/header/innerHeader';
import {margin} from '@constant/contstant';
import TabBar from '@component/tabBar/tabBar';
import useInnerHeaderAnimation from '../../../hooks/innerHeaderAnimation';
import Content from '@materialComponent/content/content';
import SemiCircleChart from '@materialComponent/semiCircleChart/semiCircleChart';
import VoucherCard from '@component/cards/voucherCard/voucherCard';
import CustomText from '@materialComponent/customText/customText';
import {font} from '@constant/contstant';
import PointCard from '@component/cards/pointCard/pointCard';
import {colors, globalStyle} from '@constant/contstant';
import CustomSlider from '@component/redeemSlider/redeemSlider';
import CustomButton from '@materialComponent/customButton/customButton';
import {scale} from 'react-native-size-matters';
import {isEven} from '@helper/reUsableMethod/reUsableMethod';
import {navigate} from '@utils/navigationRef/navigationRef';
import useRewards from './useRewards';
import RewardLoader from '@component/loader/rewardLoader';
import EmptyScreen from '../../../component/emptyScreen/emptyScreen';
import OrderLoader from '../../../component/loader/orderLoader';
import Container from '../../../materialComponent/container/container';
import {formatDateTime, formatExpiryDisplay, showErrorScreen} from '../../../utils/helper/helper';

const {height, fontScale, width} = Dimensions.get('screen');

const Rewards = () => {
  const {headerOpacity, headerTranslate, onScroll} = useInnerHeaderAnimation();

  const {
    user_point,
    user_point_loader,
    user_point_error,
    id,
    setId,
    user_point_history = [],
    user_vouchers = [],
    user_vouchers_loader,
    user_vouchers_error,
    loader,
    fetchAPI,
    pullLoader,
  } = useRewards({});

  const MemoizedVoucherItem = memo(({item}) => (
    <VoucherCard
      heading={'Your Voucher has been created'}
      subTitle={`${item.voucher_code}`}
      expiryDate={formatExpiryDisplay(item.voucher_expiration_date , true)}
      image={item.store_logo}
      point={item.voucher_value}
      buttonColor="black"
      buttonText="Apply Now"
      style={{marginHorizontal: 0}}
    />
  ));

  const MemoizedPointItem = memo(({item}) => (
    <PointCard
      heading={item.points_log_description}
      date={`Date: ${new Date(item.created_at).toLocaleDateString()}`}
      point={item.points_log_transaction_count}
      image={item?.shop?.shop_logo_url}
      pointColor={getStatusColor(item.points_status?.trim())}
      style={{marginHorizontal: 0}}
    />
  ));
  const pointsHistory = (user_point_history[0]?.logs || []).slice(0, 10);

  const getStatusColor = status => {
    if (!status) return 'black';
    switch (status.toLowerCase()) {
      case 'completed':
        return '#00CE83';
      case 'processing':
        return '#800000'; // Maroon
      case 'cancelled':
        return '#1A97CD';
      case 'pending   ':
        return '#FF9624';
      default:
        return 'black'; // Default color
    }
  };
  const cashbackActivityExists = (pointsHistory || []).length > 0;

  return showErrorScreen(user_vouchers_error) ? (
    <View style={globalStyle.show_error}>
      <EmptyScreen
        fullWidth={true}
        reload={fetchAPI}
        loader={user_point_loader}
        message={user_vouchers_error}
      />
    </View>
  ) : (
    <Container barColor={'white'}>
      <View style={styles.container}>
        <Content
          contentContainerStyle={{paddingBottom: height * 0.15}}
          onScroll={onScroll}
          scrollEventThrottle={16}
          refreshControl={
            <RefreshControl refreshing={pullLoader} onRefresh={fetchAPI} />
          }
          // stickyHeaderIndices={[1]}
        >
          <Animated.View
            style={[
              styles.headerContainer,
              {
                transform: [{translateY: headerTranslate}],
                opacity: headerOpacity,
              },
            ]}>
            <InnerHeader notification={true} setting={true} title="Rewards" />
          </Animated.View>
          {user_point_loader ? (
            <View style={styles.loaderView}>
              <OrderLoader removeHorizontalMargin={true} loading={true} />
            </View>
          ) : (
            <>
              {/* <View style={styles.tabBarContainer}>
                            <TabBar id={id} setId={setId} arr={tabBar} />
                        </View> */}

              {/* Content */}
              <View style={styles.mainView}>
                <SemiCircleChart userPoint={user_point_history[0]} />

                <CustomButton
                  onPress={() => navigate('Redeem')}
                  buttonStyle={{borderRadius: 5}}
                  fontSize={fontScale * 15}
                  height={height * 0.05}
                  marginTop={height * 0.02}
                  text={'Redeem'}
                />

                {/* <View style={[globalStyle.space_between, { marginTop: height * 0.02 }]}>
                                <CustomText fontSize={fontScale * 20} fontFamily={font.bold} text={"Cash Back Activity"} />
                            </View> */}
                {/* 
                            <View style={{ justifyContent: "center", alignItems: "center", flex: 1, marginTop: height * 0.05 }}>
                                <EmptyScreen
                                    image={"empty_points"}
                                    heading={"No Cashback Rewards Yet!"}
                                    desc={"Start shopping and earn cashback on your purchases. Your rewards will appear here!"}
                                />
                            </View> */}

                {loader ? (
                  <OrderLoader loading={true} removeHorizontalMargin={true} />
                ) : (
                  <View style={styles.vouchersView}>
                    {(user_vouchers || [])?.length > 0 ? (
                      <>
                        <View style={globalStyle.space_between}>
                          <CustomText
                            fontSize={fontScale * 18}
                            fontFamily={font.bold}
                            text={'Vouchers'}
                          />

                          <TouchableOpacity
                            onPress={() => navigate('Vouchers')}>
                            <CustomText
                              color={colors.light_theme.theme}
                              fontSize={fontScale * 14}
                              fontFamily={font.medium}
                              text={'View All'}
                            />
                          </TouchableOpacity>
                        </View>
                        <FlatList
                          data={user_vouchers?.slice(0, 3)}
                          keyExtractor={(item, index) => `voucher-${index}`}
                          renderItem={({item}) => (
                            <MemoizedVoucherItem item={item} />
                          )}
                          showsHorizontalScrollIndicator={false}
                          style={{marginTop: height * 0.01}}
                        />
                      </>
                    ) : cashbackActivityExists ? null : (
                      <View
                        style={{
                          justifyContent: 'center',
                          alignItems: 'center',
                          marginTop: height * 0.03,
                        }}>
                        <EmptyScreen
                          image={'empty_voucher'}
                          heading={'No voucher yet'}
                          desc={'No vouchers are available at the moment.'}
                          imageSize={width * 0.16}
                          headingSize={fontScale * 14}
                          descSize={fontScale * 12}
                        />
                      </View>
                    )}
                  </View>
                )}
              </View>

              {loader ? (
                <OrderLoader loading={true} removeHorizontalMargin={true} />
              ) : (pointsHistory || []).length > 0 ? (
                <>
                  <View style={styles.pointsView}>
                    <View style={globalStyle.space_between}>
                      <CustomText
                        fontSize={fontScale * 18}
                        fontFamily={font.bold}
                        text={'Cash Back Activity'}
                      />
                      <TouchableOpacity
                        onPress={() => navigate('PointHistory')}>
                        <CustomText
                          color={colors.light_theme.theme}
                          fontSize={fontScale * 14}
                          fontFamily={font.medium}
                          text={'View All'}
                        />
                      </TouchableOpacity>
                    </View>
                  </View>
                  {/* // ) : ([]).length > 0 ? ( */}
                  <FlatList
                    data={pointsHistory}
                    keyExtractor={(month, index) => `month-${index}`}
                    renderItem={({item}) => (
                      <View style={{marginTop: height * 0.02}}>
                        <View style={styles.dataView}>
                          <CustomText
                            fontSize={fontScale * 14}
                            fontFamily={font.bold}
                            text={item.month}
                          />
                        </View>
                        <FlatList
                          data={Array.isArray(item.data) ? item.data : []}
                          keyExtractor={(item, index) => `point-${index}`}
                          renderItem={({item}) => (
                            <MemoizedPointItem item={item} />
                          )}
                        />
                      </View>
                    )}
                    contentContainerStyle={{
                      paddingHorizontal: margin.horizontal,
                      marginTop: height * 0.01,
                    }}
                  />
                </>
              ) : (
                <View
                  style={{
                    justifyContent: 'center',
                    alignItems: 'center',
                    marginTop: height * 0.04,
                  }}>
                  {/* <EmptyScreen
                                        image={"empty_points"}
                                        heading={"No Cashback Rewards Yet!"}
                                        desc={"Start shopping and earn cashback on your purchases. Your rewards will appear here!"}
                                        imageSize={width * 0.26}
                                        headingSize={fontScale * 16}
                                        descSize={fontScale * 12}
                                    /> */}
                </View>
              )}
            </>
          )}
        </Content>
      </View>
    </Container>
  );
};

export default Rewards;

const styles = StyleSheet.create({
  loaderView: {
    // marginHorizontal: margin.horizontal,
  },
  mainView: {
    marginHorizontal: margin.horizontal,
    marginTop: height * 0.05,
  },
  container: {
    flex: 1,
    backgroundColor: 'white',
  },
  headerContainer: {
    width: '100%',
    zIndex: 2, // Ensure the header is above other content
  },
  tabBarContainer: {
    zIndex: 3, // TabBar should have the highest zIndex to stay on top
    backgroundColor: 'white',
  },
  contentContainer: {
    marginTop: height * 0.04,
  },
  reviewsCard: {
    marginHorizontal: margin.horizontal,
    marginTop: height * 0.04,
  },
  vouchersView: {
    marginTop: height * 0.03,
  },
  pointsView: {
    marginTop: height * 0.04,
    marginHorizontal: margin.horizontal,
  },
  buttonContainer: {
    width: '20%',
    // height :
    // height: height * 0.0
  },
  customSliderView: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: height * 0.01,
    marginTop: height * 0.04,
  },
  dataView: {
    width: width * 1,
    alignSelf: 'center',
    backgroundColor: '#e6e6e6',
    paddingHorizontal: height * 0.025,
    paddingVertical: height * 0.007,

    // marginHorizontal: margin.horizontal,
  },
});

const tabBar = ['Wallet', 'Milestones'];
