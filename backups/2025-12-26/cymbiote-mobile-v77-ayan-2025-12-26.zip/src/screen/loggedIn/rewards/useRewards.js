import { Dimensions } from 'react-native';
import useReduxStore from '@utils/hooks/useReduxStore';
import { useEffect, useState } from 'react';
import { _getPoints } from '@redux/actions/reward/reward';
import { _getPointsHistory, _getVouchers } from '../../../redux/actions/reward/reward';

const { height, fontScale } = Dimensions.get("screen");

const useRewards = () => {

    const { dispatch, getState } = useReduxStore()
    const {
        user_point,
        user_point_loader,
        user_point_error,
        user_point_history = [],
        user_vouchers = [],
        user_vouchers_error,
        user_vouchers_loader,
    } = getState("reward")

    const [id, setId] = useState(0)
    const [loader, setLoader] = useState(true)
    const [pullLoader, setPullLoader] = useState(false)

    const fetchAPI = async (pull) => {
        pull && setLoader(true)
        !pull && setPullLoader(true)
        await dispatch(_getPointsHistory({ page: 1, tab: 0 }))
        await dispatch(_getVouchers({ page: 1 }));
        setLoader(false)
        setPullLoader(false)
    }
    useEffect(() => {
        const controller = new AbortController();
        const signal = controller.signal;
        fetchAPI(true)
        return () => {
            controller.abort();
     
        };
    }, [])
    return {
        user_point,
        user_point_loader,
        user_point_error,
        id,
        setId,
        user_point_history,
        user_vouchers,
        user_vouchers_loader,
        user_vouchers_error,
        loader,
        fetchAPI,
        pullLoader
    }
};

export default useRewards;