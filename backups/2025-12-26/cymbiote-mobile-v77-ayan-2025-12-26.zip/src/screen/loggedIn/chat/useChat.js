import {useEffect, useState, useCallback} from 'react';
import firestore from '@react-native-firebase/firestore';
import useReduxStore from '../../../utils/hooks/useReduxStore';

export const useChat = (
  orderId,
  vendorId,
  customerId,
  currentUserId,
  image,
  shopName,
  orderTitle,
) => {
  const {getState} = useReduxStore();
  const {fetch_user_detail} = getState('auth');

  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(true);

  const chatRoomId = `${orderId}_${vendorId}_${customerId}`;

  const name = fetch_user_detail?.firstname
    ? fetch_user_detail?.firstname + ' ' + fetch_user_detail?.lastname
    : 'Guest';

  useEffect(() => {
    const unsub = firestore()
      .collection('chats')
      .doc(chatRoomId)
      .collection('messages')
      .orderBy('timestamp', 'desc')
      .onSnapshot(snap => {
        const list = snap.docs.map(doc => ({
          id: doc.id,
          ...doc.data(),
        }));
        setMessages(list);
        setLoading(false);
      });

    return () => unsub();
  }, [chatRoomId]);

  const sendMessage = useCallback(
    async text => {
      if (!text.trim()) return;

      await firestore()
        .collection('chats')
        .doc(chatRoomId)
        .collection('messages')
        .add({
          text,
          sender_id: currentUserId,
          seen: false,
          timestamp: firestore.FieldValue.serverTimestamp(),
        });

      let updateData = {};

      if (currentUserId === customerId) {
        updateData = {
          unseen_for_vendor: firestore.FieldValue.increment(1),
        };
      } else {
        updateData = {
          unseen_for_customer: firestore.FieldValue.increment(1),
        };
      }

      await firestore()
        .collection('chats')
        .doc(chatRoomId)
        .set(
          {
            last_message: text,
            last_message_time: firestore.FieldValue.serverTimestamp(),
            last_message_sender_id: customerId,
            customer_id: customerId,
            customer_name: name,
            shop_id: vendorId,
            shop_name: shopName,
            chat_room_id: chatRoomId,
            order_image: image,
            order_id: orderId,
            order_title: orderTitle,
            ...updateData,
          },
          {merge: true},
        );
    },
    [chatRoomId],
  );

  const markSeen = useCallback(async () => {
    try {
      const batch = firestore().batch();

      // 1) Mark all messages from other user as seen
      const snap = await firestore()
        .collection('chats')
        .doc(chatRoomId)
        .collection('messages')
        .where('sender_id', '!=', currentUserId)
        .where('seen', '==', false)
        .get();

      snap.forEach(doc => {
        batch.update(doc.ref, {seen: true});
      });

      // 2) Reset unseen counters based on who is seeing
      const chatRef = firestore().collection('chats').doc(chatRoomId);

      if (currentUserId === customerId) {
        // Customer is viewing chat → vendor unseen reset
        batch.update(chatRef, {unseen_for_customer: 0});
      } else {
        // Vendor is viewing chat → customer unseen reset
        batch.update(chatRef, {unseen_for_vendor: 0});
      }

      await batch.commit();
    } catch (error) {
      console.log('error =>', error?.message);
    }
  }, [chatRoomId]);

  return {
    messages,
    sendMessage,
    markSeen,
    loading,
  };
};
