import React from 'react';
import {View, Text, TouchableOpacity, Image} from 'react-native';
import {styles} from './chatStyles';
import Icon from '../../../materialComponent/icon/icon';
import {moderateScale} from 'react-native-size-matters';
import CustomText from '../../../materialComponent/customText/customText';
import {globalStyle} from '../../../constant/contstant';
import CustomButton from '../../../materialComponent/customButton/customButton';
import {heightPercentageToDP} from 'react-native-responsive-screen';
import {goBack, navigate} from '../../../utils/navigationRef/navigationRef';
import CustomImage from '../../../materialComponent/image/image';

const ChatHeader = ({title, image, orderTitle, shopId}) => {
  return (
    <View style={styles.header}>
      <View style={globalStyle.row}>
        <TouchableOpacity onPress={goBack}>
          <Icon
            size={moderateScale(25)}
            icon_type={'MaterialIcons'}
            name={'keyboard-backspace'}
            color={'black'}
          />
        </TouchableOpacity>
        <View
          style={{
            marginLeft: moderateScale(10),
          }}>
          <CustomImage
            size={moderateScale(5)}
            source={{uri: image}}
            style={styles.profileImage}
          />
        </View>

        <View style={{marginLeft: moderateScale(10)}}>
          <CustomText fontSize={moderateScale(14)} text={`${title}`} />
          <CustomText
            color={'gray'}
            fontSize={moderateScale(8)}
            text={`Let’s check your order (${orderTitle}) together.`}
          />
          {/* <Text style={status === "Active Now" ? styles.active : styles.offline}>
          {status}
          </Text> */}
        </View>
      </View>
      <CustomButton
        onPress={() => navigate('Brand', {shop_id: shopId, shop: {}})}
        text={'Visit Store'}
        forceHeight={heightPercentageToDP(3.5)}
        buttonStyle={{borderRadius: 5, paddingHorizontal: 10}}
        backgroundColor={'black'}
        textStyle={{fontSize: moderateScale(10), marginTop: -2}}
      />
    </View>
  );
};

export default ChatHeader;
