import { StatusBar, StyleSheet, View } from "react-native"
import CustomText from "../../../materialComponent/customText/customText"
import HelpCenterHeader from "../../../component/header/helpCenterHeader";
import OrderQuestions from "../../../component/helpCenter/orderQuestions";
import { navigate } from '@utils/navigationRef/navigationRef';
import HelpSvg from "@assets/images/help.svg"

const OrderPlacement=({navigation})=>{
    const orderPlacementQuestions = [
        "Why am I unable to place an order?",
        "How do I place an order?",
        "What payment methods are accepted?",
        "Why am I unable to place an order?",
        "How do I place an order?",
        "What payment methods are accepted?",
        "Why am I unable to place an order?",
        "How do I place an order?",
        "What payment methods are accepted?",
      ];
    return (
        <View style={styles.container}>
        
        <StatusBar animated barStyle={"dark-content"} backgroundColor={"white"} translucent={false} />
        <HelpCenterHeader borderLine={1} navigation={navigation} title={"Help Center"} IconComponent={HelpSvg}/>
   
        <OrderQuestions title={"Order Placement"}
        questions={orderPlacementQuestions}
        onPress={()=> navigate("TrackOrder")}/>
    </View>
    )
}
export default OrderPlacement; 

const styles = StyleSheet.create({
    container:{
        flex:1,
        backgroundColor:"white"
    },
})