import React from 'react';
import {Dimensions, FlatList, StatusBar, StyleSheet, View} from 'react-native';
import {colors, font, globalStyle, margin, WH} from '@constant/contstant';
import {moderateScale, verticalScale} from 'react-native-size-matters';
import useSearch from './useSearch';
import SearchScreenInput from '@component/input/searchScreenInput';
import ActiveSearch from '@component/activeSearch/activeSearch';
import SearchCategories from '@component/searchCategories/searchCategories';
import Content from '@materialComponent/content/content';
import SearchedItemsLoader from '@component/loader/searchedItemsLoader';
import CustomText from '@materialComponent/customText/customText';
import Container from '../../../materialComponent/container/container';
import EmptyScreen from '../../../component/emptyScreen/emptyScreen';

const {height, fontScale} = Dimensions.get('screen');

const Search = ({navigation, route}) => {
  const {
    value,
    handleSearch,
    localData,
    searchLoader,
    isKeyboardVisible,
    _handleBlur,
    categoriesData,
    renderProduct,
    loader,
    taxonomies,
    isCameraOpen,
    setIsCameraOpen,
    searchTaxonomyLoader,
    isFocused,
    isEmpty,
  } = useSearch({navigation, route});
  const flag = false;

  return flag ? (
    <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
      <EmptyScreen
        image={'empty_search'}
        heading={'Search Temporarily Unavailable'}
        desc={
          'We’re improving your search experience. Please check back in a few moments.'
        }
      />
    </View>
  ) : (
    <Container
      dark
      isFocused={isFocused}
      barColor={'white'}
      style={styles.container}>
      {/* <StatusBar
        animated
        barStyle="dark-content"
        backgroundColor="white"
        translucent={false}
      /> */}
      <View
        style={[
          styles.innerContainer,
          //   {marginHorizontal: loader ? 0 : margin.horizontal},
        ]}>
        <View style={{marginBottom: height * -0.001, alignItems: 'center'}}>
          <SearchScreenInput
            onBlur={_handleBlur}
            onChangeText={handleSearch}
            setIsCameraOpen={setIsCameraOpen}
            value={value}
          />
        </View>
        <Content contentContainerStyle={{marginBottom: height * 0.5}}>
          {isKeyboardVisible || value || isCameraOpen ? (
            <ActiveSearch
              value={value}
              searchLoader={searchLoader}
              localData={localData}
            />
          ) : (
            <View style={styles.categoryItem}>
              {searchTaxonomyLoader ? (
                <SearchedItemsLoader
                  category={true}
                  removeProducts={true}
                  loading={loader}
                />
              ) : (
                <SearchCategories
                  params={route?.params}
                  categories={taxonomies}
                />
              )}

              {loader ? (
                <SearchedItemsLoader loading={loader} />
              ) : (
                <>
                  {categoriesData?.length > 0 ? (
                    <View style={{marginTop: height * 0.02}}>
                      <CustomText
                        fontSize={fontScale * 17}
                        fontFamily={font.bold}
                        color="black"
                        text={`Products you may like`}
                      />
                      <FlatList
                        scrollEnabled={false}
                        data={categoriesData}
                        renderItem={renderProduct}
                        keyExtractor={(item, index) => index.toString()}
                        showsHorizontalScrollIndicator={false}
                        numColumns={2}
                        contentContainerStyle={{
                          marginTop: height * 0.02,
                          marginBottom: height * 0.3,
                        }}
                      />
                    </View>
                  ) : (
                    <></>
                  )}

                  {isEmpty ? (
                    <View
                      style={{
                        height: height * 0.85,
                        alignItems: 'center',
                        justifyContent: 'center',
                      }}>
                      <EmptyScreen
                        heading={'Categories not found!'}
                        desc={
                          'Products linked to these categories are also not available.'
                        }
                      />
                    </View>
                  ) : (
                    <></>
                  )}
                </>
              )}
            </View>
          )}
        </Content>
      </View>
    </Container>
  );
};

export default Search;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
    paddingTop: height * 0.02,
  },
  innerContainer: {
    marginHorizontal: margin.horizontal,
    flex: 1,
    backgroundColor: 'white',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between', // Ensure proper spacing.
    marginVertical: verticalScale(10),
  },
  inputContainer: {
    borderRadius: 180,
    ...globalStyle.row,
    height: WH.height(5),
    paddingHorizontal: margin.horizontal,
    backgroundColor: 'rgba(201, 210, 239 , 0.4)',
    width: '80%',
  },
  searchbar: {
    fontFamily: font.medium,
    width: '100%',
    height: '100%',
    marginLeft: moderateScale(10),
    paddingRight: moderateScale(15),
  },
  cancelText: {
    fontFamily: font.medium,
    fontSize: moderateScale(16),
    color: colors.primary,
  },
  searchListItem: {
    backgroundColor: 'red',
  },
  imageView: {
    width: moderateScale(40),
    height: moderateScale(40),
    backgroundColor: 'white',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 10,
    marginRight: moderateScale(15),
    borderColor: colors.light_theme.darkBorderColor,
    borderWidth: 1,
  },
  circle: {
    backgroundColor: colors.light_theme.borderColor,
    borderRadius: 180,
    width: moderateScale(25),
    aspectRatio: 1 / 1,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: moderateScale(10),
  },
});
