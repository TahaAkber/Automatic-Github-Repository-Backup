import {useCallback, useEffect, useRef, useState} from 'react';
import {Dimensions, Keyboard, View} from 'react-native';
import {
  _fetchCategoryProducts,
  _recentSearchRecord,
  _searchMethod,
} from '@redux/actions/common/common';
import useReduxStore from '@utils/hooks/useReduxStore';
import {WH} from '@constant/contstant';
import HomeDualCard from '@component/cards/homeDualCard';
import {
  _fetchSearchedList,
  _getTaxonomies,
} from '../../../redux/actions/common/common';
import {useIsFocused, useNavigation} from '@react-navigation/native';
import {logSearchQueryEvent} from '@helper/eventTriggers/useEventTriggers';

const {height} = Dimensions.get('screen');

const useSearch = ({route}) => {
  const {dispatch, getState} = useReduxStore();
  const {fetch_user_detail} = getState('auth');
  const [value, setValue] = useState('');
  const [searchLoader, setSearchLoader] = useState(false);
  const [searchTaxonomyLoader, setSearchTaxonomyLoader] = useState(false);
  const [isKeyboardVisible, setIsKeyboardVisible] = useState(false);
  const [isCameraOpen, setIsCameraOpen] = useState(false);
  const [loader, setLoader] = useState(false);
  const [categoriesData, setCategoriesData] = useState([]);
  const [taxonomies, setTaxonomies] = useState([]);
  const [localData, setLocalData] = useState({});
  const controllerRef = useRef(null);
  const isFocused = useIsFocused();

  const debounceRef = useRef(null);
  const lastLoggedQueryRef = useRef('');

  const navigation = useNavigation();

  useEffect(() => {
    const keyboardDidShowListener = Keyboard.addListener(
      'keyboardDidShow',
      () => {
        setIsKeyboardVisible(true); // Show "Cancel" button.
      },
    );

    const keyboardDidHideListener = Keyboard.addListener(
      'keyboardDidHide',
      () => {
        setIsKeyboardVisible(false); // Hide "Cancel" button.
      },
    );

    return () => {
      keyboardDidShowListener.remove();
      keyboardDidHideListener.remove();
    };
  }, [isKeyboardVisible]);

  const handleSearch = async text => {
    _searchMethod(
      text,
      setValue,
      setSearchLoader,
      setLocalData,
      debounceRef,
      '',
      controllerRef,
      '',
      true,
      `/rag_search?user_id=${fetch_user_detail?.id || ''}&query=`,
    );
  };

  const _handleBlur = async image => {
    if (value || image) {
      await dispatch(
        _recentSearchRecord({searchTerm: value, image, navigation}),
      );
      setIsCameraOpen(false);
      setValue('');
      setIsKeyboardVisible(false);
    }
  };

  const fetchAPI = async () => {
    try {
      setLoader(true);
      setSearchTaxonomyLoader(true);
      const taxonomies = await dispatch(
        _getTaxonomies(route?.params?.item?.id),
      );
      if (!taxonomies?.length && route?.params?.item?.id) {
        navigation.replace('SearchedItems', {
          searchTerm: route?.params?.item?.name,
        });
        setLoader(false);
        setSearchTaxonomyLoader(false);
      } else {
        setTaxonomies(taxonomies);
        setSearchTaxonomyLoader(false);
        const response = await dispatch(_fetchCategoryProducts());
        const products =
          route?.params?.item?.id &&
          (await dispatch(
            _fetchSearchedList(route?.params?.item?.name, false, 1, false),
          ));
        const mergedProducts = response?.map((item, index) => [
          ...item.products,
        ]);
        setCategoriesData(
          route?.params?.item?.id ? products : mergedProducts.flat(),
        );
        setLoader(false);
      }

  
    } catch (error) {
  
      setLoader(false);
    }
  };

  const renderProduct = useCallback(({item, index}) => {
    return (
      <View
        key={`search_${index}`}
        style={{
          marginRight: WH.width('2'),
          marginTop: index == 0 || index == 1 ? 0 : height * 0.01,
        }}>
        <HomeDualCard item={item} width={WH.width('43')} color={'black'} />
      </View>
    );
  }, []);



  useEffect(() => {
    fetchAPI();
  }, []);

  const isEmpty = taxonomies.length == 0 && categoriesData?.length == 0;

  // Log search query analytics when search results are available
  useEffect(() => {
    if (value && localData?.data && lastLoggedQueryRef.current !== value) {
      const products = localData?.data?.products || [];
      const shops = localData?.data?.shops || [];
      const allResults = localData?.data?.all || [];

      const results = {
        total_results: allResults.length,
        products_count: products.length,
        shops_count: shops.length,
      };

      logSearchQueryEvent(value, results);
      lastLoggedQueryRef.current = value;
    }
  }, [value, localData]);

  return {
    value,
    handleSearch,
    localData,
    searchLoader,
    isKeyboardVisible,
    _handleBlur,
    categoriesData,
    renderProduct,
    loader,
    taxonomies,
    isCameraOpen,
    setIsCameraOpen,
    searchTaxonomyLoader,
    isFocused,
    isEmpty,
  };
};

export default useSearch;
