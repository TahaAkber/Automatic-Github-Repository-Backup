import { _register, _socialLogin, _userVerifier } from '@redux/actions/auth/auth';
import { _getStores } from '@redux/actions/merchant/merchant';
import { _globalLoader } from '@redux/actions/common/common';
import useReduxStore from '@utils/hooks/useReduxStore';
import { _getAddress } from '@redux/actions/user/user';
import { useEffect, useState } from 'react';

const useShoppingNotificationSetting = ({ route }) => {
    const { getState, dispatch } = useReduxStore()
    const { fetch_user_detail } = getState("auth")
    const { fetch_address, fetch_address_loader, fetch_address_error } = getState("user")
    const [pullLoader, setPullLoader] = useState(false);

    const fetchAPI = async (isLoading) => {
        !isLoading && setPullLoader(true)
        await dispatch(_getAddress(fetch_user_detail?.id))
        setPullLoader(false)
    }

    useEffect(() => {
        fetchAPI(true)
    }, [])

    return {
        fetchAPI,
        fetch_address,
        pullLoader,
    };
};

export default useShoppingNotificationSetting;
