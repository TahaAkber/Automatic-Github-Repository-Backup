import {_register, _socialLogin, _userVerifier} from '@redux/actions/auth/auth';
import {_getStores} from '@redux/actions/merchant/merchant';
import {_globalLoader} from '@redux/actions/common/common';
import useReduxStore from '@utils/hooks/useReduxStore';
import {_getAddress} from '@redux/actions/user/user';
import {useCallback, useEffect, useState} from 'react';
import {_getUserNotificationStatuses} from '../../../redux/actions/user/user';
import {useFocusEffect} from '@react-navigation/native';

const useNotificationSetting = ({}) => {
  const {getState, dispatch} = useReduxStore();
  const {fetch_user_detail} = getState('auth');

  useFocusEffect(
    useCallback(() => {
      dispatch(_getUserNotificationStatuses(fetch_user_detail?.id));
    }, []),
  );

  return {
    fetch_user_detail,
  };
};

export default useNotificationSetting;
