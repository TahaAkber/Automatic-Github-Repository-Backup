import {useEffect, useState} from 'react';
import firestore from '@react-native-firebase/firestore';
import useReduxStore from '../../../utils/hooks/useReduxStore';

export const useInbox = () => {
  const {getState} = useReduxStore();
  const {fetch_user_detail} = getState('auth');
  const [inbox, setInbox] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsub = firestore()
      .collection('chats')
      .where('customer_id', '==', fetch_user_detail?.id)
      .orderBy('last_message_time', 'desc')
      .onSnapshot(snap => {
        const list = snap?.docs?.map(doc => ({
          id: doc.id,
          ...doc.data(),
        }));
        if (Array.isArray(list)) {
          setInbox(list);
        }
        setLoading(false);
      });

    return () => unsub();
  }, []);

  return {inbox, loading};
};
