import {_register, _socialLogin, _userVerifier} from '@redux/actions/auth/auth';
import {_createAddress, _getAddressDetail} from '@redux/actions/user/user';
import {getFullAddressFromCoordinates} from '@utils/helper/helper';
import Geolocation from '@react-native-community/geolocation';
import {_getStores} from '@redux/actions/merchant/merchant';
import {_globalLoader} from '@redux/actions/common/common';
import {Permission} from '@utils/imagePicker/imagePicker';
import useReduxStore from '@utils/hooks/useReduxStore';
import {useEffect, useRef, useState} from 'react';
import {Keyboard} from 'react-native';
import * as Yup from 'yup';
import {countries} from '../../../constant/dummyData';

const useCreateAddress = ({addressId}) => {
  const {getState, dispatch} = useReduxStore();
  const {fetch_user_detail} = getState('auth');


  const countryInputRef = useRef(null);
  const firstNameRef = useRef(null);
  const lastNameRef = useRef(null);
  const companyRef = useRef(null);
  const addressInputRef = useRef(null);
  const apartmentInputRef = useRef(null);
  const cityInputRef = useRef(null);
  // const provinceInputRef = useRef(null);
  const postalCodeInputRef = useRef(null);
  const phoneRef = useRef(null);

  const [keyboardVisible, setKeyboardVisible] = useState(false);
  const [address, setAddress] = useState({});
  const [loader, setLoader] = useState(false);
  const [countryCode, setCountryCode] = useState(+92);

  const _handleSubmit = async values => {
    setLoader(true);
    const res = await dispatch(
      _createAddress(values, fetch_user_detail?.id, addressId),
    );
    setLoader(false);
  };

  const _handleCurrentLocation = async () => {
    const permissionLocation = await Permission('location');
    if (permissionLocation.status) {
      Geolocation.getCurrentPosition(async info => {
        const locationDetails = await getFullAddressFromCoordinates(
          info.coords.latitude,
          info.coords.longitude,
        );
        setAddress(locationDetails);
      });
    }
    // console.log("permissionLocation", permissionLocation)
  };

  useEffect(() => {
    // Keyboard show and hide listeners
    const showSubscription = Keyboard.addListener('keyboardDidShow', () =>
      setKeyboardVisible(true),
    );
    const hideSubscription = Keyboard.addListener('keyboardDidHide', () =>
      setKeyboardVisible(false),
    );

    return () => {
      showSubscription.remove();
      hideSubscription.remove();
    };
  }, []);

  const fetchAddressDetail = async () => {
    const res = await dispatch(_getAddressDetail(addressId));
    if (res) {

      const countryIdByData = countries.find(
        item => item.value == res?.address_country,
      );

      setCountryCode(countryIdByData?.country_code);

      setAddress({
        firstName: res?.address_first_name,
        lastName: res?.address_last_name,
        country: countryIdByData?.id,
        fullAddress: res?.address_one,
        apartment: res?.address_two,
        city: res?.address_city,
        // province: res?.address_province,
        postalCode: res?.address_postal_code,
        number: res?.address_number,
      });
    }
  };

  useEffect(() => {
    if (addressId) {
      fetchAddressDetail();
    }
  }, []);

  // const validationSchema = Yup.object({
  //     country: Yup.string()
  //         .required('country is required'),
  //     address: Yup.string()
  //         .required('address is required'),
  //     city: Yup.string()
  //         .required('city is required'),
  // });

  const validationSchema = Yup.object({
    country: Yup.string().required('country is required'),
    firstName: Yup.string().required('First name is required'),
    lastName: Yup.string().required('Last name is required'),
    country: Yup.string().required('Country is required'),
    address: Yup.string().required('Address is required'),
    city: Yup.string().required('City is required'),
    phone: Yup.string().required('Phone number is required'),
    // Optional fields
    postalcode: Yup.string(),
    apartment: Yup.string(),
  });

  const schema = validationSchema;

  const handleCountryCode = country_id => {
    const countryIdByData = countries.find(item => item.id == country_id);
    setCountryCode(countryIdByData?.country_code);
  };

  return {
    _handleCurrentLocation,
    _handleSubmit,
    keyboardVisible,
    address,
    loader,
    schema,
    countryInputRef,
    addressInputRef,
    apartmentInputRef,
    cityInputRef,
    // provinceInputRef,
    postalCodeInputRef,
    fetch_user_detail,
    firstNameRef,
    lastNameRef,
    companyRef,
    phoneRef,
    countryCode,
    handleCountryCode,
  };
};

export default useCreateAddress;
