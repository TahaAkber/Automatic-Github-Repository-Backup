import React from 'react';
import Container from '@materialComponent/container/container';
import AddressForm from './addressForm';
import BackOverLay from '@materialComponent/backOverlay/backOverlay';
import InnerHeader from '@component/header/innerHeader';
import Content from '@materialComponent/content/content';
import {Dimensions} from 'react-native';
import {useIsFocused} from '@react-navigation/native';

const {fontScale, height, width} = Dimensions.get('screen');

const CreateAddress = ({route}) => {
  const addressId = route?.params?.address_id?.address_id;
  const isFocused = useIsFocused();

  return (
    <Container
      bgColor={'white'}
      barColor={"white"}
      dark
      isFocused={isFocused}
      backgroundColor={'white'}>
      <InnerHeader
        title={`${addressId ? 'Update address' : 'Add new address'}`}
        showBackIcon={true}
      />
      <Content contentContainerStyle={{}}>
        <AddressForm addressId={addressId} />
      </Content>
      {/* <BackOverLay /> */}
    </Container>
  );
};

export default CreateAddress;
