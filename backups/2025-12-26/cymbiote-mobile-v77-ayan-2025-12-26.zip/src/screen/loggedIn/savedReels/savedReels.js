import {
  Dimensions,
  StatusBar,
  StyleSheet,
  View,
  FlatList,
  RefreshControl,
  ActivityIndicator,
  Text,
} from 'react-native';
import React, {useEffect} from 'react';
import InnerHeader from '@component/header/innerHeader';
import Content from '@materialComponent/content/content';
import Container from '@materialComponent/container/container';
import SavedReelCard from '../../../component/cards/savedReelsCard/savedReelCard';
import useUserSavedReels from './useSavedReels'; // update path accordingly
import {globalStyle, margin} from '../../../constant/contstant';
import SavedReelCardLoader from '../../../component/loader/savedReelLoader';
import HomeLoader from '../../../component/loader/homeLoader';
import PagionationLoader from '../../../component/loader/endReachLoader';
import Overlay from '../../../materialComponent/overlay/overlay';
import EmptyScreen from '../../../component/emptyScreen/emptyScreen';
import {showErrorScreen} from '../../../utils/helper/helper';

const {height} = Dimensions.get('screen');

const SavedReels = () => {
  const {
    userSavedReels,
    userSavedReelsLoading,
    paginationLoader,
    paginationAPI,
    fetchAPI,
    pullLoader,
    userSavedReelsError,
  } = useUserSavedReels();

  const renderFooter = () =>
    userSavedReelsLoading ? (
      <View style={{padding: 10, alignItems: 'center'}}>
        <HomeLoader loading={userSavedReelsLoading} />
      </View>
    ) : null;

  return showErrorScreen(userSavedReelsError) ? (
    <View style={globalStyle.show_error}>
      <EmptyScreen
        fullWidth={true}
        reload={fetchAPI}
        loader={pullLoader}
        message={userSavedReelsError}
      />
    </View>
  ) : (
    <Container barColor={'white'}>
      <View style={styles.container}>
        <InnerHeader notification={true} setting={true} title="Saved Reels" />
        <Content
          refreshControl={
            <RefreshControl refreshing={pullLoader} onRefresh={fetchAPI} />
          }>
          <StatusBar
            animated
            barStyle="dark-content"
            backgroundColor="white"
            translucent={false}
          />

          {userSavedReelsLoading ? (
            <SavedReelCardLoader />
          ) : (
            <FlatList
              data={userSavedReels?.data || []}
              keyExtractor={item =>
                item.id?.toString() || item.video_url_id?.toString()
              }
              numColumns={2}
              showsVerticalScrollIndicator={false}
              renderItem={({item}) => <SavedReelCard item={item} />}
              contentContainerStyle={{
                paddingHorizontal: 10,
                paddingBottom: height * 0.07,
              }}
              ListFooterComponent={
                paginationLoader ? (
                  <View
                    style={{
                      justifyContent: 'center',
                      alignItems: 'center',
                      paddingVertical: 20,
                    }}>
                    <PagionationLoader />
                  </View>
                ) : null
              }
              onEndReached={paginationAPI}
              onEndReachedThreshold={0.2}
              initialNumToRender={10}
              windowSize={7}
              ListEmptyComponent={
                <View
                  style={{
                    justifyContent: 'center',
                    alignItems: 'center',
                    flex: 1,
                    marginTop: height * 0.22,
                  }}>
                  <EmptyScreen
                    image={'empty_reels'}
                    heading={'No Reel Saved Yet!'}
                    desc={
                      'No saved reels are here right now. Discover exciting products and save reels to see them all in one place.'
                    }
                  />
                </View>
              }
              // removeClippedSubviews={true}
            />
          )}
        </Content>
      </View>
    </Container>
  );
};

export default SavedReels;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
    paddingHorizonstal: margin.horizontalMargin,
    marginBottom: 20,
  },
});
