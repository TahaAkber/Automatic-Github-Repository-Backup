import {
  Dimensions,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import React from 'react';
import {moderateScale, verticalScale} from 'react-native-size-matters';
import InnerHeader from '@component/header/innerHeader';
import {colors, globalStyle, shadow, margin, font} from '@constant/contstant';
import OrderSvg from '@assets/images/order.svg';
import FollowingSvg from '@assets/images/following.svg';
import ReviewSvg from '@assets/images/reviews.svg';
import FavSvg from '@assets/images/fav.svg';
import InboxSvg from '@assets/images/inbox.svg';
import TrackOrderSvg from '@assets/images/tracking.svg';
import CustomerCareSvg from '@assets/images/customerCare.svg';
import HelpSvg from '@assets/images/help.svg';
// import Voucher from '@assets/images/voucher';
import useProfile from './useProfile';
import CustomText from '@materialComponent/customText/customText';
import VoucherCard from '@component/cards/voucherCard/voucherCard';
import ChildLineBottomCard from '@component/cards/childLineBottomCard/childLineBottomCard';
import {navigate} from '@utils/navigationRef/navigationRef';
import ProfileLogin from './profileLogin';
import Container from '../../../materialComponent/container/container';
import {useIsFocused} from '@react-navigation/native';

const {width, height, fontScale} = Dimensions.get('screen');

const Profile = () => {
  const {fetch_user_detail} = useProfile({});
  const isFocused = useIsFocused();
  console.log('fetch_user_detail', fetch_user_detail);
  return fetch_user_detail?.id ? (
    <Container isFocused={isFocused} barColor={colors.light_theme.theme}>
      <View style={[styles.mainView, {paddingHorizontal: 0}]}>
        {/* <StatusBar
        animated
        barStyle={'light-content'}
        backgroundColor={colors.light_theme.theme}
      /> */}
        <View style={styles.header}>
          <InnerHeader
            notification={true}
            setting={true}
            profile={true}
            title={'My Profile'}
            light={true}
            fontSize={fontScale * 16}
            showBackIcon={false}
          />
        </View>
        <View style={[globalStyle.space_between, styles.profileBox]}>
          {data.map((item, index) => {
            return (
              <TouchableOpacity
                activeOpacity={1}
                onPress={() => navigate(item.screen)}>
                <View style={styles.profileOptionBox}>
                  <item.ImageComponent
                    // width={width * 0.08}
                    // height={width * 0.08}
                    width={width * 0.06}
                    height={width * 0.06}
                    color={'red'}
                    fill={'red'}
                  />
                </View>
                <CustomText
                  text={item.title}
                  style={styles.profileOptionBoxText}
                />
              </TouchableOpacity>
            );
          })}
        </View>
        <View
          style={{
            marginHorizontal: margin.horizontal,
            marginLeft: 8,
            display: 'flex',
            flexDirection: 'row',
          }}>
          <ChildLineBottomCard
            heading={'Unlock Rewards,'}
            secondHeading={'Redeem Today!'}
            firstLineCode={'Redeem your points for discounts, offers.'}
            secondineCode={'Redeem Now'}
            onPress={() => navigate('Rewards')}
            reward={true}
            marginTop={height * 0.04}
          />
          <ChildLineBottomCard
            heading={'Explore Your'}
            secondHeading={'Saved Reels'}
            firstLineCode={
              'View and access all the reels youve saved for later.!'
            }
            secondineCode={'Watch Now'}
            onPress={() => navigate('SavedReels')}
            reward={false}
            marginTop={height * 0.04}
          />
        </View>
        {/* <VoucherCard /> */}
        {/* <View
        style={[
          globalStyle.space_between,
          {
            marginHorizontal: margin.horizontal,
          },
        ]}>
        <View style={{width: '49%'}}>
          <ChildLineCard
            firstIcon={HelpSvg}
            heading={'Help'}
            firstLineCode={'Instant Help, Just a Tap Away'}
            marginTop={height * 0.02}
            style={{
              padding: 0,
              paddingVertical: height * 0.02,
              paddingHorizontal: width * 0.01,
            }}
            fontSize={fontScale * 9}
            isTouchable={true}
            onPress={() => navigate('HelpCenter')}
          />
        </View>
        <View style={{width: '49%'}}>
          <ChildLineCard
            firstIcon={CustomerCareSvg}
            heading={'Customer Care'}
            firstLineCode={'Your Support, Our Priority!'}
            marginTop={height * 0.02}
            style={{
              padding: 0,
              paddingVertical: height * 0.02,
              paddingHorizontal: width * 0.01,
            }}
            fontSize={fontScale * 9}
            isTouchable={true}
            onPress={() => navigate('CustomerCare')}
          />
        </View>
      </View> */}
      </View>
    </Container>
  ) : (
    <ProfileLogin />
  );
};

export default Profile;

const styles = StyleSheet.create({
  mainView: {
    flex: 1,
    backgroundColor: 'white',
    paddingHorizontal: margin.horizontal,
  },
  flatLists: {
    paddingVertical: verticalScale(10),
    paddingBottom: globalStyle.bottomSpace.marginBottom,
  },
  header: {
    backgroundColor: colors.light_theme.theme,
    // paddingBottom: height * 0.06,
    paddingBottom: height * 0.09,
    // paddingBottom: height * 0.06,
    borderBottomRightRadius: 10,
    borderBottomLeftRadius: 10,
  },
  profileBox: {
    marginHorizontal: margin.horizontal,
    // marginTop: height * -0.035,
    marginTop: height * -0.05,
  },
  profileOptionBox: {
    backgroundColor: 'white',
    // width: width * 0.2,
    width: width * 0.16,
    aspectRatio: 1,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
    ...shadow,
    elevation: 10,
  },
  profileOptionBoxText: {
    textAlign: 'center',
    width: width * 0.16,
    // width: width * 0.2,
    justifyContent: 'center',
    alignItems: 'center',
    // fontSize: fontScale * 11,
    fontSize: moderateScale(12),
    // fontSize: fontScale * 13,
    marginTop: height * 0.01,
  },
});

const data = [
  {
    ImageComponent: OrderSvg,
    title: 'Orders',
    screen: 'OrderNavigation',
  },
  {
    ImageComponent: FollowingSvg,
    title: 'Following',
    screen: 'Following',
  },
  {
    ImageComponent: FavSvg,
    title: 'Favorites',
    screen: 'Favorites',
  },
  {
    ImageComponent: ReviewSvg,
    title: 'Reviews',
    screen: 'AllReviews',
  },
  {
    ImageComponent: InboxSvg,
    title: 'Inbox',
    screen: 'Inbox',
  },
];

// import React, { useRef, useState } from 'react';
// import {
//   View,
//   Text,
//   TouchableOpacity,
//   Image,
//   StyleSheet,
//   UIManager,
//   findNodeHandle,
// } from 'react-native';
// import Animated, {
//   useSharedValue,
//   useAnimatedStyle,
//   withTiming,
//   runOnJS,
// } from 'react-native-reanimated';

// export default function Profile() {
//   const [flyImageVisible, setFlyImageVisible] = useState(false);

//   const productImageRef = useRef(null);
//   const cartIconRef = useRef(null);

//   const translateX = useSharedValue(0);
//   const translateY = useSharedValue(0);
//   const scale = useSharedValue(1);
//   const opacity = useSharedValue(0);

//   const animatedStyle = useAnimatedStyle(() => ({
//     position: 'absolute',
//     width: 100,
//     height: 100,
//     transform: [
//       { translateX: translateX.value },
//       { translateY: translateY.value },
//       { scale: scale.value },
//     ],
//     opacity: opacity.value,
//     zIndex: 999,
//   }));

//   const triggerFlyToCart = () => {
//     const productHandle = findNodeHandle(productImageRef.current);
//     const cartHandle = findNodeHandle(cartIconRef.current);

//     if (!productHandle || !cartHandle) return;

//     UIManager.measure(productHandle, (_, __, w1, h1, x1, y1) => {
//       UIManager.measure(cartHandle, (_, __, w2, h2, x2, y2) => {
//         translateX.value = x1;
//         translateY.value = y1;
//         scale.value = 1;
//         opacity.value = 1;

//         runOnJS(setFlyImageVisible)(true);

//         translateX.value = withTiming(x2, { duration: 800 });
//         translateY.value = withTiming(y2, { duration: 800 });
//         scale.value = withTiming(0.2, { duration: 800 });
//         opacity.value = withTiming(0, { duration: 800 }, () => {
//           runOnJS(setFlyImageVisible)(false);
//         });
//       });
//     });
//   };

//   return (
//     <View style={styles.container}>
//       <View style={styles.header}>
//         <Text style={styles.title}>Khaadi Lawn ALA231206</Text>
//         <TouchableOpacity ref={cartIconRef} style={styles.cart}>
//           <Text style={{ fontSize: 24 }}>🛒</Text>
//         </TouchableOpacity>
//       </View>

//       <View>
//         <Image
//           ref={productImageRef}
//           source={require('../../../assets/images/tileBackgroundImage.png')}
//           style={styles.productImage}
//         />
//       </View>

//       <TouchableOpacity onPress={triggerFlyToCart} style={styles.button}>
//         <Text style={styles.buttonText}>Add To Cart</Text>
//       </TouchableOpacity>

//       {flyImageVisible && (
//         <Animated.Image
//           source={require('../../../assets/images/tileBackgroundImage.png')}
//           style={[styles.flyImage, animatedStyle]}
//         />
//       )}
//     </View>
//   );
// }

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     paddingTop: 80,
//     paddingHorizontal: 16,
//     backgroundColor: '#fff',
//   },
//   header: {
//     flexDirection: 'row',
//     justifyContent: 'space-between',
//     alignItems: 'center',
//   },
//   cart: {
//     width: 48,
//     height: 48,
//     borderRadius: 24,
//     backgroundColor: '#eee',
//     justifyContent: 'center',
//     alignItems: 'center',
//   },
//   productImage: {
//     width: 200,
//     height: 200,
//     resizeMode: 'contain',
//     alignSelf: 'center',
//     marginTop: 40,
//   },
//   title: {
//     fontSize: 20,
//     fontWeight: '600',
//   },
//   button: {
//     backgroundColor: '#7159c1',
//     paddingVertical: 14,
//     paddingHorizontal: 32,
//     marginTop: 40,
//     borderRadius: 12,
//     alignSelf: 'center',
//   },
//   buttonText: {
//     color: '#fff',
//     fontWeight: 'bold',
//     fontSize: 16,
//   },
//   flyImage: {
//     position: 'absolute',
//     width: 100,
//     height: 100,
//     borderRadius: 12,
//   },
// });
