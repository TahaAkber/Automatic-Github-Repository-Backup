import {moderateScale} from 'react-native-size-matters';
import {Dimensions, StyleSheet, TouchableOpacity, View} from 'react-native';
import React, {useEffect, useRef, useState} from 'react';
import {margin} from '@constant/contstant';
import CustomImage from '@materialComponent/image/image';
import CustomText from '@materialComponent/customText/customText';
import {font, globalStyle} from '@constant/contstant';
import Icon from '@materialComponent/icon/icon';
import {useDispatch} from 'react-redux';
import {
  _getStores,
  _getStoresForRedeem,
} from '../../../redux/actions/merchant/merchant';
import useReduxStore from '../../../utils/hooks/useReduxStore';
import {pagination} from '../../../utils/helper/helper';
import {
  call,
  isCenterOfTriple,
  isEven,
} from '../../../helper/reUsableMethod/reUsableMethod';
import {_searchMethod} from '../../../redux/actions/common/common';

const {width, height, fontScale} = Dimensions.get('screen');

const useRedeem = () => {
  const {dispatch, getState} = useReduxStore();
  const {fetch_store_for_redeem, fetch_store_loader} = getState('merchant');

  const refRBSheet = useRef(null);
  const [item, setItem] = useState({});
  const [paginationLoader, setPaginationLoader] = useState(false);
  const [page, setPage] = useState(1);

  const [search, setSearch] = useState('');
  const [searchLoader, setSearchLoader] = useState('');
  const [localData, setLocalData] = useState({});
  const debounceRef = useRef(null);
  const controllerRef = useRef(null);
  const latestSearchId = useRef(0);

  const handlePress = item => {
    setItem(item);
    refRBSheet?.current?.open();
  };

  const paginationAPI = async () => {
    if (!paginationLoader) {
      const totalPages = fetch_store_for_redeem?.data?.totalPages;
      const nextPagination = pagination(page, totalPages, setPage);
      if (nextPagination) {
        setPaginationLoader(true);
        const response = await dispatch(
          _getStoresForRedeem({page: nextPagination}),
        );
        if (response) {
          setPaginationLoader(false);
        } else {
          setPaginationLoader(false);
        }
      }
    }
  };

  const renderShops = ({item, index}) => {
    return (
      <TouchableOpacity
        onPress={() => handlePress(item)}
        style={{
          width: '32%',
          marginHorizontal: isCenterOfTriple(index) ? '2%' : 0,
          marginTop: index > 2 ? height * 0.02 : 0,
        }}>
        <CustomImage style={styles.image} source={{uri: item.shop_logo_url}} />
        <View style={{marginTop: height * 0.01}}>
          <CustomText
            text={item?.shop_name}
            fontSize={fontScale * 10}
            fontFamily={font.bold}
          />
          <View style={[globalStyle.row, {marginTop: height * 0.002}]}>
            <CustomText
              fontSize={fontScale * 9}
              style={styles.ratingText}
              color={'black'}
              fontFamily={font.medium}
              text={
                item?.rating?.average_rating
                  ? item?.rating?.average_rating.toFixed(1)
                  : '0'
              }
            />
            <Icon
              size={fontScale * 9}
              color={'#9FCD22'}
              icon_type="FontAwesome"
              style={styles.icon}
              name="star"
            />
            <CustomText
              fontSize={fontScale * 8}
              color={'black'}
              fontFamily={font.bold}
              text={`(${item?.rating?.total_reviews || 0})`}
            />
          </View>
        </View>
      </TouchableOpacity>
    );
  };

  const fetchAPI = async () => {
    setSearchLoader(true);
    await dispatch(_getStoresForRedeem({page: 1}));
    setSearchLoader(false);
  };

  useEffect(() => {
    fetchAPI();
  }, []);

  const handleSearch = async text => {
    _searchMethod(
      text,
      setSearch,
      setSearchLoader,
      setLocalData,
      debounceRef,
      latestSearchId,
      controllerRef,
      'data',
      false,
      `/shops/search?search_term=`,
    );
  };

  return {
    item,
    setItem,
    handlePress,
    renderShops,
    refRBSheet,
    fetch_store_for_redeem,
    fetch_store_loader,
    paginationAPI,
    paginationLoader,
    setSearch,
    search,
    handleSearch,
    searchLoader,
    localData,
  };
};

export default useRedeem;

const styles = StyleSheet.create({
  image: {
    width: '100%',
    height: height * 0.1,
    borderRadius: moderateScale(10),
  },
  shopsList: {
    paddingBottom: height * 0.4,
    marginHorizontal: margin.horizontal,
  },
  icon: {
    marginHorizontal: moderateScale(5),
  },
});
