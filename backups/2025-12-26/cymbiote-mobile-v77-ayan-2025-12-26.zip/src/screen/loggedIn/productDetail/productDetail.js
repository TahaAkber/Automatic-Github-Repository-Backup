import BorderLine from '@component/borderLine/borderLine';
import ProductDetailReViewWithChart from '@component/cards/productDetailReViewWithChart/productDetailReViewWithChart';
import ImageSlider from '@component/imageCarousel/imageCarousel';
import LCSCard from '@component/lcsCard/lcsCard';
import ProductDetailLoader from '@component/loader/productDetailLoader';
import ProductDetailVariants from '@component/productVariants/productDetailVariant';
import {colors, font, globalStyle, margin} from '@constant/contstant';
import {currency} from '@constant/signature';
import {
  useEventTriggers,
  logProductDetailSimilarProductClickEvent,
  logProductDetailRelatedProductClickEvent,
  logProductDetailActionEvent,
  logProductDetailSkippedProductsEvent,
} from '@helper/eventTriggers/useEventTriggers';
import Content from '@materialComponent/content/content';
import CustomButton from '@materialComponent/customButton/customButton';
import CustomText from '@materialComponent/customText/customText';
import ExpandableText from '@materialComponent/expandableText/expandableText';
import Icon from '@materialComponent/icon/icon';
import {_addToCart} from '@redux/actions/cart/cart';
import {
  formatPrice,
  showingVaraintPrice,
  toFixedMethod,
} from '@utils/helper/helper';
import {navigate} from '@utils/navigationRef/navigationRef';
import React, {useEffect, useRef} from 'react';
import {
  ActivityIndicator,
  Alert,
  Dimensions,
  FlatList,
  Platform,
  StyleSheet,
  Text,
  ToastAndroid,
  TouchableOpacity,
  TouchableWithoutFeedback,
  View,
} from 'react-native';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSequence,
  withSpring,
  withTiming,
} from 'react-native-reanimated';
import {moderateScale, verticalScale} from 'react-native-size-matters';
import SearchedItemsLoader from '../../../component/loader/searchedItemsLoader';
import {noImageUrl, WH} from '../../../constant/contstant';
import Container from '../../../materialComponent/container/container';
import {triggerCartBounce} from '../../../redux/actions/common/common';
import {triggerHaptic} from '../../../utils/haptic/haptic';
import useReduxStore from '../../../utils/hooks/useReduxStore';
import {goBack} from '../../../utils/navigationRef/navigationRef';
import useProductDetail from './useProductDetail';
import EmptyScreen from '../../../component/emptyScreen/emptyScreen';
import {showErrorScreen} from '../../../utils/helper/helper';
import HomeDualCard from '../../../component/cards/homeDualCard';

const {fontScale, width, height} = Dimensions.get('screen');

const MAX_QTY = 50;
const showQtyError = () => {
  const msg = `Maximum ${MAX_QTY} items allowed per product.`;
  if (Platform.OS === 'android') {
    ToastAndroid.show(msg, ToastAndroid.SHORT);
  } else {
    Alert.alert('Limit reached', msg);
  }
};

const cleanUrl = url => url?.split('?')[0] || '';

const bringDefaultFirst = (urls = [], defaultUrl) => {
  if (!defaultUrl) return urls;
  const def = cleanUrl(defaultUrl);
  const reordered = [];

  urls.forEach(u => {
    if (cleanUrl(u) === def) {
      reordered.unshift(u);
    } else {
      reordered.push(u);
    }
  });

  return reordered;
};

const ProductDetail = ({route}) => {
  const {
    renderSimilarProducts,
    renderVariant,
    fetch_store_product_detail,
    images,
    variant,
    fetch_store_product_detail_loader,
    dispatch,
    qty,
    variantData,
    getSelectedVariant,
    handleValue,
    result,
    localQty,
    handleQty,
    deleteProduct,
    variantStock,
    _handleBuyNow,
    checkOutLoader,
    product_id,
    _handleFavorite,
    favorite,
    shop_detail,
    default_images,
    scrollRef,
    productDetailReview,
    relatedShops,
    displayImages,
    syncingCart,
    fetch_store_products,
    relatedProductLoader,
    relatedProducts,
    brand_screen,
    defaultHeight,
    isFocused,
    fetch_store_product_detail_error,
    fetchAPI,
  } = useProductDetail({route});

  console.log(
    'fetch_store_product_detail_error',
    fetch_store_product_detail_error,
  );

  // 📊 Analytics tracking refs
  const clickedSimilarProductIdsRef = useRef(new Set());
  const clickedRelatedProductIdsRef = useRef(new Set());
  const hasLoggedSkippedProductsRef = useRef(false);

  useEventTriggers('Product Detail', {
    product_id: fetch_store_product_detail?.product_detail?.product_id,
    product_name: fetch_store_product_detail?.product_detail?.product_name,
    merchant_id: fetch_store_product_detail?.shop_detail?.shop_id,
    merchant_name: fetch_store_product_detail?.shop_detail?.shop_name,
  });

  console.log(
    'fetch_store_product_detail?.product_detail',
    fetch_store_product_detail?.product_detail,
  );
  const reportSheetRef = useRef(null);
  const reportActionsRef = useRef(null);

  // 📊 Analytics: Log skipped products when leaving screen
  useEffect(() => {
    return () => {
      if (
        !hasLoggedSkippedProductsRef.current &&
        fetch_store_product_detail?.product_detail?.product_id &&
        (fetch_store_products?.length > 0 || relatedProducts?.length > 0)
      ) {
        console.log('🔥 [PRODUCT DETAIL] Logging skipped products on unmount');

        logProductDetailSkippedProductsEvent(
          fetch_store_product_detail?.product_detail?.product_id,
          fetch_store_product_detail?.shop_detail || shop_detail,
          fetch_store_products || [],
          Array.from(clickedSimilarProductIdsRef.current),
          relatedProducts || [],
          Array.from(clickedRelatedProductIdsRef.current),
        );

        hasLoggedSkippedProductsRef.current = true;
      }
    };
  }, [
    fetch_store_product_detail,
    fetch_store_products,
    relatedProducts,
    shop_detail,
  ]);

  const productImages =
    fetch_store_product_detail?.product_detail?.product_images || [];

  // Map the product_images array to extract product_image_url for the ImageSlider
  const defaultImage = default_images?.[0];

  const imageUrls = productImages?.length
    ? bringDefaultFirst(
        productImages.map(
          image =>
            image.product_image_url_medium ||
            image.product_image_url ||
            noImageUrl,
        ),
        defaultImage,
      )
    : images;

  const imageUrlsOriginalSize = productImages?.length
    ? bringDefaultFirst(
        productImages.map(
          image =>
            image.product_image_url_high ||
            image.product_image_url ||
            noImageUrl,
        ),
        defaultImage,
      )
    : images;

  console.log(
    'imageUrlss ==>',
    // JSON.stringify(
    {
      imageUrls,
      productImages,
      imageUrlsOriginalSize,
      // imageUrlsOriginalSize,
    },
    // ),
  );

  const AnimatedAddToCartButton = ({disabled, onPress, text, loader}) => {
    const scale = useSharedValue(1);
    const {dispatch} = useReduxStore();
    const animatedStyle = useAnimatedStyle(() => ({
      transform: [{scale: scale.value}],
    }));

    const handlePress = () => {
      triggerHaptic();
      if (disabled) return;

      // bounce animation
      scale.value = withSequence(
        withTiming(1.1, {duration: 100}),
        withSpring(1, {stiffness: 300, damping: 30}),
      );

      dispatch(triggerCartBounce(true));

      if (onPress) onPress();
    };
    console.log(
      fetch_store_products,
      'fetch_store_productsfetch_store_products',
    );

    return (
      <TouchableWithoutFeedback
        onPress={handlePress}
        disabled={disabled || loader}>
        <Animated.View
          style={[
            {
              backgroundColor: disabled ? '#ccc' : colors.light_theme.theme,
              alignItems: 'center',
              justifyContent: 'center',
              width: '100%',
              fontFamily: font.medium,
              backgroundColor: colors.light_theme.theme,
              borderRadius: 180,
              height: height * 0.054,
            },
            animatedStyle,
          ]}>
          {loader ? (
            <ActivityIndicator size="small" color="white" />
          ) : (
            <Text style={{color: 'white', fontFamily: font.medium}}>
              {typeof text === 'string' ? text : ''}
            </Text>
          )}
        </Animated.View>
      </TouchableWithoutFeedback>
    );
  };

  const htmlContent =
    fetch_store_product_detail?.product_detail?.product_description_html;

  const reviewSectionRef = React.useRef(null);
  const reviewSectionY = React.useRef(0);

  console.log(imageUrls, 'HTML Content of product description');

  // 📊 Analytics: Wrapper for Buy Now with analytics tracking
  const handleBuyNowWithAnalytics = async () => {
    console.log('🔥 [PRODUCT DETAIL] Buy Now clicked');

    // 📊 Analytics: Log buy now action
    await logProductDetailActionEvent(
      'buy_now',
      fetch_store_product_detail?.product_detail,
      getSelectedVariant(),
      qty || localQty || 1,
      fetch_store_product_detail?.shop_detail || shop_detail,
    );

    // Call original handler
    await _handleBuyNow();
  };

  // 📊 Analytics: Wrapper for similar products with click tracking
  const renderSimilarProductsWithAnalytics = ({item, index}) => {
    const handleProductPress = () => {
      console.log(
        '🔥 [PRODUCT DETAIL] Similar product clicked:',
        item.product_name,
      );

      // Track the clicked product
      clickedSimilarProductIdsRef.current.add(item.product_id);

      // Log analytics event
      logProductDetailSimilarProductClickEvent(
        item,
        fetch_store_product_detail?.product_detail?.product_id,
        index,
        fetch_store_product_detail?.shop_detail || shop_detail,
      );
    };

    return (
      <View style={styles.similarProductCard}>
        <HomeDualCard item={item} color="black" onPress={handleProductPress} />
      </View>
    );
  };

  // 📊 Analytics: Wrapper for related products with click tracking
  const renderRelatedProductsWithAnalytics = ({item, index}) => {
    const handleProductPress = () => {
      console.log(
        '🔥 [PRODUCT DETAIL] Related product clicked:',
        item.product_name,
      );

      // Track the clicked product
      clickedRelatedProductIdsRef.current.add(item.product_id);

      // Log analytics event
      logProductDetailRelatedProductClickEvent(
        item,
        fetch_store_product_detail?.product_detail?.product_id,
        index,
        fetch_store_product_detail?.shop_detail || shop_detail,
      );
    };

    return (
      <View style={styles.similarProductCard}>
        <HomeDualCard item={item} color="black" onPress={handleProductPress} />
      </View>
    );
  };

  return (
    <Content ref={scrollRef} contentContainerStyle={styles.mainView}>
      {showErrorScreen(fetch_store_product_detail_error) ? (
        <View style={globalStyle.show_error}>
          <EmptyScreen
            fullWidth={true}
            reload={fetchAPI}
            loader={fetch_store_product_detail_loader}
            message={fetch_store_product_detail_error}
          />
        </View>
      ) : (
        <Container
          barColor={'white'}
          bgColor={'white'}
          isFocused={isFocused}
          dark>
          <View style={styles.container}>
            {imageUrls.length ? (
              <View>
                <ImageSlider
                  brand={shop_detail || fetch_store_product_detail?.shop_detail}
                  images={imageUrls}
                  originalResolution={imageUrlsOriginalSize}
                  key={imageUrls.length}
                  customWidth={width * 0.9}
                  customHeight={defaultHeight}
                  brand_screen={brand_screen}
                  productDetail={true}
                  id={product_id}
                />
              </View>
            ) : (
              <></>
            )}

            {fetch_store_product_detail_loader ? (
              <ProductDetailLoader
                loading={fetch_store_product_detail_loader}
              />
            ) : (
              <View style={styles.content}>
                <View style={styles.productInfo}>
                  {/* <CustomText
                    fontSize={fontScale * 15}
                    fontFamily={font.medium}
                    color="black"
                    text={
                      fetch_store_product_detail?.product_detail?.product_name
                    }
                    style={{width: width * 0.6}}
                  /> */}
                  <View style={{width: width * 0.6}}>
                    <ExpandableText
                      fontSize={fontScale * 15}
                      numberOfLines={2}
                      fontFamily={font.medium}
                      color="black"
                      // htmlContent={htmlContent}
                      text={
                        fetch_store_product_detail?.product_detail?.product_name
                      }
                      removeSeeMore={true}
                    />
                  </View>
                  <View style={styles.iconContainer}>
                    <LCSCard
                      product_id={
                        fetch_store_product_detail?.product_detail?.product_id
                      }
                      iconContainerStyle={{width: width * 0.085}}
                      containerStyle={styles.lcsIcon}
                      dark={true}
                      product_image_url={imageUrls?.[0]}
                      shop_id={
                        fetch_store_product_detail?.product_detail
                          ?.product_shop_id
                      }
                      onPressReview={() => {
                        if (scrollRef?.current && reviewSectionY.current) {
                          scrollRef.current.scrollTo({
                            y: Math.max(reviewSectionY.current + 150, 0), // 👈 50px offset
                            animated: true,
                          });
                        }
                      }}
                    />
                  </View>
                </View>

                <View style={styles.priceContainer}>
                  <View style={styles.row}>
                    <CustomText
                      fontSize={fontScale * 15}
                      fontFamily={font.bold}
                      text={`${
                        shop_detail?.shop_currency ||
                        fetch_store_product_detail?.shop_detail
                          ?.shop_currency ||
                        currency
                      } ${formatPrice(
                        toFixedMethod(
                          showingVaraintPrice(
                            getSelectedVariant()?.variant_price,
                            getSelectedVariant()?.variant_discounted_price,
                          ).discounted_price,
                        ),
                      )} `}
                      style={styles.price}
                    />
                    {getSelectedVariant()?.variant_discounted_price ? (
                      <CustomText
                        fontSize={fontScale * 15}
                        fontFamily={font.bold}
                        color={'#00000080'}
                        text={`${
                          shop_detail?.shop_currency ||
                          fetch_store_product_detail?.shop_detail
                            ?.shop_currency ||
                          currency
                        } ${formatPrice(
                          toFixedMethod(
                            showingVaraintPrice(
                              getSelectedVariant()?.variant_price,
                              getSelectedVariant()?.variant_discounted_price,
                            ).original_price,
                          ),
                        )} `}
                        style={styles.strikethroughPrice}
                      />
                    ) : (
                      <></>
                    )}
                  </View>
                  <BorderLine style={styles.borderLine} />
                  <View style={styles.qtyContainer}>
                    <CustomText
                      fontSize={fontScale * 15}
                      fontFamily={font.bold}
                      color={'black'}
                      text={'Quantity'}
                    />
                    <View style={styles.quantityContainer}>
                      <TouchableOpacity
                        disabled={
                          !getSelectedVariant()?.variant_quantity ||
                          (qty || localQty) == 1
                        }
                        style={[
                          styles.qtyButton,
                          (qty || localQty) == 1 && {opacity: 0.3},
                        ]}
                        onPress={() => {
                          console.log('🔥 [PRODUCT DETAIL] Quantity decreased');

                          // 📊 Analytics: Log quantity decrease
                          logProductDetailActionEvent(
                            'quantity_decrease',
                            fetch_store_product_detail?.product_detail,
                            getSelectedVariant(),
                            (qty || localQty) - 1,
                            fetch_store_product_detail?.shop_detail ||
                              shop_detail,
                          );

                          handleQty(
                            fetch_store_product_detail?.shop_detail?.shop_id,
                            getSelectedVariant()?.variant_id,
                            -1,
                          );
                          triggerHaptic();
                        }}>
                        <Icon
                          icon_type={'AntDesign'}
                          name={'minus'}
                          color={'black'}
                          size={moderateScale(8)}
                        />
                      </TouchableOpacity>

                      <CustomText
                        fontSize={fontScale * 15}
                        fontFamily={font.bold}
                        text={qty || localQty}
                      />

                      {/* ====== UPDATED: Plus button honors MAX_QTY and shows toast ====== */}
                      <TouchableOpacity
                        disabled={
                          !getSelectedVariant()?.variant_quantity ||
                          (qty || localQty) >= MAX_QTY
                        }
                        style={[
                          styles.qtyButton,
                          (variantStock || (qty || localQty) >= MAX_QTY) && {
                            opacity: 0.3,
                          },
                        ]}
                        onPress={() => {
                          if ((qty || localQty) >= MAX_QTY) {
                            showQtyError();
                            return;
                          }

                          console.log('🔥 [PRODUCT DETAIL] Quantity increased');

                          // 📊 Analytics: Log quantity increase
                          logProductDetailActionEvent(
                            'quantity_increase',
                            fetch_store_product_detail?.product_detail,
                            getSelectedVariant(),
                            (qty || localQty) + 1,
                            fetch_store_product_detail?.shop_detail ||
                              shop_detail,
                          );

                          handleQty(
                            fetch_store_product_detail?.shop_detail?.shop_id,
                            getSelectedVariant()?.variant_id,
                            1,
                          );
                          triggerHaptic();
                        }}>
                        <Icon
                          icon_type={'AntDesign'}
                          name={'plus'}
                          color={'black'}
                          size={moderateScale(8)}
                        />
                      </TouchableOpacity>
                    </View>
                  </View>
                </View>
                <BorderLine style={styles.borderLine} />

                <ProductDetailVariants
                  handleValue={handleValue}
                  data={result}
                />

                <View
                  style={{
                    alignItems: 'center',
                    marginTop: height * 0.02,
                  }}>
                  <View style={{width: '96%', marginTop: height * 0.01}}>
                    {/* ====== UPDATED: Add to Cart honors MAX_QTY and shows toast ====== */}
                    <AnimatedAddToCartButton
                      disabled={!getSelectedVariant()?.variant_quantity}
                      buttonStyle={[styles.fullWidthButton]}
                      onPress={() => {
                        const currentQty = qty || localQty || 1;
                        // if (currentQty > MAX_QTY) {
                        //   showQtyError();
                        //   // return;
                        // }
                        const safeQty = Math.min(currentQty, MAX_QTY);

                        console.log('🔥 [PRODUCT DETAIL] Add to Cart clicked');

                        // 📊 Analytics: Log add to cart action
                        logProductDetailActionEvent(
                          'add_to_cart',
                          fetch_store_product_detail?.product_detail,
                          getSelectedVariant(),
                          safeQty,
                          fetch_store_product_detail?.shop_detail ||
                            shop_detail,
                        );

                        dispatch(
                          _addToCart(
                            fetch_store_product_detail?.shop_detail?.shop_id,
                            getSelectedVariant()?.variant_id,
                            safeQty,
                          ),
                        );
                        triggerHaptic();
                      }}
                      text={
                        !getSelectedVariant()?.variant_quantity
                          ? 'Out Of Stock'
                          : 'Add To Cart'
                      }
                      ImageComponentPress={deleteProduct}
                      ImageComponentSize={width * 0.04}
                      imageComponentStyle={{
                        backgroundColor: 'black',
                        padding: width * 0.01,
                        borderRadius: 180,
                        left: '4%',
                      }}
                      loaderSize={'small'}
                      loader={syncingCart}
                      fontSize={fontScale * 14}
                    />
                  </View>

                  <View style={{width: '96%', marginTop: height * 0.01}}>
                    <CustomButton
                      disabled={!getSelectedVariant()?.variant_quantity}
                      buttonStyle={[
                        styles.fullWidthButton,
                        {backgroundColor: '#353535'},
                      ]}
                      onPress={handleBuyNowWithAnalytics}
                      loader={checkOutLoader}
                      text={
                        !getSelectedVariant()?.variant_quantity
                          ? 'Out Of Stock'
                          : 'Buy Now'
                      }
                      loaderSize={'small'}
                      fontSize={fontScale * 14}
                    />
                  </View>
                </View>

                <View style={{marginTop: height * 0.03}}>
                  <CustomText
                    fontSize={fontScale * 17}
                    fontFamily={font.bold}
                    color="black"
                    text={'Description'}
                  />
                  <ExpandableText
                    fontSize={fontScale * 15}
                    numberOfLines={2}
                    fontFamily={font.regular}
                    marginTop={height * 0.01}
                    color="black"
                    htmlContent={htmlContent}
                    text={
                      fetch_store_product_detail?.product_detail
                        ?.product_description
                    }
                  />
                </View>

                <TouchableOpacity
                  onPress={() =>
                    brand_screen
                      ? goBack()
                      : navigate('Brand', {
                          shop_id:
                            fetch_store_product_detail?.shop_detail?.shop_id,
                          shop: fetch_store_product_detail?.shop_detail,
                        })
                  }
                  style={{
                    marginTop: height * 0.02,
                    flexDirection: 'row',
                    alignItems: 'center',
                  }}>
                  <CustomText
                    fontSize={fontScale * 17}
                    fontFamily={font.bold}
                    color="black"
                    text={`More From ${fetch_store_product_detail?.shop_detail?.shop_name}`}
                  />
                  <View
                    style={{
                      width: width * 0.05,
                      aspectRatio: 1,
                      backgroundColor: '#D9D9D9',
                      borderRadius: 180,
                      justifyContent: 'center',
                      alignItems: 'center',
                      marginLeft: width * 0.03,
                      marginTop: height * 0.006,
                    }}>
                    <Icon
                      icon_type="MaterialCommunityIcons"
                      name="chevron-right"
                      color="black"
                      size={fontScale * 17}
                    />
                  </View>
                </TouchableOpacity>

                <FlatList
                  data={fetch_store_products || []}
                  renderItem={renderSimilarProductsWithAnalytics}
                  keyExtractor={(item, index) => index.toString()}
                  showsHorizontalScrollIndicator={false}
                  contentContainerStyle={styles.similarProductsList}
                  numColumns={2}
                />

                <View
                  ref={reviewSectionRef}
                  onLayout={event => {
                    reviewSectionY.current = event.nativeEvent.layout.y;
                  }}>
                  <ProductDetailReViewWithChart
                    product_id={product_id}
                    productDetailReview={productDetailReview}
                  />
                </View>

                {relatedProductLoader ? <SearchedItemsLoader /> : <></>}

                {relatedProducts?.length > 0 && (
                  <View style={{marginTop: height * 0.03}}>
                    <CustomText
                      fontSize={fontScale * 17}
                      fontFamily={font.bold}
                      color="black"
                      text={`Related to ${fetch_store_product_detail?.shop_detail?.shop_name}`}
                    />
                    <FlatList
                      data={relatedProducts || []}
                      renderItem={renderRelatedProductsWithAnalytics}
                      keyExtractor={(item, index) => index.toString()}
                      showsHorizontalScrollIndicator={false}
                      contentContainerStyle={styles.similarProductsList}
                      numColumns={2}
                    />
                  </View>
                )}
              </View>
            )}
          </View>
        </Container>
      )}
    </Content>
  );
};

export default ProductDetail;

const styles = StyleSheet.create({
  mainView: {
    backgroundColor: '#fff',
    paddingBottom: globalStyle.bottomSpace.marginBottom,
  },
  container: {
    flex: 1,
  },
  content: {
    marginHorizontal: margin.horizontal,
  },
  productInfo: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: -5,
  },
  iconContainer: {
    width: width * 0.31,
    alignItems: 'flex-end',
  },
  lcsIcon: {
    bottom: 0,
    position: 'relative',
  },
  ratingContainer: {
    marginTop: height * 0.01,
    ...globalStyle.row,
  },
  ratingValue: {
    marginRight: width * 0.02,
  },
  priceContainer: {
    marginTop: height * 0.01,
  },
  row: {
    ...globalStyle.row,
  },
  price: {
    marginRight: width * 0.02,
  },
  strikethroughPrice: {
    textDecorationLine: 'line-through',
    opacity: 0.8,
  },
  qtyContainer: {
    ...globalStyle.space_between,
    marginTop: height * 0.02,
  },
  qtyButton: {
    borderRadius: 5,
    width: width * 0.065,
    aspectRatio: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#E5EBFC',
  },
  borderLine: {
    marginLeft: 0,
    width: '100%',
    justifyContent: 'center',
    alignItems: 'center',
    height: verticalScale(1),
    marginTop: height * 0.02,
  },
  similarProductsList: {
    marginTop: verticalScale(15),
  },
  productRating: {
    marginTop: verticalScale(5),
  },
  ratingText: {
    marginLeft: 5,
  },
  soldText: {
    marginLeft: 5,
  },
  description: {
    marginTop: verticalScale(10),
    marginLeft: 5,
  },
  fullWidthButton: {
    width: '100%',
    fontFamily: font.medium,
    backgroundColor: colors.light_theme.theme,
    borderRadius: 180,
    height: height * 0.054,
  },
  cartContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  checkoutButtonWrapper: {
    width: '55%',
  },
  cartActions: {
    ...globalStyle.space_between,
    width: '30%',
  },
  similarProductsHeader: {
    marginTop: verticalScale(15),
    ...globalStyle.space_between,
  },
  quantityContainer: {
    ...globalStyle.row,
    width: '30%',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
});
