import React, {useCallback, useEffect, useMemo, useRef, useState} from 'react';
import useReduxStore from '@utils/hooks/useReduxStore';
import {Animated} from 'react-native';
import {_recentViewed, _getRecentViewedList} from '@redux/actions/user/user';
import ShopTile from '@component/cards/shopTile/shopTile';
import {pagination} from '@utils/helper/helper';
import {_storeNotificationToken} from '@redux/actions/auth/auth';
import {useIsFocused, useFocusEffect} from '@react-navigation/native';
import {
  _getTrendingCollection,
  _getStores,
} from '@redux/actions/merchant/merchant';
import {
  _getMaintenanceStatus,
  _resetVideoIndexes,
  _setVideoIndexes,
  _focusHomeTab,
} from '@redux/actions/common/common';
import useNetworkSpeed from '@hooks/useNetworkSpeed';

const AnimatedShopTile = React.memo(
  ({item, index, logShopTileView, logShopTileViewEnd, markShopAsClicked}) => {
    const progress = useRef(new Animated.Value(0)).current;

    useEffect(() => {
      Animated.spring(progress, {
        toValue: 1,
        useNativeDriver: true,
        damping: 12,
        stiffness: 150,
        mass: 0.7,
        delay: Math.min(index, 10) * 70,
      }).start();
    }, [progress, index]);

    const translateY = progress.interpolate({
      inputRange: [0, 1],
      outputRange: [14, 0],
    });

    const scale = progress.interpolate({
      inputRange: [0, 1],
      outputRange: [0.96, 1],
    });

    return (
      <Animated.View
        style={{
          opacity: progress,
          transform: [{translateY}, {scale}],
        }}>
        <ShopTile
          item={item}
          index={index}
          logShopTileView={logShopTileView}
          logShopTileViewEnd={logShopTileViewEnd}
          markShopAsClicked={markShopAsClicked}
        />
      </Animated.View>
    );
  },
);

const useHome = ({navigation}) => {
  const {dispatch, getState} = useReduxStore();
  const {pageSize, speedCategory} = useNetworkSpeed();
  const {fetch_store, fetch_store_loader, trending_collection_loader} =
    getState('merchant');
  const {
    fetch_recent_viewed,
    fetch_recent_viewed_locally,
    selected_categories,
  } = getState('user');
  const {fetch_user_detail, token} = getState('auth');

  const {activeVideoIndex, homeScrollPosition} = getState('common');
  const [scrollY, setScrollY] = useState(new Animated.Value(0));
  const [search, setSearch] = useState('');
  const [pullLoader, setPullLoader] = useState(false);
  const [shops, setShops] = useState([]);
  const [paginationLoader, setPaginationLoader] = useState(false);
  const [page, setPage] = useState(1);
  const lastActiveIndexRef = useRef(null);
  const listRef = useRef(null);
  const isFocused = useIsFocused();

  const fetchAPI = async isLoading => {
    !isLoading && setPullLoader(true);
    !isLoading && setPage(1);
    await dispatch(
      _getStores({
        page: 1,
        user_id: fetch_user_detail?.id,
        pull: !isLoading,
        categories: selected_categories.toString(),
        pageSize: pageSize,
      }),
      dispatch(_resetVideoIndexes()),
    );
    setPullLoader(false);
  };

  const multipleRecentViewedPushed = async () => {
    await Promise.all(
      (fetch_recent_viewed_locally || [])
        .reverse()
        .map(
          item =>
            !item.user_id &&
            dispatch(
              _recentViewed(
                fetch_user_detail?.id,
                item.recent_view_type,
                item.recent_view_shop_id,
                item.recent_view_product_id,
              ),
            ),
        ),
    );
  };

  const processRecentViews = async () => {
    if (fetch_recent_viewed_locally.length && fetch_user_detail?.id) {
      await multipleRecentViewedPushed();
    }
    dispatch(
      _getRecentViewedList(
        fetch_user_detail?.id || '',
        fetch_user_detail?.id ? '' : fetch_recent_viewed_locally,
      ),
    );
  };

  useFocusEffect(
    useCallback(() => {
      processRecentViews();
      dispatch(_getMaintenanceStatus());
    }, [fetch_user_detail, fetch_recent_viewed_locally]),
  );

  const renderItem = useCallback(
    ({item, index, logShopTileView, logShopTileViewEnd, markShopAsClicked}) => (
      <AnimatedShopTile
        key={`shop_tile_${index}`}
        item={item}
        index={index}
        logShopTileView={logShopTileView}
        logShopTileViewEnd={logShopTileViewEnd}
        markShopAsClicked={markShopAsClicked}
      />
    ),
    [],
  );

  const paginationAPI = async () => {
    if (!paginationLoader && !fetch_store_loader) {
      const totalPages = fetch_store?.pagination?.totalPages;
      const nextPagination = pagination(page, totalPages);
      if (nextPagination && !paginationLoader) {
        setPaginationLoader(true);
        const response = await dispatch(
          _getStores({
            page: nextPagination,
            user_id: fetch_user_detail?.id,
            categories: selected_categories.toString(),
            pageSize: pageSize,
          }),
        );
        setPage(nextPagination);
        if (response) {
          setPaginationLoader(false);
          if (
            response?.pagination?.totalPages ==
            response?.pagination?.currentPage
          ) {
            setPage(1);
          }
        } else {
          setPaginationLoader(false);
        }
      }
    }
  };

  useFocusEffect(
    useCallback(() => {
      dispatch(_focusHomeTab(true));
      return () => {
        dispatch(_focusHomeTab(false));
      };
    }, [dispatch]),
  );

  useEffect(() => {
    dispatch(_getTrendingCollection());
  }, []);

  const flatListRef = useRef(null);

  const storesData = useMemo(
    () => fetch_store?.shops ?? [],
    [fetch_store.shops],
  );

  const lastUpdateTimeRef = useRef(0);
  const UPDATE_DELAY = 100;
  const viewabilityConfigRef = useRef({
    viewAreaCoveragePercentThreshold: 60,
  });

  const handleViewableItemsChanged = ({viewableItems}) => {
    const now = Date.now();
    if (now - lastUpdateTimeRef.current < UPDATE_DELAY) return;
    if (!isFocused) return;
    const visibleItem = viewableItems.find(
      v => v.item?.shop_id || v.item?.shop?.shop_id,
    );
    if (visibleItem) {
      lastUpdateTimeRef.current = now;
      lastActiveIndexRef.current = visibleItem.index;
      dispatch(
        _setVideoIndexes({
          index: visibleItem.index,
          activeIndex: visibleItem.index,
        }),
      );
    }
  };

  useEffect(() => {
    if (!isFocused) {
      lastActiveIndexRef.current = activeVideoIndex;
      dispatch(
        _setVideoIndexes({
          index: null,
          activeIndex: null,
        }),
      );
    } else {
      if (lastActiveIndexRef.current !== null) {
        dispatch(
          _setVideoIndexes({
            index: lastActiveIndexRef.current,
            activeIndex: lastActiveIndexRef.current,
          }),
        );
      }
    }
  }, [isFocused]);

  useEffect(() => {
    if (isFocused && homeScrollPosition) {
      listRef.current?.scrollToOffset({
        offset: 0,
        animated: true,
      });
    }
  }, [isFocused, homeScrollPosition]);

  const whiteBackground = fetch_user_detail?.email == 'Ben.ten550@gmail.com';

  return {
    fetch_recent_viewed,
    fetch_store_loader,
    fetch_store,
    pullLoader,
    scrollY,
    search,
    fetchAPI,
    renderItem,
    setSearch,
    paginationAPI,
    paginationLoader,
    fetch_user_detail,
    shops,
    token,
    storesData,
    flatListRef,
    trending_collection_loader,
    handleViewableItemsChanged,
    viewabilityConfigRef,
    isFocused,
    listRef,
    speedCategory,
    pageSize,
    fetch_user_detail,
    whiteBackground,
  };
};

export default useHome;
