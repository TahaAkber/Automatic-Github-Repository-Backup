import {useRef, useEffect, useCallback} from 'react';
import {useIsFocused} from '@react-navigation/native';
import {
  logHomeShopTileViewEvent,
  logHomeSkippedItemsEvent,
} from '../../../helper/eventTriggers/useEventTriggers';

/**
 * Custom hook to track home page analytics
 * Tracks shop tile views, time spent, and skipped items
 */
const useHomeAnalytics = storesData => {
  const isFocused = useIsFocused();

  // Track viewed and clicked shop IDs
  const viewedShopIdsRef = useRef(new Set());
  const clickedShopIdsRef = useRef(new Set());

  // Track view start times for each shop tile
  const shopViewTimesRef = useRef({});

  // Track all displayed shops
  const displayedShopsRef = useRef([]);

  // Update displayed shops when storesData changes
  useEffect(() => {
    if (storesData && storesData.length > 0) {
      displayedShopsRef.current = storesData;

    }
  }, [storesData]);

  /**
   * Log shop tile view when it becomes visible
   */
  const logShopTileView = useCallback((shopItem, tilePosition) => {
    if (!shopItem || !shopItem.shop_id) return;

    const shopId = shopItem.shop_id;

    // Start tracking view time
    shopViewTimesRef.current[shopId] = Date.now();

    // Mark as viewed
    viewedShopIdsRef.current.add(shopId);

  }, []);

  /**
   * Log shop tile view end when it becomes invisible
   */
  const logShopTileViewEnd = useCallback(async (shopItem, tilePosition) => {
    if (!shopItem || !shopItem.shop_id) return;

    const shopId = shopItem.shop_id;
    const startTime = shopViewTimesRef.current[shopId];

    if (startTime) {
      const viewDuration = (Date.now() - startTime) / 1000;

      // Only log if viewed for at least 0.5 seconds
      if (viewDuration >= 0.5) {
        await logHomeShopTileViewEvent(shopItem, tilePosition, viewDuration);
      }

      // Clean up
      delete shopViewTimesRef.current[shopId];
    }
  }, []);

  /**
   * Mark a shop as clicked
   */
  const markShopAsClicked = useCallback((shopId) => {
    if (shopId) {
      clickedShopIdsRef.current.add(shopId);
    }
  }, []);

  /**
   * Log skipped items when user leaves home page
   */
  const logSkippedItems = useCallback(async () => {
    const displayedShops = displayedShopsRef.current;
    const viewedShopIds = Array.from(viewedShopIdsRef.current);
    const clickedShopIds = Array.from(clickedShopIdsRef.current);

    if (displayedShops.length > 0) {
  

      await logHomeSkippedItemsEvent(
        displayedShops,
        viewedShopIds,
        clickedShopIds,
      );
    }
  }, []);

  /**
   * Reset analytics data
   */
  const resetAnalytics = useCallback(() => {
    viewedShopIdsRef.current.clear();
    clickedShopIdsRef.current.clear();
    shopViewTimesRef.current = {};

  }, []);

  /**
   * Handle screen focus/blur
   */
  useEffect(() => {
    if (!isFocused) {
      // User left home page, log skipped items
      logSkippedItems();
    } else {
      // User returned to home page, reset analytics
      resetAnalytics();
    }
  }, [isFocused, logSkippedItems, resetAnalytics]);

  return {
    logShopTileView,
    logShopTileViewEnd,
    markShopAsClicked,
    logSkippedItems,
    resetAnalytics,
  };
};

export default useHomeAnalytics;
