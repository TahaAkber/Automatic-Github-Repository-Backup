import React, {useEffect, useRef} from 'react';
import {
  StyleSheet,
  View,
  Image,
  TouchableOpacity,
  Animated,
} from 'react-native';
import Robot from '../../../assets/images/hirobo.png';
import CercleThump from '@assets/images/cercle-thumb.svg';
import CustomText from '../../../materialComponent/customText/customText';
import {colors, font} from '../../../constant/contstant';
import {moderateScale} from 'react-native-size-matters';
import CustomImage from '../../../materialComponent/image/image';

const suggestions = [
  'Show me smartphones under Rs.30000',
  'I need comfortable running shoes for men',
  'Gift ideas for a 25-year-old female',
  'Find me a hydrating face cream for oily skin',
  // 'What’s trending in snacks this week?',
];

const ChatSuggestion = ({onSuggestionPress}) => {
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(20)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 500,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 500,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  return (
    <Animated.View
      style={[
        styles.container,
        {
          opacity: fadeAnim,
          transform: [{translateY: slideAnim}],
        },
      ]}>
      <CustomImage
        size={moderateScale(5)}
        source={Robot}
        style={styles.bannerImage}
        resizeMode="contain"
      />

      <View style={styles.bubble}>
        <CercleThump style={styles.logo} />
        <CustomText
          fontSize={16}
          style={styles.text}
          fontFamily={font.regular}
          text={'Hi, you can ask me anything'}
        />
      </View>

      <View style={styles.suggestionWrapper}>
        {suggestions.map((item, index) => (
          <TouchableOpacity
            key={index}
            style={styles.suggestionChip}
            onPress={() => onSuggestionPress?.(item)}>
            <CustomText
              color={'black'}
              style={styles.suggestionText}
              text={item}
            />
          </TouchableOpacity>
        ))}
      </View>
    </Animated.View>
  );
};

export default ChatSuggestion;

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    marginTop: moderateScale(20),
    paddingHorizontal: moderateScale(10),
  },
  bannerImage: {
    width: moderateScale(150),
    height: moderateScale(150),
  },
  bubble: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#EFEFEF',
    borderRadius: 20,
    paddingHorizontal: moderateScale(15),
    paddingVertical: moderateScale(12),
    marginTop: moderateScale(10),
    maxWidth: '90%',
  },
  logo: {
    width: 20,
    height: 20,
    marginRight: 10,
    resizeMode: 'contain',
  },
  text: {
    fontWeight: '600',
    color: '#444',
    flex: 1,
  },
  suggestionWrapper: {
    marginTop: moderateScale(15),
    width: '100%',
    alignItems: 'center',
    gap: moderateScale(10),
    marginLeft: moderateScale(35),
  },
  suggestionChip: {
    borderWidth: 1,
    borderColor: colors.light_theme.theme,
    borderRadius: 20,
    paddingVertical: moderateScale(10),
    paddingHorizontal: moderateScale(14),
    alignSelf: 'flex-start',
    maxWidth: '94%',
  },
  suggestionText: {
    color: '#0B57D0',
    fontSize: 14,
    fontFamily: font.regular,
  },
});
