import { moderateScale } from 'react-native-size-matters';
import { Dimensions, FlatList, StatusBar, StyleSheet, View } from 'react-native';
import React from 'react';
import InnerHeader from '@component/header/innerHeader';
import { margin } from '@constant/contstant';
import Stories from '@component/cards/stories/stories';
import SearchInput from '@component/input/searchInput';
import BrandTab from '@component/brandTab/brandTab';
import CustomImage from '../../../materialComponent/image/image';
import CustomText from '../../../materialComponent/customText/customText';
import { colors, font } from '../../../constant/contstant';
import InboxCard from '../../../component/cards/inboxCard/inboxCard';
import EmptyScreen from '../../../component/emptyScreen/emptyScreen';

const { width, height, fontScale } = Dimensions.get("screen");

const Inbox = () => {

    const renderInbox = ({ item, index }) => (

        <InboxCard key={index} item={item} index={index} />

    );

    return (
        <View style={styles.container}>
            <StatusBar animated barStyle={"dark-content"} backgroundColor={"white"} translucent={false} />
            <InnerHeader notification={true} setting={true} title={"Inbox"} />
            <View style={{ justifyContent: "center", alignItems: "center", flex: 1,  marginTop: height * -0.1 }}>
                <EmptyScreen
                    image={"empty_messages"}
                    heading={"No Messages Yet!"}
                    desc={"Your inbox is empty. Start shopping or reach out for support, and your messages will appear here!"}
                />
            </View>
            {/* <View style={[styles.horizontal, { marginTop: height * 0.02 }]}>
                <SearchInput placeholder={"Search Your Store Here..."} />
                <View style={{ marginTop: height * 0.015 }}>
                    <Stories heading={"Stories"} />
                </View>
            </View>

            <View style={{ marginTop: height * 0.03 }}>
                <View>
                    <FlatList
                        scrollEnabled={true}
                        // data={messages}
                        data={[]}
                        renderItem={renderInbox}
                        keyExtractor={(item, index) => index.toString()}
                        showsHorizontalScrollIndicator={false}
                        contentContainerStyle={styles.shopsList}
                    />
                </View>
            </View> */}
        </View>
    );
};

export default Inbox;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: "white",
    },
    horizontal: {
        marginHorizontal: margin.horizontal,
    },
    contentContainer: {
        marginRight: moderateScale(10),
    },
    image: {
        width: moderateScale(80),
        height: moderateScale(80),
        borderRadius: moderateScale(10),
    },
    shopsList: {
        paddingBottom: height * 0.4,
        // paddingHorizontal: margin.horizontal
    },
});


const messages = [
    {
        shopName: "Outtfitter",
        lastMessage: "Product is available?",
        unread: 3,
        time: "2 min ago"
    },
    {
        shopName: "Ndure",
        lastMessage: "Product is available?",
        unread: 3,
        time: "2 min ago"
    },
    {
        shopName: "Outtfitter",
        lastMessage: "Product is available?",
        unread: 3,
        time: "2 min ago"
    },
    {
        shopName: "Outtfitter",
        lastMessage: "Product is available?",
        unread: 3,
        time: "2 min ago"
    },
    {
        shopName: "Outtfitter",
        lastMessage: "Product is available?",
        unread: 3,
        time: "2 min ago"
    },
    {
        shopName: "Ndure",
        lastMessage: "Product is available?",
        unread: 3,
        time: "2 min ago"
    },
    {
        shopName: "Outtfitter",
        lastMessage: "Product is available?",
        unread: 3,
        time: "2 min ago"
    },
    {
        shopName: "Outtfitter",
        lastMessage: "Product is available?",
        unread: 3,
        time: "2 min ago"
    },

]