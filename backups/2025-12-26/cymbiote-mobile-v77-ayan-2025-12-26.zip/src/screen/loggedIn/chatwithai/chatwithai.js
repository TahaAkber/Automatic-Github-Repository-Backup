import {
  Dimensions,
  StatusBar,
  StyleSheet,
  TouchableOpacity,
  View,
} from 'react-native';
import {moderateScale, verticalScale} from 'react-native-size-matters';
import {colors, font, globalStyle, margin} from '../../../constant/contstant';
import CustomText from '../../../materialComponent/customText/customText';
import Icon from '../../../materialComponent/icon/icon';
import CercleThump from '@assets/images/cercle-thumb.svg';
import {useEffect, useState, useRef} from 'react';
import LinearGradient from 'react-native-linear-gradient';
import ChatUI from '../../../component/ChatwithAI/chatUi';
import {_chatWithAI, resetChatData} from '../../../redux/actions/chatai/chatai';
import useReduxStore from '../../../utils/hooks/useReduxStore';
import ChatSuggestion from './chatSuggestion';
import Container from '../../../materialComponent/container/container';

const {width, height, fontScale} = Dimensions.get('screen');

const Chatwithai = ({route, navigation}) => {
  const {getState, dispatch} = useReduxStore();
  const {data, chatHistory} = getState('chatAi');
  const [keyboardVisible, setKeyboardVisible] = useState(false);
  const searchQuery = route?.params?.searchQuery;

  const [messages, setMessages] = useState([]);
  const [resetting, setResetting] = useState(false);
  const hasAutoSentQuery = useRef(false);
  const getMessages = async (vendorId, customerId) => {
    try {
      return vendorId;
    } catch (error) {
      console.error('Error fetching messages: ', error);
    }
  };

  const handleSendMessage = async message => {
    if (typeof message !== 'string' || !message.trim()) {
      console.warn('Attempted to send an invalid text message:', message);
      return;
    }

    // setMessages(prev => [userMessage, ...prev]);

    // 4. Hit AI API
    await dispatch(_chatWithAI(message));
    // 5. Create AI message

    // 7. Update UI
    // setMessages(prev => [data, ...prev]);
  };
  const handleReset = async () => {
    setResetting(true);

    await dispatch(resetChatData());
    setResetting(false);
  };

  useEffect(() => {
    // Only trigger on initial load
    // const {data} = getState('chatAi');
    if (!data?.session_id) {
      dispatch(_chatWithAI(''));
    }
  }, [data]);

  useEffect(() => {
    // Automatically send search query when screen loads with a query (only once)
    if (searchQuery && data?.session_id && !hasAutoSentQuery.current) {
      hasAutoSentQuery.current = true;
      handleSendMessage(searchQuery);
    }
  }, [searchQuery, data?.session_id]);
  return (
    <Container barColor={'white'}>
      <View style={styles.container}>
        <View style={styles.header}>
          <View style={globalStyle.row}>
            <TouchableOpacity
              onPress={() => {
                navigation.goBack();
              }}>
              <Icon
                icon_type={'AntDesign'}
                name={'arrowleft'}
                color={'black'}
                size={24}
                style={{
                  marginTop: verticalScale(9),
                }}
              />
            </TouchableOpacity>
            <View style={styles.titleContainer}>
              <View
                style={[styles.searchListItem, {paddingTop: height * 0.01}]}>
                <LinearGradient
                  colors={[
                    '#00CE83',
                    '#1A97CD',
                    '#FF7F00',
                    '#ED1D1D',
                    '#6966CD',
                  ]} // Gradient colors for the border
                  start={{x: 0, y: 0}} // Gradient direction
                  end={{x: 1, y: 1}} // Gradient direction
                  style={[styles.imageView]} // Gradient border applied here
                >
                  <View style={styles.iconWrapper}>
                    <CercleThump
                      width={moderateScale(16)}
                      height={moderateScale(16)}
                    />
                  </View>
                </LinearGradient>
                <CustomText
                  fontSize={moderateScale(14)}
                  fontFamily={font.medium}
                  text={'Search with cercle AI'}
                />
              </View>
            </View>{' '}
          </View>

          <TouchableOpacity onPress={handleReset}>
            {resetting ? (
              <Icon
                icon_type="Feather"
                name="loader"
                color="black"
                size={24}
                style={{
                  // marginRight: margin.horizontal,
                  transform: [{rotate: '90deg'}],
                }} // Optional rotation
              />
            ) : (
              <Icon
                icon_type="MaterialIcons"
                name="refresh"
                color="black"
                size={24}
                // style={{marginRight: margin.horizontal}}
              />
            )}
          </TouchableOpacity>
        </View>

        <View style={styles.borderLine} />
        {!keyboardVisible && chatHistory.length <= 1 && (
          <ChatSuggestion onSuggestionPress={handleSendMessage} />
        )}

        <View style={styles.borderLine} />
        <ChatUI
          // messages={messages}
          onKeyboardToggle={setKeyboardVisible}
          onSendMessage={handleSendMessage}
          // name={name}
          messages={chatHistory} // ✅ from Redux now
          products={data?.products}
        />
      </View>
    </Container>
  );
};

export default Chatwithai;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
  },
  header: {
    paddingTop: verticalScale(5),
    marginBottom: height * 0.01,
    paddingHorizontal: margin.horizontal,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  image: {
    width: '21%',
    aspectRatio: 1,
    marginRight: '3%',
    borderRadius: 180,
  },
  borderLine: {
    marginLeft: 0,
    width: '95%',
    backgroundColor: '#00000033',
    height: height * 0.003,
    alignSelf: 'center',
    opacity: 0.3,
    height: '0.2%',
  },
  nameView: {
    marginLeft: '1%',
  },
  searchListItem: {
    ...globalStyle.row,
  },
  imageView: {
    width: moderateScale(40),
    height: moderateScale(40),
    backgroundColor: '#F2F2F2',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 180,
    marginRight: moderateScale(10),
    borderColor: colors.light_theme.darkBorderColor,
    borderWidth: 1,
  },
  iconWrapper: {
    backgroundColor: 'white',
    borderRadius: 180,
    padding: moderateScale(10),
  },
  titleContainer: {
    marginLeft: 10,
  },
});
