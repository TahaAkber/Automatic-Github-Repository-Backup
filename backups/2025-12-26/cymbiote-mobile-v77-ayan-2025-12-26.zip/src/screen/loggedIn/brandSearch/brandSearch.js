import React, {useEffect} from 'react';
import {
  StyleSheet,
  View,
  StatusBar,
  FlatList,
  Alert,
  ActivityIndicator,
  Dimensions,
  RefreshControl,
} from 'react-native';
import {colors, globalStyle, margin, WH} from '@constant/contstant';
import {SafeAreaView} from 'react-native-safe-area-context';
import HomeFilter from '@component/homeFilter/homeFilter';
import {dashboardFilters} from '@constant/dummyData';
import useBrandSearch from './useBrandSearch';
import SearchInput from '@component/input/searchInput';
import {dashboardCollections, homeData} from '@constant/dummyData';
import CustomText from '@materialComponent/customText/customText';
import ImageSlider from '@component/imageCarousel/imageCarousel';
import Content from '../../../materialComponent/content/content';
import SearchedItemsLoader from '../../../component/loader/searchedItemsLoader';
import BrandLoader from '../../../component/loader/brandLoader';
import EmptyScreen from '../../../component/emptyScreen/emptyScreen';
import PagionationLoader from '../../../component/loader/endReachLoader';

const {width, height, fontScale} = Dimensions.get('screen');

const BrandSearch = ({disabled, route}) => {
  const shop_id = route?.params?.shop_id;
  const {
    renderProduct,
    isCollection,
    images,
    brandProducts,
    value,
    handleSearch,
    _handleBlur,
    searchLoader,
    isKeyboardVisible,
    localData,
    fetchAPI,
    brand_search_products_loader,
    paginationAPI,
    paginationLoader,
    products,
    collectionProducts,
    selectedCollectionId,
    collectionLoading,
    handleSelectCollection,
    pullLoader,
    setProducts,
    brand_search_products,
    initialLoading,
    setPage,
  } = useBrandSearch({route});
  useEffect(() => {
    setProducts([]);
    setPage(1);
    fetchAPI(true); // fetch page 1 only
  }, [shop_id]);

  // const productCount = value
  //   ? localData?.products?.length || 0
  //   : products?.length || 0;

  const productCount =
    brand_search_products?.pagination?.totalProductCount || 0;
  const noProductsFound = value
    ? localData?.products?.length
    : products?.length;
  return (
    <SafeAreaView
      style={{
        flex: 1,
        backgroundColor: 'white',
        paddingHorizontal: margin.horizontal,
        paddingTop: height * 0.02,
      }}>
      <StatusBar
        animated
        barStyle="dark-content"
        backgroundColor="white"
        translucent={false}
      />
      <SearchInput
        placeholder={`Search from ${route?.params?.brandName || 'brand'}`}
        value={value}
        onChangeText={handleSearch}
        onBlur={_handleBlur}
      />
      {/* {!searchLoader && !products?.length ? (
        <View
          style={{
            justifyContent: 'center',
            alignItems: 'center',
            marginVertical: height * 0.1,
          }}>
          <BrandLoader loading={true} />
        </View>
      ) : null} */}
      {searchLoader && (
        <View
          style={{
            justifyContent: 'center',
            alignItems: 'center',
            // marginVertical: height * 0.1,
          }}>
          <SearchedItemsLoader />
        </View>
      )}
      {/* <View style={{ marginBottom: height * 0.02 }}>
        <HomeFilter  collection={dashboardCollections} marginTop={height * 0.02} data={dashboardFilters} />
      </View> */}

      {!noProductsFound ? (
        <View
          style={{
            flex: 1,
            justifyContent: 'center',
            alignItems: 'center',
          }}>
          <EmptyScreen
            image={'empty_search'}
            heading={'We couldn’t find a match'}
            desc={'Try another keyword or search in'}
          />
        </View>
      ) : (
        <>
          {/* Display product count */}
          {!isCollection ? (
            <CustomText
              fontSize={fontScale * 13}
              color={'#959595'}
              marginTop={height * 0.0}
              center
              style={{paddingVertical: height * 0.02}}
              text={`${productCount} results from ${
                route?.params?.brandName || ''
              }`}
            />
          ) : null}

          <Content>
            {/* {isCollection ? (
              <ImageSlider
                style={{ marginVertical: 0, marginTop: height * 0.0 }}
                customHeight={height * 0.2}
                customWidth={width * 0.9}
              brand={false}
                images={images || []}
              />
            ) : null} */}
            {initialLoading ? (
              <SearchedItemsLoader /> // your existing skeleton component
            ) : (
              <View style={{marginTop: height * 0.0, flex: 1}}>
                <FlatList
                  // scrollEnabled={true}
                  // data={value ? localData?.products || [] : brandProducts || []}
                  //  data={brand_search_products?.data?.products || []}
                  data={value ? localData?.products : products}
                  // data={value ? localData?.products || [] : products}
                  renderItem={renderProduct}
                  keyExtractor={(item, index) => `product_${item.id || index}`}
                  showsHorizontalScrollIndicator={false}
                  numColumns={2}
                  contentContainerStyle={styles.flatListContainerWithoutImage}
                  ListFooterComponent={
                    // Only show pagination loader when not searching
                    !value && paginationLoader ? (
                      <PagionationLoader />
                    ) : (
                      <View style={{height: height * 0.05}} />
                    )
                  }
                  onEndReached={paginationAPI}
                  onEndReachedThreshold={0.5}
                  refreshControl={
                    <RefreshControl
                      refreshing={pullLoader}
                      onRefresh={fetchAPI}
                    />
                  }
                />
              </View>
            )}
          </Content>
        </>
      )}
    </SafeAreaView>
  );
};

export default BrandSearch;

const styles = StyleSheet.create({
  flatListContainerWithoutImage: {
    paddingBottom: height * 0.1,
  },
});
