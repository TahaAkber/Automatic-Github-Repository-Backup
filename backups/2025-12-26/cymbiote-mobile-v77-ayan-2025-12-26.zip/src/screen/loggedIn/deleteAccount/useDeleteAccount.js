import {_getStores} from '@redux/actions/merchant/merchant';
import {_globalLoader} from '@redux/actions/common/common';
import useReduxStore from '@utils/hooks/useReduxStore';
import {_login} from '@redux/actions/auth/auth';
import {CommonActions, useNavigation} from '@react-navigation/native';
import {useRef, useState} from 'react';
import {_deleteUser} from '../../../redux/actions/user/user';
import {navigate} from '../../../utils/navigationRef/navigationRef';

const useDeleteAccount = ({}) => {
  const {getState, dispatch} = useReduxStore();
  const {fetch_user_detail, token} = getState('auth');
  const navigation = useNavigation();
  const refRBSheet = useRef();

  const [loader, setLoader] = useState(false);

  const _handleDeleteAccount = async () => {
    setLoader(true);
    const response = await dispatch(_deleteUser());
    navigation.pop(2);
    setLoader(false);
  };

  return {
    fetch_user_detail,
    token,
    navigation,
    refRBSheet,
    loader,
    _handleDeleteAccount,
  };
};

export default useDeleteAccount;
