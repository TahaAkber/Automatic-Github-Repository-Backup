import React, {useState, useRef, useCallback, useEffect, useMemo} from 'react';
import {Dimensions, View, Animated, LayoutAnimation} from 'react-native';
import VariantCard from '@component/cards/variantCard/variantCard';
import useReduxStore from '@utils/hooks/useReduxStore';
import {font, WH} from '../../../constant/contstant';
import HomeDualCard from '../../../component/cards/homeDualCard';
import {_fetchSearchedList} from '../../../redux/actions/common/common';
import {_getLatestOrderDetail} from '../../../redux/actions/orders/orders';

const {height, width, fontScale} = Dimensions.get('screen');

const useThankYou = ({data, order_email}) => {
  const {getState, dispatch} = useReduxStore();
  const {fetch_user_detail} = getState('auth');
  const {fetch_address} = getState('user');
  const {fetch_internal_order} = getState('order');
  const [expanded, setExpanded] = useState(false);
  const animatedHeight = useRef(new Animated.Value(0)).current;
  const rotateAnim = useRef(new Animated.Value(0)).current;
  const scrollViewRef = useRef(null);
  const [product, setProduct] = useState([]);

  const defaultAddressItem =
    fetch_address.find(item => item?.address_default_select) || {};

  const toggleExpand = () => {
    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);

    Animated.timing(rotateAnim, {
      toValue: expanded ? 0 : 1,
      duration: 300,
      useNativeDriver: true,
    }).start();

    if (!expanded) {
      Animated.timing(animatedHeight, {
        toValue: 1,
        duration: 300,
        useNativeDriver: false,
      }).start(() => {
        scrollViewRef.current?.scrollToEnd({animated: true});
      });
    } else {
      Animated.timing(animatedHeight, {
        toValue: 0,
        duration: 300,
        useNativeDriver: false,
      }).start();
    }

    setExpanded(!expanded);
  };

  const renderItem = useCallback(({item, index}) => {
    const image = item.product_variant?.variant?.images?.length
      ? item.product_variant?.variant?.images?.[0]?.preview?.image.url
      : item.product_variant?.product?.product_image_url;

    return (
      <View style={{marginTop: index == 0 ? 0 : height * 0.015}}>
        <VariantCard
          borderWidth={'100%'}
          index={0}
          isDisabled={false}
          display={true}
          product={item?.product_variant?.product}
          qty={item?.quantity}
          variantStock={true}
          shop={data.shop}
          variant={item?.product_variant?.variant}
          optionHeight={height*0.022}
          image={image}
          removeBorder={true}
          imageStyle={{width: width * 0.2}}
          marginTop={height * 0.01}
          priceSize={fontScale * 15}
          priceFontFamily={font.medium}
          headingSize={fontScale * 15}
          imageQty={true}
          productTitle={item?.product_variant?.product?.product_name}
        />
      </View>
    );
  }, []);

  const renderProduct = useCallback(({item, index}) => {
    return (
      <View
        key={`search_${index}`}
        style={{
          marginRight: WH.width('2'),
          marginTop: index == 0 || index == 1 ? 0 : height * 0.01,
        }}>
        <HomeDualCard item={item} width={WH.width('43')} color={'black'} />
      </View>
    );
  }, []);

  const rotate = rotateAnim.interpolate({
    inputRange: [0, 1],
    outputRange: ['0deg', '180deg'], // Rotate from 0 to 180 degrees
  });

  const orderSummary = [
    {
      label: 'Contact Information',
      value: fetch_user_detail?.email,
    },
    {
      label: 'Shipping Address',
      value: `${defaultAddressItem?.address_one}, ${defaultAddressItem?.address_two}, ${defaultAddressItem?.address_city}`,
    },
    {
      label: 'Shipping Method',
      value: 'Standard',
    },
    // {
    //     "label": "Payment Method",
    //     "value": "CARD · Rs 10.00, 1 · Rs 13,910.00"
    // },
  ];

  const fetchAPI = async () => {
    try {
      const categories = data.products
        ?.map(item => item.product_variant?.product?.product_custom_category)
        .filter(Boolean);

      const uniqueCategories = [...new Set(categories)];
      const products = await dispatch(
        _fetchSearchedList(uniqueCategories.toString(), false, 1, false),
      );

      setProduct(products);
    } catch (err) {
      setProduct([]);
  
    }
  };

  useEffect(() => {
    fetchAPI();
  }, []);

  const [isLoading, setIsLoading] = useState(false);
  const [latestOrderDetail, setLatestOrderDetail] = useState({});



  // Fetch latest orders when component mounts
  const startPollingOrders = () => {
    if (!latestOrderDetail?.order_title && data?.shop?.shop_id && order_email) {
      setIsLoading(true);
      const interval = setInterval(async () => {
        const isDone = await dispatch(
          _getLatestOrderDetail(data?.shop?.shop_id, order_email),
        );
        if (isDone) {
          clearInterval(interval);
          setIsLoading(false);
          setLatestOrderDetail(isDone);
        }
      }, 3000);
    }
  };

  useEffect(() => {
    startPollingOrders();
  }, [data]);

  const date = new Date(latestOrderDetail?.created_at);

  // Format: Apr 16 2025
  const formatted = date.toLocaleDateString('en-US', {
    month: 'short',
    day: '2-digit',
    year: 'numeric',
  });

  return {
    expanded,
    setExpanded,
    animatedHeight,
    rotateAnim,
    scrollViewRef,
    toggleExpand,
    renderItem,
    rotate,
    orderSummary,
    renderProduct,
    isLoading,
    latestOrderDetail,
    formatted,
    product,
  };
};

export default useThankYou;
