import React, {useEffect, useMemo, useState} from 'react';
import {
  Dimensions,
  StyleSheet,
  View,
  TouchableOpacity,
  Animated,
  UIManager,
  Platform,
  FlatList,
  ActivityIndicator,
} from 'react-native';
import Content from '@materialComponent/content/content';
import {margin, colors, font, globalStyle} from '@constant/contstant';
import LottieThankYou from '@component/lottieFiles/lottieThankYou';
import CustomText from '@materialComponent/customText/customText';
import BrandTab from '@component/brandTab/brandTab';
import MerchantChatBox from '@component/cards/merchantChat/merchantChatBox';
import SummaryTable from '@component/table/summaryTable';
import Icon from '@materialComponent/icon/icon';
import {moderateScale} from 'react-native-size-matters';
import BorderLine from '@component/borderLine/borderLine';
import OrderSummary from '@component/orderSummary/orderSummary';
import useThankYou from './useThankYou';
import useReduxStore from '../../../utils/hooks/useReduxStore';
import {
  _getInternalOrder,
  _getLatestOrderDetail,
} from '../../../redux/actions/orders/orders';
import OrderDetailLoader from '../../../component/loader/orderDetailLoader';
import OrderLinks from '../../../component/orderLinks/orderLinks';
import MerchantItemsHeader from '../../../component/header/merchantItemsHeader';

const {height, width, fontScale} = Dimensions.get('screen');

if (
  Platform.OS === 'android' &&
  UIManager.setLayoutAnimationEnabledExperimental
) {
  UIManager.setLayoutAnimationEnabledExperimental(true);
}

const ThankYou = ({data, order_email}) => {
  const {
    scrollViewRef,
    renderItem,
    renderProduct,
    product,
    isLoading,
    latestOrderDetail,
    formatted,
  } = useThankYou({data, order_email});

  if (isLoading) {
    return <OrderDetailLoader removeMargin={true} loading={true} />;
  }

  return (
    <Content key={1} ref={scrollViewRef}>
      <View style={styles.mainView}>
        <MerchantItemsHeader
          shop={data?.shop}
          subtitle={`${data?.products?.length} items . Pending ${formatted}`}
        />
        <LottieThankYou />
        <View style={{marginHorizontal: margin.horizontal}}>
          <CustomText
            center
            fontFamily={font.bold}
            fontSize={fontScale * 18}
            text={`Thank you for your order ${latestOrderDetail?.order_title}`}
          />
          <View style={{width: '70%', alignSelf: 'center'}}>
            <CustomText
              color={'#9A9A9A'}
              marginTop={height * 0.005}
              center
              fontSize={fontScale * 17}
              text={'We’re processing it and will notify you once it ships.'}
            />
          </View>
        </View>
        <View style={[styles.order]}>
          {/* <BrandTab
                        item={data?.shop}
                        followColor={colors.light_theme.theme}
                        followStyle={{ paddingHorizontal: 0, paddingVertical: 0 }}
                        followSize={fontScale * 15}
                        removeFollowText={true}
                    /> */}
          <FlatList
            scrollEnabled={false}
            data={data?.products}
            renderItem={renderItem}
          />
          {/* <View style={{ marginTop: height * 0.015, marginBottom: height * 0.02 }}>
                        <MerchantChatBox />
                    </View> */}
        </View>
        <View
          style={{
            marginTop: height * 0.02,
            marginHorizontal: margin.horizontal,
          }}>
          <OrderLinks shop={data?.shop} orderId={latestOrderDetail?.order_id} />
        </View>
        {(product || [])?.length > 0 && (
          <>
            <View
              style={{
                marginTop: height * 0.02,
                marginHorizontal: margin.horizontal,
              }}>
              <CustomText
                fontSize={fontScale * 17}
                fontFamily={font.bold}
                color="black"
                text={`Products you may like`}
              />
              <FlatList
                scrollEnabled={false}
                data={product || []}
                renderItem={renderProduct}
                keyExtractor={(item, index) => index.toString()}
                showsHorizontalScrollIndicator={false}
                numColumns={2}
                contentContainerStyle={{
                  marginTop: height * 0.02,
                  marginBottom: height * 0.1,
                }}
              />
            </View>
          </>
        )}

        {/* <View style={[styles.order, { marginTop: height * 0.01, paddingBottom: height * 0.01 }]}>
                    <SummaryTable label={'Total'} value={orderTotal} />
                    <SummaryTable marginTop={height * 0.01} label={'Order No.'} value={orderNumber} />
                    <BorderLine marginTop={height * 0.01} style={[styles.borderLine, { width: '100%' }]} />
                    <TouchableOpacity
                        style={styles.toggleButton}
                        onPress={toggleExpand}
                        activeOpacity={0.7}
                    >
                        <CustomText text={'View Order Summary'} style={styles.toggleText} />
                        <Animated.View // Wrap the icon in an Animated.View
                            style={{ transform: [{ rotate }] }}
                        >
                            <Icon
                                icon_type={'Feather'}
                                name={'chevron-down'}
                                size={moderateScale(15)}
                                color={colors.light_theme.theme}
                            />
                        </Animated.View>
                    </TouchableOpacity>
                </View> */}
        {/* <OrderSummary expanded={expanded} animatedHeight={animatedHeight} orderSummary={orderSummary} /> */}
      </View>
    </Content>
  );
};

export default ThankYou;

const styles = StyleSheet.create({
  mainView: {
    flex: 1,
    backgroundColor: 'white',
    paddingBottom: globalStyle.bottomSpace.marginBottom,
  },
  order: {
    // backgroundColor: '#FAFAFA',
    // backgroundColor: 'red',
    marginHorizontal: margin.horizontal,
    // paddingTop: height * 0.01,
    marginTop: height * 0.02,
    borderWidth: 2,
    borderColor: '#FAFAFA',
    paddingHorizontal: width * 0.02,
    paddingVertical: height * 0.02,
    borderRadius: 15,
  },
  borderLine: {
    marginLeft: 0,
    width: '95%',
    backgroundColor: '#00000033',
    height: height * 0.003,
    alignSelf: 'center',
    opacity: 0.3,
  },
  toggleButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: height * 0.01,
    marginBottom: height * 0.005,
  },
  toggleText: {
    marginRight: width * 0.01,
    color: 'black',
    fontFamily: font.regular,
  },
  loadingContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
});
