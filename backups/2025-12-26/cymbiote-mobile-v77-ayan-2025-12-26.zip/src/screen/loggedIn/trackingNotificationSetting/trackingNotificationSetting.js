import { Dimensions, StatusBar, StyleSheet, View } from 'react-native';
import React, { useState } from 'react';
import InnerHeader from '@component/header/innerHeader';
import { margin } from '@constant/contstant';
import Toggle from '@materialComponent/toggle/toggle';
import Content from '@materialComponent/content/content';
import Container from '../../../materialComponent/container/container';

const { height } = Dimensions.get('screen');

const TrackingNotificationSetting = ({ route }) => {
  return (
    <Container barColor={"white"}>
      <View style={[styles.mainView]}>
        <InnerHeader title={'Tracking'} />
        <Content>
          <View style={styles.content}>
            {data.map((item, index) => {
              return (
                <Toggle
                  text={item.desc}
                  marginTop={index == 0 ? height * 0.02 : height * 0.03}
                  item={item}
                />
              );
            })}
          </View>
        </Content>
      </View>
    </Container>

  );
};

export default TrackingNotificationSetting;

const styles = StyleSheet.create({
  mainView: {
    flex: 1,
    backgroundColor: 'white',
  },
  content: {
    marginHorizontal: margin.horizontal,
    paddingBottom: height * 0.1,
  },
});

const data = [
  {
    toggle: true,
    desc: 'Order added',
    db_value: 'notification_setting_order_create',
  },
  {
    toggle: true,
    desc: 'Order updated',
    db_value: 'notification_setting_order_update',
  },
  {
    toggle: true,
    desc: 'Order shipped',
    db_value: 'notification_setting_order_shipped',
  },
  {
    toggle: true,
    desc: 'Order in transit',
    db_value: 'notification_setting_order_intransit',
  },
  {
    toggle: true,
    desc: 'Order out for delivery',
    db_value: 'notification_setting_order_dispatched',
  },
  {
    toggle: true,
    desc: 'Order delivered',
    db_value: 'notification_setting_order_delivered',
  },
  // {
  //   toggle: true,
  //   desc: "Order delivery delayed",
  // },
  // {
  //   toggle: true,
  //   desc: "Order failure",
  // },
  // {
  //   toggle: true,
  //   desc: "Order exception",
  // },
  // {
  //   toggle: true,
  //   desc: "Order ready for pickup",
  // },
  {
    toggle: true,
    desc: 'Order picked up',
    db_value: 'notification_setting_order_picked_up',
  },
  {
    toggle: true,
    desc: 'Order refunded',
    db_value: 'notification_setting_order_refunded',
  },
];
