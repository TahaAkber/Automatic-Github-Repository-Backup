import {
  Dimensions,
  FlatList,
  RefreshControl,
  StatusBar,
  StyleSheet,
  TouchableOpacity,
  View,
} from 'react-native';
import React from 'react';
import {moderateScale, scale, verticalScale} from 'react-native-size-matters';
import InnerHeader from '@component/header/innerHeader';
import {globalStyle} from '@constant/contstant';
import useCart from './useCart';
import AddressCardForCart from '@component/cards/addressCardForCart/addressCardForCart';
import Content from '@materialComponent/content/content';
import CartLoader from '@component/loader/cartLoader';
import {margin} from '@constant/contstant';
import AddressCard from '../../../component/cards/addressCardForCart/addressCard';
import CustomText from '../../../materialComponent/customText/customText';
import CircleIcon from '../../../materialComponent/circleIcon/circleIcon';
import {navigate} from '../../../utils/navigationRef/navigationRef';
import {colors, font} from '../../../constant/contstant';
import {useNavigation} from '@react-navigation/native';
import { heightPercentageToDP } from 'react-native-responsive-screen';

const {fontScale, height, width} = Dimensions.get('screen');

const Cart = () => {
  const {
    renderItem,
    cart_item,
    cart_item_loader,
    pullLoader,
    cart,
    fetchAPI,
    fetch_address,
  } = useCart({});

  const navigation = useNavigation();
  return (
    <View style={styles.mainView}>
      <Content
        refreshControl={
          <RefreshControl refreshing={pullLoader} onRefresh={fetchAPI} />
        }>
        <View style={{backgroundColor: '#f6f6f6', flex: 1}}>
          {cart_item_loader ? (
            <View style={{marginHorizontal: margin.horizontal}}>
              <CartLoader />
            </View>
          ) : (
            <View style={{marginTop: height * 0.012}}>
              {cart_item ? (
                <AddressCard
                  style={{backgroundColor: 'white'}}
                  data={fetch_address}
                  cart={true}
                  defaultDesign={true}
                />
              ) : (
                // <AddressCardForCart style={{ backgroundColor: "white" }} data={fetch_address} cart={true} defaultDesign={true} />
                // <></>
                <></>
              )}
              <View style={{flex: 1}}>
                <FlatList
                  contentContainerStyle={styles.flatLists}
                  showsVerticalScrollIndicator={false}
                  data={cart_item}
                  scrollEnabled={false}
                  keyExtractor={item => item.cartId}
                  renderItem={renderItem}
                />
              </View>
            </View>
          )}
        </View>
      </Content>
    </View>
  );
};

export default Cart;

const styles = StyleSheet.create({
  mainView: {
    flex: 1,
    // backgroundColor: 'red',
  },
  flatLists: {
    paddingHorizontal: margin.horizontal,
    marginTop: height * 0.012,
    // paddingVertical: verticalScale(10),
    paddingBottom: heightPercentageToDP(20),
  },
  addAddressContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginHorizontal: margin.horizontal,
    borderColor: colors.light_theme.theme,
    borderWidth: 1,
    padding: width * 0.04,
    borderRadius: moderateScale(10),
  },
});
