import React from 'react';
import {Dimensions, FlatList, StatusBar, StyleSheet, View} from 'react-native';
import {colors, font, globalStyle, margin, WH} from '@constant/contstant';
import {moderateScale, verticalScale} from 'react-native-size-matters';
import useSearchSecondDegree from './useSearchSecondDegree';
import SearchScreenInput from '@component/input/searchScreenInput';
import ActiveSearch from '@component/activeSearch/activeSearch';
import SearchCategories from '@component/searchCategories/searchCategories';
import Content from '@materialComponent/content/content';
import SearchedItemsLoader from '@component/loader/searchedItemsLoader';
import SearchSecondDegree from '../../../component/searchSecondDegree/searchSecondDegree';
import CustomText from '../../../materialComponent/customText/customText';
import BrandTab from '../../../component/brandTab/brandTab';
import {navigate} from '../../../utils/navigationRef/navigationRef';

const {height, fontScale} = Dimensions.get('screen');

const SearchSecondDegreeScreen = ({navigation, route}) => {
  const {
    value,
    handleSearch,
    localData,
    searchLoader,
    isKeyboardVisible,
    _handleBlur,
    categoriesData,
    renderProduct,
    loader,
  } = useSearchSecondDegree({navigation, route});

  return (
    <View style={styles.container}>
      <StatusBar
        animated
        barStyle="dark-content"
        backgroundColor="white"
        translucent={false}
      />
      <View style={styles.innerContainer}>
        <View style={{marginBottom: height * 0.02}}>
          <SearchScreenInput
            onBlur={_handleBlur}
            onChangeText={handleSearch}
            value={value}
          />
        </View>
        <Content contentContainerStyle={{marginBottom: height * 0.5}}>
          {isKeyboardVisible || value ? (
            <ActiveSearch
              value={value}
              searchLoader={searchLoader}
              localData={localData}
            />
          ) : (
            <View style={styles.categoryItem}>
              <SearchSecondDegree route={route} />
              {loader ? (
                <SearchedItemsLoader loading={loader} />
              ) : (
                <View style={{marginTop: height * 0.0}}>
                  {categoriesData?.length > 0 && (
                    <View style={{marginTop: height * 0.03}}>
                      <CustomText
                        fontSize={fontScale * 17}
                        fontFamily={font.bold}
                        color="black"
                        text={`Feature brands`}
                      />
                      {categoriesData.map((item, index) => {
                        return (
                          <View
                            style={{
                              marginTop:
                                index == 0 ? height * 0.03 : height * 0.03,
                            }}
                            key={`related_shop_${index}`}>
                            <BrandTab
                              item={item}
                              followText={'Visit Store'}
                              followPress={() =>
                                navigate('Brand', {
                                  shop_id: item.shop_id,
                                  shop: item,
                                })
                              }
                              followColor={'white'}
                              followStyle={{backgroundColor: 'black'}}
                            />
                            <FlatList
                              data={item?.products}
                              renderItem={renderProduct}
                              keyExtractor={(item, index) => index.toString()}
                              showsHorizontalScrollIndicator={false}
                              contentContainerStyle={styles.similarProductsList}
                              horizontal
                            />
                          </View>
                        );
                      })}
                    </View>
                  )}
                </View>
              )}
            </View>
          )}
        </Content>
      </View>
    </View>
  );
};

export default SearchSecondDegreeScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
    paddingTop: height * 0.02,
  },
  innerContainer: {
    marginHorizontal: margin.horizontal,
    flex: 1,
    backgroundColor: 'white',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between', // Ensure proper spacing.
    marginVertical: verticalScale(10),
  },
  inputContainer: {
    borderRadius: 180,
    ...globalStyle.row,
    height: WH.height(5),
    paddingHorizontal: margin.horizontal,
    backgroundColor: 'rgba(201, 210, 239 , 0.4)',
    width: '80%',
  },
  searchbar: {
    fontFamily: font.medium,
    width: '100%',
    height: '100%',
    marginLeft: moderateScale(10),
    paddingRight: moderateScale(15),
  },
  cancelText: {
    fontFamily: font.medium,
    fontSize: moderateScale(16),
    color: colors.primary,
  },
  searchListItem: {
    backgroundColor: 'red',
  },
  imageView: {
    width: moderateScale(40),
    height: moderateScale(40),
    backgroundColor: 'white',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 10,
    marginRight: moderateScale(15),
    borderColor: colors.light_theme.darkBorderColor,
    borderWidth: 1,
  },
  circle: {
    backgroundColor: colors.light_theme.borderColor,
    borderRadius: 180,
    width: moderateScale(25),
    aspectRatio: 1 / 1,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: moderateScale(10),
  },
  categoryItem: {
    paddingBottom: height * 0.3,
  },
  similarProductsList: {
    marginTop: height * 0.02,
  },
});
