import {useCallback, useEffect, useRef, useState} from 'react';
import {Dimensions, Keyboard, View} from 'react-native';
import {
  _fetchCategoryProducts,
  _recentSearchRecord,
  _searchMethod,
} from '@redux/actions/common/common';
import useReduxStore from '@utils/hooks/useReduxStore';
import {WH} from '@constant/contstant';
import HomeDualCard from '@component/cards/homeDualCard';

const {height} = Dimensions.get('screen');

const useSearchSecondDegree = ({route}) => {
  const {dispatch} = useReduxStore();
  const [value, setValue] = useState('');
  const [searchLoader, setSearchLoader] = useState(false);
  const [isKeyboardVisible, setIsKeyboardVisible] = useState(false);
  const [loader, setLoader] = useState(false);
  const [categoriesData, setCategoriesData] = useState([]);
  const [localData, setLocalData] = useState({});
  const controllerRef = useRef(null);

  const debounceRef = useRef(null);

  

  useEffect(() => {
    const keyboardDidShowListener = Keyboard.addListener(
      'keyboardDidShow',
      () => {
        setIsKeyboardVisible(true); // Show "Cancel" button.
      },
    );

    const keyboardDidHideListener = Keyboard.addListener(
      'keyboardDidHide',
      () => {
        setIsKeyboardVisible(false); // Hide "Cancel" button.
      },
    );

    return () => {
      keyboardDidShowListener.remove();
      keyboardDidHideListener.remove();
    };
  }, [isKeyboardVisible]);

  const handleSearch = async text => {
    _searchMethod(
      text,
      setValue,
      setSearchLoader,
      setLocalData,
      debounceRef,
      '',
      controllerRef,
      '',
      true,
      '/rag_search?query=',
    );
  };

  const _handleBlur = () => {
    if (value) {
      dispatch(_recentSearchRecord({searchTerm: value, navigation}));
    }
  };

  const fetchAPI = async () => {
    setLoader(true);
    const response = await dispatch(
      _fetchCategoryProducts(route?.params?.first_degree_category),
    );
    setCategoriesData(response);
    setLoader(false);
  };

  const renderProduct = useCallback(({item}) => {
    return (
      <View style={{marginRight: WH.width('2')}}>
        <HomeDualCard item={item} width={WH.width('43')} color={'black'} />
      </View>
    );
  }, []);

  useEffect(() => {
    fetchAPI();
  }, []);

  return {
    value,
    handleSearch,
    localData,
    searchLoader,
    isKeyboardVisible,
    _handleBlur,
    categoriesData,
    renderProduct,
    loader,
  };
};

export default useSearchSecondDegree;
