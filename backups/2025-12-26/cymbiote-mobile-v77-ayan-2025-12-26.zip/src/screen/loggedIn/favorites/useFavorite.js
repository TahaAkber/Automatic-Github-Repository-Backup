import {_getRecentViewedList} from '@redux/actions/user/user';
import {_getStores, _getFollowingStore} from '@redux/actions/merchant/merchant';
import useReduxStore from '@utils/hooks/useReduxStore';
import {_recentViewed} from '@redux/actions/user/user';
import {useEffect} from 'react';
import {_getFavorite} from '../../../redux/actions/user/user';

const useFavorite = ({}) => {
  const {dispatch, getState} = useReduxStore();
  const {fetch_user_detail} = getState('auth');
  const {
    fetch_favorite_list_local,
    fetch_favorite_list,
    fetch_favorite_list_loader,
    fetch_favorite_list_error,
  } = getState('user');

  const fetchAPI = () => {
    dispatch(_getFavorite(true, fetch_favorite_list_local));
  };

  useEffect(() => {
    fetchAPI();
  }, []);



  return {
    dispatch,
    fetch_favorite_list_local,
    fetch_favorite_list,
    fetch_favorite_list_loader,
    fetch_favorite_list_error,
    fetchAPI
  };
};

export default useFavorite;
