import {moderateScale} from 'react-native-size-matters';
import {Dimensions, FlatList, StatusBar, StyleSheet, View} from 'react-native';
import React, {useMemo} from 'react';
import InnerHeader from '@component/header/innerHeader';
import {margin} from '@constant/contstant';
import HomeDualCard from '../../../component/cards/homeDualCard';
import useFavorite from './useFavorite';
import EmptyScreen from '../../../component/emptyScreen/emptyScreen';
import Container from '../../../materialComponent/container/container';
import {showErrorScreen} from '../../../utils/helper/helper';
import {globalStyle} from '../../../constant/contstant';
import SearchedItemsLoader from '../../../component/loader/searchedItemsLoader';

const {width, height, fontScale} = Dimensions.get('screen');

const GAP = 12; // space between items vertically
const SIDE = width * 0.04; // horizontal padding for the grid
const CARD_WIDTH = (width - SIDE * 2 - GAP) / 2; // width for each card

const Favorites = () => {
  const {
    fetch_favorite_list,
    fetch_favorite_list_error,
    fetchAPI,
    fetch_favorite_list_loader,
  } = useFavorite({});

  // Flatten: [{shop, products:[...]}, ...]  ->  [...products]
  const products = useMemo(() => {
    if (!Array.isArray(fetch_favorite_list)) return [];
    return fetch_favorite_list.flatMap(s =>
      Array.isArray(s.products) ? s.products : [],
    );
  }, [fetch_favorite_list]);

  const renderProduct = ({item}) => (
    <View style={{width: CARD_WIDTH}}>
      <HomeDualCard
        item={item}
        width={CARD_WIDTH}
        color="black"
        headingNumOfLines={1}
        showShopName
      />
    </View>
  );

  return showErrorScreen(fetch_favorite_list_error) ? (
    <View style={globalStyle.show_error}>
      <EmptyScreen
        fullWidth={true}
        reload={fetchAPI}
        loader={fetch_favorite_list_loader}
        message={fetch_favorite_list_error}
      />
    </View>
  ) : (
    <Container bgColor={"white"} isFocused={true} dark barColor="white">
      <View style={styles.container}>
        <InnerHeader notification setting title="Favorites" />
        {fetch_favorite_list_loader ? (
          <View style={{marginHorizontal: margin.horizontal}}>
            <SearchedItemsLoader />
          </View>
        ) : products.length === 0 ? (
          <View
            style={{
              flex: 1,
              justifyContent: 'center',
              alignItems: 'center',
              marginTop: -height * 0.1,
            }}>
            <EmptyScreen
              image="empty_favorite"
              heading="No Favorites Yet!"
              desc="Save your favorite products here for quick access. Start exploring and add items you love!"
            />
          </View>
        ) : (
          <FlatList
            data={products}
            numColumns={2}
            renderItem={renderProduct}
            keyExtractor={(item, index) => String(item?.id ?? index)}
            contentContainerStyle={{
              paddingHorizontal: SIDE,
              paddingBottom: height * 0.2,
              paddingTop: moderateScale(8),
            }}
            columnWrapperStyle={{justifyContent: 'space-between'}}
            showsVerticalScrollIndicator={false}
          />
        )}
      </View>
    </Container>
  );
};

export default Favorites;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
  },
});

// import { moderateScale } from 'react-native-size-matters';
// import { Dimensions, FlatList, StatusBar, StyleSheet, View } from 'react-native';
// import React from 'react';
// import InnerHeader from '@component/header/innerHeader';
// import { margin } from '@constant/contstant';
// import BrandTab from '@component/brandTab/brandTab';
// import { homeData } from '@constant/dummyData';
// import VariantCard from '@component/cards/variantCard/variantCard';
// import useFavorite from './useFavorite';
// import EmptyScreen from '../../../component/emptyScreen/emptyScreen';
// import HomeDualCard from '../../../component/cards/homeDualCard';
// import Container from '../../../materialComponent/container/container';

// const { width, height, fontScale } = Dimensions.get("screen");

// const Favorites = () => {

//     const { fetch_favorite_list } = useFavorite({})

//     const renderProducts = ({ item }) => {
//         const image = item.product_image_url;
//         return (
//             <View style={{ marginTop: height * 0.02, }}>

//                 <HomeDualCard
//                     color={"black"} // Customize the color as per your design
//                     //    width={width * 0.42} // Adjust width as per your design
//                     item={item} // Pass item to the HomeDualCard
//                     //    headingSize={fontScale * 14} // Adjust heading size
//                     //    priceSize={fontScale * 12} // Adjust price size
//                     headingNumOfLines={1}
//                     showShopName={true} // Show shop name
//                 //    marginRight={1} // Adjust margin right
//                 />

//             </View>
//         )
//     };

//     return (
//         <Container barColor={"white"}>
//             <View style={styles.container}>
//                 <InnerHeader notification={true} setting={true} title={"Favorites"} />

//                 <>
//                     {fetch_favorite_list.length == 0 ?
//                         <View style={{ justifyContent: "center", alignItems: "center", flex: 1, marginTop: height * -0.1 }}>
//                             <EmptyScreen
//                                 image={"empty_favorite"}
//                                 heading={"No Favorites Yet!"}
//                                 desc={"Save your favorite products here for quick access. Start exploring and add items you love!"}
//                             />
//                         </View> :
//                         <View style={{}}>
//                             <View>
//                                 <FlatList
//                                     scrollEnabled={true}
//                                     data={fetch_favorite_list}
//                                     numColumns={2}
//                                     renderItem={({ item, index }) => {
//                                         // const image = item.product_variant?.images?.length
//                                         //     ? item.product_variant?.variant?.images?.[0]?.preview?.image.url
//                                         //     : item.product_variant?.product?.product_image_url;
//                                         return (
//                                             <View>
//                                                 <View style={[styles.horizontal, index != 0 && {}]}>
//                                                     {/* <BrandTab item={item} followColor={"white"} followStyle={{ backgroundColor: "black" }} /> */}
//                                                     <FlatList
//                                                         scrollEnabled={true}
//                                                         data={item.products}
//                                                         renderItem={renderProducts}
//                                                         keyExtractor={(item, index) => index.toString()}
//                                                         showsHorizontalScrollIndicator={false}
//                                                         contentContainerStyle={styles.similarProductsList}
//                                                     />
//                                                 </View>
//                                             </View>
//                                         )
//                                     }}
//                                     keyExtractor={(item, index) => index.toString()}
//                                     showsHorizontalScrollIndicator={false}
//                                     contentContainerStyle={styles.shopsList}
//                                 />
//                             </View>
//                         </View>
//                     }

//                 </>

//             </View>
//         </Container>
//     );
// };

// export default Favorites;

// const styles = StyleSheet.create({
//     container: {
//         flex: 1,
//         backgroundColor: "white",

//     },
//     horizontal: {
//         // marginHorizontal: margin.horizontal,
//         width: '50%',  // Ensure each item takes 50% of the screen width for two columns
//         padding: 5,

//         // alignItems:"center",
//         // justifyContent:"center",
//     },
//     contentContainer: {
//         marginRight: moderateScale(10),
//     },
//     image: {
//         width: moderateScale(80),
//         height: moderateScale(80),
//         borderRadius: moderateScale(10),
//     },
//     shopsList: {
//         paddingBottom: height * 0.2,
//         // backgroundColor:"#f4f4f4",
//         paddingHorizontal: width * 0.03,
//     },
//     similarProductsList: {

//     },
// });
