// ReelsScreen.js
import React, {useCallback, useRef, useState, useMemo, useEffect} from 'react';
import {
  Dimensions,
  StatusBar,
  StyleSheet,
  TouchableOpacity,
  View,
  Animated,
  FlatList,
  AppState,
  Platform,
} from 'react-native';
import {useIsFocused, useRoute} from '@react-navigation/native';
import {TapGestureHandler} from 'react-native-gesture-handler';
import Video from 'react-native-video';
import {useDispatch} from 'react-redux';
import Icon from '../../materialComponent/icon/icon';
import BrandTab from '../../component/brandTab/brandTab';
import ReelProduct from './reelProducts';
import ReelsLSC from './reelsLSC';
import useReels from './useReels';
import {
  _updateReelViewCount,
  _likeReel,
  updateShopReel,
} from '../../redux/actions/reels/reels';
import {goBack} from '../../utils/navigationRef/navigationRef';
import ScrollThumb from '../../component/lottieFiles/scrollThumb';
import Overlay from '../../materialComponent/overlay/overlay';
import {moderateScale} from 'react-native-size-matters';
import {TOGGLE_VOLUME} from '../../redux/types/reels/reels';
import {useSafeAreaInsets} from 'react-native-safe-area-context';
import ReelLoader from '../../component/loader/reelLoader';
import VideoBufferIndicator from '../../component/videoBufferIndicator/videoBufferIndicator';
import DoubleTapHeart from '../../component/doubleTapHeart/doubleTapHeart';
import {
  logReelViewEvent,
  logReelProductClickEvent,
} from '../../helper/eventTriggers/useEventTriggers';
import BottomSheetReport from '../../materialComponent/bottomSheet/bottomSheetReport';
import {isAndroid, shadow} from '../../constant/contstant';
import {heightPercentageToDP} from 'react-native-responsive-screen';

const {width, height} = Dimensions.get('screen');
const ITEM_HEIGHT = height;
const PRELOAD_WINDOW = 3;
const DOUBLE_TAP_DELAY = 100; // gesture handler timing

const ReelsScreen = () => {
  const route = useRoute();
  const loaderTimersRef = useRef({});
  const showLoaderRef = useRef({});
  const dispatch = useDispatch();
  const flatListRef = useRef();
  const viewedVideoIds = useRef(new Set());
  const scrollY = useRef(new Animated.Value(0)).current;
  const isFocused = useIsFocused();

  const [currentIndex, setCurrentIndex] = useState(0);
  const [isVideoReady, setIsVideoReady] = useState({});
  const [bufferingVideos, setBufferingVideos] = useState(new Set());

  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [volumeLevel, setVolumeLevel] = useState(0);
  const [loadingIndexes, setLoadingIndexes] = useState(new Set());
  const [pausedVideos, setPausedVideos] = useState(new Set());
  const [hasShownThumbOnce, setHasShownThumbOnce] = useState(false);

  const [showHeart, setShowHeart] = useState({});
  const [heartPosition, setHeartPosition] = useState({x: 0, y: 0});
  const [heartTokenByIndex, setHeartTokenByIndex] = useState({});
  const heartSeqRef = useRef(0);
  const heartBusyRef = useRef({});

  const reelStartTimeRef = useRef({});
  const reelDurationRef = useRef({});
  const reelProductClickOrderRef = useRef({});
  const loggedReelViewsRef = useRef(new Set());
  const reportSheetRef = useRef(null);

  const {shopId, videoId, isDeepLink} = route.params;

  const {
    shopReels,
    shopReelsLoading,
    paginationLoader,
    paginationAPI,
    viewabilityConfigRef,
    showScrollThumb,
    setShowScrollThumb,
    toggleVolume,
  } = useReels({
    shop_id: shopId,
    video_id: videoId,
    deep_link: isDeepLink,
  });

  console.log('shopReels ==>', shopReels?.[currentIndex]?.id);

  // AppState handling
  const [appState, setAppState] = useState(AppState.currentState);
  const appStateRef = useRef(AppState.currentState);
  useEffect(() => {
    const subscription = AppState.addEventListener('change', nextAppState => {
      if (
        appStateRef.current.match(/active/) &&
        nextAppState.match(/inactive|background/)
      ) {
        setPausedVideos(new Set([currentIndex]));
      }
      if (
        appStateRef.current.match(/inactive|background/) &&
        nextAppState === 'active'
      ) {
        setPausedVideos(new Set());
      }
      appStateRef.current = nextAppState;
      setAppState(nextAppState);
    });
    return () => subscription.remove();
  }, [currentIndex]);

  const insets = useSafeAreaInsets();

  // keep your original offset (no layout change)
  const reelProductOffset = useMemo(() => {
    return Platform.OS === 'android'
      ? insets.bottom + height * -0.05
      : insets.bottom + height * -0.1;
  }, [insets.bottom]);

  const handleViewableItemsChanged = useCallback(
    ({viewableItems}) => {
      if (viewableItems.length > 0) {
        const {index, item} = viewableItems[0];

        // Log previous reel watch duration before switching
        if (currentIndex !== index && reelStartTimeRef.current[currentIndex]) {
          const prevReel = shopReels[currentIndex];
          if (
            prevReel &&
            !loggedReelViewsRef.current.has(prevReel.video_url_id)
          ) {
            const watchDuration =
              (Date.now() - reelStartTimeRef.current[currentIndex]) / 1000;
            const totalDuration = reelDurationRef.current[currentIndex] || 0;

            logReelViewEvent(prevReel, watchDuration, totalDuration);
            loggedReelViewsRef.current.add(prevReel.video_url_id);
          }
        }

        setCurrentIndex(index);

        // Start tracking new reel
        if (!reelStartTimeRef.current[index]) {
          reelStartTimeRef.current[index] = Date.now();
        }

        if (!viewedVideoIds.current.has(item.video_url_id)) {
          viewedVideoIds.current.add(item.video_url_id);
          dispatch(_updateReelViewCount(item.video_url_id));
        }
      }
    },
    [dispatch, shopReels, currentIndex],
  );

  const handleToggleVolume = () => {
    dispatch({type: TOGGLE_VOLUME});
  };

  // 📊 Analytics: Handle product click tracking
  const handleProductClick = useCallback(
    (productData, productPosition) => {
      const reelData = shopReels[currentIndex];
      if (!reelData) return;

      // Initialize click order for this reel if not exists
      if (!reelProductClickOrderRef.current[currentIndex]) {
        reelProductClickOrderRef.current[currentIndex] = 0;
      }

      // Increment click order
      reelProductClickOrderRef.current[currentIndex] += 1;
      const clickOrder = reelProductClickOrderRef.current[currentIndex];

      // Calculate watch duration before click
      const watchDurationBeforeClick = reelStartTimeRef.current[currentIndex]
        ? (Date.now() - reelStartTimeRef.current[currentIndex]) / 1000
        : 0;

      // Log the product click event
      logReelProductClickEvent(
        reelData,
        productData,
        clickOrder,
        productPosition,
        watchDurationBeforeClick,
      );
    },
    [shopReels, currentIndex],
  );

  const iosBufferTimersRef = useRef({}); // { [index]: timeoutId } to delay spinner
  const hasStartedRef = useRef({}); // { [index]: boolean } after first frame shown
  const showBufferWithDelay = useCallback((idx, delay = 250) => {
    clearTimeout(iosBufferTimersRef.current[idx]);
    iosBufferTimersRef.current[idx] = setTimeout(() => {
      setBufferingVideos(prev => new Set(prev).add(idx));
    }, delay);
  }, []);

  const hideBuffer = useCallback(idx => {
    clearTimeout(iosBufferTimersRef.current[idx]);
    setBufferingVideos(prev => {
      const s = new Set(prev);
      s.delete(idx);
      return s;
    });
  }, []);
  const handleScrollApi = useCallback(async () => {
    if (isLoadingMore) return;
    setIsLoadingMore(true);
    await paginationAPI();
    setIsLoadingMore(false);
  }, [paginationAPI, isLoadingMore]);

  // single-tap: play/pause (no timers)
  const handleSingleTap = useCallback(index => {
    setPausedVideos(prevState => {
      const next = new Set(prevState);
      next.has(index) ? next.delete(index) : next.add(index);
      return next;
    });
  }, []);

  // double-tap: guarded like + one heart animation
  const handleDoubleTap = async (index, nativeEvent) => {
    // guard: ignore re-entrancy while heart anim is active
    if (heartBusyRef.current[index]) return;
    heartBusyRef.current[index] = true;

    try {
      const {x: locationX = width / 2, y: locationY = height / 2} =
        nativeEvent || {};
      setHeartPosition({x: locationX, y: locationY});
      setShowHeart(prev => ({...prev, [index]: true}));

      // token so heart anim runs once
      const token = ++heartSeqRef.current;
      setHeartTokenByIndex(prev => ({...prev, [index]: token}));

      const currentReel = shopReels[index];
      if (!currentReel) return;

      if (!currentReel.isLiked) {
        await dispatch(_likeReel(currentReel.id, true));
        dispatch(
          updateShopReel(currentReel.id, {
            isLiked: true,
            video_likes_count: (currentReel.video_likes_count || 0) + 1,
          }),
        );
      }
    } catch (error) {
  
    }
  };

  useEffect(() => {
    if (!isFocused) {
      setPausedVideos(new Set(shopReels.map((_, i) => i)));

      // 📊 Analytics: Log final reel view when leaving screen
      if (reelStartTimeRef.current[currentIndex]) {
        const currentReel = shopReels[currentIndex];
        if (
          currentReel &&
          !loggedReelViewsRef.current.has(currentReel.video_url_id)
        ) {
          const watchDuration =
            (Date.now() - reelStartTimeRef.current[currentIndex]) / 1000;
          const totalDuration = reelDurationRef.current[currentIndex] || 0;

          logReelViewEvent(currentReel, watchDuration, totalDuration);
          loggedReelViewsRef.current.add(currentReel.video_url_id);
        }
      }
    } else {
      setPausedVideos(new Set());

      // 📊 Analytics: Restart tracking when screen becomes focused
      if (!reelStartTimeRef.current[currentIndex]) {
        reelStartTimeRef.current[currentIndex] = Date.now();
      }
    }
  }, [isFocused, shopReels, currentIndex]);

  useEffect(() => {
    if (currentIndex >= 1 && showScrollThumb) {
      setShowScrollThumb(false);
    }
  }, [currentIndex, showScrollThumb]);

  const renderItem = useCallback(
    ({item, index}) => {
      if (Math.abs(index - currentIndex) > PRELOAD_WINDOW || !isFocused) {
        return <View style={styles.reelContainer} />;
      }
      const isPaused =
        pausedVideos.has(index) ||
        !isFocused ||
        appState !== 'active' ||
        index !== currentIndex;

      const handleLoadStart = () => {
        setLoadingIndexes(prev => new Set(prev).add(index));
        showLoaderRef.current[index] = false;

        loaderTimersRef.current[index] = setTimeout(() => {
          showLoaderRef.current[index] = true;
          flatListRef.current?.setNativeProps({});
        }, 500);
      };

      const handleLoad = () => {
        clearTimeout(loaderTimersRef.current[index]);
        delete loaderTimersRef.current[index];
        delete showLoaderRef.current[index];

        setLoadingIndexes(prev => {
          const newSet = new Set(prev);
          newSet.delete(index);
          return newSet;
        });
      };

      // Non-hook refs are fine here
      const singleTapRef = React.createRef();
      const doubleTapRef = React.createRef();

      return (
        <View style={styles.reelContainer}>
          {showScrollThumb && !hasShownThumbOnce && index < 1 && (
            <View style={styles.scrollThumbOverlay}>
              <Overlay borderRadius={moderateScale(10)} />
              <ScrollThumb
                onFinish={() => {
                  setShowScrollThumb(false);
                  setHasShownThumbOnce(true);
                }}
              />
            </View>
          )}

          <StatusBar
            animated
            barStyle="light-content"
            translucent
            backgroundColor="transparent"
          />

          {/* Wrap existing TouchableOpacity with gesture handlers (no layout change) */}
          <TapGestureHandler
            ref={doubleTapRef}
            numberOfTaps={2}
            maxDelayMs={DOUBLE_TAP_DELAY}
            onActivated={e => handleDoubleTap(index, e.nativeEvent)}>
            <TapGestureHandler
              ref={singleTapRef}
              waitFor={doubleTapRef}
              onActivated={() => handleSingleTap(index)}>
              <View style={styles.video}>
                <TouchableOpacity
                  style={styles.videoTouchable}
                  activeOpacity={1}>
                  {isFocused && shopReels[index] && (
                    <>
                      {!isVideoReady[index] && (
                        <View style={styles.loaderBackground} />
                      )}
                      <Video
                        poster={shopReels[index].video_thumbnail_url}
                        key={shopReels?.[index]?.video_url_id}
                        source={{uri: shopReels[index].video_url, type: 'm3u8'}}
                        style={[StyleSheet.absoluteFill, {zIndex: -1}]}
                        resizeMode="cover"
                        repeat
                        muted={toggleVolume}
                        paused={isPaused}
                        useTextureView={false} // Android only; harmless on iOS
                        // ---- ANDROID buffering controls (keep as-is; iOS ignores)
                        bufferConfig={{
                          minBufferMs: 5000,
                          maxBufferMs: 15000,
                          bufferForPlaybackMs: 200,
                          bufferForPlaybackAfterRebufferMs: 5000,
                          backBufferDurationMs: 120000,
                          cacheSizeMB: 256,
                        }}
                        // ---- iOS playback smoothness & bitrate cap
                        automaticallyWaitsToMinimizeStalling={true} // iOS
                        preferredPeakBitRate={
                          Platform.OS === 'ios' ? 2000000 : undefined
                        } // ~2 Mbps cap
                        // ---- LIFECYCLE
                        onLoadStart={() => {
                          setIsVideoReady(prev => ({...prev, [index]: false}));
                          // delay initial loader to avoid flicker
                          showBufferWithDelay(index, 300);
                          handleLoadStart();
                        }}
                        onReadyForDisplay={() => {
                          // iOS fires when the first frame is ready
                          hasStartedRef.current[index] = true;
                          setIsVideoReady(prev => ({...prev, [index]: true}));
                          hideBuffer(index);
                        }}
                        onLoad={data => {
                          // both platforms
                          // on iOS, onReadyForDisplay is the reliable "first frame" event,
                          // but keep onLoad to clean Android state as well.
                          setIsVideoReady(prev => ({...prev, [index]: true}));
                          hideBuffer(index);
                          handleLoad();

                          // 📊 Analytics: Capture video duration
                          if (data?.duration) {
                            reelDurationRef.current[index] = data.duration;
                          }
                        }}
                        // ---- BUFFERING
                        onBuffer={({isBuffering}) => {
                          // Only show buffer if this is the active reel and we’ve already started
                          if (index !== currentIndex) return;
                          if (isBuffering) {
                            // add a small delay to avoid micro-stalls showing the spinner
                            showBufferWithDelay(index, 200);
                          } else {
                            hideBuffer(index);
                          }
                        }}
                        onPlaybackStalled={() => {
                          // iOS-specific stall signal
                          if (index === currentIndex)
                            showBufferWithDelay(index, 150);
                        }}
                        onPlaybackResume={() => {
                          hasStartedRef.current[index] = true;
                          hideBuffer(index);
                        }}
                      />
                    </>
                  )}
                  {pausedVideos.has(index) && (
                    <View style={styles.pauseIconContainer}>
                      <View style={styles.playIcon}>
                        <Icon
                          icon_type="Entypo"
                          name="controller-play"
                          size={50}
                          color="black"
                        />
                      </View>
                    </View>
                  )}
                </TouchableOpacity>
              </View>
            </TapGestureHandler>
          </TapGestureHandler>

          {/* Keep overlays/layout unchanged */}
          {/* <View style={styles.overlayContent}> ... </View> */}

          <ReelProduct
            data={[item]}
            bottomPlace={reelProductOffset}
            currentIndex={currentIndex}
            setCurrentIndex={setCurrentIndex}
            item={item}
            handleToggleVolume={handleToggleVolume}
            toggleVolume={toggleVolume}
            isActive={index === currentIndex}
            setIsMuted={setIsMuted}
            isMuted={isMuted}
            containerStyle={styles.lcsCard}
            onProductClick={handleProductClick}
          />

          <VideoBufferIndicator
            isBuffering={bufferingVideos.has(index)}
            isVisible={index === currentIndex && isFocused}
          />

          {showHeart[index] && (
            <DoubleTapHeart
              visible={showHeart[index]}
              x={heartPosition.x}
              y={heartPosition.y}
              token={heartTokenByIndex[index] ?? 0}
              onAnimationEnd={() => {
                setShowHeart(prev => ({...prev, [index]: false}));
                heartBusyRef.current[index] = false; // release guard
              }}
            />
          )}
        </View>
      );
    },
    [
      currentIndex,
      loadingIndexes,
      isFocused,
      pausedVideos,
      toggleVolume,
      appState,
      bufferingVideos,
      showHeart,
      heartPosition,
      reelProductOffset,
      hasShownThumbOnce,
      showScrollThumb,
    ],
  );

  const renderLoaderFooter = useMemo(
    () =>
      isLoadingMore ? (
        <View style={styles.footerLoader}>
          <ReelLoader />
        </View>
      ) : null,
    [isLoadingMore],
  );

  return (
    <View style={styles.container}>
      <View
        style={[styles.header, !isAndroid && {top: heightPercentageToDP(5)}]}>
        <TouchableOpacity onPress={goBack} style={styles.backButton}>
          <Icon icon_type="Feather" name="arrow-left" size={24} color="white" />
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => reportSheetRef?.current?.open()}
          style={[
            // styles.backButton,
            {
              // backgroundColor: 'rgba(0,0,0,0.5)',
              borderRadius: 180,
              alignItems: 'center',
              justifyContent: 'center',
              width: moderateScale(35),
              aspectRatio: 1,
              ...shadow,
            },
          ]}>
          <Icon
            icon_type="FontAwesome"
            name="warning"
            size={moderateScale(18)}
            color="white"
          />
        </TouchableOpacity>
      </View>

      {shopReelsLoading ? (
        <View style={styles.loaderContainer}>
          <ReelLoader />
        </View>
      ) : (
        <FlatList
          ref={flatListRef}
          data={shopReels}
          keyExtractor={item => item?.video_url_id?.toString()}
          renderItem={renderItem}
          showsVerticalScrollIndicator={false}
          horizontal={false}
          onEndReached={handleScrollApi}
          onEndReachedThreshold={0.6}
          initialNumToRender={Math.max(3, PRELOAD_WINDOW + 1)}
          removeClippedSubviews={true}
          legacyImplementation={true}
          viewabilityConfig={viewabilityConfigRef.current}
          onViewableItemsChanged={handleViewableItemsChanged}
          snapToInterval={ITEM_HEIGHT}
          decelerationRate="fast"
          scrollEventThrottle={16}
          ListFooterComponent={renderLoaderFooter}
          refreshing={paginationLoader}
          bounces={false}
          windowSize={PRELOAD_WINDOW * 2 + 1}
          maxToRenderPerBatch={PRELOAD_WINDOW + 1}
        />
      )}
      <BottomSheetReport
        ref={reportSheetRef}
        reel={true}
        id={shopReels?.[currentIndex]?.id}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {flex: 1, backgroundColor: '#000'},
  reelContainer: {
    width,
    height: ITEM_HEIGHT,
    justifyContent: 'center',
    alignItems: 'center',
    position: 'relative',
  },
  video: {width: '100%', height: '100%', position: 'absolute'},
  videoTouchable: {flex: 1},
  overlayContent: {marginHorizontal: 10},
  cardView: {width: width * 0.9},
  backButton: {padding: 10},
  header: {
    position: 'absolute',
    top: 30,
    padding: 10,
    zIndex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    width: '100%',
  },
  footerLoader: {},
  loaderContainer: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.4)',
    zIndex: 2,
  },
  pauseIconContainer: {
    position: 'absolute',
    height: height,
    justifyContent: 'center',
    alignItems: 'center',
    alignSelf: 'center',
    zIndex: 999,
  },
  scrollThumbOverlay: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 4,
    pointerEvents: 'box-none',
  },
  playIcon: {
    backgroundColor: 'rgba(255,255,255,0.5)',
    borderRadius: 180,
    justifyContent: 'center',
    alignItems: 'center',
    width: width * 0.22,
    height: width * 0.22,
  },
  lcsCard: {zIndex: 2},
});

export default ReelsScreen;
