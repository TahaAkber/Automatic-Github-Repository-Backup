import React, {useEffect, useState, useRef} from 'react';
import {
  View,
  Dimensions,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  StatusBar,
  RefreshControl,
  FlatList,
} from 'react-native';
import {useFocusEffect, useRoute} from '@react-navigation/native';
import {navigate} from '../../utils/navigationRef/navigationRef';
import ReelHeader from '../../component/header/reelHaader';
import ReelsBrand from './reelsBrand';
import SavedImage from '@assets/images/saved-video.svg';
import SavedImageDark from '@assets/images/saved-video-d.svg';
import ViewsIcon from '@assets/images/viewsIcon.svg';
import ReelPageLoader from '../../component/loader/reelPageLoader';
import useReels from './useReels';
import CustomBackgoundImage from '../../materialComponent/image/bgImage';
import CustomText from '../../materialComponent/customText/customText';
import Icon from '../../materialComponent/icon/icon';
import Content from '../../materialComponent/content/content';
import {font} from '../../constant/contstant';
import Container from '../../materialComponent/container/container';

const {width, height} = Dimensions.get('screen');

const Reels = () => {
  const route = useRoute();
  const {shopId} = route.params;
  const {
    reels,
    loading,
    shop,
    paginationAPI,
    paginationLoader,
    shopAndSavedReels,
    shopSavedReelsLoading,
    fetchShopAndSavedReels,
  } = useReels({
    shop_id: shopId,
  });

  const [activeTab, setActiveTab] = useState('Reels');
  const [refreshing, setRefreshing] = useState(false); // State to control refreshing state
  const [flatListKey, setFlatListKey] = useState(0); // Key to force FlatList re-render
  const scrollViewRef = useRef(null);
  const tabPosition = useRef(0);

  const handleTabLayout = event => {
    tabPosition.current = event.nativeEvent.layout.y;
  };

  const scrollToTabs = () => {
    if (scrollViewRef.current) {
      scrollViewRef.current.scrollTo({y: tabPosition.current, animated: true});
    }
  };

  // Function to handle refresh
  const handleRefresh = async () => {
    setRefreshing(true);
    await fetchShopAndSavedReels(); // Fetch new data
    setFlatListKey(prevKey => prevKey + 1); // Update the key to force re-render of FlatList
    setRefreshing(false);
  };
  const renderItem = ({item, index}) => (
    <TouchableOpacity
      key={item.video_url_id}
      style={styles.thumbnailItem}
      onPress={() =>
        navigate('ReelsScreen', {
          shopId: shopId,
          videoId: item.video_url_id,
        })
      }
      activeOpacity={0.8}>
      <CustomBackgoundImage
        source={{uri: item.video_thumbnail_url}}
        style={styles.thumbnail}
      />
      <View style={styles.viewCountContainer}>
        <ViewsIcon width={14} height={14} fill="white" />
        <CustomText
          style={styles.viewCountText}
          text={item.video_view_count ?? 0}
          fontFamily={font.bold}
        />
      </View>
    </TouchableOpacity>
  );

  return (
    <Content
      style={{backgroundColor: 'white'}}
      refreshControl={
        <RefreshControl
          refreshing={refreshing}
          onRefresh={handleRefresh} // Trigger refresh when user pulls down
        />
      }>
      <Container>
        <ReelHeader />
        <ScrollView
          ref={scrollViewRef}
          contentContainerStyle={styles.container}
          showsVerticalScrollIndicator={false}>
          <StatusBar
            animated
            barStyle={'dark-content'}
            backgroundColor={'white'}
            translucent={false}
          />

          {shopSavedReelsLoading ? (
            <ReelPageLoader />
          ) : (
            <>
              <ReelsBrand
                shop={shopAndSavedReels?.shop}
                item={shopAndSavedReels?.shop}
              />

              {/* Tabs */}
              <View style={styles.whiteBackgroundWrapper}>
                <View style={styles.tabContainer} onLayout={handleTabLayout}>
                  <TouchableOpacity
                    style={[
                      styles.tabButton,
                      activeTab === 'Reels' && styles.activeTabButton,
                    ]}
                    onPress={() => setActiveTab('Reels')}>
                    <Icon
                      icon_type={'AntDesign'}
                      size={20}
                      name={activeTab === 'Reels' ? 'appstore1' : 'appstore-o'}
                      color={activeTab === 'Reels' ? '#000' : 'gray'}
                    />
                  </TouchableOpacity>

                  <TouchableOpacity
                    style={[
                      styles.tabButton,
                      activeTab === 'Saved' && styles.activeTabButton,
                    ]}
                    onPress={() => {
                      setActiveTab('Saved');
                      scrollToTabs();
                    }}>
                    {activeTab === 'Saved' ? (
                      <SavedImageDark />
                    ) : (
                      <SavedImage width={25} height={25} />
                    )}
                  </TouchableOpacity>
                </View>

                {/* Tab Content */}
                {activeTab === 'Reels' ? (
                  loading ? (
                    <></>
                  ) : (
                    <FlatList
                      key={flatListKey} // Add key here to force re-render when new data is fetched
                      data={shopAndSavedReels?.reels || []}
                      keyExtractor={item => item?.video_url_id?.toString()}
                      numColumns={3}
                      contentContainerStyle={styles.gridContainer}
                      renderItem={renderItem}
                      scrollEnabled={false}
                      extraData={shopAndSavedReels?.reels}
                    />
                  )
                ) : (
                  <FlatList
                    key={flatListKey} // Add key here to force re-render when new data is fetched
                    data={shopAndSavedReels?.savedReels || []}
                    keyExtractor={item => item?.video_url_id?.toString()}
                    numColumns={3}
                    contentContainerStyle={styles.gridContainer}
                    renderItem={renderItem}
                    ListEmptyComponent={
                      <View style={styles.noReelsContainer}>
                        <CustomText
                          style={styles.noReelsText}
                          text={
                            'You haven’t saved any reels from this shop yet.'
                          }
                          fontFamily={font.bold}
                        />
                      </View>
                    }
                    scrollEnabled={false}
                    extraData={shopAndSavedReels?.savedReels} // Ensure FlatList tracks changes
                  />
                )}
              </View>
            </>
          )}
        </ScrollView>
      </Container>
    </Content>
  );
};

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    backgroundColor: 'white',
  },
  tabContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginVertical: 10,
  },
  tabButton: {
    paddingVertical: 10,
    paddingHorizontal: 15,
    marginHorizontal: 40,
  },
  activeTabButton: {
    borderBottomWidth: 2,
    borderBottomColor: '#000',
  },
  gridContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    paddingHorizontal: width * 0.01,
    justifyContent: 'flex-start',
  },
  thumbnailItem: {
    width: width * 0.31,
    height: height * 0.16,
    marginBottom: width * 0.01,
    overflow: 'hidden',
    marginLeft: 3,
  },
  thumbnail: {
    width: '100%',
    height: '100%',
  },
  viewCountContainer: {
    position: 'absolute',
    bottom: 3,
    left: 1,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 8,
    paddingVertical: 4,
  },
  viewCountText: {
    color: 'white',
    marginLeft: 5,
    fontSize: 12,
    fontWeight: '500',
  },
  noReelsContainer: {
    minHeight: height - 520,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 20,
  },
  noReelsText: {
    textAlign: 'center',
    fontSize: 18,
    color: '#555',
  },
  whiteBackgroundWrapper: {},
});

export default Reels;
