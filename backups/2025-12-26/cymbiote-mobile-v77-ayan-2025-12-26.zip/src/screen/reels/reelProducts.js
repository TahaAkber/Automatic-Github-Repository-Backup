import CustomImage from '@materialComponent/image/image';
import React, {useCallback, useEffect, useRef, useState} from 'react';
import {Dimensions, StyleSheet, TouchableOpacity, View} from 'react-native';
import {moderateScale} from 'react-native-size-matters';
import Carousel from 'react-native-snap-carousel';
import CustomText from '../../materialComponent/customText/customText';
import Like from '../../materialComponent/like/like';
import {font, globalStyle, margin} from '../../constant/contstant';
import useReduxStore from '../../utils/hooks/useReduxStore';
import {navigate} from '../../utils/navigationRef/navigationRef';
import {
  defaultShopImages,
  formatPrice,
  getImageHeightFromItem,
  shareItems,
  showingVaraintPrice,
} from '../../utils/helper/helper';
import {currency} from '../../constant/signature';
import BrandTab from '../../component/brandTab/brandTab';
import ReelsLSC from './reelsLSC';

const {height, width, fontScale} = Dimensions.get('window');
const dynamicWidthHeight = width * 0.55;
const dynamicImageWidthHeight = height * 0.06;

const ReelProduct = ({
  data,
  setCurrentIndex,
  currentIndex,
  horizontal,
  bottomPlace,
  item,
  handleToggleVolume,
  toggleVolume,
  isActive,
  setIsMuted,
  isMuted,
  containerStyle,
  story,
  onProductClick, // 📊 Analytics callback
}) => {
  const arrayData = Object.values(data); // ✅ Now it's an array
  const carouselRef = useRef(null);
  const [carouselData, setCarouselData] = useState(arrayData.slice(0, 5));
  const [isLoading, setIsLoading] = useState(false);
  const {getState} = useReduxStore();
  const {fetch_favorite_list_local, fetch_favorite_list} = getState('user');
  const finalArray = [
    ...fetch_favorite_list
      .flatMap(shop => shop.products || [])
      .map(p => p.product_id),
    ...fetch_favorite_list_local.map(p => p.wishlist_product_id),
  ];
  // Simulate fetching more data
  const loadMoreData = () => {
    if (!isLoading && carouselData.length < data.length) {
      setIsLoading(true);
      setTimeout(() => {
        const newData = data.slice(
          carouselData.length,
          carouselData.length + 5,
        );
        setCarouselData([...carouselData, ...newData]);
        setIsLoading(false);
      }, 1500);
    }
  };

  const [productHeights, setProductHeights] = useState({});

  useEffect(() => {
    if (!carouselData || carouselData.length === 0) return; // 👈 guard clause
    const loadHeights = async () => {
      const heightsMap = {};

      await Promise.all(
        carouselData.map(async item => {
          try {
            const imageUrl = defaultShopImages(item)?.[0];
            const height = await getImageHeightFromItem(imageUrl);
            heightsMap[item.product_id] = height;
          } catch (err) {
            console.error('Failed to get height for', item, err);
          }
        }),
      );

      setProductHeights(heightsMap);
    };

    loadHeights();
  }, [carouselData]);

  const shareData = {
    videoId: item?.video_url_id,
    message: 'Check out this product reel.',
    image_url: item?.video_thumbnail_url,
  };
  const renderItem = useCallback(
    ({item, index}) => {
      return (
        <TouchableOpacity
          activeOpacity={0.9}
          onPress={() => {
            // 📊 Analytics: Track product click
            if (onProductClick) {
              const productData = {
                product_id: item.product_id,
                product_name: item.product_name,
                merchant_id: item.shop_id,
                merchant_name: item.shop_name,
              };
              onProductClick(productData, index);
            }

            // Navigate to product detail
            navigate('ProductDetail', {
              product_id: item.product_id,
              shop_id: item.shop_id,
              default_images: defaultShopImages(item),
              height: productHeights[item?.product_id],
            });
          }}
          style={styles.cardContainer}>
          <CustomImage
            style={styles.productImage}
            source={{uri: item.product_image_url}}
          />
          <View style={styles.textContainer}>
            <CustomText
              numberOfLines={1}
              fontSize={fontScale * 14}
              color="white"
              fontFamily={font.medium}
              text={item.product_name}
            />

            <View style={globalStyle.row}>
              <CustomText
                numberOfLines={1}
                marginTop={height * 0.003}
                fontSize={fontScale * 14}
                color="white"
                fontFamily={font.medium}
                // text={`PKR ${formatPrice(item.variant_price)}`}
                text={`${item?.product_currency || currency} ${formatPrice(
                  showingVaraintPrice(
                    item.variant_price,
                    item.variant_discounted_price,
                  ).discounted_price,
                )}`}
              />

              {item.variant_discounted_price ? (
                <CustomText
                  numberOfLines={1}
                  marginTop={height * 0.003}
                  fontSize={fontScale * 14}
                  color="white"
                  fontFamily={font.medium}
                  style={{
                    textDecorationLine: 'line-through',
                    marginLeft: 5,
                    opacity: 0.8,
                  }}
                  // text={`PKR ${formatPrice(item.variant_price)}`}
                  text={`${item?.product_currency || currency} ${formatPrice(
                    showingVaraintPrice(
                      item.variant_price,
                      item.variant_discounted_price,
                    ).original_price,
                  )}`}
                />
              ) : (
                <></>
              )}
            </View>
          </View>
          <View style={{width: '15%', aspectRatio: 1, position: 'relative'}}>
            <Like
              style={{
                position: 'absolute',
                top: '50%',
                left: '50%',
                transform: [
                  {translateX: -moderateScale(12)},
                  {translateY: -moderateScale(12)},
                ],
              }}
              size={moderateScale(15)}
              key={finalArray.length}
              product_id={item?.product_id}
            />
          </View>
        </TouchableOpacity>
      );
    },
    [onProductClick, productHeights],
  );

  return (
    <View style={[styles.container, {bottom: bottomPlace}]}>
      {/* <View style={{ marginHorizontal: margin.horizontal }}> */}

      <View style={{width: width - margin.horizontal - width * 0.06}}>
        {story ? (
          <></>
        ) : (
          <ReelsLSC
            containerStyle={containerStyle}
            horizontal
            data={item}
            fontSize={fontScale * 20}
            iconContainerStyle={{marginTop: height * 0.02}}
            isActive={isActive}
            setIsMuted={setIsMuted}
            isMuted={isMuted}
            toggleVolume={toggleVolume}
            onPress={() => shareItems('ReelsScreen', item?.id, shareData)}
          />
        )}

        {story ? (
          <></>
        ) : (
          <BrandTab
            navigateToReel
            removeFollowText
            mainViewStyle={{paddingHorizontal: 0, marginBottom: 0}}
            item={item}
            light={'white'}
            handleToggleVolume={handleToggleVolume}
            isFromReels={story ? false : true}
            // toggleVolume={toggleVolume}
          />
        )}
      </View>
      {/* </View> */}
      <View style={[!horizontal && styles.carouselContainer]}>
        <Carousel
          ref={carouselRef}
          data={carouselData}
          renderItem={renderItem}
          sliderWidth={width}
          itemWidth={width * 0.65}
          horizontal={horizontal}
          inactiveSlideOpacity={0.7} // More visible inactive slides
          inactiveSlideScale={0.9} // Smoothly reduce size of inactive slides
          loop={true} // Enables infinite scrolling
          autoplay={false} // Enables auto-scroll
          useScrollView={true}
          firstItem={2}
          z
          nestedScrollEnabled
          contentContainerCustomStyle={styles.carouselContent}
          activeSlideAlignment="center" // Ensures smooth transitions
          onSnapToItem={index => {
            setCurrentIndex?.(index); // only calls if it exists
            if (index === carouselData.length - 2) loadMoreData();
          }}
        />
      </View>
    </View>
  );
};

export default ReelProduct;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    position: 'absolute',
    right: 0,
    width: '100%',
  },
  carouselContainer: {
    alignItems: 'center',
  },
  cardContainer: {
    width: width * 0.9,
    alignSelf: 'center',

    borderRadius: 10,
    flexDirection: 'row',
    padding: width * 0.02,
    backgroundColor: 'rgba(134, 134, 134, 0.6)',
    alignItems: 'center',
    overflow: 'hidden', // Ensures child elements are clipped to the border radius
  },

  productImage: {
    height: width * 0.155,
    aspectRatio: 1,
    borderRadius: 7,
    backgroundColor: '#efefef',
    borderColor: '#f7f7f7',
  },
  textContainer: {
    width: '65%',
    marginLeft: width * 0.01,
  },
  carouselContent: {
    paddingVertical: 10,
  },
});
