import React, {useEffect} from 'react';
import {
  View,
  Dimensions,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  ImageBackground,
  ActivityIndicator,
  StatusBar,
} from 'react-native';
import {navigate} from '../../utils/navigationRef/navigationRef';
import ReelHeader from '../../component/header/reelHaader';
import LCSCard from '../../component/lcsCard/lcsCard';
import Overlay from '../../materialComponent/overlay/overlay';
import useReels from './useReels';
import ReelsBrand from './reelsBrand'; // Import the ReelsBrand component

const {width, height} = Dimensions.get('screen');

const DashboardReels = () => {
  const {reels, loading, shop, paginationAPI, paginationLoader} = useReels({
    user_id: 61,
  });

  useEffect(() => {
    paginationAPI();
  }, []);

  return (
    <View style={styles.container}>
      {loading ? (
        <ActivityIndicator size="large" color="#000" style={styles.loader} />
      ) : (
        <ScrollView
          contentContainerStyle={styles.gridContainer}
          showsVerticalScrollIndicator={false}>
          {reels.map((item, index) => (
            <TouchableOpacity
              key={item.product_id}
              style={[
                styles.reelItem,
                index === 0 ? styles.largeItem : styles.smallItem,
              ]}
              onPress={() =>
                navigate('ReelsScreen', {
                  reel: reels,
                  selectedReel: item,
                  shop: shop || {},
                })
              }
              activeOpacity={0.8}>
              <ImageBackground
                source={{uri: item.product_reel_thumbnail_url}}
                style={styles.thumbnail}>
                <Overlay reverseGradient={true} />
              </ImageBackground>
              <View style={styles.iconContainer}>
                <LCSCard
                  containerStyle={width * 0.7}
                  iconContainerStyle={[
                    styles.iconContainer,
                    index === 0 ? {} : {margin: '-5%'},
                  ]}
                />
              </View>
            </TouchableOpacity>
          ))}
          {paginationLoader && (
            <ActivityIndicator
              size="small"
              color="#000"
              style={styles.loader}
            />
          )}
        </ScrollView>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
  },
  gridContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    padding: width * 0.018,
    justifyContent: 'space-between',
  },
  reelItem: {
    borderRadius: 20,
    overflow: 'hidden',
    margin: width * 0.005,
    position: 'relative',
  },
  largeItem: {
    width: width * 0.95,
    height: height * 0.4,
  },
  smallItem: {
    width: width * 0.47,
    height: height * 0.28,
  },
  thumbnail: {
    width: '100%',
    height: '100%',
  },
  iconContainer: {
    alignSelf: 'center',
  },
  loader: {flex: 1, justifyContent: 'center', alignItems: 'center'},
});

export default DashboardReels;
